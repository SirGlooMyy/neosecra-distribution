"""Development seed for an explicitly enabled demo database.

This module is intentionally opt-in.  It must never turn a production tenant
into demo mode or add mock firewall records just because a container restarted.
Run with ``SEED_DEMO_DATA=1 python -m seed --yes`` from a disposable
development environment.
"""
import asyncio
import hashlib
import os
import sys
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.core.crypto import encrypt
from app.core.database import AsyncSessionLocal
from app.core.security import hash_password
from app.modules.auth.models import User
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.partners.models import Partner
from app.modules.tenants.models import Tenant
from app.modules.devices.models import Device, DeviceCredential
from app.modules.portal.models import PortalTemplate
from app.modules.vouchers.models import STATUS_PENDING, Voucher, VoucherBatch
from app.modules.syslog.models import FirewallLog

SUPER_ADMIN_EMAIL = "admin@hotspot.io"
SUPER_ADMIN_PASSWORD = "Admin123!"
ADMIN_EMAIL = "admin@hotspot.com"
ADMIN_PASSWORD = "Admin123!"
PARTNER_EMAIL = "partner@hotspot.io"
PARTNER_PASSWORD = "Partner123!"
CUSTOMER_EMAIL = "customer@hotspot.io"
CUSTOMER_PASSWORD = "Customer123!"


async def seed() -> None:
    if os.getenv("SEED_DEMO_DATA", "0").strip().lower() not in {"1", "true", "yes"}:
        print("[seed] skipped: set SEED_DEMO_DATA=1 to seed a disposable demo database")
        return
    async with AsyncSessionLocal() as db:
        # Root tenant
        tenant = (await db.execute(select(Tenant).where(Tenant.slug == "vdatalab"))).scalar_one_or_none()
        if not tenant:
            tenant = Tenant(name="VDataLab Operator", slug="vdatalab", is_root=True, is_demo=True)
            db.add(tenant)
            await db.flush()
            print(f"[seed] created root tenant {tenant.id}")
        # Never mutate an existing tenant's production/demo classification.
        # The flag is an installation boundary, not a seed convenience.

        # Partner
        partner = (await db.execute(select(Partner).where(Partner.tenant_id == tenant.id))).scalar_one_or_none()
        if not partner:
            partner = Partner(tenant_id=tenant.id, name="Demo Bayi", reseller_code="DEMO001",
                              contact_email="bayi@demo.io")
            db.add(partner)
            await db.flush()
            print(f"[seed] created partner {partner.id}")

        # Customer
        customer = (await db.execute(select(Customer).where(Customer.partner_id == partner.id))).scalar_one_or_none()
        if not customer:
            customer = Customer(tenant_id=tenant.id, partner_id=partner.id, name="Acme Cafe",
                                contact_email="it@acme.io")
            db.add(customer)
            await db.flush()
            print(f"[seed] created customer {customer.id}")

        # Location
        location = (await db.execute(select(Location).where(Location.customer_id == customer.id))).scalar_one_or_none()
        if not location:
            location = Location(customer_id=customer.id, name="Acme Merkez Subesi",
                                city="Istanbul", default_ssid="Acme-Guest")
            db.add(location)
            await db.flush()
            print(f"[seed] created location {location.id}")

        # Demo captive-portal anchor and a voucher path that works with the
        # bundled FortiGate simulator. The token is deliberately a local-only
        # demo value; production deployments must replace it immediately.
        device = (await db.execute(
            select(Device).where(Device.location_id == location.id).limit(1)
        )).scalar_one_or_none()
        if not device:
            device = Device(
                location_id=location.id,
                name="Demo FortiGate",
                vendor="fortigate",
                model="60F (simulator)",
                mgmt_ip="127.0.0.1",
                api_host=os.getenv("DEMO_FIREWALL_HOST", "fortigate-simulator"),
                api_port=int(os.getenv("DEMO_FIREWALL_PORT", "40000")),
                status="unknown",
                meta={"api_tls": False},
            )
            db.add(device)
            await db.flush()
            print(f"[seed] created demo device {device.id}")
        elif not device.is_active:
            # The development seed should always expose its demo integration;
            # production soft-deleted devices are never touched by this seed.
            device.is_active = True

        credential = (await db.execute(
            select(DeviceCredential).where(DeviceCredential.device_id == device.id).limit(1)
        )).scalar_one_or_none()
        if not credential:
            credential = DeviceCredential(
                device_id=device.id,
                api_token_encrypted=encrypt(os.getenv("DEMO_FIREWALL_TOKEN", "demo-token")),
                api_vdom="root",
                verify_tls=False,
            )
            db.add(credential)
        elif not credential.api_token_encrypted:
            credential.api_token_encrypted = encrypt(os.getenv("DEMO_FIREWALL_TOKEN", "demo-token"))
            credential.api_vdom = credential.api_vdom or "root"
            credential.verify_tls = False

        template = (await db.execute(
            select(PortalTemplate).where(
                PortalTemplate.customer_id == customer.id,
                PortalTemplate.location_id == location.id,
                PortalTemplate.is_active.is_(True),
            ).limit(1)
        )).scalar_one_or_none()
        if not template:
            template = PortalTemplate(
                customer_id=customer.id,
                location_id=location.id,
                name="Demo Voucher Portal",
                method="voucher",
                is_default=True,
                theme={
                    "primary_color": "#4f46e5",
                    "title": "Acme Guest Wi-Fi",
                    "subtitle": "Demo internet erisimi",
                    "terms_text": "Kullanim kosullarini ve KVKK metnini kabul ediyorum.",
                    "support_text": "Demo destek: resepsiyon",
                },
                fields=[{"name": "voucher_code", "type": "text", "required": True}],
                success_message="Erisim basariyla saglandi.",
                meta={},
            )
            db.add(template)

        batch = (await db.execute(
            select(VoucherBatch).where(
                VoucherBatch.customer_id == customer.id,
                VoucherBatch.location_id == location.id,
                VoucherBatch.name == "Demo vouchers",
            ).limit(1)
        )).scalar_one_or_none()
        if not batch:
            batch = VoucherBatch(
                customer_id=customer.id,
                location_id=location.id,
                name="Demo vouchers",
                prefix="DEMO",
                count=1,
                duration_minutes=240,
            )
            db.add(batch)
            await db.flush()
        voucher_hash = hashlib.sha256(b"DEMO2026").hexdigest()
        voucher = (await db.execute(
            select(Voucher).where(Voucher.code_hash == voucher_hash).limit(1)
        )).scalar_one_or_none()
        if not voucher:
            db.add(Voucher(
                batch_id=batch.id,
                code_hash=voucher_hash,
                code_prefix="DEMO20",
                status=STATUS_PENDING,
            ))
        else:
            # The fixed demo code is intentionally reusable between local
            # runs; real voucher batches must never be reset this way.
            voucher.status = STATUS_PENDING
            voucher.used_at = None
            voucher.used_by_session_id = None
            voucher.used_phone = None

        # Populate a small, clearly marked FortiGate traffic/event/UTM sample
        # so a fresh demo installation opens with a useful Analyzer view. The
        # idempotency marker prevents these records from being duplicated when
        # the seed command is rerun; real syslog records are never overwritten.
        demo_log_exists = (await db.execute(
            select(FirewallLog.id)
            .where(
                FirewallLog.customer_id == customer.id,
                FirewallLog.raw_syslog.like("demo-hotspot %"),
            )
            .limit(1)
        )).scalar_one_or_none()
        if not demo_log_exists:
            now = datetime.now(timezone.utc)
            demo_events = [
                ("traffic", "accept", "info", "10.10.0.42", "142.250.184.14", 51542, 443, "https", "guest-101"),
                ("traffic", "accept", "info", "10.10.0.43", "151.101.1.69", 51543, 443, "https", "guest-102"),
                ("traffic", "deny", "warning", "10.10.0.44", "203.0.113.20", 49822, 23, "telnet", "guest-103"),
                ("event", "auth", "notice", "10.10.0.42", None, None, None, "radius", "guest-101"),
                ("event", "logout", "info", "10.10.0.43", None, None, None, "captive-portal", "guest-102"),
                ("utm", "deny", "critical", "10.10.0.44", "198.51.100.7", 40112, 443, "https", "guest-103"),
                ("utm", "block", "warning", "10.10.0.45", "93.184.216.34", 53001, 80, "http", "guest-104"),
                ("traffic", "accept", "info", "10.10.0.45", "8.8.8.8", 53002, 53, "dns", "guest-104"),
                ("event", "admin-login", "warning", "10.10.0.10", None, None, None, "https", "admin"),
                ("traffic", "accept", "info", "10.10.0.46", "104.16.132.229", 53003, 443, "https", "guest-105"),
                ("utm", "monitor", "notice", "10.10.0.47", "172.217.16.14", 53004, 443, "https", "guest-106"),
                ("traffic", "timeout", "error", "10.10.0.48", "192.0.2.44", 53005, 8443, "tcp/8443", "guest-107"),
            ]
            for index, (log_type, action, severity, src_ip, dst_ip, src_port, dst_port, service, user) in enumerate(demo_events):
                event_time = now - timedelta(minutes=index * 7)
                fields = {
                    "date": event_time.strftime("%Y-%m-%d"),
                    "time": event_time.strftime("%H:%M:%S"),
                    "srcip": src_ip,
                    "dstip": dst_ip,
                    "srcport": src_port,
                    "dstport": dst_port,
                    "service": service,
                    "action": action,
                    "user": user,
                    "policyid": 100 + index,
                    "sessionid": "demo-session-" + str(index + 1).zfill(3),
                }
                db.add(FirewallLog(
                    tenant_id=tenant.id,
                    customer_id=customer.id,
                    device_id=device.id,
                    received_at=event_time,
                    event_time=event_time,
                    vendor="fortigate",
                    log_type=log_type,
                    severity=severity,
                    action=action,
                    src_ip=src_ip,
                    dst_ip=dst_ip,
                    src_port=src_port,
                    dst_port=dst_port,
                    proto="6" if dst_port in (80, 443, 8443) else ("17" if dst_port == 53 else None),
                    service=service,
                    user=user,
                    policyid=100 + index,
                    duration=30 + index * 5,
                    sentbyte=1200 + index * 430,
                    rcvdbyte=8400 + index * 1200,
                    session_id=fields["sessionid"],
                    raw_syslog="demo-hotspot " + log_type + " " + action + " " + src_ip + " -> " + str(dst_ip or "-"),
                    parsed_fields=fields,
                ))

        # VPN samples are seeded independently from the general demo marker so
        # an already-initialized demo gains the one-click VPN report too.
        vpn_log_exists = (await db.execute(
            select(FirewallLog.id)
            .where(
                FirewallLog.customer_id == customer.id,
                FirewallLog.raw_syslog.like("demo-hotspot vpn %"),
            )
            .limit(1)
        )).scalar_one_or_none()
        if not vpn_log_exists:
            now = datetime.now(timezone.utc)
            vpn_events = [
                ("ssl-vpn", "tunnel-up", "alice", "10.20.0.11", "172.16.10.11", 48_000_000, 220_000_000),
                ("ssl-vpn", "tunnel-down", "alice", "10.20.0.11", "172.16.10.11", 82_000_000, 410_000_000),
                ("ipsec", "tunnel-up", "branch-user", "10.20.0.12", "172.16.20.12", 12_000_000, 95_000_000),
                ("ipsec", "tunnel-down", "branch-user", "10.20.0.12", "172.16.20.12", 31_000_000, 180_000_000),
            ]
            for index, (subtype, action, vpn_user, src_ip, dst_ip, sent, received) in enumerate(vpn_events):
                event_time = now - timedelta(hours=index * 4 + 1)
                db.add(FirewallLog(
                    tenant_id=tenant.id,
                    customer_id=customer.id,
                    device_id=device.id,
                    received_at=event_time,
                    event_time=event_time,
                    vendor="fortigate",
                    log_type="vpn",
                    log_subtype=subtype,
                    severity="notice",
                    action=action,
                    src_ip=src_ip,
                    dst_ip=dst_ip,
                    proto="6",
                    service=subtype,
                    user=vpn_user,
                    duration=3600,
                    sentbyte=sent,
                    rcvdbyte=received,
                    session_id=f"demo-vpn-{index + 1:03d}",
                    raw_syslog=f"demo-hotspot vpn {subtype} {action} {vpn_user}",
                    parsed_fields={
                        "vpn": subtype,
                        "action": action,
                        "user": vpn_user,
                        "srcip": src_ip,
                        "dstip": dst_ip,
                    },
                ))

        # Users
        users = [
            User(email=ADMIN_EMAIL, full_name="Demo Super Admin",
                 hashed_password=hash_password(ADMIN_PASSWORD), role="super_admin"),
            User(email=SUPER_ADMIN_EMAIL, full_name="Super Admin",
                 hashed_password=hash_password(SUPER_ADMIN_PASSWORD), role="super_admin"),
            User(email=PARTNER_EMAIL, full_name="Partner Admin",
                 hashed_password=hash_password(PARTNER_PASSWORD), role="partner_admin",
                 tenant_id=tenant.id, partner_id=partner.id),
            User(email=CUSTOMER_EMAIL, full_name="Customer Admin",
                 hashed_password=hash_password(CUSTOMER_PASSWORD), role="customer_admin",
                 tenant_id=tenant.id, customer_id=customer.id),
        ]
        for u in users:
            existing = (await db.execute(select(User).where(User.email == u.email))).scalar_one_or_none()
            if not existing:
                db.add(u)
                print(f"[seed] created user {u.email} ({u.role})")

        await db.commit()

    print("\n=== Demo Credentials ===")
    print(f"super_admin    : {ADMIN_EMAIL} / {ADMIN_PASSWORD}")
    print(f"super_admin    : {SUPER_ADMIN_EMAIL} / {SUPER_ADMIN_PASSWORD}")
    print(f"partner_admin  : {PARTNER_EMAIL} / {PARTNER_PASSWORD}")
    print(f"customer_admin : {CUSTOMER_EMAIL} / {CUSTOMER_PASSWORD}")
    print("\nLogin: POST /api/v1/auth/login  {\"email\": ..., \"password\": ...}")


if __name__ == "__main__":
    if "--yes" not in sys.argv:
        print("This will seed the database. Run with: python -m seed --yes")
        sys.exit(0)
    asyncio.run(seed())
