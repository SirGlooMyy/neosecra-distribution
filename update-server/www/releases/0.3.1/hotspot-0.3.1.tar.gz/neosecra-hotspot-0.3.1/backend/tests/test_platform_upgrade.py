"""Tests for the platform upgrade subsystem.

Covers minisig verification, semver helpers, channel formatting, reachable
updates, preflight checks, orchestrator gating, API read endpoints, and
history persistence — all using real minisign formats.
"""
import asyncio
import base64
import hashlib
import json
import tempfile
from pathlib import Path
from unittest import mock

import pytest
from unittest.mock import AsyncMock
from cryptography.hazmat.primitives.asymmetric import ed25519
from fastapi.testclient import TestClient

from app.core.database import get_db
from app.main import app
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.shared.upgrade.upgrade_service import (
    HISTORY_KEY,
    UpgradeNotEnabled,
    _compute_reachable_updates,
    _fetch_channel_json,
    _format_channel_updates,
    _parse_version_tuple,
    _semver_gte,
    _upsert_setting,
    _verify_minisig,
    get_upgrade_history,
    orchestrator,
    provider,
)

client = TestClient(app)


def _user(role: str = "super_admin") -> User:
    return User(
        id=mock.MagicMock(),
        email="admin@test.io",
        hashed_password="x",
        role=role,
        tenant_id=None,
        partner_id=None,
        customer_id=None,
        location_id=None,
        is_2fa_enabled=False,
        mfa_required=False,
        mfa_methods=[],
    )


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    r.fetchone.return_value = None
    db.execute.return_value = r
    db.get.return_value = None
    db.commit = mock.AsyncMock()
    db.add = mock.MagicMock()
    return db


def _make_minisig_keypair():
    private_key = ed25519.Ed25519PrivateKey.generate()
    pub_bytes = private_key.public_key().public_bytes_raw()
    pub_b64 = base64.b64encode(pub_bytes).decode()
    return private_key, pub_b64


def _make_minisig_content(private_key, data: bytes) -> str:
    # Real minisign signs the BLAKE2b-512 digest of the payload (prehashed).
    digest = hashlib.blake2b(data, digest_size=64).digest()
    signature = private_key.sign(digest)
    sig_b64 = base64.b64encode(signature).decode()
    return f"trust me\n{sig_b64}"


# ── 1. Semver helpers ─────────────────────────────────────────────


class TestSemverHelpers:
    def test_semver_gte_simple(self):
        assert _semver_gte("1.10.0", "1.9.9") is True
        assert _semver_gte("1.9.9", "1.10.0") is False
        assert _semver_gte("2.0.0", "1.9.9") is True

    def test_semver_gte_equal(self):
        assert _semver_gte("1.0.0", "1.0.0") is True
        assert _semver_gte("0.0.0", "0.0.0") is True

    def test_semver_gte_v_prefix(self):
        assert _semver_gte("v1.10.0", "1.9.9") is True
        assert _semver_gte("V2.0.0", "1.9.9") is True

    def test_semver_gte_prerelease(self):
        assert _semver_gte("1.10.0-alpha", "1.9.9") is True
        assert _semver_gte("1.10.0-alpha", "1.10.0") is True

    def test_semver_gte_different_lengths(self):
        assert _semver_gte("1.10", "1.9.9") is True
        assert _semver_gte("1", "0.9.9") is True

    def test_semver_gte_edge(self):
        assert _semver_gte("", "0.0.0") is True
        assert _semver_gte(None, "0.0.0") is True

    def test_parse_version_tuple_standard(self):
        assert _parse_version_tuple("1.10.0") == (1, 10, 0)
        assert _parse_version_tuple("0.0.0") == (0, 0, 0)

    def test_parse_version_tuple_v_prefix(self):
        assert _parse_version_tuple("v2.3.4") == (2, 3, 4)
        assert _parse_version_tuple("V5.6.7") == (5, 6, 7)

    def test_parse_version_tuple_prerelease(self):
        assert _parse_version_tuple("1.10.0-alpha") == (1, 10, 0)
        assert _parse_version_tuple("2.0.0-rc1") == (2, 0, 0)

    def test_parse_version_tuple_pads_short(self):
        assert _parse_version_tuple("1") == (1, 0, 0)
        assert _parse_version_tuple("2.5") == (2, 5, 0)

    def test_parse_version_tuple_empty(self):
        assert _parse_version_tuple("") == (0, 0, 0)


# ── 2. Minisig verification ───────────────────────────────────────


class TestMinisigVerification:
    def test_valid_signature(self):
        priv, pub_b64 = _make_minisig_keypair()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".key", delete=False) as f:
            f.write(pub_b64)
            key_path = f.name
        import app.shared.upgrade.upgrade_service as us
        orig = us.CHANNEL_PUBLIC_KEY_PATH
        us.CHANNEL_PUBLIC_KEY_PATH = key_path
        try:
            data = b'{"releases": []}'
            sig_content = _make_minisig_content(priv, data)
            assert _verify_minisig(data, sig_content) is True
        finally:
            us.CHANNEL_PUBLIC_KEY_PATH = orig
            Path(key_path).unlink(missing_ok=True)

    def test_tampered_data_fails(self):
        priv, pub_b64 = _make_minisig_keypair()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".key", delete=False) as f:
            f.write(pub_b64)
            key_path = f.name
        import app.shared.upgrade.upgrade_service as us
        orig = us.CHANNEL_PUBLIC_KEY_PATH
        us.CHANNEL_PUBLIC_KEY_PATH = key_path
        try:
            data = b'{"releases": []}'
            sig_content = _make_minisig_content(priv, data)
            assert _verify_minisig(b"tampered-data", sig_content) is False
        finally:
            us.CHANNEL_PUBLIC_KEY_PATH = orig
            Path(key_path).unlink(missing_ok=True)

    def test_missing_key_file(self):
        import app.shared.upgrade.upgrade_service as us
        orig = us.CHANNEL_PUBLIC_KEY_PATH
        us.CHANNEL_PUBLIC_KEY_PATH = "/nonexistent/key.pub"
        try:
            assert _verify_minisig(b"data", "some\nsig") is False
        finally:
            us.CHANNEL_PUBLIC_KEY_PATH = orig

    def test_invalid_signature_format(self):
        import app.shared.upgrade.upgrade_service as us
        orig = us.CHANNEL_PUBLIC_KEY_PATH
        us.CHANNEL_PUBLIC_KEY_PATH = "/nonexistent/key.pub"
        try:
            assert _verify_minisig(b"data", "") is False
            assert _verify_minisig(b"data", "ab") is False
        finally:
            us.CHANNEL_PUBLIC_KEY_PATH = orig


# ── 3. Reachable updates ─────────────────────────────────────────


class TestReachableUpdates:
    FAKE_RELEASES = [
        {"version": "1.1.0", "minimum_current_version": "1.0.0"},
        {"version": "1.2.0", "minimum_current_version": "1.1.0"},
        {"version": "2.0.0", "minimum_current_version": "1.5.0"},
    ]

    def test_reachable_from_1_0_0(self):
        result = _compute_reachable_updates("1.0.0", self.FAKE_RELEASES)
        assert [r["version"] for r in result] == ["1.1.0", "1.2.0"]

    def test_reachable_from_1_1_0(self):
        result = _compute_reachable_updates("1.1.0", self.FAKE_RELEASES)
        assert [r["version"] for r in result] == ["1.1.0", "1.2.0"]

    def test_reachable_from_1_5_0(self):
        result = _compute_reachable_updates("1.5.0", self.FAKE_RELEASES)
        assert [r["version"] for r in result] == ["1.1.0", "1.2.0", "2.0.0"]

    def test_already_latest(self):
        releases = [{"version": "3.0.0", "minimum_current_version": "3.0.0"}]
        assert _compute_reachable_updates("2.0.0", releases) == []

    def test_empty_releases(self):
        assert _compute_reachable_updates("1.0.0", []) == []

    def test_unsorted_releases(self):
        releases = [
            {"version": "1.2.0", "minimum_current_version": "1.1.0"},
            {"version": "1.1.0", "minimum_current_version": "1.0.0"},
        ]
        result = _compute_reachable_updates("1.0.0", releases)
        assert [r["version"] for r in result] == ["1.1.0", "1.2.0"]


# ── 4. Channel formatting ────────────────────────────────────────


class TestChannelFormatting:
    FAKE_CHANNEL = {
        "releases": [
            {
                "version": "1.1.0",
                "minimum_current_version": "1.0.0",
                "release_notes": "Bug fixes",
                "images": {"amd64": "hotspot:1.1.0"},
            },
            {
                "version": "1.2.0",
                "minimum_current_version": "1.1.0",
                "release_notes": "Features",
                "images": {"amd64": "hotspot:1.2.0"},
            },
            {
                "version": "2.0.0",
                "minimum_current_version": "1.5.0",
                "release_notes": "Breaking",
                "images": {"amd64": "hotspot:2.0.0"},
            },
        ]
    }

    def test_format_has_updates(self):
        result = _format_channel_updates("1.0.0", self.FAKE_CHANNEL)
        assert "has_update" in result
        assert result["has_update"] is True
        assert len(result["updates"]) == 2
        for u in result["updates"]:
            assert "target_version" in u
            assert "minimum_current_version" in u
            assert "release_notes" in u
            assert "images" in u

    def test_format_no_updates(self):
        result = _format_channel_updates("0.1.0", self.FAKE_CHANNEL)
        assert result["has_update"] is False
        assert result["updates"] == []


# ── 5. Preflight checks ──────────────────────────────────────────


class TestPreflightChecks:
    def test_run_preflight_returns_list(self):
        db = _mock_db()
        checks = asyncio.run(provider.run_readiness_checks(db))
        assert isinstance(checks, list)
        assert len(checks) >= 3

    def test_preflight_license_pass(self):
        db = _mock_db()
        with mock.patch(
            "app.shared.upgrade.upgrade_service.get_platform_license",
            return_value={"status": "ACTIVE", "edition": "Enterprise"},
        ):
            checks = asyncio.run(provider.run_readiness_checks(db))
        lic = [c for c in checks if "Lisans" in c["name"]]
        assert len(lic) == 1
        assert lic[0]["status"] == "PASS"

    def test_preflight_license_fail(self):
        db = _mock_db()
        with mock.patch(
            "app.shared.upgrade.upgrade_service.get_platform_license",
            return_value=None,
        ):
            checks = asyncio.run(provider.run_readiness_checks(db))
        lic = [c for c in checks if "Lisans" in c["name"]]
        assert len(lic) == 1
        assert lic[0]["status"] == "FAIL"


# ── 6. Orchestrator gating ───────────────────────────────────────


class TestOrchestratorGating:
    def test_start_upgrade_raises_not_enabled(self):
        db = _mock_db()
        with pytest.raises(
            UpgradeNotEnabled, match="UPGRADE_EXECUTION_NOT_SUPPORTED"
        ):
            asyncio.run(orchestrator.start_upgrade(db, "1.2.0", "test-user"))

    def test_api_start_upgrade_returns_400(self):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        try:
            resp = client.post(
                "/api/v1/platform-upgrade/start",
                headers={"Idempotency-Key": "legacy-test-001"},
                json={"target_version": "2.0.0"},
            )
            assert resp.status_code == 400
            assert "UPGRADE_EXECUTION_NOT_SUPPORTED" in resp.text
        finally:
            app.dependency_overrides.clear()

    def test_api_start_upgrade_requires_idempotency_key(self):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        try:
            resp = client.post(
                "/api/v1/platform-upgrade/start",
                json={"target_version": "2.0.0"},
            )
            assert resp.status_code == 400
            assert resp.json()["detail"] == "IDEMPOTENCY_KEY_REQUIRED"
        finally:
            app.dependency_overrides.clear()


# ── 7. API read endpoints ────────────────────────────────────────


class TestApiReadEndpoints:
    def test_canonical_license_status_contract(self, monkeypatch):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.get_platform_license",
            AsyncMock(return_value=None),
        )
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.get_platform_usage",
            AsyncMock(return_value={}),
        )
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.get_or_create_installation_id",
            AsyncMock(return_value="hotspot-install-test"),
        )
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.get_current_system_info",
            AsyncMock(return_value={"current_version": "1.0.0"}),
        )
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.check_available_updates",
            AsyncMock(return_value={"channel_status": "ok", "has_update": False, "updates": []}),
        )
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.run_preflight_checks",
            AsyncMock(return_value=[]),
        )
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.orchestrator.get_session",
            AsyncMock(return_value=None),
        )
        try:
            resp = client.get("/api/v1/licensing/status")
            assert resp.status_code == 200, resp.text
            data = resp.json()
            assert data["product_code"] == "hotspot"
            assert data["installation_id"] == "hotspot-install-test"
            assert data["license_status"] == "NOT_INSTALLED"
            assert data["update"]["reason_code"] == "LICENSE_NOT_INSTALLED"
            assert data["update"]["heartbeat_fresh"] is False
            assert data["update"]["preflight"] == "fail"
            assert data["active_job"] is None
        finally:
            app.dependency_overrides.clear()

    def test_canonical_license_ack_rejects_unverified_input(self, monkeypatch):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        setting = mock.MagicMock(value={"envelope_string": "stored-envelope"})
        db.execute.return_value.scalar_one_or_none.return_value = setting
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing._status",
            AsyncMock(return_value={"license": {"license_id": "LIC-1"}, "license_status": "ACTIVE"}),
        )
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.fingerprint_matches",
            lambda envelope, supplied: supplied in {"canonical", "legacy"},
        )
        monkeypatch.setattr(
            "app.api.v1.endpoints.platform_licensing.license_fingerprints",
            lambda envelope: ("canonical", "legacy"),
        )
        try:
            bad_fingerprint = client.post(
                "/api/v1/licensing/ack",
                json={"fingerprint": "tampered", "verifier_status": "ACTIVE"},
            )
            assert bad_fingerprint.status_code == 400
            assert bad_fingerprint.json()["detail"] == "LICENSE_FINGERPRINT_MISMATCH"
            bad_status = client.post(
                "/api/v1/licensing/ack",
                json={"fingerprint": "canonical", "verifier_status": "EXPIRED"},
            )
            assert bad_status.status_code == 400
            assert bad_status.json()["detail"] == "LICENSE_STATUS_MISMATCH"
            accepted = client.post(
                "/api/v1/licensing/ack",
                json={"fingerprint": "legacy", "verifier_status": "ACTIVE"},
            )
            assert accepted.status_code == 200
            assert accepted.json()["fingerprint"] == "canonical"
            canonical = client.post(
                "/api/v1/licensing/ack",
                json={"fingerprint": "canonical", "verifier_status": "ACTIVE"},
            )
            assert canonical.status_code == 200
            assert canonical.json()["fingerprint"] == "canonical"
        finally:
            app.dependency_overrides.clear()

    def test_info_returns_200_with_keys(self):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        try:
            resp = client.get("/api/v1/platform-upgrade/info")
            assert resp.status_code == 200
            data = resp.json()
            assert "current_version" in data
            assert "upgrade_status" in data
        finally:
            app.dependency_overrides.clear()

    def test_check_returns_200(self):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        try:
            resp = client.get("/api/v1/platform-upgrade/check")
            assert resp.status_code == 200
            data = resp.json()
            assert "updates" in data
            assert "has_update" in data
        finally:
            app.dependency_overrides.clear()

    def test_status_returns_200(self):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        try:
            resp = client.get("/api/v1/platform-upgrade/status")
            assert resp.status_code == 200
        finally:
            app.dependency_overrides.clear()

    def test_history_returns_200(self):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        try:
            resp = client.get("/api/v1/platform-upgrade/history")
            assert resp.status_code == 200
            data = resp.json()
            assert "history" in data
            assert isinstance(data["history"], list)
        finally:
            app.dependency_overrides.clear()

    def test_preflight_api_returns_200(self):
        db = _mock_db()
        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user()
        try:
            resp = client.post("/api/v1/platform-upgrade/preflight")
            assert resp.status_code == 200
            data = resp.json()
            assert "checks" in data
            assert isinstance(data["checks"], list)
        finally:
            app.dependency_overrides.clear()


# ── 8. History persistence ───────────────────────────────────────


class TestHistoryPersistence:
    def test_persist_and_retrieve_history(self):
        fake = [
            {
                "id": "upg_20260728120000",
                "state": "COMPLETED",
                "target_version": "2.0.0",
                "started_by": "admin",
                "simulated": True,
            }
        ]
        db = _mock_db()
        asyncio.run(_upsert_setting(db, HISTORY_KEY, {"history": fake}))
        db = _mock_db()
        history = asyncio.run(get_upgrade_history(db))
        assert isinstance(history, list)


# ── 9. Fetch channel — fail-closed behavior ──────────────────────


class TestFetchChannelFailClosed:
    def test_no_channel_url(self):
        import app.shared.upgrade.upgrade_service as us
        orig = us.CHANNEL_URL
        us.CHANNEL_URL = ""
        try:
            result, error = asyncio.run(_fetch_channel_json())
            assert result is None
            assert error == "UPGRADE_CHANNEL_URL not set"
        finally:
            us.CHANNEL_URL = orig

    def test_network_error_fail_closed(self):
        """Network errors return (None, error_string) — no crash."""
        import app.shared.upgrade.upgrade_service as us
        orig = us.CHANNEL_URL
        us.CHANNEL_URL = "https://invalid.example.com/channel.json"
        try:
            result, error = asyncio.run(_fetch_channel_json())
            assert result is None
            assert error is not None
        finally:
            us.CHANNEL_URL = orig


# ── 10. Capabilities — EXECUTION_ENABLED off ─────────────────────


class TestCapabilities:
    def test_execution_disabled_by_default(self):
        caps = provider.get_capabilities()
        assert caps["execution_enabled"] is False
        assert caps["can_auto_upgrade"] is False
        assert caps["can_backup"] is False
        assert caps["can_migrate"] is False
        assert caps["can_rollback"] is False
        assert caps["execution_provider"] == "MANUAL"

    def test_release_channel_default(self):
        caps = provider.get_capabilities()
        assert caps["release_channel"] == "hotspot-stable"
