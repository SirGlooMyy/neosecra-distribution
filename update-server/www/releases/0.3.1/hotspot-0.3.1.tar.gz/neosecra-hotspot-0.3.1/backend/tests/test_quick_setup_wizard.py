import pytest
import uuid
from unittest.mock import AsyncMock, MagicMock
from app.modules.system.wizard_service import QuickSetupIn, run_quick_setup
from app.modules.auth.models import User

@pytest.mark.asyncio
async def test_quick_setup_wizard_flow():
    db = AsyncMock()
    mock_customer_id = uuid.uuid4()
    
    user = User(
        id=uuid.uuid4(),
        email="admin@hotspot.io",
        role="super_admin",
        customer_id=mock_customer_id,
    )
    
    payload = QuickSetupIn(
        location_name="Test Hotel Spa",
        capacity_profile="medium",
        gateway_type="fortigate",
        gateway_ip="192.168.10.1",
        shared_secret="Secret12345!",
        auth_methods=["tc_sms", "pms", "free"],
        session_timeout_minutes=180,
        download_speed_mbps=25,
        upload_speed_mbps=5,
        daily_data_quota_mb=4096,
        portal_title="Test Hotel Wi-Fi",
        portal_welcome_text="Hoş geldiniz",
        enable_5651_sealing=True,
    )
    
    result = await run_quick_setup(db, user, payload)
    
    assert result.success is True
    assert result.location_name == "Test Hotel Spa"
    assert "config user radius" in result.cli_snippet
    assert "Secret12345!" in result.cli_snippet
    assert str(result.location_id) in result.portal_url
    assert db.add.call_count >= 4
    assert db.commit.called
