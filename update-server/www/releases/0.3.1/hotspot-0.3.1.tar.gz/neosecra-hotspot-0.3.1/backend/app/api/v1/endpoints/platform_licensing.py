"""Canonical product-neutral platform licensing endpoints.

The legacy ``/api/v1/system/license*`` and customer ``/api/v1/licenses``
routes remain intact. This namespace is the stable contract consumed by the
shared License/Update screen in all NeoSecra products.
"""

from datetime import datetime, timezone
from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.audit.service import log_audit
from app.shared.licensing.contract import CHANNEL, PRODUCT_CODE, update_entitlement_expired
from app.shared.licensing.license_service import (
    fingerprint_matches,
    get_or_create_installation_id,
    get_platform_license,
    get_platform_usage,
    license_fingerprints,
    save_platform_license,
)
from app.modules.system.models import PlatformSetting
from app.shared.upgrade.upgrade_service import (
    check_available_updates,
    get_current_system_info,
    orchestrator,
    provider,
    run_preflight_checks,
)

router = APIRouter(prefix="/licensing", tags=["licensing"])


class LicenseInstallRequest(BaseModel):
    license_envelope: str


class LicenseAckRequest(BaseModel):
    fingerprint: str
    verifier_status: str


DELIVERY_SETTING_KEY = "platform_license_delivery"


async def _delivery_state(db: AsyncSession) -> dict:
    row = (await db.execute(select(PlatformSetting).where(PlatformSetting.key == DELIVERY_SETTING_KEY))).scalar_one_or_none()
    return dict(row.value or {}) if row and isinstance(row.value, dict) else {"status": "NOT_ACKNOWLEDGED"}


async def _record_delivery(db: AsyncSession, **values: str) -> dict:
    row = (await db.execute(select(PlatformSetting).where(PlatformSetting.key == DELIVERY_SETTING_KEY))).scalar_one_or_none()
    state = {**(row.value or {})} if row and isinstance(row.value, dict) else {}
    state.update(values)
    if row:
        row.value = state
    else:
        db.add(PlatformSetting(key=DELIVERY_SETTING_KEY, value=state))
    await db.commit()
    return state


def _require(user: User, write: bool = False) -> None:
    permission = "system.write" if write else "system.read"
    if not has_permission(user.role, permission):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


async def _status(db: AsyncSession) -> dict:
    license_data = await get_platform_license(db)
    system = await get_current_system_info(db)
    updates = await check_available_updates(db)
    checks = await run_preflight_checks(db)
    release = (updates.get("updates") or [None])[0]
    caps = provider.get_capabilities()
    active_job = await orchestrator.get_session(db)
    license_status = (license_data or {}).get("status", "NOT_INSTALLED")
    channel_status = str(updates.get("channel_status") or "unknown")
    preflight_pass = bool(checks) and all(c.get("status") == "PASS" for c in checks)
    if license_status == "NOT_INSTALLED":
        reason_code = "LICENSE_NOT_INSTALLED"
    elif license_status in {"EXPIRED", "REVOKED", "INVALID_PRODUCT", "INVALID_SIGNATURE", "INSTALLATION_MISMATCH", "NOT_YET_VALID"}:
        reason_code = f"LICENSE_{license_status}"
    elif update_entitlement_expired(license_data):
        reason_code = "UPDATE_ENTITLEMENT_EXPIRED"
    elif channel_status == "ok" and not updates.get("has_update"):
        reason_code = "NO_RELEASE"
    elif channel_status != "ok":
        reason_code = "CHANNEL_INVALID"
    elif str(caps.get("execution_provider", "MANUAL")).upper() == "AGENT" and not caps.get("heartbeat_fresh"):
        reason_code = "AGENT_STALE"
    elif not caps.get("execution_enabled"):
        reason_code = "MANUAL_ONLY"
    elif not preflight_pass:
        reason_code = "PREFLIGHT_FAILED"
    elif not caps.get("can_auto_upgrade"):
        reason_code = "UPGRADE_NOT_READY"
    else:
        reason_code = None
    return {
        "product_code": PRODUCT_CODE,
        "installation_id": (license_data or {}).get("installation_id") or await get_or_create_installation_id(db),
        "current_version": system.get("current_version"),
        "license_status": license_status,
        "license": license_data,
        "usage": await get_platform_usage(db),
        "update": {
            "channel": CHANNEL,
            "channel_status": channel_status,
            "target_version": (release or {}).get("target_version") or (release or {}).get("version"),
            "can_auto_upgrade": bool(
                caps.get("can_auto_upgrade")
                and license_data
                and license_status in {"ACTIVE", "EXPIRING_SOON", "GRACE_PERIOD"}
                and not update_entitlement_expired(license_data)
                and updates.get("has_update")
                and preflight_pass
            ),
            "can_backup": bool(caps.get("can_backup")),
            "can_rollback": bool(caps.get("can_rollback")),
            "heartbeat_fresh": bool(caps.get("heartbeat_fresh", False)),
            "preflight": "pass" if preflight_pass else "fail",
            "has_update": bool(updates.get("has_update")),
            "reason_code": reason_code,
        },
        "active_job": active_job,
        "delivery": await _delivery_state(db),
    }


@router.get("/status")
async def get_status(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user)
    return await _status(db)


@router.post("/install")
async def install(body: LicenseInstallRequest, request: Request, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, True)
    envelope = body.license_envelope.strip()
    if not await save_platform_license(db, envelope, user_id=str(user.id)):
        await log_audit(db, "license.install_failed", "system", None, user.id, request, {"reason": "signature_validation_failed"})
        await db.commit()
        raise HTTPException(status_code=400, detail="LICENSE_SIGNATURE_INVALID")
    result = await _status(db)
    canonical_fingerprint = (result.get("license") or {}).get("fingerprint")
    await log_audit(db, "license.installed", "system", None, user.id, request, {"fingerprint": canonical_fingerprint})
    await db.commit()
    result["delivery"] = {"status": "APPLIED", "fingerprint": canonical_fingerprint}
    result["delivery"] = await _record_delivery(db, status="APPLIED", fingerprint=str(canonical_fingerprint or ""), applied_at=datetime.now(timezone.utc).isoformat())
    return result


@router.post("/install/file")
async def install_file(request: Request, file: UploadFile = File(...), db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, True)
    content = await file.read(2_000_001)
    if len(content) > 2_000_000:
        raise HTTPException(status_code=413, detail="LICENSE_FILE_TOO_LARGE")
    try:
        envelope = content.decode("utf-8").strip()
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="LICENSE_FORMAT_INVALID")
    # Keep file imports on the same audited canonical install path.
    return await install(LicenseInstallRequest(license_envelope=envelope), request, db, user)


@router.post("/validate")
async def validate(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user)
    if not await get_platform_license(db):
        raise HTTPException(status_code=404, detail="LICENSE_NOT_INSTALLED")
    return await _status(db)


@router.delete("", status_code=status.HTTP_204_NO_CONTENT)
async def remove(request: Request, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, True)
    from app.shared.licensing.license_service import delete_platform_license
    await delete_platform_license(db)
    await log_audit(db, "license.deleted", "system", None, user.id, request)
    await db.commit()
    return None


@router.post("/ack")
async def acknowledge(body: LicenseAckRequest, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, True)
    data = await _status(db)
    if data["license"] is None:
        raise HTTPException(status_code=404, detail="LICENSE_NOT_INSTALLED")
    setting = (await db.execute(
        select(PlatformSetting).where(PlatformSetting.key == "platform_license")
    )).scalar_one_or_none()
    raw = setting.value if setting else None
    if isinstance(raw, str):
        try:
            import json
            raw = json.loads(raw)
        except (TypeError, ValueError):
            raw = None
    envelope = raw.get("envelope_string") if isinstance(raw, dict) else raw
    if not envelope or not fingerprint_matches(str(envelope), body.fingerprint):
        raise HTTPException(status_code=400, detail="LICENSE_FINGERPRINT_MISMATCH")
    expected_status = str(data.get("license_status") or "").upper()
    if body.verifier_status.strip().upper() != expected_status:
        raise HTTPException(status_code=400, detail="LICENSE_STATUS_MISMATCH")
    canonical_fingerprint = license_fingerprints(str(envelope))[0]
    delivery = await _record_delivery(db, status="ACKNOWLEDGED", fingerprint=canonical_fingerprint, verifier_status=expected_status, acknowledged_at=datetime.now(timezone.utc).isoformat())
    return {
        "status": "ACKNOWLEDGED",
        "fingerprint": canonical_fingerprint,
        "verifier_status": expected_status,
        "license_status": expected_status,
        "delivery": delivery,
    }
