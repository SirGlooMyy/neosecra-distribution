import logging

from pydantic_settings import BaseSettings, SettingsConfigDict

log = logging.getLogger(__name__)


class ProductionSettingsError(RuntimeError):
    """Raised when production configuration is unsafe."""


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=True)

    PROJECT_NAME: str = "Hotspot Platform"
    VERSION: str = "0.3.5"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    # Explicit demo toggle for mock fallbacks. Off by default so production
    # builds do not quietly behave like demos.
    DEMO_MODE: bool = False

    # This installation is intentionally single-customer.  The customer row
    # remains as an internal ownership anchor for existing records, but API
    # callers do not select a tenant/customer.  Set this explicitly in
    # production when more than one legacy customer row exists.
    SINGLE_TENANT_MODE: bool = True
    SINGLE_TENANT_CUSTOMER_ID: str = ""

    # Disable IP-based rate limiting (dev/test convenience). NEVER enable in
    # production — rate limits are a security boundary against brute force.
    DISABLE_RATE_LIMIT: bool = False

    # --- Database ---
    DATABASE_URL: str = "postgresql+asyncpg://hotspot:hotspot@postgres:5432/hotspot"
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20

    # --- Redis ---
    REDIS_URL: str = "redis://redis:6379/0"

    # --- MinIO / S3 (5651 archive + reports) ---
    MINIO_ENDPOINT: str = "http://minio:9000"
    MINIO_ACCESS_KEY: str = "minioadmin"
    MINIO_SECRET_KEY: str = "minioadmin"
    MINIO_BUCKET_5651: str = "hotspot-5651"
    MINIO_BUCKET_REPORTS: str = "hotspot-reports"
    MINIO_BUCKET_UPDATES: str = "hotspot-updates"
    MINIO_SECURE: bool = False

    # --- Security / JWT ---
    SECRET_KEY: str = "change-me-in-production-please-use-at-least-32-characters"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # --- Fernet key for firewall token / secrets encryption ---
    # Empty -> generated at startup (dev only). Production MUST set a stable key.
    CRYPTO_KEY: str = ""

    # --- Auth hardening ---
    LOGIN_MAX_ATTEMPTS: int = 5
    LOGIN_WINDOW_MINUTES: int = 15
    TWO_FA_ENABLED: bool = False

    # --- MFA (Multi-Factor Authentication) ---
    MFA_TOTP_ISSUER: str = "Hotspot Platform"
    MFA_CODE_LENGTH: int = 6
    MFA_CODE_TTL_SECONDS: int = 300
    MFA_MAX_ATTEMPTS: int = 3

    # --- SMS OTP (captive portal guest auth) ---
    # Provider: "console" (dev, logs code), "log" (same), "http" (real gateway),
    # or one of: "netgsm", "vatansms", "iletimerkezi", "twilio", "muttl", "relateddigital".
    SMS_PROVIDER: str = "console"
    SMS_OTP_LENGTH: int = 6
    SMS_OTP_TTL_SECONDS: int = 180
    SMS_OTP_MAX_ATTEMPTS: int = 3
    # Per-phone send rate limit (abuse / flooding guard).
    SMS_SEND_MAX_PER_WINDOW: int = 3
    SMS_SEND_WINDOW_MINUTES: int = 15
    # Real HTTP provider (used only when SMS_PROVIDER == "http").
    SMS_HTTP_URL: str = ""
    SMS_HTTP_TOKEN: str = ""
    SMS_SENDER: str = "HOTSPOT"

    # --- SMS Provider-specific credentials ---
    NETGSM_USER: str = ""
    NETGSM_PASS: str = ""
    NETGSM_USERCODE: str = ""
    NETGSM_PASSWORD: str = ""
    NETGSM_MSGHEADER: str = ""
    VATANSMS_API_KEY: str = ""
    VATANSMS_API_ID: str = ""
    ILETIMERKEZI_API_KEY: str = ""
    ILETIMERKEZI_API_HASH: str = ""
    ILETIMERKEZI_API_URL: str = ""
    TWILIO_ACCOUNT_SID: str = ""
    TWILIO_AUTH_TOKEN: str = ""
    TWILIO_FROM_NUMBER: str = ""
    MUTTL_API_KEY: str = ""
    MUTTL_API_URL: str = ""
    RELATEDDIGITAL_API_KEY: str = ""
    RELATEDDIGITAL_API_URL: str = ""

    # --- NVI (National Identity Verification) ---
    NVI_ENABLED: bool = True
    # TLS verification must stay on by default; dev overrides can disable it
    # only when an on-prem NVI endpoint uses a custom CA.
    NVI_VERIFY_TLS: bool = True
    NVI_CACHE_TTL: int = 86400

    # --- Captive portal flow ---
    # Short-lived token binding a verified guest identity to a portal session.
    PORTAL_TOKEN_TTL_SECONDS: int = 300
    # Public URL used in manager approval e-mails. If empty, the request host
    # is used (suitable for on-prem/demo installations).
    PORTAL_PUBLIC_BASE_URL: str = ""
    PORTAL_APPROVAL_TOKEN_TTL_MINUTES: int = 30
    # Default guest session duration when policy/voucher gives none (minutes).
    GUEST_SESSION_DEFAULT_MINUTES: int = 240

    # --- 5651 archive (append-only + hash chain, Mutlak Kural #4) ---
    # Object-store provider: "local" (file, dev/on-prem), "minio" (S3-compatible,
    # lazy-imported so the app runs without the client lib), "none" (dev, no
    # upload — archive record still created, content_ref points to content hash).
    ARCHIVE_PROVIDER: str = "local"
    ARCHIVE_LOCAL_DIR: str = "./_archives"
    ARCHIVE_MINIO_ENDPOINT: str = ""        # e.g. minio:9000
    ARCHIVE_MINIO_ACCESS_KEY: str = ""
    ARCHIVE_MINIO_SECRET_KEY: str = ""      # set via env, never logged
    ARCHIVE_MINIO_BUCKET: str = "hotspot-5651"
    ARCHIVE_MINIO_SECURE: bool = False

    # --- RADIUS Enterprise / 802.1X ---
    EAP_CERT_DIR: str = "/opt/freeradius/certs"
    FREERADIUS_CONFIG_DIR: str = "/etc/freeradius"
    MAB_ENABLED: bool = False
    RADIUS_ENTERPRISE_ENABLED: bool = False

    # --- RADIUS VPN MFA ---
    # The bundled FreeRADIUS listener is part of the Hotspot installation.
    # RADIUS_LISTENER_HOST is the address FortiGate can reach (it is not the
    # Docker service name); leave empty to let the API use the request host.
    RADIUS_LISTENER_HOST: str = ""
    RADIUS_LISTENER_PORT: int = 1812
    RADIUS_LISTENER_ACCOUNTING_PORT: int = 1813
    RADIUS_INTERNAL_HOST: str = "freeradius"
    RADIUS_INTERNAL_PORT: int = 1812
    # Private named volume shared only by API and the bundled FreeRADIUS
    # container. Plaintext client definitions never cross an HTTP boundary.
    RADIUS_RUNTIME_CLIENTS_FILE: str = "/var/lib/hotspot/radius-runtime/clients.conf"
    # Accounting freshness window used when presenting live RADIUS sessions.
    # NAS devices should send an Interim-Update at this interval.
    RADIUS_INTERIM_INTERVAL_SECONDS: int = 300
    # API key for FreeRADIUS rest module calls to challenge endpoints.
    RADIUS_API_KEY: str = ""
    # API key for the syslog HTTP ingestion endpoint.
    SYSLOG_API_KEY: str = ""

    # --- LDAP / AD (captive portal enterprise auth) ---
    LDAP_URL: str = "ldap://localhost:389"
    LDAP_BIND_DN: str = ""
    LDAP_BIND_PASSWORD: str = ""
    LDAP_BASE_DN: str = ""
    LDAP_SEARCH_FILTER: str = "(|(sAMAccountName={username})(uid={username})(userPrincipalName={username}@*))"

    # --- 5651 / TUBITAK KamuSM Digital Signing ---
    TUBITAK_KAMUSM_ENABLED: bool = False
    TUBITAK_KAMUSM_API_URL: str = "https://kamusm.tubitak.gov.tr/sign"
    TUBITAK_KAMUSM_USERNAME: str = ""
    TUBITAK_KAMUSM_PASSWORD: str = ""
    TUBITAK_CERTIFICATE_PATH: str = ""
    TUBITAK_CERTIFICATE_PASSWORD: str = ""
    EVIDENCE_STORAGE_PATH: str = "./_evidence"

    # --- ClickHouse (sıcak/soğuk log depolama) ---
    CLICKHOUSE_HOST: str = "clickhouse"
    # ClickHouse is optional for the MVP; PostgreSQL remains the source of
    # truth when this is disabled.  Operators can enable hot-log analytics
    # explicitly in environments where the HTTP endpoint is provisioned.
    CLICKHOUSE_ENABLED: bool = True
    # clickhouse-connect speaks the HTTP protocol; native port 9000 would
    # return a protocol error.  Keep 8123 as the service default.
    CLICKHOUSE_PORT: int = 8123
    CLICKHOUSE_DB: str = "hotspot"
    CLICKHOUSE_USER: str = "default"
    CLICKHOUSE_PASSWORD: str = ""
    CLICKHOUSE_CONNECT_TIMEOUT: int = 10
    CLICKHOUSE_SEND_TIMEOUT: int = 30

    # --- Arşiv retention (5651, Mutlak Kural #4) ---
    ARCHIVE_RETENTION_DAYS: int = 730
    ARCHIVE_HOT_DAYS: int = 90
    ARCHIVE_COLD_DAYS: int = 730
    ARCHIVE_COMPRESSION: str = "zstd"  # zstd > gzip (faster, better ratio)

    # --- Backup / Restore ---
    BACKUP_RETENTION_DAYS: int = 30
    BACKUP_PATH: str = "/data/backups"
    MINIO_BUCKET_BACKUPS: str = "hotspot-backups"

    # --- Email (SMTP) ---
    EMAIL_DEFAULT_FROM: str = "noreply@hotspot.local"

    # --- White-Label / Branding ---
    WHITELABEL_DEFAULT_PRIMARY: str = "#4F46E5"

    # --- CORS ---
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000,http://localhost:5174,http://localhost:5175"

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    def validate_production(self) -> list[str]:
        """Fail-fast checks for production safety. Returns list of errors."""
        errors: list[str] = []
        if self.ENVIRONMENT != "production":
            return errors
        if self.DEBUG:
            errors.append("DEBUG must be False in production")
        if self.SECRET_KEY == "change-me-in-production-please-use-at-least-32-characters":
            errors.append("SECRET_KEY must be changed from default in production")
        if not self.CRYPTO_KEY:
            errors.append("CRYPTO_KEY must be set in production")
        if self.SMS_PROVIDER in ("console", "log"):
            errors.append("SMS_PROVIDER must be a real gateway in production")
        if self.MINIO_ACCESS_KEY == "minioadmin" and self.MINIO_SECRET_KEY == "minioadmin":
            errors.append("MinIO credentials must be changed from defaults in production")
        if "*" in str(self.CORS_ORIGINS):
            errors.append("CORS wildcard '*' is not allowed in production")
        if not self.ARCHIVE_MINIO_ENDPOINT and self.ARCHIVE_PROVIDER == "minio":
            errors.append("ARCHIVE_MINIO_ENDPOINT must be set when ARCHIVE_PROVIDER=minio")
        if not self.RADIUS_API_KEY:
            errors.append("RADIUS_API_KEY must be set in production")
        if not self.SYSLOG_API_KEY:
            errors.append("SYSLOG_API_KEY must be set in production")
        if not self.MINIO_SECURE and self.ARCHIVE_PROVIDER == "minio":
            errors.append("MINIO_SECURE must be True in production")
        if errors:
            for err in errors:
                log.critical("Production config error: %s", err)
        return errors


settings = Settings()
