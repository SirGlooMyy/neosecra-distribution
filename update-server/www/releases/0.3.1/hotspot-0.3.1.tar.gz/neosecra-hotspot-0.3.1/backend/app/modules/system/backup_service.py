"""Backup & Restore service for PostgreSQL, MinIO archives, and config files.

Backup flows run in Celery tasks (background). pg_dump/pg_restore via
subprocess with lazy imports so the app boots on any platform.
"""
from __future__ import annotations

import logging
import os
import uuid
import io
import json
from datetime import datetime, timezone

from sqlalchemy import String, DateTime, BigInteger, Text, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from app.core.config import settings
from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk

log = logging.getLogger(__name__)

# ---- constants ----------------------------------------------------------------
BT_FULL = "full"
BT_CONFIG = "config"
BT_DB = "db"
BT_ARCHIVES = "archives"
BACKUP_TYPES = (BT_FULL, BT_CONFIG, BT_DB, BT_ARCHIVES)

BS_RUNNING = "running"
BS_COMPLETED = "completed"
BS_FAILED = "failed"
BACKUP_STATUSES = (BS_RUNNING, BS_COMPLETED, BS_FAILED)


class BackupJob(Base, UUIDPK, TimestampMixin):
    __tablename__ = "backup_jobs"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    type: Mapped[str] = mapped_column(String(20), nullable=False, default=BT_FULL)
    status: Mapped[str] = mapped_column(String(20), default=BS_RUNNING, nullable=False)
    file_ref: Mapped[str | None] = mapped_column(String(500), nullable=True)
    file_size: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[uuid.UUID] = fk("users", ondelete="SET NULL")


# ---- helpers ------------------------------------------------------------------
def _pg_env() -> dict[str, str]:
    env = os.environ.copy()
    env["PGHOST"] = settings.DATABASE_URL.split("@")[-1].split(":")[0]
    env["PGUSER"] = settings.DATABASE_URL.split("://")[1].split(":")[0]
    env["PGPASSWORD"] = settings.DATABASE_URL.split(":")[2].split("@")[0]
    env["PGDATABASE"] = settings.DATABASE_URL.split("/")[-1].split("?")[0]
    return env


def _run_pg_dump(output_path: str) -> str:
    import subprocess as sp
    env = _pg_env()
    host = settings.DATABASE_URL.split("@")[-1].split(":")[0]
    user = settings.DATABASE_URL.split("://")[1].split(":")[0]
    dbname = settings.DATABASE_URL.split("/")[-1].split("?")[0]
    cmd = ["pg_dump", "-h", host, "-U", user, "-d", dbname, "-F", "c", "-f", output_path]
    sp.run(cmd, env=env, check=True, capture_output=True, text=True)
    return output_path


def _run_pg_restore(input_path: str) -> str:
    import subprocess as sp
    env = _pg_env()
    host = settings.DATABASE_URL.split("@")[-1].split(":")[0]
    user = settings.DATABASE_URL.split("://")[1].split(":")[0]
    dbname = settings.DATABASE_URL.split("/")[-1].split("?")[0]
    cmd = ["pg_restore", "-h", host, "-U", user, "-d", dbname, "-c", "-F", "c", input_path]
    sp.run(cmd, env=env, check=True, capture_output=True, text=True)
    return input_path


def _minio_client():
    from minio import Minio  # type: ignore[import-not-found]
    return Minio(
        settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE,
    )


def _ensure_backup_bucket():
    client = _minio_client()
    bucket = settings.MINIO_BUCKET_BACKUPS
    if not client.bucket_exists(bucket):
        client.make_bucket(bucket)
    return client, bucket


def _upload_to_minio(local_path: str, key: str) -> str:
    client, bucket = _ensure_backup_bucket()
    import io
    with open(local_path, "rb") as fh:
        data = fh.read()
    client.put_object(bucket, key, io.BytesIO(data), length=len(data))
    return f"minio:{bucket}/{key}"


def _download_from_minio(file_ref: str, local_path: str) -> str:
    client, bucket = _ensure_backup_bucket()
    key = file_ref.split("minio:")[1].split("/", 1)[1]
    client.fget_object(bucket, key, local_path)
    return local_path


# ---- service functions --------------------------------------------------------
async def start_full_backup(db: AsyncSession, user_id: uuid.UUID) -> dict:
    job = BackupJob(
        name=f"full_backup_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}",
        type=BT_FULL,
        status=BS_RUNNING,
        started_at=datetime.now(timezone.utc),
        created_by=user_id,
    )
    db.add(job)
    await db.commit()
    await db.refresh(job)

    from app.modules.workers.tasks import run_full_backup
    run_full_backup.delay(str(job.id))  # type: ignore[attr-defined]

    return {"job_id": str(job.id), "status": BS_RUNNING, "name": job.name}


async def start_db_backup(db: AsyncSession, user_id: uuid.UUID) -> dict:
    job = BackupJob(
        name=f"db_backup_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}",
        type=BT_DB,
        status=BS_RUNNING,
        started_at=datetime.now(timezone.utc),
        created_by=user_id,
    )
    db.add(job)
    await db.commit()
    await db.refresh(job)

    from app.modules.workers.tasks import run_db_backup
    run_db_backup.delay(str(job.id))  # type: ignore[attr-defined]

    return {"job_id": str(job.id), "status": BS_RUNNING, "name": job.name}


async def start_config_backup(db: AsyncSession, user_id: uuid.UUID) -> dict:
    job = BackupJob(
        name=f"config_backup_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}",
        type=BT_CONFIG,
        status=BS_RUNNING,
        started_at=datetime.now(timezone.utc),
        created_by=user_id,
    )
    db.add(job)
    await db.commit()
    await db.refresh(job)

    from app.modules.workers.tasks import run_config_backup
    run_config_backup.delay(str(job.id))  # type: ignore[attr-defined]

    return {"job_id": str(job.id), "status": BS_RUNNING, "name": job.name}


async def list_backups(db: AsyncSession) -> list[BackupJob]:
    res = await db.execute(
        select(BackupJob).order_by(BackupJob.created_at.desc())
    )
    return list(res.scalars().all())


async def get_backup(db: AsyncSession, backup_id: uuid.UUID) -> BackupJob | None:
    return await db.get(BackupJob, backup_id)


async def delete_backup(db: AsyncSession, backup_id: uuid.UUID) -> None:
    job = await db.get(BackupJob, backup_id)
    if job:
        await db.delete(job)
        await db.commit()


async def restore_from_backup(db: AsyncSession, backup_id: uuid.UUID) -> dict:
    job = await db.get(BackupJob, backup_id)
    if not job:
        raise ValueError("Yedek bulunamadi")
    if not job.file_ref:
        raise ValueError("Bu yedegin dosyasi yok")
    if job.type not in {BT_FULL, BT_DB}:
        raise ValueError("Bu yedek tipi geri yukleme desteklemiyor")

    try:
        from app.modules.workers.tasks import run_restore_backup
        run_restore_backup.delay(str(job.id))  # type: ignore[attr-defined]
        return {"job_id": str(job.id), "status": "restoring", "message": "Geri yukleme baslatildi"}
    except Exception as exc:
        job.status = BS_FAILED
        job.error_message = str(exc)
        await db.commit()
        raise


# ---- sync helpers called by Celery tasks --------------------------------------
def execute_db_backup(output_dir: str, job_id: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, f"hotspot_db_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.dump")
    _run_pg_dump(path)
    return path


def execute_config_backup(output_dir: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    import tarfile
    path = os.path.join(output_dir, f"hotspot_config_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.tar.gz")
    # Never archive .env or docker-compose files: they contain database,
    # object-store and JWT secrets. Store only a non-sensitive configuration
    # snapshot; secret material must be provisioned separately via a secret
    # manager during restore.
    snapshot = {
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "archive_provider": settings.ARCHIVE_PROVIDER,
        "archive_retention_days": settings.ARCHIVE_RETENTION_DAYS,
        "archive_compression": settings.ARCHIVE_COMPRESSION,
        "guest_session_default_minutes": settings.GUEST_SESSION_DEFAULT_MINUTES,
    }
    payload = json.dumps(snapshot, ensure_ascii=False, indent=2).encode("utf-8")
    with tarfile.open(path, "w:gz") as tar:
        info = tarfile.TarInfo(name="config.snapshot.json")
        info.size = len(payload)
        info.mtime = int(datetime.now(timezone.utc).timestamp())
        tar.addfile(info, io.BytesIO(payload))
    return path


def execute_archives_backup(output_dir: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    import tarfile
    path = os.path.join(output_dir, f"hotspot_archives_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.tar.gz")
    with tarfile.open(path, "w:gz") as tar:
        archive_dir = settings.ARCHIVE_LOCAL_DIR or "./_archives"
        if os.path.isdir(archive_dir):
            tar.add(archive_dir, arcname="archives")
    return path


def upload_backup_file(local_path: str, job_id: str, backup_type: str) -> str:
    key = f"backups/{backup_type}/{job_id}_{os.path.basename(local_path)}"
    return _upload_to_minio(local_path, key)
