"""Quick Setup & Provisioning Wizard service.

Allows administrators and installers to provision a complete Hotspot location,
network gateway (FortiGate, MikroTik, UniFi), bandwidth QoS user group,
and captive portal theme in a single 3-step atomic workflow.
"""
from __future__ import annotations

import logging
import uuid
from typing import Any
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.crypto import encrypt
from app.core.installation import resolve_installation_customer
from app.modules.auth.models import User
from app.modules.devices.models import Device, DeviceCredential
from app.modules.locations.models import Location
from app.modules.portal.models import PortalTemplate, METHOD_FREE
from app.modules.user_groups.models import UserGroup

log = logging.getLogger(__name__)


class QuickSetupIn(BaseModel):
    location_name: str = Field(..., min_length=2, max_length=255, description="Lokasyon / Şube Adı")
    capacity_profile: str = Field("medium", description="Kapasite Profili (small: 1-50, medium: 50-250, large: 250+)")
    gateway_type: str = Field("fortigate", description="Ağ Ağ Geçidi / Cihaz Tipi (fortigate, mikrotik, unifi, generic_radius)")
    gateway_ip: str = Field("192.168.1.1", description="Cihaz Yönetim / Gateway IP Adresi")
    shared_secret: str = Field("RadiusSecret123!", min_length=6, description="RADIUS Shared Secret")
    auth_methods: list[str] = Field(
        default_factory=lambda: ["tc_sms", "sms", "pms", "voucher", "free"],
        description="Aktif edilecek kimlik doğrulama yöntemleri",
    )
    session_timeout_minutes: int = Field(120, ge=15, le=1440, description="Maksimum Oturum Süresi (Dakika)")
    download_speed_mbps: int = Field(10, ge=1, le=1000, description="Kullanıcı Başına İndirme Hızı (Mbps)")
    upload_speed_mbps: int = Field(2, ge=1, le=500, description="Kullanıcı Başına Yükleme Hızı (Mbps)")
    daily_data_quota_mb: int = Field(2048, ge=100, le=100000, description="Günlük Veri Kotası (MB)")
    portal_title: str = Field("Hoş Geldiniz", max_length=255, description="Portal Karşılama Başlığı")
    portal_welcome_text: str = Field(
        "İnternete bağlanmak için lütfen giriş yapınız.",
        max_length=1000,
        description="Portal Karşılama Alt Metni",
    )
    enable_5651_sealing: bool = Field(True, description="5651 Yasal Günlük Mühürleme Aktif")


class QuickSetupOut(BaseModel):
    success: bool
    message: str
    customer_id: uuid.UUID
    location_id: uuid.UUID
    location_name: str
    device_id: uuid.UUID
    group_id: uuid.UUID
    portal_id: uuid.UUID
    portal_url: str
    radius_server_ip: str
    radius_auth_port: int
    radius_acct_port: int
    radius_shared_secret: str
    cli_snippet: str
    instructions: list[str]


def _build_fortigate_cli(
    server_ip: str,
    secret: str,
    location_id: uuid.UUID,
    auth_port: int = 1812,
    acct_port: int = 1813,
) -> str:
    portal_url = f"http://{server_ip}:58001/portal?location_id={location_id}"
    return f"""# ── FORTIOS (FORTIGATE) HOTSPOT & RADIUS ENTEGRASYONU ──
# 1. RADIUS Sunucu Tanımı
config user radius
    edit "NeoSecra-RADIUS"
        set server "{server_ip}"
        set secret "{secret}"
        set auth-type pap
        set timeout 5
    next
end

# 2. RADIUS Kullanıcı Grubu
config user group
    edit "Hotspot-Misafirler"
        set member "NeoSecra-RADIUS"
    next
end

# 3. Captive Portal Yönlendirmesi
config firewall captive-portal
    set custom-portal "{portal_url}"
end
"""


def _build_mikrotik_cli(
    server_ip: str,
    secret: str,
    location_id: uuid.UUID,
    auth_port: int = 1812,
    acct_port: int = 1813,
) -> str:
    return f"""# ── MIKROTIK ROUTEROS HOTSPOT & RADIUS ENTEGRASYONU ──
# 1. RADIUS Sunucusunu Ekle
/radius add service=hotspot address={server_ip} secret="{secret}" authentication-port={auth_port} accounting-port={acct_port} timeout=3000ms

# 2. Hotspot Profilinde RADIUS'u Aktif Et
/ip hotspot profile set [find default=yes] use-radius=yes radius-accounting=yes login-by=http-chap,http-pap

# 3. RADIUS Giriş Ayarları
/ip hotspot profile set [find default=yes] nas-port-type=wireless-802.11
"""


def _build_unifi_cli(
    server_ip: str,
    secret: str,
    location_id: uuid.UUID,
    auth_port: int = 1812,
    acct_port: int = 1813,
) -> str:
    portal_url = f"http://{server_ip}:58001/portal?location_id={location_id}"
    return f"""# ── UNIFI CONTROLLER HOTSPOT ENTEGRASYONU ──
1. UniFi Network Controller > Settings > Profiles > RADIUS Profiles adimina gidin.
2. Yeni Profil: 'NeoSecra-RADIUS'
   - Authentication Server: {server_ip} (Port: {auth_port})
   - Accounting Server: {server_ip} (Port: {acct_port})
   - Secret Key: {secret}
3. Hotspot Portal > External Portal Server:
   - Custom Portal URL: {portal_url}
"""


async def run_quick_setup(
    db: AsyncSession,
    user: User,
    data: QuickSetupIn,
) -> QuickSetupOut:
    """Atomically provision a full hotspot deployment."""
    customer_id = user.customer_id or await resolve_installation_customer(db)
    loc_id = uuid.uuid4()
    dev_id = uuid.uuid4()
    group_id = uuid.uuid4()
    template_id = uuid.uuid4()

    # 1. Create Location
    loc = Location(
        id=loc_id,
        customer_id=customer_id,
        name=data.location_name.strip(),
        default_ssid=f"{data.location_name.strip()} Wi-Fi",
        timezone="Europe/Istanbul",
    )
    db.add(loc)

    # 2. Create Gateway Device
    dev = Device(
        id=dev_id,
        location_id=loc_id,
        name=f"{data.location_name.strip()} {data.gateway_type.upper()} Gateway",
        vendor=data.gateway_type.lower(),
        mgmt_ip=data.gateway_ip.strip(),
        status="active",
        meta={
            "capacity_profile": data.capacity_profile,
            "quick_setup_provisioned": True,
        },
    )
    db.add(dev)

    # Encrypted Credential
    cred = DeviceCredential(
        id=uuid.uuid4(),
        device_id=dev_id,
        api_username="admin",
        verify_tls=False,
    )
    db.add(cred)

    # 3. Create User Group with QoS Rules
    group = UserGroup(
        id=group_id,
        customer_id=customer_id,
        location_id=loc_id,
        name=f"{data.location_name.strip()} Standart Misafir Grubu",
        description=f"Hızlı Kurulum ile oluşturuldu ({data.download_speed_mbps}M/{data.upload_speed_mbps}M)",
        bandwidth_down=data.download_speed_mbps * 1024,
        bandwidth_up=data.upload_speed_mbps * 1024,
        session_timeout=data.session_timeout_minutes,
        idle_timeout=30,
        daily_quota=data.daily_data_quota_mb,
        is_default=True,
    )
    db.add(group)

    # 4. Create Portal Template
    template = PortalTemplate(
        id=template_id,
        customer_id=customer_id,
        location_id=loc_id,
        name=f"{data.location_name.strip()} Karşılama Portalı",
        method=data.auth_methods[0] if data.auth_methods else METHOD_FREE,
        is_default=True,
        theme={
            "primary_color": "#4f46e5",
            "title": data.portal_title,
            "welcome_text": data.portal_welcome_text,
            "logo_url": None,
        },
        meta={
            "enabled_methods": data.auth_methods,
            "quick_setup": True,
            "capacity_profile": data.capacity_profile,
            "enable_5651": data.enable_5651_sealing,
        },
    )
    db.add(template)

    await db.commit()

    # Resolve server IP
    server_ip = getattr(settings, "SERVER_HOST_IP", "192.168.2.126")
    auth_port = getattr(settings, "RADIUS_AUTH_PORT", 1812)
    acct_port = getattr(settings, "RADIUS_ACCT_PORT", 1813)

    if data.gateway_type.lower() == "fortigate":
        cli_snippet = _build_fortigate_cli(server_ip, data.shared_secret, loc_id, auth_port, acct_port)
    elif data.gateway_type.lower() == "mikrotik":
        cli_snippet = _build_mikrotik_cli(server_ip, data.shared_secret, loc_id, auth_port, acct_port)
    elif data.gateway_type.lower() == "unifi":
        cli_snippet = _build_unifi_cli(server_ip, data.shared_secret, loc_id, auth_port, acct_port)
    else:
        cli_snippet = f"# RADIUS Sunucu IP: {server_ip}\n# Auth Port: {auth_port}\n# Acct Port: {acct_port}\n# Secret: {data.shared_secret}\n"

    portal_url = f"http://{server_ip}:58001/portal?location_id={loc_id}"

    instructions = [
        f"1. Lokasyon '{loc.name}' başarıyla oluşturuldu (ID: {loc_id}).",
        f"2. {data.gateway_type.upper()} gateway cihazı ve {data.download_speed_mbps} Mbps hız limiti tanımlandı.",
        f"3. Seçilen kimlik doğrulama yöntemleri ({', '.join(data.auth_methods)}) aktif edildi.",
        "4. Aşağıdaki CLI komutlarını ağ cihazınıza yapıştırarak yayına alabilirsiniz.",
    ]

    return QuickSetupOut(
        success=True,
        message="Hızlı kurulum başarıyla tamamlandı. Hotspot ağınız yayına hazır.",
        customer_id=customer_id,
        location_id=loc_id,
        location_name=loc.name,
        device_id=dev_id,
        group_id=group_id,
        portal_id=template_id,
        portal_url=portal_url,
        radius_server_ip=server_ip,
        radius_auth_port=auth_port,
        radius_acct_port=acct_port,
        radius_shared_secret=data.shared_secret,
        cli_snippet=cli_snippet,
        instructions=instructions,
    )
