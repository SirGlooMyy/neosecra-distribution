from datetime import datetime, timedelta, timezone

from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext
from app.modules.traffic.models import TrafficHourly, TrafficDaily, TopTalker
from app.modules.sessions.models import GuestSession
from app.modules.locations.models import Location

# Public entry point for the periodic materialization job. Kept here as a
# compatibility import for callers that already use the traffic service.
from app.modules.traffic.aggregation import aggregate_traffic  # noqa: E402,F401


async def get_traffic_trend(
    db: AsyncSession, scope: ScopeContext, days: int = 30
) -> dict:
    cid = scope.customer_id
    now = datetime.now(timezone.utc)
    since = now - timedelta(days=days)

    # Hourly traffic
    q_hourly = select(
        TrafficHourly.hour,
        TrafficHourly.bytes_in,
        TrafficHourly.bytes_out,
        TrafficHourly.session_count,
        TrafficHourly.active_users,
    ).where(
        TrafficHourly.customer_id == cid,
        TrafficHourly.hour >= since,
    )
    if scope.location_id:
        q_hourly = q_hourly.where(TrafficHourly.location_id == scope.location_id)
    q_hourly = q_hourly.order_by(TrafficHourly.hour)
    r = await db.execute(q_hourly)
    hourly = [
        {"hour": h.strftime("%H:00") if hasattr(h, "strftime") else str(h), "bytes_in": int(bi), "bytes_out": int(bo), "sessions": int(sc), "active": int(au)}
        for h, bi, bo, sc, au in r.all()
    ]

    # Daily traffic
    q_daily = select(
        TrafficDaily.date,
        func.sum(TrafficDaily.bytes_in),
        func.sum(TrafficDaily.bytes_out),
        func.sum(TrafficDaily.session_count),
        func.max(TrafficDaily.peak_concurrent),
    ).where(
        TrafficDaily.customer_id == cid,
        TrafficDaily.date >= since,
    )
    if scope.location_id:
        q_daily = q_daily.where(TrafficDaily.location_id == scope.location_id)
    q_daily = q_daily.group_by(TrafficDaily.date).order_by(TrafficDaily.date)
    r = await db.execute(q_daily)
    daily = [
        {"date": d.strftime("%Y-%m-%d") if hasattr(d, "strftime") else str(d), "bytes_in": int(bi), "bytes_out": int(bo), "sessions": int(sc), "peak": int(pk or 1)}
        for d, bi, bo, sc, pk in r.all()
    ]

    # Top talkers
    q_top = select(TopTalker).where(
        TopTalker.customer_id == cid,
        TopTalker.period_start >= since,
    )
    if scope.location_id:
        q_top = q_top.where(TopTalker.location_id == scope.location_id)
    q_top = q_top.order_by(TopTalker.rank).limit(20)
    r = await db.execute(q_top)
    top_talkers = list(r.scalars().all())

    # Fallback to direct aggregation from live GuestSession if materialized tables are empty
    if not daily:
        q_sess = select(
            func.date_trunc("day", GuestSession.started_at).label("day"),
            func.coalesce(func.sum(GuestSession.bytes_in), 0),
            func.coalesce(func.sum(GuestSession.bytes_out), 0),
            func.count(GuestSession.id),
        ).where(
            GuestSession.started_at >= since,
        )
        if cid:
            q_sess = q_sess.where(GuestSession.customer_id == cid)
        if scope.location_id:
            q_sess = q_sess.where(GuestSession.location_id == scope.location_id)
        q_sess = q_sess.group_by(func.date_trunc("day", GuestSession.started_at)).order_by("day")
        r_sess = await db.execute(q_sess)
        daily = [
            {
                "date": d.strftime("%Y-%m-%d") if hasattr(d, "strftime") else str(d)[:10],
                "bytes_in": int(bi or 0),
                "bytes_out": int(bo or 0),
                "sessions": int(sc),
                "peak": 1,
            }
            for d, bi, bo, sc in r_sess.all()
        ]

    if not hourly:
        q_h = select(
            func.date_trunc("hour", GuestSession.started_at).label("hour"),
            func.coalesce(func.sum(GuestSession.bytes_in), 0),
            func.coalesce(func.sum(GuestSession.bytes_out), 0),
            func.count(GuestSession.id),
        ).where(
            GuestSession.started_at >= (now - timedelta(hours=24)),
        )
        if cid:
            q_h = q_h.where(GuestSession.customer_id == cid)
        if scope.location_id:
            q_h = q_h.where(GuestSession.location_id == scope.location_id)
        q_h = q_h.group_by(func.date_trunc("hour", GuestSession.started_at)).order_by("hour")
        r_h = await db.execute(q_h)
        hourly = [
            {
                "hour": h.strftime("%H:00") if hasattr(h, "strftime") else str(h)[11:16],
                "bytes_in": int(bi or 0),
                "bytes_out": int(bo or 0),
                "sessions": int(sc),
                "active": int(sc),
            }
            for h, bi, bo, sc in r_h.all()
        ]

    top_talkers_data = []
    if top_talkers:
        top_talkers_data = [{
            "mac": t.mac,
            "phone": t.phone,
            "bytes_in": t.bytes_in,
            "bytes_out": t.bytes_out,
            "session_count": t.session_count,
            "rank": t.rank,
        } for t in top_talkers]
    else:
        q_top_sess = select(
            GuestSession.mac,
            GuestSession.phone,
            func.coalesce(func.sum(GuestSession.bytes_in), 0).label("bi"),
            func.coalesce(func.sum(GuestSession.bytes_out), 0).label("bo"),
            func.count(GuestSession.id).label("sc"),
        ).where(
            GuestSession.started_at >= since,
        )
        if cid:
            q_top_sess = q_top_sess.where(GuestSession.customer_id == cid)
        if scope.location_id:
            q_top_sess = q_top_sess.where(GuestSession.location_id == scope.location_id)
        q_top_sess = q_top_sess.group_by(GuestSession.mac, GuestSession.phone).order_by(desc("bo + bi")).limit(20)
        r_top = await db.execute(q_top_sess)
        top_talkers_data = [
            {
                "mac": mac,
                "phone": phone or "Misafir Kullanıcı",
                "bytes_in": int(bi or 0),
                "bytes_out": int(bo or 0),
                "session_count": int(sc),
                "rank": idx + 1,
            }
            for idx, (mac, phone, bi, bo, sc) in enumerate(r_top.all())
        ]

    # Live Summary
    tot_in = sum(d["bytes_in"] for d in daily)
    tot_out = sum(d["bytes_out"] for d in daily)
    tot_sess = sum(d["sessions"] for d in daily)
    unique_macs = len(set(t["mac"] for t in top_talkers_data))

    summary = {
        "total_bytes_in": tot_in,
        "total_bytes_out": tot_out,
        "total_sessions": tot_sess,
        "peak_concurrent": max((d.get("peak", 1) for d in daily), default=1),
        "avg_session_duration_min": 24.5,
        "unique_macs": unique_macs or len(top_talkers_data),
    }

    return {
        "daily": daily,
        "hourly": hourly,
        "top_talkers": top_talkers_data,
        "summary": summary,
    }


async def get_traffic_dashboard(db: AsyncSession, scope: ScopeContext) -> dict:
    cid = scope.customer_id
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    # Auth method distribution from live guest sessions
    q_auth = select(
        GuestSession.auth_method,
        func.count(GuestSession.id),
    ).where(
        GuestSession.started_at >= (now - timedelta(days=30)),
    )
    if cid:
        q_auth = q_auth.where(GuestSession.customer_id == cid)
    q_auth = q_auth.group_by(GuestSession.auth_method)
    r_auth = await db.execute(q_auth)
    auth_rows = r_auth.all()
    total_auth_count = sum(c for _, c in auth_rows) or 1
    auth_method_distribution = {
        (method or "SMS OTP").upper(): round((count / total_auth_count) * 100, 1)
        for method, count in auth_rows
    }

    # Top locations by traffic
    q_loc = select(
        Location.name,
        func.count(GuestSession.id),
        func.coalesce(func.sum(GuestSession.bytes_in + GuestSession.bytes_out), 0),
    ).outerjoin(
        Location, GuestSession.location_id == Location.id
    ).where(
        GuestSession.started_at >= (today_start - timedelta(days=30)),
    )
    if cid:
        q_loc = q_loc.where(GuestSession.customer_id == cid)
    q_loc = q_loc.group_by(Location.name).order_by(desc(func.count(GuestSession.id))).limit(10)
    r_loc = await db.execute(q_loc)
    top_locations = [
        {"name": loc_name or "Ana Merkez (Default AP)", "total_bytes": int(b or 0), "sessions": cnt}
        for loc_name, cnt, b in r_loc.all()
    ]

    total_bw = sum(loc["total_bytes"] for loc in top_locations)

    return {
        "total_bandwidth": total_bw,
        "current_throughput": 0,
        "daily_usage": [],
        "top_locations": top_locations,
        "top_talkers": [],
        "auth_method_distribution": auth_method_distribution,
    }

