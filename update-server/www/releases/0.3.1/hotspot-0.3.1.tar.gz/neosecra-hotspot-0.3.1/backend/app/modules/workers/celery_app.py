"""Celery application + beat schedule for the Hotspot platform.

Run:
  celery -A app.modules.workers.celery_app worker -l info
  celery -A app.modules.workers.celery_app beat -l info

Beat schedule (all times UTC):
  * expire_due_sessions  — every 5 min  -> sessions.service.expire_due
    (Mutlak Kural #5: marks overdue active sessions EXPIRED, never deletes)
  * archive_5651_daily   — 02:30 daily  -> builds yesterday's per-customer
    5651 archive record via logs_5651.service.build_session_archive
    (Mutlak Kural #4: append-only; new chain record, never mutates existing)
  * cleanup_expired_trial_sandboxes — 05:00 daily -> decommissions expired
    trial sandbox tenant/customer/location/device/template/license records

Internal worker jobs run with a GLOBAL scope (they are platform jobs, not user
requests) and never bypass tenant isolation on the API surface.
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery("hotspot", broker=settings.REDIS_URL, backend=settings.REDIS_URL)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=100,
    worker_max_memory_per_child=200000,  # 200 MB per child process (recycled on limit)
    beat_schedule={
        # Mark overdue sessions as EXPIRED (soft state change, never delete).
        "expire-due-sessions": {
            "task": "app.modules.workers.tasks.expire_due_sessions",
            "schedule": crontab(minute="*/5"),
        },
        # Recompute recent traffic buckets after RADIUS/session updates.
        "aggregate-traffic": {
            "task": "app.modules.workers.tasks.aggregate_traffic",
            "schedule": crontab(minute="*/5"),
        },
        # Seal yesterday's 5651 session archive per customer (append-only).
        "daily-5651-archive": {
            "task": "app.modules.workers.tasks.archive_5651_daily",
            "schedule": crontab(minute="30", hour="2"),
        },
        # Generate and deliver due scheduled reports.
        "scheduled-reports": {
            "task": "app.modules.workers.tasks.send_scheduled_reports",
            "schedule": crontab(minute="0", hour="*"),
        },
        # Cleanup old backups daily at 03:00 UTC.
        "cleanup-old-backups": {
            "task": "app.modules.workers.tasks.cleanup_old_backups",
            "schedule": crontab(minute="0", hour="3"),
        },
        # Decommission expired trial sandboxes daily at 05:00 UTC.
        "cleanup-expired-trial-sandboxes": {
            "task": "app.modules.workers.tasks.cleanup_expired_trial_sandboxes",
            "schedule": crontab(minute="0", hour="5"),
        },
        # ClickHouse schema ensure + flush (her 60sn).
        "syslog-flush-clickhouse": {
            "task": "app.modules.workers.tasks.syslog_flush_to_clickhouse",
            "schedule": crontab(minute="*/1"),
        },
        # Create daily JSONL.zst archive from ClickHouse (her gün 02:45 UTC).
        "syslog-archive-daily": {
            "task": "app.modules.workers.tasks.syslog_archive_daily",
            "schedule": crontab(minute="45", hour="2"),
        },
        # Enforce 730-day retention (her gün 04:00 UTC).
        "syslog-retention-enforce": {
            "task": "app.modules.workers.tasks.syslog_retention_enforce",
            "schedule": crontab(minute="0", hour="4"),
        },
        # Revoke firewall rules for expired sessions (her 10 dk).
        "revoke-expired-firewall-rules": {
            "task": "app.modules.workers.tasks.revoke_expired_firewall_rules",
            "schedule": crontab(minute="*/10"),
        },
        # Nightly 5651 archive chunk sign for every customer (02:00 Turkey = 23:00 UTC).
        "archive-daily-sign": {
            "task": "app.modules.workers.tasks.archive_daily_sign",
            "schedule": crontab(minute="0", hour="23"),
        },
    },
)

# Import tasks so they register on the app (explicit, no autodiscover needed).
import app.modules.workers.tasks  # noqa: F401,E402
