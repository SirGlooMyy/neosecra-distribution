"""License service — signed Ed25519 envelope install, verify, trial, and read-only.

Ported from neosecra-pish with Hotspot adaptations:
- EXPECTED_PRODUCT = "hotspot"
- Module map uses Hotspot internal module names (portal, sessions, devices, etc.)
- Settings stored via PlatformSetting (key-value table in system module)
- Role mapping: super_admin, partner_admin, customer_admin → grant;
  location_manager, support → viewer-like deny (entitlement resolves False)
"""

import base64
import hashlib
import hmac
import json
import logging
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any
from uuid import uuid4

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.exceptions import InvalidSignature
from app.shared.licensing.contract import license_status, update_entitlement_expired

from app.core.config import settings
from app.modules.auth.models import User
from app.modules.system.models import PlatformSetting

logger = logging.getLogger(__name__)

EXPECTED_PRODUCT = "hotspot"

# Legacy product identifiers accepted as this product. Early envelopes carried
# the display name ("NeoSecra Assessment") or the pre-rename product code
# ("security-health") instead of the canonical code. Keys are normalized:
# lowercase, alphanumeric only.
_LEGACY_PRODUCT_ALIASES: dict[str, frozenset[str]] = {
    "assessment": frozenset({
        "assessment", "neosecraassessment", "securityhealth",
        "neosecrasecurityhealth", "vdatasecurityhealth",
    }),
    "pish": frozenset({
        "pish", "neosecrapish", "awarenessportal", "neosecraawarenessportal",
    }),
    "hotspot": frozenset({
        "hotspot", "hotspotent", "hotspotstandard", "hotspotenterprise", "neosecrahotspot",
    }),
}


def _normalize_product(value: str) -> str:
    return "".join(ch for ch in value.lower() if ch.isalnum())


def _product_matches(product: str) -> bool:
    """True when the envelope's product field identifies this product.

    Accepts the canonical code and legacy aliases (display names, pre-rename
    codes). Denies licenses issued for genuinely different products.
    """
    normalized = _normalize_product(product)
    aliases = _LEGACY_PRODUCT_ALIASES.get(EXPECTED_PRODUCT, frozenset({EXPECTED_PRODUCT}))
    return normalized in aliases

# ── Trusted Keyring (config-driven) ──────────────────────────────────────────


def _build_keyring() -> dict[str, dict[str, Any]]:
    """Build trusted keyring from config/env.

    Priority (first non-empty wins):
    1. LICENSE_PUBLIC_KEY_B64 env var
    2. LICENSE_PUBLIC_KEY_FILE (path to a file containing the base64-encoded key)
    3. Built-in default key for development/testing

    The key is registered as ``vdata-license-prod-2026-01`` so existing
    envelopes signed with that key ID continue to work.
    """
    key_b64 = os.environ.get("LICENSE_PUBLIC_KEY_B64") or ""
    if not key_b64:
        key_file = os.environ.get("LICENSE_PUBLIC_KEY_FILE") or ""
        if key_file and Path(key_file).exists():
            key_b64 = Path(key_file).read_text().strip()

    if not key_b64:
        environment = str(getattr(settings, "ENVIRONMENT", "development") or "development").lower()
        if environment == "production":
            raise RuntimeError("LICENSE_PUBLIC_KEY_B64 or LICENSE_PUBLIC_KEY_FILE is required in production")
        # Built-in dev/test default (same keypair used in neosecra-lisans golden vectors)
        key_b64 = "5K_u8vWPF2cAI0zXq2hGGGt08ag2DL0rek5IMY4OYrM="
        logger.info(
            "LICENSE_PUBLIC_KEY_B64 not set — using built-in dev key. "
            "Set this env var in production."
        )

    return {
        "vdata-license-prod-2026-01": {
            "public_key_b64": key_b64,
            "valid_from": "2026-01-01T00:00:00Z",
            "valid_until": "2036-12-31T23:59:59Z",
            "status": "active",
        },
    }


TRUSTED_KEYRING = _build_keyring()

# ── Module Name Mapping (license platform codes → Hotspot internal names) ────
MODULE_NAME_MAP: dict[str, list[str]] = {
    "hotspot_core": [
        "portal", "sessions", "devices", "locations",
    ],
    "radius": [
        "radius",
    ],
    "vouchers": [
        "vouchers",
    ],
    "sms_ott": [
        "sms", "whatsapp",
    ],
    "logs_5651": [
        "logs_5651", "archive", "syslog",
    ],
    "reporting": [
        "reports",
    ],
}


def expand_licensed_modules(license_modules: list[str]) -> list[str]:
    """Expand platform module codes into internal module names."""
    expanded: set[str] = set()
    for code in license_modules:
        mapped = MODULE_NAME_MAP.get(code)
        if mapped:
            expanded.update(mapped)
        else:
            # Pass through unknown codes verbatim
            expanded.add(code)
    return sorted(expanded)


# ── Trial Mode ──────────────────────────────────────────────────────────────
TRIAL_PERIOD_DAYS = 30
GRACE_PERIOD_DAYS = 14
CRL_STALE_HOURS = 24

# ── CRL Cache (Revocation List) ─────────────────────────────────────────────

CRL_CACHE_PATH = os.environ.get("LICENSE_CRL_CACHE_PATH", "/tmp/license_crl_cache.json")


def _decode_base64url(value: str | bytes) -> bytes:
    """Decode padded or unpadded base64url values from license envelopes."""
    raw = value.encode("ascii") if isinstance(value, str) else value
    return base64.urlsafe_b64decode(raw + b"=" * (-len(raw) % 4))


def crl_cache_path() -> str:
    return os.environ.get("LICENSE_CRL_CACHE_PATH", CRL_CACHE_PATH)


def load_cached_crl() -> dict | None:
    """Load CRL from local cache file."""
    path = Path(crl_cache_path())
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        # Validate structure
        if "revoked_licenses" not in data or "cached_at" not in data:
            return None
        return data
    except Exception:
        return None


def save_crl_cache(crl_data: dict) -> None:
    """Persist CRL to local cache file."""
    try:
        crl_data["cached_at"] = datetime.now(timezone.utc).isoformat()
        Path(crl_cache_path()).write_text(json.dumps(crl_data, indent=2))
    except Exception as e:
        logger.warning("Failed to save CRL cache: %s", e)


def is_crl_stale(crl: dict) -> bool:
    """Check if cached CRL is older than CRL_STALE_HOURS."""
    cached_at = crl.get("cached_at")
    if not cached_at:
        return True
    try:
        age = datetime.now(timezone.utc) - datetime.fromisoformat(cached_at)
        return age > timedelta(hours=CRL_STALE_HOURS)
    except Exception:
        return True


def is_license_revoked(license_id: str, crl: dict | None = None) -> bool:
    """Check if a license ID appears in the revocation list."""
    if crl is None:
        crl = load_cached_crl()
    if crl is None:
        return False  # No CRL available — assume not revoked (air-gap safe)
    revoked = crl.get("revoked_licenses", {})
    return license_id in revoked

# ── Trial Tracking ──────────────────────────────────────────────────────────

async def get_or_create_trial_start(db: AsyncSession) -> datetime:
    """Get trial start timestamp, creating one if not set.

    Trial begins on first call of this function (typically first startup).
    """
    res = await db.execute(
        select(PlatformSetting).where(PlatformSetting.key == "trial_start")
    )
    setting = res.scalar_one_or_none()
    if not setting:
        now = datetime.now(timezone.utc)
        setting = PlatformSetting(
            key="trial_start",
            value=json.dumps({"started_at": now.isoformat(), "trial_count": 1}),
            category="system",
            is_secret=False,
        )
        db.add(setting)
        await db.commit()
        return now
    raw = json.loads(setting.value) if isinstance(setting.value, str) else setting.value
    if isinstance(raw, dict) and "started_at" in raw:
        return datetime.fromisoformat(raw["started_at"])
    return datetime.now(timezone.utc)


async def get_trial_status(db: AsyncSession) -> dict:
    """Return trial mode info: active, days_used, days_remaining."""
    started = await get_or_create_trial_start(db)
    now = datetime.now(timezone.utc)
    elapsed = (now - started).days
    remaining = max(0, TRIAL_PERIOD_DAYS - elapsed)
    return {
        "trial_active": remaining > 0,
        "days_used": elapsed,
        "days_remaining": remaining,
        "total_days": TRIAL_PERIOD_DAYS,
        "started_at": started.isoformat(),
    }


def is_update_entitlement_expired(
    payload: dict, now: datetime | None = None
) -> bool:
    """Return whether the signed license update entitlement has expired.

    Missing values remain permissive for backwards-compatible envelopes.
    Malformed values fail closed so an update cannot start with an
    unverifiable entitlement boundary.
    """
    return update_entitlement_expired(payload, now)

# ── License Status Helpers ───────────────────────────────────────────────────

def _compute_license_status(payload: dict, now: datetime | None = None) -> str:
    """Compute canonical license status from payload fields."""
    normalized = dict(payload)
    normalized.setdefault("grace_period_days", GRACE_PERIOD_DAYS)
    return license_status(normalized, now)


async def get_or_create_installation_id(db: AsyncSession) -> str:
    """Retrieve or dynamically provision a persistent server installation ID."""
    res = await db.execute(
        select(PlatformSetting).where(PlatformSetting.key == "installation_id")
    )
    setting = res.scalar_one_or_none()
    if not setting:
        inst_id = str(uuid4())
        setting = PlatformSetting(
            key="installation_id",
            value=json.dumps({"id": inst_id}),
            category="system",
            is_secret=False,
        )
        db.add(setting)
        await db.commit()
        return inst_id
    raw = json.loads(setting.value) if isinstance(setting.value, str) else setting.value
    return raw.get("id")

def verify_ed25519_envelope(envelope_str: str) -> dict:
    """
    Parse and verify the signed Ed25519 license envelope.
    Returns decoded payload dictionary or raises ValueError with stable error codes.
    """
    try:
        envelope = json.loads(envelope_str)
    except Exception:
        raise ValueError("LICENSE_FORMAT_INVALID")

    # Validate structure
    required_keys = ["schema_version", "key_id", "algorithm", "payload", "signature"]
    if not all(k in envelope for k in required_keys):
        raise ValueError("LICENSE_FORMAT_INVALID")

    if envelope["schema_version"] != 1:
        raise ValueError("LICENSE_SCHEMA_UNSUPPORTED")

    if envelope["algorithm"] != "Ed25519":
        raise ValueError("LICENSE_ALGORITHM_UNSUPPORTED")

    key_id = envelope["key_id"]
    if key_id not in TRUSTED_KEYRING:
        raise ValueError("LICENSE_KEY_ID_UNKNOWN")

    key_meta = TRUSTED_KEYRING[key_id]
    if key_meta["status"] != "active":
        raise ValueError("LICENSE_KEY_ID_UNKNOWN")

    # Decode key and signature
    try:
        pub_bytes = _decode_base64url(key_meta["public_key_b64"])
        public_key = ed25519.Ed25519PublicKey.from_public_bytes(pub_bytes)

        signature_bytes = _decode_base64url(envelope["signature"])
        payload_str = envelope["payload"]
    except Exception:
        raise ValueError("LICENSE_FORMAT_INVALID")

    # Verify signature over the raw base64url payload string
    try:
        public_key.verify(signature_bytes, payload_str.encode("utf-8"))
    except InvalidSignature:
        raise ValueError("LICENSE_SIGNATURE_INVALID")

    # Decode and parse payload
    try:
        payload_bytes = _decode_base64url(payload_str)
        payload = json.loads(payload_bytes.decode("utf-8"))
    except Exception:
        raise ValueError("LICENSE_FORMAT_INVALID")

    # Validate payload critical fields
    payload_required = ["license_id", "issuer", "valid_from", "expires_at", "limits", "modules"]
    if not all(k in payload for k in payload_required):
        raise ValueError("LICENSE_FORMAT_INVALID")

    if payload["issuer"] not in ("VData", "NeoSecra"):
        raise ValueError("LICENSE_FORMAT_INVALID")

    return payload


def license_fingerprints(envelope_str: str) -> tuple[str, str]:
    """Return canonical payload and legacy envelope fingerprints."""
    envelope = json.loads(envelope_str)
    payload_bytes = _decode_base64url(str(envelope["payload"]))
    payload = json.loads(payload_bytes.decode("utf-8"))
    canonical_payload = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str)
    return (
        hashlib.sha256(canonical_payload.encode("utf-8")).hexdigest(),
        hashlib.sha256(envelope_str.encode("utf-8")).hexdigest(),
    )


def fingerprint_matches(envelope_str: str, supplied: str) -> bool:
    if not supplied or len(supplied) != 64:
        return False
    try:
        return any(hmac.compare_digest(supplied, expected) for expected in license_fingerprints(envelope_str))
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        return False

async def get_platform_license(db: AsyncSession) -> dict | None:
    """Retrieve platform license and check validity states.

    Returns a dict with canonical status, expanded modules, usage limits,
    and CRL revocation status. Returns ``None`` when no license exists
    (caller should check trial mode).
    """
    res = await db.execute(
        select(PlatformSetting).where(PlatformSetting.key == "platform_license")
    )
    setting = res.scalar_one_or_none()
    if not setting or not setting.value:
        return None

    raw = json.loads(setting.value) if isinstance(setting.value, str) else setting.value
    envelope_str = raw.get("envelope_string") if isinstance(raw, dict) else raw
    if not envelope_str:
        return None

    # Check for legacy HMAC license
    if envelope_str.startswith("legacy_hmac:"):
        if settings.ENVIRONMENT in ["development", "test"]:
            try:
                raw_payload = envelope_str.replace("legacy_hmac:", "")
                payload = json.loads(raw_payload)
                payload["status"] = "LEGACY_WARNING"
                payload["legacy_warning"] = True
                payload["enabled_modules"] = payload.get("modules", payload.get("enabled_modules", []))
                return payload
            except Exception:
                pass
        return {
            "status": "INVALID_SIGNATURE",
            "edition": "Bilinmiyor",
            "legacy_warning": True,
            "enabled_modules": [],
        }

    # Verify Ed25519 envelope
    try:
        payload = verify_ed25519_envelope(envelope_str)
    except ValueError as e:
        logger.error("Platform license verification failed: %s", e)
        return {
            "status": "INVALID_SIGNATURE",
            "edition": "Bilinmiyor",
            "expires_at": None,
            "max_customers": 0,
            "max_assets": 0,
            "max_users": 0,
            "enabled_modules": [],
        }

    # Product field enforcement
    product = payload.get("product_code", payload.get("product"))
    if product is not None and not _product_matches(product):
        logger.warning(
            "License product mismatch: expected '%s', got '%s'",
            EXPECTED_PRODUCT, product,
        )
        return {
            "status": "INVALID_PRODUCT",
            "edition": payload.get("edition", "unknown"),
            "expires_at": payload.get("expires_at"),
            "max_customers": 0,
            "max_assets": 0,
            "max_users": 0,
            "enabled_modules": [],
            "detail": f"License is for product '{product}', not '{EXPECTED_PRODUCT}'",
        }

    if product is None or _normalize_product(product) != EXPECTED_PRODUCT:
        payload["legacy_warning"] = True

    # CRL revocation check
    crl = load_cached_crl()
    license_id = payload.get("license_id", "")
    if is_license_revoked(license_id, crl):
        logger.warning("License %s is revoked", license_id)
        return {
            "status": "REVOKED",
            "license_id": license_id,
            "edition": payload.get("edition", "unknown"),
            "revoked": True,
            "enabled_modules": [],
            "expires_at": payload.get("expires_at"),
            "max_customers": 0,
            "max_assets": 0,
            "max_users": 0,
        }

    # Verify installation binding
    server_inst_id = await get_or_create_installation_id(db)
    if payload.get("installation_id") not in (None, "", server_inst_id):
        payload["status"] = "INSTALLATION_MISMATCH"
        payload["enabled_modules"] = []
        return payload

    # Compute status from dates
    payload["status"] = _compute_license_status(payload)

    # Check CRL staleness for status info
    crl_stale = is_crl_stale(crl) if crl else True

    # Expand module codes into internal names
    raw_modules = payload.get("modules", payload.get("enabled_modules", []))
    expanded = expand_licensed_modules(raw_modules)

    # Flatten fields for frontend compatibility
    payload["enabled_modules"] = expanded
    limits = payload.get("limits", {})
    payload["max_customers"] = limits.get("max_customers", 0)
    payload["max_assets"] = limits.get("max_assets", 0)
    payload["max_users"] = limits.get("max_users", 0)
    payload["key_id"] = "vdata-license-prod-2026-01"
    payload["product_code"] = EXPECTED_PRODUCT
    payload["crl_stale"] = crl_stale
    payload["revoked"] = False
    # License-server envelopes carry this field for update entitlement. Keep
    # both the raw date and a computed flag available to API/UI consumers.
    payload["update_entitlement_until"] = payload.get("update_entitlement_until")
    payload["update_entitlement_expired"] = is_update_entitlement_expired(payload)
    payload["fingerprint"] = license_fingerprints(envelope_str)[0]

    return payload

async def save_platform_license(db: AsyncSession, envelope_str: str, user_id: str | None = None) -> bool:
    """Validate and persist the signed license envelope."""
    # Check for legacy HMAC license
    if envelope_str.startswith("legacy_hmac:"):
        if settings.ENVIRONMENT not in ["development", "test"]:
            return False  # Reject old format in production

        res = await db.execute(select(PlatformSetting).where(PlatformSetting.key == "platform_license"))
        setting = res.scalar_one_or_none()
        if not setting:
            setting = PlatformSetting(
                key="platform_license",
                value=json.dumps({"envelope_string": envelope_str}),
                category="system",
                is_secret=True,
            )
            db.add(setting)
        else:
            setting.value = json.dumps({"envelope_string": envelope_str})
        await db.commit()
        return True

    try:
        verify_ed25519_envelope(envelope_str)
    except ValueError:
        return False

    res = await db.execute(select(PlatformSetting).where(PlatformSetting.key == "platform_license"))
    setting = res.scalar_one_or_none()
    if not setting:
        setting = PlatformSetting(
            key="platform_license",
            value=json.dumps({"envelope_string": envelope_str}),
            category="system",
            is_secret=True,
            updated_by=user_id,
        )
        db.add(setting)
    else:
        setting.value = json.dumps({"envelope_string": envelope_str})
        if user_id:
            setting.updated_by = user_id
    await db.commit()
    return True


async def delete_platform_license(db: AsyncSession) -> None:
    """Remove platform license key."""
    res = await db.execute(select(PlatformSetting).where(PlatformSetting.key == "platform_license"))
    setting = res.scalar_one_or_none()
    if setting:
        await db.delete(setting)
        await db.commit()


async def get_platform_usage(db: AsyncSession) -> dict:
    """Query counts to evaluate current platform usage against license caps."""
    from app.modules.tenants.models import Tenant
    from app.modules.customers.models import Customer
    from app.modules.devices.models import Device
    from app.modules.sessions.models import GuestSession

    tenant_count = (await db.execute(select(func.count(Tenant.id)))).scalar() or 0
    customer_count = (await db.execute(select(func.count(Customer.id)))).scalar() or 0
    device_count = (await db.execute(select(func.count(Device.id)))).scalar() or 0
    session_count = (await db.execute(select(func.count(GuestSession.id)))).scalar() or 0

    return {
        "tenants": tenant_count,
        "customers": customer_count,
        "devices": device_count,
        "sessions": session_count,
    }

async def resolve_effective_entitlement(
    db: AsyncSession, user: User, module: str,
    organization_id: str | None = None,
) -> bool:
    """
    Authoritative resolution engine: role + license + module check.

    **Fail-closed order:**
    1. User role authorization — reject viewer-only roles (location_manager, support).
    2. Platform license check — if no license installed, fall back to trial
       mode (30-day trial). If trial expired too → deny.
    3. License status check — only ACTIVE, EXPIRING_SOON, GRACE_PERIOD pass.
       GRACE_PERIOD is read-only (mutations blocked).
    4. Module entitlement — the licensed modules must include ``module``.
    """
    # 1. User role authorization check
    #   super_admin, partner_admin, customer_admin → grant
    #   location_manager, support → viewer-like deny
    allowed_roles = {
        "super_admin",
        "partner_admin",
        "customer_admin",
    }
    if user.role not in allowed_roles:
        logger.debug("Role '%s' not allowed for licensed modules", user.role)
        return False

    # 2. Platform level license check
    license_data = await get_platform_license(db)

    if not license_data:
        # No license installed → check trial mode
        trial = await get_trial_status(db)
        if not trial["trial_active"]:
            logger.info(
                "License required for module '%s' — no license and trial expired "
                "(%d/%d days used)",
                module, trial["days_used"], trial["total_days"],
            )
            return False
        # Trial active — all modules open (banner shown in UI)
        logger.debug(
            "Trial mode — granting module '%s' (%d/%d days remaining)",
            module, trial["days_remaining"], trial["total_days"],
        )
        return True

    # 3. License status check
    status = license_data.get("status")
    if status in ("REVOKED", "INVALID", "INVALID_SIGNATURE", "INVALID_PRODUCT", "EXPIRED"):
        logger.warning(
            "License status '%s' — denying module '%s'", status, module
        )
        return False

    if status == "INSTALLATION_MISMATCH":
        return False

    if status == "NOT_YET_VALID":
        return False

    if status == "GRACE_PERIOD":
        logger.info(
            "License in GRACE_PERIOD — module '%s' allowed (read-only mode)", module
        )

    # 4. Module entitlement
    enabled_modules = license_data.get("enabled_modules", [])
    if module not in enabled_modules:
        logger.info(
            "Module '%s' not in enabled modules: %s", module, enabled_modules
        )
        return False

    return True


def is_read_only_session(license_data: dict | None = None) -> bool:
    """Check if the current session should be read-only.

    Returns ``True`` when the license is in grace period or no valid license
    exists. Frontend uses this to disable mutation buttons.
    """
    if license_data is None:
        return False  # Conservative default when no context
    status = license_data.get("status", "")
    return status == "GRACE_PERIOD"


async def require_licensed_module(
    db: AsyncSession, user: User, module: str,
    organization_id: str | None = None,
) -> None:
    """Raise HTTPException 403 if module is not entitled.

    Call this in endpoint handlers that require a specific module license.
    The error detail is always ``LICENSE_REQUIRED`` so the frontend can
    intercept it and redirect to the license install page.
    """
    from fastapi import HTTPException, status

    if not await resolve_effective_entitlement(db, user, module, organization_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="LICENSE_REQUIRED",
        )
