"""Platform upgrade subsystem.

Honest upgrade orchestration with a real state machine. There is no fake
progress and no fabricated update catalog. What the platform actually executes
is gated behind ``EXECUTION_ENABLED``:

* Disabled (default): the subsystem reports capabilities truthfully
  (``can_auto_upgrade``/``can_backup``/``can_rollback`` all ``False``), returns
  ``upgrade_status="IDLE"`` unless a real session completed, and every execution
  endpoint raises ``UPGRADE_EXECUTION_NOT_SUPPORTED``.
* Enabled: the orchestrator runs a real ``pg_dump`` backup, a real ``alembic``
  migration, and a real health probe, persisting every stage transition to the
  DB so the operator sees genuine state + stage log instead of a percentage.

Production safety: backup/restore/migration commands are only constructed when
the flag is on. The DATABASE_URL is forwarded to ``pg_dump``/``psql`` via the
subprocess environment without ever being read, printed, or logged here.
"""
import base64
import copy
import hashlib
import json
import os
import re
import glob
import secrets
import time
import shutil
import logging
import ssl
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import httpx
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import ed25519
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.system.models import PlatformSetting
from app.shared.licensing.license_service import (
    get_platform_license,
    is_update_entitlement_expired,
)

logger = logging.getLogger(__name__)

# --- configuration ---------------------------------------------------------

EXECUTION_PROVIDER = os.getenv("UPGRADE_EXECUTION_PROVIDER", "MANUAL").upper()
EXECUTION_ENABLED = os.getenv("UPGRADE_EXECUTION_ENABLED", "false").lower() in (
    "1", "true", "yes", "on",
)
BACKUP_DIR = os.getenv("UPGRADE_BACKUP_DIR", "") or "/app/backups"
STAGE_TIMEOUT = int(os.getenv("UPGRADE_STAGE_TIMEOUT", "1800"))

# Host-side update-agent bridge. The backend only writes trigger JSON and
# reads journal JSON; the agent performs download, signature verification,
# backup, compose switch and rollback on the installation host.
AGENT_TRIGGER_DIR = os.getenv("UPGRADE_TRIGGER_DIR", "/upgrade-bridge/trigger")
AGENT_JOURNAL_DIR = os.getenv("UPGRADE_JOURNAL_DIR", "/upgrade-bridge/journal")
AGENT_HEARTBEAT_PATH = os.getenv("UPGRADE_AGENT_HEARTBEAT", "/upgrade-bridge/agent-alive")
AGENT_HEARTBEAT_FRESHNESS = int(os.getenv("UPGRADE_HEARTBEAT_FRESHNESS", "300"))
AGENT_UPGRADE_TRIGGER = "upgrade-request.json"
AGENT_ROLLBACK_TRIGGER = "rollback-request.json"
_VERSION_FORMAT_RE = re.compile(r"^\d+\.\d+\.\d+$")

# --- channel configuration -------------------------------------------------

CHANNEL_URL = os.getenv("UPGRADE_CHANNEL_URL", "")
CHANNEL_CA_BUNDLE = os.getenv("UPGRADE_CHANNEL_CA_BUNDLE", "")
CHANNEL_VERIFY_SSL = os.getenv("UPGRADE_CHANNEL_VERIFY_SSL", "true").lower() in ("1", "true", "yes", "on")
CHANNEL_PUBLIC_KEY_PATH = os.getenv("UPGRADE_CHANNEL_PUBLIC_KEY", "")
CHANNEL_TIMEOUT = 10

# --- session states --------------------------------------------------------

STATE_IDLE = "IDLE"
STATE_PREFLIGHT = "PREFLIGHT"
STATE_BACKING_UP = "BACKING_UP"
STATE_MIGRATING = "MIGRATING"
STATE_VERIFYING = "VERIFYING"
STATE_COMPLETED = "COMPLETED"
STATE_FAILED = "FAILED"
STATE_ROLLED_BACK = "ROLLED_BACK"

TERMINAL_STATES = {STATE_COMPLETED, STATE_FAILED, STATE_ROLLED_BACK}
STAGE_ORDER = [
    STATE_PREFLIGHT, STATE_BACKING_UP, STATE_MIGRATING, STATE_VERIFYING,
]

SESSION_KEY = "system.upgrade_session"
HISTORY_KEY = "system.upgrade_history"
RELEASE_CHANNEL_KEY = "system.upgrade_release_channel"
IDEMPOTENCY_KEY = "system.upgrade_idempotency"

_DEFAULT_SCHEMA_REV = "alembic_head_unknown"

# --- version helpers -------------------------------------------------------


def _read_version() -> str:
    """Resolve current version from PRODUCT_VERSION env, then pyproject.toml."""
    try:
        ver = os.getenv("PRODUCT_VERSION", "").strip()
        if ver:
            return ver
    except Exception:
        pass
    try:
        import tomllib
        current_dir = os.path.dirname(os.path.abspath(__file__))
        for _ in range(6):
            candidate = os.path.join(current_dir, "pyproject.toml")
            if os.path.exists(candidate):
                with open(candidate, "rb") as f:
                    data = tomllib.load(f)
                return data.get("project", {}).get("version", "0.0.0")
            parent = os.path.dirname(current_dir)
            if parent == current_dir:
                break
            current_dir = parent
    except Exception:
        pass
    return "0.0.0"


# --- exceptions ------------------------------------------------------------


class UpgradeError(Exception):
    """Base error for the upgrade subsystem (carries a stable detail code)."""


class UpgradeNotEnabled(UpgradeError):
    """Raised when an execution endpoint is hit with the flag off."""


class UpgradeConflict(UpgradeError):
    """Raised when a session is already in-flight."""


def _pg_env_from_database_url() -> dict[str, str]:
    """Build PG* environment variables without logging database credentials."""
    url = os.getenv("DATABASE_URL", "")
    if not url:
        return {}
    url = re.sub(r"^postgres(?:ql)?\+[^:/@]+://", "postgresql://", url, count=1)
    from urllib.parse import unquote, urlparse
    try:
        parsed = urlparse(url)
        port = parsed.port
    except ValueError:
        return {}
    if parsed.scheme not in ("postgres", "postgresql"):
        return {}
    env: dict[str, str] = {}
    if parsed.hostname:
        env["PGHOST"] = parsed.hostname
    if port:
        env["PGPORT"] = str(port)
    if parsed.username:
        env["PGUSER"] = unquote(parsed.username)
    if parsed.password:
        env["PGPASSWORD"] = unquote(parsed.password)
    if parsed.path and parsed.path != "/":
        env["PGDATABASE"] = unquote(parsed.path.lstrip("/"))
    return env


# --- helpers ---------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_session_record(target_version: str, started_by: str, from_version: str | None = None) -> dict:
    return {
        "id": f"upg_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}",
        "state": STATE_IDLE,
        "target_version": target_version,
        "from_version": from_version,
        "started_by": started_by,
        "started_at": _now_iso(),
        "finished_at": None,
        "backup_path": None,
        "error": None,
        "stages": [],
    }


async def _load_setting(db: AsyncSession, key: str, default):
    res = await db.execute(select(PlatformSetting).where(PlatformSetting.key == key))
    s = res.scalar_one_or_none()
    if not s:
        return default, None
    return s.value, s


async def _upsert_setting(db: AsyncSession, key: str, value, *, commit: bool = True):
    _, setting = await _load_setting(db, key, None)
    if setting is None:
        db.add(PlatformSetting(key=key, value=value, category="system"))
    else:
        setting.value = value
    if commit:
        await db.commit()


# --- agent bridge helpers -------------------------------------------------

def _strip_v(version: str) -> str:
    return (version or "").lstrip("vV")


def _current_version_or_none() -> str | None:
    try:
        value = provider.get_current_version().get("current_version")
    except Exception:
        return None
    value = _strip_v(str(value or ""))
    return value if value and value.upper() != "UNKNOWN" else None


def _require_version_format(version: str) -> None:
    if not isinstance(version, str) or not _VERSION_FORMAT_RE.fullmatch(version):
        raise UpgradeError(f"INVALID_VERSION_FORMAT:{version!r}")


_JOURNAL_STATE_MAP = {
    "PREFLIGHT": STATE_PREFLIGHT, "BACKING_UP": STATE_BACKING_UP,
    "BACKUP": STATE_BACKING_UP, "MIGRATING": STATE_MIGRATING,
    "MIGRATION": STATE_MIGRATING, "VERIFYING": STATE_VERIFYING,
    "VERIFY": STATE_VERIFYING, "COMPLETED": STATE_COMPLETED,
    "DONE": STATE_COMPLETED, "SUCCESS": STATE_COMPLETED,
    "OK": STATE_COMPLETED, "FAILED": STATE_FAILED,
    "ERROR": STATE_FAILED, "ROLLED_BACK": STATE_ROLLED_BACK,
    "ROLLBACK": STATE_ROLLED_BACK,
}
_AGENT_STATUS_STATE_MAP = {
    "COMPLETED": STATE_COMPLETED, "FAILED": STATE_FAILED,
    "REJECTED": STATE_FAILED, "CHANNEL_INVALID": STATE_FAILED,
    "LOCK_FAILED": STATE_FAILED, "DOWNLOAD_FAILED": STATE_FAILED,
    "ROLLBACK_COMPLETED": STATE_ROLLED_BACK, "ROLLBACK_FAILED": STATE_FAILED,
}


def _map_journal_state(value: str | None) -> str | None:
    return _JOURNAL_STATE_MAP.get(str(value or "").strip().upper())


def _map_journal_stage_status(value: str | None) -> str:
    return "ok" if str(value or "").strip().upper() in {"COMPLETED", "DONE", "SUCCESS", "OK"} else ("fail" if str(value or "").strip().upper() in {"FAILED", "ERROR"} else "running")


def _parse_iso8601(value) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _agent_status_matches_session(status: dict, session: dict | None) -> bool:
    if session is None:
        return True
    timestamp = _parse_iso8601(status.get("timestamp"))
    started = _parse_iso8601(session.get("started_at"))
    if not timestamp or not started or timestamp.replace(microsecond=0) < started.replace(microsecond=0):
        return False
    target = _strip_v(str(status.get("target_version") or ""))
    candidates = {_strip_v(str(v)) for v in (session.get("target_version"), session.get("rollback_to")) if v}
    return bool(target and target in candidates)


class AgentUpgradeProvider:
    """Bridge provider for the Neosecra distribution host update-agent."""

    def __init__(self, trigger_dir: str | None = None, journal_dir: str | None = None, heartbeat_path: str | None = None, freshness_seconds: int | None = None):
        self.trigger_dir = trigger_dir or AGENT_TRIGGER_DIR
        self.journal_dir = journal_dir or AGENT_JOURNAL_DIR
        self.heartbeat_path = heartbeat_path or AGENT_HEARTBEAT_PATH
        self.freshness_seconds = freshness_seconds if freshness_seconds is not None else AGENT_HEARTBEAT_FRESHNESS
        self.upgrade_trigger_path = os.path.join(self.trigger_dir, AGENT_UPGRADE_TRIGGER)
        self.rollback_trigger_path = os.path.join(self.trigger_dir, AGENT_ROLLBACK_TRIGGER)

    def _heartbeat_status(self) -> tuple[bool, str]:
        if not os.path.exists(self.heartbeat_path):
            return False, f"Heartbeat file missing ({self.heartbeat_path})"
        try:
            age = max(0.0, time.time() - os.path.getmtime(self.heartbeat_path))
        except OSError as exc:
            return False, f"Heartbeat mtime unreadable ({exc})"
        return (True, "") if age <= self.freshness_seconds else (False, f"Heartbeat stale ({age:.0f}s old > {self.freshness_seconds}s)")

    def get_capabilities(self) -> dict:
        fresh, reason = self._heartbeat_status()
        enabled = EXECUTION_ENABLED
        return {
            "execution_provider": "AGENT", "execution_enabled": enabled,
            "can_auto_upgrade": enabled and fresh, "can_backup": enabled,
            "can_migrate": enabled, "can_rollback": enabled,
            "heartbeat_fresh": fresh, "heartbeat_reason": reason,
            "release_channel": os.getenv("UPGRADE_RELEASE_CHANNEL", "hotspot-stable"),
            "instructions": ("Host update-agent aktif; güncelleme tetikleyicisi yazılabilir." if fresh else f"Host update-agent hazır değil: {reason}"),
        }

    def get_current_version(self) -> dict:
        return ManualUpgradeProvider().get_current_version()

    async def check_available_updates(self, db: AsyncSession) -> dict:
        # Catalog and signature validation are identical for both providers.
        return await ManualUpgradeProvider().check_available_updates(db)

    async def run_readiness_checks(self, db: AsyncSession) -> list[dict]:
        checks = await ManualUpgradeProvider().run_readiness_checks(db)
        fresh, reason = self._heartbeat_status()
        checks.append({
            "name": "Host update-agent",
            "status": "PASS" if fresh else "FAIL",
            "message": "Agent heartbeat güncel." if fresh else reason,
        })
        return checks

    def _write_trigger_atomic(self, path: str, payload: dict) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        tmp = f"{path}.tmp.{os.getpid()}.{secrets.token_hex(4)}"
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, sort_keys=True)
                fh.write("\n")
            os.replace(tmp, path)
        finally:
            try:
                if os.path.exists(tmp): os.remove(tmp)
            except OSError:
                pass

    async def _resolve_channel_release(self, target_version: str) -> tuple[dict | None, str]:
        if not CHANNEL_URL:
            return None, "CHANNEL_NOT_CONFIGURED"
        channel, error = await _fetch_channel_json()
        if channel is None:
            return None, f"CHANNEL_UNAVAILABLE:{error}"
        target = _strip_v(target_version)
        for release in channel.get("releases", []):
            if _strip_v(str(release.get("version", ""))) == target:
                return release, ""
        return None, "TARGET_VERSION_NOT_IN_CHANNEL"

    def build_upgrade_trigger(
        self,
        target_version: str,
        bundle_url: str | None,
        requested_by: str = "ui",
        *,
        channel_url: str | None = None,
        archive_url: str | None = None,
    ) -> dict:
        """Build the small, auditable trigger consumed by the host agent.

        Hotspot releases are source/Compose archives rather than Assessment
        Docker image bundles, so the signed archive URL is carried explicitly
        when no separate bundle is published.
        """
        return {
            "target_version": target_version,
            "requested_at": _now_iso(),
            "requested_by": requested_by,
            "bundle_url": bundle_url,
            "channel_url": channel_url or CHANNEL_URL,
            "archive_url": archive_url,
        }

    def build_rollback_trigger(self, job_id: str, rollback_to: str) -> dict:
        return {"job_id": job_id, "target_version": rollback_to, "requested_at": _now_iso(), "requested_by": "ui"}

    def _read_latest_journal(self, target_version: str | None = None, session: dict | None = None) -> dict | None:
        if not os.path.isdir(self.journal_dir):
            return None
        try:
            files = sorted(glob.glob(os.path.join(self.journal_dir, "upgrade-*.json")) + glob.glob(os.path.join(self.journal_dir, "rollback-*.json")), key=os.path.getmtime)
        except OSError:
            return None
        journal = None
        journal_mtime = 0.0
        if files:
            candidates = [f for f in files if target_version and f"-to-{_strip_v(target_version)}-" in os.path.basename(f)] or files
            try:
                latest = candidates[-1]
                with open(latest, encoding="utf-8") as fh: journal = json.load(fh)
                journal_mtime = os.path.getmtime(latest)
            except (OSError, ValueError):
                journal = None
        status_path = os.path.join(self.journal_dir, "agent-status.json")
        try: status_mtime = os.path.getmtime(status_path)
        except OSError: status_mtime = 0.0
        if status_mtime >= journal_mtime and status_mtime:
            try:
                with open(status_path, encoding="utf-8") as fh: status = json.load(fh)
            except (OSError, ValueError): status = None
            if status and _agent_status_matches_session(status, session):
                mapped = _AGENT_STATUS_STATE_MAP.get(str(status.get("state", "")).upper())
                if mapped:
                    journal = journal or {"stages": []}
                    journal["status"] = mapped
                    if mapped == STATE_FAILED: journal.setdefault("error", f"AGENT_STATUS:{status.get('state')}")
                elif str(status.get("state", "")).upper() in {"STARTED", "ROLLBACK_STARTED"}:
                    journal = {"status": None, "stages": []}
        return journal

    def sync_session_from_journal(self, session: dict) -> bool:
        journal = self._read_latest_journal(session.get("target_version"), session)
        if journal is None:
            return False
        state = _map_journal_state(journal.get("status"))
        stages = []
        for item in journal.get("stages") or []:
            name = _map_journal_state(item.get("name"))
            if name:
                stages.append({"stage": name, "status": _map_journal_stage_status(item.get("status")), "started_at": item.get("started_at"), "finished_at": item.get("finished_at"), "detail": item.get("detail")})
        if state is None and stages: state = stages[-1]["stage"]
        if state: session["state"] = state
        if stages: session["stages"] = stages
        if state in TERMINAL_STATES:
            session["finished_at"] = session.get("finished_at") or journal.get("finished_at") or _now_iso()
            if state == STATE_FAILED: session["error"] = journal.get("error") or session.get("error") or "AGENT_UPGRADE_FAILED"
        return True


# --- provider: capabilities + metadata -------------------------------------


class UpgradeProvider:
    """Canonical interface contract for upgrade providers."""

    def get_capabilities(self) -> dict:
        raise NotImplementedError()

    def get_current_version(self) -> dict:
        raise NotImplementedError()

    async def check_available_updates(self, db: AsyncSession) -> dict:
        raise NotImplementedError()

    async def run_readiness_checks(self, db: AsyncSession) -> list[dict]:
        raise NotImplementedError()


class ManualUpgradeProvider(UpgradeProvider):
    """Controlled manual upgrade provider.

    Capabilities reflect the orchestrator's real execution ability (flag +
    tool presence), never a hardcoded ``True``. Version metadata is resolved
    from pyproject.toml / env / git, in that order.
    """

    def get_capabilities(self) -> dict:
        can_backup = EXECUTION_ENABLED and shutil.which("pg_dump") is not None
        can_migrate = EXECUTION_ENABLED and shutil.which("alembic") is not None
        can_rollback = EXECUTION_ENABLED and shutil.which("psql") is not None
        can_auto_upgrade = can_backup and can_migrate and can_rollback
        return {
            "execution_provider": EXECUTION_PROVIDER,
            "execution_enabled": EXECUTION_ENABLED,
            "can_auto_upgrade": can_auto_upgrade,
            "can_backup": can_backup,
            "can_migrate": can_migrate,
            "can_rollback": can_rollback,
            "release_channel": os.getenv("UPGRADE_RELEASE_CHANNEL", "hotspot-stable"),
            "instructions": (
                "Otomatik yükseltme kapalidir. Bu ekran mevcut sürüm, lisans "
                "uygunlugu ve ön kosullari dogrular. Gerçek yükseltme; yetkili "
                "operatör tarafindan onayli bakim prosedürüyle "
                "(UPGRADE_EXECUTION_ENABLED) yürütülür."
            ),
        }

    def get_current_version(self) -> dict:
        version = os.getenv("PRODUCT_VERSION")
        build_number = os.getenv("PRODUCT_BUILD_NUMBER")
        commit_hash = os.getenv("PRODUCT_COMMIT_SHA")
        build_date = os.getenv("PRODUCT_BUILD_DATE")

        if not version:
            version = _read_version()

        if not version:
            try:
                current_dir = os.path.dirname(os.path.abspath(__file__))
                repo_dir = None
                for _ in range(10):
                    if os.path.exists(os.path.join(current_dir, ".git")):
                        repo_dir = current_dir
                        break
                    parent = os.path.dirname(current_dir)
                    if parent == current_dir:
                        break
                    current_dir = parent
                if repo_dir:
                    git_hash = subprocess.check_output(
                        ["git", "rev-parse", "--short", "HEAD"],
                        cwd=repo_dir, stderr=subprocess.DEVNULL,
                    ).decode().strip()
                    try:
                        version = subprocess.check_output(
                            ["git", "describe", "--tags", "--always"],
                            cwd=repo_dir, stderr=subprocess.DEVNULL,
                        ).decode().strip()
                    except Exception:
                        version = f"dev-{git_hash}"
                    commit_hash = git_hash
                    build_number = f"dev-{git_hash}"
                    try:
                        build_date = subprocess.check_output(
                            ["git", "show", "-s", "--format=%cI", "HEAD"],
                            cwd=repo_dir, stderr=subprocess.DEVNULL,
                        ).decode().strip()
                    except Exception:
                        pass
            except Exception:
                pass

        version = version or "0.0.0"
        build_number = build_number or "0"
        commit_hash = commit_hash or "unknown"
        release_channel = os.getenv("UPGRADE_RELEASE_CHANNEL", "hotspot-stable")

        return {
            "product_name": "Hotspot Platform",
            "current_version": version,
            "build_number": build_number,
            "commit_hash": commit_hash,
            "release_channel": release_channel,
            "installation_type": "Docker Compose",
            "database_schema_revision": _DEFAULT_SCHEMA_REV,
            "frontend_version": version,
            "backend_version": version,
            "worker_version": version,
            "last_upgrade_date": build_date,
            "upgrade_status": STATE_IDLE,
        }

    async def check_available_updates(self, db: AsyncSession) -> dict:
        info = self.get_current_version()
        current = info["current_version"]

        if CHANNEL_URL:
            channel, error = await _fetch_channel_json()
            if channel is not None:
                return _format_channel_updates(current, channel)
            logger.warning(
                "Channel update unavailable (%s) — fail-closed, no update advertised",
                error,
            )
            return {"updates": [], "has_update": False}

        manifest_path = os.getenv("UPGRADE_UPDATE_MANIFEST_PATH", "")
        available = None
        if manifest_path and os.path.exists(manifest_path):
            try:
                with open(manifest_path, "r") as f:
                    manifest = json.load(f)
                target = manifest.get("target_version")
                minimum = manifest.get("minimum_current_version")
                if target and (not minimum or _semver_gte(current, minimum)):
                    available = manifest
            except Exception:
                logger.warning("Upgrade manifest at %s could not be read", manifest_path)

        return {
            "updates": [available] if available else [],
            "has_update": bool(available),
        }

    async def run_readiness_checks(self, db: AsyncSession) -> list[dict]:
        checks = []

        lic = await get_platform_license(db)
        if lic and lic.get("status") in ("ACTIVE", "EXPIRING_SOON", "GRACE_PERIOD"):
            checks.append({
                "name": "Lisans Güncelleme Yetkisi", "status": "PASS",
                "message": f"Aktif lisans yetkisi dogrulandi ({lic.get('edition')}).",
            })
        elif lic and lic.get("legacy_warning"):
            checks.append({
                "name": "Lisans Güncelleme Yetkisi", "status": "WARNING",
                "message": "Bu lisans eski dogrulama biçimi kullaniyor; Ed25519 lisans yüklenmeli.",
            })
        else:
            checks.append({
                "name": "Lisans Güncelleme Yetkisi", "status": "FAIL",
                "message": "Platform güncellemesi için geçerli ve aktif lisans gereklidir.",
            })

        if lic and lic.get("update_entitlement_until"):
            expired = is_update_entitlement_expired(lic)
            checks.append({
                "name": "Güncelleme Yetki Süresi",
                "status": "FAIL" if expired else "PASS",
                "message": (
                    "Güncelleme yetki süresi dolmuş; lisansı yenileyin."
                    if expired else
                    f"Güncelleme yetkisi {lic.get('update_entitlement_until')} tarihine kadar geçerli."
                ),
            })

        try:
            await db.execute(text("SELECT 1"))
            checks.append({"name": "Veritabani Baglantisi", "status": "PASS",
                           "message": "Ana veritabani aktif ve erisilebilir."})
        except Exception:
            checks.append({"name": "Veritabani Baglantisi", "status": "FAIL",
                           "message": "Veritabanina baglanilamadi."})

        try:
            _, used, free = shutil.disk_usage("/")
            free_gb = free / (1024 ** 3)
            if free_gb > 5.0:
                checks.append({"name": "Disk Alani Kontrolü", "status": "PASS",
                               "message": f"Yeterli disk alani ({free_gb:.1f} GB bos)."})
            else:
                checks.append({"name": "Disk Alani Kontrolü", "status": "WARNING",
                               "message": f"Disk alani sinirli ({free_gb:.1f} GB bos, en az 5 GB önerilir)."})
        except Exception:
            checks.append({"name": "Disk Alani Kontrolü", "status": "UNKNOWN",
                           "message": "Disk alani okunamadi."})

        caps = self.get_capabilities()
        checks.append({
            "name": "Yürütme Saglayicisi",
            "status": "PASS" if caps["execution_enabled"] else "WARNING",
            "message": (
                f"Execution {'açik' if caps['execution_enabled'] else 'kapali'} "
                f"(UPGRADE_EXECUTION_ENABLED). Backup/Migration/Rollback "
                f"{'hazir' if caps['can_auto_upgrade'] else 'devre disi'}."
            ),
        })

        return checks

    async def create_backup(self) -> str:
        raise NotImplementedError("BACKUP_NOT_SUPPORTED")

    async def verify_backup(self, backup_id: str) -> bool:
        raise NotImplementedError("BACKUP_NOT_SUPPORTED")

    async def apply_update(self, target_version: str) -> None:
        raise NotImplementedError("UPDATE_NOT_SUPPORTED")

    async def run_health_checks(self) -> list[dict]:
        raise NotImplementedError("HEALTH_CHECK_NOT_SUPPORTED")

    async def rollback(self) -> None:
        raise NotImplementedError("ROLLBACK_NOT_SUPPORTED")


# --- semver helpers --------------------------------------------------------


def _semver_gte(current: str, minimum: str) -> bool:
    def parts(v: str):
        out = []
        for token in (v or "").lstrip("vV").split("."):
            num = ""
            for ch in token:
                if ch.isdigit():
                    num += ch
                else:
                    break
            out.append(int(num) if num else 0)
        return out or [0]
    try:
        c, m = parts(current), parts(minimum)
        n = max(len(c), len(m))
        c += [0] * (n - len(c))
        m += [0] * (n - len(m))
        return c >= m
    except Exception:
        return True


def _parse_version_tuple(v: str) -> tuple[int, ...]:
    parts = []
    for token in (v or "0.0.0").lstrip("vV").split("."):
        num = ""
        for ch in token:
            if ch.isdigit():
                num += ch
            else:
                break
        parts.append(int(num) if num else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


# --- channel helpers -------------------------------------------------------


def _verify_minisig(data: bytes, sig_content: str) -> bool:
    try:
        lines = [ln for ln in sig_content.strip().splitlines() if ln.strip()]
        if len(lines) < 2:
            return False
        # Minisig format: line 0 = untrusted comment, line 1 = base64 blob
        # (2-byte alg + 8-byte key id + 64-byte Ed25519 signature over data).
        # With trusted comments the file has 4 lines and line 3 is the
        # TRUSTED COMMENT signature — NOT the data signature. lines[1] is
        # correct for both 2-line and 4-line files.
        b64_sig = lines[1].strip()
        sig_bytes = base64.b64decode(b64_sig)
        if len(sig_bytes) < 64:
            return False
        signature = sig_bytes[-64:]

        key_path = Path(CHANNEL_PUBLIC_KEY_PATH)
        if not key_path.is_file():
            logger.warning("Channel public key not found at %s", CHANNEL_PUBLIC_KEY_PATH)
            return False
        # Minisign .pub files are 2 lines: comment + base64 key — take the
        # last non-empty line, not the whole file (comment breaks b64decode).
        pub_lines = [ln for ln in key_path.read_text().strip().splitlines() if ln.strip()]
        key_b64 = pub_lines[-1].strip()
        pub_bytes = base64.b64decode(key_b64)
        # Minisign pubkey blob: 2-byte alg + 8-byte keynum + 32-byte key.
        if len(pub_bytes) > 32:
            pub_bytes = pub_bytes[-32:]

        public_key = ed25519.Ed25519PublicKey.from_public_bytes(pub_bytes)
        # minisign signs the BLAKE2b-512 digest of the file (prehashed mode),
        # not the raw bytes.
        digest = hashlib.blake2b(data, digest_size=64).digest()
        public_key.verify(signature, digest)
        return True
    except InvalidSignature:
        logger.warning("Channel signature INVALID")
        return False
    except Exception as exc:
        logger.warning("Minisig verification error: %s", exc)
        return False


async def _fetch_channel_json() -> tuple[dict | None, str | None]:
    if not CHANNEL_URL:
        return None, "UPGRADE_CHANNEL_URL not set"

    verify = False if not CHANNEL_VERIFY_SSL else (CHANNEL_CA_BUNDLE if CHANNEL_CA_BUNDLE and os.path.exists(CHANNEL_CA_BUNDLE) else True)

    try:
        async with httpx.AsyncClient(verify=verify, timeout=CHANNEL_TIMEOUT) as client:
            resp = await client.get(CHANNEL_URL)
            resp.raise_for_status()
            body = resp.content

            sig_resp = await client.get(CHANNEL_URL + ".minisig")
            sig_resp.raise_for_status()
            sig_content = sig_resp.text
    except Exception as exc:
        logger.warning("Channel fetch failed: %s", exc)
        return None, str(exc)

    if not CHANNEL_PUBLIC_KEY_PATH:
        logger.warning("UPGRADE_CHANNEL_PUBLIC_KEY not set — cannot verify channel")
        return None, "UPGRADE_CHANNEL_PUBLIC_KEY not set"

    if not _verify_minisig(body, sig_content):
        logger.warning("Channel signature verification failed — discarding channel data")
        return None, "CHANNEL_SIGNATURE_INVALID"

    try:
        channel = json.loads(body)
        # Never advertise a release from another NeoSecra product when a
        # reverse proxy or environment variable is misconfigured. Older test
        # manifests may omit identity fields, so omission remains compatible;
        # an explicit mismatch is always rejected.
        expected_product = os.getenv("UPGRADE_PRODUCT", "hotspot").strip().lower()
        expected_edition = os.getenv("UPGRADE_EDITION", "").strip().lower()
        channel_product = str(channel.get("product_code") or channel.get("product") or "").strip().lower()
        channel_edition = str(channel.get("edition") or "").strip().lower()
        channel_status = str(channel.get("status") or "").strip().lower()
        if channel_status not in {"available", "ready", "unavailable"}:
            logger.warning("Channel status invalid: %s", channel_status)
            return None, "CHANNEL_STATUS_INVALID"
        # An unavailable channel is valid metadata but must never advertise a
        # release to the update UI.  Keep the signed document available for
        # diagnostics while returning an empty catalogue below.
        product_aliases = {"hotspot", "neosecra-hotspot"}
        product_ok = bool(channel_product) and (channel_product in product_aliases or channel_product == expected_product)
        edition_ok = not channel_edition or not expected_edition or channel_edition == expected_edition
        if not product_ok or not edition_ok:
            logger.warning("Channel product identity mismatch: %s/%s", channel_product, channel_edition)
            return None, "CHANNEL_PRODUCT_MISMATCH"
        if channel_status == "unavailable":
            channel = {**channel, "releases": [], "current_version": None}
        return channel, None
    except Exception as exc:
        logger.warning("Channel JSON parse failed: %s", exc)
        return None, str(exc)


def _compute_reachable_updates(current: str, releases: list[dict]) -> list[dict]:
    if not releases:
        return []

    sorted_rel = sorted(releases, key=lambda r: _parse_version_tuple(r.get("version", "0.0.0")))
    available: set[str] = {current}
    reachable: list[dict] = []

    for rel in sorted_rel:
        min_v = rel.get("minimum_current_version", "0.0.0")
        if any(_semver_gte(av, min_v) for av in available):
            reachable.append(rel)
            available.add(rel["version"])
    return reachable


def _format_channel_updates(current: str, channel: dict) -> dict:
    releases = channel.get("releases", [])
    current_tuple = _parse_version_tuple(current)
    reachable = [
        rel for rel in _compute_reachable_updates(current, releases)
        if _parse_version_tuple(rel.get("version", "0.0.0")) > current_tuple
    ]
    reachable.sort(key=lambda rel: _parse_version_tuple(rel.get("version", "0.0.0")), reverse=True)

    updates = []
    for rel in reachable:
        updates.append({
            "target_version": rel["version"],
            "minimum_current_version": rel.get("minimum_current_version", "0.0.0"),
            "released_at": rel.get("released_at", ""),
            "package_size": (rel.get("archive") or {}).get("size_bytes", 0),
            "release_notes": rel.get("release_notes", ""),
            "images": rel.get("images", {}) or {
                "backend": rel.get("backend_image"),
                "worker": rel.get("worker_image"),
                "frontend": rel.get("frontend_image"),
                "bundle": (rel.get("docker_bundle") or {}).get("url"),
            },
        })

    return {"updates": updates, "has_update": bool(updates)}


provider = AgentUpgradeProvider() if EXECUTION_PROVIDER == "AGENT" else ManualUpgradeProvider()


# --- orchestrator: real state machine -------------------------------------


class UpgradeOrchestrator:
    """Drives a single upgrade session through real stages.

    All side-effecting stages call subprocesses (``pg_dump``/``alembic``/``psql``)
    and are only reachable when ``EXECUTION_ENABLED`` is on. Stage commands are
    built by small overridable factories so tests can monkeypatch them without
    touching the real tools.
    """

    def __init__(self):
        self._exec_timeout = STAGE_TIMEOUT

    # -- command factories (overridable in tests) ---------------------------

    def _backup_command(self, dest_path: str) -> list[str]:
        return ["pg_dump", "--no-owner", "--clean", "--if-exists", "-f", dest_path]

    def _migration_command(self) -> list[str]:
        return ["alembic", "upgrade", "head"]

    def _restore_command(self, backup_path: str) -> list[str]:
        return ["psql", "-v", "ON_ERROR_STOP=1", "-f", backup_path]

    def _exec(self, cmd: list[str], cwd: str | None = None) -> tuple[int, str, str]:
        env = dict(os.environ)
        if cmd and cmd[0] in ("pg_dump", "psql"):
            env.update(_pg_env_from_database_url())
        proc = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=self._exec_timeout,
            env=env,
        )
        return proc.returncode, proc.stdout, proc.stderr

    # -- session storage ----------------------------------------------------

    async def get_session(self, db: AsyncSession) -> dict | None:
        value, _ = await _load_setting(db, SESSION_KEY, None)
        if EXECUTION_PROVIDER == "AGENT" and value and isinstance(provider, AgentUpgradeProvider):
            provider.sync_session_from_journal(value)
            if value.get("state") in TERMINAL_STATES:
                await self._archive_session(db, value)
                return None
            await self._save_session(db, value)
        return value

    async def get_history(self, db: AsyncSession) -> list[dict]:
        value, _ = await _load_setting(db, HISTORY_KEY, {"history": []})
        return (value or {}).get("history", [])

    async def get_idempotent_result(self, db: AsyncSession, key: str | None) -> dict | None:
        if not key:
            return None
        value, _ = await _load_setting(db, IDEMPOTENCY_KEY, {})
        return (value or {}).get(key[:128])

    async def record_idempotent_result(self, db: AsyncSession, key: str | None, session: dict) -> None:
        if not key:
            return
        value, _ = await _load_setting(db, IDEMPOTENCY_KEY, {})
        records = dict(value or {})
        records[key[:128]] = copy.deepcopy(session)
        if len(records) > 100:
            records.pop(next(iter(records)), None)
        await _upsert_setting(db, IDEMPOTENCY_KEY, records)

    async def _save_session(self, db: AsyncSession, session: dict):
        await _upsert_setting(db, SESSION_KEY, session)

    async def _archive_session(self, db: AsyncSession, session: dict):
        history_value, _ = await _load_setting(db, HISTORY_KEY, {"history": []})
        history = (history_value or {}).get("history", [])
        session = {**session, "finished_at": session.get("finished_at") or _now_iso()}
        history = [session] + copy.deepcopy(history)
        history = history[:50]
        await _upsert_setting(db, HISTORY_KEY, {"history": history}, commit=False)
        await _upsert_setting(db, SESSION_KEY, None, commit=False)
        await db.commit()

    # -- stage bookkeeping --------------------------------------------------

    def _begin_stage(self, session: dict, stage: str):
        session["stages"].append({
            "stage": stage, "status": "running",
            "started_at": _now_iso(), "finished_at": None, "detail": None,
        })

    def _finish_stage(self, session: dict, status: str, detail: str | None):
        if session["stages"]:
            last = session["stages"][-1]
            last["status"] = status
            last["finished_at"] = _now_iso()
            last["detail"] = detail

    async def _transition(self, db: AsyncSession, session: dict, state: str):
        session["state"] = state
        await self._save_session(db, session)

    # -- public API ---------------------------------------------------------

    async def start_upgrade(
        self, db: AsyncSession, target_version: str, started_by: str
    ) -> dict:
        if not EXECUTION_ENABLED:
            raise UpgradeNotEnabled("UPGRADE_EXECUTION_NOT_SUPPORTED")

        lic = await get_platform_license(db)
        if lic and is_update_entitlement_expired(lic):
            raise UpgradeError("UPDATE_ENTITLEMENT_EXPIRED")

        existing = await self.get_session(db)
        if existing and existing.get("state") not in TERMINAL_STATES:
            raise UpgradeConflict(
                f"UPGRADE_IN_PROGRESS:{existing.get('state')}"
            )

        if EXECUTION_PROVIDER == "AGENT" and isinstance(provider, AgentUpgradeProvider):
            return await self._start_agent_upgrade(db, target_version, started_by)

        session = _new_session_record(target_version, started_by, _current_version_or_none())
        await self._save_session(db, session)
        try:
            await self._run_pipeline(db, session)
        except UpgradeError:
            raise
        except Exception as exc:
            await self._fail(db, session, detail=str(exc))
            raise
        return session

    async def _start_agent_upgrade(self, db: AsyncSession, target_version: str, started_by: str) -> dict:
        agent = provider
        _require_version_format(target_version)
        fresh, reason = agent._heartbeat_status()
        if not fresh:
            raise UpgradeError(f"AGENT_NOT_AVAILABLE:{reason}")
        if os.path.exists(agent.upgrade_trigger_path):
            raise UpgradeConflict("TRIGGER_ALREADY_PENDING")
        release, release_error = await agent._resolve_channel_release(target_version)
        if release is None:
            raise UpgradeError(f"TARGET_VERSION_REJECTED:{release_error}")
        session = _new_session_record(target_version, started_by, _current_version_or_none())
        session.update({"state": STATE_PREFLIGHT, "provider": "AGENT"})
        await self._save_session(db, session)
        bundle_url = release.get("bundle_url") or (release.get("images") or {}).get("bundle") or (release.get("docker_bundle") or {}).get("url")
        archive = release.get("archive") or {}
        archive_url = archive.get("url") if isinstance(archive, dict) else (archive or None)
        # Hotspot's host updater consumes the signed source archive directly;
        # do not silently enqueue an image-less `none` docker bundle.
        if not bundle_url or str(bundle_url).lower().endswith("/none"):
            bundle_url = archive_url
        agent._write_trigger_atomic(
            agent.upgrade_trigger_path,
            agent.build_upgrade_trigger(
                target_version,
                bundle_url,
                started_by,
                channel_url=CHANNEL_URL,
                archive_url=archive_url,
            ),
        )
        return session

    async def _run_pipeline(self, db: AsyncSession, session: dict):
        await self._transition(db, session, STATE_PREFLIGHT)
        self._begin_stage(session, STATE_PREFLIGHT)
        checks = await provider.run_readiness_checks(db)
        failed = [c for c in checks if c.get("status") == "FAIL"]
        self._finish_stage(
            session,
            "ok" if not failed else "fail",
            f"{len(checks)} kontrol, {len(failed)} basarisiz",
        )
        await self._save_session(db, session)
        if failed:
            return await self._fail(db, session, detail="PREFLIGHT_FAILED")

        await self._transition(db, session, STATE_BACKING_UP)
        self._begin_stage(session, STATE_BACKING_UP)
        try:
            backup_path = await self._do_backup()
            session["backup_path"] = backup_path
            self._finish_stage(session, "ok", backup_path)
            await self._save_session(db, session)
        except Exception as exc:
            self._finish_stage(session, "fail", str(exc))
            await self._save_session(db, session)
            return await self._fail(db, session, detail=f"BACKUP_FAILED:{exc}")

        await self._transition(db, session, STATE_MIGRATING)
        self._begin_stage(session, STATE_MIGRATING)
        try:
            code, out, err = self._exec(self._migration_command())
            self._finish_stage(
                session, "ok" if code == 0 else "fail",
                (out[-400:] if code == 0 else (err or out)[-400:]) or None,
            )
            await self._save_session(db, session)
            if code != 0:
                return await self._fail(db, session, detail="MIGRATION_FAILED")
        except Exception as exc:
            self._finish_stage(session, "fail", str(exc))
            await self._save_session(db, session)
            return await self._fail(db, session, detail=f"MIGRATION_FAILED:{exc}")

        await self._transition(db, session, STATE_VERIFYING)
        self._begin_stage(session, STATE_VERIFYING)
        healthy = await self._verify_health(db)
        self._finish_stage(session, "ok" if healthy else "fail", None)
        await self._save_session(db, session)
        if not healthy:
            return await self._fail(db, session, detail="HEALTH_CHECK_FAILED")

        session["state"] = STATE_COMPLETED
        session["finished_at"] = _now_iso()
        await self._archive_session(db, session)

    async def _do_backup(self) -> str:
        if not EXECUTION_ENABLED:
            raise UpgradeNotEnabled("UPGRADE_EXECUTION_NOT_SUPPORTED")
        backup_dir = BACKUP_DIR or os.path.join(
            _tempfile_getdefault(), "platform_upgrades"
        )
        os.makedirs(backup_dir, exist_ok=True)
        dest = os.path.join(
            backup_dir,
            f"upgrade_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.sql",
        )
        code, out, err = self._exec(self._backup_command(dest))
        if code != 0 or not os.path.exists(dest) or os.path.getsize(dest) == 0:
            raise UpgradeError(f"BACKUP_FAILED:{(err or out).strip()[:300]}")
        return dest

    async def _verify_health(self, db: AsyncSession) -> bool:
        try:
            await db.execute(text("SELECT 1"))
            return True
        except Exception:
            return False

    async def _fail(self, db: AsyncSession, session: dict, detail: str):
        session["state"] = STATE_FAILED
        session["error"] = detail
        session["finished_at"] = _now_iso()
        await self._archive_session(db, session)

    async def rollback(self, db: AsyncSession, job_id: str, started_by: str) -> dict:
        if not EXECUTION_ENABLED:
            raise UpgradeNotEnabled("ROLLBACK_NOT_SUPPORTED")

        if EXECUTION_PROVIDER == "AGENT" and isinstance(provider, AgentUpgradeProvider):
            return await self._agent_rollback(db, job_id, started_by)

        session = await self.get_session(db)
        if not session or session.get("id") != job_id:
            for h in await self.get_history(db):
                if h.get("id") == job_id:
                    session = h
                    break
        if not session:
            raise UpgradeError("ROLLBACK_SESSION_NOT_FOUND")

        backup_path = session.get("backup_path")
        if not backup_path or not os.path.exists(backup_path):
            raise UpgradeError("ROLLBACK_NO_BACKUP")

        self._begin_stage(session, "ROLLBACK")
        code, out, err = self._exec(self._restore_command(backup_path))
        self._finish_stage(
            session, "ok" if code == 0 else "fail",
            (err or out).strip()[:300] or None,
        )
        if code != 0:
            session["state"] = STATE_FAILED
            session["error"] = "ROLLBACK_FAILED"
        else:
            session["state"] = STATE_ROLLED_BACK
        session["rolled_back_by"] = started_by
        session["finished_at"] = _now_iso()
        await self._archive_session(db, session)
        return session

    async def _agent_rollback(self, db: AsyncSession, job_id: str, started_by: str) -> dict:
        agent = provider
        fresh, reason = agent._heartbeat_status()
        if not fresh:
            raise UpgradeError(f"AGENT_NOT_AVAILABLE:{reason}")
        if os.path.exists(agent.rollback_trigger_path):
            raise UpgradeConflict("ROLLBACK_TRIGGER_ALREADY_PENDING")
        session = await self.get_session(db)
        if not session or session.get("id") != job_id:
            for item in await self.get_history(db):
                if item.get("id") == job_id:
                    session = item
                    break
        if not session:
            raise UpgradeError("ROLLBACK_SESSION_NOT_FOUND")
        rollback_to = session.get("from_version")
        if not rollback_to:
            raise UpgradeError("ROLLBACK_TARGET_UNKNOWN")
        agent._write_trigger_atomic(agent.rollback_trigger_path, agent.build_rollback_trigger(job_id, rollback_to))
        session["rollback_to"] = rollback_to
        session["rollback_requested_at"] = _now_iso()
        session["rolled_back_by"] = started_by
        await self._save_session(db, session)
        return session


def _tempfile_getdefault() -> str:
    import tempfile
    return tempfile.gettempdir()


orchestrator = UpgradeOrchestrator()


# --- module-level facade (preserved API) -----------------------------------


async def get_current_system_info(db: AsyncSession) -> dict:
    info = provider.get_current_version()
    try:
        from sqlalchemy import text as sa_text
        result = await db.execute(sa_text("SELECT version_num FROM alembic_version"))
        row = result.fetchone()
        if row:
            info["database_schema_revision"] = row[0]
    except Exception:
        info["database_schema_revision"] = info.get("database_schema_revision", "alembic_head_unknown")
    session = await orchestrator.get_session(db)
    if session and session.get("state"):
        info["upgrade_status"] = session["state"]
    else:
        history = await orchestrator.get_history(db)
        if history:
            info["upgrade_status"] = history[0].get("state", STATE_IDLE)
        else:
            info["upgrade_status"] = STATE_IDLE
    return info


async def check_available_updates(db: AsyncSession) -> dict:
    return await provider.check_available_updates(db)


async def run_preflight_checks(db: AsyncSession) -> list[dict]:
    return await provider.run_readiness_checks(db)


async def get_upgrade_history(db: AsyncSession) -> list[dict]:
    history = await orchestrator.get_history(db)
    for item in history:
        if "simulated" not in item:
            item["simulated"] = False
    return history
