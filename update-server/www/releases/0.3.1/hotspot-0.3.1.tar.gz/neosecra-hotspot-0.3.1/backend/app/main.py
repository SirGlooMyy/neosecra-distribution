import asyncio
import inspect
import json
import logging
import os
import socket
import threading
import time
from contextlib import asynccontextmanager
from urllib.parse import urlparse

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1.router import api_router
from app.core.config import ProductionSettingsError, settings
from app.modules.portal.public_router import router as portal_public_router
from app.modules.portal.ios_captive import router as ios_captive_router

log = logging.getLogger(__name__)


class JSONFormatter(logging.Formatter):
    """Structured JSON logging for production."""

    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "time": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0]:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


if settings.ENVIRONMENT == "production":
    for handler in logging.getLogger().handlers:
        handler.setFormatter(JSONFormatter())

errors = settings.validate_production()
if errors:
    raise ProductionSettingsError(
        "Production configuration is unsafe — refusing to start:\n" + "\n".join(errors)
    )


_syslog_server = None


async def _run_health_check(check, *, timeout: float = 3.0):
    """Run a potentially blocking dependency probe off the ASGI loop.

    DNS resolution and client connection setup can block in a library-owned
    executor that is not cancellable.  A short-lived daemon thread keeps those
    operations from delaying request handling or event-loop shutdown.
    """
    loop = asyncio.get_running_loop()
    result: asyncio.Future = loop.create_future()

    def _runner() -> None:
        try:
            value = check()
            if inspect.isawaitable(value):
                value = asyncio.run(value)
        except Exception as exc:  # pragma: no cover - dependency-specific
            value = exc

        def _finish() -> None:
            if not result.done():
                result.set_result(value)

        try:
            loop.call_soon_threadsafe(_finish)
        except RuntimeError:
            # The request loop may have been closed after a timeout.
            pass

    threading.Thread(target=_runner, name="health-check", daemon=True).start()
    value = await asyncio.wait_for(result, timeout=timeout)
    if isinstance(value, Exception):
        raise value
    return value


def _url_host_resolves(url: str, *, timeout: float = 0.25) -> bool:
    """Resolve a dependency hostname without touching the event loop."""
    try:
        parsed = urlparse(url)
        host = parsed.hostname or ""
        port = parsed.port or 0
    except ValueError:
        return False
    if not host:
        return False
    for family in (socket.AF_INET, socket.AF_INET6):
        try:
            socket.inet_pton(family, host)
            return True
        except OSError:
            pass

    done = threading.Event()
    resolved = {"ok": False}

    def _resolve() -> None:
        try:
            socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            resolved["ok"] = True
        except OSError:
            pass
        finally:
            done.set()

    threading.Thread(target=_resolve, name="health-dns-resolve", daemon=True).start()
    return resolved["ok"] if done.wait(timeout) else False


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Start syslog TCP server on application startup, stop on shutdown."""
    global _syslog_server
    syslog_task = None
    try:
        from app.core.database import AsyncSessionLocal
        from app.modules.radius.runtime import sync_runtime_clients

        # Keep the bundled FreeRADIUS client list aligned with encrypted
        # platform records before the daemon's health-gated startup.
        try:
            async with AsyncSessionLocal() as radius_db:
                await sync_runtime_clients(radius_db)
        except Exception:
            # RADIUS runtime refresh is best-effort; it must never prevent the
            # syslog listener/API from starting during a first boot migration.
            log.warning("RADIUS runtime client refresh failed", exc_info=True)

        from app.modules.syslog.listener import serve_forever
        syslog_task = asyncio.create_task(
            serve_forever(AsyncSessionLocal)
        )
        log.info("Syslog TCP server task created")
    except Exception:
        log.exception("Failed to start syslog TCP server (non-fatal)")
    yield
    if syslog_task:
        syslog_task.cancel()
        try:
            await syslog_task
        except asyncio.CancelledError:
            pass
        log.info("Syslog TCP server stopped")


app = FastAPI(
    title="Hotspot Platform",
    version=os.getenv("PRODUCT_VERSION", "0.3.5"),
    description="FortiGate hotspot platform: captive portal, guest session management, 5651 log archiving and digital signing, FortiGate syslog ingestion, ClickHouse analytics, and SMS authentication.",
    lifespan=lifespan,
    contact={
        "name": "Hotspot Team",
        "email": "info@hotspotplatform.com",
        "url": "https://hotspotplatform.com",
    },
    license_info={
        "name": "Proprietary",
        "url": "https://hotspotplatform.com/license",
    },
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Catch-all exception handler — returns structured error responses."""
    log.exception("Unhandled exception: %s", exc)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "error_type": type(exc).__name__},
    )

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_vary_header(request: Request, call_next):
    response = await call_next(request)
    if "Origin" in request.headers and "Vary" not in response.headers:
        response.headers["Vary"] = "Origin"
    elif "Origin" in request.headers and "origin" not in response.headers.get("Vary", "").lower():
        response.headers["Vary"] += ", Origin"
    return response

app.include_router(api_router, prefix="/api/v1")
app.include_router(portal_public_router, prefix="/portal/public")
app.include_router(ios_captive_router)


@app.get("/health", tags=["system"], summary="Health check endpoint for all platform services")
async def health():
    checks: dict = {
        "status": "ok",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "timestamp": time.time(),
    }
    degraded = False
    try:
        from app.core.database import AsyncSessionLocal

        if not _url_host_resolves(settings.DATABASE_URL):
            raise RuntimeError("database hostname is not resolvable")
        async with AsyncSessionLocal() as db:
            await asyncio.wait_for(
                db.execute(__import__("sqlalchemy").text("SELECT 1")),
                timeout=3.0,
            )
        checks["database"] = "ok"
    except Exception:
        checks["database"] = "unavailable"
        degraded = True
    try:
        import redis.asyncio as redis

        if not _url_host_resolves(settings.REDIS_URL):
            raise RuntimeError("redis hostname is not resolvable")
        r = redis.from_url(settings.REDIS_URL, decode_responses=True)
        try:
            await asyncio.wait_for(r.ping(), timeout=3.0)
        finally:
            await r.aclose()
        checks["redis"] = "ok"
    except Exception:
        checks["redis"] = "unavailable"
        degraded = True
    try:
        # Import the configured application, not Celery's default amqp app.
        from app.modules.workers.celery_app import celery_app

        replies = await _run_health_check(lambda: celery_app.control.ping(timeout=2))
        checks["celery"] = "ok" if replies else "unavailable"
        degraded = degraded or not bool(replies)
    except Exception:
        checks["celery"] = "unavailable"
        degraded = True

    if settings.ARCHIVE_PROVIDER != "minio":
        checks["minio"] = "disabled"
    else:
        try:
            from minio import Minio

            def _check_minio():
                client = Minio(
                    settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
                    access_key=settings.MINIO_ACCESS_KEY,
                    secret_key=settings.MINIO_SECRET_KEY,
                    secure=settings.MINIO_SECURE,
                )
                client.list_buckets()

            await _run_health_check(_check_minio)
            checks["minio"] = "ok"
        except Exception:
            checks["minio"] = "unavailable"
            degraded = True

    if not settings.CLICKHOUSE_ENABLED:
        checks["clickhouse"] = "disabled"
    else:
        try:
            import clickhouse_connect

            def _check_clickhouse():
                client = clickhouse_connect.get_client(
                    host=settings.CLICKHOUSE_HOST,
                    port=settings.CLICKHOUSE_PORT,
                    database=settings.CLICKHOUSE_DB,
                    username=settings.CLICKHOUSE_USER,
                    password=settings.CLICKHOUSE_PASSWORD,
                    connect_timeout=settings.CLICKHOUSE_CONNECT_TIMEOUT,
                    send_receive_timeout=settings.CLICKHOUSE_SEND_TIMEOUT,
                )
                client.execute("SELECT 1")

            await _run_health_check(_check_clickhouse)
            checks["clickhouse"] = "ok"
        except Exception:
            checks["clickhouse"] = "unavailable"
            degraded = True
    if degraded:
        checks["status"] = "degraded"
    return JSONResponse(content=checks)
