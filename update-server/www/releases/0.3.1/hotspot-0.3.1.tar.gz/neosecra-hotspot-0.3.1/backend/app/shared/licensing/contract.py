"""Canonical Hotspot license/update contract."""
from datetime import datetime, timezone, timedelta
PRODUCT_CODE = "hotspot"
CHANNEL = "hotspot-stable"
EDITIONS = frozenset({"standard", "enterprise"})
LICENSE_STATUSES = ("NOT_INSTALLED", "ACTIVE", "EXPIRING_SOON", "GRACE_PERIOD", "EXPIRED", "REVOKED", "INVALID_PRODUCT", "INVALID_SIGNATURE", "INSTALLATION_MISMATCH", "NOT_YET_VALID", "LEGACY_WARNING")
_NON_TIME_STATUSES = frozenset({"REVOKED", "INVALID_PRODUCT", "INVALID_SIGNATURE", "INSTALLATION_MISMATCH", "LEGACY_WARNING"})


def _parse_datetime(value: object) -> datetime:
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def license_status(payload: dict | None, now: datetime | None = None) -> str:
    if not payload: return "NOT_INSTALLED"
    raw_status = str(payload.get("status") or "").upper()
    if raw_status in _NON_TIME_STATUSES: return raw_status
    try:
        now = now or datetime.now(timezone.utc); start = _parse_datetime(payload["valid_from"]); end = _parse_datetime(payload["expires_at"]); grace_days = int(payload.get("grace_period_days", 0))
        if grace_days < 0: raise ValueError("negative grace period")
    except (KeyError, TypeError, ValueError, OverflowError): return "INVALID_SIGNATURE"
    if now < start: return "NOT_YET_VALID"
    if now >= end:
        grace_end = end + timedelta(days=grace_days)
        return "GRACE_PERIOD" if grace_days > 0 and now < grace_end else "EXPIRED"
    return "EXPIRING_SOON" if (end-now).days <= 30 else "ACTIVE"
def update_entitlement_expired(payload: dict | None, now: datetime | None = None) -> bool:
    value = (payload or {}).get("update_entitlement_until")
    if not value: return False
    try: return (now or datetime.now(timezone.utc)) >= _parse_datetime(value)
    except (TypeError, ValueError, OverflowError): return True
