"""5651 archive admin endpoints.

Read = archive.read; build/trigger = archive.write. Archives are append-only
(Mutlak Kural #4) so there is no update/delete here — only list, get, build
(admin trigger; the worker calls the same service on a schedule) and verify
(tamper-evidence check of the hash chain).

Digital signing, report generation, chain verification, and court evidence
export endpoints are added in compliance with 5651 sayili Kanun ve TUBITAK
KamuSM entegrasyon gereksinimleri.
"""
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.shared.licensing.license_service import require_licensed_module
from app.modules.customers.models import Customer
from app.modules.logs_5651 import service
from app.modules.logs_5651.models import ArchiveRecord
from app.modules.logs_5651.models import RECORD_TYPES
from app.modules.logs_5651.schemas import (
    ArchiveBuildIn,
    ArchiveRecordOut,
    ArchiveVerifyResult,
    ChainVerifyResult,
    EvidenceStatus,
    KamuSmConfigOut,
    KamuSmConfigUpdate,
    SignResult,
    SingleVerifyResult,
)

router = APIRouter()


def _require(role: str, perm: str) -> None:
    if not has_permission(role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


async def _authorize_build(db: AsyncSession, scope, customer_id: uuid.UUID) -> None:
    """Caller's scope must cover the target customer (IDOR guard on the build
    trigger). super_admin any; partner_admin under their partner; customer_admin
    their own only; anyone else denied."""
    if scope.level == "global":
        return
    if scope.level == "partner":
        cust = await db.get(Customer, customer_id)
        if not cust or str(cust.partner_id) != str(scope.partner_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu musteri sizin partner kapsaminizda degil")
        return
    if scope.level == "customer":
        if str(scope.customer_id) != str(customer_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Baska musteri icin arsiv olusturamazsiniz")
        return
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Arsiv olusturma yetkiniz yok")


async def _authorize_customer_access(db: AsyncSession, scope, customer_id: uuid.UUID) -> None:
    """Generic IDOR guard: caller must have access to the target customer."""
    if scope.level == "global":
        return
    if scope.level == "partner":
        cust = await db.get(Customer, customer_id)
        if not cust or str(cust.partner_id) != str(scope.partner_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu musteri sizin kapsaminizda degil")
        return
    if scope.level == "customer":
        if str(scope.customer_id) != str(customer_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Baska musteri verisine erisemezsiniz")
        return
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Erisim yetkiniz yok")


# ---- existing endpoints -------------------------------------------------------


@router.get("", response_model=list[ArchiveRecordOut], summary="List all 5651 archive records with optional type filter", description="Returns a list of archive records scoped to the authenticated user's tenant. Optionally filters by record type. Requires the archive.read permission.")
async def list_archives(
    record_type: str | None = Query(None),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    return await service.list_archives(db, scope_for(user), record_type=record_type)


@router.post("/build", response_model=ArchiveRecordOut, status_code=status.HTTP_201_CREATED, summary="Trigger immediate archive build for a specified period", description="Administratively triggers the sealing of session archives for the given customer and time period. The scheduled worker uses the same underlying build service. Requires the archive.write permission.")
async def build_archive(
    body: ArchiveBuildIn, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.write")
    scope = scope_for(user)
    customer_id = body.customer_id or await resolve_installation_customer(db)
    await _authorize_build(db, scope, customer_id)
    await require_licensed_module(db, user, "logs_5651")
    if body.record_type not in RECORD_TYPES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"record_type {RECORD_TYPES} icinden olmali",
        )
    if body.record_type == "session_archive":
        return await service.build_session_archive(
            db,
            customer_id=customer_id,
            period_start=body.period_start,
            period_end=body.period_end,
            request=request,
        )
    else:
        return await service.build_raw_log_archive(
            db,
            customer_id=customer_id,
            record_type=body.record_type,
            period_start=body.period_start,
            period_end=body.period_end,
            request=request,
        )


@router.get("/verify", response_model=ArchiveVerifyResult, summary="Verify the integrity of the archive hash chain", description="Walks the complete hash chain to verify that no archive record has been tampered with. Optionally scoped to a specific customer ID. Returns verification status and details of any inconsistencies. Requires the archive.read permission.")
@router.get("/verify/{customer_id}", response_model=ArchiveVerifyResult, summary="Verify archive hash chain for a specific customer", description="Walks the complete hash chain for the specified customer to detect tampering. Returns detailed break information if any integrity violation is found. Requires the archive.read permission.")
async def verify_chain(
    customer_id: uuid.UUID | None = None,
    record_type: str = Query("session_archive"),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    scope = scope_for(user)
    cid = customer_id or scope.customer_id
    if cid is None and scope.level.value == "global":
        cid = await resolve_installation_customer(db)
    if not cid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Müşteri ID bulunamadı.",
        )
    return await service.verify_chain(
        db, customer_id=cid, record_type=record_type
    )


@router.post("/sign-all", summary="Sign all unsigned 5651 archives", description="Signs all currently unsigned archive records for the tenant using configured KamuSM or local certificate.")
async def sign_all_archives(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.write")
    await require_licensed_module(db, user, "logs_5651")
    return await service.sign_all_unsigned_archives(db, scope_for(user))


@router.post("/seal-today", summary="Seal and sign today's live logs immediately", description="Instantly builds and cryptographically signs both Session and Firewall Traffic archives for today.")
async def seal_today_logs(
    customer_id: uuid.UUID | None = Query(None, description="Musteri ID (opsiyonel)"),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.write")
    await require_licensed_module(db, user, "logs_5651")
    return await service.seal_live_logs_today(db, scope_for(user), customer_id=customer_id)


@router.post("/{record_id}/sign", response_model=SignResult, summary="Trigger digital signing for an archive record", description="Initiates digital signing of the specified archive record using the customer's configured KamuSM or local certificate settings. Returns signing status and signature metadata. Requires the archive.write permission.")
async def sign_archive(
    record_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.write")
    await require_licensed_module(db, user, "logs_5651")
    from app.modules.logs_5651.signing_service import sign_archive_record

    archive = await service.get_archive(db, record_id, scope_for(user))
    archive_rec = await db.get(ArchiveRecord, archive["id"])
    try:
        result = await sign_archive_record(db, archive_rec)  # type: ignore[arg-type]
    except RuntimeError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    await db.commit()
    return result


@router.post("/sign/config", response_model=KamuSmConfigOut, summary="Update TUBITAK KamuSM signing configuration for a customer", description="Updates the digital signing configuration including KamuSM credentials and certificate settings. Sensitive fields such as passwords are encrypted before storage. Requires the archive.write permission.")
@router.put("/sign/config", response_model=KamuSmConfigOut, summary="Update TUBITAK KamuSM signing configuration for a customer", description="Updates the digital signing configuration including KamuSM credentials and certificate settings. Sensitive fields such as passwords are encrypted before storage. Requires the archive.write permission.")
async def update_sign_config(
    body: KamuSmConfigUpdate,
    customer_id: uuid.UUID | None = Query(None, description="Musteri ID (opsiyonel)"),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.write")
    await require_licensed_module(db, user, "logs_5651")
    scope = scope_for(user)
    if customer_id is None:
        customer_id = scope.customer_id or await resolve_installation_customer(db)
    await _authorize_customer_access(db, scope, customer_id)
    from app.modules.logs_5651.signing_service import update_kamusm_config

    return await update_kamusm_config(db, customer_id, body.model_dump(exclude_none=True))


@router.get("/sign/config", response_model=KamuSmConfigOut, summary="Get KamuSM signing configuration with secrets masked", description="Returns the current digital signing configuration for the specified customer. Secret values such as passwords are masked in the response. Requires the archive.read permission.")
async def get_sign_config(
    customer_id: uuid.UUID | None = Query(None, description="Musteri ID (opsiyonel)"),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    scope = scope_for(user)
    if customer_id is None:
        customer_id = scope.customer_id or await resolve_installation_customer(db)
    await _authorize_customer_access(db, scope, customer_id)
    from app.modules.logs_5651.signing_service import get_kamusm_status

    return await get_kamusm_status(db, customer_id)


@router.get("/chain/verify/{customer_id}", response_model=ChainVerifyResult, summary="Verify the full hash chain integrity for a customer", description="Walks and verifies the complete hash chain for a given customer and record type. Returns detailed break information and sequence gaps if tampering is detected. Requires the archive.read permission.")
async def verify_full_chain(
    customer_id: uuid.UUID,
    record_type: str = Query("session_archive"),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    from app.modules.logs_5651.verify_service import verify_chain_integrity

    return await verify_chain_integrity(db, customer_id, record_type)


@router.get("/{record_id}/verify", response_model=SingleVerifyResult, summary="Verify a single archive record integrity and signature", description="Validates the content hash, hash chain linkage, and digital signature (if present) for the specified archive record. Returns detailed verification status for each check. Requires the archive.read permission.")
async def verify_single_archive(
    record_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    archive = await service.get_archive(db, record_id, scope_for(user))
    from app.modules.logs_5651.verify_service import verify_single_archive as _verify

    return await _verify(db, archive["id"])


@router.get("/{record_id}/download-raw", summary="Download raw archive file (jsonl/zstd)", description="Downloads the raw cryptographic archive payload.")
async def download_archive_raw(
    record_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    archive = await service.get_archive(db, record_id, scope_for(user))
    from app.modules.logs_5651.archive_service import read_archive_payload

    content = read_archive_payload(archive.get("content_ref") or "")
    if not content:
        import json
        content = json.dumps(archive, indent=2, default=str).encode("utf-8")

    filename = f"5651_raw_archive_{archive.get('chain_seq', 1)}_{str(archive['id'])[:8]}.jsonl"
    return Response(
        content=content,
        media_type="application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/{record_id}/download", summary="Download an archive record as 5651-compliant PDF report", description="Generates and downloads a 5651-compliant PDF report for the specified archive record. The PDF includes session details, hash chain information, and digital signature metadata. Requires the archive.read permission.")
async def download_archive_pdf(
    record_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    archive = await service.get_archive(db, record_id, scope_for(user))
    archive_rec = await db.get(ArchiveRecord, archive["id"])
    records = [archive_rec] if archive_rec else []

    from app.modules.logs_5651.report_service import generate_5651_pdf

    pdf_bytes = await generate_5651_pdf(
        db,
        customer_id=archive["customer_id"],
        period_start=archive["period_start"],
        period_end=archive["period_end"],
        archive_records=records,
    )
    filename = f"5651_arsiv_{archive.get('chain_seq', 1)}_{str(archive['id'])[:12]}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/{record_id}/download-zip", summary="Download complete 5651 evidence ZIP package", description="Generates and downloads a complete 5651 court/audit ZIP package containing the official PDF report, raw JSONL log records, cryptographic signature manifest, and verification guide.")
async def download_archive_zip(
    record_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    archive = await service.get_archive(db, record_id, scope_for(user))
    from app.modules.logs_5651.report_service import generate_archive_zip_package

    zip_bytes, filename = await generate_archive_zip_package(
        db,
        archive_id=archive["id"],
        customer_id=archive["customer_id"],
    )
    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# Keep the catch-all UUID route after every static route above.  Starlette
# evaluates routes in declaration order; placing this before /verify, /build,
# /sign/config, or /chain/verify makes those paths attempt UUID parsing and
# return a misleading 422 instead of reaching their handlers.
@router.get("/{record_id}", response_model=ArchiveRecordOut, summary="Retrieve a single archive record by its ID", description="Fetches detailed information about a specific 5651 archive record including its hash chain linkage and timestamps. Access is scoped to the user's tenant. Requires the archive.read permission.")
async def get_archive(
    record_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    return await service.get_archive(db, record_id, scope_for(user))


# ---- court evidence export ----------------------------------------------------


@router.post("/evidence/export/{session_id}", response_model=EvidenceStatus, summary="Export court evidence package for a specific session", description="Generates a court evidence package for the specified session. The package includes session data, syslog records, RADIUS accounting, and hash chain information in a signed ZIP archive. Prepared in accordance with 5651 sayili Kanun. Requires the archive.write permission.")
async def export_court_evidence(
    session_id: uuid.UUID,
    customer_id: uuid.UUID | None = Query(None, description="Musteri ID (opsiyonel)"),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.write")
    await require_licensed_module(db, user, "logs_5651")
    scope = scope_for(user)
    if customer_id is None:
        customer_id = scope.customer_id or await resolve_installation_customer(db)
    await _authorize_customer_access(db, scope, customer_id)

    from app.modules.logs_5651.report_service import (
        generate_court_evidence_package,
        save_evidence_package,
    )

    pkg_bytes = await generate_court_evidence_package(db, session_id, customer_id)
    pkg_ref = await save_evidence_package(pkg_bytes, session_id, customer_id)


    return EvidenceStatus(
        export_id=uuid.uuid4(),
        session_id=session_id,
        status="ready",
        package_ref=pkg_ref,
        created_at=datetime.now(timezone.utc),
        error_message=None,
    )


@router.get("/evidence/export/{session_id}/status", response_model=EvidenceStatus, summary="Check court evidence export status for a session", description="Returns the current status of a court evidence export for the specified session. Includes download reference and availability information. Requires the archive.read permission.")
async def get_evidence_export_status(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "archive.read")
    scope = scope_for(user)
    # Scope check: ensure caller can access this session's customer
    from app.modules.sessions import service as sessions_service

    await sessions_service.get_session(db, session_id, scope)

    return EvidenceStatus(
        export_id=session_id,
        session_id=session_id,
        status="available",
        package_ref=None,
        created_at=datetime.now(timezone.utc),
        error_message=None,
    )


# FastAPI/Starlette evaluates routes in declaration order. Keep every generic
# UUID route after static paths such as /verify, /sign/config and /evidence.
# Otherwise `/sign/config` is parsed as `record_id=sign` by `/{record_id}/sign`
# and fails UUID validation with 422 before the real handler is reached.
_generic_archive_routes = [
    route for route in router.routes
    if getattr(route, "path", None) in {
        "/{record_id}",
        "/{record_id}/sign",
        "/{record_id}/verify",
        "/{record_id}/download",
        "/{record_id}/download-raw",
        "/{record_id}/download-zip",
    }
]
if _generic_archive_routes:
    _generic_paths = {getattr(route, "path", None) for route in _generic_archive_routes}
    router.routes = [
        route for route in router.routes
        if getattr(route, "path", None) not in _generic_paths
    ] + _generic_archive_routes
