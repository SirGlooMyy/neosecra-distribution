"""ClickHouse async client for syslog hot/cold storage.

Sıcak veri (0-90g): ClickHouse'da anlık sorgulanabilir.
Soğuk veri (91-730g): ClickHouse sıkıştırılmış partition (TTL ile otomatik).
730g sonrası: ClickHouse TTL ile otomatik silme.

PostgreSQL'de sadece arşiv katalog + hash + imza bilgisi tutulur.
"""
import logging
from datetime import datetime, timezone
from typing import Any
from types import SimpleNamespace

from app.core.config import settings

_missing_clickhouse_connect = None

try:
    import clickhouse_connect  # type: ignore[import-not-found]
    from clickhouse_connect.driver import Client  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover - optional dependency in tests/dev
    def _missing_clickhouse_connect_impl(*args, **kwargs):
        raise RuntimeError("clickhouse_connect package is not installed")

    _missing_clickhouse_connect = _missing_clickhouse_connect_impl
    clickhouse_connect = SimpleNamespace(get_client=_missing_clickhouse_connect_impl)
    Client = Any  # type: ignore[misc,assignment]

log = logging.getLogger(__name__)

_client = None


def _get_client():
    global _client
    if _client is None:
        _client = clickhouse_connect.get_client(
            host=settings.CLICKHOUSE_HOST,
            port=settings.CLICKHOUSE_PORT,
            database=settings.CLICKHOUSE_DB,
            username=settings.CLICKHOUSE_USER,
            password=settings.CLICKHOUSE_PASSWORD,
            connect_timeout=settings.CLICKHOUSE_CONNECT_TIMEOUT,
            send_receive_timeout=settings.CLICKHOUSE_SEND_TIMEOUT,
        )
    return _client


async def ensure_schema() -> None:
    """Create tables if they don't exist (idempotent)."""
    if _missing_clickhouse_connect is not None and getattr(clickhouse_connect, "get_client", None) is _missing_clickhouse_connect:
        raise RuntimeError("clickhouse_connect package is not installed")
    c = _get_client()
    for stmt in [
        """CREATE TABLE IF NOT EXISTS hotspot.syslog_logs (
            timestamp DateTime64(3) CODEC(ZSTD(3)),
            customer_id UUID, location_id UUID, device_id UUID,
            facility LowCardinality(String), severity UInt8,
            hostname LowCardinality(String), app_name LowCardinality(String),
            source_ip IPv6, dest_ip IPv6, mac String,
            username LowCardinality(String), domain LowCardinality(String),
            application LowCardinality(String), action LowCardinality(String),
            message String CODEC(ZSTD(3)), raw String CODEC(ZSTD(3)), session_id UUID,
            INDEX idx_ip (source_ip, dest_ip) TYPE bloom_filter(0.01) GRANULARITY 1,
            INDEX idx_mac (mac) TYPE bloom_filter(0.01) GRANULARITY 1,
            INDEX idx_user (username) TYPE bloom_filter(0.01) GRANULARITY 1,
            INDEX idx_device (device_id) TYPE set(100) GRANULARITY 2,
            INDEX idx_domain (domain) TYPE bloom_filter(0.01) GRANULARITY 1,
            INDEX idx_msg_token (message) TYPE tokenbf_v1(30720, 2, 0) GRANULARITY 1,
            INDEX idx_raw_token (raw) TYPE tokenbf_v1(30720, 2, 0) GRANULARITY 1,
            INDEX idx_time (timestamp) TYPE minmax GRANULARITY 1
        ) ENGINE = MergeTree
        PARTITION BY (customer_id, toYYYYMM(timestamp))
        ORDER BY (timestamp, customer_id, severity)
        TTL toDateTime(timestamp) + INTERVAL 730 DAY TO DELETE
        SETTINGS index_granularity = 8192""",

        """CREATE TABLE IF NOT EXISTS hotspot.traffic_hourly (
            customer_id UUID, location_id UUID,
            hour DateTime CODEC(ZSTD(3)),
            session_count UInt32, bytes_in UInt64, bytes_out UInt64,
            active_users UInt32, new_users UInt32
        ) ENGINE = SummingMergeTree
        PARTITION BY (customer_id, toYYYYMM(hour))
        ORDER BY (customer_id, location_id, hour)
        TTL toDateTime(hour) + INTERVAL 730 DAY""",
    ]:
        c.command(stmt)


async def insert_syslog_batch(records: list[dict]) -> int:
    """Batch insert syslog records into ClickHouse.
    Returns the number of records inserted.
    """
    if not records:
        return 0
    c = _get_client()
    c.insert(
        table="syslog_logs",
        data=[[
            r.get("timestamp", datetime.now(timezone.utc)),
            r.get("customer_id"),
            r.get("location_id"),
            r.get("device_id"),
            r.get("facility", "unknown"),
            r.get("severity", 5),
            r.get("hostname", ""),
            r.get("app_name", ""),
            r.get("source_ip", "::"),
            r.get("dest_ip", "::"),
            r.get("mac", ""),
            r.get("username", ""),
            r.get("domain", ""),
            r.get("application", ""),
            r.get("action", ""),
            r.get("message", ""),
            r.get("raw", ""),
            r.get("session_id", "00000000-0000-0000-0000-000000000000"),
        ] for r in records],
        column_names=[
            "timestamp", "customer_id", "location_id", "device_id",
            "facility", "severity", "hostname", "app_name",
            "source_ip", "dest_ip", "mac", "username", "domain",
            "application", "action", "message", "raw", "session_id",
        ],
    )
    return len(records)


async def query_syslog(
    customer_id: str,
    *,
    from_time: datetime | None = None,
    to_time: datetime | None = None,
    log_type: str | None = None,
    source_ip: str | None = None,
    dest_ip: str | None = None,
    mac: str | None = None,
    username: str | None = None,
    domain: str | None = None,
    application: str | None = None,
    action: str | None = None,
    severity_min: int | None = None,
    severity_max: int | None = None,
    hostname: str | None = None,
    location_id: str | None = None,
    device_id: str | None = None,
    quick_filter: str | None = None,
    q: str | None = None,
    limit: int = 100,
    offset: int = 0,
    **kwargs: Any,
) -> list[dict]:
    """Search syslog records in ClickHouse with filters including free-text q search."""
    conditions = ["customer_id = {cid:String}"]
    params: dict[str, Any] = {"cid": customer_id}

    if quick_filter:
        qf = quick_filter.lower().strip()
        if qf == "denied":
            conditions.append("action IN ('deny', 'blocked', 'drop', 'client-rst', 'server-rst', 'timeout')")
        elif qf == "vpn":
            conditions.append("(app_name = 'vpn' OR positionCaseInsensitive(raw, 'vpn') > 0 OR positionCaseInsensitive(message, 'tunnel-up') > 0)")
        elif qf == "webfilter":
            conditions.append("(app_name = 'webfilter' OR (app_name = 'utm' AND positionCaseInsensitive(raw, 'webfilter') > 0))")
        elif qf in ("appctrl", "app-ctrl"):
            conditions.append("(app_name IN ('app-ctrl', 'appctrl', 'application') OR positionCaseInsensitive(raw, 'app-ctrl') > 0)")
        elif qf in ("threats", "critical"):
            conditions.append("(action IN ('deny', 'blocked', 'drop') OR app_name IN ('utm', 'webfilter', 'ips', 'virus') OR (severity <= 3 AND app_name != 'vpn'))")

    if from_time:
        conditions.append("timestamp >= {ft:String}")
        params["ft"] = from_time.isoformat()
    if to_time:
        conditions.append("timestamp <= {tt:String}")
        params["tt"] = to_time.isoformat()
    if log_type and not quick_filter:
        types = [value.strip() for value in log_type.split(",") if value.strip()]
        if types:
            if "vpn" in types:
                conditions.append(
                    "(app_name IN {log_types:Array(String)} OR "
                    "(positionCaseInsensitive(raw, 'vpn') > 0 OR "
                    "positionCaseInsensitive(message, 'ssl vpn') > 0 OR "
                    "positionCaseInsensitive(message, 'tunnel-up') > 0 OR "
                    "positionCaseInsensitive(message, 'tunnel-down') > 0))"
                )
            else:
                conditions.append("app_name IN {log_types:Array(String)}")
            params["log_types"] = types
    if source_ip:
        conditions.append("positionCaseInsensitive(toString(source_ip), {sip:String}) > 0")
        params["sip"] = source_ip.strip()
    if dest_ip:
        conditions.append("positionCaseInsensitive(toString(dest_ip), {dip:String}) > 0")
        params["dip"] = dest_ip.strip()
    if mac:
        conditions.append("positionCaseInsensitive(mac, {mac:String}) > 0")
        params["mac"] = mac.strip().upper()
    if username:
        conditions.append("positionCaseInsensitive(username, {uname:String}) > 0")
        params["uname"] = username.strip()
    if domain:
        conditions.append("positionCaseInsensitive(domain, {dom:String}) > 0")
        params["dom"] = domain.strip()
    if application:
        conditions.append("positionCaseInsensitive(application, {app:String}) > 0")
        params["app"] = application.strip()
    if action:
        conditions.append("lower(action) = lower({act:String})")
        params["act"] = action.strip()
    if severity_min is not None:
        conditions.append("severity >= {smin:UInt8}")
        params["smin"] = severity_min
    if severity_max is not None:
        conditions.append("severity <= {smax:UInt8}")
        params["smax"] = severity_max
    if hostname:
        conditions.append("positionCaseInsensitive(hostname, {hst:String}) > 0")
        params["hst"] = hostname.strip()
    if location_id:
        conditions.append("toString(location_id) = {lid:String}")
        params["lid"] = location_id
    if device_id:
        conditions.append("toString(device_id) = {did:String}")
        params["did"] = device_id
    if q:
        needle = q.strip()
        conditions.append(
            "(positionCaseInsensitive(message, {q:String}) > 0 OR "
            "positionCaseInsensitive(raw, {q:String}) > 0 OR "
            "positionCaseInsensitive(toString(source_ip), {q:String}) > 0 OR "
            "positionCaseInsensitive(toString(dest_ip), {q:String}) > 0 OR "
            "positionCaseInsensitive(hostname, {q:String}) > 0 OR "
            "positionCaseInsensitive(username, {q:String}) > 0 OR "
            "positionCaseInsensitive(application, {q:String}) > 0 OR "
            "positionCaseInsensitive(action, {q:String}) > 0 OR "
            "positionCaseInsensitive(domain, {q:String}) > 0)"
        )
        params["q"] = needle

    where = " AND ".join(conditions)
    query = f"SELECT * FROM hotspot.syslog_logs WHERE {where} ORDER BY timestamp DESC LIMIT {limit} OFFSET {offset}"

    c = _get_client()
    result = c.query(query, parameters=params)
    return [dict(zip(result.column_names, row)) for row in result.result_rows]


async def get_syslog_facets(
    customer_id: str,
    *,
    from_time: datetime | None = None,
    to_time: datetime | None = None,
    q: str | None = None,
    limit: int = 10,
) -> dict[str, list[dict]]:
    """Compute top-N facets and date histogram from ClickHouse."""
    conditions = ["customer_id = {cid:String}"]
    params: dict[str, Any] = {"cid": customer_id}
    if from_time:
        conditions.append("timestamp >= {ft:String}")
        params["ft"] = from_time.isoformat()
    if to_time:
        conditions.append("timestamp <= {tt:String}")
        params["tt"] = to_time.isoformat()
    if q:
        conditions.append(
            "(position(lower(message), {q:String}) > 0 OR "
            "position(lower(raw), {q:String}) > 0 OR "
            "position(lower(hostname), {q:String}) > 0 OR "
            "position(lower(username), {q:String}) > 0)"
        )
        params["q"] = q.lower().strip()

    where = " AND ".join(conditions)
    c = _get_client()
    facets: dict[str, list[dict]] = {}

    dimensions = [
        ("vendor", "hostname"),  # hostname can represent vendor/device if vendor field is low card
        ("action", "action"),
        ("severity", "toString(severity)"),
        ("src_ip", "IPv6NumToString(source_ip)"),
        ("dst_ip", "IPv6NumToString(dest_ip)"),
        ("user", "username"),
        ("domain", "domain"),
        ("application", "application"),
    ]

    for facet_key, col in dimensions:
        res = c.query(
            f"SELECT {col} AS val, count() AS cnt FROM hotspot.syslog_logs "
            f"WHERE {where} AND {col} != '' GROUP BY val ORDER BY cnt DESC LIMIT {limit}",
            parameters=params,
        )
        facets[facet_key] = [{"value": str(row[0]), "count": int(row[1])} for row in res.result_rows]

    # Date histogram (hourly buckets)
    hist_res = c.query(
        f"SELECT toStartOfHour(timestamp) AS bucket, count() AS cnt FROM hotspot.syslog_logs "
        f"WHERE {where} GROUP BY bucket ORDER BY bucket ASC LIMIT 100",
        parameters=params,
    )
    facets["histogram"] = [
        {"timestamp": r[0].isoformat() if hasattr(r[0], "isoformat") else str(r[0]), "count": int(r[1])}
        for r in hist_res.result_rows
    ]
    return facets


async def count_syslog(customer_id: str, from_time: datetime, to_time: datetime) -> int:
    """Quick count of syslog records for dashboard."""
    c = _get_client()
    result = c.query(
        "SELECT count() FROM hotspot.syslog_logs "
        "WHERE customer_id = {cid:String} AND timestamp >= {ft:String} AND timestamp <= {tt:String}",
        parameters={"cid": customer_id, "ft": from_time.isoformat(), "tt": to_time.isoformat()},
    )
    return result.first_row[0] if result.first_row else 0


async def get_traffic_aggregation(
    customer_id: str, *, days: int = 30, location_id: str | None = None
) -> dict:
    """Aggregate traffic from ClickHouse for dashboard."""
    c = _get_client()
    conditions = ["customer_id = {cid:String}"]
    params: dict[str, Any] = {"cid": customer_id}
    if location_id:
        conditions.append("location_id = {lid:String}")
        params["lid"] = location_id

    where = " AND ".join(conditions)

    hourly = c.query(
        f"SELECT toStartOfHour(hour) AS h, sum(bytes_in) AS bi, sum(bytes_out) AS bo, "
        f"sum(session_count) AS sc, sum(active_users) AS au "
        f"FROM hotspot.traffic_hourly WHERE {where} AND hour >= now() - INTERVAL {days} DAY "
        f"GROUP BY h ORDER BY h",
        parameters=params,
    )

    summary = c.query(
        f"SELECT sum(bytes_in), sum(bytes_out), sum(session_count), "
        f"max(active_users) FROM hotspot.traffic_hourly "
        f"WHERE {where} AND hour >= now() - INTERVAL {days} DAY",
        parameters=params,
    )

    srow = summary.first_row
    return {
        "hourly": [
            {"hour": r[0], "bytes_in": r[1], "bytes_out": r[2], "sessions": r[3], "active": r[4]}
            for r in hourly.result_rows
        ] if hourly.result_rows else [],
        "summary": {
            "total_bytes_in": int(srow[0]) if srow else 0,
            "total_bytes_out": int(srow[1]) if srow else 0,
            "total_sessions": int(srow[2]) if srow else 0,
            "peak_active": int(srow[3]) if srow else 0,
        } if srow else {},
    }


async def close() -> None:
    global _client
    if _client:
        _client.close()
        _client = None
