import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext
from app.modules.radius.vlan_service import build_user_group_key, build_vlan_avps
from app.modules.user_groups.models import UserGroup
from app.modules.user_groups.schemas import (
    UserGroupCreate,
    UserGroupPolicyOut,
    UserGroupPolicyPreviewOut,
    UserGroupUpdate,
)
from app.modules.auth.models import User


async def list_groups(db: AsyncSession, scope: ScopeContext) -> list[UserGroup]:
    q = select(UserGroup).where(
        UserGroup.customer_id == scope.customer_id,
        UserGroup.is_active,
    )
    if scope.location_id:
        q = q.where(
            (UserGroup.location_id == scope.location_id) | (UserGroup.location_id.is_(None))
        )
    q = q.order_by(UserGroup.priority.desc(), UserGroup.name)
    r = await db.execute(q)
    return list(r.scalars().all())


async def get_group(db: AsyncSession, group_id: uuid.UUID, scope: ScopeContext) -> UserGroup:
    q = select(UserGroup).where(
        UserGroup.id == group_id,
        UserGroup.customer_id == scope.customer_id,
        UserGroup.is_active,
    )
    r = await db.execute(q)
    g = r.scalar_one_or_none()
    if not g:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Grup bulunamadi")
    return g


async def create_group(
    db: AsyncSession, body: UserGroupCreate, scope: ScopeContext, user: User, request: Request
) -> UserGroup:
    if body.is_default:
        await _clear_default_flag(db, body.customer_id)
    g = UserGroup(
        customer_id=body.customer_id,
        location_id=body.location_id,
        name=body.name,
        description=body.description,
        bandwidth_up=body.bandwidth_up,
        bandwidth_down=body.bandwidth_down,
        session_timeout=body.session_timeout,
        idle_timeout=body.idle_timeout,
        daily_quota=body.daily_quota,
        weekly_quota=body.weekly_quota,
        monthly_quota=body.monthly_quota,
        hourly_quota=body.hourly_quota,
        max_sessions=body.max_sessions,
        access_start=body.access_start,
        access_end=body.access_end,
        is_default=body.is_default,
        priority=body.priority,
    )
    db.add(g)
    await db.flush()
    await db.commit()
    await db.refresh(g)
    return g


async def update_group(
    db: AsyncSession, group_id: uuid.UUID, body: UserGroupUpdate, scope: ScopeContext, user: User, request: Request
) -> UserGroup:
    g = await get_group(db, group_id, scope)
    if body.is_default is True:
        await _clear_default_flag(db, g.customer_id, exclude=group_id)
    upd = body.model_dump(exclude_unset=True)
    for k, v in upd.items():
        setattr(g, k, v)
    await db.commit()
    await db.refresh(g)
    return g


async def delete_group(
    db: AsyncSession, group_id: uuid.UUID, scope: ScopeContext, user: User, request: Request
) -> None:
    g = await get_group(db, group_id, scope)
    g.is_active = False
    await db.commit()


async def list_session_groups(
    db: AsyncSession,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
) -> list[UserGroup]:
    """Active policy groups eligible for guest sessions."""
    q = select(UserGroup).where(
        UserGroup.customer_id == customer_id,
        UserGroup.is_active,
    )
    if location_id:
        q = q.where(
            or_(
                UserGroup.location_id == location_id,
                UserGroup.location_id.is_(None),
            )
        )
    q = q.order_by(
        UserGroup.location_id.is_not(None).desc(),
        UserGroup.is_default.desc(),
        UserGroup.priority.desc(),
        UserGroup.created_at.desc(),
    )
    r = await db.execute(q)
    return list(r.scalars().all())


def _format_kbps(value: int | None) -> str:
    if value in (None, 0):
        return "limitsiz"
    if value >= 1000:
        return f"{value / 1000:.1f} Mbps"
    return f"{value} Kbps"


def _format_mb(value: int | None) -> str:
    if value in (None, 0):
        return "limitsiz"
    if value >= 1024:
        return f"{value / 1024:.1f} GB"
    return f"{value} MB"


def _format_duration(minutes: int | None) -> str:
    if not minutes:
        return "oturum süresiz"
    if minutes % 1440 == 0:
        days = minutes // 1440
        return f"{days} gün geçerli"
    if minutes % 60 == 0:
        hours = minutes // 60
        return f"{hours} saat geçerli"
    return f"{minutes} dk geçerli"


def _format_window(group: UserGroup) -> str:
    start = group.access_start.isoformat() if group.access_start else "baslangic yok"
    end = group.access_end.isoformat() if group.access_end else "bitis yok"
    if group.access_start or group.access_end:
        return f"{start} -> {end}"
    return "zaman penceresi yok"


def _policy_summary(group: UserGroup) -> str:
    scope = "lokasyon bazli" if group.location_id else "musteri geneli"
    limits = [
        f"yetki: {_format_duration(group.session_timeout)}",
        f"upload {_format_kbps(group.bandwidth_up)}",
        f"download {_format_kbps(group.bandwidth_down)}",
        f"eşzamanli {group.max_sessions} cihaz",
    ]
    if group.daily_quota or group.weekly_quota or group.monthly_quota or group.hourly_quota:
        limits.append(
            f"kota {_format_mb(group.daily_quota)} gunluk / {_format_mb(group.weekly_quota)} haftalik / {_format_mb(group.monthly_quota)} aylik"
        )
    if group.access_start or group.access_end:
        limits.append(_format_window(group))
    return f"{scope} · " + " · ".join(limits)


def _policy_notes(group: UserGroup) -> list[str]:
    notes = [
        "Bu grup captive portal doğrulamasında aktif grup olarak uygulanır.",
        f"Dinamik oturum yetkisi: {_format_duration(group.session_timeout)} (kullanıcı giriş anından itibaren başlar).",
    ]
    if group.location_id:
        notes.append("Lokasyon bazlidir; ayni musterinin genel grubunu ezer.")
    else:
        notes.append("Musteri geneli fallback olarak kullanilir.")
    if group.bandwidth_up or group.bandwidth_down:
        notes.append(
            f"Bant limiti: upload {_format_kbps(group.bandwidth_up)}, download {_format_kbps(group.bandwidth_down)}."
        )
    if group.daily_quota or group.weekly_quota or group.monthly_quota or group.hourly_quota:
        notes.append(
            f"Kota sinirlari: gunluk {_format_mb(group.daily_quota)}, haftalik {_format_mb(group.weekly_quota)}, aylik {_format_mb(group.monthly_quota)}."
        )
    notes.append(f"Eşzamanli cihaz limiti: {group.max_sessions}.")
    return notes


def pick_session_group(
    groups: list[UserGroup],
    now: datetime | None = None,
) -> UserGroup | None:
    """Return the first group whose access window allows the current time."""
    now = now or datetime.now(timezone.utc)
    for group in groups:
        if group.access_start and now < group.access_start:
            continue
        if group.access_end and now > group.access_end:
            continue
        return group
    return None


def build_group_policy(group: UserGroup) -> dict:
    access_start = group.access_start.isoformat() if group.access_start else None
    access_end = group.access_end.isoformat() if group.access_end else None
    max_sessions = group.max_sessions if group.max_sessions is not None else 1
    is_default = bool(group.is_default)
    priority = group.priority if group.priority is not None else 0
    radius_vlan_key = build_user_group_key(group.name, group.id) if group.vlan_id else None
    radius_avps = build_vlan_avps(group.vlan_id) if group.vlan_id else None
    return {
        "group_id": str(group.id),
        "group_name": group.name,
        "customer_id": str(group.customer_id),
        "location_id": str(group.location_id) if group.location_id else None,
        "scope": "location" if group.location_id else "customer",
        "scope_label": "Lokasyon bazli" if group.location_id else "Musteri geneli",
        "radius_vlan_key": radius_vlan_key,
        "radius_avps": radius_avps,
        "bandwidth_up": group.bandwidth_up,
        "bandwidth_down": group.bandwidth_down,
        "session_timeout": group.session_timeout,
        "idle_timeout": group.idle_timeout,
        "daily_quota": group.daily_quota,
        "weekly_quota": group.weekly_quota,
        "monthly_quota": group.monthly_quota,
        "hourly_quota": group.hourly_quota,
        "max_sessions": max_sessions,
        "vlan_id": group.vlan_id,
        "is_default": is_default,
        "priority": priority,
        "access_start": access_start,
        "access_end": access_end,
        "access_window": {
            "start": access_start,
            "end": access_end,
        },
        "policy_summary": _policy_summary(group),
        "enforcement_notes": _policy_notes(group),
    }


async def preview_captive_policy(
    db: AsyncSession,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    now: datetime | None = None,
) -> UserGroupPolicyPreviewOut:
    groups = await list_session_groups(db, customer_id, location_id)
    selected = pick_session_group(groups, now=now)
    candidate_policies = [
        UserGroupPolicyOut.model_validate(build_group_policy(group)) for group in groups
    ]
    selected_policy = (
        UserGroupPolicyOut.model_validate(build_group_policy(selected))
        if selected
        else None
    )

    if not groups:
        message = "Bu kapsamda user group tanimli degil; customer varsayilanlari uygulanir."
    elif not selected:
        message = "Bu saat araliginda aktif user group yok; captive flow 403 dondurur."
    else:
        message = f"Etkin policy {selected.name} grubu uzerinden uygulanir."

    return UserGroupPolicyPreviewOut(
        customer_id=customer_id,
        location_id=location_id,
        eligible_group_count=len(groups),
        selected_group=selected_policy,
        candidate_groups=candidate_policies,
        message=message,
    )


async def _clear_default_flag(db: AsyncSession, customer_id: uuid.UUID, exclude: uuid.UUID | None = None) -> None:
    q = select(UserGroup).where(
        UserGroup.customer_id == customer_id,
        UserGroup.is_default,
        UserGroup.is_active,
    )
    if exclude:
        q = q.where(UserGroup.id != exclude)
    r = await db.execute(q)
    for g in r.scalars().all():
        g.is_default = False
    await db.flush()
