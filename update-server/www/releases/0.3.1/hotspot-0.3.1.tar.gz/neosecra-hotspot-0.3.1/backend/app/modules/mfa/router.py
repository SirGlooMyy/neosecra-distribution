"""MFA HTTP endpoints."""
import uuid
import io
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.modules.auth.deps import get_current_user, require_permission
from app.modules.auth.models import User
from app.modules.mfa import (
    portal_service,
    rdp_service,
    service as mfa_service,
    vpn_service,
)

router = APIRouter()


async def _customer_for_mfa(db: AsyncSession, user: User) -> uuid.UUID:
    """Resolve the installation customer for global/super-admin users.

    VPN MFA is an installation capability, so a super-admin must be able to
    configure it even when the admin account itself has no customer_id.
    """
    cid = user.customer_id or await resolve_installation_customer(db)
    if not cid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Musteri baglantisi bulunamadi",
        )
    return cid


# ---- Schemas ----------------------------------------------------------------
class TotpSetupOut(BaseModel):
    secret: str
    qr_code_uri: str
    backup_codes: list[str]


class TotpVerifyIn(BaseModel):
    code: str = Field(..., min_length=4, max_length=10)


class MfaCodeSendIn(BaseModel):
    method: str = Field(..., pattern=r"^(sms|email|whatsapp)$")


class MfaCodeSendOut(BaseModel):
    session_token: str
    ttl_seconds: int


class MfaCodeVerifyIn(BaseModel):
    session_token: str
    code: str = Field(..., min_length=4, max_length=10)


class BackupCodeVerifyIn(BaseModel):
    code: str = Field(..., min_length=1)


class MfaStatusOut(BaseModel):
    mfa_required: bool
    methods: list[str]
    active_tokens: list[str]
    backup_codes_remaining: int


class RdpConfigIn(BaseModel):
    is_enabled: bool = True
    gateway_host: str | None = None
    gateway_port: int = 3391
    allowed_groups: list[str] = []
    mfa_method: str = "sms"


class VpnConfigIn(BaseModel):
    is_enabled: bool = True
    # Public address/port of the bundled Hotspot RADIUS listener.  The
    # gateway_* names are retained as a wire-compatibility alias for older
    # admin builds and are never shown as a VPN gateway setting.
    radius_listener_host: str | None = Field(default=None, max_length=255)
    radius_listener_port: int | None = Field(default=None, ge=1, le=65535)
    gateway_host: str | None = None
    # FreeRADIUS authentication listener (the FortiGate VPN gateway itself
    # stays on its own SSL-VPN/IPsec port).
    gateway_port: int = 1812
    radius_nas_ip: str | None = Field(default=None, max_length=64)
    radius_accounting_port: int = Field(default=1813, ge=1, le=65535)
    # Only accepted on writes; never returned by the API.
    radius_shared_secret: str | None = Field(default=None, min_length=4, max_length=512)
    allowed_groups: list[str] = []
    mfa_method: str = "totp"
    sms_template: str | None = Field(
        default=None,
        max_length=500,
        description="VPN SMS metni; {code} ve {username} yer tutucuları desteklenir.",
    )


class PortalConfigIn(BaseModel):
    is_enabled: bool = True
    mfa_method: str = "sms"
    require_mfa_after: str | None = None


class ConfigOut(BaseModel):
    id: str
    is_enabled: bool
    mfa_method: str
    extra: dict = {}


class VpnMfaUserCreateIn(BaseModel):
    username: str = Field(..., min_length=1, max_length=255)
    mfa_method: str = Field(default="totp", pattern=r"^(totp|sms|email)$")
    secret: str | None = None
    phone: str | None = None
    email: str | None = None


class VpnMfaUserOut(BaseModel):
    id: str
    username: str
    mfa_method: str
    phone: str | None = None
    email: str | None = None
    is_active: bool
    qr_code_uri: str | None = None
    qr_code_svg: str | None = None
    # Only populated on the one-time setup response; list calls keep it null.
    totp_secret: str | None = None


def _totp_uri(username: str, secret: str) -> str:
    label = quote(f"Hotspot VPN:{username}")
    issuer = quote("Hotspot VPN")
    return f"otpauth://totp/{label}?secret={quote(secret)}&issuer={issuer}&algorithm=SHA1&digits=6&period=30"


def _totp_qr_svg(uri: str) -> str | None:
    """Render a self-contained QR SVG without sending the secret elsewhere."""
    try:
        import qrcode
        from qrcode.image.svg import SvgPathImage
        image = qrcode.make(uri, image_factory=SvgPathImage)
        buf = io.BytesIO()
        image.save(buf)
        return buf.getvalue().decode("utf-8")
    except Exception:
        return None


def _request_host(request: Request | None) -> str | None:
    if not request:
        return None
    forwarded = request.headers.get("x-forwarded-host") or request.headers.get("host")
    if not forwarded:
        return request.url.hostname
    # X-Forwarded-Host may contain a comma-separated proxy chain and a port.
    host = forwarded.split(",", 1)[0].strip()
    if host.startswith("[") and "]" in host:
        return host[1:host.index("]")]
    return host.rsplit(":", 1)[0] if host.count(":") == 1 else host


def _vpn_config_payload(config, request: Request | None = None) -> dict:
    """Stable, secret-safe representation used by all VPN config responses."""
    # Older admin builds used this as a placeholder. Never surface it as a
    # real destination after the UI has been upgraded.
    configured_host = config.gateway_host if config.gateway_host not in ("radius.example.local", "") else None
    listener_host = configured_host or settings.RADIUS_LISTENER_HOST or _request_host(request)
    listener_port = config.gateway_port or settings.RADIUS_LISTENER_PORT
    return {
        "id": str(config.id),
        "customer_id": str(config.customer_id),
        "is_enabled": bool(config.is_enabled),
        "gateway_host": configured_host,
        "gateway_port": config.gateway_port,
        "radius_listener_host": listener_host,
        "radius_listener_port": listener_port,
        "radius_service": {
            "mode": "embedded",
            "service_name": settings.RADIUS_INTERNAL_HOST,
            "auth_port": settings.RADIUS_INTERNAL_PORT,
            "accounting_port": settings.RADIUS_LISTENER_ACCOUNTING_PORT,
        },
        "radius_nas_ip": config.radius_nas_ip,
        "radius_accounting_port": config.radius_accounting_port,
        "radius_secret_configured": bool(config.radius_shared_secret_encrypted),
        "radius_secret_updated_at": config.radius_secret_updated_at.isoformat() if config.radius_secret_updated_at else None,
        "allowed_groups": config.allowed_groups or [],
        "mfa_method": config.mfa_method,
        "sms_template": config.sms_template or "VPN giriş doğrulama kodunuz: {code}",
    }


# ---- Endpoints --------------------------------------------------------------

@router.get("/config", summary="Get compatibility MFA settings for the admin UI")
async def get_compat_mfa_config(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Return a stable user-level config shape for older admin clients.

    Customer-scoped RDP/portal settings remain available under their
    dedicated routes below. This endpoint prevents the legacy /mfa/config
    client call from being interpreted as DELETE /mfa/{method} (405).
    """
    current = await mfa_service.get_mfa_status(db, user.id)
    methods = current.get("methods", [])
    return {
        "default_method": methods[0] if methods else "totp",
        "enforce_for_admins": bool(current.get("mfa_required")),
        "enforce_for_portal": False,
        "backup_codes": [],
        "backup_codes_remaining": current.get("backup_codes_remaining", 0),
        "rdp_mfa_enabled": False,
        "vpn_mfa_enabled": False,
        "portal_mfa_enabled": False,
    }


@router.put("/config", summary="Update compatibility MFA settings for the admin UI")
async def update_compat_mfa_config(
    body: dict,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not has_permission(user.role, "system.write"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")
    if "enforce_for_admins" in body:
        user.mfa_required = bool(body["enforce_for_admins"])
        await db.commit()
    return body


@router.post("/regenerate-backup-codes", summary="Regenerate backup codes for the current user")
async def regenerate_backup_codes(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return {"codes": await mfa_service.generate_backup_codes(db, user.id)}

@router.get("/status", response_model=MfaStatusOut, summary="Get MFA status and configured methods for the current user", description="Returns the MFA configuration status including which methods are enabled, active tokens, and remaining backup codes. Requires a valid access token.")
async def mfa_status(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await mfa_service.get_mfa_status(db, user.id)


@router.post("/setup/totp", response_model=TotpSetupOut, summary="Set up TOTP authentication for the current user", description="Initializes TOTP setup by generating a secret, QR code URI, and backup codes. The user must scan the QR code with an authenticator app and verify with a code to activate. Requires a valid access token.")
async def setup_totp(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await mfa_service.setup_totp(db, user.id, request)


@router.post("/verify/totp", summary="Verify and activate TOTP with an authenticator code", description="Completes TOTP setup by verifying a code generated from the user's authenticator app. On success, TOTP is activated for the user's account. Requires a valid access token.")
async def verify_totp(
    body: TotpVerifyIn,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    ok = await mfa_service.activate_totp(db, user.id, body.code)
    return {"verified": ok}


@router.post("/send-code", response_model=MfaCodeSendOut, summary="Send an MFA verification code via SMS, email, or WhatsApp", description="Sends a one-time verification code to the user using the specified delivery method. Returns a session token for subsequent verification. Requires a valid access token.")
async def send_code(
    body: MfaCodeSendIn,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    session_token = await mfa_service.send_mfa_code(db, user.id, body.method, request)
    return MfaCodeSendOut(
        session_token=session_token,
        ttl_seconds=settings.MFA_CODE_TTL_SECONDS,
    )


@router.post("/verify-code", summary="Verify an MFA code sent via SMS, email, or WhatsApp", description="Validates a one-time code against the provided session token. Used to complete MFA verification for a login or sensitive action. Requires a valid access token.")
async def verify_code(
    body: MfaCodeVerifyIn,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    ok = await mfa_service.verify_mfa_code(db, body.session_token, body.code, request)
    return {"verified": ok}


@router.post("/verify-backup", summary="Verify a backup code for MFA recovery", description="Validates a backup code for the user. Backup codes are generated during TOTP setup and can be used when the primary MFA method is unavailable. Each backup code can only be used once. Requires a valid access token.")
async def verify_backup(
    body: BackupCodeVerifyIn,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    ok = await mfa_service.verify_backup_code(db, user.id, body.code, request)
    return {"verified": ok}


@router.delete("/{method}", status_code=204, summary="Disable a specific MFA method for the current user", description="Disables the specified MFA method (totp, sms, email, or whatsapp) for the authenticated user. Returns 204 No Content on success. Requires a valid access token.")
async def disable_mfa(
    method: str,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if method not in ("totp", "sms", "email", "whatsapp"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Gecersiz MFA yontemi: {method}",
        )
    await mfa_service.disable_mfa(db, user.id, method, request)


# ---- RDP MFA config ---------------------------------------------------------
@router.get("/rdp/config", summary="Get RDP MFA configuration for the customer", description="Returns the RDP gateway MFA configuration for the authenticated user's customer. Includes gateway host, port, allowed groups, and MFA method. Requires the mfa.rdp.read permission.")
async def get_rdp_config(
    user: User = Depends(require_permission("mfa.rdp.read")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await rdp_service.get_config(db, cid)
    if not config:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="RDP MFA yapilandirmasi bulunamadi")
    return config


@router.put("/rdp/config", summary="Update RDP MFA configuration for the customer", description="Creates or updates the RDP gateway MFA configuration. Supports settings for gateway host, port, allowed groups, and MFA method. Requires the mfa.rdp.write permission.")
async def update_rdp_config(
    body: RdpConfigIn,
    user: User = Depends(require_permission("mfa.rdp.write")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await rdp_service.get_config(db, cid)
    if config:
        return await rdp_service.update_config(db, cid, **body.model_dump())
    return await rdp_service.create_config(db, cid, **body.model_dump())


# ---- VPN MFA config ---------------------------------------------------------
@router.get("/vpn/config", summary="Get VPN MFA configuration for the customer", description="Returns the VPN MFA configuration and the bundled Hotspot RADIUS listener details. Requires the mfa.vpn.read permission.")
async def get_vpn_config(
    request: Request,
    user: User = Depends(require_permission("mfa.vpn.read")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await vpn_service.get_config(db, cid)
    if not config:
        # An unconfigured installation is a valid initial state. Returning a
        # stable, secret-safe payload lets the UI render the setup form without
        # treating the first visit as an application error.
        return {
            "id": None,
            "customer_id": str(cid),
            "is_enabled": False,
            "gateway_host": None,
            "gateway_port": settings.RADIUS_LISTENER_PORT,
            "radius_listener_host": settings.RADIUS_LISTENER_HOST or _request_host(request),
            "radius_listener_port": settings.RADIUS_LISTENER_PORT,
            "radius_service": {
                "mode": "embedded",
                "service_name": settings.RADIUS_INTERNAL_HOST,
                "auth_port": settings.RADIUS_INTERNAL_PORT,
                "accounting_port": settings.RADIUS_LISTENER_ACCOUNTING_PORT,
            },
            "radius_nas_ip": None,
            "radius_accounting_port": settings.RADIUS_LISTENER_ACCOUNTING_PORT,
            "radius_secret_configured": False,
            "radius_secret_updated_at": None,
            "allowed_groups": [],
            "mfa_method": "totp",
            "sms_template": "VPN giriş doğrulama kodunuz: {code}",
        }
    return _vpn_config_payload(config, request)


@router.put("/vpn/config", summary="Update VPN MFA configuration for the customer", description="Creates or updates VPN MFA and the FortiGate client settings. The RADIUS server itself is bundled with Hotspot; customers do not install FreeRADIUS. Requires the mfa.vpn.write permission.")
async def update_vpn_config(
    body: VpnConfigIn,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await vpn_service.get_config(db, cid)
    updates = body.model_dump()
    # New clients use the explicit listener names; old clients can continue
    # sending gateway_host/gateway_port without a migration.
    if body.radius_listener_host is not None:
        updates["gateway_host"] = body.radius_listener_host
    if body.radius_listener_port is not None:
        updates["gateway_port"] = body.radius_listener_port
    updates.pop("radius_listener_host", None)
    updates.pop("radius_listener_port", None)
    if config:
        updated = await vpn_service.update_config(db, cid, **updates)
        # The request-scoped AsyncSession is not auto-committed. Persist the
        # FortiGate/RADIUS settings before returning so a page refresh (and the
        # captive portal flow) sees the same configuration.
        await db.commit()
        from app.modules.radius.runtime import sync_runtime_clients
        await sync_runtime_clients(db)
        return _vpn_config_payload(updated)
    created = await vpn_service.create_config(db, cid, **updates)
    await db.commit()
    from app.modules.radius.runtime import sync_runtime_clients
    await sync_runtime_clients(db)
    return _vpn_config_payload(created)


@router.post("/vpn/test-radius", summary="Test the configured FreeRADIUS listener used by FortiGate")
async def test_vpn_radius(
    request: Request,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    """Test the saved listener; no caller-supplied destination is accepted."""
    from app.core.crypto import decrypt
    from app.modules.radius.service import test_radius_connection

    cid = await _customer_for_mfa(db, user)
    config = await vpn_service.get_config(db, cid)
    if not config or not config.radius_shared_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Önce FortiGate NAS IP ve shared secret kaydedin")
    try:
        secret = decrypt(config.radius_shared_secret_encrypted)
    except Exception:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="RADIUS shared secret çözülemedi")
    # The listener is bundled with this installation. Test it over the
    # internal Docker network; the public host/port is only for FortiGate.
    internal_host = settings.RADIUS_INTERNAL_HOST
    internal_port = settings.RADIUS_INTERNAL_PORT
    ok = await test_radius_connection(internal_host, secret, port=internal_port)
    return {
        "ok": bool(ok),
        "message": "Dahili RADIUS yanıt verdi." if ok else "Dahili RADIUS yanıt vermedi; servis ve shared secret'ı kontrol edin.",
        "host": settings.RADIUS_LISTENER_HOST or _request_host(request),
        "port": config.gateway_port or settings.RADIUS_LISTENER_PORT,
        "service": internal_host,
    }


# ---- VPN MFA per-user registration ------------------------------------------

@router.get("/vpn/users", response_model=list[VpnMfaUserOut], summary="List VPN MFA registered users for the customer", description="Returns all active VPN MFA users registered for the authenticated user's customer. Includes username, MFA method, and contact information. Requires the mfa.vpn.read permission.")
async def list_vpn_mfa_users(
    user: User = Depends(require_permission("mfa.vpn.read")),
    db: AsyncSession = Depends(get_db),
):
    from app.modules.mfa.models import VpnMfaUser

    cid = await _customer_for_mfa(db, user)
    rows = (await db.execute(
        select(VpnMfaUser).where(
            VpnMfaUser.customer_id == cid,
            VpnMfaUser.is_active.is_(True),
        ).order_by(VpnMfaUser.username)
    )).scalars().all()
    return [
        VpnMfaUserOut(
            id=str(r.id),
            username=r.username,
            mfa_method=r.mfa_method,
            phone=r.phone,
            email=r.email,
            is_active=r.is_active,
        )
        for r in rows
    ]


@router.post("/vpn/users", response_model=VpnMfaUserOut, status_code=status.HTTP_201_CREATED, summary="Register a new VPN MFA user", description="Creates a new VPN MFA user registration with the specified username, MFA method, and optional contact details. The user's secret is encrypted before storage. Requires the mfa.vpn.write permission.")
async def create_vpn_mfa_user(
    body: VpnMfaUserCreateIn,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    from app.modules.mfa.models import VpnMfaUser
    from app.core.crypto import encrypt

    cid = await _customer_for_mfa(db, user)
    existing = (await db.execute(
        select(VpnMfaUser).where(
            VpnMfaUser.customer_id == cid,
            VpnMfaUser.username == body.username,
        )
    )).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Bu kullanici zaten kayitli")
    setup_secret = None
    if body.mfa_method == "totp":
        if body.secret:
            setup_secret = body.secret.strip().replace(" ", "").upper()
        else:
            import pyotp
            setup_secret = pyotp.random_base32()
    record = VpnMfaUser(
        customer_id=cid,
        username=body.username,
        mfa_method=body.mfa_method,
        secret_encrypted=encrypt(setup_secret) if setup_secret else None,
        phone=body.phone,
        email=body.email,
    )
    db.add(record)
    await db.flush()
    await db.refresh(record)
    await db.commit()
    return VpnMfaUserOut(
        id=str(record.id),
        username=record.username,
        mfa_method=record.mfa_method,
        phone=record.phone,
        email=record.email,
        is_active=record.is_active,
        qr_code_uri=_totp_uri(record.username, setup_secret) if setup_secret else None,
        qr_code_svg=_totp_qr_svg(_totp_uri(record.username, setup_secret)) if setup_secret else None,
        totp_secret=setup_secret,
    )


@router.post("/vpn/users/{user_id}/totp-setup", response_model=VpnMfaUserOut, summary="Generate a new TOTP QR setup for a VPN user")
async def setup_vpn_totp(
    user_id: uuid.UUID,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    """Rotate a VPN user's TOTP secret and return the QR URI once."""
    from app.core.crypto import encrypt
    from app.modules.mfa.models import VpnMfaUser
    import pyotp

    cid = await _customer_for_mfa(db, user)
    record = (
        await db.execute(
            select(VpnMfaUser).where(
                VpnMfaUser.id == user_id,
                VpnMfaUser.customer_id == cid,
                VpnMfaUser.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kullanici bulunamadi")
    if record.mfa_method != "totp":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Bu kullanici TOTP kullanmiyor")
    secret = pyotp.random_base32()
    record.secret_encrypted = encrypt(secret)
    await db.commit()
    return VpnMfaUserOut(
        id=str(record.id), username=record.username, mfa_method=record.mfa_method,
        phone=record.phone, email=record.email, is_active=record.is_active,
        qr_code_uri=_totp_uri(record.username, secret), totp_secret=secret,
        qr_code_svg=_totp_qr_svg(_totp_uri(record.username, secret)),
    )


@router.delete("/vpn/users/{user_id}", status_code=204, summary="Deactivate a VPN MFA user registration", description="Deletes the specified VPN MFA user registration. Requires the mfa.vpn.write permission.")
async def delete_vpn_mfa_user(
    user_id: uuid.UUID,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    from app.modules.mfa.models import VpnMfaUser

    record = await db.get(VpnMfaUser, user_id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kullanici bulunamadi")
    await db.delete(record)
    await db.commit()


@router.post("/vpn/generate-config", summary="Generate FreeRADIUS config snippet for VPN MFA", description="Generates a FreeRADIUS configuration snippet for VPN MFA integration based on the customer's current VPN MFA settings. The output is ready to be included in FreeRADIUS configuration files. Requires the mfa.vpn.write permission.")
async def generate_vpn_mfa_config(
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await vpn_service.get_config(db, cid)
    if not config:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="VPN MFA yapilandirmasi bulunamadi")
    snippet = vpn_service.generate_radius_config_for_vpn_mfa(config)
    return {"config": snippet, "customer_id": str(cid)}


# ---- Portal MFA config ------------------------------------------------------
@router.get("/portal/config", summary="Get portal MFA configuration for the customer", description="Returns the captive portal MFA configuration for the authenticated user's customer. Includes enabled status, MFA method, and conditional MFA rules. Requires the mfa.portal.read permission.")
async def get_portal_config(
    user: User = Depends(require_permission("mfa.portal.read")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await portal_service.get_portal_config(db, cid)
    if not config:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Portal MFA yapilandirmasi bulunamadi")
    return config


@router.put("/portal/config", summary="Update portal MFA configuration for the customer", description="Creates or updates the captive portal MFA configuration. Supports settings for MFA method and conditional MFA rules. Requires the mfa.portal.write permission.")
async def update_portal_config(
    body: PortalConfigIn,
    user: User = Depends(require_permission("mfa.portal.write")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await portal_service.get_portal_config(db, cid)
    if config:
        return await portal_service.update_portal_config(db, config.id, **body.model_dump())
    return await portal_service.create_portal_config(db, cid, **body.model_dump())
