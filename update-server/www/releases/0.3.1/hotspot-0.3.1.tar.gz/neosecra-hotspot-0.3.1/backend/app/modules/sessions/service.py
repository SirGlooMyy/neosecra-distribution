"""Guest session service: creation (public captive flow), scoped admin
list/get and close.

create_session is a PUBLIC-flow helper (no admin JWT) — the caller resolves
customer_id/location_id/device_id from the device the guest is behind and
passes them in explicitly (Mutlak Kural #1/#2 — tenant isolation extends to
the guest auth path). Admin views are scope-filtered on the customer (->
partner) axis with an extra LOCATION filter on the denormalized location_id,
mirroring vouchers/identity. Fail-closed for any scoped role with no
assignment.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import inspect
import logging
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import false, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.sessions.models import (
    STATUS_ACTIVE,
    STATUS_PENDING,
    STATUS_CLOSED,
    STATUS_EXPIRED,
    GuestSession,
    AUTH_STATUS_AUTHORIZED,
    AUTH_STATUS_FAILED,
    AUTH_STATUS_REVOKED,
)

log = logging.getLogger(__name__)


# ---- scoped query (customer -> partner axis, mirrors vouchers/identity) --
async def _scoped_query_async(db: AsyncSession, scope: ScopeContext):
    """Scope query on GuestSession (customer axis). LOCATION level filters on
    the denormalized location_id directly (no customer join needed). Fail-closed
    for a scoped role with no assignment."""
    q = select(GuestSession)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = q.join(Customer, GuestSession.customer_id == Customer.id)
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(GuestSession.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        return q.where(GuestSession.location_id == scope.location_id), True
    return q.where(false()), False


# ---- public-flow create (no admin JWT) -----------------------------------
async def create_session(
    db: AsyncSession,
    *,
    session_id: uuid.UUID | None = None,
    customer_id: uuid.UUID,
    mac: str,
    auth_method: str,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    identity_verification_id: uuid.UUID | None = None,
    voucher_id: uuid.UUID | None = None,
    group_id: uuid.UUID | None = None,
    phone: str | None = None,
    ip: str | None = None,
    nas_ip: str | None = None,
    ssid: str | None = None,
    duration_minutes: int | None = None,
    authorize_ok: bool = True,
    authorize_message: str | None = None,
    status: str = STATUS_ACTIVE,
    meta: dict | None = None,
    request: Request | None = None,
    # KVKK / Consent (HS-MVP-SLICE-01)
    terms_accepted: bool = False,
    privacy_accepted: bool = False,
    terms_version: str | None = None,
    privacy_version: str | None = None,
    consent_ip: str | None = None,
    consent_user_agent: str | None = None,
) -> GuestSession:
    """Create an authorized guest internet session. Called by the PUBLIC
    captive flow after portal-token validation + firewall authorize. Caller
    passes the resolved site context explicitly.

    flush -> log_audit -> commit -> refresh, mirroring vouchers/identity.
    """
    now = datetime.now(timezone.utc)
    started_at = now
    expires_at = now + timedelta(minutes=duration_minutes) if duration_minutes else None

    mac = (mac or "").strip().upper()
    ip = (ip or "").strip() or None

    # A reconnect from the same client must replace the previous open
    # session. Otherwise a brief Wi-Fi roam leaves multiple rows marked
    # active and the concurrency limit rejects the legitimate reconnect.
    identity_conditions = []
    if mac:
        identity_conditions.append(GuestSession.mac == mac)
    if ip:
        identity_conditions.append(GuestSession.ip == ip)
    if identity_conditions:
        previous_result = await db.execute(
            select(GuestSession)
            .where(
                GuestSession.customer_id == customer_id,
                GuestSession.status.in_((STATUS_ACTIVE, STATUS_PENDING)),
                or_(*identity_conditions),
            )
            .with_for_update()
        )
        previous_scalars = previous_result.scalars()
        if inspect.isawaitable(previous_scalars):
            previous_scalars = await previous_scalars
        previous_rows = previous_scalars.all()
        if inspect.isawaitable(previous_rows):
            previous_rows = await previous_rows
        if isinstance(previous_rows, (list, tuple)):
            for previous in previous_rows:
                previous.status = STATUS_CLOSED
                previous.ended_at = now
                previous.authorization_status = AUTH_STATUS_REVOKED
                previous.revoked_at = now

    # Never expose a session as active before the firewall has confirmed the
    # authorization.  A failed device call remains pending so an operator can
    # retry synchronization, but it must not count as an online guest.
    effective_status = status if authorize_ok else STATUS_PENDING

    session = GuestSession(
        id=session_id or uuid.uuid4(),
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        identity_verification_id=identity_verification_id,
        voucher_id=voucher_id,
        group_id=group_id,
        phone=phone,
        mac=mac,
        ip=ip,
        nas_ip=nas_ip,
        ssid=ssid,
        auth_method=auth_method,
        status=effective_status,
        started_at=started_at,
        expires_at=expires_at,
        authorize_ok=authorize_ok,
        authorize_message=authorize_message,
        meta=meta or {},
        terms_accepted=terms_accepted,
        terms_accepted_at=now if terms_accepted else None,
        privacy_accepted=privacy_accepted,
        privacy_accepted_at=now if privacy_accepted else None,
        terms_version=terms_version,
        privacy_version=privacy_version,
        consent_ip=consent_ip,
        consent_user_agent=consent_user_agent,
    )
    db.add(session)
    await db.flush()
    await log_audit(
        db,
        "session.created",
        "guest_session",
        str(session.id),
        None,
        request,
        details={
            "customer_id": str(customer_id),
            "mac": mac,
            "auth_method": auth_method,
            "status": status,
            "meta": meta or {},
        },
    )
    await db.commit()
    await db.refresh(session)
    return session


async def count_active_sessions_for_identity(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    phone: str | None = None,
    mac: str | None = None,
) -> int:
    """Count active sessions for the same user identity.

    The portal flow uses this to enforce user-group concurrency caps before
    authorizing a new guest session.
    """
    now = datetime.now(timezone.utc)
    filters = [
        GuestSession.customer_id == customer_id,
        GuestSession.status == STATUS_ACTIVE,
        GuestSession.ended_at.is_(None),
        or_(GuestSession.expires_at.is_(None), GuestSession.expires_at > now),
    ]
    identity_filters = []
    if phone:
        identity_filters.append(GuestSession.phone == phone)
    if mac:
        identity_filters.append(GuestSession.mac == mac.strip().upper())
    if not identity_filters:
        return 0
    stmt = select(func.count()).select_from(GuestSession).where(*filters, or_(*identity_filters))
    result = await db.execute(stmt)
    return int(result.scalar_one() or 0)


# ---- scoped admin views --------------------------------------------------
async def get_session(
    db: AsyncSession, session_id: uuid.UUID, scope: ScopeContext
) -> GuestSession:
    q, allowed = await _scoped_query_async(db, scope)
    result = await db.execute(q.where(GuestSession.id == session_id))
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Oturum bulunamadi",
        )
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu oturuma erisim yetkiniz yok",
        )
    return session


async def list_pending_sessions(
    db: AsyncSession, scope: ScopeContext
) -> list[GuestSession]:
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        return []
    q = q.where(GuestSession.status == STATUS_PENDING)
    result = await db.execute(q.order_by(GuestSession.started_at.desc()))
    return list(result.scalars().all())


async def approve_session(
    db: AsyncSession,
    session_id: uuid.UUID,
    scope: ScopeContext,
    actor_id: uuid.UUID | None = None,
    request: Request | None = None,
) -> GuestSession:
    session = await get_session(db, session_id, scope)
    if session.status != STATUS_PENDING:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Oturum onay bekliyor durumunda degil",
        )
    if not session.device_id:
        raise HTTPException(status_code=409, detail="Oturumun bağlı olduğu güvenlik duvarı bulunamadı")

    # Approval is the gate before network access.  The firewall call is made
    # here (not when the guest submits the portal form), so a pending request
    # can never accidentally receive internet access.
    from app.modules.firewall_adapters.service import authorize_guest_service
    flow_scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=session.customer_id)
    session_payload = {
        "session_id": str(session.id),
        "mac": session.mac,
        "ip": session.ip,
        "username": session.phone or session.mac or "guest",
        "duration_minutes": max(1, int((session.expires_at - session.started_at).total_seconds() / 60)) if session.expires_at and session.started_at else None,
    }
    group_policy = (session.meta or {}).get("group_policy")
    if isinstance(group_policy, dict):
        session_payload.update(group_policy)
    result = await authorize_guest_service(db, session.device_id, flow_scope, session_payload)
    if not result.ok:
        session.authorize_ok = False
        session.authorization_status = AUTH_STATUS_FAILED
        session.authorization_attempts = (session.authorization_attempts or 0) + 1
        session.authorization_error_message = result.message
        await db.commit()
        raise HTTPException(status_code=502, detail=result.message or "Güvenlik duvarı erişimi açılamadı")

    now = datetime.now(timezone.utc)
    session.status = STATUS_ACTIVE
    session.authorize_ok = True
    session.authorize_message = "Yönetici tarafından onaylandı"
    session.authorization_status = AUTH_STATUS_AUTHORIZED
    session.authorized_at = now
    session.authorization_attempts = (session.authorization_attempts or 0) + 1
    session.external_session_id = session.external_session_id or str(session.id)
    meta = dict(session.meta or {})
    approval = dict(meta.get("approval") or {})
    approval.update({
        "status": "approved",
        "approved_at": now.isoformat(),
        "approved_by": str(actor_id) if actor_id else None,
    })
    approval.pop("token_hash", None)
    meta["approval"] = approval
    session.meta = meta
    await db.flush()
    await log_audit(
        db,
        "session.approved",
        "guest_session",
        str(session_id),
        str(actor_id) if actor_id else None,
        request,
    )
    await db.commit()
    await db.refresh(session)
    return session


async def reject_session(
    db: AsyncSession,
    session_id: uuid.UUID,
    scope: ScopeContext,
    actor_id: uuid.UUID | None = None,
    request: Request | None = None,
) -> GuestSession:
    session = await get_session(db, session_id, scope)
    if session.status != STATUS_PENDING:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Oturum onay bekliyor durumunda degil",
        )
    session.status = STATUS_CLOSED
    now = datetime.now(timezone.utc)
    session.ended_at = now
    meta = dict(session.meta or {})
    approval = dict(meta.get("approval") or {})
    approval.update({
        "status": "rejected",
        "rejected_at": now.isoformat(),
        "rejected_by": str(actor_id) if actor_id else None,
    })
    approval.pop("token_hash", None)
    meta["approval"] = approval
    session.meta = meta
    await db.flush()
    await log_audit(
        db,
        "session.rejected",
        "guest_session",
        str(session_id),
        str(actor_id) if actor_id else None,
        request,
    )
    await db.commit()
    await db.refresh(session)
    return session


async def approve_session_by_token(
    db: AsyncSession,
    session_id: uuid.UUID,
    token: str,
    *,
    decision: str = "approve",
    request: Request | None = None,
) -> GuestSession:
    """Process a one-time manager e-mail decision without an admin JWT.

    The token is stored only as a SHA-256 digest in the session metadata and
    is removed after the decision, making e-mail links single-use.
    """
    session = await db.get(GuestSession, session_id)
    if not session or session.status != STATUS_PENDING:
        raise HTTPException(status_code=404, detail="Onay bekleyen oturum bulunamadı")
    approval = (session.meta or {}).get("approval") or {}
    digest = hashlib.sha256(token.encode("utf-8")).hexdigest()
    if not approval.get("token_hash") or not hmac.compare_digest(str(approval.get("token_hash")), digest):
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    expires_at = approval.get("token_expires_at")
    if expires_at:
        try:
            if datetime.fromisoformat(str(expires_at)) < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Onay bağlantısının süresi doldu")
        except ValueError:
            raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    if decision.lower() in {"reject", "rejected", "red"}:
        return await reject_session(db, session.id, ScopeContext(level=TenantLevel.CUSTOMER, customer_id=session.customer_id), None, request)
    return await approve_session(db, session.id, ScopeContext(level=TenantLevel.CUSTOMER, customer_id=session.customer_id), None, request)


async def list_online_sessions(
    db: AsyncSession, scope: ScopeContext
) -> list[GuestSession]:
    """List only truly active online guest sessions.
    
    1. Sweeps and closes expired sessions (leases past expires_at).
    2. Validates ended_at IS NULL and expires_at > now.
    3. Correlates live network traffic from FirewallLog to verify transmitting vs idle state.
    """
    now = datetime.now(timezone.utc)
    
    # 1. Sweep expired active sessions in background
    try:
        expired_stmt = (
            select(GuestSession)
            .where(
                GuestSession.status == STATUS_ACTIVE,
                or_(
                    and_(GuestSession.expires_at.is_not(None), GuestSession.expires_at <= now),
                    and_(GuestSession.expires_at.is_(None), GuestSession.started_at < now - timedelta(hours=24)),
                )
            )
        )
        expired_sessions = (await db.execute(expired_stmt)).scalars().all()
        for s in expired_sessions:
            s.status = STATUS_CLOSED
            s.ended_at = s.expires_at or now
        if expired_sessions:
            await db.commit()
    except Exception as e:
        log.warning("Session auto-sweep error: %s", e)

    # 2. Query scoped active sessions
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        return []
    q = q.where(
        GuestSession.status == STATUS_ACTIVE,
        GuestSession.ended_at.is_(None),
        or_(GuestSession.expires_at.is_(None), GuestSession.expires_at > now),
    )
    result = await db.execute(q.order_by(GuestSession.started_at.desc()))
    sessions = list(result.scalars().all())

    # 3. Live traffic & telemetry correlation
    try:
        from app.modules.syslog.models import FirewallLog

        for session in sessions:
            meta = dict(session.meta or {})
            traffic_status = "transmitting"
            last_seen = session.started_at
            total_bytes = int(session.bytes_in or 0) + int(session.bytes_out or 0)

            if session.ip:
                log_stmt = (
                    select(FirewallLog.effective_event_time, FirewallLog.rcvdbyte, FirewallLog.sentbyte)
                    .where(
                        FirewallLog.src_ip == session.ip,
                        FirewallLog.effective_event_time >= now - timedelta(hours=2),
                    )
                    .order_by(FirewallLog.effective_event_time.desc())
                    .limit(1)
                )
                last_log = (await db.execute(log_stmt)).first()
                if last_log:
                    last_seen = last_log[0]
                    diff_min = (now - last_seen).total_seconds() / 60.0
                    if diff_min <= 15:
                        traffic_status = "transmitting"  # 🟢 Aktif İletişimde
                    elif diff_min <= 60:
                        traffic_status = "idle"          # 🟡 Boşta / Uyku Modu
                    else:
                        traffic_status = "inactive"      # ⚪ Sinyal Yok
                else:
                    diff_start = (now - session.started_at).total_seconds() / 60.0
                    if diff_start > 30:
                        traffic_status = "idle"

            meta["live_telemetry"] = {
                "traffic_status": traffic_status,
                "last_seen": last_seen.isoformat() if last_seen else None,
                "is_active_transmitting": traffic_status == "transmitting",
                "total_bytes": total_bytes,
            }
            session.meta = meta
    except Exception as e:
        log.warning("Live telemetry correlation error: %s", e)

    return sessions


async def list_sessions(
    db: AsyncSession, scope: ScopeContext
) -> list[GuestSession]:
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        return []
    result = await db.execute(q.order_by(GuestSession.started_at.desc()))
    return list(result.scalars().all())


async def _revoke_on_firewall_background(
    session_id: uuid.UUID,
    device_id: uuid.UUID,
    ip: str | None,
    mac: str,
    scope: ScopeContext,
) -> None:
    """Fire-and-forget firewall revoke. Runs in a background task so the
    API response is not blocked by a slow/unreachable firewall."""
    try:
        from app.modules.firewall_adapters.service import revoke_guest_service
        from app.core.database import AsyncSessionLocal

        async with AsyncSessionLocal() as db:
            session = await db.get(GuestSession, session_id)
            group_name = "Guest"
            if session and isinstance(session.meta, dict):
                group_name = (session.meta.get("group_policy") or {}).get("group_name") or "Guest"
            await revoke_guest_service(
                db, device_id, scope,
                {"session_id": str(session_id), "ip": ip, "mac": mac, "group_name": group_name},
            )
            if session:
                session.authorization_status = AUTH_STATUS_REVOKED
                session.revoked_at = datetime.now(timezone.utc)
                session.authorize_ok = False
                session.is_active = False
                await db.commit()
    except Exception:
        log.warning("bg firewall revoke failed for session=%s", session_id, exc_info=True)


async def _disconnect_radius_background(
    session_id: uuid.UUID,
    location_id: uuid.UUID | None,
    nas_ip: str | None,
    radius_session_id: str | None,
    username: str | None,
    mac: str | None,
    user_ip: str | None,
) -> None:
    """Send RFC 5176 Disconnect-Request after a session is closed.

    The NAS secret is decrypted only inside this short-lived worker session;
    it is never returned to the API or written to logs. Missing RADIUS
    metadata is a valid deployment mode and simply skips the best-effort
    packet.
    """
    if not location_id or not nas_ip:
        return
    try:
        from app.core.crypto import decrypt
        from app.core.database import AsyncSessionLocal
        from app.modules.devices.models import RadiusClient
        from app.modules.radius.coa import send_coa_disconnect

        async with AsyncSessionLocal() as radius_db:
            client = (await radius_db.execute(
                select(RadiusClient).where(
                    RadiusClient.location_id == location_id,
                    RadiusClient.nas_ip == nas_ip,
                    RadiusClient.is_active.is_(True),
                ).limit(1)
            )).scalar_one_or_none()
            if not client:
                return
            secret = decrypt(client.shared_secret_encrypted)
        result = await send_coa_disconnect(
            nas_ip,
            secret,
            username=username,
            session_id=radius_session_id,
            user_ip=user_ip,
            mac_address=mac,
        )
        if not result.get("ok"):
            log.warning("RADIUS Disconnect-Request failed for session=%s: %s", session_id, result.get("message"))
    except Exception:
        log.warning("bg RADIUS disconnect failed for session=%s", session_id, exc_info=True)


async def close_session(
    db: AsyncSession,
    session_id: uuid.UUID,
    scope: ScopeContext,
    actor_id: uuid.UUID | None = None,
    request: Request | None = None,
    reason: str | None = None,
) -> GuestSession:
    """Close a guest session idempotently. Repeating the action for an
    already-closed session returns the existing row instead of surfacing a
    noisy 409 to the dashboard. On close:
      - duration computed from started_at -> ended_at
      - firewall revoke fired as background task
      - 5651 session summary audit event appended (append-only, not UPDATE)
    """
    session = await get_session(db, session_id, scope)
    if session.status == STATUS_CLOSED:
        return session
    now = datetime.now(timezone.utc)
    session.status = STATUS_CLOSED
    session.is_active = False
    session.authorize_ok = False
    session.authorization_status = AUTH_STATUS_REVOKED
    session.revoked_at = now
    session.ended_at = now
    if session.started_at:
        duration_sec = int((now - session.started_at).total_seconds())
    else:
        duration_sec = 0
    await db.flush()
    await log_audit(
        db,
        "session.closed",
        "guest_session",
        str(session_id),
        str(actor_id) if actor_id else None,
        request,
        details={"reason": reason, "duration_sec": duration_sec},
    )
    await log_audit(
        db,
        "5651.session_summary",
        "guest_session",
        str(session_id),
        str(actor_id) if actor_id else None,
        request,
        details={
            "reason": reason,
            "duration_sec": duration_sec,
            "bytes_in": session.bytes_in,
            "bytes_out": session.bytes_out,
            "mac": session.mac,
            "ip": session.ip,
            "phone": session.phone,
            "auth_method": session.auth_method,
            "started_at": session.started_at.isoformat() if session.started_at else None,
            "ended_at": now.isoformat(),
        },
    )
    await db.commit()
    await db.refresh(session)
    if session.device_id:
        asyncio.create_task(
            _revoke_on_firewall_background(
                session.id, session.device_id, session.ip, session.mac, scope,
            )
        )
    if session.nas_ip and session.location_id:
        asyncio.create_task(
            _disconnect_radius_background(
                session.id,
                session.location_id,
                session.nas_ip,
                session.radius_session_id,
                session.phone,
                session.mac,
                session.ip,
            )
        )
    return session


# ---- M5 expiry sweep (called by the worker scheduler) ---------------------
async def expire_due(db: AsyncSession, request: Request | None = None) -> int:
    """Flip active sessions past their expires_at to STATUS_EXPIRED.

    Mutlak Kural #5 — sessions are NOT deleted; they are marked expired so the
    correlation chain (5651 archive, RADIUS, syslog) stays intact. Returns the
    count flipped. Called by the Celery beat worker (M6)."""
    now = datetime.now(timezone.utc)
    res = await db.execute(
        select(GuestSession).where(
            GuestSession.status == STATUS_ACTIVE,
            GuestSession.expires_at.is_not(None),
            GuestSession.expires_at < now,
        )
    )
    due = list(res.scalars().all())
    for s in due:
        s.status = STATUS_EXPIRED
        s.ended_at = s.ended_at or now
    if due:
        await log_audit(
            db,
            "session.expired_batch",
            "guest_session",
            None,
            None,
            request,
            details={"count": len(due)},
        )
        await db.commit()
    return len(due)
