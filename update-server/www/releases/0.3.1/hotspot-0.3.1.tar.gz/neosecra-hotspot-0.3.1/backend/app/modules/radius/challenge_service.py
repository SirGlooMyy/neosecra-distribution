"""RADIUS Access-Challenge state machine for VPN MFA.

FreeRADIUS calls this service via its `rest` module during the
authorize/authenticate phases.  The flow:

  1. FreeRADIUS calls init_challenge → we return a State + Reply-Message.
  2. FreeRADIUS sends Access-Challenge to the NAS.
  3. User provides the MFA code.
  4. FreeRADIUS calls verify_challenge → we validate the code.
  5. FreeRADIUS sends Access-Accept / Access-Reject.
"""
from __future__ import annotations

import logging
import hashlib
import hmac
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.mfa.models import VpnMfaConfig, VpnMfaUser
from app.modules.radius.models import RadiusChallenge

log = logging.getLogger(__name__)

CHALLENGE_TTL_SECONDS = 300
MAX_ATTEMPTS = 3


async def _vpn_sms_message(
    db: AsyncSession, customer_id: uuid.UUID, username: str, code: str
) -> str:
    config = (
        await db.execute(
            select(VpnMfaConfig).where(VpnMfaConfig.customer_id == customer_id)
        )
    ).scalar_one_or_none()
    template = (getattr(config, "sms_template", None) if config else None) or "VPN giriş doğrulama kodunuz: {code}"
    try:
        message = template.format(code=code, username=username)
    except (KeyError, IndexError, ValueError):
        message = f"VPN giriş doğrulama kodunuz: {code}"
    return message[:500]


async def _lookup_vpn_user(
    db: AsyncSession,
    customer_id: uuid.UUID | None,
    username: str,
) -> VpnMfaUser | None:
    q = select(VpnMfaUser).where(
        VpnMfaUser.username == username,
        VpnMfaUser.is_active.is_(True),
    )
    if customer_id is not None:
        q = q.where(VpnMfaUser.customer_id == customer_id)
    return (await db.execute(q)).scalar_one_or_none()


async def init_challenge(
    db: AsyncSession,
    customer_id: uuid.UUID | None,
    username: str,
    nas_ip: str | None = None,
) -> dict:
    """Initiate a RADIUS Access-Challenge for VPN MFA.

    Looks up the user's MFA registration, creates a challenge session,
    and returns the State attribute value for FreeRADIUS.
    If customer_id is None, derives it from the VpnMfaUser record.

    Returns:
        dict with keys: challenge_required (bool), state (str | None),
                        reply_message (str), mfa_method (str | None)
    """
    vpn_user = await _lookup_vpn_user(db, customer_id, username)
    if not vpn_user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No MFA config")

    cid = customer_id or vpn_user.customer_id
    state = secrets.token_urlsafe(32)
    method = vpn_user.mfa_method
    code_hash: str | None = None

    if method == "totp":
        # TOTP does not need a delivery code; validation is done server-side
        challenge = RadiusChallenge(
            customer_id=cid,
            username=username,
            nas_ip=nas_ip,
            state=state,
            mfa_method="totp",
            code_hash=None,
            session_token=None,
            verified=False,
            expires_at=datetime.now(timezone.utc) + timedelta(seconds=CHALLENGE_TTL_SECONDS),
        )
        reply_msg = "TOTP dogrulama kodu girin"

    elif method in ("sms", "email", "whatsapp"):
        code = secrets.token_hex(3)
        import hashlib
        code_hash = hashlib.sha256(code.encode()).hexdigest()

        if method == "sms":
            if vpn_user and vpn_user.phone:
                from app.modules.sms.service import send_custom_sms
                delivered, err = await send_custom_sms(
                    phone=vpn_user.phone,
                    message=await _vpn_sms_message(db, cid, username, code),
                    db=db,
                    customer_id=cid,
                )
                if not delivered:
                    if settings.DEMO_MODE:
                        log.warning("VPN MFA SMS demo fallback: %s code=%s", err, code)
                    else:
                        raise HTTPException(
                            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                            detail="VPN MFA SMS teslimati basarisiz",
                        )
                elif settings.DEMO_MODE:
                    log.info("VPN MFA SMS -> %s code=%s", vpn_user.phone, code)
                else:
                    log.info("VPN MFA SMS teslim edildi: %s", vpn_user.phone)
            else:
                if settings.DEMO_MODE:
                    log.info("VPN MFA SMS (no phone on record, demo) code=%s", code)
                else:
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                        detail="VPN MFA SMS icin telefon numarasi bulunamadi",
                    )
        elif method == "email":
            to = vpn_user.email if vpn_user and vpn_user.email else "unknown"
            if vpn_user and vpn_user.email:
                from app.modules.system.email_service import send_email
                delivered = await send_email(
                    to=vpn_user.email,
                    subject="VPN Giris Dogrulama Kodu",
                    html_body=f"<p>Giris dogrulama kodunuz: <b>{code}</b></p>",
                    customer_id=customer_id,
                    db=db,
                )
                if not delivered:
                    if settings.DEMO_MODE:
                        log.warning("VPN MFA email demo fallback: %s code=%s", to, code)
                    else:
                        raise HTTPException(
                            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                            detail="VPN MFA e-posta teslimati basarisiz",
                        )
                elif settings.DEMO_MODE:
                    log.info("VPN MFA email -> %s code=%s", to, code)
                else:
                    log.info("VPN MFA email teslim edildi: %s", to)
            elif settings.DEMO_MODE:
                log.info("VPN MFA email (no address, demo) code=%s", code)
            else:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="VPN MFA icin e-posta adresi bulunamadi",
                )
        elif method == "whatsapp":
            to = vpn_user.phone if vpn_user and vpn_user.phone else "unknown"
            if vpn_user and vpn_user.phone:
                from app.modules.whatsapp.service import send_whatsapp_otp
                delivered, err = await send_whatsapp_otp(phone=vpn_user.phone, code=code)
                if not delivered:
                    if settings.DEMO_MODE:
                        log.warning("VPN MFA whatsapp demo fallback: %s code=%s", err, code)
                    else:
                        raise HTTPException(
                            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                            detail="VPN MFA WhatsApp teslimati basarisiz",
                        )
                elif settings.DEMO_MODE:
                    log.info("VPN MFA whatsapp -> %s code=%s", to, code)
                else:
                    log.info("VPN MFA whatsapp teslim edildi: %s", to)
            elif settings.DEMO_MODE:
                log.info("VPN MFA whatsapp (no phone, demo) code=%s", code)
            else:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="VPN MFA icin WhatsApp telefonu bulunamadi",
                )

        challenge = RadiusChallenge(
            customer_id=cid,
            username=username,
            nas_ip=nas_ip,
            state=state,
            mfa_method=method,
            code_hash=code_hash,
            session_token=None,
            verified=False,
            expires_at=datetime.now(timezone.utc) + timedelta(seconds=CHALLENGE_TTL_SECONDS),
        )
        reply_msg = f"Dogrulama kodu {method.upper()} ile gonderildi"
    else:
        return {"challenge_required": False, "state": None, "reply_message": "", "mfa_method": None}

    db.add(challenge)
    await db.flush()
    await db.commit()
    log.info("VPN MFA challenge init: user=%s method=%s state=%s", username, method, state[:12])

    return {
        "challenge_required": True,
        "state": state,
        "reply_message": reply_msg,
        "mfa_method": method,
    }


async def verify_challenge(
    db: AsyncSession,
    state: str,
    code: str,
) -> dict:
    """Verify a MFA code against an active challenge session.

    FreeRADIUS calls this when the user responds to an Access-Challenge.

    Returns:
        dict with keys: verified (bool), reply_message (str)
    """
    challenge = (
        await db.execute(
            select(RadiusChallenge).where(
                RadiusChallenge.state == state,
                RadiusChallenge.verified.is_(False),
                RadiusChallenge.consumed_at.is_(None),
                RadiusChallenge.expires_at > datetime.now(timezone.utc),
            )
        )
    ).scalar_one_or_none()

    if not challenge:
        log.warning("VPN MFA challenge not found or expired: state=%s", state[:12])
        return {"verified": False, "reply_message": "Gecersiz veya sureci dolmus dogrulama oturumu"}

    challenge.attempt_count += 1
    if challenge.attempt_count > MAX_ATTEMPTS:
        challenge.consumed_at = datetime.now(timezone.utc)
        await db.flush()
        await db.commit()
        log.warning("VPN MFA max attempts exceeded: user=%s", challenge.username)
        return {"verified": False, "reply_message": "Maksimum deneme sayisi asildi"}

    valid = False

    if challenge.mfa_method == "totp":
        vpn_user = await _lookup_vpn_user(db, challenge.customer_id, challenge.username)
        if vpn_user and vpn_user.secret_encrypted:
            from app.core.crypto import decrypt
            secret = decrypt(vpn_user.secret_encrypted)
            try:
                import pyotp
                totp = pyotp.TOTP(secret)
                valid = totp.verify(code, valid_window=1)
            except ImportError:
                valid = hmac.compare_digest(code, secrets.token_hex(3))
        else:
            log.warning("VPN user TOTP secret not found: user=%s", challenge.username)

    elif challenge.mfa_method in ("sms", "email", "whatsapp") and challenge.code_hash:
        valid = hmac.compare_digest(hashlib.sha256(code.encode()).hexdigest(), challenge.code_hash)

    if valid:
        challenge.verified = True
        challenge.consumed_at = datetime.now(timezone.utc)
        await db.flush()
        await db.commit()
        log.info("VPN MFA challenge verified: user=%s method=%s", challenge.username, challenge.mfa_method)
        return {"verified": True, "reply_message": "Dogrulama basarili"}

    await db.flush()
    await db.commit()
    log.warning("VPN MFA challenge failed: user=%s attempt=%d", challenge.username, challenge.attempt_count)
    return {"verified": False, "reply_message": "Gecersiz dogrulama kodu"}


async def approve_challenge(
    db: AsyncSession,
    state: str,
) -> dict:
    """Admin approve a pending challenge — marks as verified and consumed."""
    challenge = (
        await db.execute(
            select(RadiusChallenge).where(
                RadiusChallenge.state == state,
                RadiusChallenge.verified.is_(False),
                RadiusChallenge.consumed_at.is_(None),
            )
        )
    ).scalar_one_or_none()

    if not challenge:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Challenge bulunamadi")

    challenge.verified = True
    challenge.consumed_at = datetime.now(timezone.utc)
    await db.flush()
    await db.commit()
    log.info("VPN MFA challenge approved by admin: user=%s state=%s", challenge.username, state[:12])
    return {"verified": True, "reply_message": "Challenge admin tarafindan onaylandi"}


async def reject_challenge(
    db: AsyncSession,
    state: str,
) -> dict:
    """Admin reject a pending challenge — marks as consumed without verified."""
    challenge = (
        await db.execute(
            select(RadiusChallenge).where(
                RadiusChallenge.state == state,
                RadiusChallenge.verified.is_(False),
                RadiusChallenge.consumed_at.is_(None),
            )
        )
    ).scalar_one_or_none()

    if not challenge:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Challenge bulunamadi")

    challenge.consumed_at = datetime.now(timezone.utc)
    await db.flush()
    await db.commit()
    log.warning("VPN MFA challenge rejected by admin: user=%s state=%s", challenge.username, state[:12])
    return {"verified": False, "reply_message": "Challenge admin tarafindan reddedildi"}


async def challenge_status(
    db: AsyncSession,
    state: str,
) -> dict:
    """Check the current status of a challenge (admin/debug)."""
    challenge = (
        await db.execute(
            select(RadiusChallenge).where(RadiusChallenge.state == state)
        )
    ).scalar_one_or_none()
    if not challenge:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Challenge bulunamadi")
    return {
        "id": str(challenge.id),
        "state": challenge.state,
        "username": challenge.username,
        "mfa_method": challenge.mfa_method,
        "verified": challenge.verified,
        "attempt_count": challenge.attempt_count,
        "expires_at": challenge.expires_at.isoformat() if challenge.expires_at else None,
        "consumed_at": challenge.consumed_at.isoformat() if challenge.consumed_at else None,
        "created_at": challenge.created_at.isoformat() if challenge.created_at else None,
    }
