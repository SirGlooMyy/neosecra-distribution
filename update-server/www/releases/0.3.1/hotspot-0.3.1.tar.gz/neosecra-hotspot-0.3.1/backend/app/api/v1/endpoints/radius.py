import uuid
from urllib.parse import parse_qs

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import settings
from app.core.ingest_auth import require_ingest_api_key
from app.modules.radius.models import RadiusEvent
from app.modules.radius.schemas import RadiusEventCreate, RadiusEventOut
from app.modules.radius import challenge_service

router = APIRouter()


class VpnChallengeInitIn(BaseModel):
    """FreeRADIUS REST payload for the first Access-Request."""

    username: str = Field(..., min_length=1, max_length=255)
    customer_id: uuid.UUID | None = None
    nas_ip: str | None = None


class VpnChallengeVerifyIn(BaseModel):
    """FreeRADIUS REST payload for the Access-Challenge response."""

    state: str = Field(..., min_length=8, max_length=255)
    code: str = Field(..., min_length=4, max_length=32)


@router.post("/events", response_model=RadiusEventOut, summary="Ingest a RADIUS accounting event", description="Creates a new RADIUS accounting event record from a NAS device. Typically called by the RADIUS server or a syslog forwarder. Accepts standard RADIUS attributes such as username, NAS IP, and session identifiers.")
async def create_radius_event(
    body: RadiusEventCreate,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS")
    event = RadiusEvent(
        tenant_id=body.tenant_id,
        username=body.username,
        nas_ip=body.nas_ip,
        nas_port=body.nas_port,
        acct_status_type=body.acct_status_type,
        acct_session_id=body.acct_session_id,
        calling_station_id=body.calling_station_id,
        framed_ip_address=body.framed_ip_address,
        acct_input_octets=body.acct_input_octets,
        acct_output_octets=body.acct_output_octets,
        acct_session_time=body.acct_session_time,
        acct_terminate_cause=body.acct_terminate_cause,
        acct_interim_interval=body.acct_interim_interval,
    )
    db.add(event)
    await db.commit()
    await db.refresh(event)
    return event


@router.post(
    "/vpn/challenge/init",
    summary="Start a VPN MFA RADIUS Access-Challenge",
    description="Called by the FreeRADIUS REST module for a FortiGate VPN login. The response contains the State and Reply-Message used for the second Access-Request.",
)
async def init_vpn_challenge(
    body: VpnChallengeInitIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    return await challenge_service.init_challenge(
        db,
        customer_id=body.customer_id,
        username=body.username,
        nas_ip=body.nas_ip,
    )


@router.post(
    "/vpn/challenge/init/form",
    include_in_schema=False,
)
async def init_vpn_challenge_form(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """FreeRADIUS ``rest`` compatibility endpoint.

    Older bundled configurations use ``body = post`` and send attribute names
    such as ``User-Name`` and ``NAS-IP-Address``.  Keep this adapter at the
    HTTP boundary; the challenge service itself remains JSON/domain based.
    """
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    try:
        form = await request.form()
        values = {str(key): str(value) for key, value in form.items()}
    except Exception:
        raw = (await request.body()).decode("utf-8", errors="replace")
        values = {key: items[-1] for key, items in parse_qs(raw, keep_blank_values=True).items() if items}
    def _value(*keys: str) -> str | None:
        for key in keys:
            value = values.get(key)
            if value not in (None, ""):
                return value
        return None
    username = _value("username", "User-Name", "User_Name")
    if not username:
        raise HTTPException(status_code=422, detail="User-Name gerekli")
    customer_raw = _value("customer_id", "Customer-Id", "Customer-ID")
    customer_id = None
    if customer_raw:
        try:
            customer_id = uuid.UUID(customer_raw)
        except ValueError:
            raise HTTPException(status_code=422, detail="customer_id gecersiz")
    result = await challenge_service.init_challenge(
        db,
        customer_id=customer_id,
        username=username,
        nas_ip=_value("nas_ip", "NAS-IP-Address", "NAS_IP_Address"),
    )
    # rlm_rest consumes a JSON policy, not an arbitrary application payload.
    # Keep the friendly fields for diagnostics/API callers while also exposing
    # standard RADIUS list-qualified attributes for Access-Challenge.
    if result.get("challenge_required"):
        result.update({
            "control:Auth-Type": "Challenge",
            "reply:State": result.get("state"),
            "reply:Reply-Message": result.get("reply_message"),
        })
    return result


@router.post(
    "/vpn/challenge/verify",
    summary="Verify a VPN MFA RADIUS Access-Challenge",
    description="Called by FreeRADIUS when FortiGate returns the one-time SMS, email or authenticator code.",
)
async def verify_vpn_challenge(
    body: VpnChallengeVerifyIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    return await challenge_service.verify_challenge(db, state=body.state, code=body.code)


@router.post(
    "/vpn/challenge/verify/form",
    include_in_schema=False,
)
async def verify_vpn_challenge_form(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """FreeRADIUS ``rest`` compatibility endpoint for the OTP response.

    ``rlm_rest`` sends RADIUS attributes as URL-encoded form fields when the
    operation uses ``body = post``.  Keep this adapter at the HTTP boundary so
    the challenge service remains independent of FreeRADIUS attribute names.
    Invalid codes deliberately return 401: rlm_rest maps that status to
    ``reject`` and cannot accidentally turn a failed OTP into Access-Accept.
    """
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    try:
        form = await request.form()
        values = {str(key): str(value) for key, value in form.items()}
    except Exception:
        raw = (await request.body()).decode("utf-8", errors="replace")
        values = {key: items[-1] for key, items in parse_qs(raw, keep_blank_values=True).items() if items}

    def _value(*keys: str) -> str | None:
        for key in keys:
            value = values.get(key)
            if value not in (None, ""):
                return value
        return None

    state = _value("state", "State", "State_", "reply:State")
    code = _value("code", "User-Password", "User_Password", "user_password")
    if not state or not code:
        raise HTTPException(status_code=422, detail="State ve OTP kodu gerekli")
    result = await challenge_service.verify_challenge(db, state=state, code=code)
    if not result.get("verified"):
        raise HTTPException(status_code=401, detail=result.get("reply_message") or "Gecersiz OTP")
    return result
