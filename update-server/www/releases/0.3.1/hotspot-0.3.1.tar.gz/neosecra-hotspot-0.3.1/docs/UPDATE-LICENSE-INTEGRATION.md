# Neosecra lisans ve tek tık güncelleme entegrasyonu

Hotspot lisans envelope'ını yerelde Ed25519 ile doğrular. Lisans sunucusuna
çalışma anında bağımlı değildir; `update_entitlement_until` alanı güncelleme
başlatılmadan önce kontrol edilir.

Canonical delivery ACK, ürünün yerel verifier'ının ürettiği payload SHA-256
fingerprint'i ve aynı anda hesaplanan `verifier_status` değerini taşır.
`/api/v1/licensing/ack` kayıtlı envelope'u yeniden doğrular; caller'ın farklı
fingerprint/status göndermesi `LICENSE_FINGERPRINT_MISMATCH` veya
`LICENSE_STATUS_MISMATCH` ile reddedilir ve cevap yalnızca canonical
fingerprint'i içerir. Legacy ajan uyumluluğu bounded envelope hash ile
sınırlıdır; bu değer yeni teslimatlarda kullanılmaz.

## Bileşenler

* `GET/POST /api/v1/system/license*`: lisans durumu, `.lic` yükleme ve
  doğrulama.
* `GET /api/v1/system/version`: çalışan backend/frontend/schema sürümü.
* `POST /api/v1/system/updates/check`: imzalı `hotspot-stable` kanalı.
* `POST /api/v1/system/updates/preflight`: lisans, entitlement, DB, disk ve
  host agent heartbeat kontrolleri.
* `POST /api/v1/system/updates/start`: yalnızca doğrulanmış semver hedefi için
  atomik `upgrade-request.json` yazar.
* `GET /api/v1/system/updates/session`: agent journal'ını canlı okur.
* `GET /api/v1/system/updates/history` ve rollback endpointi: geçmiş/geri alma.

## Host kurulumu

Hotspot compose'ı aşağıdaki bind mount'ları bekler:

```text
/opt/neosecra/hotspot/state/upgrade-bridge/trigger
/opt/neosecra/hotspot/state/upgrade-bridge/journal
/opt/neosecra/hotspot/state/upgrade-bridge/agent-alive
```

Neosecra Distribution içindeki Hotspot kurulum betiği bu sözleşmeyi doğrudan
kurar; Assessment birimlerini kopyalamak gerekmez:

```bash
cd neosecra-distribution/deployment/v1/agent
sudo ./install-hotspot-agent.sh \
  --hotspot-root /opt/neosecra/hotspot \
  --backend-uid 1000:1000
```

Bu kurulum `neosecra-hotspot-update-agent.path` ve heartbeat timer'ını,
`/opt/neosecra/hotspot/state/upgrade-bridge` köprüsünü ve imza anahtarını
oluşturur. Trigger dosyasını API yazar; root çalışan agent yalnızca imzalı
`hotspot-stable` arşivini `/opt/neosecra/hotspot/update-agent/hotspot-updater.sh`
ile uygular. Güncelleme uygulayıcısı PostgreSQL yedeği alır, yeni Compose
release'ini staging'de build/migrate eder, `/api/v1/health` kapısından geçince
`current` symlink'ini değiştirir; başarısızlıkta eski release ve yedeğe döner.

Kanal release kaydı `archive.url` alanında Hotspot kaynak arşivini taşımalıdır.
Arşivin içinde `docker-compose.yml`, `backend/.env.example`, `backend/`,
`frontend/admin/` ve `frontend/portal/` bulunur. Üretim sırrı olan
`backend/.env` arşive konmaz; agent mevcut kurulumdaki dosyayı staging'e
kopyalar. `archive.sha256` ve `archive.minisig` zorunludur.

Yerel artifact üretimi için `scripts/build-release.sh` kullanılabilir; çıkan
`.tar.gz` ve `.sha256` dosyası `neosecra-distribution/update-server/publish.sh`
ile `--product hotspot --channel stable` kanalına imzalı olarak
yayınlanır. Yayın adımı archive ve kanal minisign imzalarını üretir; admin
ekranı ancak bu kaydı gördüğünde tek tık butonunu açar.

Agent heartbeat dosyası güncel değilse API `can_auto_upgrade=false` döndürür;
buton bu nedenle bilinçli olarak pasif kalır.

Ortak status yanıtı `update.channel_status`, `target_version`, `has_update`,
`heartbeat_fresh`, `preflight` ve `reason_code` alanlarını; kök yanıt gerçek
`active_job` session'ını içerir. `reason_code` (ör. `LICENSE_EXPIRED`,
`AGENT_STALE`, `CHANNEL_INVALID`, `NO_RELEASE`) backend gerçeğidir ve UI
tarafından başarıya çevrilemez.

`POST /api/v1/system/updates/start` ve geriye uyumlu
`/api/v1/system/platform-upgrade/start` endpoint'leri `Idempotency-Key`
header'ını zorunlu tutar; eksik header `400 IDEMPOTENCY_KEY_REQUIRED`, tekrar
istek ise aynı journal/session sonucunun replay'idir.

## Release kanalı

Dağıtım sunucusunda imzalı ve ürüne özel kanal:

```text
https://update.neosecra.com/channels/hotspot-stable.json
```

Kanalda `releases` boşsa Hotspot güncel/kanal beklemede gösterir. Release
yayımlandığında manifestteki archive SHA-256/minisig ve minimum sürüm bilgisi
UI'a gelir; backend yalnızca imzalı hedefi agent'a iletir.

## Canlı kurulum notu

Hotspot için ayrılan canlı host bu çalışma ortamından henüz verilmediği için
canlı host'a systemd unit, bridge dizini veya compose restart uygulanmadı. Kurulum
sonrasında `/api/v1/system/updates/capability` çıktısında
`heartbeat_fresh=true` ve `can_auto_upgrade=true` görülmeden tek tık butonu
bilinçli olarak etkinleşmez.
