import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Play,
  RefreshCw,
  RotateCcw,
  Shield,
  ShieldCheck,
  Server,
  Download,
  Activity,
  Sparkles,
  Clock,
  Check,
  XCircle,
  ArrowRight,
} from 'lucide-react';
import {
  checkPlatformUpdates,
  getPlatformVersion,
  getPlatformLicenseStatus,
  getUpdateCapability,
  getUpdateHistory,
  getUpdateSession,
  rollbackPlatformUpdate,
  runUpdatePreflight,
  startPlatformUpdate,
} from '../lib/api';

const terminalStates = new Set(['COMPLETED', 'FAILED', 'ROLLED_BACK']);

const stateLabels: Record<string, { label: string; tone: string }> = {
  IDLE: { label: 'Boşta (Hazır)', tone: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300' },
  PREFLIGHT: { label: 'Ön Koşullar Denetleniyor', tone: 'bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300' },
  BACKING_UP: { label: 'Sistem Yedeği Alınıyor', tone: 'bg-indigo-50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-300' },
  MIGRATING: { label: 'Veritabanı Göçü Yapılıyor', tone: 'bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-300' },
  VERIFYING: { label: 'Sistem Sağlığı Doğrulanıyor', tone: 'bg-purple-50 dark:bg-purple-950/30 text-purple-700 dark:text-purple-300' },
  COMPLETED: { label: 'Başarıyla Tamamlandı', tone: 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300' },
  FAILED: { label: 'Güncelleme Başarısız', tone: 'bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300' },
  ROLLED_BACK: { label: 'Geri Alındı (Rollback)', tone: 'bg-orange-50 dark:bg-orange-950/30 text-orange-700 dark:text-orange-300' },
};

const pipelineSteps = [
  { key: 'PREFLIGHT', title: '1. Ön Koşul', desc: 'Disk, DB ve lisans doğrulaması' },
  { key: 'BACKING_UP', title: '2. Yedekleme', desc: 'PostgreSQL DB dump & config' },
  { key: 'MIGRATING', title: '3. Dağıtım & Göç', desc: 'Minisign imza & Alembic şema' },
  { key: 'VERIFYING', title: '4. Doğrulama', desc: 'Sistem sağlık & API testi' },
];

export const PlatformUpgradePage: React.FC = () => {
  const [version, setVersion] = useState<any>(null);
  const [capability, setCapability] = useState<any>(null);
  const [updates, setUpdates] = useState<any>({ updates: [], has_update: false });
  const [session, setSession] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [preflight, setPreflight] = useState<any[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [targetVersionInput, setTargetVersionInput] = useState('');
  const [contractStatus, setContractStatus] = useState<any>(null);

  const load = async () => {
    setLoading(true);
    try {
      const [v, c, u, s, h, ls] = await Promise.all([
        getPlatformVersion(),
        getUpdateCapability(),
        checkPlatformUpdates(),
        getUpdateSession(),
        getUpdateHistory(),
        getPlatformLicenseStatus(),
      ]);
      setVersion(v);
      setCapability(c);
      setUpdates(u);
      setSession(s?.session || null);
      setHistory(h?.history || []);
      setContractStatus(ls);
    } catch (error: any) {
      setMessage({ text: error?.message || 'Güncelleme merkezi verileri yüklenemedi.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  useEffect(() => {
    if (!session || terminalStates.has(session.state)) return;
    const timer = window.setInterval(async () => {
      try {
        const value = await getUpdateSession();
        const next = value?.session || null;
        setSession(next);
        if (!next || terminalStates.has(next.state)) {
          await load();
        }
      } catch {
        /* poll */
      }
    }, 3000);
    return () => window.clearInterval(timer);
  }, [session?.state]);

  const handleCheckUpdates = async () => {
    setBusy(true);
    setMessage(null);
    try {
      const x = await checkPlatformUpdates();
      setUpdates(x);
      setMessage({ text: 'Dağıtım kanalı kontrol edildi.', type: 'success' });
    } catch (error: any) {
      setMessage({ text: error?.message || 'Dağıtım kanalına erişilemedi.', type: 'error' });
    } finally {
      setBusy(false);
    }
  };

  const handleRunPreflight = async () => {
    setBusy(true);
    setMessage(null);
    try {
      const x = await runUpdatePreflight();
      setPreflight(x.checks || []);
      const allPassed = (x.checks || []).every((c: any) => c.status === 'PASS');
      if (allPassed) {
        setMessage({ text: 'Tüm ön koşul testleri başarıyla tamamlandı (PASS).', type: 'success' });
      } else {
        setMessage({ text: 'Bazı ön koşul testleri başarısız oldu.', type: 'error' });
      }
    } catch (error: any) {
      setMessage({ text: error?.message || 'Ön koşul analizi çalıştırılamadı.', type: 'error' });
    } finally {
      setBusy(false);
    }
  };

  const start = async (target: string) => {
    if (!target) return;
    if (!window.confirm(`${target} sürümüne güncelleme başlatılacak. Devam edilsin mi?`)) return;

    setBusy(true);
    setMessage(null);
    try {
      const res = await startPlatformUpdate(target);
      const nextSession = res?.session || null;
      if (nextSession) setSession(nextSession);
      if (nextSession?.state === 'COMPLETED') {
        setMessage({ text: `v${target} güncellemesi doğrulanarak tamamlandı.`, type: 'success' });
      } else if (nextSession?.state === 'FAILED') {
        setMessage({ text: nextSession.error || 'Güncelleme başarısız oldu.', type: 'error' });
      } else {
        setMessage({ text: 'Güncelleme isteği kuyruğa alındı; ilerleme gerçek agent journal kaydından okunacak.', type: 'info' });
      }
      await load();
    } catch (error: any) {
      setMessage({ text: error?.message || 'Güncelleme başlatılamadı.', type: 'error' });
    } finally {
      setBusy(false);
    }
  };

  const handleRollback = async (jobId: string) => {
    if (!window.confirm('Önceki yedek noktasına geri dönülecek (Rollback). Devam edilsin mi?')) return;
    setBusy(true);
    setMessage(null);
    try {
      await rollbackPlatformUpdate(jobId);
      setMessage({ text: 'Geri alma işlemi başlatıldı.', type: 'info' });
      await load();
    } catch (error: any) {
      setMessage({ text: error?.message || 'Geri alma başarısız.', type: 'error' });
    } finally {
      setBusy(false);
    }
  };

  const currentState = session?.state || version?.upgrade_status || 'IDLE';
  const stCfg = stateLabels[currentState] || stateLabels.IDLE;
  const currentVer = version?.current_version || '—';
  const canAutoUpgrade = Boolean(capability?.can_auto_upgrade && contractStatus?.update?.can_auto_upgrade);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24" role="status" aria-live="polite">
        <RefreshCw className="h-5 w-5 animate-spin text-slate-500" />
        <span className="ml-2 text-sm text-slate-500">Güncelleme durumu yükleniyor...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 1. Header with standard buttons */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Güncelleme Merkezi
            </h1>
            <span className="inline-flex items-center rounded-md bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-mono">
              v{currentVer}
            </span>
            <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold ${stCfg.tone}`}>
              {stCfg.label}
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            NeoSecra Distribution imzalı dağıtım kanalı ve host update-agent orkestrasyonu.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCheckUpdates}
            disabled={busy}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${busy ? 'animate-spin' : ''}`} />
            Güncellemeleri Denetle
          </button>

          <button
            onClick={handleRunPreflight}
            disabled={busy}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            <ShieldCheck className="h-3.5 w-3.5 text-slate-500" />
            Ön Koşulları Çalıştır
          </button>

          <button
            onClick={() => start(updates.updates?.[0]?.target_version || targetVersionInput)}
            disabled={busy || !canAutoUpgrade || !(updates.updates?.[0]?.target_version || targetVersionInput)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition disabled:opacity-50"
          >
            <Play className="h-3.5 w-3.5 fill-current" />
            Güncellemeyi Başlat
          </button>
        </div>
      </div>

      {/* Alert Notification */}
      {message && (
        <div
          className={`p-3.5 rounded-xl text-xs font-medium flex items-center justify-between border ${
            message.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/50'
              : message.type === 'error'
              ? 'bg-rose-50 dark:bg-rose-950/20 text-rose-800 dark:text-rose-400 border-rose-100 dark:border-rose-900/50'
              : 'bg-blue-50 dark:bg-blue-950/20 text-blue-800 dark:text-blue-400 border-blue-100 dark:border-blue-900/50'
          }`}
        >
          <div className="flex items-center gap-2">
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{message.text}</span>
          </div>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-slate-600 text-xs">
            ✕
          </button>
        </div>
      )}

      {contractStatus?.update?.reason_code && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-3.5 text-xs font-medium text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/20 dark:text-amber-300" role="status">
          Güncelleme pasif nedeni: <code className="font-mono">{contractStatus.update.reason_code}</code>
        </div>
      )}

      {/* 2. Standard 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Çalışan Sürüm</span>
            <Server className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white font-mono">v{currentVer}</span>
            <span className="text-xs text-slate-500 font-mono">({version?.database_schema_revision || 'head'})</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Dağıtım Kanalı</span>
            <Sparkles className="h-4 w-4 text-indigo-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">
              {version?.release_channel || capability?.release_channel || 'hotspot-stable'}
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Host Update-Agent</span>
            <Activity className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-sm font-bold ${capability?.can_auto_upgrade ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600'}`}>
              {capability?.can_auto_upgrade ? 'Hazır / Canlı' : 'Devre Dışı'}
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Orkestrasyon Durumu</span>
            <Shield className="h-4 w-4 text-purple-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-sm font-bold text-slate-900 dark:text-white">
              {stCfg.label}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Active Session Step Tracker */}
      {session && !terminalStates.has(session.state) && (
        <div className="rounded-xl border border-blue-200 bg-blue-50/40 p-4 dark:border-blue-900/50 dark:bg-blue-950/20 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4 text-blue-600 animate-spin" />
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                Güncelleme Süreci: v{currentVer} → v{session.target_version}
              </span>
            </div>
            <span className="text-xs font-mono text-slate-500">
              Oturum: {session.id?.slice(0, 8)}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {pipelineSteps.map((step) => {
              const isActive = session.state === step.key;
              return (
                <div
                  key={step.key}
                  className={`rounded-lg border p-2.5 text-xs ${
                    isActive
                      ? 'border-blue-400 bg-white font-semibold text-blue-900 dark:border-blue-800 dark:bg-slate-900 dark:text-blue-300'
                      : 'border-slate-200 bg-white/60 text-slate-600 dark:border-slate-800 dark:bg-slate-900/60 dark:text-slate-400'
                  }`}
                >
                  <div className="font-bold">{step.title}</div>
                  <div className="text-[10px] text-slate-500">{step.desc}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. Main 2-Column Content */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column: Signed Catalog & Preflight (7 cols) */}
        <div className="space-y-6 lg:col-span-7">
          {/* Catalog Box */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                İmzalı Sürümler Kataloğu
              </h3>
              <span className="text-xs text-slate-500">
                {updates.updates?.length || 0} sürüm mevcut
              </span>
            </div>

            {updates.has_update && updates.updates?.length > 0 ? (
              <div className="space-y-3">
                {updates.updates.map((item: any) => (
                  <div
                    key={item.target_version}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50/50 p-3.5 dark:border-slate-800 dark:bg-slate-850/50"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold text-slate-900 dark:text-white">
                          v{item.target_version}
                        </span>
                        <span className="rounded-md bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                          İmzalı Minisign
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-slate-500">
                        {item.release_notes || 'Güvenlik ve kararlılık güncellemeleri.'}
                      </p>
                    </div>

                    <button
                      onClick={() => start(item.target_version)}
                      disabled={busy || !canAutoUpgrade}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700 transition disabled:opacity-50"
                    >
                      <Play className="h-3 w-3 fill-current" />
                      Yükle &amp; Güncelle
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-4 text-center dark:border-slate-800 dark:bg-slate-850/30">
                <CheckCircle2 className="mx-auto h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                <p className="mt-2 text-xs font-semibold text-slate-800 dark:text-slate-200">
                  Çalışan sürüm güncel (v{currentVer})
                </p>
                <p className="mt-0.5 text-[11px] text-slate-500">
                  Dağıtım kanalında daha yeni bir sürüm bulunmuyor.
                </p>
              </div>
            )}
          </div>

          {/* Preflight Results Box */}
          {preflight && (
            <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 pb-3 dark:border-slate-800">
                Ön Koşul Test Sonuçları
              </h3>

              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {preflight.map((check: any) => {
                  const isPass = check.status === 'PASS';
                  return (
                    <div
                      key={check.name}
                      className="flex items-start gap-2.5 rounded-lg border border-slate-100 bg-slate-50/60 p-2.5 text-xs dark:border-slate-800 dark:bg-slate-850/40"
                    >
                      {isPass ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="font-semibold text-slate-900 dark:text-white">
                          {check.name}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {check.message || (isPass ? 'Koşul sağlandı.' : 'Başarısız.')}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Target Version & Action Trigger (5 cols) */}
        <div className="space-y-6 lg:col-span-5">
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 pb-3 dark:border-slate-800">
              Manuel Sürüm Tetikleme
            </h3>

            <p className="text-xs text-slate-500">
              Hedef sürüm belirterek host update-agent kuyruğuna güncelleme isteği bırakabilirsiniz.
            </p>

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                Hedef Sürüm
              </label>
              <div className="flex items-center gap-2">
                <span className="rounded-lg bg-slate-100 px-2.5 py-1.5 font-mono text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                  v{currentVer} →
                </span>
                <input
                  type="text"
                  value={targetVersionInput}
                  onChange={(e) => setTargetVersionInput(e.target.value.trim())}
                  placeholder="Hedef semver (örn. 0.3.6)"
                  className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-xs font-semibold dark:border-slate-700 dark:bg-slate-950 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <button
              onClick={() => start(targetVersionInput)}
              disabled={busy || !targetVersionInput || !canAutoUpgrade}
              className="w-full inline-flex justify-center items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition disabled:opacity-50 shadow-xs"
            >
              {busy ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5 fill-current" />}
              v{targetVersionInput} Sürümüne Güncelle
            </button>

            <div className="rounded-lg bg-slate-50 p-3 text-[11px] text-slate-500 dark:bg-slate-850/60 dark:text-slate-400 space-y-1">
              <div className="font-semibold text-slate-700 dark:text-slate-300">Güvenlik Kontrolleri:</div>
              <div>• PostgreSQL dump yedeği otomatik alınır.</div>
              <div>• Minisign imzası doğrulanır.</div>
              <div>• Hata durumunda otomatik geri alma (Rollback) uygulanır.</div>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Update & Restore History Table */}
      {history.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 pb-3 dark:border-slate-800">
            Güncelleme ve Geri Yükleme Geçmişi
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase dark:border-slate-800">
                  <th className="py-2.5 px-3">Sürüm Geçişi</th>
                  <th className="py-2.5 px-3">Tarih</th>
                  <th className="py-2.5 px-3">Durum</th>
                  <th className="py-2.5 px-3 text-right">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {history.slice(0, 10).map((item: any) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-850/50">
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-900 dark:text-white">
                      v{item.from_version || '?'} → v{item.target_version}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500">
                      {item.finished_at ? new Date(item.finished_at).toLocaleString('tr-TR') : '-'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                        {stateLabels[item.state]?.label || item.state}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {capability?.can_rollback && item.backup_path && (
                        <button
                          onClick={() => handleRollback(item.id)}
                          disabled={busy}
                          className="inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 transition"
                        >
                          <RotateCcw className="h-3 w-3" />
                          Geri Al
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
