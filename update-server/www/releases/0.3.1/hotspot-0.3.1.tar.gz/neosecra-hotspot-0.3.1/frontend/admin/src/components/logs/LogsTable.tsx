import React from 'react';
import { GitCompare, Loader2, ChevronRight, Shield, User, Globe, AlertCircle, CheckCircle2, XCircle, Clock } from 'lucide-react';
import type { FirewallLog } from '../../types/logs';

interface Props {
  logs: FirewallLog[];
  loading: boolean;
  hasNext: boolean;
  total: number;
  onLoadMore: () => void;
  onCorrelate: (sessionId: string) => void;
  onSelectLog?: (log: FirewallLog) => void;
  onFilterUser?: (user: string) => void;
  onFilterIp?: (ip: string) => void;
}

const severityColor: Record<string, string> = {
  emergency: 'bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-900/40',
  alert: 'bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-900/40',
  critical: 'bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-900/40',
  error: 'bg-orange-100 text-orange-800 dark:bg-orange-950/40 dark:text-orange-300 border-orange-200 dark:border-orange-900/40',
  high: 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300 border-red-200 dark:border-red-900/40',
  medium: 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-900/40',
  warning: 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-900/40',
  notice: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/40 dark:text-cyan-300 border-cyan-200 dark:border-cyan-900/40',
  low: 'bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-300 border-blue-200 dark:border-blue-900/40',
  info: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700',
};
const actionColor: Record<string, string> = {
  accept: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900/40',
  'ip-conn': 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900/40',
  deny: 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-900/40',
  block: 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-900/40',
  blocked: 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-900/40',
  'client-rst': 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-900/40',
  'server-rst': 'bg-orange-50 text-orange-700 dark:bg-orange-950/40 dark:text-orange-300 border-orange-200 dark:border-orange-900/40',
  close: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border-slate-200 dark:border-slate-700',
  timeout: 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-900/40',
};

export const LogsTable: React.FC<Props> = ({
  logs,
  loading,
  hasNext,
  total,
  onLoadMore,
  onCorrelate,
  onSelectLog,
  onFilterUser,
  onFilterIp,
}) => {
  if (loading && logs.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm p-6 space-y-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="animate-pulse flex items-center justify-between gap-4 py-2">
            <div className="h-4 w-28 bg-slate-200 dark:bg-slate-800 rounded-md" />
            <div className="h-4 w-48 bg-slate-200 dark:bg-slate-800 rounded-md" />
            <div className="h-4 w-24 bg-slate-200 dark:bg-slate-800 rounded-md" />
            <div className="h-4 w-16 bg-slate-200 dark:bg-slate-800 rounded-md" />
            <div className="h-4 w-40 bg-slate-200 dark:bg-slate-800 rounded-md" />
          </div>
        ))}
      </div>
    );
  }

  if (!loading && logs.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm p-14 text-center">
        <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-500 dark:bg-indigo-950/40 flex items-center justify-center mx-auto mb-3">
          <Globe className="w-6 h-6" />
        </div>
        <h4 className="text-base font-bold text-slate-800 dark:text-slate-200">Kayıt Bulunamadı</h4>
        <p className="text-slate-400 text-xs mt-1 max-w-sm mx-auto">
          Seçili zaman aralığında veya aktif filtrelerle eşleşen güvenlik olayı bulunamadı. Filtreleri temizleyip tekrar deneyin.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/50 text-[11px] font-bold uppercase tracking-wider text-slate-500">
              <th className="px-4 py-3.5 whitespace-nowrap">Zaman</th>
              <th className="px-4 py-3.5 whitespace-nowrap">Kullanıcı (User)</th>
              <th className="px-4 py-3.5 whitespace-nowrap">Kaynak → Hedef (IP : Port)</th>
              <th className="px-4 py-3.5 whitespace-nowrap">İşlem (Action)</th>
              <th className="px-4 py-3.5 whitespace-nowrap">Seviye</th>
              <th className="px-4 py-3.5 whitespace-nowrap">Log Türü</th>
              <th className="px-4 py-3.5 whitespace-nowrap">Politika & Mesaj</th>
              <th className="px-3 py-3.5 text-right">Detay</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80 text-xs">
            {logs.map((log) => {
              const displayUser = (log.user && log.user !== 'hotspot') ? log.user : (log.parsed?.user && log.parsed.user !== 'hotspot' ? log.parsed.user : null);
              const isVpn =
                log.log_type === 'vpn' ||
                Boolean(displayUser) ||
                Boolean(log.parsed?.srcintf === 'ssl.root') ||
                Boolean(log.parsed?.policyname?.toLowerCase().includes('sslvpn'));

              return (
                <tr
                  key={log.id}
                  className={`group transition-colors cursor-pointer ${
                    isVpn
                      ? 'bg-indigo-50/30 dark:bg-indigo-950/10 hover:bg-indigo-50/70 dark:hover:bg-indigo-950/25'
                      : 'hover:bg-slate-50/60 dark:hover:bg-slate-800/20'
                  }`}
                  onClick={() => onSelectLog?.(log)}
                >
                  {/* Zaman */}
                  <td className="px-4 py-3 text-slate-500 font-mono whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    <div className="text-[10px] text-slate-400 font-sans">
                      {new Date(log.timestamp).toLocaleDateString('tr-TR')}
                    </div>
                  </td>

                  {/* Kullanıcı */}
                  <td className="px-4 py-3 whitespace-nowrap">
                    {displayUser ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onFilterUser?.(displayUser);
                        }}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-100/90 text-indigo-900 dark:bg-indigo-950/80 dark:text-indigo-200 font-bold text-xs hover:ring-2 hover:ring-indigo-400 transition"
                        title="Bu kullanıcıyı filtrele"
                      >
                        <User className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                        <span>{displayUser}</span>
                      </button>
                    ) : (
                      <span className="text-slate-300 dark:text-slate-600 font-mono">—</span>
                    )}
                  </td>

                  {/* Kaynak -> Hedef */}
                  <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (log.src_ip) onFilterIp?.(log.src_ip);
                        }}
                        className="font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                        title="Kaynak IP filtrele"
                      >
                        {log.src_ip || '—'}
                      </button>
                      {log.src_port != null && <span className="text-slate-400 text-[11px]">:{log.src_port}</span>}
                      <span className="text-slate-300 dark:text-slate-600 mx-0.5">→</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (log.dst_ip) onFilterIp?.(log.dst_ip);
                        }}
                        className="font-bold text-amber-600 dark:text-amber-400 hover:underline"
                        title="Hedef IP filtrele"
                      >
                        {log.dst_ip || '—'}
                      </button>
                      {log.dst_port != null && <span className="text-slate-400 text-[11px]">:{log.dst_port}</span>}
                    </div>
                  </td>

                  {/* Action */}
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[11px] border ${
                        actionColor[log.action] || 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      {log.action}
                    </span>
                  </td>

                  {/* Severity */}
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span
                      className={`inline-flex px-2 py-0.5 rounded-full font-semibold text-[10px] uppercase border ${
                        severityColor[log.severity] || severityColor.info
                      }`}
                    >
                      {log.severity}
                    </span>
                  </td>

                  {/* Log Türü */}
                  <td className="px-4 py-3 whitespace-nowrap font-medium text-slate-600 dark:text-slate-300">
                    <span className="inline-flex items-center gap-1">
                      {isVpn && <Shield className="w-3 h-3 text-indigo-500" />}
                      <span className="uppercase font-bold text-[11px]">{log.log_type}</span>
                    </span>
                    {log.log_subtype && <span className="text-slate-400 text-[10px] ml-1">/{log.log_subtype}</span>}
                  </td>

                  {/* Mesaj */}
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-300 max-w-[280px] truncate font-medium">
                    {log.message || '—'}
                  </td>

                  {/* Detay & Korelasyon */}
                  <td className="px-3 py-3 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onCorrelate(log.correlation_id || log.id);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition opacity-0 group-hover:opacity-100"
                        title="Oturum Korelasyonu"
                      >
                        <GitCompare className="w-3.5 h-3.5" />
                      </button>
                      <ChevronRight className="w-4 h-4 text-slate-400 inline transition-transform group-hover:translate-x-0.5" />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Sayfalama & Yükleme Çubuğu */}
      <div className="flex items-center justify-between px-5 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
        <span className="text-xs font-semibold text-slate-500">
          Toplam <span className="text-slate-800 dark:text-slate-200 font-bold">{total.toLocaleString('tr-TR')}</span> güvenlik kaydı
        </span>
        {hasNext && (
          <button
            onClick={onLoadMore}
            disabled={loading}
            className="inline-flex items-center px-4 py-2 text-xs font-bold text-indigo-600 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 rounded-2xl transition disabled:opacity-60 shadow-sm"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : null}
            Daha Fazla Kayıt Yükle (+50)
          </button>
        )}
      </div>
    </div>
  );
};
