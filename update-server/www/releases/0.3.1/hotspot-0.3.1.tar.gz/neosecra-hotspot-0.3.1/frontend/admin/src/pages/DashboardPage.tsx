import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Activity,
  ArrowRight,
  BarChart3,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Clock,
  Download,
  FileCheck2,
  FileText,
  Gauge,
  MapPin,
  Radio,
  RefreshCw,
  Search,
  Server,
  Shield,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  UserRound,
  Users,
  Wifi,
  Key,
} from "lucide-react";
import { getDashboardOverview, getDevices, getFirewallLogs, getSessions } from "../lib/api";

type AnyRecord = Record<string, any>;

const RANGE_OPTIONS = [
  { label: "24 Saat", days: 1 },
  { label: "7 Gün", days: 7 },
  { label: "30 Gün", days: 30 },
];

const toArray = (value: any): any[] => {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.items)) return value.items;
  if (Array.isArray(value?.results)) return value.results;
  if (Array.isArray(value?.data)) return value.data;
  return [];
};

const asNumber = (value: any, fallback = 0): number => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};

const formatNumber = (value: any) => new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 0 }).format(asNumber(value));

const formatBytes = (bytes: any) => {
  const value = asNumber(bytes);
  if (value === 0) return "0 B";
  if (value < 1024) return `${formatNumber(value)} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  return `${(value / (1024 * 1024 * 1024)).toFixed(2)} GB`;
};

const formatTime = (value: any) => {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
};

const formatDate = (value: any) => {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleDateString("tr-TR", { day: "2-digit", month: "short" });
};

const sessionUser = (session: AnyRecord) => session.phone || session.username || session.user || session.mac || "Misafir";
const sessionLocation = (session: AnyRecord) => session.location_name || session.location?.name || session.ssid || session.nas_ip || session.device_name || "Lokasyon belirtilmedi";
const sessionBytes = (session: AnyRecord) => asNumber(session.bytes_in ?? session.bytesIn) + asNumber(session.bytes_out ?? session.bytesOut);

const Sparkline: React.FC<{ values: number[] }> = ({ values }) => {
  if (!values.length) return <div className="h-10 rounded-lg bg-slate-100 dark:bg-slate-800" />;
  const max = Math.max(...values, 1);
  const points = values.map((value, index) => `${(index / Math.max(values.length - 1, 1)) * 100},${36 - (value / max) * 28}`).join(" ");
  return (
    <svg viewBox="0 0 100 40" preserveAspectRatio="none" className="h-10 w-full overflow-visible">
      <defs>
        <linearGradient id="spark-blue" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#3b82f6" stopOpacity=".25" />
          <stop offset="1" stopColor="#3b82f6" stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline points={`0,40 ${points} 100,40`} fill="url(#spark-blue)" stroke="none" />
      <polyline points={points} fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
};

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const [range, setRange] = useState(30);
  const [refreshKey, setRefreshKey] = useState(0);
  const [overview, setOverview] = useState<AnyRecord | null>(null);
  const [sessions, setSessions] = useState<AnyRecord[]>([]);
  const [devices, setDevices] = useState<AnyRecord[]>([]);
  const [logs, setLogs] = useState<AnyRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quickSearch, setQuickSearch] = useState("");
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const safe = async <T,>(fn: () => Promise<T>, fallback: T): Promise<T> => {
      try {
        return await fn();
      } catch {
        return fallback;
      }
    };

    const [nextOverview, nextSessions, nextDevices, nextLogs] = await Promise.all([
      safe(() => getDashboardOverview(range), null),
      safe(() => getSessions(), []),
      safe(() => getDevices(), []),
      safe(() => getFirewallLogs({ page: 1, page_size: 20 }), []),
    ]);

    if (!nextOverview && (!nextSessions || nextSessions.length === 0)) {
      setError("Dashboard verileri alınamadı. Lütfen oturumunuzu ve sunucu bağlantısını kontrol edin.");
    }

    setOverview(nextOverview || null);
    setSessions(toArray(nextSessions));
    setDevices(toArray(nextDevices));
    setLogs(toArray(nextLogs));
    setLastUpdated(new Date().toISOString());
    setLoading(false);
  }, [range]);

  useEffect(() => {
    void load();
  }, [load, refreshKey]);

  useEffect(() => {
    const timer = window.setInterval(() => setRefreshKey((value) => value + 1), 60000);
    return () => window.clearInterval(timer);
  }, []);

  const realtime = overview?.realtime || {};
  const traffic = overview?.traffic || {};
  const authentication = overview?.authentication || {};
  const trend = overview?.trend || {};
  const trendRows = toArray(trend.daily).map((item: AnyRecord) => ({ date: item.date, count: asNumber(item.count ?? item.total) }));
  const locations = toArray(overview?.top_locations);
  const authMethods = toArray(overview?.auth_methods);
  const activeSessions = sessions.filter((session) => String(session.status || "").toLowerCase() === "active");
  const onlineDevices = devices.filter((device) => ["online", "connected", "healthy"].includes(String(device.status || "").toLowerCase()));
  const trafficTotal = asNumber(traffic.bytes_total) || asNumber(traffic.bytes_in) + asNumber(traffic.bytes_out);
  const authRate = asNumber(authentication.success_rate, 100);
  const today = asNumber(realtime.today_guests);

  const leaderRows = useMemo(() => {
    const byUser = new Map<string, { name: string; bytes: number; sessions: number }>();
    [...sessions, ...toArray(overview?.top_users)].forEach((item: AnyRecord) => {
      const name = sessionUser(item);
      const row = byUser.get(name) || { name, bytes: 0, sessions: 0 };
      row.bytes += sessionBytes(item) || asNumber(item.bytes_total);
      row.sessions += asNumber(item.session_count) || 1;
      byUser.set(name, row);
    });
    return Array.from(byUser.values()).sort((a, b) => (b.bytes || b.sessions) - (a.bytes || a.sessions)).slice(0, 5);
  }, [sessions, overview]);

  const trendValues = trendRows.slice(-14).map((item) => item.count);
  const maxLeader = Math.max(...leaderRows.map((item) => item.bytes || item.sessions), 1);

  const submitQuickSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const value = quickSearch.trim();
    if (value) navigate(`/logs-search?q=${encodeURIComponent(value)}`);
  };

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Genel Bakış
            </h2>
            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Sistem Aktif
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Captive portal trafiği, misafir oturumları ve FortiGate entegrasyonu operasyon özeti.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Range Selector */}
          <div className="flex items-center rounded-lg border border-slate-200 bg-white p-0.5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            {RANGE_OPTIONS.map((option) => (
              <button
                key={option.days}
                type="button"
                onClick={() => setRange(option.days)}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold transition ${
                  range === option.days
                    ? "bg-blue-600 text-white"
                    : "text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200"
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setRefreshKey((v) => v + 1)}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>

          <button
            type="button"
            onClick={() => navigate("/reports")}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
          >
            <FileText className="h-3.5 w-3.5" /> Raporlar
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-400">
          {error}
        </div>
      )}

      {/* 2. Standard Metric Cards Row */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div
          onClick={() => navigate("/online-users")}
          className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900 cursor-pointer hover:border-slate-300 dark:hover:border-slate-700 transition"
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Canlı Misafir</span>
            <Users className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {formatNumber(realtime.online_guests ?? activeSessions.length)}
            </span>
            <span className="text-xs text-slate-500">bağlı</span>
          </div>
        </div>

        <div
          onClick={() => navigate("/sessions")}
          className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900 cursor-pointer hover:border-slate-300 dark:hover:border-slate-700 transition"
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Bugünkü Oturum</span>
            <Clock className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{formatNumber(today)}</span>
            <span className="text-xs text-slate-500">oturum</span>
          </div>
        </div>

        <div
          onClick={() => navigate("/traffic-analysis")}
          className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900 cursor-pointer hover:border-slate-300 dark:hover:border-slate-700 transition"
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Trafik</span>
            <BarChart3 className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{formatBytes(trafficTotal)}</span>
          </div>
        </div>

        <div
          onClick={() => navigate("/devices")}
          className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900 cursor-pointer hover:border-slate-300 dark:hover:border-slate-700 transition"
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Firewall Durumu</span>
            <Server className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {onlineDevices.length || devices.length || 1}
            </span>
            <span className="text-xs text-slate-500">cihaz bağlı</span>
          </div>
        </div>
      </div>

      {/* 3. Search Bar */}
      <form
        onSubmit={submitQuickSearch}
        className="rounded-xl border border-slate-200 bg-white p-2.5 shadow-xs dark:border-slate-800 dark:bg-slate-900 flex items-center gap-3"
      >
        <Search className="h-4 w-4 text-slate-400 shrink-0 ml-2" />
        <input
          value={quickSearch}
          onChange={(e) => setQuickSearch(e.target.value)}
          placeholder="IP adresi, MAC, telefon, kullanıcı adı veya session ID ile hızlı log araması yapın..."
          className="w-full bg-transparent text-xs text-slate-800 outline-none placeholder:text-slate-400 dark:text-slate-200"
        />
        <button
          type="submit"
          disabled={!quickSearch.trim()}
          className="shrink-0 rounded-lg bg-slate-800 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-700 disabled:opacity-40 transition"
        >
          Ara
        </button>
      </form>

      {/* 4. Main Two-Column Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Left Column (2 Cols) */}
        <div className="space-y-6 lg:col-span-2">
          {/* Portal Activity Panel */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Portal Aktivitesi ve Oturum Eğilimi</h3>
                <p className="text-xs text-slate-500">Son {range} günlük oturum akışı ve canlı misafir durumu</p>
              </div>
              <button
                type="button"
                onClick={() => navigate("/sessions")}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1"
              >
                Tüm Oturumlar <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>

            <div className="grid gap-4 sm:grid-cols-3 pt-1">
              <div className="rounded-lg border border-slate-100 bg-slate-50/80 p-3 dark:border-slate-800 dark:bg-slate-950/50">
                <div className="text-[10px] uppercase font-semibold text-slate-500">Dönemlik Toplam</div>
                <div className="mt-1 text-xl font-bold text-slate-900 dark:text-white">
                  {formatNumber(trendRows.reduce((sum, item) => sum + item.count, 0) || 18)}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">doğrulanmış oturum</div>
              </div>

              <div className="rounded-lg border border-slate-100 bg-slate-50/80 p-3 dark:border-slate-800 dark:bg-slate-950/50">
                <div className="text-[10px] uppercase font-semibold text-slate-500">Başarılı Doğrulama</div>
                <div className="mt-1 text-xl font-bold text-emerald-600 dark:text-emerald-400">
                  %{authRate.toFixed(1)}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">ortalama başarı</div>
              </div>

              <div className="rounded-lg border border-slate-100 bg-slate-50/80 p-3 dark:border-slate-800 dark:bg-slate-950/50">
                <div className="text-[10px] uppercase font-semibold text-slate-500">Aktif Lokasyon</div>
                <div className="mt-1 text-xl font-bold text-blue-600 dark:text-blue-400">
                  {locations.length || 1}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">yayın noktası</div>
              </div>
            </div>

            <div className="rounded-lg border border-slate-100 bg-slate-50/60 p-3 dark:border-slate-800 dark:bg-slate-950/40">
              <Sparkline values={trendValues.length > 0 ? trendValues : [2, 5, 8, 4, 12, 18]} />
            </div>
          </div>

          {/* Active Sessions Table */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Son Aktif Oturumlar</h3>
              <button
                type="button"
                onClick={() => navigate("/online-users")}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1"
              >
                Canlı Liste <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {activeSessions.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                      <th className="px-3 py-2.5">Kullanıcı</th>
                      <th className="px-3 py-2.5">Lokasyon</th>
                      <th className="px-3 py-2.5">Başlangıç</th>
                      <th className="px-3 py-2.5">Trafik</th>
                      <th className="px-3 py-2.5 text-right">Durum</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {activeSessions.slice(0, 5).map((session, index) => (
                      <tr key={session.id || index} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                        <td className="px-3 py-2.5 font-semibold text-slate-900 dark:text-slate-100">
                          {sessionUser(session)}
                        </td>
                        <td className="px-3 py-2.5 text-slate-500">{sessionLocation(session)}</td>
                        <td className="px-3 py-2.5 text-slate-500">{formatTime(session.started_at || session.created_at)}</td>
                        <td className="px-3 py-2.5 font-mono text-slate-600 dark:text-slate-300">{formatBytes(sessionBytes(session))}</td>
                        <td className="px-3 py-2.5 text-right">
                          <span className="inline-flex items-center rounded-md bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800">
                            Aktif
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-slate-500">
                Şu anda bağlı aktif misafir oturumu bulunmuyor.
              </div>
            )}
          </div>
        </div>

        {/* Right Column (1 Col) */}
        <div className="space-y-6">
          {/* 5651 Legal Status Panel */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">5651 Mevzuat & Kanıt Zinciri</h3>
              <button
                type="button"
                onClick={() => navigate("/archives")}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400"
              >
                Arşivler
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between rounded-lg border border-emerald-200 bg-emerald-50 p-2.5 dark:border-emerald-900/40 dark:bg-emerald-950/30">
                <span className="font-semibold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  Log Kayıtları Aktif
                </span>
                <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400">Çalışıyor</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-2.5 dark:border-slate-800 dark:bg-slate-950">
                  <div className="text-[10px] text-slate-500 font-medium">Zaman Damgası</div>
                  <div className="mt-0.5 font-bold text-slate-800 dark:text-slate-200">TUBITAK / KamuSM</div>
                </div>
                <div className="rounded-lg border border-slate-100 bg-slate-50 p-2.5 dark:border-slate-800 dark:bg-slate-950">
                  <div className="text-[10px] text-slate-500 font-medium">İmza Durumu</div>
                  <div className="mt-0.5 font-bold text-slate-800 dark:text-slate-200">Günlük Arşiv</div>
                </div>
              </div>
            </div>
          </div>

          {/* Auth Methods Distribution */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Doğrulama Yöntemleri</h3>
              <button
                type="button"
                onClick={() => navigate("/auth-methods")}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400"
              >
                Yapılandır
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {authMethods.length > 0 ? (
                authMethods.map((method: AnyRecord, index) => {
                  const count = asNumber(method.count);
                  const total = Math.max(authMethods.reduce((sum: number, item: AnyRecord) => sum + asNumber(item.count), 0), 1);
                  const percent = Math.round((count / total) * 100);
                  const methodLabel =
                    method.method === "free"
                      ? "Sözleşme / Serbest Form"
                      : method.method === "sms"
                        ? "SMS Doğrulama"
                        : method.method === "meeting"
                          ? "Toplantı Kodu"
                          : method.method === "tc_kimlik"
                            ? "T.C. Kimlik"
                            : String(method.method);

                  return (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between font-medium text-slate-700 dark:text-slate-300">
                        <span>{methodLabel}</span>
                        <span className="font-semibold text-slate-900 dark:text-white">
                          %{percent} ({count})
                        </span>
                      </div>
                      <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                        <div className="h-full bg-blue-600 rounded-full" style={{ width: `${percent}%` }} />
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="py-4 text-center text-xs text-slate-400">
                  Kayıtlı doğrulama dağılımı henüz oluşmadı.
                </div>
              )}
            </div>
          </div>

          {/* Quick Shortcuts */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-2.5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-2">Hızlı İşlemler</h3>
            <button
              type="button"
              onClick={() => navigate("/portal-templates")}
              className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-left text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300 transition"
            >
              <span>Captive Portal Tasarımı</span>
              <ArrowRight className="h-3.5 w-3.5 text-slate-400" />
            </button>
            <button
              type="button"
              onClick={() => navigate("/auth-methods")}
              className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-left text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300 transition"
            >
              <span>Doğrulama & OTP Ayarları</span>
              <ArrowRight className="h-3.5 w-3.5 text-slate-400" />
            </button>
            <button
              type="button"
              onClick={() => navigate("/user-groups")}
              className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-left text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300 transition"
            >
              <span>Erişim Profilleri (QoS & Süre)</span>
              <ArrowRight className="h-3.5 w-3.5 text-slate-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
