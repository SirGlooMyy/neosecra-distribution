import React, { useState, useEffect } from "react";
import { BarChart3, Download, RefreshCw, TrendingUp, ShieldCheck, Database, MapPin, UserCheck, HardDrive, FileSpreadsheet, FileText, Gauge, Activity, Radio, Clock } from "lucide-react";
import { getReportSummary, getDailyTrendData, downloadQuickReport, downloadReportFile } from "../lib/api";

interface DifferentiatorReportCardProps {
  id: string;
  title: string;
  description: string;
  badge: string;
  icon: React.ReactNode;
  dateRange: string;
}

const DifferentiatorReportCard: React.FC<DifferentiatorReportCardProps> = ({ id, title, description, badge, icon, dateRange }) => {
  const getFromTime = () => {
    const now = new Date();
    if (dateRange === "Bugün") {
      return new Date(now.setHours(0, 0, 0, 0)).toISOString();
    } else if (dateRange === "Son 7 Gün") {
      return new Date(now.setDate(now.getDate() - 7)).toISOString();
    } else if (dateRange === "Son 30 Gün") {
      return new Date(now.setDate(now.getDate() - 30)).toISOString();
    }
    return "";
  };

  const handleExportCSV = () => {
    const fromTime = getFromTime();
    const params = new URLSearchParams({ report_type: id, format: "csv" });
    if (fromTime) params.set("date_from", fromTime);
    void downloadReportFile(`/reports/differentiator/export?${params.toString()}`, `${id}.csv`);
  };

  const handleExportPDF = () => {
    const fromTime = getFromTime();
    const params = new URLSearchParams({ report_type: id, format: "pdf" });
    if (fromTime) params.set("date_from", fromTime);
    void downloadReportFile(`/reports/differentiator/export?${params.toString()}`, `${id}.pdf`);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 flex flex-col justify-between hover:border-indigo-200 dark:hover:border-indigo-900 transition-colors">
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="p-2.5 bg-blue-50 dark:bg-indigo-950/40 rounded-xl text-blue-600 dark:text-indigo-400">
            {icon}
          </div>
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
            {badge}
          </span>
        </div>
        <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base mb-1">{title}</h3>
        <p className="text-xs text-slate-500 line-clamp-2">{description}</p>
      </div>

      <div className="flex items-center space-x-2 pt-2 border-t border-slate-100 dark:border-slate-800">
        <button
          onClick={handleExportCSV}
          className="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs font-semibold transition-colors"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 mr-1.5" />
          CSV İndir
        </button>
        <button
          onClick={handleExportPDF}
          className="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-blue-50 dark:bg-indigo-950/30 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 text-indigo-700 dark:text-indigo-400 rounded-xl text-xs font-semibold transition-colors"
        >
          <FileText className="w-3.5 h-3.5 mr-1.5" />
          PDF İndir
        </button>
      </div>
    </div>
  );
};

interface QuickReportCardProps {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  accent: string;
}

const QuickReportCard: React.FC<QuickReportCardProps> = ({ id, title, description, icon, accent }) => {
  const [busy, setBusy] = useState<"pdf" | "csv" | null>(null);

  const download = async (format: "pdf" | "csv") => {
    setBusy(format);
    try {
      await downloadQuickReport(id, { days: 30, format });
    } catch (error) {
      console.error("Hızlı rapor indirilemedi", error);
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-indigo-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
      <div className={`absolute inset-x-0 top-0 h-1 ${accent}`} />
      <div className="mb-4 flex items-start justify-between gap-3">
        <div className="rounded-xl bg-blue-50 p-2.5 text-blue-600 dark:bg-indigo-950/40 dark:text-indigo-300">{icon}</div>
        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-slate-500 dark:bg-slate-800 dark:text-slate-400">30 gün</span>
      </div>
      <h4 className="mb-1 text-sm font-bold text-slate-900 dark:text-slate-100">{title}</h4>
      <p className="mb-5 min-h-[34px] text-xs leading-5 text-slate-500">{description}</p>
      <div className="flex gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
        <button
          type="button"
          disabled={Boolean(busy)}
          onClick={() => void download("pdf")}
          className="inline-flex flex-1 items-center justify-center rounded-xl bg-blue-600 px-3 py-2 text-xs font-bold text-white transition hover:bg-indigo-700 disabled:cursor-wait disabled:opacity-60"
        >
          {busy === "pdf" ? <RefreshCw className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <FileText className="mr-1.5 h-3.5 w-3.5" />}
          PDF al
        </button>
        <button
          type="button"
          disabled={Boolean(busy)}
          onClick={() => void download("csv")}
          className="inline-flex items-center justify-center rounded-xl bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700 transition hover:bg-emerald-100 disabled:cursor-wait disabled:opacity-60 dark:bg-emerald-950/30 dark:text-emerald-300"
          aria-label={`${title} CSV indir`}
        >
          {busy === "csv" ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <FileSpreadsheet className="h-3.5 w-3.5" />}
        </button>
      </div>
    </div>
  );
};

export const ReportsPage: React.FC = () => {
  const [dateRange, setDateRange] = useState("Son 7 Gün");
  const [summary, setSummary] = useState<any>({ total: 0, by_status: {}, by_auth_method: {}, bytes_total: 0, avg_duration_minutes: 0 });
  const [dailyTrend, setDailyTrend] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        let fromTime = "";
        const now = new Date();
        if (dateRange === "Bugün") {
          fromTime = new Date(now.setHours(0, 0, 0, 0)).toISOString();
        } else if (dateRange === "Son 7 Gün") {
          fromTime = new Date(now.setDate(now.getDate() - 7)).toISOString();
        } else if (dateRange === "Son 30 Gün") {
          fromTime = new Date(now.setDate(now.getDate() - 30)).toISOString();
        }

        const results = await Promise.allSettled([
          getReportSummary(fromTime),
          // getDailyTrendData(customerId, days): keep the platform/global
          // scope implicit and pass the selected period as the second arg.
          getDailyTrendData(undefined, dateRange === "Son 30 Gün" ? 30 : 7),
        ]);

        if (results[0].status === "fulfilled" && results[0].value) setSummary(results[0].value);
        if (results[1].status === "fulfilled" && results[1].value) {
          // The dashboard endpoint returns an envelope ({ daily, weekly, ... })
          // while older installations returned the array directly. Keep the
          // chart tolerant of both response shapes so a backend mismatch never
          // crashes the whole Reports page.
          const trendPayload: any = results[1].value;
          const daily = Array.isArray(trendPayload)
            ? trendPayload
            : Array.isArray(trendPayload.daily)
              ? trendPayload.daily
              : Array.isArray(trendPayload.data)
                ? trendPayload.data
                : [];
          setDailyTrend(daily);
        }
        results.forEach((result) => {
          if (result.status === "rejected") console.warn("Rapor bileşeni yüklenemedi", result.reason);
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [dateRange]);

  const handleExport = () => {
    let fromTime = "";
    const now = new Date();
    if (dateRange === "Bugün") {
      fromTime = new Date(now.setHours(0, 0, 0, 0)).toISOString();
    } else if (dateRange === "Son 7 Gün") {
      fromTime = new Date(now.setDate(now.getDate() - 7)).toISOString();
    } else if (dateRange === "Son 30 Gün") {
      fromTime = new Date(now.setDate(now.getDate() - 30)).toISOString();
    }
    const params = new URLSearchParams({ format: "csv" });
    if (fromTime) params.set("date_from", fromTime);
    void downloadReportFile(`/reports/sessions/export?${params.toString()}`, "sessions.csv");
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const maxTrendCount = dailyTrend.length > 0 ? Math.max(...dailyTrend.map(d => d.count), 1) : 1;
  const sessionChartData = dailyTrend.map((d: any) => {
    const parts = d.date.split("-");
    const label = parts.length === 3 ? `${parts[2]}/${parts[1]}` : d.date;
    const pct = Math.max(10, Math.round((d.count / maxTrendCount) * 100));
    return {
      label,
      value: d.count,
      heightStyle: { height: `${pct}%` }
    };
  });

  const totalAuthCount = Object.values(summary.by_auth_method || {}).reduce((a: any, b: any) => a + b, 0) as number;
  const authMethodsBreakdown = Object.entries(summary.by_auth_method || {}).map(([method, count]: [string, any], idx) => {
    const pct = totalAuthCount > 0 ? Math.round((count / totalAuthCount) * 100) : 0;
    const colors = ["bg-indigo-600", "bg-violet-600", "bg-pink-600", "bg-emerald-600", "bg-amber-600", "bg-teal-600"];
    const labels: Record<string, string> = {
      sms: "SMS OTP Doğrulama",
      tc: "T.C. Kimlik Doğrulama",
      voucher: "Bilet / Voucher Girişi",
      free: "Ücretsiz Giriş",
      whatsapp: "WhatsApp Doğrulama",
      ldap: "LDAP Entegrasyonu"
    };
    return {
      label: labels[method] || method.toUpperCase(),
      percentage: pct,
      count,
      color: colors[idx % colors.length]
    };
  });

  if (loading) {
    return (
      <div className="flex justify-center items-center py-24 space-x-2">
        <RefreshCw className="w-6 h-6 text-indigo-500 animate-spin" />
        <span className="text-sm font-medium text-slate-500">Raporlar yükleniyor...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Raporlar &amp; Analitik
            </h2>
            <span className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <BarChart3 className="h-3 w-3 text-blue-500" />
              FortiGate + 5651 Uyumlu
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Firewall Analyzer olaylarını, VPN trafiğini, misafir oturum kullanımını ve 5651 yasal rapor setlerini tek merkezden dışa aktarın.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 shadow-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="Bugün">Bugün</option>
            <option value="Son 7 Gün">Son 7 Gün</option>
            <option value="Son 30 Gün">Son 30 Gün</option>
          </select>

          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
          >
            <Download className="h-3.5 w-3.5" />
            Genel Oturum Raporu (CSV)
          </button>
        </div>
      </div>

      {/* 2. Standard 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Oturum</span>
            <TrendingUp className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{summary.total.toLocaleString("tr-TR")}</span>
            <span className="text-xs text-slate-500">oturum</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Ortalama Süre</span>
            <Activity className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{summary.avg_duration_minutes} dk</span>
            <span className="text-xs text-slate-500">oturum başı</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Veri Tüketimi</span>
            <Database className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{formatBytes(summary.bytes_total)}</span>
            <span className="text-xs text-slate-500">toplam hacim</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Aktif Metotlar</span>
            <UserCheck className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">{authMethodsBreakdown.length}</span>
            <span className="text-xs text-slate-500">doğrulama yöntemi</span>
          </div>
        </div>
      </div>

      {/* 3. Operator Presets */}
      <section className="space-y-4 rounded-xl border border-slate-200 bg-slate-50/50 p-5 dark:border-slate-800 dark:bg-slate-900/50">
        <div className="flex flex-wrap items-end justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <Gauge className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Tek Tık Hazır Operasyon Raporları</h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Analyzer ve captive portal verisini birleştirir; yöneticiye gönderilebilir düzenli PDF/CSV üretir.</p>
          </div>
          <span className="rounded-md border border-slate-200 bg-white px-2.5 py-0.5 text-[11px] font-semibold text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
            FortiGate + Portal
          </span>
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          <QuickReportCard
            id="vpn_activity_30d"
            title="VPN Canlı / Tünel (Tunnel-Up) Raporu"
            description="Sadece canlı tünel kurma (tunnel-up) bağlantı anı kayıtları, sanal IP ve kullanıcı bilgisi."
            icon={<Radio className="h-4 w-4" />}
            accent="bg-blue-600"
          />
          <QuickReportCard
            id="vpn_duration_audit_30d"
            title="VPN Detaylı Süre & Kullanım Raporu"
            description="Kullanıcı bazlı toplam içeride kalma süresi, bağlandığı günler ve indirilen/yüklenen veri hacmi."
            icon={<Clock className="h-4 w-4" />}
            accent="bg-indigo-600"
          />
          <QuickReportCard
            id="top_bandwidth_users_30d"
            title="En Çok Bant Genişliği Tüketenler"
            description="Trafik kayıtlarından kullanıcı/IP bazlı bant genişliği ve transfer sıralaması."
            icon={<Gauge className="h-4 w-4" />}
            accent="bg-emerald-600"
          />
          <QuickReportCard
            id="firewall_security_30d"
            title="Firewall Güvenlik Özeti"
            description="İzin, engelleme, UTM ve kritik güvenlik olaylarının konsolide özeti."
            icon={<ShieldCheck className="h-4 w-4" />}
            accent="bg-rose-600"
          />
          <QuickReportCard
            id="captive_portal_usage_30d"
            title="Portal Kullanım Özeti"
            description="Oturum, doğrulama metodu, lokasyon ve veri tüketim dağılımı."
            icon={<Activity className="h-4 w-4" />}
            accent="bg-blue-600"
          />
        </div>
      </section>

      {/* 4. Daily Oturum Trend & Auth breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Daily Oturum Trend Chart */}
        <div className="lg:col-span-8 rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-1">
              <BarChart3 className="w-4 h-4 text-blue-600" />
              Günlük Oturum İstatistikleri
            </h3>
            <p className="text-xs text-slate-500 mb-6">Seçilen periyoda ait toplam Wi-Fi bağlantı oturumu grafiği.</p>
          </div>
          {/* Chart Columns Area */}
          <div className="flex items-end justify-between h-56 px-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            {sessionChartData.length === 0 ? (
              <div className="flex items-center justify-center w-full h-full text-slate-400 text-xs">
                Grafik verisi bulunamadı.
              </div>
            ) : (
              sessionChartData.map((d, index) => (
                <div key={index} className="flex flex-col items-center space-y-2 flex-1 group">
                  <div className="opacity-0 group-hover:opacity-100 bg-slate-800 text-white text-[10px] px-1.5 py-0.5 rounded transition-opacity duration-150 -translate-y-1 font-mono">
                    {d.value}
                  </div>
                  <div 
                    className="w-7 bg-blue-600 hover:bg-blue-700 rounded-t transition-all duration-200"
                    style={d.heightStyle}
                  />
                  <span className="text-[10px] text-slate-400 font-mono">{d.label}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Auth breakdown percentage bars */}
        <div className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Giriş Metotları Dağılımı</h3>
            <p className="text-xs text-slate-500">Misafirlerin Wi-Fi doğrulamada tercih ettiği yöntemler.</p>
          </div>
          <div className="space-y-4">
            {authMethodsBreakdown.length === 0 ? (
              <div className="text-slate-400 text-xs py-8 text-center">
                Veri bulunamadı.
              </div>
            ) : (
              authMethodsBreakdown.map((m, index) => (
                <div key={index} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-600 dark:text-slate-400">{m.label}</span>
                    <span className="text-slate-800 dark:text-slate-200">%{m.percentage} ({m.count})</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div 
                      className={`${m.color} h-2 rounded-full transition-all duration-500`}
                      style={{ width: `${m.percentage}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>


      {/* Differentiator Reports Section (Phase 4) */}
      <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Farklılaştırıcı Rapor Setleri</h3>
          <p className="text-xs text-slate-500">5651 yasal uyum, mahkeme delil paketleri ve ileri düzey operasyonel raporlar.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <DifferentiatorReportCard
            id="5651_evidence"
            title="5651 Mahkeme Delil Paketi"
            description="Mahkeme ve kolluk kuvvetlerine sunulabilir imzalı hash zincirli yasal delil paketi."
            badge="Yasal Uyum"
            icon={<ShieldCheck className="w-5 h-5" />}
            dateRange={dateRange}
          />

          <DifferentiatorReportCard
            id="ip_identity_matrix"
            title="IP ↔ Kimlik Korelasyon Matrisi"
            description="IP, MAC, Telefon, TC Kimlik ve Voucher doğrulamalarının uçtan uca korelasyon matrisi."
            badge="Güvenlik"
            icon={<Database className="w-5 h-5" />}
            dateRange={dateRange}
          />

          <DifferentiatorReportCard
            id="venue_density"
            title="Lokasyon & Mekan Yoğunluk"
            description="Mekan ve şube bazlı Wi-Fi bağlantı yoğunluğu, ortalama kalınan süre ve data tüketimi."
            badge="Mekan Analitiği"
            icon={<MapPin className="w-5 h-5" />}
            dateRange={dateRange}
          />

          <DifferentiatorReportCard
            id="operator_audit"
            title="BTK / Operatör Denetim Raporu"
            description="Sistem yöneticisi işlem izleri, kural güncellemeleri ve denetim günlükleri."
            badge="Denetim"
            icon={<UserCheck className="w-5 h-5" />}
            dateRange={dateRange}
          />

          <DifferentiatorReportCard
            id="quota_license_usage"
            title="Kota & Lisans Kullanım Raporu"
            description="Aktif cihaz ve kullanıcı oturum lisansı tüketimi ile bandwidth kota analizleri."
            badge="Lisans & Kota"
            icon={<HardDrive className="w-5 h-5" />}
            dateRange={dateRange}
          />
        </div>
      </div>
    </div>
  );
};
