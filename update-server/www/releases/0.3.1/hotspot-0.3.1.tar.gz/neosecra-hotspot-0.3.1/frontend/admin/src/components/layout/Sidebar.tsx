import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { logout } from '../../lib/api'
import { ChevronDown, LogOut } from 'lucide-react'
import {
  Home, Users, MapPin, Server,
  Globe, Key, Hotel, Clock, Wifi, FileStack, Bell, AlertTriangle,
  Database, PenSquare, Activity, BarChart2, Calendar, Settings, Search, UserCheck, Award, RefreshCw, ShieldCheck, Zap,
} from 'lucide-react'

interface MenuItem {
  label: string
  path: string
  icon: any
}

interface MenuSection {
  title: string
  items: MenuItem[]
}

const sections: MenuSection[] = [
  {
    title: 'Genel',
    items: [
      { label: 'Genel Bakış', path: '/', icon: Home },
      { label: 'Hızlı Kurulum ⚡', path: '/quick-setup', icon: Zap },
      { label: 'Lokasyonlar', path: '/locations', icon: MapPin },
    ],
  },
  {
    title: 'Altyapı',
    items: [
      { label: 'Cihazlar', path: '/devices', icon: Server },
    ],
  },
  {
    title: 'Kullanıcılar',
    items: [
      { label: 'Erişim Profilleri', path: '/user-groups', icon: Users },
      { label: 'Kullanıcı Yönetimi', path: '/users', icon: Users },
    ],
  },
  {
    title: 'Portal',
    items: [
      { label: 'Captive Portal', path: '/portal-templates', icon: Globe },
      { label: 'Auth Yöntemleri', path: '/auth-methods', icon: Key },
      { label: 'VPN 2FA / MFA', path: '/vpn-mfa', icon: ShieldCheck },
      { label: 'Otel / PMS', path: '/pms-config', icon: Hotel },
    ],
  },
  {
    title: 'İzleme',
    items: [
      { label: 'Oturumlar', path: '/sessions', icon: Clock },
      { label: 'Onay İstekleri', path: '/approval-requests', icon: UserCheck },
      { label: 'Online Kullanıcılar', path: '/online-users', icon: Wifi },
      { label: 'Firewall Analyzer', path: '/firewall-logs', icon: FileStack },
      { label: 'Syslog Triggers', path: '/syslog-triggers', icon: Bell },
      { label: 'Alarm Panosu', path: '/alarm-dashboard', icon: AlertTriangle },
    ],
  },
  {
    title: 'Loglar & Raporlar',
    items: [
      { label: '5651 Logları', path: '/archives', icon: Database },
      { label: 'Signing Config', path: '/signing-config', icon: PenSquare },
      { label: 'Trafik Analizi', path: '/traffic-analysis', icon: Activity },
      { label: 'Raporlar', path: '/reports', icon: BarChart2 },
      { label: 'Report Scheduler', path: '/report-scheduler', icon: Calendar },
    ],
  },
    {
      title: 'Sistem',
      items: [
        { label: 'Ayarlar', path: '/settings', icon: Settings },
        { label: 'Platform Lisansı', path: '/platform-license', icon: Award },
        { label: 'Güncelleme Merkezi', path: '/platform-upgrade', icon: RefreshCw },
      ],
  },
]

export const Sidebar: React.FC<{
  className?: string
  isOpen?: boolean
  onClose?: () => void
}> = ({ className = '', isOpen = false, onClose }) => {
  const navigate = useNavigate()
  const location = useLocation()
  const [expanded, setExpanded] = useState<string[]>([
    'Genel', 'Altyapı', 'Kullanıcılar', 'Portal',
    'İzleme', 'Loglar & Raporlar', 'Sistem',
  ])

  const toggleSection = (title: string) => {
    setExpanded(prev =>
      prev.includes(title) ? prev.filter(t => t !== title) : [...prev, title]
    )
  }

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/'
    // /firewall-log is the legacy singular bookmark for the Analyzer route.
    // Keep the canonical sidebar item highlighted for both URLs.
    if (path === '/firewall-logs') {
      return location.pathname === '/firewall-logs' || location.pathname === '/firewall-log'
    }
    return location.pathname.startsWith(path)
  }

  const handleLogout = () => {
    if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
      logout()
    }
  }

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 z-20 bg-black/60 backdrop-blur-sm md:hidden" onClick={() => onClose?.()} />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-30 flex w-64 flex-col border-r border-border bg-surface-secondary p-5 transition-transform duration-200 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 md:static ${className}`}
      >
        <div className="mb-6 flex items-center space-x-3 px-2">
          <div className="flex items-center justify-center rounded-lg bg-blue-600 p-2 text-white shadow-xs">
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">
            Hotspot
          </span>
        </div>

        <nav className="flex-1 space-y-4 overflow-y-auto pr-1">
          {sections.map((section) => {
            const isExpanded = expanded.includes(section.title)
            const hasActive = section.items.some(i => isActive(i.path))
            return (
              <div key={section.title}>
                <button
                  onClick={() => toggleSection(section.title)}
                  className={`flex w-full items-center justify-between px-4 py-1.5 text-[10px] font-semibold uppercase tracking-widest transition-colors ${
                    hasActive && !isExpanded
                      ? 'text-primary'
                      : 'text-muted'
                  } hover:text-primary`}
                >
                  {section.title}
                  <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                </button>
                {isExpanded && (
                  <ul className="mt-1 space-y-0.5">
                    {section.items.map((item) => {
                      const Icon = item.icon
                      const active = isActive(item.path)
                      return (
                        <li key={item.label}>
                          <a
                            href={item.path}
                            onClick={(e) => { e.preventDefault(); navigate(item.path); onClose?.() }}
                            className={`flex items-center rounded-lg px-4 py-2 text-xs font-semibold transition-colors ${
                              active
                                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400 font-bold'
                                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-850 dark:hover:text-slate-200'
                            }`}
                          >
                            <Icon className={`mr-3 h-4 w-4 ${active ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}`} />
                            {item.label}
                          </a>
                        </li>
                      )
                    })}
                  </ul>
                )}
              </div>
            )
          })}
        </nav>

        <div className="mt-auto border-t border-border pt-4">
          <div className="flex items-center justify-between rounded-lg border border-border bg-white/[0.01] p-2.5 transition-colors hover:bg-white/[0.03]">
            <div className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-600 text-xs font-bold text-white shadow-xs">
                H
              </div>
              <div className="min-w-0">
                <div className="truncate text-xs font-semibold text-primary">Hasan Coşan</div>
                <div className="text-[10px] uppercase tracking-wider text-muted">Süper Admin</div>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="rounded-md p-1.5 text-muted transition-colors hover:bg-rose-500/10 hover:text-rose-400"
              aria-label="Çıkış Yap"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  )
}

