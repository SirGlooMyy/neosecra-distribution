import React, { useEffect, useState } from "react";
import {
  getSigningConfig,
  updateSigningConfig,
  testSigningConnection,
  signArchive,
  verifyArchive,
  getCertificates,
  getArchiveVerificationResults,
  getLogArchives,
} from "../lib/api";
import {
  Save,
  Plug,
  PenSquare,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Shield,
  FileBadge,
  Eye,
} from "lucide-react";

interface SigningArchiveRow {
  id: string;
  customerName: string;
  date: string;
  recordCount: number;
  fileSizeKb: number;
  hash: string;
  isSigned: boolean;
  signatureOrigin: string | null;
  signMethod: string | null;
  certificateSerial: string | null;
  signedAt: string | null;
}

const SIGNATURE_ORIGIN_LABELS: Record<string, string> = {
  kamusm: "KamuSM",
  localfile: "Yerel sertifika",
  demo: "Demo",
  unknown: "Bilinmiyor",
};

const SIGN_METHOD_LABELS: Record<string, string> = {
  kamusm: "KamuSM",
  localfile: "Yerel sertifika",
  pkcs11: "PKCS#11",
};

const SIGNATURE_ORIGIN_TONES: Record<string, string> = {
  kamusm: "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 border-emerald-100 dark:border-emerald-900/40",
  localfile: "bg-indigo-50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-300 border-indigo-100 dark:border-indigo-900/40",
  demo: "bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-300 border-amber-100 dark:border-amber-900/40",
  unknown: "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700",
};

const formatSignatureOrigin = (value?: string | null) =>
  SIGNATURE_ORIGIN_LABELS[value || "unknown"] || value || "Bilinmiyor";

const formatSignMethod = (value?: string | null) =>
  SIGN_METHOD_LABELS[value || ""] || value || "-";

const originToneClass = (value?: string | null) =>
  SIGNATURE_ORIGIN_TONES[value || "unknown"] || SIGNATURE_ORIGIN_TONES.unknown;

const formatDateTime = (value?: string | null) =>
  value ? new Date(value).toLocaleString("tr-TR") : "-";

const mapArchiveRow = (a: any): SigningArchiveRow => ({
  id: String(a.id),
  customerName: a.customer_name || a.customerName || "Bilinmeyen",
  date: a.period_start ? new Date(a.period_start).toLocaleDateString("tr-TR") : "-",
  recordCount: Number(a.item_count ?? a.record_count ?? 0),
  fileSizeKb: Math.round(Number(a.content_size ?? 0) / 1024),
  hash: String(a.content_hash || a.hash || ""),
  isSigned: Boolean(a.signature_value),
  signatureOrigin: a.signature_origin ?? a.meta?.signature_origin ?? null,
  signMethod: a.sign_method ?? null,
  certificateSerial: a.certificate_serial ?? null,
  signedAt: a.signature_time ?? null,
});

export const SigningConfigPage: React.FC = () => {
  const [config, setConfig] = useState<any>(null);
  const [certs, setCerts] = useState<any[]>([]);
  const [verifications, setVerifications] = useState<any[]>([]);
  const [archives, setArchives] = useState<SigningArchiveRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [signingArchive, setSigningArchive] = useState(false);
  const [selectedArchiveId, setSelectedArchiveId] = useState("");
  const [signResult, setSignResult] = useState<any>(null);
  const [verifyResult, setVerifyResult] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"config" | "status" | "verify">("config");

  const loadData = async () => {
    setLoading(true);
    try {
      const [c, certsData, verData, archData] = await Promise.all([
        getSigningConfig(),
        getCertificates(),
        getArchiveVerificationResults(),
        getLogArchives(),
      ]);
      setConfig(c);
      setCerts(certsData);
      setVerifications(verData);
      setArchives((archData || []).map(mapArchiveRow));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showSuccess = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleSave = async () => {
    if (!config) return;
    try {
      await updateSigningConfig(config);
      showSuccess();
    } catch (err) {
      console.error(err);
    }
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await testSigningConnection();
      setTestResult(res);
    } catch (err: any) {
      setTestResult({ success: false, message: err.message });
    } finally {
      setTesting(false);
    }
  };

  const handleSign = async () => {
    if (!selectedArchiveId) return;
    setSigningArchive(true);
    setSignResult(null);
    try {
      const res = await signArchive(selectedArchiveId);
      setSignResult({
        ...res,
        success: true,
        message: "Arşiv başarıyla imzalandı.",
      });
      loadData();
    } catch (err: any) {
      setSignResult({ success: false, message: err.message });
    } finally {
      setSigningArchive(false);
    }
  };

  const handleVerify = async (archiveId: string) => {
    setVerifyResult(null);
    try {
      const res = await verifyArchive(archiveId);
      const success = Boolean(res?.overall_ok ?? res?.ok ?? res?.success ?? false);
      setVerifyResult({
        ...res,
        success,
        message: res?.message || (success ? "Arşiv doğrulandı." : "Arşiv doğrulanamadı."),
      });
      loadData();
    } catch (err: any) {
      setVerifyResult({ success: false, message: err.message });
    }
  };

  const signedCount = archives.filter((a) => a.isSigned).length;
  const unsignedCount = archives.filter((a) => !a.isSigned).length;

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              5651 Log İmzalama &amp; Zaman Damgası
            </h2>
            <span className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <Shield className="h-3 w-3 text-emerald-500" />
              KamuSM / RFC 3161 Mühürleme
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            TÜBİTAK KamuSM ve Yerel Kriptografik Sertifika ile 5651 log arşivlerinin elektronik mühürleme ve doğrulama süreçleri.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleTest}
            disabled={testing}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            {testing ? (
              <RefreshCw className="h-3.5 w-3.5 text-blue-600 animate-spin" />
            ) : (
              <Plug className="h-3.5 w-3.5 text-slate-500" />
            )}
            Bağlantıyı Test Et
          </button>
          <button
            onClick={handleSave}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
          >
            <Save className="h-3.5 w-3.5" />
            Kaydet
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/50 rounded-xl text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          Yapılandırma ayarları başarıyla kaydedildi!
        </div>
      )}

      {/* 2. Standard 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">İmzalama Modu</span>
            <Shield className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white">
              {config?.kamusm_username ? "KamuSM API" : "Yerel Sertifika"}
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Mühürlü Arşivler</span>
            <FileBadge className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{signedCount}</span>
            <span className="text-xs text-slate-500">dosya</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Bekleyen Arşivler</span>
            <PenSquare className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{unsignedCount}</span>
            <span className="text-xs text-slate-500">imza bekliyor</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Sertifika Durumu</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
              {config?.kamusm_username ? "KamuSM Bağlı" : "Yerel Aktif"}
            </span>
            <span className="text-xs text-slate-500">Mühürleme Hazır</span>
          </div>
        </div>
      </div>

      {/* 3. Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-1">
        <div className="flex gap-1">
          {(["config", "status", "verify"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold border-b-2 transition ${
                activeTab === tab
                  ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                  : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
              }`}
            >
              {tab === "config" ? (
                <Shield className="w-3.5 h-3.5" />
              ) : tab === "status" ? (
                <FileBadge className="w-3.5 h-3.5" />
              ) : (
                <Eye className="w-3.5 h-3.5" />
              )}
              {tab === "config" ? "KamuSM Yapılandırması" : tab === "status" ? "İmza Durumu" : "Arşiv Doğrulama"}
            </button>
          ))}
        </div>
      </div>


      {activeTab === "config" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
              TÜBİTAK KamuSM Bağlantı Ayarları
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Kullanıcı Adı</label>
                <input
                  type="text"
                  value={config?.kamusm_username || ""}
                  onChange={(e) =>
                    setConfig({ ...(config || {}), kamusm_username: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Şifre</label>
                <input
                  type="password"
                  value={config?.kamusm_password || ""}
                  onChange={(e) =>
                    setConfig({ ...(config || {}), kamusm_password: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl space-y-2">
              <h4 className="text-xs font-semibold text-slate-500">Sertifika Bilgisi</h4>
              <div className="text-sm text-slate-700 dark:text-slate-300">
                <p>
                  <span className="text-slate-400">Subject:</span> {config?.certificate_subject || "-"}
                </p>
                <p>
                  <span className="text-slate-400">Issuer:</span> {config?.certificate_issuer || "-"}
                </p>
                <p>
                  <span className="text-slate-400">Seri:</span> {config?.certificate_serial || "-"}
                </p>
                <p>
                  <span className="text-slate-400">Geçerlilik:</span> {config?.certificate_valid_until || "-"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={handleSave}
                className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold"
              >
                <Save className="w-4 h-4 mr-2" /> Kaydet
              </button>
              <button
                onClick={handleTest}
                disabled={testing}
                className="inline-flex items-center px-4 py-2 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl text-sm font-semibold disabled:opacity-50"
              >
                {testing ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Plug className="w-4 h-4 mr-2" />
                )}{" "}
                Bağlantıyı Test Et
              </button>
            </div>
            {testResult && (
              <div
                className={`p-3 rounded-xl text-sm font-medium flex items-start space-x-2 ${
                  testResult.success
                    ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 border border-emerald-100"
                    : "bg-rose-50 dark:bg-rose-950/20 text-rose-800 border border-rose-100"
                }`}
              >
                {testResult.success ? (
                  <CheckCircle2 className="w-4 h-4 mt-0.5" />
                ) : (
                  <XCircle className="w-4 h-4 mt-0.5" />
                )}
                <span>{testResult.message}</span>
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
              Bağlantı Durumu
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Durum</span>
                <span
                  className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                    config?.is_connected
                      ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700"
                      : "bg-rose-50 dark:bg-rose-950/30 text-rose-700"
                  }`}
                >
                  {config?.is_connected ? "Bağlı" : "Bağlı Değil"}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Son İmza</span>
                <span className="text-xs">{formatDateTime(config?.last_signed_at)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Son İmza Kaynağı</span>
                <span
                  className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${originToneClass(
                    config?.last_signature_origin,
                  )}`}
                >
                  {formatSignatureOrigin(config?.last_signature_origin)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Sonraki İmza</span>
                <span className="text-xs">
                  {config?.next_scheduled ? new Date(config.next_scheduled).toLocaleString("tr-TR") : "-"}
                </span>
              </div>
            </div>
            {config?.last_signature_origin === "demo" && (
              <div className="rounded-xl border border-amber-200 dark:border-amber-900/50 bg-amber-50 dark:bg-amber-950/20 p-3 text-xs text-amber-800 dark:text-amber-300">
                Son imza demo modda üretildi. Gerçek KamuSM bağlantısı doğrulanana kadar bu kayıtlar test amaçlı sayılmalı.
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === "status" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
                Manuel İmzalama
              </h3>
              <div className="flex gap-3">
                <select
                  value={selectedArchiveId}
                  onChange={(e) => setSelectedArchiveId(e.target.value)}
                  className="flex-1 px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Arşiv seçin...</option>
                  {archives.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.customerName} - {a.date}
                      {a.signatureOrigin ? ` - ${formatSignatureOrigin(a.signatureOrigin)}` : ""}
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleSign}
                  disabled={signingArchive || !selectedArchiveId}
                  className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-sm font-semibold"
                >
                  {signingArchive ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <PenSquare className="w-4 h-4 mr-2" />
                  )}
                  İmzala
                </button>
              </div>
              {signResult && (
                <div
                  className={`p-3 rounded-xl text-sm font-medium border ${
                    signResult.success
                      ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 border-emerald-100"
                      : "bg-rose-50 dark:bg-rose-950/20 text-rose-800 border-rose-100"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <span>{signResult.message}</span>
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${originToneClass(
                        signResult.signature_origin,
                      )}`}
                    >
                      {formatSignatureOrigin(signResult.signature_origin)}
                    </span>
                  </div>
                  <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-2 text-xs text-slate-500">
                    <span>İmza yöntemi: {formatSignMethod(signResult.sign_method)}</span>
                    <span>İmza zamanı: {formatDateTime(signResult.signing_time)}</span>
                    <span>Sertifika: {signResult.certificate_serial || "-"}</span>
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
                Sertifikalar
              </h3>
              {certs.length === 0 ? (
                <p className="text-sm text-slate-400">Sertifika bulunamadı.</p>
              ) : (
                <div className="space-y-3">
                  {certs.map((cert) => (
                    <div key={cert.id} className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Subject</span>
                        <span className="font-medium text-xs">{cert.subject}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Issuer</span>
                        <span className="text-xs">{cert.issuer}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Geçerlilik</span>
                        <span className="text-xs">
                          {cert.valid_from} - {cert.valid_until}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Durum</span>
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                            cert.is_valid
                              ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700"
                              : "bg-rose-50 dark:bg-rose-950/30 text-rose-700"
                          }`}
                        >
                          {cert.is_valid ? "Geçerli" : "Geçersiz"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === "verify" && (
        <div className="space-y-4">
          <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Arşiv</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">İmza Zamanı</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Kaynak</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Yöntem</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Sertifika</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Hash</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Durum</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">
                      İşlem
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {archives.map((a) => (
                    <tr key={a.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                      <td className="px-6 py-4 text-sm text-slate-800 dark:text-slate-200">
                        {a.customerName} - {a.date}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-500">{formatDateTime(a.signedAt)}</td>
                      <td className="px-6 py-4 text-sm">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${originToneClass(
                            a.signatureOrigin,
                          )}`}
                        >
                          {formatSignatureOrigin(a.signatureOrigin)}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-500">{formatSignMethod(a.signMethod)}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">
                        <span className="font-mono text-xs">{a.certificateSerial || "-"}</span>
                      </td>
                      <td className="px-6 py-4 text-sm font-mono text-xs text-slate-500 max-w-[140px] truncate" title={a.hash}>
                        {a.hash ? `${a.hash.slice(0, 16)}...` : "-"}
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                            a.isSigned
                              ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100"
                              : "bg-slate-100 dark:bg-slate-800 text-slate-500 border-slate-200"
                          }`}
                        >
                          {a.isSigned ? "İmzalı" : "Bekliyor"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => handleVerify(a.id)}
                          className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5 mr-1" /> Doğrula
                        </button>
                      </td>
                    </tr>
                  ))}
                  {archives.length === 0 && (
                    <tr>
                      <td colSpan={8} className="px-6 py-12 text-center text-slate-500">
                        Arşiv bulunamadı.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {verifyResult && (
            <div
              className={`p-4 rounded-xl border flex items-start space-x-3 ${
                verifyResult.success
                  ? "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/50 text-emerald-800 dark:text-emerald-300"
                  : "bg-rose-50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50 text-rose-800 dark:text-rose-300"
              }`}
            >
              {verifyResult.success ? (
                <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
              ) : (
                <XCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              )}
              <div className="flex-1 text-sm font-medium">{verifyResult.message}</div>
            </div>
          )}

          {verifications.length > 0 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
                Doğrulama Geçmişi
              </h3>
              <div className="space-y-2">
                {verifications.map((v) => {
                  const isValid = Boolean(v.is_valid ?? v.overall_ok ?? v.success);
                  return (
                    <div
                      key={v.id}
                      className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-sm"
                    >
                      <div className="flex items-center gap-3">
                        {isValid ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <XCircle className="w-4 h-4 text-rose-600" />
                        )}
                        <span className="text-slate-600 dark:text-slate-400">{v.message}</span>
                      </div>
                      <span className="text-xs text-slate-400">
                        {v.verified_at ? new Date(v.verified_at).toLocaleString("tr-TR") : "-"}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
