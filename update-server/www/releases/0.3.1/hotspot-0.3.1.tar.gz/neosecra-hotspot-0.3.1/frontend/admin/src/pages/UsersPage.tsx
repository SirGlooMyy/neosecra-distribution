import React, { useState, useEffect } from "react";
import {
  getOnlineSessions,
  getSessions,
  getBanRules,
  getWhitelist,
  createBanRule,
  deleteBanRule,
  createWhitelistEntry,
  deleteWhitelistEntry,
  getMeetingCodes,
  deleteMeetingCode,
  getPendingSessions,
  approveSession,
  rejectSession,
  closeSession,
  getCurrentCustomerId,
  getLocalUsers,
  createLocalUser,
  updateLocalUser,
  deleteLocalUser,
} from "../lib/api";
import {
  Search,
  UserCheck,
  UserX,
  Shield,
  ShieldOff,
  Plus,
  Trash2,
  Ban,
  CheckCircle,
  Clock,
  Wifi,
  Users,
  RefreshCw,
  UserPlus,
  Mail,
  Phone,
  Edit2,
  Lock,
  Key,
  X,
  Layers,
} from "lucide-react";

const buildWhitelistForm = (customerId: string = "") => ({
  customer_id: customerId,
  mac_address: "",
  phone: "",
  description: "",
});

const buildBanForm = (customerId: string = "") => ({
  customer_id: customerId,
  mac_address: "",
  phone: "",
  ip_address: "",
  reason: "",
});

function normalizeSession(session: any) {
  const startedAt = session?.started_at || session?.created_at;
  const endedAt = session?.ended_at;
  const end = endedAt ? new Date(endedAt).getTime() : Date.now();
  const start = startedAt ? new Date(startedAt).getTime() : end;
  const durationMinutes = Number.isFinite(start) ? Math.max(0, Math.round((end - start) / 60000)) : 0;

  const formData = session?.meta?.form_data && typeof session.meta.form_data === "object" ? session.meta.form_data : {};
  const fullName = formData.full_name || formData.first_name || formData.ad_soyad || "";
  const phone = session?.phone || formData.phone || formData.gsm || formData.telefon || "";
  const tcNo = formData.tc_number || formData.tc_no || formData.tc || session?.tc_number || "";
  const department = formData.department || formData.unit || formData.birim || formData.company || formData.firma || "";
  const displayName = fullName || phone || (tcNo ? `TC: ${tcNo}` : "") || session?.username || session?.user || session?.mac || "Misafir";

  return {
    ...session,
    formData,
    fullName,
    phone,
    tcNo,
    department,
    displayName,
    user: displayName,
    device: session?.ssid || session?.device_name || session?.nas_ip || (session?.device_id ? "Cihaz " + String(session.device_id).slice(0, 8) : "—"),
    durationMinutes,
    startTime: startedAt,
    endTime: endedAt,
  };
}

export const UsersPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState(
    () => (typeof window !== "undefined" && window.location.pathname === "/users" ? "all" : "online")
  );
  const [onlineUsers, setOnlineUsers] = useState<any[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [pendingUsers, setPendingUsers] = useState<any[]>([]);
  const [banRules, setBanRules] = useState<any[]>([]);
  const [whitelist, setWhitelist] = useState<any[]>([]);
  const [meetingCodes, setMeetingCodes] = useState<any[]>([]);
  const [localUsers, setLocalUsers] = useState<any[]>([]);
  const [editingLocalUser, setEditingLocalUser] = useState<any | null>(null);
  const [localSaving, setLocalSaving] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showBanForm, setShowBanForm] = useState(false);
  const [showWhitelistForm, setShowWhitelistForm] = useState(false);
  const [currentCustomerId, setCurrentCustomerId] = useState("");
  const [whitelistForm, setWhitelistForm] = useState(() => buildWhitelistForm());
  const [banForm, setBanForm] = useState(() => buildBanForm());
  const [localForm, setLocalForm] = useState({ username: "", password: "", display_name: "", email: "", phone: "", max_devices: 3 });

  const tabs = [
    { key: "online", label: "Online Kullanıcılar", icon: Wifi },
    { key: "all", label: "Tüm Oturumlar", icon: Users },
    { key: "offline", label: "Geçmiş Oturumlar", icon: Clock },
    { key: "pending", label: "Onay Bekleyenler", icon: UserCheck },
    { key: "manual", label: "Manuel Kullanıcılar", icon: UserCheck },
    { key: "banned", label: "Yasaklılar", icon: Ban },
    { key: "whitelist", label: "Beyaz Liste", icon: Shield },
    { key: "meeting", label: "Toplantı Kodları", icon: Clock },
  ];

  const loadAll = async () => {
    setLoading(true);
    try {
      const results = await Promise.allSettled([
        getOnlineSessions(),
        getSessions(),
        getPendingSessions(),
        getBanRules(),
        getWhitelist(),
        getMeetingCodes(),
        getLocalUsers(),
      ]);
      const value = <T,>(index: number, fallback: T): T =>
        results[index].status === "fulfilled" ? (results[index].value as T) : fallback;
      setOnlineUsers(value<any[]>(0, []).map(normalizeSession));
      setAllUsers(value<any[]>(1, []).map(normalizeSession));
      setPendingUsers(value<any[]>(2, []).map(normalizeSession));
      setBanRules(value<any[]>(3, []));
      setWhitelist(value<any[]>(4, []));
      setMeetingCodes(value<any[]>(5, []));
      setLocalUsers(value<any[]>(6, []));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  useEffect(() => {
    (async () => {
      const customerId = await getCurrentCustomerId();
      if (customerId) {
        setCurrentCustomerId(customerId);
      }
    })();
  }, []);

  useEffect(() => {
    if (!currentCustomerId) return;
    setWhitelistForm((prev) => (prev.customer_id === currentCustomerId ? prev : buildWhitelistForm(currentCustomerId)));
    setBanForm((prev) => (prev.customer_id === currentCustomerId ? prev : buildBanForm(currentCustomerId)));
  }, [currentCustomerId]);

  const handleBan = async () => {
    try {
      await createBanRule(banForm);
      setShowBanForm(false);
      setBanForm(buildBanForm(currentCustomerId));
      await loadAll();
    } catch (err) {
      console.error(err);
    }
  };

  const handleUnban = async (id: string) => {
    if (!confirm("Bu yasağı kaldırmak istediğinize emin misiniz?")) return;
    try {
      await deleteBanRule(id);
      await loadAll();
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddWhitelist = async () => {
    try {
      await createWhitelistEntry(whitelistForm);
      setShowWhitelistForm(false);
      setWhitelistForm(buildWhitelistForm(currentCustomerId));
      await loadAll();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCloseSession = async (sessionId: string) => {
    if (!sessionId || !confirm("Bu kullanıcının oturumunu sonlandırmak istediğinize emin misiniz?")) return;
    try {
      await closeSession(sessionId, "Yönetici tarafından kapatıldı");
      await loadAll();
    } catch (err) {
      console.error(err);
    }
  };

  const renderOnline = () => (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-emerald-500" />
          <span className="text-sm font-bold text-slate-900 dark:text-white">
            {onlineUsers.length} Aktif Oturum
          </span>
          <span className="text-xs text-slate-500">· Canlı ağ trafiği teyit edilen doğrulanmış kullanıcılar</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative min-w-[240px]">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Kullanıcı, MAC veya IP filtrele..."
              className="w-full rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-8 pr-3 text-xs text-slate-800 outline-none focus:border-blue-500 focus:bg-white dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
              <th className="px-3 py-2.5">Kullanıcı & Kimlik</th>
              <th className="px-3 py-2.5">Ağ Durumu</th>
              <th className="px-3 py-2.5">IP & MAC</th>
              <th className="px-3 py-2.5">SSID / AP</th>
              <th className="px-3 py-2.5">Süre</th>
              <th className="px-3 py-2.5">Trafik</th>
              <th className="px-3 py-2.5 text-right">İşlemler</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {onlineUsers
              .filter(
                (s: any) =>
                  !search ||
                  [s.user, s.fullName, s.phone, s.tcNo, s.department, s.mac, s.ip, s.device].some((val) =>
                    String(val || "").toLowerCase().includes(search.toLowerCase())
                  )
              )
              .map((s: any, i: number) => {
                const live = s.meta?.live_telemetry;
                const isTransmitting = live?.traffic_status === "transmitting";

                return (
                  <tr key={s.id || i} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                    <td className="px-3 py-2.5 font-medium">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">
                        {s.fullName || s.displayName || s.user}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                        {s.phone && <span>{s.phone}</span>}
                        {s.department && (
                          <span className="rounded bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 text-[10px] text-slate-600 dark:text-slate-300 font-medium">
                            {s.department}
                          </span>
                        )}
                        <span className="rounded bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 text-[10px] text-slate-500 font-medium">
                          {s.auth_method || "Portal"}
                        </span>
                      </div>
                    </td>

                    <td className="px-3 py-2.5">
                      <span
                        className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-semibold border ${
                          isTransmitting
                            ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800"
                            : "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800"
                        }`}
                      >
                        {isTransmitting ? "Veri Akışı Var" : "Bağlı"}
                      </span>
                    </td>

                    <td className="px-3 py-2.5 font-mono text-[11px]">
                      <div className="font-medium text-slate-800 dark:text-slate-200">{s.ip || "—"}</div>
                      <div className="text-slate-400 text-[10px]">{s.mac}</div>
                    </td>

                    <td className="px-3 py-2.5 text-slate-600 dark:text-slate-300">
                      <div>{s.ssid || "Wi-Fi"}</div>
                      <div className="text-[10px] text-slate-400">{s.device || "FortiGate AP"}</div>
                    </td>

                    <td className="px-3 py-2.5 text-slate-600 dark:text-slate-400 font-mono">
                      <div>{s.durationMinutes ? `${s.durationMinutes} dk` : "Yeni"}</div>
                      {s.expires_at && (
                        <div className="text-[10px] text-slate-500 font-sans">
                          Bitiş: {new Date(s.expires_at).toLocaleTimeString("tr-TR")}
                        </div>
                      )}
                    </td>

                    <td className="px-3 py-2.5 font-mono text-slate-600 dark:text-slate-400">
                      <div>↓ {((s.bytes_in || 0) / (1024 * 1024)).toFixed(1)} MB</div>
                      <div className="text-[10px] text-slate-400">↑ {((s.bytes_out || 0) / (1024 * 1024)).toFixed(1)} MB</div>
                    </td>

                    <td className="px-3 py-2.5 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            setBanForm({
                              ...banForm,
                              mac_address: s.mac,
                              phone: s.phone || s.user || "",
                              ip_address: s.ip || "",
                            });
                            setShowBanForm(true);
                          }}
                          className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
                          title="Yasak Kuralı Ekle"
                        >
                          <Ban className="h-3.5 w-3.5 text-rose-500" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCloseSession(s.id)}
                          className="rounded-md border border-rose-200 bg-rose-50 px-2 py-1 text-[11px] font-semibold text-rose-700 hover:bg-rose-100 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-400 transition"
                          title="Oturumu Kapat"
                        >
                          Bağlantıyı Kes
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            {onlineUsers.length === 0 && (
              <tr>
                <td colSpan={7} className="py-10 text-center text-xs text-slate-500">
                  Şu anda aktif misafir oturumu bulunmuyor.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderAll = () => (
    <div className="space-y-3">
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-8 pr-3 text-xs text-slate-800 outline-none focus:border-blue-500 focus:bg-white dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
          placeholder="Kullanıcı filtrele..."
        />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
              <th className="px-3 py-2.5">Kullanıcı</th>
              <th className="px-3 py-2.5">MAC</th>
              <th className="px-3 py-2.5">IP</th>
              <th className="px-3 py-2.5">Durum</th>
              <th className="px-3 py-2.5">Başlangıç</th>
              <th className="px-3 py-2.5">Süre</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {allUsers
              .filter(
                (s: any) =>
                  !search ||
                  [s.user, s.fullName, s.phone, s.tcNo, s.department, s.mac, s.ip].some((value) =>
                    String(value || "").toLowerCase().includes(search.toLowerCase())
                  )
              )
              .map((s: any, i: number) => (
                <tr key={s.id || i} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                  <td className="px-3 py-2.5 font-medium">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">
                      {s.fullName || s.displayName || s.user}
                    </div>
                    <div className="text-[11px] text-slate-400">{s.phone}</div>
                  </td>
                  <td className="px-3 py-2.5 font-mono text-slate-600 dark:text-slate-400">{s.mac}</td>
                  <td className="px-3 py-2.5 font-mono text-slate-600 dark:text-slate-400">{s.ip || "—"}</td>
                  <td className="px-3 py-2.5">
                    <span
                      className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-semibold border ${
                        s.status === "active"
                          ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400"
                          : "bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-300"
                      }`}
                    >
                      {s.status === "active" ? "Aktif" : "Sonlandı"}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-slate-500">{s.startTime ? new Date(s.startTime).toLocaleString("tr-TR") : "—"}</td>
                  <td className="px-3 py-2.5 font-mono text-slate-500">{s.durationMinutes ? `${s.durationMinutes} dk` : "—"}</td>
                </tr>
              ))}
            {allUsers.length === 0 && (
              <tr>
                <td colSpan={6} className="py-10 text-center text-xs text-slate-500">
                  Kayıtlı oturum bulunamadı.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderOffline = () => {
    const offlineList = allUsers.filter((s: any) => s.status !== "active");
    return (
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
              <th className="px-3 py-2.5">Kullanıcı</th>
              <th className="px-3 py-2.5">MAC</th>
              <th className="px-3 py-2.5">IP</th>
              <th className="px-3 py-2.5">Bitiş Zamanı</th>
              <th className="px-3 py-2.5">Toplam Süre</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {offlineList.map((s: any, i: number) => (
              <tr key={s.id || i} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                <td className="px-3 py-2.5 font-semibold text-slate-900 dark:text-slate-100">{s.fullName || s.displayName || s.user}</td>
                <td className="px-3 py-2.5 font-mono text-slate-500">{s.mac}</td>
                <td className="px-3 py-2.5 font-mono text-slate-500">{s.ip || "—"}</td>
                <td className="px-3 py-2.5 text-slate-500">{s.endTime ? new Date(s.endTime).toLocaleString("tr-TR") : "—"}</td>
                <td className="px-3 py-2.5 font-mono text-slate-500">{s.durationMinutes ? `${s.durationMinutes} dk` : "—"}</td>
              </tr>
            ))}
            {offlineList.length === 0 && (
              <tr>
                <td colSpan={5} className="py-10 text-center text-xs text-slate-500">
                  Geçmiş oturum kaydı bulunamadı.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    );
  };

  const renderPending = () => (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse text-xs">
        <thead>
          <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
            <th className="px-3 py-2.5">Talep Sahibi</th>
            <th className="px-3 py-2.5">Telefon / Kimlik</th>
            <th className="px-3 py-2.5">Birim / Firma</th>
            <th className="px-3 py-2.5">Talep Zamanı</th>
            <th className="px-3 py-2.5 text-right">Onay İşlemi</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
          {pendingUsers.map((p: any) => (
            <tr key={p.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
              <td className="px-3 py-2.5 font-semibold text-slate-900 dark:text-slate-100">{p.fullName || p.user}</td>
              <td className="px-3 py-2.5 text-slate-500">{p.phone || p.tcNo || "—"}</td>
              <td className="px-3 py-2.5 text-slate-500">{p.department || "—"}</td>
              <td className="px-3 py-2.5 text-slate-500">{p.startTime ? new Date(p.startTime).toLocaleString("tr-TR") : "—"}</td>
              <td className="px-3 py-2.5 text-right">
                <div className="inline-flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={async () => {
                      await approveSession(p.id);
                      await loadAll();
                    }}
                    className="rounded-md bg-emerald-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-emerald-700 transition"
                  >
                    Onayla
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await rejectSession(p.id);
                      await loadAll();
                    }}
                    className="rounded-md border border-slate-300 px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 transition"
                  >
                    Reddet
                  </button>
                </div>
              </td>
            </tr>
          ))}
          {pendingUsers.length === 0 && (
            <tr>
              <td colSpan={5} className="py-10 text-center text-xs text-slate-500">
                Onay bekleyen misafir talebi bulunmuyor.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );

  const renderBanned = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">{banRules.length} Yasaklı Tanım</span>
        <button
          type="button"
          onClick={() => setShowBanForm(true)}
          className="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-700 transition"
        >
          + Yeni Yasak Ekle
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
              <th className="px-3 py-2.5">MAC Adresi</th>
              <th className="px-3 py-2.5">Telefon</th>
              <th className="px-3 py-2.5">IP</th>
              <th className="px-3 py-2.5">Sebep</th>
              <th className="px-3 py-2.5 text-right">İşlem</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {banRules.map((b: any) => (
              <tr key={b.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                <td className="px-3 py-2.5 font-mono text-slate-800 dark:text-slate-200">{b.mac_address || "—"}</td>
                <td className="px-3 py-2.5 text-slate-500">{b.phone || "—"}</td>
                <td className="px-3 py-2.5 font-mono text-slate-500">{b.ip_address || "—"}</td>
                <td className="px-3 py-2.5 text-slate-500">{b.reason || "Belirtilmedi"}</td>
                <td className="px-3 py-2.5 text-right">
                  <button
                    type="button"
                    onClick={() => handleUnban(b.id)}
                    className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
                    title="Yasağı Kaldır"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </td>
              </tr>
            ))}
            {banRules.length === 0 && (
              <tr>
                <td colSpan={5} className="py-10 text-center text-xs text-slate-500">
                  Yasaklı kural bulunmuyor.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderWhitelist = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">{whitelist.length} Beyaz Liste Kaydı</span>
        <button
          type="button"
          onClick={() => setShowWhitelistForm(true)}
          className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 transition"
        >
          + Beyaz Listeye Ekle
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
              <th className="px-3 py-2.5">MAC Adresi</th>
              <th className="px-3 py-2.5">Telefon</th>
              <th className="px-3 py-2.5">Açıklama</th>
              <th className="px-3 py-2.5 text-right">İşlem</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {whitelist.map((w: any) => (
              <tr key={w.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                <td className="px-3 py-2.5 font-mono text-slate-800 dark:text-slate-200">{w.mac_address || "—"}</td>
                <td className="px-3 py-2.5 text-slate-500">{w.phone || "—"}</td>
                <td className="px-3 py-2.5 text-slate-500">{w.description || "—"}</td>
                <td className="px-3 py-2.5 text-right">
                  <button
                    type="button"
                    onClick={async () => {
                      if (!confirm("Beyaz listeden kaldırmak istediğinize emin misiniz?")) return;
                      await deleteWhitelistEntry(w.id);
                      await loadAll();
                    }}
                    className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
                    title="Kaldır"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </td>
              </tr>
            ))}
            {whitelist.length === 0 && (
              <tr>
                <td colSpan={4} className="py-10 text-center text-xs text-slate-500">
                  Beyaz listede kayıt bulunmuyor.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderManual = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">{localUsers.length} Manuel Kullanıcı</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
              <th className="px-3 py-2.5">Kullanıcı Adı</th>
              <th className="px-3 py-2.5">Görünen İsim</th>
              <th className="px-3 py-2.5">E-Posta / Telefon</th>
              <th className="px-3 py-2.5">Cihaz Limiti</th>
              <th className="px-3 py-2.5 text-right">İşlem</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {localUsers.map((u: any) => (
              <tr key={u.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                <td className="px-3 py-2.5 font-semibold text-slate-900 dark:text-slate-100">{u.username}</td>
                <td className="px-3 py-2.5 text-slate-500">{u.display_name || "—"}</td>
                <td className="px-3 py-2.5 text-slate-500">{u.email || u.phone || "—"}</td>
                <td className="px-3 py-2.5 text-slate-500">{u.max_devices || 3} Cihaz</td>
                <td className="px-3 py-2.5 text-right">
                  <button
                    type="button"
                    onClick={async () => {
                      if (!confirm(`"${u.username}" kullanıcısını silmek istediğinize emin misiniz?`)) return;
                      await deleteLocalUser(u.id);
                      await loadAll();
                    }}
                    className="rounded-md p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-slate-800"
                    title="Sil"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </td>
              </tr>
            ))}
            {localUsers.length === 0 && (
              <tr>
                <td colSpan={5} className="py-10 text-center text-xs text-slate-500">
                  Manuel kullanıcı bulunmuyor.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderMeeting = () => (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse text-xs">
        <thead>
          <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
            <th className="px-3 py-2.5">Toplantı Kodu</th>
            <th className="px-3 py-2.5">Etkinlik</th>
            <th className="px-3 py-2.5">Kullanım</th>
            <th className="px-3 py-2.5">Süre</th>
            <th className="px-3 py-2.5">Bitiş Tarihi</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
          {meetingCodes.map((m: any) => (
            <tr key={m.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
              <td className="px-3 py-2.5 font-mono font-bold text-slate-900 dark:text-slate-100">{m.code}</td>
              <td className="px-3 py-2.5 text-slate-600 dark:text-slate-300">{m.event_name || "—"}</td>
              <td className="px-3 py-2.5 text-slate-500">{m.used_count || 0}/{m.max_uses || "—"}</td>
              <td className="px-3 py-2.5 font-mono text-slate-500">{m.duration_minutes ? `${m.duration_minutes} dk` : "—"}</td>
              <td className="px-3 py-2.5 text-slate-500">{m.expires_at ? new Date(m.expires_at).toLocaleDateString("tr-TR") : "—"}</td>
            </tr>
          ))}
          {meetingCodes.length === 0 && (
            <tr>
              <td colSpan={5} className="py-10 text-center text-xs text-slate-500">
                Kayıtlı toplantı kodu bulunmuyor.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Kullanıcı Yönetimi
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Canlı misafir oturumları, onay bekleyen talepler, yetki kuralları ve erişim listelerini yönetin.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadAll}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
        </div>
      </div>

      {/* 2. Standard 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Canlı Oturumlar</span>
            <Wifi className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{onlineUsers.length}</span>
            <span className="text-xs text-slate-500">aktif</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Onay Bekleyenler</span>
            <UserCheck className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">{pendingUsers.length}</span>
            <span className="text-xs text-slate-500">talep</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Yasaklı Kurallar</span>
            <Ban className="h-4 w-4 text-rose-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-rose-600 dark:text-rose-400">{banRules.length}</span>
            <span className="text-xs text-slate-500">cihaz / tel</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Beyaz Liste</span>
            <Shield className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{whitelist.length}</span>
            <span className="text-xs text-slate-500">tanımlı</span>
          </div>
        </div>
      </div>

      {/* 3. Navigation Tabs */}
      <div className="flex flex-wrap gap-1 border-b border-slate-200 dark:border-slate-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              type="button"
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold border-b-2 transition ${
                isActive
                  ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                  : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 4. Tab Content Panel */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900">
        {loading ? (
          <div className="flex items-center justify-center py-10 text-slate-500 text-xs">
            <RefreshCw className="h-4 w-4 animate-spin text-blue-500 mr-2" />
            Veriler yükleniyor...
          </div>
        ) : (
          <>
            {activeTab === "online" && renderOnline()}
            {activeTab === "all" && renderAll()}
            {activeTab === "offline" && renderOffline()}
            {activeTab === "pending" && renderPending()}
            {activeTab === "manual" && renderManual()}
            {activeTab === "banned" && renderBanned()}
            {activeTab === "whitelist" && renderWhitelist()}
            {activeTab === "meeting" && renderMeeting()}
          </>
        )}
      </div>

      {/* 5. Ban Form Modal */}
      {showBanForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Ban className="h-4 w-4 text-rose-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Yasaklama Kuralı Ekle</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowBanForm(false)}
                className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">MAC Adresi</label>
                <input
                  type="text"
                  value={banForm.mac_address}
                  onChange={(e) => setBanForm({ ...banForm, mac_address: e.target.value })}
                  placeholder="AA:BB:CC:DD:EE:FF"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-rose-500 dark:border-slate-700 dark:bg-slate-800 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Telefon Numarası</label>
                <input
                  type="text"
                  value={banForm.phone}
                  onChange={(e) => setBanForm({ ...banForm, phone: e.target.value })}
                  placeholder="5XXXXXXXXX"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-rose-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Yasaklama Sebebi</label>
                <input
                  type="text"
                  value={banForm.reason}
                  onChange={(e) => setBanForm({ ...banForm, reason: e.target.value })}
                  placeholder="Kural ihlali, yetkisiz erişim vb."
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-rose-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowBanForm(false)}
                className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                type="button"
                onClick={handleBan}
                className="rounded-lg bg-rose-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-rose-700 transition"
              >
                Yasağı Uygula
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Whitelist Form Modal */}
      {showWhitelistForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Beyaz Listeye Ekle</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowWhitelistForm(false)}
                className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">MAC Adresi</label>
                <input
                  type="text"
                  value={whitelistForm.mac_address}
                  onChange={(e) => setWhitelistForm({ ...whitelistForm, mac_address: e.target.value })}
                  placeholder="AA:BB:CC:DD:EE:FF"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Telefon Numarası</label>
                <input
                  type="text"
                  value={whitelistForm.phone}
                  onChange={(e) => setWhitelistForm({ ...whitelistForm, phone: e.target.value })}
                  placeholder="5XXXXXXXXX"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Açıklama</label>
                <input
                  type="text"
                  value={whitelistForm.description}
                  onChange={(e) => setWhitelistForm({ ...whitelistForm, description: e.target.value })}
                  placeholder="VIP Misafir, Yönetici Cihazı vb."
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-emerald-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowWhitelistForm(false)}
                className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                type="button"
                onClick={handleAddWhitelist}
                className="rounded-lg bg-emerald-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 transition"
              >
                Listeye Kaydet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
