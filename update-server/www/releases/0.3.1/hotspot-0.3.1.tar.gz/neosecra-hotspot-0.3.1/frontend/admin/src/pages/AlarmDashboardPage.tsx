import React, { useState, useEffect } from "react";
import { getAlarmEvents, getAlarmStats, acknowledgeAlarm, getAlarmTrend } from "../lib/api";
import { Bell, BellOff, AlertTriangle, AlertCircle, Info, RefreshCw, CheckCircle, Clock, Server, Filter, TrendingUp } from "lucide-react";

export const AlarmDashboardPage: React.FC = () => {
  const [events, setEvents] = useState<any[]>([]);
  const [stats, setStats] = useState<any | null>(null);
  const [trend, setTrend] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  const load = async () => {
    setLoading(true);
    try {
      const [eventsData, statsData, trendData] = await Promise.all([
        getAlarmEvents(),
        getAlarmStats(),
        getAlarmTrend(14),
      ]);
      setEvents(Array.isArray(eventsData) ? eventsData : []);
      setStats(statsData || null);
      setTrend(Array.isArray(trendData) ? trendData : []);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleAcknowledge = async (id: string) => {
    try {
      await acknowledgeAlarm(id);
      setEvents((prev) => prev.map((event) => event.id === id ? { ...event, acknowledged: true, acknowledged_at: new Date().toISOString() } : event));
      setStats((prev) => prev ? { ...prev, acknowledged: prev.acknowledged + 1, unacknowledged: prev.unacknowledged - 1 } : prev);
    } catch (err) { console.error(err); }
  };

  const severityIcon = (s: string) => {
    switch (s) {
      case 'critical': return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      default: return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const severityColor = (s: string) => {
    switch (s) {
      case 'critical': return 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900';
      case 'warning': return 'bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900';
      default: return 'bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900';
    }
  };

  const filtered = events.filter((event: any) => filter === 'all' || event.severity === filter);

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Alarm Panosu
            </h2>
            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <AlertTriangle className="h-3 w-3 text-amber-500" />
              Olay Müdahale Merkezi
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Tetikleyicilerden gelen kritik güvenlik olaylarını inceleyin, sorumlu operatör tarafından onaylayın.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={load}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
        </div>
      </div>

      {/* 2. Standard 4 KPI Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Alarm</span>
            <Bell className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{stats?.total_today ?? 0}</span>
            <span className="text-xs text-slate-500">bugün</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Kritik Olaylar</span>
            <AlertCircle className="h-4 w-4 text-rose-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-rose-600 dark:text-rose-400">{stats?.critical ?? 0}</span>
            <span className="text-xs text-slate-500">acil</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Uyarı Seviyesi</span>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-amber-600 dark:text-amber-400">{stats?.warning ?? 0}</span>
            <span className="text-xs text-slate-500">uyarı</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Onaylanan Alarmlar</span>
            <CheckCircle className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{stats?.acknowledged ?? 0}</span>
            <span className="text-xs text-slate-500">kapatıldı</span>
          </div>
        </div>
      </div>

      {/* Severity distribution bar */}
      {stats && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-500 mb-3">Severity Dağılımı</h3>
          <div className="flex h-6 rounded-full overflow-hidden">
            <div className="bg-red-500 transition-all" style={{ width: `${stats.total_today > 0 ? (stats.critical / stats.total_today) * 100 : 0}%` }}></div>
            <div className="bg-amber-500 transition-all" style={{ width: `${stats.total_today > 0 ? (stats.warning / stats.total_today) * 100 : 0}%` }}></div>
            <div className="bg-blue-500 transition-all" style={{ width: `${stats.total_today > 0 ? (stats.info / stats.total_today) * 100 : 0}%` }}></div>
          </div>
          <div className="flex gap-4 mt-2 text-xs text-slate-500">
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-red-500 rounded-full"></span> Kritik (%{stats.total_today > 0 ? ((stats.critical / stats.total_today) * 100).toFixed(0) : 0})</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-amber-500 rounded-full"></span> Uyarı (%{stats.total_today > 0 ? ((stats.warning / stats.total_today) * 100).toFixed(0) : 0})</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-blue-500 rounded-full"></span> Bilgi (%{stats.total_today > 0 ? ((stats.info / stats.total_today) * 100).toFixed(0) : 0})</span>
          </div>
        </div>
      )}

      {/* Trend Chart */}
      {trend.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-500 mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" /> Alarm Trendi (Son 14 Gün)
          </h3>
          <div className="relative h-32">
            <div className="absolute inset-0 flex items-end space-x-1">
              {trend.map((d: any, i: number) => {
                const maxC = Math.max(...trend.map(x => x.count), 1);
                const pct = (d.count / maxC) * 100;
                return (
                  <div key={i} className="flex-1 flex flex-col items-center" title={`${d.date}: ${d.count} alarm (Kritik: ${d.critical}, Uyarı: ${d.warning})`}>
                    <div className="w-full bg-gradient-to-t from-red-500 via-amber-400 to-blue-400 rounded-t" style={{ height: `${Math.max(pct, 1)}%` }}></div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="flex justify-between text-xs text-slate-400 mt-1">
            <span>{trend[0]?.date}</span>
            <span>{trend[trend.length - 1]?.date}</span>
          </div>
          <div className="flex gap-4 mt-2 text-[10px] text-slate-500">
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-red-500 rounded-full"></span> Kritik</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-amber-400 rounded-full"></span> Uyarı</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 bg-blue-400 rounded-full"></span> Bilgi</span>
          </div>
        </div>
      )}

      {/* Filter */}
      <div className="flex items-center gap-2">
        <Filter className="w-4 h-4 text-slate-400" />
        {['all', 'critical', 'warning', 'info'].map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1.5 text-xs font-medium rounded-xl transition-all ${filter === f ? 'bg-indigo-100 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
            {f === 'all' ? 'Tümü' : f === 'critical' ? 'Kritik' : f === 'warning' ? 'Uyarı' : 'Bilgi'}
          </button>
        ))}
      </div>

      {/* Alarm Events Timeline */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-8 text-slate-500">Alarm bulunmuyor.</div>
        ) : filtered.map((event: any) => (
          <div key={event.id} className={`border rounded-2xl p-4 shadow-sm transition-all ${severityColor(event.severity)} ${event.acknowledged ? 'opacity-70' : ''}`}>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="mt-0.5">{severityIcon(event.severity)}</div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm">{event.trigger_name || event.title || 'Alarm'}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full uppercase font-bold ${event.severity === 'critical' ? 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400' : event.severity === 'warning' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400' : 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400'}`}>{event.severity}</span>
                    {event.acknowledged && <span className="text-[10px] bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400 px-1.5 py-0.5 rounded-full">Onaylandı</span>}
                  </div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{event.message}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-slate-400">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(event.timestamp || event.event_time || event.created_at).toLocaleString('tr-TR')}</span>
                    <span className="flex items-center gap-1"><Server className="w-3 h-3" /> {event.source || '-'}</span>
                    {event.acknowledged_at && (
                      <span className="flex items-center gap-1"><CheckCircle className="w-3 h-3" /> {new Date(event.acknowledged_at).toLocaleString('tr-TR')}</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {!event.acknowledged && (
                  <button onClick={() => handleAcknowledge(event.id)} className="p-2 text-slate-400 hover:text-green-600 hover:bg-green-50 dark:hover:bg-green-950/20 rounded-xl" title="Onayla">
                    <CheckCircle className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
