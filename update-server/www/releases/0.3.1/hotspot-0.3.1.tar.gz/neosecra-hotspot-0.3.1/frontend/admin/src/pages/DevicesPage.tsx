import React, { useState, useEffect } from "react";
import {
  getDevices,
  getLocations,
  getVendorCapabilities,
  addDevice,
  deleteDevice,
  getDeviceCredential,
  setDeviceCredential,
  testDeviceConnection,
  refreshDeviceInfo,
  syncActiveSessions,
} from "../lib/api";
import type { DeviceCredentialMetadata } from "../lib/api";
import {
  Plus,
  Trash2,
  Search,
  Server,
  Play,
  CheckCircle2,
  XCircle,
  RefreshCw,
  AlertTriangle,
  WifiOff,
  HardDrive,
  Shield,
  ShieldOff,
  Check,
  X,
  Wifi,
} from "lucide-react";

interface Device {
  id: string;
  name: string;
  vendor: string;
  model: string;
  mgmt_ip: string;
  location_id: string;
  locationName: string;
  status: string;
  serial_number?: string | null;
  firmware_version?: string | null;
  last_seen_at?: string | null;
  meta?: Record<string, any>;
}

interface LocationOption {
  id: string;
  name: string;
}

interface VendorOption {
  vendor: string;
  display_name: string;
}

const FALLBACK_VENDOR_OPTIONS: VendorOption[] = [
  { vendor: "fortigate", display_name: "Fortinet FortiGate" },
];

const readMetaString = (meta: Record<string, any> | undefined, ...keys: string[]): string | null => {
  if (!meta) return null;
  for (const key of keys) {
    const value = meta[key];
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return null;
};

const formatDate = (value: string | null | undefined): string => {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString("tr-TR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const normalizeDevice = (item: any, locationLookup: Record<string, string>): Device => {
  const meta = item?.meta && typeof item.meta === "object" ? item.meta : {};
  const locationId = String(item?.location_id ?? item?.locationId ?? "");
  const locationName = item?.location_name || item?.locationName || locationLookup[locationId] || "Lokasyon atanmadı";
  const serial = item?.serial_number || readMetaString(meta, "serial_number", "serialNumber", "serial", "fortigate_serial");
  const firmware = item?.firmware_version || readMetaString(meta, "firmware_version", "firmwareVersion", "version", "os_version");
  const lastSeen = item?.last_seen_at || readMetaString(meta, "last_seen_at", "last_test_at", "lastTestAt");

  return {
    id: String(item?.id ?? ""),
    name: item?.name || "İsimsiz Cihaz",
    vendor: String(item?.vendor || "fortigate").toLowerCase(),
    model: item?.model || readMetaString(meta, "model", "hardware_model") || "Genel Cihaz",
    mgmt_ip: item?.mgmt_ip || item?.mgmtIp || item?.api_host || "0.0.0.0",
    location_id: locationId,
    locationName,
    status: String(item?.status || "offline").toLowerCase(),
    serial_number: serial,
    firmware_version: firmware,
    last_seen_at: lastSeen,
    meta,
  };
};

export const DevicesPage: React.FC = () => {
  const [devices, setDevices] = useState<Device[]>([]);
  const [locations, setLocations] = useState<LocationOption[]>([]);
  const [vendorOptions, setVendorOptions] = useState<VendorOption[]>(FALLBACK_VENDOR_OPTIONS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [refreshingId, setRefreshingId] = useState<string | null>(null);
  const [syncingId, setSyncingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ id: string; success: boolean; msg: string } | null>(null);
  const [credentials, setCredentials] = useState<Record<string, DeviceCredentialMetadata | null>>({});
  const [credentialDevice, setCredentialDevice] = useState<Device | null>(null);
  const [credentialForm, setCredentialForm] = useState({
    api_token: "",
    api_username: "",
    api_vdom: "root",
    verify_tls: true,
  });
  const [credentialSaving, setCredentialSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    vendor: "fortigate",
    model: "",
    mgmtIp: "",
    locationId: "",
    apiPort: 443,
    apiToken: "",
    apiUsername: "",
    apiVdom: "root",
    verifyTls: true,
    apiTls: true,
  });

  const loadDevices = async () => {
    setLoading(true);
    setError(null);
    try {
      const [rawDevices, rawLocations, rawVendors] = await Promise.all([
        getDevices(),
        getLocations().catch(() => []),
        getVendorCapabilities().catch(() => []),
      ]);

      const locationLookup: Record<string, string> = {};
      const nextLocations = (Array.isArray(rawLocations) ? rawLocations : []).map((loc: any) => {
        const id = String(loc.id);
        const name = String(loc.name || `Lokasyon #${id}`);
        locationLookup[id] = name;
        return { id, name };
      });
      setLocations(nextLocations);

      if (Array.isArray(rawVendors) && rawVendors.length > 0) {
        const mapped = rawVendors
          .filter((v: any) => v && (v.vendor === "fortigate" || v.id === "fortigate"))
          .map((v: any) => ({
            vendor: String(v.vendor || v.id || "fortigate").toLowerCase(),
            display_name: String(v.display_name || v.displayName || v.name || "Fortinet FortiGate"),
          }));
        if (mapped.length > 0) setVendorOptions(mapped);
      }

      const normalizedList = (Array.isArray(rawDevices) ? rawDevices : []).map((d: any) => normalizeDevice(d, locationLookup));
      setDevices(normalizedList);

      normalizedList.forEach((d) => {
        getDeviceCredential(d.id)
          .then((cred) => {
            setCredentials((prev) => ({ ...prev, [d.id]: cred }));
          })
          .catch(() => null);
      });
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Cihazlar yüklenirken bir hata oluştu.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDevices();
  }, []);

  const filtered = devices.filter(
    (d) =>
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      d.model.toLowerCase().includes(search.toLowerCase()) ||
      d.mgmt_ip.toLowerCase().includes(search.toLowerCase()) ||
      d.locationName.toLowerCase().includes(search.toLowerCase()) ||
      (d.serial_number && d.serial_number.toLowerCase().includes(search.toLowerCase())) ||
      (d.firmware_version && d.firmware_version.toLowerCase().includes(search.toLowerCase()))
  );

  const onlineCount = devices.filter((device) => device.status === "online").length;
  const warningCount = devices.filter((device) => device.status === "warning").length;
  const offlineCount = devices.filter((device) => device.status === "offline").length;

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.mgmtIp || !formData.locationId) return;

    try {
      if (formData.vendor === "fortigate" && !formData.apiToken.trim()) {
        setError("FortiGate cihazı için API token zorunludur.");
        return;
      }

      const newDev = await addDevice({
        name: formData.name,
        vendor: formData.vendor,
        model: formData.model || "Genel Cihaz",
        location_id: formData.locationId,
        mgmt_ip: formData.mgmtIp,
        api_host: formData.mgmtIp,
        api_port: formData.apiPort,
        meta: {
          device_type: "firewall",
          api_tls: formData.apiTls,
        },
      });

      if (formData.apiToken.trim() || formData.apiUsername.trim()) {
        try {
          const savedCredential = await setDeviceCredential(String(newDev.id), {
            api_token: formData.apiToken.trim() || undefined,
            api_username: formData.apiUsername.trim() || undefined,
            api_vdom: formData.apiVdom.trim() || undefined,
            verify_tls: formData.verifyTls,
          });
          setCredentials((prev) => ({ ...prev, [String(newDev.id)]: savedCredential }));
        } catch (err) {
          console.error("Kimlik bilgisi kaydedilemedi:", err);
        }
      }

      const locationLookup = Object.fromEntries(locations.map((loc) => [loc.id, loc.name]));
      setDevices((prev) => [normalizeDevice(newDev, locationLookup), ...prev]);
      setFormData({
        name: "",
        vendor: "fortigate",
        model: "",
        mgmtIp: "",
        locationId: "",
        apiPort: 443,
        apiToken: "",
        apiUsername: "",
        apiVdom: "root",
        verifyTls: true,
        apiTls: true,
      });
      setShowAddModal(false);
      setError(null);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Cihaz eklenemedi.");
    }
  };

  const openCredentialEditor = async (device: Device) => {
    const cached = credentials[device.id];
    const existing = cached !== undefined ? cached : await getDeviceCredential(device.id).catch(() => null);
    if (existing) {
      setCredentials((prev) => ({ ...prev, [device.id]: existing }));
    }
    setCredentialForm({
      api_token: "",
      api_username: existing?.api_username || "",
      api_vdom: existing?.api_vdom || "root",
      verify_tls: existing?.verify_tls !== false,
    });
    setCredentialDevice(device);
  };

  const handleCredentialSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!credentialDevice) return;
    setCredentialSaving(true);
    try {
      const current = credentials[credentialDevice.id];
      if (!current?.has_token && !credentialForm.api_token.trim()) {
        throw new Error("İlk kayıt için API token zorunludur.");
      }
      const saved = await setDeviceCredential(credentialDevice.id, {
        api_token: credentialForm.api_token || undefined,
        api_username: credentialForm.api_username || undefined,
        api_vdom: credentialForm.api_vdom || undefined,
        verify_tls: credentialForm.verify_tls,
      });
      setCredentials((prev) => ({ ...prev, [credentialDevice.id]: saved }));
      setCredentialDevice(null);
      setTestResult({ id: credentialDevice.id, success: true, msg: "Kimlik bilgileri kaydedildi." });
    } catch (err: any) {
      setTestResult({ id: credentialDevice.id, success: false, msg: err?.message || "Kimlik bilgileri kaydedilemedi." });
    } finally {
      setCredentialSaving(false);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`"${name}" cihazını silmek istediğinize emin misiniz?`)) {
      try {
        await deleteDevice(id);
        setDevices(devices.filter((d) => d.id !== id));
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleTestConnection = async (id: string, name: string) => {
    setTestingId(id);
    setTestResult(null);
    try {
      const res = await testDeviceConnection(id);
      if (res.success) {
        setDevices((prev) =>
          prev.map((device) =>
            device.id === id ? { ...device, status: "online", last_seen_at: new Date().toISOString() } : device
          )
        );
      } else {
        setDevices((prev) =>
          prev.map((device) => (device.id === id ? { ...device, status: "warning" } : device))
        );
      }
      setTestResult({
        id,
        success: res.success,
        msg: res.message || `${name} bağlantısı başarılı.`,
      });
      const refreshedCredential = await getDeviceCredential(id).catch(() => null);
      setCredentials((prev) => ({ ...prev, [id]: refreshedCredential }));
    } catch (err: any) {
      setDevices((prev) =>
        prev.map((device) => (device.id === id ? { ...device, status: "offline" } : device))
      );
      setTestResult({
        id,
        success: false,
        msg: err?.message || `${name} ile bağlantı kurulamadı.`,
      });
    } finally {
      setTestingId(null);
    }
  };

  const handleRefreshDeviceInfo = async (id: string) => {
    setRefreshingId(id);
    try {
      const updated = await refreshDeviceInfo(id);
      const locationLookup = Object.fromEntries(locations.map((location) => [location.id, location.name]));
      setDevices((prev) => prev.map((device) => (device.id === id ? normalizeDevice(updated, locationLookup) : device)));
      setTestResult({ id, success: true, msg: "Cihaz bilgileri güncellendi." });
    } catch (err: any) {
      console.error("Refresh failed:", err);
      setTestResult({ id, success: false, msg: err?.message || "Cihaz bilgileri alınamadı." });
    } finally {
      setRefreshingId(null);
    }
  };

  const handleSyncSessions = async (id: string) => {
    setSyncingId(id);
    try {
      const result = await syncActiveSessions(id);
      const count = Array.isArray(result)
        ? result.length
        : Array.isArray(result?.sessions)
          ? result.sessions.length
          : null;
      setTestResult({
        id,
        success: true,
        msg: count === null ? "Cihaz oturumları sorgulandı." : `${count} aktif oturum cihazdan alındı.`,
      });
    } catch (err: any) {
      console.error("Sync sessions failed:", err);
      setTestResult({ id, success: false, msg: err?.message || "Cihaz oturumları alınamadı." });
    } finally {
      setSyncingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Cihazlar ve Ağ Geçitleri
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Hotspot yetkilendirmesi yapan FortiGate firewall ve ağ geçidi entegrasyonlarını yönetin.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadDevices}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
          >
            <Plus className="h-3.5 w-3.5" /> Yeni Cihaz
          </button>
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-200"
        >
          {error}
        </div>
      )}

      {/* 2. Standard 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Cihaz</span>
            <Server className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{devices.length}</span>
            <span className="text-xs text-slate-500">kayıtlı</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Aktif & Bağlı</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{onlineCount}</span>
            <span className="text-xs text-slate-500">cihaz</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Uyarı / İnceleme</span>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-amber-600 dark:text-amber-400">{warningCount}</span>
            <span className="text-xs text-slate-500">cihaz</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Çevrimdışı</span>
            <WifiOff className="h-4 w-4 text-rose-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-rose-600 dark:text-rose-400">{offlineCount}</span>
            <span className="text-xs text-slate-500">cihaz</span>
          </div>
        </div>
      </div>

      {/* 3. Search Bar */}
      <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xs dark:border-slate-800 dark:bg-slate-900">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cihaz adı, IP adresi, seri numarası veya model filtrele..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500 focus:bg-white dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:focus:bg-slate-900"
          />
        </div>
      </div>

      {/* 4. Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900">
        {loading ? (
          <div className="flex items-center justify-center py-12 text-slate-500">
            <RefreshCw className="h-5 w-5 animate-spin text-blue-500 mr-2" />
            <span className="text-xs">Cihazlar yükleniyor...</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-4 py-3">Cihaz</th>
                  <th className="px-4 py-3">Vendor / Model</th>
                  <th className="px-4 py-3">Seri No</th>
                  <th className="px-4 py-3">Firmware</th>
                  <th className="px-4 py-3">VDOM</th>
                  <th className="px-4 py-3">TLS</th>
                  <th className="px-4 py-3">Kimlik</th>
                  <th className="px-4 py-3">Yönetim IP</th>
                  <th className="px-4 py-3">Lokasyon</th>
                  <th className="px-4 py-3">Durum</th>
                  <th className="px-4 py-3 text-right">İşlemler</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((d) => {
                  const meta = d.meta || {};
                  const credential = credentials[d.id];
                  const vdom = credential?.api_vdom || readMetaString(meta, "vdom", "VDOM") || "root";
                  const hasCredential = Boolean(credential?.has_token);
                  const verifyTls = credential?.verify_tls ?? meta.verify_tls ?? meta.verifyTls ?? true;

                  return (
                    <tr key={d.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                      <td className="px-4 py-3 font-semibold text-slate-900 dark:text-slate-100">
                        <div className="flex items-center gap-2">
                          <div
                            className={`h-2 w-2 rounded-full shrink-0 ${
                              d.status === "online"
                                ? "bg-emerald-500"
                                : d.status === "warning"
                                  ? "bg-amber-500"
                                  : "bg-rose-500"
                            }`}
                          />
                          <span>{d.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-medium text-slate-800 dark:text-slate-200">
                          {d.vendor === "fortigate" ? "FortiGate" : d.vendor}
                        </span>
                        {d.model && <span className="text-slate-400 ml-1">({d.model})</span>}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-400">
                        {d.serial_number || "—"}
                      </td>
                      <td className="px-4 py-3 text-slate-500">
                        {d.firmware_version || "—"}
                      </td>
                      <td className="px-4 py-3 text-slate-500">
                        <div>{vdom}</div>
                        <div className="mt-0.5 text-[10px] text-slate-400">
                          {d.status === "online" ? "Çevrimiçi" : d.status === "warning" ? "Uyarı" : "Çevrimdışı"}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {verifyTls ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-medium text-emerald-600 dark:text-emerald-400">
                            <Shield className="h-3 w-3" aria-hidden="true" /> TLS
                          </span>
                        ) : (
                          <span
                            className="inline-flex items-center gap-1 text-[10px] font-medium text-amber-600 dark:text-amber-400"
                            title="TLS doğrulaması devre dışı"
                          >
                            <ShieldOff className="h-3 w-3" aria-hidden="true" /> Uyarı
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {hasCredential ? (
                          <span className="inline-flex items-center gap-1 rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                            <Check className="h-3 w-3" /> Token Var
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                            Tanımsız
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-300">{d.mgmt_ip}</td>
                      <td className="px-4 py-3 text-slate-500">{d.locationName}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-semibold border ${
                            d.status === "online"
                              ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800"
                              : d.status === "warning"
                                ? "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800"
                                : "bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800"
                          }`}
                        >
                          {d.status === "online" ? "Aktif" : d.status === "warning" ? "Uyarı" : "Bağlantı Yok"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openCredentialEditor(d)}
                            title="Kimlik Bilgileri"
                            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
                          >
                            <Shield className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleTestConnection(d.id, d.name)}
                            disabled={testingId === d.id}
                            title="Test Et"
                            aria-label={`${d.name} bağlantısını test et`}
                            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-blue-600 dark:hover:bg-slate-800"
                          >
                            <Play className={`h-3.5 w-3.5 ${testingId === d.id ? "animate-spin" : ""}`} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRefreshDeviceInfo(d.id)}
                            disabled={refreshingId === d.id}
                            title="Cihaz Bilgilerini Yenile"
                            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-blue-600 dark:hover:bg-slate-800"
                          >
                            <RefreshCw className={`h-3.5 w-3.5 ${refreshingId === d.id ? "animate-spin" : ""}`} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSyncSessions(d.id)}
                            disabled={syncingId === d.id}
                            title="Oturumları Senkronize Et"
                            className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-blue-600 dark:hover:bg-slate-800"
                          >
                            <Wifi className={`h-3.5 w-3.5 ${syncingId === d.id ? "animate-spin" : ""}`} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(d.id, d.name)}
                            title="Cihazı Sil"
                            className="rounded-md p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-slate-800"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        {testResult && testResult.id === d.id && (
                          <div
                            className={`mt-1 text-[10px] text-right font-medium ${
                              testResult.success ? "text-emerald-600" : "text-rose-600"
                            }`}
                          >
                            {testResult.msg}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={11} className="py-10 text-center text-xs text-slate-500">
                      Arama kriterlerinize uygun cihaz bulunamadı.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 5. Add Device Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form
            onSubmit={handleAddSubmit}
            className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Server className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Yeni Cihaz Entegrasyonu</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Cihaz Adı *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Örn: Merkez FortiGate 100F"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Yönetim IP *</label>
                <input
                  type="text"
                  required
                  value={formData.mgmtIp}
                  onChange={(e) => setFormData({ ...formData, mgmtIp: e.target.value })}
                  placeholder="192.168.1.1"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Lokasyon *</label>
                <select
                  required
                  value={formData.locationId}
                  onChange={(e) => setFormData({ ...formData, locationId: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                >
                  <option value="">Lokasyon Seçin</option>
                  {locations.map((loc) => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Model</label>
                <input
                  type="text"
                  value={formData.model}
                  onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                  placeholder="Örn: FG-100F"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
            </div>

            {/* REST API Token Section */}
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950 space-y-3">
              <span className="font-bold text-slate-800 dark:text-slate-200">FortiGate REST API Yapılandırması</span>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1 sm:col-span-2">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">REST API Token *</label>
                  <input
                    type="password"
                    required
                    value={formData.apiToken}
                    onChange={(e) => setFormData({ ...formData, apiToken: e.target.value })}
                    placeholder="FortiGate üzerinde oluşturulan API token"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">VDOM</label>
                  <input
                    type="text"
                    value={formData.apiVdom}
                    onChange={(e) => setFormData({ ...formData, apiVdom: e.target.value })}
                    placeholder="root"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Port</label>
                  <input
                    type="number"
                    value={formData.apiPort}
                    onChange={(e) => setFormData({ ...formData, apiPort: Number(e.target.value) })}
                    placeholder="443"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                type="submit"
                className="rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
              >
                Cihazı Ekle
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 6. Credential Editor Modal */}
      {credentialDevice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form
            onSubmit={handleCredentialSave}
            className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">API Kimlik Bilgileri</h3>
                  <p className="text-[11px] text-slate-500">{credentialDevice.name} ({credentialDevice.mgmt_ip})</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setCredentialDevice(null)}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">
                  Yeni REST API Token {credentials[credentialDevice.id]?.has_token ? "(Değiştirmek için)" : "*"}
                </label>
                <input
                  type="password"
                  value={credentialForm.api_token}
                  onChange={(e) => setCredentialForm({ ...credentialForm, api_token: e.target.value })}
                  placeholder={credentials[credentialDevice.id]?.has_token ? "Mevcut tokenı korumak için boş bırakın" : "Token girin"}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 font-mono"
                />
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">API Kullanıcı Adı (Opsiyonel)</label>
                  <input
                    type="text"
                    value={credentialForm.api_username}
                    onChange={(e) => setCredentialForm({ ...credentialForm, api_username: e.target.value })}
                    placeholder="admin"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">VDOM</label>
                  <input
                    type="text"
                    value={credentialForm.api_vdom}
                    onChange={(e) => setCredentialForm({ ...credentialForm, api_vdom: e.target.value })}
                    placeholder="root"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setCredentialDevice(null)}
                className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                type="submit"
                disabled={credentialSaving}
                className="rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition disabled:opacity-50"
              >
                {credentialSaving ? "Kaydediliyor..." : "Kaydet"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
