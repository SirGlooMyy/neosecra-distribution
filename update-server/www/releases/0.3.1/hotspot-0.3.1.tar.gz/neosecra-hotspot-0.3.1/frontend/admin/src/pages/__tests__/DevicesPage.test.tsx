import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

// Mock the api module
vi.mock('../../lib/api', () => ({
  getDevices: vi.fn(),
  getLocations: vi.fn(),
  getVendorCapabilities: vi.fn(),
  addDevice: vi.fn(),
  deleteDevice: vi.fn(),
  getDeviceCredential: vi.fn(),
  setDeviceCredential: vi.fn(),
  testDeviceConnection: vi.fn(),
  refreshDeviceInfo: vi.fn(),
  syncActiveSessions: vi.fn(),
}));

import {
  getDevices,
  getLocations,
  getVendorCapabilities,
  getDeviceCredential,
  testDeviceConnection,
} from '../../lib/api';
import { DevicesPage } from '../DevicesPage';

const mockDevices = [
  {
    id: '1',
    name: 'FortiGate-1',
    vendor: 'fortigate',
    model: 'FG-100F',
    mgmt_ip: '10.0.0.1',
    serial_number: 'SN12345',
    firmware_version: '7.2.5',
    location_id: 'loc-1',
    locationName: 'Merkez Ofis',
    status: 'online',
    last_seen_at: '2025-01-15T10:30:00Z',
    meta: {
      vdom: 'root',
      verify_tls: true,
    },
  },
  {
    id: '2',
    name: 'FortiGate-2',
    vendor: 'fortigate',
    model: 'FG-60F',
    mgmt_ip: '10.0.0.2',
    serial_number: 'SN54321',
    firmware_version: '7.0.6',
    location_id: 'loc-2',
    locationName: 'Şube Ofis',
    status: 'offline',
    last_seen_at: '2025-01-10T08:15:00Z',
    meta: {
      verify_tls: false,
    },
  },
  {
    id: '3',
    name: 'FortiGate-3',
    vendor: 'fortigate',
    model: 'FG-200F',
    mgmt_ip: '10.0.0.3',
    location_id: 'loc-1',
    locationName: 'Merkez Ofis',
    status: 'warning',
    last_seen_at: null,
    meta: {},
  },
];

const mockLocations = [
  { id: 'loc-1', name: 'Merkez Ofis' },
  { id: 'loc-2', name: 'Şube Ofis' },
];

describe('DevicesPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (getDevices as any).mockResolvedValue(mockDevices);
    (getLocations as any).mockResolvedValue(mockLocations);
    (getVendorCapabilities as any).mockResolvedValue([]);
    (getDeviceCredential as any).mockResolvedValue(null);
  });

  // 1. Loading state
  it('shows loading skeleton while fetching devices', async () => {
    // Keep promise unresolved during render
    (getDevices as any).mockImplementation(() => new Promise(() => {}));

    render(<DevicesPage />);

    // The page should show loading state - check for the loading text or skeleton
    expect(screen.getByText('Cihazlar ve Ağ Geçitleri')).toBeInTheDocument();
    expect(screen.getByText(/Hotspot yetkilendirmesi yapan FortiGate firewall/)).toBeInTheDocument();
  });

  // 2. Renders device table on successful load
  it('renders device table with device data', async () => {
    render(<DevicesPage />);

    // Wait for the device names to appear
    expect(await screen.findByText('FortiGate-1')).toBeInTheDocument();
    expect(await screen.findByText('FortiGate-2')).toBeInTheDocument();
    expect(await screen.findByText('FortiGate-3')).toBeInTheDocument();

    // Verify API was called
    expect(getDevices).toHaveBeenCalledTimes(1);
    expect(getLocations).toHaveBeenCalledTimes(1);
  });

  // 3. Shows connected status badge
  it('shows active status badge for online devices', async () => {
    render(<DevicesPage />);

    // Online device should show "Aktif" status badge (in stats card + table)
    const activeElements = await screen.findAllByText('Aktif');
    expect(activeElements.length).toBeGreaterThanOrEqual(1);
    // The row label should show "Çevrimiçi"
    expect(screen.getByText('Çevrimiçi')).toBeInTheDocument();
  });

  // 4. Shows offline status badge
  it('shows offline status badge for offline devices', async () => {
    render(<DevicesPage />);

    // Offline device should show "Bağlantı Yok" status badge
    expect(await screen.findByText('Bağlantı Yok')).toBeInTheDocument();
    // And the stats card shows "Çevrimdışı" label
    const offlineElements = screen.getAllByText('Çevrimdışı');
    expect(offlineElements.length).toBeGreaterThanOrEqual(1);
  });

  // 5. Shows TLS warning when verification disabled
  it('shows TLS warning badge when verify_tls is false', async () => {
    render(<DevicesPage />);

    // The device with verify_tls: false should show TLS warning
    // ShieldOff icon with "Uyarı" text and title "TLS doğrulaması devre dışı"
    const tlsWarningElements = await screen.findAllByTitle('TLS doğrulaması devre dışı');
    expect(tlsWarningElements.length).toBeGreaterThanOrEqual(1);
  });

  // 6. Shows auth failure / error state
  it('shows error state when fetching devices fails', async () => {
    (getDevices as any).mockRejectedValue(new Error('Sunucu hatası'));

    render(<DevicesPage />);

    expect(await screen.findByText('Sunucu hatası')).toBeInTheDocument();
  });

  // 7. Handles test connection action
  it('handles test connection action and updates device status', async () => {
    (testDeviceConnection as any).mockResolvedValue({
      success: true,
      message: 'Bağlantı başarılı',
    });

    render(<DevicesPage />);

    // Wait for devices to load
    await screen.findByText('FortiGate-1');

    // Find and click the test connection button for the offline device
    // The button has title "Test Et"
    const testButtons = screen.getAllByTitle('Test Et');
    expect(testButtons.length).toBeGreaterThanOrEqual(1);

    // Click test on the first device
    const user = userEvent.setup();
    await user.click(testButtons[0]);

    // Wait for the success message
    expect(await screen.findByText('Bağlantı başarılı')).toBeInTheDocument();
    expect(testDeviceConnection).toHaveBeenCalledWith('1');
  });

  // 8. Test connection failure
  it('shows failure message when test connection fails', async () => {
    (testDeviceConnection as any).mockResolvedValue({
      success: false,
      message: 'Bağlantı başarısız: Timeout',
    });

    render(<DevicesPage />);

    await screen.findByText('FortiGate-1');

    const testButtons = screen.getAllByTitle('Test Et');
    const user = userEvent.setup();
    await user.click(testButtons[0]);

    expect(await screen.findByText('Bağlantı başarısız: Timeout')).toBeInTheDocument();
  });
});
