import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import {
  getAuthMethodsConfig,
  getSmsAuthStatus,
  getSmsAuthConfig,
  updateSmsAuthConfig,
  testSmsAuth,
  updateWhatsAppConfig,
  testWhatsApp,
  updateLdapConfig,
  testLdapConnection,
  getMeetingCodes,
  createMeetingCode,
  deleteMeetingCode,
  getLocalUsers,
  createLocalUser,
  updateLocalUser,
  deleteLocalUser,
  getVpnMfaConfig,
  updateVpnMfaConfig,
  getVpnMfaUsers,
  createVpnMfaUser,
  setupVpnMfaTotp,
  deleteVpnMfaUser,
  generateVpnMfaRadiusConfig,
  testVpnRadius,
} from "../lib/api";
import {
  MessageCircle,
  Server,
  QrCode,
  Users,
  Plus,
  Trash2,
  Edit3,
  Save,
  RefreshCw,
  Send,
  CheckCircle2,
  XCircle,
  Activity,
  ShieldCheck,
  Check,
  Copy,
} from "lucide-react";

const BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function generateTotpSecret(length = 20) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  let bits = 0;
  let value = 0;
  let output = "";
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  return output;
}

const vpnMethodLabel = (method: string) =>
  method === "totp" ? "Authenticator (TOTP)" : method === "sms" ? "SMS OTP" : "E-posta OTP";

export const AuthMethodsPage: React.FC = () => {
  const routeLocation = useLocation();
  const [activeTab, setActiveTab] = useState<"sms" | "vpn" | "whatsapp" | "ldap" | "meeting" | "users">(
    routeLocation.pathname === "/vpn-mfa" ? "vpn" : "sms"
  );
  const [config, setConfig] = useState<any>({ whatsapp: {}, ldap: {} });
  const [smsStatus, setSmsStatus] = useState<any>(null);
  const [smsConfig, setSmsConfig] = useState<any>({
    provider: "console",
    username: "",
    password: "",
    api_key: "",
    api_secret: "",
    sender: "",
    http_url: "",
    http_token: "",
    http_template: "",
    provider_options: {},
  });
  const [smsTestPhone, setSmsTestPhone] = useState("");
  const [smsTestMessage, setSmsTestMessage] = useState("Hotspot SMS test mesajı");
  const [meetingCodes, setMeetingCodes] = useState<any[]>([]);
  const [localUsers, setLocalUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [testing, setTesting] = useState(false);
  const [waTestPhone, setWaTestPhone] = useState("");
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [userForm, setUserForm] = useState({
    username: "",
    password: "",
    display_name: "",
    email: "",
    phone: "",
    role: "guest",
  });
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [codeForm, setCodeForm] = useState({
    code: "",
    event_name: "",
    max_uses: 50,
    duration_minutes: 480,
    expires_at: "",
  });
  const [vpnConfig, setVpnConfig] = useState<any>({
    is_enabled: false,
    radius_listener_host: "",
    radius_listener_port: 1812,
    radius_nas_ip: "",
    radius_accounting_port: 1813,
    radius_secret_configured: false,
    radius_shared_secret: "",
    allowed_groups: [],
    mfa_method: "totp",
    sms_template: "VPN giriş doğrulama kodunuz: {code}",
  });
  const [vpnUsers, setVpnUsers] = useState<any[]>([]);
  const [vpnUserForm, setVpnUserForm] = useState({
    username: "",
    mfa_method: "totp",
    secret: "",
    phone: "",
    email: "",
  });
  const [vpnBusy, setVpnBusy] = useState(false);
  const [showVpnUserForm, setShowVpnUserForm] = useState(false);
  const [totpSetup, setTotpSetup] = useState<any | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const [c, sms, smsCfg, m, u] = await Promise.all([
        getAuthMethodsConfig().catch(() => ({ whatsapp: {}, ldap: {} })),
        getSmsAuthStatus().catch(() => null),
        getSmsAuthConfig().catch(() => null),
        getMeetingCodes().catch(() => []),
        getLocalUsers().catch(() => []),
      ]);
      setConfig(c || { whatsapp: {}, ldap: {} });
      setMeetingCodes(Array.isArray(m) ? m : []);
      setLocalUsers(Array.isArray(u) ? u : []);
      setSmsStatus(sms);
      if (smsCfg) setSmsConfig((current: any) => ({ ...current, ...smsCfg }));
      const [vpn, registered] = await Promise.allSettled([getVpnMfaConfig(), getVpnMfaUsers()]);
      if (vpn.status === "fulfilled" && vpn.value) setVpnConfig((current: any) => ({ ...current, ...vpn.value }));
      if (registered.status === "fulfilled" && Array.isArray(registered.value)) setVpnUsers(registered.value);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showSuccess = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleWaSave = async () => {
    try {
      await updateWhatsAppConfig(config.whatsapp);
      showSuccess();
    } catch (err) {
      console.error(err);
    }
  };

  const handleLdapSave = async () => {
    try {
      await updateLdapConfig(config.ldap);
      showSuccess();
    } catch (err) {
      console.error(err);
    }
  };

  const handleLdapTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await testLdapConnection();
      setTestResult(res);
    } catch (err: any) {
      setTestResult({ success: false, message: err.message });
    } finally {
      setTesting(false);
    }
  };

  const handleSmsSave = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const saved = await updateSmsAuthConfig(smsConfig);
      setSmsConfig((current: any) => ({
        ...current,
        ...saved,
      }));
      setSmsStatus((current: any) => ({
        ...current,
        provider: saved.provider,
        configured: saved.configured,
        source: saved.source,
        sender: saved.sender,
      }));
      showSuccess();
    } catch (err: any) {
      setTestResult({ success: false, message: err?.message || "SMS ayarları kaydedilemedi" });
    } finally {
      setTesting(false);
    }
  };

  const handleSmsTest = async () => {
    if (!smsTestPhone.trim()) return;
    setTesting(true);
    setTestResult(null);
    try {
      setTestResult(await testSmsAuth(smsTestPhone, smsTestMessage));
    } catch (err: any) {
      setTestResult({ success: false, message: err?.message || "SMS testi başarısız" });
    } finally {
      setTesting(false);
    }
  };

  const handleVpnSave = async () => {
    setVpnBusy(true);
    try {
      const payload = {
        ...vpnConfig,
        radius_listener_port: Number(vpnConfig.radius_listener_port) || 1812,
        radius_accounting_port: Number(vpnConfig.radius_accounting_port) || 1813,
        radius_shared_secret: vpnConfig.radius_shared_secret?.trim() || undefined,
        sms_template: vpnConfig.sms_template?.trim() || undefined,
      };
      await updateVpnMfaConfig(payload);
      setVpnConfig((v: any) => ({
        ...v,
        radius_shared_secret: "",
        radius_secret_configured: Boolean(v.radius_shared_secret?.trim()) || v.radius_secret_configured,
      }));
      showSuccess();
    } catch (err: any) {
      setTestResult({ success: false, message: err?.message || "VPN MFA ayarı kaydedilemedi" });
    } finally {
      setVpnBusy(false);
    }
  };

  const handleVpnRadiusTest = async () => {
    setVpnBusy(true);
    setTestResult(null);
    try {
      setTestResult(await testVpnRadius());
    } catch (err: any) {
      setTestResult({ ok: false, message: err?.message || "RADIUS bağlantı testi başarısız" });
    } finally {
      setVpnBusy(false);
    }
  };

  const handleVpnUserSave = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!vpnUserForm.username.trim()) return;
    if (vpnUserForm.mfa_method === "sms" && !vpnUserForm.phone.trim()) {
      setTestResult({ success: false, message: "SMS MFA için telefon numarası gereklidir." });
      return;
    }
    if (vpnUserForm.mfa_method === "email" && !vpnUserForm.email.trim()) {
      setTestResult({ success: false, message: "E-posta MFA için e-posta adresi gereklidir." });
      return;
    }
    setVpnBusy(true);
    try {
      const payload = {
        ...vpnUserForm,
        username: vpnUserForm.username.trim(),
        secret: vpnUserForm.secret || undefined,
        phone: vpnUserForm.phone || undefined,
        email: vpnUserForm.email || undefined,
      };
      const created = await createVpnMfaUser(payload);
      setVpnUsers((current) => [...current, created]);
      setVpnUserForm({
        username: "",
        mfa_method: vpnConfig.mfa_method || "totp",
        secret: "",
        phone: "",
        email: "",
      });
      setShowVpnUserForm(false);
      showSuccess();
    } catch (err: any) {
      setTestResult({ success: false, message: err?.message || "VPN kullanıcısı eklenemedi" });
    } finally {
      setVpnBusy(false);
    }
  };

  const handleVpnTotpSetup = async (item: any) => {
    setVpnBusy(true);
    try {
      const setup = await setupVpnMfaTotp(item.id);
      setTotpSetup(setup);
      showSuccess();
    } catch (err: any) {
      setTestResult({ success: false, message: err?.message || "TOTP kurulumu başarısız" });
    } finally {
      setVpnBusy(false);
    }
  };

  const handleVpnUserDelete = async (id: string) => {
    if (!confirm("Bu VPN kullanıcısının MFA kaydını silmek istediğinize emin misiniz?")) return;
    try {
      await deleteVpnMfaUser(id);
      setVpnUsers((current) => current.filter((item) => item.id !== id));
      showSuccess();
    } catch (err: any) {
      setTestResult({ success: false, message: err?.message || "VPN kullanıcısı silinemedi" });
    }
  };

  const openUserCreate = () => {
    setEditingUser(null);
    setUserForm({ username: "", password: "", display_name: "", email: "", phone: "", role: "guest" });
    setShowUserModal(true);
  };

  const openUserEdit = (u: any) => {
    setEditingUser(u);
    setUserForm({
      username: u.username,
      password: "",
      display_name: u.display_name,
      email: u.email || "",
      phone: u.phone || "",
      role: u.role || "guest",
    });
    setShowUserModal(true);
  };

  const handleUserSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingUser) {
        const payload = { ...userForm };
        if (!payload.password) delete (payload as any).password;
        const updated = await updateLocalUser(editingUser.id, payload);
        setLocalUsers(localUsers.map((u) => (u.id === editingUser.id ? updated : u)));
      } else {
        const created = await createLocalUser(userForm);
        setLocalUsers([created, ...localUsers]);
      }
      setShowUserModal(false);
      showSuccess();
    } catch (err) {
      console.error(err);
    }
  };

  const handleUserDelete = async (id: string) => {
    if (!confirm("Bu kullanıcıyı silmek istediğinize emin misiniz?")) return;
    try {
      await deleteLocalUser(id);
      setLocalUsers(localUsers.filter((u) => u.id !== id));
      showSuccess();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCodeSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const created = await createMeetingCode({
        ...codeForm,
        expires_at: new Date(codeForm.expires_at).toISOString(),
      });
      setMeetingCodes([created, ...meetingCodes]);
      setShowCodeModal(false);
      showSuccess();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCodeDelete = async (id: string) => {
    if (!confirm("Bu toplantı kodunu silmek istediğinize emin misiniz?")) return;
    try {
      await deleteMeetingCode(id);
      setMeetingCodes(meetingCodes.filter((c) => c.id !== id));
      showSuccess();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Doğrulama &amp; Kimlik Yöntemleri
            </h2>
            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
              Auth Gateway
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            SMS sağlayıcıları, FortiGate VPN 2FA/MFA (RADIUS), Active Directory / LDAP ve etkinlik kodları.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadData}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs font-medium text-emerald-800 dark:border-emerald-900/40 dark:bg-emerald-950/30 dark:text-emerald-300 flex items-center gap-2">
          <Check className="h-4 w-4 text-emerald-600" />
          İşlem başarıyla tamamlandı!
        </div>
      )}

      {/* 2. Standard 4 KPI Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">SMS Gateway</span>
            <MessageCircle className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold capitalize text-slate-900 dark:text-white">
              {smsStatus?.provider || smsConfig.provider || "Console"}
            </span>
            <span className="text-[11px] text-slate-500">{smsStatus?.configured ? "Üretim" : "Demo"}</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">FortiGate RADIUS</span>
            <Server className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white">
              {vpnConfig.is_enabled ? "Aktif" : "Devre Dışı"}
            </span>
            <span className="text-[11px] text-slate-500">Port {vpnConfig.radius_listener_port || 1812}</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">VPN MFA Kullanıcıları</span>
            <ShieldCheck className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white">{vpnUsers.length}</span>
            <span className="text-[11px] text-slate-500">
              {vpnUsers.filter((u) => u.mfa_method === "totp").length} TOTP
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplantı Kodları</span>
            <QrCode className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white">{meetingCodes.length}</span>
            <span className="text-[11px] text-slate-500">etkin kod</span>
          </div>
        </div>
      </div>

      {/* 3. Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2 text-xs">
        {[
          { id: "sms", label: "Portal SMS / OTP", icon: MessageCircle },
          { id: "vpn", label: "VPN 2FA / MFA (FortiGate)", icon: ShieldCheck },
          { id: "whatsapp", label: "WhatsApp OTP", icon: MessageCircle },
          { id: "ldap", label: "LDAP / Active Directory", icon: Server },
          { id: "meeting", label: "Toplantı Kodları", icon: QrCode },
          { id: "users", label: "Manuel Kullanıcılar", icon: Users },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setActiveTab(tab.id as any);
                setTestResult(null);
              }}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold transition ${
                isActive
                  ? "bg-blue-600 text-white shadow-xs"
                  : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 4. Tab Contents */}

      {/* TAB 1: SMS / OTP */}
      {activeTab === "sms" && (
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(300px,0.65fr)]">
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs">
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Portal SMS / OTP Sağlayıcısı</h3>
                <p className="text-xs text-slate-500">Misafir doğrulama kodları seçilen sağlayıcı üzerinden gönderilir.</p>
              </div>
              <span
                className={`shrink-0 rounded-md px-2 py-0.5 text-[10px] font-semibold ${
                  smsStatus?.configured
                    ? "bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-900/50"
                    : "bg-amber-50 text-amber-800 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-900/50"
                }`}
              >
                {smsStatus?.configured ? "Üretim Modu" : "Demo Modu"}
              </span>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">SMS Sağlayıcısı</label>
                <select
                  value={smsConfig.provider || "console"}
                  onChange={(e) =>
                    setSmsConfig((v: any) => ({ ...v, provider: e.target.value, provider_options: {} }))
                  }
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                >
                  <option value="console">Console (Demo Modu - Loga Yazar)</option>
                  <option value="netgsm">NetGSM (Türkiye)</option>
                  <option value="iletimerkezi">İleti Merkezi</option>
                  <option value="vatansms">VatanSMS</option>
                  <option value="twilio">Twilio</option>
                  <option value="http">Özel HTTP Gateway</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Gönderici Başlığı (Header)</label>
                <input
                  value={smsConfig.sender || ""}
                  onChange={(e) => setSmsConfig((v: any) => ({ ...v, sender: e.target.value }))}
                  placeholder="HOTSPOT"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
            </div>

            {smsConfig.provider === "netgsm" && (
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-3 dark:border-slate-800 dark:bg-slate-950/50">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">NetGSM Kullanıcı Kodu</label>
                    <input
                      value={smsConfig.username || ""}
                      onChange={(e) => setSmsConfig((v: any) => ({ ...v, username: e.target.value }))}
                      placeholder="850xxxx"
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">NetGSM API Şifresi</label>
                    <input
                      type="password"
                      autoComplete="new-password"
                      value={smsConfig.password || ""}
                      onChange={(e) => setSmsConfig((v: any) => ({ ...v, password: e.target.value }))}
                      placeholder="••••••••"
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                    />
                  </div>
                </div>
              </div>
            )}

            {smsConfig.provider === "vatansms" && (
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-3 dark:border-slate-800 dark:bg-slate-950/50">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">VatanSMS API ID</label>
                    <input
                      value={smsConfig.username || ""}
                      onChange={(e) => setSmsConfig((v: any) => ({ ...v, username: e.target.value }))}
                      placeholder="API_ID"
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">VatanSMS API Anahtarı</label>
                    <input
                      type="password"
                      autoComplete="new-password"
                      value={smsConfig.api_key || ""}
                      onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_key: e.target.value }))}
                      placeholder="••••••••"
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                    />
                  </div>
                </div>
              </div>
            )}

            {smsConfig.provider === "iletimerkezi" && (
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-3 dark:border-slate-800 dark:bg-slate-950/50">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">İleti Merkezi API Key</label>
                    <input
                      type="password"
                      autoComplete="new-password"
                      value={smsConfig.api_key || ""}
                      onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_key: e.target.value }))}
                      placeholder="••••••••"
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">İleti Merkezi API Hash</label>
                    <input
                      type="password"
                      autoComplete="new-password"
                      value={smsConfig.api_secret || ""}
                      onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_secret: e.target.value }))}
                      placeholder="••••••••"
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleSmsSave}
                disabled={testing}
                className="rounded-lg bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 transition"
              >
                SMS Ayarlarını Kaydet
              </button>
            </div>

            {/* Test SMS Block */}
            <div className="border-t border-slate-100 pt-3 dark:border-slate-800 space-y-2">
              <div className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Send className="h-3.5 w-3.5 text-blue-500" /> Test SMS Gönder
              </div>
              <div className="flex gap-2">
                <input
                  value={smsTestPhone}
                  onChange={(e) => setSmsTestPhone(e.target.value)}
                  placeholder="5XX XXX XX XX"
                  className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800 flex-1"
                />
                <button
                  type="button"
                  onClick={handleSmsTest}
                  disabled={testing || !smsTestPhone.trim()}
                  className="rounded-lg bg-slate-800 px-4 py-1.5 font-semibold text-white hover:bg-slate-700 disabled:opacity-40 transition flex items-center gap-1.5"
                >
                  {testing ? <RefreshCw className="h-3 w-3 animate-spin" /> : null} Gönder
                </button>
              </div>

              {testResult && activeTab === "sms" && (
                <div
                  className={`rounded-lg border p-2.5 text-xs ${
                    testResult.success
                      ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-emerald-300"
                      : "border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900/50 dark:bg-rose-950/20 dark:text-rose-300"
                  }`}
                >
                  {testResult.message}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-4 text-xs">
            <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
              <h4 className="font-bold text-slate-900 dark:text-white border-b border-slate-100 pb-2 dark:border-slate-800">
                SMS Durumu
              </h4>
              <div className="space-y-2 text-slate-600 dark:text-slate-400">
                <div className="flex justify-between">
                  <span>Aktif Sağlayıcı:</span>
                  <strong className="text-slate-900 dark:text-white capitalize">
                    {smsStatus?.provider || smsConfig.provider || "Console"}
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span>OTP Kod Uzunluğu:</span>
                  <strong className="text-slate-900 dark:text-white">{smsStatus?.otp_length || 6} hane</strong>
                </div>
                <div className="flex justify-between">
                  <span>Geçerlilik Süresi:</span>
                  <strong className="text-slate-900 dark:text-white">
                    {Math.round((smsStatus?.otp_ttl_seconds || 180) / 60)} dakika
                  </strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: VPN MFA (RADIUS) */}
      {activeTab === "vpn" && (
        <div className="space-y-6 text-xs">
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900/70">
            <div className="flex items-start gap-3">
              <ShieldCheck className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                  FortiGate Dahili FreeRADIUS &amp; 2FA / MFA Servisi
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  FreeRADIUS Hotspot servisiyle tümleşik çalışır. FortiGate SSL-VPN veya Captive Portal için ikinci faktör (TOTP Authenticator, SMS veya E-posta) sağlar.
                </p>
              </div>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-12">
            <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
                <h4 className="font-bold text-slate-900 dark:text-white">RADIUS Sunucu &amp; MFA Ayarları</h4>
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={Boolean(vpnConfig.is_enabled)}
                    onChange={(e) => setVpnConfig((v: any) => ({ ...v, is_enabled: e.target.checked }))}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                  />
                  Servis Aktif
                </label>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">İkinci Faktör (MFA)</label>
                  <select
                    value={vpnConfig.mfa_method || "totp"}
                    onChange={(e) => setVpnConfig((v: any) => ({ ...v, mfa_method: e.target.value }))}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                  >
                    <option value="totp">Authenticator (Google/Microsoft TOTP)</option>
                    <option value="sms">SMS OTP</option>
                    <option value="email">E-Posta OTP</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Auth Port (UDP)</label>
                  <input
                    type="number"
                    value={vpnConfig.radius_listener_port || 1812}
                    onChange={(e) =>
                      setVpnConfig((v: any) => ({ ...v, radius_listener_port: Number(e.target.value) }))
                    }
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">RADIUS Shared Secret</label>
                  <input
                    type="password"
                    autoComplete="new-password"
                    value={vpnConfig.radius_shared_secret || ""}
                    onChange={(e) => setVpnConfig((v: any) => ({ ...v, radius_shared_secret: e.target.value }))}
                    placeholder={
                      vpnConfig.radius_secret_configured
                        ? "Secret kayıtlı (Değiştirmek için yazın)"
                        : "FortiGate RADIUS şifresi"
                    }
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleVpnSave}
                  disabled={vpnBusy}
                  className="rounded-lg bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 transition"
                >
                  Ayarları Kaydet
                </button>
                <button
                  type="button"
                  onClick={handleVpnRadiusTest}
                  disabled={vpnBusy}
                  className="rounded-lg border border-slate-300 bg-white px-3 py-2 font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200"
                >
                  RADIUS Test Et
                </button>
              </div>

              {testResult && activeTab === "vpn" && (
                <div
                  className={`rounded-lg border p-2.5 text-xs ${
                    testResult.ok || testResult.success
                      ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-emerald-300"
                      : "border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900/50 dark:bg-rose-950/20 dark:text-rose-300"
                  }`}
                >
                  {testResult.message || (testResult.ok ? "Bağlantı başarılı" : "Hata oluştu")}
                </div>
              )}
            </div>

            {/* VPN Users List (6 Cols) */}
            <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
                <h4 className="font-bold text-slate-900 dark:text-white">Kayıtlı VPN MFA Kullanıcıları</h4>
                <button
                  type="button"
                  onClick={() => setShowVpnUserForm(!showVpnUserForm)}
                  className="rounded-lg bg-blue-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-700 transition flex items-center gap-1"
                >
                  <Plus className="h-3 w-3" /> Kullanıcı Ekle
                </button>
              </div>

              {showVpnUserForm && (
                <form onSubmit={handleVpnUserSave} className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-2 dark:border-slate-800 dark:bg-slate-950">
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">FortiGate Kullanıcı Adı</label>
                    <input
                      required
                      value={vpnUserForm.username}
                      onChange={(e) => setVpnUserForm((v) => ({ ...v, username: e.target.value }))}
                      placeholder="alice.vpn"
                      className="w-full rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs dark:border-slate-700 dark:bg-slate-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">MFA Yöntemi</label>
                    <select
                      value={vpnUserForm.mfa_method}
                      onChange={(e) => setVpnUserForm((v) => ({ ...v, mfa_method: e.target.value }))}
                      className="w-full rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs dark:border-slate-700 dark:bg-slate-800"
                    >
                      <option value="totp">Authenticator (TOTP)</option>
                      <option value="sms">SMS OTP</option>
                      <option value="email">E-Posta OTP</option>
                    </select>
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowVpnUserForm(false)}
                      className="rounded-md border px-2.5 py-1 text-slate-600 hover:bg-slate-100 text-xs"
                    >
                      İptal
                    </button>
                    <button type="submit" className="rounded-md bg-blue-600 px-3 py-1 text-white text-xs font-semibold">
                      Kaydet
                    </button>
                  </div>
                </form>
              )}

              <div className="overflow-x-auto max-h-[360px]">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50/50 text-[10px] uppercase font-semibold text-slate-500 dark:border-slate-800 dark:bg-slate-950">
                      <th className="px-3 py-2">Kullanıcı</th>
                      <th className="px-3 py-2">Yöntem</th>
                      <th className="px-3 py-2 text-right">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {vpnUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                        <td className="px-3 py-2 font-semibold text-slate-900 dark:text-slate-100">{u.username}</td>
                        <td className="px-3 py-2">{vpnMethodLabel(u.mfa_method)}</td>
                        <td className="px-3 py-2 text-right space-x-1">
                          {u.mfa_method === "totp" && (
                            <button
                              type="button"
                              onClick={() => handleVpnTotpSetup(u)}
                              className="rounded p-1 text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800"
                              title="QR Kodu Göster"
                            >
                              <QrCode className="h-3.5 w-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleVpnUserDelete(u.id)}
                            className="rounded p-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800"
                            title="Sil"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {!vpnUsers.length && (
                      <tr>
                        <td colSpan={3} className="py-6 text-center text-slate-400">
                          Kayıtlı VPN MFA kullanıcısı bulunamadı.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: WhatsApp OTP */}
      {activeTab === "whatsapp" && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs max-w-2xl">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 pb-3 dark:border-slate-800">
            WhatsApp OTP Gateway
          </h3>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">WhatsApp API URL</label>
              <input
                type="text"
                value={config.whatsapp?.api_url || ""}
                onChange={(e) =>
                  setConfig({ ...config, whatsapp: { ...config.whatsapp, api_url: e.target.value } })
                }
                placeholder="https://graph.facebook.com/v18.0/..."
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Access Token</label>
              <input
                type="password"
                value={config.whatsapp?.access_token || ""}
                onChange={(e) =>
                  setConfig({ ...config, whatsapp: { ...config.whatsapp, access_token: e.target.value } })
                }
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleWaSave}
                className="rounded-lg bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700"
              >
                Kaydet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: LDAP / Active Directory */}
      {activeTab === "ldap" && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs max-w-2xl">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 pb-3 dark:border-slate-800">
            Active Directory / LDAP Entegrasyonu
          </h3>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">LDAP Sunucu URL (ldap:// veya ldaps://)</label>
              <input
                type="text"
                value={config.ldap?.server_url || ""}
                onChange={(e) =>
                  setConfig({ ...config, ldap: { ...config.ldap, server_url: e.target.value } })
                }
                placeholder="ldap://ad.company.local:389"
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Bind DN</label>
              <input
                type="text"
                value={config.ldap?.bind_dn || ""}
                onChange={(e) =>
                  setConfig({ ...config, ldap: { ...config.ldap, bind_dn: e.target.value } })
                }
                placeholder="cn=admin,dc=company,dc=local"
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Base DN</label>
              <input
                type="text"
                value={config.ldap?.base_dn || ""}
                onChange={(e) =>
                  setConfig({ ...config, ldap: { ...config.ldap, base_dn: e.target.value } })
                }
                placeholder="ou=Users,dc=company,dc=local"
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleLdapSave}
                className="rounded-lg bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700"
              >
                Kaydet
              </button>
              <button
                type="button"
                onClick={handleLdapTest}
                disabled={testing}
                className="rounded-lg border border-slate-300 bg-white px-3 py-2 font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200"
              >
                Bağlantıyı Test Et
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: Toplantı Kodları */}
      {activeTab === "meeting" && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Etkinlik &amp; Toplantı Kodları</h3>
            <button
              type="button"
              onClick={() => {
                setCodeForm({
                  code: "",
                  event_name: "",
                  max_uses: 50,
                  duration_minutes: 480,
                  expires_at: new Date(Date.now() + 86400000 * 30).toISOString().slice(0, 16),
                });
                setShowCodeModal(true);
              }}
              className="rounded-lg bg-blue-600 px-3 py-1.5 font-semibold text-white hover:bg-blue-700 flex items-center gap-1"
            >
              <Plus className="h-3.5 w-3.5" /> Yeni Kod
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/50 text-[10px] uppercase font-semibold text-slate-500 dark:border-slate-800 dark:bg-slate-950">
                  <th className="px-3 py-2">Kod</th>
                  <th className="px-3 py-2">Etkinlik</th>
                  <th className="px-3 py-2">Kullanım</th>
                  <th className="px-3 py-2">Süre (Dk)</th>
                  <th className="px-3 py-2">Son Geçerlilik</th>
                  <th className="px-3 py-2 text-right">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {meetingCodes.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                    <td className="px-3 py-2 font-mono font-bold text-blue-600 dark:text-blue-400">{c.code}</td>
                    <td className="px-3 py-2 text-slate-800 dark:text-slate-200">{c.event_name}</td>
                    <td className="px-3 py-2 text-slate-500">
                      {c.used_count || 0} / {c.max_uses}
                    </td>
                    <td className="px-3 py-2 text-slate-500">{c.duration_minutes} dk</td>
                    <td className="px-3 py-2 text-slate-500">{new Date(c.expires_at).toLocaleDateString("tr-TR")}</td>
                    <td className="px-3 py-2 text-right">
                      <button
                        type="button"
                        onClick={() => handleCodeDelete(c.id)}
                        className="rounded p-1 text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {!meetingCodes.length && (
                  <tr>
                    <td colSpan={6} className="py-6 text-center text-slate-400">
                      Henüz oluşturulmuş toplantı kodu yok.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 6: Manuel Kullanıcılar */}
      {activeTab === "users" && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Manuel / Yerel Kullanıcılar</h3>
            <button
              type="button"
              onClick={openUserCreate}
              className="rounded-lg bg-blue-600 px-3 py-1.5 font-semibold text-white hover:bg-blue-700 flex items-center gap-1"
            >
              <Plus className="h-3.5 w-3.5" /> Yeni Kullanıcı
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/50 text-[10px] uppercase font-semibold text-slate-500 dark:border-slate-800 dark:bg-slate-950">
                  <th className="px-3 py-2">Kullanıcı Adı</th>
                  <th className="px-3 py-2">Ad Soyad</th>
                  <th className="px-3 py-2">E-Posta / Tel</th>
                  <th className="px-3 py-2">Rol</th>
                  <th className="px-3 py-2">Durum</th>
                  <th className="px-3 py-2 text-right">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {localUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                    <td className="px-3 py-2 font-semibold text-slate-900 dark:text-slate-100">{u.username}</td>
                    <td className="px-3 py-2 text-slate-500">{u.display_name}</td>
                    <td className="px-3 py-2 text-slate-500">{u.email || u.phone || "—"}</td>
                    <td className="px-3 py-2 capitalize">{u.role}</td>
                    <td className="px-3 py-2">
                      <span className="rounded-md bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">
                        {u.is_active ? "Aktif" : "Pasif"}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-right space-x-1">
                      <button
                        type="button"
                        onClick={() => openUserEdit(u)}
                        className="rounded p-1 text-blue-600 hover:bg-blue-50"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUserDelete(u.id)}
                        className="rounded p-1 text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {!localUsers.length && (
                  <tr>
                    <td colSpan={6} className="py-6 text-center text-slate-400">
                      Kayıtlı manuel kullanıcı bulunamadı.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TOTP Setup QR Modal */}
      {totpSetup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setTotpSetup(null)}>
          <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-3 text-xs" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-slate-100 pb-2 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white">Authenticator QR Kurulumu</h3>
              <button type="button" onClick={() => setTotpSetup(null)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>
            <div
              className="mx-auto flex h-48 w-48 items-center justify-center rounded-lg border border-slate-200 bg-white p-2"
              dangerouslySetInnerHTML={{ __html: totpSetup.qr_code_svg || "" }}
            />
            <div className="rounded-lg bg-slate-50 p-2.5 font-mono text-[11px] text-slate-700 text-center break-all dark:bg-slate-950 dark:text-slate-300">
              {totpSetup.totp_secret || totpSetup.secret}
            </div>
            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setTotpSetup(null)}
                className="rounded-lg bg-blue-600 px-4 py-1.5 font-semibold text-white"
              >
                Tamamla
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Meeting Code Modal */}
      {showCodeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowCodeModal(false)}>
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-bold text-slate-900 dark:text-white">Yeni Toplantı Kodu Oluştur</h3>
            <form onSubmit={handleCodeSave} className="space-y-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Kod</label>
                <input
                  type="text"
                  required
                  value={codeForm.code}
                  onChange={(e) => setCodeForm({ ...codeForm, code: e.target.value.toUpperCase() })}
                  placeholder="TOPLANTI2026"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800 font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Etkinlik Adı</label>
                <input
                  type="text"
                  required
                  value={codeForm.event_name}
                  onChange={(e) => setCodeForm({ ...codeForm, event_name: e.target.value })}
                  placeholder="Yönetim Kurulu Toplantısı"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Maks. Kullanım</label>
                  <input
                    type="number"
                    value={codeForm.max_uses}
                    onChange={(e) => setCodeForm({ ...codeForm, max_uses: Number(e.target.value) })}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Süre (Dk)</label>
                  <input
                    type="number"
                    value={codeForm.duration_minutes}
                    onChange={(e) => setCodeForm({ ...codeForm, duration_minutes: Number(e.target.value) })}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Son Geçerlilik Tarihi</label>
                <input
                  type="datetime-local"
                  required
                  value={codeForm.expires_at}
                  onChange={(e) => setCodeForm({ ...codeForm, expires_at: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCodeModal(false)}
                  className="rounded-lg border px-3 py-1.5 text-slate-600 hover:bg-slate-50"
                >
                  İptal
                </button>
                <button type="submit" className="rounded-lg bg-blue-600 px-4 py-1.5 font-semibold text-white">
                  Oluştur
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* User Create/Edit Modal */}
      {showUserModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowUserModal(false)}>
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-bold text-slate-900 dark:text-white">
              {editingUser ? "Kullanıcıyı Düzenle" : "Yeni Manuel Kullanıcı"}
            </h3>
            <form onSubmit={handleUserSave} className="space-y-3">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Kullanıcı Adı</label>
                <input
                  type="text"
                  required
                  value={userForm.username}
                  onChange={(e) => setUserForm({ ...userForm, username: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">
                  {editingUser ? "Yeni Şifre (boş bırakılırsa değişmez)" : "Şifre"}
                </label>
                <input
                  type="password"
                  value={userForm.password}
                  onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                  required={!editingUser}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Ad Soyad</label>
                <input
                  type="text"
                  value={userForm.display_name}
                  onChange={(e) => setUserForm({ ...userForm, display_name: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowUserModal(false)}
                  className="rounded-lg border px-3 py-1.5 text-slate-600 hover:bg-slate-50"
                >
                  İptal
                </button>
                <button type="submit" className="rounded-lg bg-blue-600 px-4 py-1.5 font-semibold text-white">
                  {editingUser ? "Güncelle" : "Oluştur"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
