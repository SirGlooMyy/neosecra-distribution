import React, { useEffect, useState } from "react";
import {
  closeSession,
  getSessionCorrelation,
  getSessions,
  approveSession,
  rejectSession,
  retryAuthorization,
  syncSessionWithDevice,
} from "../lib/api";
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Globe,
  Layers,
  RefreshCw,
  Search,
  ShieldAlert,
  ShieldCheck,
  UserX,
  WifiOff,
  XCircle,
  AlertTriangle,
  X,
  Play,
  Wifi,
  LogOut,
  ExternalLink,
} from "lucide-react";
import { ConfirmModal } from "../components/ui/ConfirmModal";

type SessionStatus = "active" | "closed" | "expired" | "pending" | string;
type AuthStatus = "pending" | "authorized" | "failed" | "revoking" | "revoked" | string;

interface SessionPolicy {
  group_id?: string | null;
  group_name?: string | null;
  scope?: string | null;
  scope_label?: string | null;
  location_id?: string | null;
  access_start?: string | null;
  access_end?: string | null;
  priority?: number | null;
  is_default?: boolean;
  bandwidth_up?: number | null;
  bandwidth_down?: number | null;
  session_timeout?: number | null;
  idle_timeout?: number | null;
}

interface SessionMeta {
  group_policy?: SessionPolicy;
  authorization_status?: AuthStatus;
  authorize_error?: string | null;
  authorize_retry_count?: number;
  fortigate_sync_status?: "healthy" | "unhealthy" | "not-configured" | string;
  external_session_id?: string | null;
  device_name?: string | null;
  authorized_at?: string | null;
  revoked_at?: string | null;
  [key: string]: any;
}

interface RawSession {
  id: string;
  customer_id?: string;
  location_id?: string | null;
  device_id?: string | null;
  identity_verification_id?: string | null;
  voucher_id?: string | null;
  group_id?: string | null;
  phone?: string | null;
  mac: string;
  ip?: string | null;
  nas_ip?: string | null;
  ssid?: string | null;
  auth_method: string;
  status: SessionStatus;
  started_at: string;
  expires_at?: string | null;
  ended_at?: string | null;
  authorize_ok: boolean;
  authorize_message?: string | null;
  authorization_status?: AuthStatus;
  authorization_error_message?: string | null;
  authorized_at?: string | null;
  revoked_at?: string | null;
  external_session_id?: string | null;
  radius_session_id?: string | null;
  bytes_in?: number;
  bytes_out?: number;
  is_active?: boolean;
  meta?: SessionMeta;
  created_at?: string;
}

interface SessionRow {
  id: string;
  user: string;
  fullName?: string;
  phone?: string;
  tcNo?: string;
  department?: string;
  displayName?: string;
  mac: string;
  ip: string;
  gateway: string;
  device: string;
  startTime: string;
  durationMinutes: number;
  status: SessionStatus;
  authMethod: string;
  groupName: string;
  groupScope: string;
  accessWindow: string;
  firewallState: string;
  firewallClassName: string;
  authorizeMessage: string | null;
  /* New fields */
  authorizeStatus: AuthStatus;
  authorizeError: string | null;
  fortigateSyncStatus: string;
  deviceName: string | null;
  externalSessionId: string | null;
  authorizedAt: string | null;
  revokedAt: string | null;
  meta?: SessionMeta;
}

interface SessionCorrelation {
  guest_session_id: string;
  customer_id: string;
  location_id?: string | null;
  device_id?: string | null;
  mac: string;
  ip?: string | null;
  phone?: string | null;
  nas_ip?: string | null;
  auth_method: string;
  identity_verification_id?: string | null;
  voucher_id?: string | null;
  radius_session_id?: string | null;
  started_at?: string | null;
  ended_at?: string | null;
  expires_at?: string | null;
  status: string;
  bytes_in: number;
  bytes_out: number;
  sources_matched: Record<string, boolean>;
  evidence_timeline?: SessionCorrelationTimelineItem[];
  missing_sources?: string[];
  stitching_summary?: string;
  case_window_minutes?: number;
  investigation_filters?: Record<string, any>;
  related_log_count?: number;
  related_log_groups?: SessionCorrelationGroup[];
  case_summary?: string;
  complete: boolean;
}

interface SessionCorrelationTimelineItem {
  source: string;
  label: string;
  matched: boolean;
  timestamp?: string | null;
  details?: string | null;
}

interface SessionCorrelationGroup {
  correlation_id: string;
  correlation_type: string;
  reason: string;
  hit_count: number;
  first_timestamp: string;
  last_timestamp: string;
  sample_hostname?: string | null;
  sample_source_ip?: string | null;
  sample_session_id?: string | null;
}

const FORTIGATE_SYNC_LABELS: Record<string, string> = {
  healthy: "Sağlıklı",
  unhealthy: "Sorunlu",
  "not-configured": "Yapılandırılmamış",
};

const FORTIGATE_SYNC_COLORS: Record<string, string> = {
  healthy:
    "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30",
  unhealthy:
    "bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-900/30",
  "not-configured":
    "bg-slate-50 dark:bg-slate-950/30 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800",
};

const AUTH_STATUS_LABELS: Record<string, string> = {
  pending: "Bekliyor",
  authorized: "Yetkilendirildi",
  failed: "Başarısız",
  revoking: "İptal Ediliyor",
  revoked: "İptal Edildi",
};

const AUTH_STATUS_COLORS: Record<string, string> = {
  pending:
    "bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-900/30",
  authorized:
    "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30",
  failed:
    "bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-900/30",
  revoking:
    "bg-indigo-50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-400 border-indigo-100 dark:border-indigo-900/30",
  revoked:
    "bg-slate-50 dark:bg-slate-950/30 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800",
};

const AUTH_STATUS_ICONS: Record<string, React.FC<{ className?: string }>> = {
  pending: Clock,
  authorized: ShieldCheck,
  failed: ShieldAlert,
  revoking: AlertCircle,
  revoked: XCircle,
};

const formatDate = (value?: string | null) => {
  if (!value) return "—";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return "—";
  return parsed.toLocaleString("tr-TR");
};

const formatDuration = (start: string, end?: string | null) => {
  const startDate = new Date(start);
  if (Number.isNaN(startDate.getTime())) return "—";
  const endDate = end ? new Date(end) : new Date();
  if (Number.isNaN(endDate.getTime())) return "—";
  const diffMs = endDate.getTime() - startDate.getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 60) return `${mins} dk`;
  const hours = Math.floor(mins / 60);
  const rem = mins % 60;
  return `${hours} s ${rem} dk`;
};

export const SessionsPage: React.FC = () => {
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "pending" | "failed">("all");
  const [detailsId, setDetailsId] = useState<string | null>(null);
  const [correlation, setCorrelation] = useState<SessionCorrelation | null>(null);
  const [correlationLoading, setCorrelationLoading] = useState(false);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [syncingId, setSyncingId] = useState<string | null>(null);
  const [revokingId, setRevokingId] = useState<string | null>(null);
  const [confirmRevoke, setConfirmRevoke] = useState<string | null>(null);
  const [approvalActionId, setApprovalActionId] = useState<string | null>(null);

  const isOffline = error === "offline";

  const normalizeSession = (raw: any): SessionRow => {
    const meta: SessionMeta = raw.meta || {};
    const groupPolicy = meta?.group_policy;
    const formData = meta?.form_data && typeof meta.form_data === "object" ? meta.form_data : {};
    const fullName = formData.full_name || formData.first_name || formData.ad_soyad || "";
    const phone = raw.phone || formData.phone || formData.gsm || formData.telefon || "";
    const tcNo = formData.tc_number || formData.tc_no || formData.tc || raw.tc_number || "";
    const department = formData.department || formData.unit || formData.birim || formData.company || formData.firma || "";
    const displayName = fullName || phone || (tcNo ? `TC: ${tcNo}` : "") || raw.username || raw.user || raw.mac || "Misafir";

    const isClosed = raw.status === "closed" || raw.status === "expired" || raw.is_active === false;
    const status: SessionStatus = isClosed ? (raw.status || "closed") : (raw.authorize_ok ? "active" : raw.status || "pending");
    const authorizeStatus: AuthStatus = isClosed
      ? (raw.authorization_status === "revoking" ? "revoking" : "revoked")
      : (raw.authorization_status || meta?.authorization_status || (raw.authorize_ok ? "authorized" : raw.authorize_message ? "failed" : "pending"));
    const firewallState = isClosed ? "blocked" : (raw.authorize_ok ? "allowed" : "blocked");

    return {
      id: String(raw.id),
      user: displayName,
      fullName,
      phone,
      tcNo,
      department,
      displayName,
      mac: raw.mac || "—",
      ip: raw.ip || "—",
      gateway: raw.nas_ip || "—",
      device: raw.ssid || "—",
      startTime: raw.started_at || "",
      durationMinutes: raw.started_at
        ? Math.round((Date.now() - new Date(raw.started_at).getTime()) / 60000)
        : 0,
      status,
      authMethod: raw.auth_method || "—",
      groupName: groupPolicy?.group_name || "—",
      groupScope: groupPolicy?.scope_label || groupPolicy?.scope || "—",
      accessWindow: groupPolicy?.access_start || groupPolicy?.access_end
        ? `${groupPolicy?.access_start || "?"} - ${groupPolicy?.access_end || "?"}`
        : "—",
      firewallState,
      firewallClassName: firewallState === "allowed"
        ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400"
        : "bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400",
      authorizeMessage: raw.authorize_message || null,
      /* New fields */
      authorizeStatus,
      authorizeError: raw.authorization_error_message || meta?.authorize_error || (raw.authorize_ok === false && raw.authorize_message ? raw.authorize_message : null),
      fortigateSyncStatus: meta?.fortigate_sync_status || "not-configured",
      deviceName: meta?.device_name || null,
      externalSessionId: raw.external_session_id || meta?.external_session_id || raw.radius_session_id || null,
      authorizedAt: raw.authorized_at || meta?.authorized_at || null,
      revokedAt: raw.revoked_at || meta?.revoked_at || null,
      meta,
    };
  };

  const loadSessions = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getSessions();
      setSessions((data || []).map(normalizeSession));
    } catch (err: any) {
      console.error(err);
      if (err instanceof TypeError || err.message?.includes("Failed to fetch") || err.message?.includes("NetworkError")) {
        setError("offline");
      } else {
        setError(err?.message || "Oturumlar yüklenirken bir hata oluştu.");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSessions();
  }, []);

  const handleCorrelation = async (id: string) => {
    if (detailsId === id) {
      setDetailsId(null);
      setCorrelation(null);
      return;
    }
    setDetailsId(id);
    setCorrelationLoading(true);
    setCorrelation(null);
    try {
      const result = await getSessionCorrelation(id);
      setCorrelation(result);
    } catch {
      setCorrelation(null);
    } finally {
      setCorrelationLoading(false);
    }
  };

  const handleRetryAuthorization = async (sessionId: string) => {
    setRetryingId(sessionId);
    try {
      await retryAuthorization(sessionId);
      setSessions((prev) =>
        prev.map((s) =>
          s.id === sessionId ? { ...s, authorizeStatus: "pending" as AuthStatus, authorizeError: null } : s
        )
      );
    } catch (err: any) {
      console.error("Retry authorization failed:", err);
    } finally {
      setRetryingId(null);
    }
  };

  const handleSyncWithDevice = async (sessionId: string) => {
    setSyncingId(sessionId);
    try {
      await syncSessionWithDevice(sessionId);
      loadSessions();
    } catch (err: any) {
      console.error("Sync with device failed:", err);
    } finally {
      setSyncingId(null);
    }
  };

  const handleApproval = async (sessionId: string, decision: "approve" | "reject") => {
    setApprovalActionId(sessionId);
    try {
      if (decision === "approve") await approveSession(sessionId);
      else await rejectSession(sessionId);
      await loadSessions();
    } catch (err: any) {
      console.error("Session approval failed:", err);
    } finally {
      setApprovalActionId(null);
    }
  };

  const handleRevokeSession = async (sessionId: string) => {
    setRevokingId(sessionId);
    try {
      await closeSession(sessionId, "Yönetici tarafından sonlandırıldı");
      setSessions((prev) =>
        prev.map((s) =>
          s.id === sessionId ? { ...s, authorizeStatus: "revoking" as AuthStatus } : s
        )
      );
      setConfirmRevoke(null);
    } catch (err: any) {
      console.error("Revoke failed:", err);
    } finally {
      setRevokingId(null);
    }
  };

  const filtered = sessions.filter((s) => {
    const q = search.toLowerCase();
    if (statusFilter === "active" && s.status !== "active") return false;
    if (statusFilter === "pending" && s.authorizeStatus !== "pending" && s.status !== "pending") return false;
    if (statusFilter === "failed" && s.authorizeStatus !== "failed") return false;
    return (
      s.mac.toLowerCase().includes(q) ||
      s.ip.toLowerCase().includes(q) ||
      s.user.toLowerCase().includes(q) ||
      s.gateway.toLowerCase().includes(q) ||
      s.groupName.toLowerCase().includes(q) ||
      (s.deviceName && s.deviceName.toLowerCase().includes(q)) ||
      (s.externalSessionId && s.externalSessionId.toLowerCase().includes(q))
    );
  });

  const activeCount = sessions.filter((s) => s.status === "active").length;
  const pendingCount = sessions.filter((s) => s.authorizeStatus === "pending" || s.status === "pending").length;
  const failedCount = sessions.filter((s) => s.authorizeStatus === "failed").length;
  const revokingCount = sessions.filter((s) => s.authorizeStatus === "revoking").length;

  // Loading Skeleton
  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Oturumlar</h2>
            <p className="text-sm text-slate-500">Aktif ve geçmiş oturumları görüntüleyin, yetkilendirme ve sonlandırma işlemlerini yönetin.</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm animate-pulse">
              <div className="h-3 w-20 bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="mt-2 h-8 w-16 bg-slate-200 dark:bg-slate-800 rounded" />
            </div>
          ))}
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
          <div className="p-6 space-y-4 animate-pulse">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex gap-4">
                <div className="h-4 w-1/5 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/6 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/6 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/6 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/12 bg-slate-200 dark:bg-slate-800 rounded" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Error / Offline State
  if (error && sessions.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Oturumlar</h2>
            <p className="text-sm text-slate-500">Aktif ve geçmiş oturumları görüntüleyin, yetkilendirme ve sonlandırma işlemlerini yönetin.</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 shadow-sm">
          <div className="flex flex-col items-center justify-center text-center">
            {isOffline ? (
              <>
                <div className="p-4 rounded-full bg-amber-100 dark:bg-amber-900/30 mb-4">
                  <WifiOff className="w-10 h-10 text-amber-600 dark:text-amber-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50 mb-2">Sunucuya Bağlanılamıyor</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6">
                  Backend sunucusuna ulaşılamıyor. İnternet bağlantınızı ve API adresini kontrol edin.
                </p>
              </>
            ) : (
              <>
                <div className="p-4 rounded-full bg-rose-100 dark:bg-rose-900/30 mb-4">
                  <AlertTriangle className="w-10 h-10 text-rose-600 dark:text-rose-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50 mb-2">Yükleme Hatası</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6">{error}</p>
              </>
            )}
            <button
              onClick={loadSessions}
              className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Tekrar Dene
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Empty State
  if (!loading && sessions.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Oturumlar</h2>
            <p className="text-sm text-slate-500">Aktif ve geçmiş oturumları görüntüleyin, yetkilendirme ve sonlandırma işlemlerini yönetin.</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 shadow-sm">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="p-4 rounded-full bg-slate-100 dark:bg-slate-800 mb-4">
              <Layers className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50 mb-2">Henüz Oturum Yok</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6">
              Sistemde kayıtlı hiçbir oturum bulunamadı. Kullanıcılar bağlandıkça oturumlar burada görünecektir.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Oturumlar
            </h2>
            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Canlı Oturum Takibi
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            FortiGate yetkilendirmesi, aktif IP/MAC eşleşmeleri ve 5651 oturum zinciri.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadSessions}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
        </div>
      </div>

      {/* 2. Stats Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Oturum</span>
            <Layers className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{sessions.length}</span>
            <span className="text-xs text-slate-500">kayıtlı</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Aktif Oturumlar</span>
            <Wifi className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{activeCount}</span>
            <span className="text-xs text-slate-500">çevrimiçi</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Onay Bekleyenler</span>
            <Clock className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{pendingCount}</span>
            <span className="text-xs text-slate-500">istek</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Yetkilendirme Hatası</span>
            <AlertCircle className="h-4 w-4 text-rose-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{failedCount}</span>
            <span className="text-xs text-slate-500">oturum</span>
          </div>
        </div>
      </div>

      {/* Offline Banner */}
      {isOffline && (
        <div className="flex items-center gap-3 px-4 py-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/30 rounded-xl text-xs text-amber-700 dark:text-amber-400">
          <WifiOff className="w-4 h-4 flex-shrink-0" />
          <span>Sunucuya bağlantı kurulamıyor. Veriler önbellekten gösteriliyor olabilir.</span>
        </div>
      )}

      {/* 3. Search & Filter */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-2.5 shadow-xs dark:border-slate-800 dark:bg-slate-900 sm:flex-row text-xs">
        <div className="relative flex-1 flex items-center">
          <Search className="absolute left-3 text-slate-400 w-4 h-4" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="MAC, IP, cihaz adı, oturum ID veya kullanıcı ara..."
            className="w-full rounded-lg border border-slate-200 bg-white py-1.5 pl-9 pr-3 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as any)}
          className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
        >
          <option value="all">Tüm Durumlar</option>
          <option value="active">Aktif Oturumlar</option>
          <option value="pending">Onay Bekleyenler</option>
          <option value="failed">Yetki Hatası</option>
        </select>
      </div>

      {/* Table */}
      <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Kullanıcı / MAC</th>
                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">IP / Gateway</th>
                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Yetki Durumu</th>
                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">FortiGate Sync</th>
                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Cihaz</th>
                <th className="hidden 2xl:table-cell px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Dış Oturum ID</th>
                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Başlangıç / Süre</th>
                <th className="hidden 2xl:table-cell px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Yetkilendirme</th>
                <th className="hidden xl:table-cell px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Yöntem / Grup</th>
                <th className="hidden xl:table-cell px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Güvenlik Duvarı</th>
                <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((s) => {
                const AuthIcon = AUTH_STATUS_ICONS[s.authorizeStatus] || Clock;
                return (
                  <React.Fragment key={s.id}>
                    <tr
                      className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors cursor-pointer"
                      onClick={() => handleCorrelation(s.id)}
                    >
                      {/* User / MAC */}
                      <td className="px-4 py-4">
                        <div className="text-sm font-semibold text-slate-950 dark:text-slate-50 truncate max-w-[200px]">{s.fullName || s.user}</div>
                        <div className="text-xs text-slate-400 flex flex-wrap items-center gap-1.5 mt-0.5">
                          {s.phone && <span>📞 {s.phone}</span>}
                          {s.tcNo && <span>🆔 {s.tcNo}</span>}
                          {s.department && <span className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">🏢 {s.department}</span>}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400 mt-0.5">{s.mac}</div>
                      </td>

                      {/* IP / Gateway */}
                      <td className="px-4 py-4">
                        <div className="text-sm text-slate-600 dark:text-slate-400">{s.ip}</div>
                        <div className="text-xs text-slate-400">{s.gateway}</div>
                      </td>

                      {/* Authorization Status */}
                      <td className="px-4 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                          AUTH_STATUS_COLORS[s.authorizeStatus] || AUTH_STATUS_COLORS.pending
                        }`}>
                          <AuthIcon className="w-3 h-3 mr-1 flex-shrink-0" />
                          {AUTH_STATUS_LABELS[s.authorizeStatus] || s.authorizeStatus}
                        </span>
                      </td>

                      {/* FortiGate Sync Status */}
                      <td className="px-4 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                          FORTIGATE_SYNC_COLORS[s.fortigateSyncStatus] || FORTIGATE_SYNC_COLORS["not-configured"]
                        }`}>
                          {FORTIGATE_SYNC_LABELS[s.fortigateSyncStatus] || s.fortigateSyncStatus}
                        </span>
                      </td>

                      {/* Device Name */}
                      <td className="px-4 py-4 text-sm text-slate-600 dark:text-slate-400">
                        {s.deviceName || s.device || "—"}
                      </td>

                      {/* External Session ID */}
                      <td className="hidden 2xl:table-cell px-4 py-4">
                        {s.externalSessionId ? (
                          <span className="text-xs font-mono text-slate-500 truncate max-w-[100px] block" title={s.externalSessionId}>
                            {s.externalSessionId.slice(0, 16)}...
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400">—</span>
                        )}
                      </td>

                      {/* Start Time / Duration */}
                      <td className="px-4 py-4">
                        <div className="text-sm text-slate-600 dark:text-slate-400">{formatDate(s.startTime)}</div>
                        <div className="text-xs text-slate-400">
                          <Clock className="w-3 h-3 inline mr-1" />
                          {formatDuration(s.startTime)}
                        </div>
                      </td>

                      {/* Authorized At / Revoked At or Error */}
                      <td className="hidden 2xl:table-cell px-4 py-4 text-sm">
                        {s.authorizeStatus === "authorized" && s.authorizedAt && (
                          <div className="text-xs text-emerald-600 dark:text-emerald-400">
                            Yetki: {formatDate(s.authorizedAt)}
                          </div>
                        )}
                        {(s.authorizeStatus === "revoked" || s.authorizeStatus === "revoking") && s.revokedAt && (
                          <div className="text-xs text-slate-500">
                            İptal: {formatDate(s.revokedAt)}
                          </div>
                        )}
                        {s.authorizeStatus === "failed" && s.authorizeError && (
                          <div className="text-xs text-rose-500" title={s.authorizeError}>
                            {s.authorizeError.length > 40 ? s.authorizeError.slice(0, 40) + "..." : s.authorizeError}
                          </div>
                        )}
                        {s.authorizeStatus === "pending" && (
                          <span className="text-xs text-amber-500">Yetkilendirme bekliyor</span>
                        )}
                        {!s.authorizedAt && !s.revokedAt && s.authorizeStatus !== "failed" && s.authorizeStatus !== "pending" && (
                          <span className="text-xs text-slate-400">—</span>
                        )}
                      </td>

                      {/* Auth Method / Group */}
                      <td className="hidden xl:table-cell px-4 py-4">
                        <div className="text-sm text-slate-600 dark:text-slate-400">{s.authMethod}</div>
                        <div className="text-xs text-slate-400">{s.groupName}</div>
                      </td>

                      {/* Firewall */}
                      <td className="hidden xl:table-cell px-4 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium ${s.firewallClassName}`}>
                          {s.firewallState === "allowed" ? (
                            <><CheckCircle2 className="w-3 h-3 mr-1" />İzinli</>
                          ) : (
                            <><XCircle className="w-3 h-3 mr-1" />Engelli</>
                          )}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-4 text-sm text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="inline-flex items-center gap-1">
                          {s.status === "pending" && s.meta?.approval?.required && (
                            <>
                              <button onClick={() => handleApproval(s.id, "approve")} disabled={approvalActionId === s.id} title="Erişimi onayla" className="inline-flex items-center gap-1 rounded-xl bg-emerald-50 px-2 py-1.5 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-100 disabled:opacity-50 dark:bg-emerald-950/30 dark:text-emerald-400">
                                <CheckCircle2 className="h-3.5 w-3.5" /> Onayla
                              </button>
                              <button onClick={() => handleApproval(s.id, "reject")} disabled={approvalActionId === s.id} title="Erişimi reddet" className="inline-flex items-center gap-1 rounded-xl bg-rose-50 px-2 py-1.5 text-[11px] font-semibold text-rose-700 hover:bg-rose-100 disabled:opacity-50 dark:bg-rose-950/30 dark:text-rose-400">
                                <XCircle className="h-3.5 w-3.5" /> Reddet
                              </button>
                            </>
                          )}
                          {s.authorizeStatus === "failed" && (
                            <button
                              onClick={() => handleRetryAuthorization(s.id)}
                              disabled={retryingId === s.id}
                              title="Yetkilendirmeyi Tekrar Dene"
                              className="inline-flex items-center text-amber-600 hover:text-amber-950 dark:text-amber-400 dark:hover:text-amber-300 p-2 hover:bg-amber-50 dark:hover:bg-amber-950/30 rounded-xl transition-all disabled:opacity-50"
                            >
                              <Play className={`w-4 h-4 ${retryingId === s.id ? "animate-spin" : ""}`} />
                            </button>
                          )}
                          <button
                            onClick={() => handleSyncWithDevice(s.id)}
                            disabled={syncingId === s.id}
                            title="FortiGate ile Senkronize Et"
                            className="inline-flex items-center text-sky-600 hover:text-sky-950 dark:text-sky-400 dark:hover:text-sky-300 p-2 hover:bg-sky-50 dark:hover:bg-sky-950/30 rounded-xl transition-all disabled:opacity-50"
                          >
                            <Wifi className={`w-4 h-4 ${syncingId === s.id ? "animate-spin" : ""}`} />
                          </button>
                          {(s.authorizeStatus === "authorized" || s.authorizeStatus === "pending") && (
                            <button
                              onClick={() => setConfirmRevoke(s.id)}
                              title="Oturumu Sonlandır"
                              className="inline-flex items-center text-rose-600 hover:text-rose-950 dark:text-rose-400 dark:hover:text-rose-300 p-2 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-all"
                            >
                              <LogOut className="w-4 h-4" />
                            </button>
                          )}
                          {s.authorizeStatus === "revoking" && (
                            <span className="text-xs text-indigo-500 italic">İptal ediliyor...</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  </React.Fragment>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={11} className="px-6 py-12 text-center text-slate-500">
                    <div className="flex flex-col items-center gap-2">
                      <Search className="w-5 h-5 text-slate-400" />
                      <span>Arama kriterlerinize uygun oturum bulunamadı.</span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Revoke Confirmation Modal */}
      <ConfirmModal
        open={confirmRevoke !== null}
        title="Oturumu Sonlandır"
        message="Bu oturumu sonlandırmak istediğinize emin misiniz? Bu işlem kullanıcının bağlantısını kesecek ve yetkilendirmeyi iptal edecektir."
        confirmLabel="Evet, Sonlandır"
        cancelLabel="İptal"
        variant="danger"
        loading={revokingId === confirmRevoke}
        onConfirm={() => {
          if (confirmRevoke) handleRevokeSession(confirmRevoke);
        }}
        onCancel={() => setConfirmRevoke(null)}
      />

      {/* Correlation Detail Panel */}
      {detailsId && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-500" />
                Oturum Korelasyonu
              </h3>
              <button
                onClick={() => {
                  setDetailsId(null);
                  setCorrelation(null);
                }}
                className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
              >
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            {correlationLoading && (
              <div className="flex items-center justify-center py-8">
                <RefreshCw className="w-5 h-5 text-indigo-500 animate-spin" />
                <span className="ml-2 text-sm text-slate-500">Korelasyon yükleniyor...</span>
              </div>
            )}

            {!correlationLoading && correlation && (
              <>
                {/* Timeline */}
                <div className="space-y-3">
                  {(correlation.evidence_timeline || []).map((item, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                      <div className={`p-1.5 rounded-full ${
                        item.matched
                          ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400"
                          : "bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400"
                      }`}>
                        {item.matched ? (
                          <CheckCircle2 className="w-4 h-4" />
                        ) : (
                          <Clock className="w-4 h-4" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase">
                            {item.source}
                          </span>
                          <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${
                            item.matched
                              ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400"
                              : "bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400"
                          }`}>
                            {item.matched ? "eşleşti" : "bekliyor"}
                          </span>
                        </div>
                        <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-500 dark:text-slate-400">
                          {item.timestamp && (
                            <span className="inline-flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5" />
                              {new Date(item.timestamp).toLocaleString("tr-TR")}
                            </span>
                          )}
                          {item.details && <span className="break-words">{item.details}</span>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
                    <div className="font-semibold text-slate-900 dark:text-slate-50">Kimlik</div>
                    <div className="text-slate-500">MAC: {correlation.mac}</div>
                    <div className="text-slate-500">IP: {correlation.ip || "—"}</div>
                    <div className="text-slate-500">Telefon: {correlation.phone || "—"}</div>
                    <div className="text-slate-500">RADIUS Session: {correlation.radius_session_id || "—"}</div>
                  </div>
                  <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
                    <div className="font-semibold text-slate-900 dark:text-slate-50">Zaman</div>
                    <div className="text-slate-500">Başlangıç: {correlation.started_at ? new Date(correlation.started_at).toLocaleString("tr-TR") : "—"}</div>
                    <div className="text-slate-500">Bitiş: {correlation.ended_at ? new Date(correlation.ended_at).toLocaleString("tr-TR") : "—"}</div>
                    <div className="text-slate-500">Süre Sonu: {correlation.expires_at ? new Date(correlation.expires_at).toLocaleString("tr-TR") : "—"}</div>
                    <div className="text-slate-500">Durum: {correlation.status}</div>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 flex items-center gap-3 bg-slate-50 dark:bg-slate-950/30">
                  {correlation.complete ? <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" /> : <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400" />}
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-slate-50">
                      {correlation.complete ? "Korelasyon tamam" : "Korelasyon eksik"}
                    </div>
                    <div className="text-sm text-slate-500 dark:text-slate-400">
                      Portal, kimlik ve dış kaynaklar aynı oturumda eşleştiriliyor; timeline hangi kaydın ne zaman bağlandığını gösteriyor.
                    </div>
                  </div>
                </div>
              </>
            )}

            {!correlationLoading && !correlation && (
              <div className="text-sm text-slate-500">Korelasyon verisi bulunamadı.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
