import React, { useState, useEffect, useMemo } from "react";
import {
  getUserGroups,
  createUserGroup,
  updateUserGroup,
  deleteUserGroup,
  getCurrentScope,
  getLocations,
  getUserGroupPolicyPreview,
} from "../lib/api";
import {
  Users,
  Plus,
  Edit2,
  Trash2,
  Save,
  X,
  Clock,
  Gauge,
  HardDrive,
  Laptop,
  Check,
  Search,
  RefreshCw,
  Copy,
  Sliders,
  Layers,
  HelpCircle,
  Shield,
} from "lucide-react";

interface UserGroup {
  id: string;
  customer_id: string;
  location_id: string | null;
  name: string;
  description: string;
  bandwidth_up: number | null;
  bandwidth_down: number | null;
  session_timeout: number | null;
  idle_timeout: number | null;
  daily_quota: number | null;
  weekly_quota: number | null;
  monthly_quota: number | null;
  hourly_quota: number | null;
  max_sessions: number;
  is_default: boolean;
  is_active: boolean;
  priority: number;
  access_start: string | null;
  access_end: string | null;
}

const buildEmptyForm = (customerId: string = "") => ({
  customer_id: customerId,
  location_id: null as string | null,
  name: "",
  description: "",
  bandwidth_up: null as number | null,
  bandwidth_down: null as number | null,
  session_timeout: null as number | null,
  idle_timeout: null as number | null,
  daily_quota: null as number | null,
  weekly_quota: null as number | null,
  monthly_quota: null as number | null,
  hourly_quota: null as number | null,
  max_sessions: 1,
  is_default: false,
  priority: 0,
  access_start: null as string | null,
  access_end: null as string | null,
});

const PRESET_DURATIONS = [
  { label: "1 Saat", minutes: 60 },
  { label: "8 Saat", minutes: 480 },
  { label: "1 Gün", minutes: 1440 },
  { label: "3 Gün", minutes: 4320 },
  { label: "5 Gün", minutes: 7200 },
  { label: "7 Gün", minutes: 10080 },
  { label: "15 Gün", minutes: 21600 },
  { label: "30 Gün", minutes: 43200 },
  { label: "Limitsiz", minutes: null },
];

const PRESET_DOWNLOADS = [
  { label: "Limitsiz", kbps: null },
  { label: "5 Mbps", kbps: 5120 },
  { label: "10 Mbps", kbps: 10240 },
  { label: "25 Mbps", kbps: 25600 },
  { label: "50 Mbps", kbps: 51200 },
  { label: "100 Mbps", kbps: 102400 },
];

const PRESET_UPLOADS = [
  { label: "Limitsiz", kbps: null },
  { label: "2 Mbps", kbps: 2048 },
  { label: "5 Mbps", kbps: 5120 },
  { label: "10 Mbps", kbps: 10240 },
  { label: "20 Mbps", kbps: 20480 },
];

export const UserGroupsPage: React.FC = () => {
  const [groups, setGroups] = useState<UserGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFormModal, setShowFormModal] = useState(false);
  const [showFlowModal, setShowFlowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [currentCustomerId, setCurrentCustomerId] = useState("");
  const [currentLocationId, setCurrentLocationId] = useState<string | null>(null);
  const [currentScopeLabel, setCurrentScopeLabel] = useState<string>("Genel Kapsam");
  const [locations, setLocations] = useState<any[]>([]);
  const [form, setForm] = useState(() => buildEmptyForm());
  const [formTab, setFormTab] = useState<"general" | "duration" | "qos" | "quota">("general");

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState("");
  const [locationFilter, setLocationFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState<"all" | "default" | "custom">("all");

  // Policy Preview
  const [policyPreview, setPolicyPreview] = useState<any>(null);
  const [policyPreviewLoading, setPolicyPreviewLoading] = useState(false);
  const [policyPreviewError, setPolicyPreviewError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await getUserGroups();
      setGroups(Array.isArray(data) ? data : []);
      if (!currentCustomerId && data?.[0]?.customer_id) {
        setCurrentCustomerId(String(data[0].customer_id));
      }
    } catch (err) {
      console.error("Gruplar yüklenemedi:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const [locs, scope] = await Promise.all([
          getLocations().catch(() => []),
          getCurrentScope().catch(() => null),
        ]);
        setLocations(Array.isArray(locs) ? locs : []);
        if (scope?.customer_id) {
          setCurrentCustomerId(scope.customer_id);
        }
        if (scope?.location_id) {
          setCurrentLocationId(scope.location_id);
        }
        setCurrentScopeLabel(
          scope?.location_id
            ? "Lokasyon Kapsamı"
            : scope?.customer_id
              ? "Müşteri Kapsamı"
              : "Genel Kapsam"
        );
      } catch (err) {
        console.error(err);
      }
    })();
  }, []);

  useEffect(() => {
    if (!currentCustomerId) return;
    setForm((prev) => (prev.customer_id === currentCustomerId ? prev : buildEmptyForm(currentCustomerId)));
  }, [currentCustomerId]);

  useEffect(() => {
    if (!currentLocationId) return;
    setForm((prev) => (prev.location_id === currentLocationId ? prev : { ...prev, location_id: currentLocationId }));
  }, [currentLocationId]);

  useEffect(() => {
    const customerId = currentCustomerId || form.customer_id;
    if (!customerId) return;

    let cancelled = false;
    const loadPolicyPreview = async () => {
      setPolicyPreviewLoading(true);
      setPolicyPreviewError(null);
      try {
        const preview = await getUserGroupPolicyPreview(customerId, form.location_id || null);
        if (!cancelled) setPolicyPreview(preview);
      } catch (err: any) {
        if (!cancelled) {
          console.error(err);
          setPolicyPreview(null);
          setPolicyPreviewError(err?.message || "Politika önizlemesi yüklenemedi.");
        }
      } finally {
        if (!cancelled) setPolicyPreviewLoading(false);
      }
    };

    void loadPolicyPreview();
    return () => {
      cancelled = true;
    };
  }, [currentCustomerId, form.customer_id, form.location_id, groups]);

  const resetForm = () => {
    setForm({
      ...buildEmptyForm(currentCustomerId),
      location_id: currentLocationId,
    });
    setEditingId(null);
    setShowFormModal(false);
    setFormTab("general");
  };

  const handleEdit = (g: UserGroup) => {
    setForm({
      customer_id: g.customer_id || currentCustomerId,
      location_id: g.location_id || currentLocationId,
      name: g.name,
      description: g.description || "",
      bandwidth_up: g.bandwidth_up,
      bandwidth_down: g.bandwidth_down,
      session_timeout: g.session_timeout,
      idle_timeout: g.idle_timeout,
      daily_quota: g.daily_quota,
      weekly_quota: g.weekly_quota,
      monthly_quota: g.monthly_quota,
      hourly_quota: g.hourly_quota,
      max_sessions: g.max_sessions || 1,
      is_default: g.is_default || false,
      priority: g.priority || 0,
      access_start: g.access_start,
      access_end: g.access_end,
    });
    setEditingId(g.id);
    setShowFormModal(true);
    setFormTab("general");
  };

  const handleClone = (g: UserGroup) => {
    setForm({
      customer_id: g.customer_id || currentCustomerId,
      location_id: g.location_id || currentLocationId,
      name: `${g.name} (Kopya)`,
      description: g.description || "",
      bandwidth_up: g.bandwidth_up,
      bandwidth_down: g.bandwidth_down,
      session_timeout: g.session_timeout,
      idle_timeout: g.idle_timeout,
      daily_quota: g.daily_quota,
      weekly_quota: g.weekly_quota,
      monthly_quota: g.monthly_quota,
      hourly_quota: g.hourly_quota,
      max_sessions: g.max_sessions || 1,
      is_default: false,
      priority: (g.priority || 0) + 1,
      access_start: null,
      access_end: null,
    });
    setEditingId(null);
    setShowFormModal(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) return;
    try {
      const payload = form.customer_id
        ? form
        : (() => {
            const { customer_id: _customerId, ...withoutCustomer } = form;
            return withoutCustomer;
          })();
      if (editingId) await updateUserGroup(editingId, payload);
      else await createUserGroup(payload);
      resetForm();
      await load();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`"${name}" kullanıcı grubunu silmek istediğinize emin misiniz?`)) return;
    try {
      await deleteUserGroup(id);
      await load();
    } catch (err) {
      console.error(err);
    }
  };

  const formatMin = (v: number | null | undefined) => {
    if (!v) return "Limitsiz";
    if (v % 1440 === 0) return `${v / 1440} Gün`;
    if (v >= 1440) return `${Math.floor(v / 1440)}g ${v % 1440}d`;
    if (v % 60 === 0) return `${v / 60} Saat`;
    if (v >= 60) return `${Math.floor(v / 60)}s ${v % 60}d`;
    return `${v} dk`;
  };

  const formatBandwidth = (kbps: number | null | undefined) => {
    if (!kbps) return "Limitsiz";
    if (kbps >= 1024) return `${(kbps / 1024).toFixed(kbps % 1024 === 0 ? 0 : 1)} Mbps`;
    return `${kbps} Kbps`;
  };

  const formatQuota = (mb: number | null | undefined) => {
    if (!mb) return "Limitsiz";
    if (mb >= 1024) return `${(mb / 1024).toFixed(mb % 1024 === 0 ? 0 : 1)} GB`;
    return `${mb} MB`;
  };

  const locationMap = useMemo(() => new Map(locations.map((loc: any) => [loc.id, loc.name])), [locations]);

  // Filtered Groups List
  const filteredGroups = useMemo(() => {
    return groups.filter((g) => {
      const matchesSearch =
        !searchQuery.trim() ||
        g.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (g.description && g.description.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesLocation =
        locationFilter === "all" ||
        (locationFilter === "global" && !g.location_id) ||
        g.location_id === locationFilter;

      const matchesType =
        typeFilter === "all" ||
        (typeFilter === "default" && g.is_default) ||
        (typeFilter === "custom" && !g.is_default);

      return matchesSearch && matchesLocation && matchesType;
    });
  }, [groups, searchQuery, locationFilter, typeFilter]);

  // Metrics
  const defaultGroup = useMemo(() => groups.find((g) => g.is_default), [groups]);
  const qosRestrictedCount = useMemo(() => groups.filter((g) => g.bandwidth_down || g.bandwidth_up).length, [groups]);
  const quotaRestrictedCount = useMemo(() => groups.filter((g) => g.daily_quota || g.monthly_quota).length, [groups]);

  return (
    <div className="space-y-6">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Erişim Profilleri
            </h2>
            <span className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <Layers className="h-3 w-3 text-slate-500" />
              {currentScopeLabel}
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Captive portal sonrası kullanıcılara uygulanacak yetki süresi, bant genişliği (QoS) ve kota kurallarını yapılandırın.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowFlowModal(true)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition"
          >
            <HelpCircle className="h-3.5 w-3.5 text-slate-500" />
            Otomasyon Akışı
          </button>
          <button
            type="button"
            onClick={load}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
          <button
            type="button"
            onClick={() => {
              resetForm();
              setShowFormModal(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
          >
            <Plus className="h-3.5 w-3.5" /> Yeni Profil
          </button>
        </div>
      </div>

      {/* 2. Standard 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Profil</span>
            <Users className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{groups.length}</span>
            <span className="text-xs text-slate-500">profil</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Varsayılan Profil</span>
            <Check className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-base font-bold text-slate-900 dark:text-slate-100 truncate">
              {defaultGroup ? defaultGroup.name : "Tanımsız"}
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">QoS Hız Sınırı</span>
            <Gauge className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{qosRestrictedCount}</span>
            <span className="text-xs text-slate-500">grupta aktif</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Kota Korumalı</span>
            <HardDrive className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{quotaRestrictedCount}</span>
            <span className="text-xs text-slate-500">grupta aktif</span>
          </div>
        </div>
      </div>

      {/* 3. Search & Filter Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between rounded-xl border border-slate-200 bg-white p-3 shadow-xs dark:border-slate-800 dark:bg-slate-900">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Profil veya açıklama filtrele..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500 focus:bg-white dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:focus:bg-slate-900"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
            className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium dark:border-slate-700 dark:bg-slate-850 text-slate-700 dark:text-slate-200"
          >
            <option value="all">Tüm Lokasyonlar</option>
            <option value="global">Müşteri Geneli</option>
            {locations.map((loc: any) => (
              <option key={loc.id} value={loc.id}>
                {loc.name}
              </option>
            ))}
          </select>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as any)}
            className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium dark:border-slate-700 dark:bg-slate-850 text-slate-700 dark:text-slate-200"
          >
            <option value="all">Tüm Profiller</option>
            <option value="default">Varsayılan</option>
            <option value="custom">Özel Tanımlar</option>
          </select>
        </div>
      </div>

      {/* 4. Group Cards Grid */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {loading ? (
          <div className="col-span-2 rounded-xl border border-slate-200 bg-white p-12 text-center text-slate-500 dark:border-slate-800 dark:bg-slate-900">
            <RefreshCw className="mx-auto h-5 w-5 animate-spin text-blue-500 mb-2" />
            Profiller yükleniyor...
          </div>
        ) : filteredGroups.length === 0 ? (
          <div className="col-span-2 rounded-xl border border-slate-200 bg-white p-12 text-center text-slate-500 dark:border-slate-800 dark:bg-slate-900">
            Kriterlere uygun erişim grubu bulunamadı.
          </div>
        ) : (
          filteredGroups.map((g) => {
            const locName = g.location_id ? locationMap.get(g.location_id) || "Lokasyon grubu" : "Müşteri geneli";
            return (
              <div
                key={g.id}
                className={`flex flex-col justify-between rounded-xl border bg-white p-5 shadow-xs transition dark:bg-slate-900 ${
                  g.is_default
                    ? "border-blue-300 dark:border-blue-800/80"
                    : "border-slate-200 dark:border-slate-800"
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">{g.name}</h3>
                        {g.is_default && (
                          <span className="inline-flex items-center gap-1 rounded-md bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 dark:bg-emerald-950/40 dark:border-emerald-800 dark:text-emerald-300">
                            Varsayılan
                          </span>
                        )}
                        <span className="rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                          {locName}
                        </span>
                        {g.priority > 0 && (
                          <span className="rounded-md border border-amber-200 bg-amber-50 px-2 py-0.5 text-[10px] font-medium text-amber-800 dark:border-amber-900/60 dark:bg-amber-950/30 dark:text-amber-300">
                            Öncelik: {g.priority}
                          </span>
                        )}
                      </div>
                      {g.description && (
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{g.description}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleClone(g)}
                        title="Profili Klonla"
                        className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleEdit(g)}
                        title="Profili Düzenle"
                        className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-blue-600 dark:hover:bg-slate-800"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(g.id, g.name)}
                        title="Profili Sil"
                        className="rounded-md p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-slate-800"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 pt-1">
                    <div className="rounded-lg border border-slate-100 bg-slate-50/80 p-2 text-center dark:border-slate-800 dark:bg-slate-950/50">
                      <div className="text-[10px] text-slate-400 font-medium">Azami Yetki</div>
                      <div className="mt-0.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                        {formatMin(g.session_timeout)}
                      </div>
                    </div>

                    <div className="rounded-lg border border-slate-100 bg-slate-50/80 p-2 text-center dark:border-slate-800 dark:bg-slate-950/50">
                      <div className="text-[10px] text-slate-400 font-medium">Hız Limiti (D/U)</div>
                      <div className="mt-0.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                        {g.bandwidth_down || g.bandwidth_up
                          ? `${formatBandwidth(g.bandwidth_down)} / ${formatBandwidth(g.bandwidth_up)}`
                          : "Limitsiz"}
                      </div>
                    </div>

                    <div className="rounded-lg border border-slate-100 bg-slate-50/80 p-2 text-center dark:border-slate-800 dark:bg-slate-950/50">
                      <div className="text-[10px] text-slate-400 font-medium">Eşzamanlı Cihaz</div>
                      <div className="mt-0.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                        {g.max_sessions || 1} Cihaz
                      </div>
                    </div>

                    <div className="rounded-lg border border-slate-100 bg-slate-50/80 p-2 text-center dark:border-slate-800 dark:bg-slate-950/50">
                      <div className="text-[10px] text-slate-400 font-medium">Günlük / Aylık Kota</div>
                      <div className="mt-0.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                        {g.daily_quota || g.monthly_quota
                          ? `${formatQuota(g.daily_quota)} / ${formatQuota(g.monthly_quota)}`
                          : "Limitsiz"}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2 text-[11px] text-slate-400 dark:border-slate-800">
                  <span>Boşta Kapatma: {formatMin(g.idle_timeout)}</span>
                  {g.access_start ? (
                    <span className="text-amber-600 font-medium">
                      Planlı: {new Date(g.access_start).toLocaleDateString("tr-TR")} - {g.access_end ? new Date(g.access_end).toLocaleDateString("tr-TR") : "Süresiz"}
                    </span>
                  ) : (
                    <span className="text-slate-500 font-medium">Sürekli Erişim</span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* 5. Otomasyon Akışı Modal */}
      {showFlowModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-xl rounded-xl border border-slate-200 bg-white p-5 shadow-xl dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Oturum Süresi ve FortiGate Entegrasyon Akışı
                </h3>
                <p className="text-xs text-slate-500">
                  Profil atama, hız limitleri ve yetki süresinin işleyişi.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowFlowModal(false)}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="grid gap-3 sm:grid-cols-3 text-xs">
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950 space-y-1">
                <span className="font-bold text-blue-600 dark:text-blue-400">1. Portal Doğrulaması</span>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                  Misafir giriş yaptığında lokasyona ve önceliğe göre aktif profil atanır.
                </p>
              </div>

              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950 space-y-1">
                <span className="font-bold text-blue-600 dark:text-blue-400">2. Dinamik Süre</span>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                  Kullanıcının yetki süresi kendi giriş anından itibaren bağımsız başlar.
                </p>
              </div>

              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950 space-y-1">
                <span className="font-bold text-blue-600 dark:text-blue-400">3. FortiGate & QoS</span>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                  Kullanıcı IP'si FortiGate Adres Grubuna eklenir ve Traffic Shaper kuralları uygulanır.
                </p>
              </div>
            </div>

            {policyPreview && (
              <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3 dark:border-slate-800 dark:bg-slate-950/60 text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-200">Etkin Politika Özeti: </span>
                <span className="text-slate-600 dark:text-slate-400">{policyPreview.selected_group?.policy_summary || policyPreview.message}</span>
              </div>
            )}

            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => setShowFlowModal(false)}
                className="rounded-lg bg-slate-800 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 transition"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Create / Edit Group Modal Dialog */}
      {showFormModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Sliders className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  {editingId ? "Erişim Profilini Düzenle" : "Yeni Erişim Profili Oluştur"}
                </h3>
              </div>
              <button
                type="button"
                onClick={resetForm}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Tabs */}
            <div className="flex border-b border-slate-100 dark:border-slate-800 gap-4 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setFormTab("general")}
                className={`pb-2 border-b-2 transition ${
                  formTab === "general"
                    ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                    : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                Temel Bilgiler
              </button>
              <button
                type="button"
                onClick={() => setFormTab("duration")}
                className={`pb-2 border-b-2 transition ${
                  formTab === "duration"
                    ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                    : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                Oturum Süresi
              </button>
              <button
                type="button"
                onClick={() => setFormTab("qos")}
                className={`pb-2 border-b-2 transition ${
                  formTab === "qos"
                    ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                    : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                Hız Limiti (QoS)
              </button>
              <button
                type="button"
                onClick={() => setFormTab("quota")}
                className={`pb-2 border-b-2 transition ${
                  formTab === "quota"
                    ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                    : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                Kota & Cihazlar
              </button>
            </div>

            {/* TAB 1: General */}
            {formTab === "general" && (
              <div className="grid gap-3 sm:grid-cols-2 text-xs">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Grup / Profil Adı *</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Örn: Misafir Standart, VIP"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Lokasyon</label>
                  <select
                    value={form.location_id || ""}
                    onChange={(e) => setForm({ ...form, location_id: e.target.value || null })}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  >
                    <option value="">Tüm Lokasyonlar (Müşteri Geneli)</option>
                    {locations.map((loc: any) => (
                      <option key={loc.id} value={loc.id}>
                        {loc.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Açıklama</label>
                  <input
                    type="text"
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    placeholder="Profil kullanım amacı"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Öncelik Seviyesi</label>
                  <input
                    type="number"
                    value={form.priority}
                    onChange={(e) => setForm({ ...form, priority: parseInt(e.target.value) || 0 })}
                    placeholder="0"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>

                <div className="flex items-center space-x-2 pt-5">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={form.is_default}
                      onChange={(e) => setForm({ ...form, is_default: e.target.checked })}
                      className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                    />
                    <span className="font-medium text-slate-700 dark:text-slate-300">Varsayılan Profil</span>
                  </label>
                </div>
              </div>
            )}

            {/* TAB 2: Duration */}
            {formTab === "duration" && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Azami Yetki Süresi</span>
                  <span className="font-bold text-blue-600 dark:text-blue-400">
                    Seçili: {formatMin(form.session_timeout)}
                  </span>
                </div>

                <div className="flex flex-wrap gap-2">
                  {PRESET_DURATIONS.map((p) => (
                    <button
                      key={p.label}
                      type="button"
                      onClick={() => setForm((f) => ({ ...f, session_timeout: p.minutes }))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                        form.session_timeout === p.minutes
                          ? "bg-blue-600 text-white"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">Özel (Dakika):</span>
                  <input
                    type="number"
                    placeholder="Örn: 4320"
                    value={form.session_timeout || ""}
                    onChange={(e) => setForm({ ...form, session_timeout: e.target.value ? parseInt(e.target.value) : null })}
                    className="w-36 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs dark:border-slate-700 dark:bg-slate-800 font-mono"
                  />
                  <span className="text-[11px] text-slate-400">Boş bırakılırsa limitsiz kabul edilir.</span>
                </div>
              </div>
            )}

            {/* TAB 3: QoS */}
            {formTab === "qos" && (
              <div className="space-y-4 text-xs">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">İndirme Hız Sınırı (Download)</span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">{formatBandwidth(form.bandwidth_down)}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {PRESET_DOWNLOADS.map((p) => (
                      <button
                        key={p.label}
                        type="button"
                        onClick={() => setForm((f) => ({ ...f, bandwidth_down: p.kbps }))}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                          form.bandwidth_down === p.kbps
                            ? "bg-blue-600 text-white"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-slate-500">Özel (Kbps):</span>
                    <input
                      type="number"
                      value={form.bandwidth_down || ""}
                      onChange={(e) => setForm({ ...form, bandwidth_down: e.target.value ? parseInt(e.target.value) : null })}
                      className="w-32 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs dark:border-slate-700 dark:bg-slate-800 font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">Yükleme Hız Sınırı (Upload)</span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">{formatBandwidth(form.bandwidth_up)}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {PRESET_UPLOADS.map((p) => (
                      <button
                        key={p.label}
                        type="button"
                        onClick={() => setForm((f) => ({ ...f, bandwidth_up: p.kbps }))}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                          form.bandwidth_up === p.kbps
                            ? "bg-blue-600 text-white"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-slate-500">Özel (Kbps):</span>
                    <input
                      type="number"
                      value={form.bandwidth_up || ""}
                      onChange={(e) => setForm({ ...form, bandwidth_up: e.target.value ? parseInt(e.target.value) : null })}
                      className="w-32 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs dark:border-slate-700 dark:bg-slate-800 font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: Quota */}
            {formTab === "quota" && (
              <div className="grid gap-3 sm:grid-cols-2 text-xs">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Eşzamanlı Cihaz / Oturum</label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={form.max_sessions}
                    onChange={(e) => setForm({ ...form, max_sessions: parseInt(e.target.value) || 1 })}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Boşta Kapatma / Idle Timeout (dk)</label>
                  <input
                    type="number"
                    value={form.idle_timeout || ""}
                    onChange={(e) => setForm({ ...form, idle_timeout: e.target.value ? parseInt(e.target.value) : null })}
                    placeholder="Örn: 30"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Günlük Kota (MB)</label>
                  <input
                    type="number"
                    value={form.daily_quota || ""}
                    onChange={(e) => setForm({ ...form, daily_quota: e.target.value ? parseInt(e.target.value) : null })}
                    placeholder="Örn: 5120 (5 GB)"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">Aylık Kota (MB)</label>
                  <input
                    type="number"
                    value={form.monthly_quota || ""}
                    onChange={(e) => setForm({ ...form, monthly_quota: e.target.value ? parseInt(e.target.value) : null })}
                    placeholder="Örn: 51200 (50 GB)"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                  />
                </div>
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                type="button"
                onClick={resetForm}
                className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={!form.name.trim()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition disabled:opacity-50"
              >
                <Save className="h-3.5 w-3.5" />
                {editingId ? "Değişiklikleri Kaydet" : "Profili Kaydet"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
