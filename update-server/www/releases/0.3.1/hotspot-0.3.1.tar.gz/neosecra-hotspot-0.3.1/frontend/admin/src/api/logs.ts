import { request, requestBlob } from '../lib/api';
import type { SearchFilters, SearchResponse, FacetResult, CorrelateResult, FirewallLog } from '../types/logs';

function buildSearchParams(filters: SearchFilters): URLSearchParams {
  const params = new URLSearchParams();
  if (filters.q) params.set('q', filters.q);
  if (filters.time_window) params.set('time_window', filters.time_window);
  if (filters.vendor) params.set('vendor', filters.vendor);
  if (filters.log_type?.length) params.set('log_type', filters.log_type.join(','));
  if (filters.severity?.length) params.set('severity', filters.severity.join(','));
  if (filters.action?.length) params.set('action', filters.action.join(','));
  if (filters.src_ip) params.set('src_ip', filters.src_ip);
  if (filters.dst_ip) params.set('dst_ip', filters.dst_ip);
  if (filters.src_port != null) params.set('src_port', String(filters.src_port));
  if (filters.dst_port != null) params.set('dst_port', String(filters.dst_port));
  if (filters.user) params.set('user', filters.user);
  if (filters.from) params.set('from', filters.from);
  if (filters.to) params.set('to', filters.to);
  // The advanced search API uses limit/offset (the legacy /firewall-logs
  // endpoint used page/page_size). Translate the UI pagination here so large
  // result sets do not silently return the same first page.
  const pageSize = filters.page_size || 50;
  const page = filters.page || 1;
  params.set('limit', String(pageSize));
  params.set('offset', String(Math.max(0, (page - 1) * pageSize)));
  return params;
}

function normalizeLog(item: any): FirewallLog {
  const parsed = (item?.parsed_fields && typeof item.parsed_fields === 'object')
    ? item.parsed_fields
    : {};
  const timestamp = item?.event_time || item?.received_at || new Date().toISOString();
  const raw = item?.raw_syslog || item?.raw || item?.message || '';
  return {
    id: String(item?.id || (timestamp + '-' + (item?.src_ip || '') + '-' + (item?.dst_ip || ''))),
    timestamp,
    vendor: item?.vendor || 'fortigate',
    hostname: item?.hostname || parsed.devname || parsed.hostname || null,
    log_type: (item?.log_type || 'event') as FirewallLog['log_type'],
    log_subtype: item?.log_subtype || parsed.subtype || null,
    severity: item?.severity || 'info',
    action: item?.action || '',
    src_ip: item?.src_ip || parsed.srcip || parsed.src_ip || parsed.remip || parsed.peerip || '',
    dst_ip: item?.dst_ip || parsed.dstip || parsed.dst_ip || parsed.tunnelip || parsed.assignip || '',
    src_port: item?.src_port ?? parsed.srcport ?? parsed.src_port ?? null,
    dst_port: item?.dst_port ?? parsed.dstport ?? parsed.dst_port ?? null,
    user: item?.user || parsed.user || parsed.username || null,
    message: item?.message || parsed.logdesc || parsed.msg || parsed.message || raw,
    raw,
    parsed,
    correlation_id: item?.correlation_id || item?.session_id || null,
    correlation_type: item?.correlation_type || null,
    correlation_reason: item?.correlation_reason || null,
    correlation_group_size: item?.correlation_group_size || null,
  };
}

export async function searchLogs(filters: SearchFilters): Promise<SearchResponse> {
  const params = buildSearchParams(filters);
  const result = await request(`/logs/search?${params.toString()}`);
  const page = filters.page || 1;
  const pageSize = filters.page_size || 50;
  const items = Array.isArray(result?.items) ? result.items.map(normalizeLog) : [];
  return {
    items,
    total: Number(result?.total || 0),
    page,
    page_size: pageSize,
    has_next: page * pageSize < Number(result?.total || 0),
  };
}

export async function getFacets(filters: SearchFilters): Promise<FacetResult> {
  const params = buildSearchParams(filters);
  return request(`/logs/facets?${params.toString()}`);
}

export async function correlateSession(sessionId: string): Promise<CorrelateResult> {
  return request(`/logs/correlate/${sessionId}`);
}

export async function exportLogs(filters: SearchFilters, format: string = 'csv'): Promise<{ blob: Blob; filename: string }> {
  const params = buildSearchParams(filters);
  params.set('format', format);
  const response = await requestBlob(`/logs/export?${params.toString()}`);
  const disposition = response.headers.get('content-disposition') || '';
  const match = disposition.match(/filename="([^"]+)"/i);
  const filename = match?.[1] || `logs-export.${format}`;
  return { blob: await response.blob(), filename };
}

export async function listSavedSearches(surface: string = 'firewall_logs') {
  const views = await request(`/search/views?surface=${surface}`);
  return Array.isArray(views)
    ? views.map((view: any) => ({
        ...view,
        name: view.name || view.title,
        query: view.query || view.filters || {},
      }))
    : [];
}

export async function createSavedSearch(name: string, query: SearchFilters, surface: string = 'firewall_logs') {
  return request('/search/views', {
    method: 'POST',
    body: JSON.stringify({ title: name, filters: query, surface }),
  });
}

export async function deleteSavedSearch(id: string) {
  return request(`/search/views/${id}`, {
    method: 'DELETE',
  });
}
