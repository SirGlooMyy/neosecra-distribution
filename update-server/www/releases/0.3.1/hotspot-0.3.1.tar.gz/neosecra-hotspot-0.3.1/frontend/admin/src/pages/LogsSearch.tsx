import React, { useState, useCallback, useRef, useEffect } from 'react';
import { LogsToolbar } from '../components/logs/LogsToolbar';
import { LogsFilterPanel } from '../components/logs/LogsFilterPanel';
import { LogsFacets } from '../components/logs/LogsFacets';
import { LogsTable } from '../components/logs/LogsTable';
import { LogHistogram } from '../components/logs/LogHistogram';
import { CorrelateModal } from '../components/logs/CorrelateModal';
import {
  searchLogs,
  getFacets,
  correlateSession,
  exportLogs,
  listSavedSearches,
  createSavedSearch,
  deleteSavedSearch,
} from '../api/logs';
import { getCurrentScope, getVpnSessions } from '../lib/api';
import type {
  SearchFilters,
  FirewallLog,
  FacetResult,
  CorrelateResult,
  TimeWindow,
  SearchView,
  LogType,
} from '../types/logs';
import {
  Bookmark,
  X,
  Save,
  ShieldAlert,
  Ban,
  Users,
  Activity,
  SlidersHorizontal,
  RotateCcw,
  Shield,
  Search,
  Sparkles,
  Lock,
  Globe,
  Radio,
  Zap,
  CheckCircle2,
  Copy,
  ChevronDown,
  Layers,
  ArrowRight,
  UserCheck,
  Terminal,
  ExternalLink,
} from 'lucide-react';

interface PlaybookPreset {
  id: string;
  title: string;
  desc: string;
  filters: Partial<SearchFilters>;
  badge: string;
}

interface PlaybookGroup {
  category: string;
  icon: any;
  items: PlaybookPreset[];
}

const PLAYBOOK_SECTIONS: PlaybookGroup[] = [
  {
    category: 'VPN & Uzak Erişim',
    icon: Shield,
    items: [
      {
        id: 'vpn-ssl-users',
        title: 'Aktif SSL-VPN Kullanıcıları',
        desc: 'hasan.cosan ve FortiClient ile yerel ağa bağlanan tüm kullanıcılar',
        filters: { log_type: ['vpn'] },
        badge: 'Kullanıcı Tünelleri',
      },
      {
        id: 'vpn-ipsec',
        title: 'IPsec Tünelleri & IKE (Port 500/4500)',
        desc: 'Site-to-Site ve Dial-up IPsec şifreli tünel bağlantıları',
        filters: { log_type: ['vpn'], q: '500' },
        badge: 'Port 500/4500',
      },
      {
        id: 'vpn-failed',
        title: 'Başarısız VPN Giriş Denemeleri',
        desc: 'Hatalı parola veya yetkisiz SSL-VPN bağlanma girişimleri',
        filters: { log_type: ['vpn'], action: ['deny', 'block', 'timeout'] },
        badge: 'Auth Hatası',
      },
      {
        id: 'vpn-drops',
        title: 'Kapanan & Kopan Tüneller',
        desc: 'Zaman aşımı veya kullanıcı çıkışıyla sonlanan VPN oturumları',
        filters: { log_type: ['vpn'], action: ['close', 'timeout', 'client-rst', 'server-rst'] },
        badge: 'Disconnect',
      },
    ],
  },
  {
    category: 'Tehditler & Engellemeler',
    icon: Ban,
    items: [
      {
        id: 'threat-wan-blocks',
        title: 'Dış Ağdan Gelen Engellemeler (WAN)',
        desc: 'Güvenlik duvarının WAN arayüzünde düşürdüğü dış saldırılar',
        filters: { action: ['deny', 'block', 'blocked'] },
        badge: 'Drop / Deny',
      },
      {
        id: 'threat-critical-alerts',
        title: 'Kritik & Acil Güvenlik Alarmları',
        desc: 'IPS, exploit ve yüksek öncelikli güvenlik duvarı alarmları',
        filters: { severity: ['emergency', 'alert', 'critical', 'error'] },
        badge: 'Critical / Error',
      },
      {
        id: 'threat-port-scans',
        title: 'Şüpheli Port Taramaları (RDP/SSH/SMB)',
        desc: 'Port 3389, 22 ve 445 gibi yönetim portlarına yönelik yoklamalar',
        filters: { q: '3389 22 445' },
        badge: 'Port Scan',
      },
    ],
  },
  {
    category: 'Web & UTM Uygulama',
    icon: Globe,
    items: [
      {
        id: 'utm-webfilter-all',
        title: 'Web Filtreleme & URL Ziyaretleri',
        desc: 'Kullanıcıların ziyaret ettiği tüm web siteleri ve kategoriler',
        filters: { log_type: ['webfilter', 'utm'] },
        badge: 'Web Filter',
      },
      {
        id: 'utm-blocked-sites',
        title: 'Engellenen Zararlı / Yasaklı Siteler',
        desc: 'Kategori veya güvenlik kuralıyla erişimi kesilen alan adları',
        filters: { log_type: ['webfilter'], action: ['deny', 'block', 'blocked'] },
        badge: 'Blocked URL',
      },
      {
        id: 'utm-app-ctrl',
        title: 'Uygulama Kontrolü (App-Ctrl)',
        desc: 'Sosyal medya, video akışı, torrent ve kurumsal uygulamalar',
        filters: { log_type: ['app-ctrl', 'utm'] },
        badge: 'Application',
      },
      {
        id: 'utm-dns-queries',
        title: 'DNS Sorguları & Çözümlemeleri (53)',
        desc: 'İç ağdaki istemcilerin DNS sorgu logları',
        filters: { q: '53' },
        badge: 'Port 53',
      },
    ],
  },
  {
    category: 'Yönetici & Sistem',
    icon: Lock,
    items: [
      {
        id: 'admin-logins',
        title: 'FortiGate Yönetici Girişleri',
        desc: 'Admin hesabı oturum açma ve sistem yönetim aktiviteleri',
        filters: { log_type: ['event'], q: 'admin' },
        badge: 'Admin Session',
      },
      {
        id: 'admin-failed-logins',
        title: 'Başarısız Yönetici Girişleri',
        desc: 'Yönetim paneline yönelik hatalı şifre denemeleri',
        filters: { log_type: ['event'], severity: ['warning', 'error', 'alert'], q: 'failed' },
        badge: 'Brute Force Alarm',
      },
    ],
  },
  {
    category: 'Hotspot & Bağlantı',
    icon: Zap,
    items: [
      {
        id: 'hotspot-rst-disconnects',
        title: 'Bağlantı Kopmaları & RST Paketleri',
        desc: 'İstemci veya sunucu tarafından sıfırlanan (RST) bağlantılar',
        filters: { action: ['client-rst', 'server-rst', 'timeout'] },
        badge: 'Reset / Drop',
      },
      {
        id: 'hotspot-timeouts',
        title: 'Zaman Aşımı & Yavaşlık Olayları',
        desc: 'Cevap veremeyen sunucular ve zaman aşımına uğrayan paketler',
        filters: { action: ['timeout'] },
        badge: 'Latency / Timeout',
      },
    ],
  },
];

const DEFAULT_FILTERS: SearchFilters = {
  time_window: '24h',
  page: 1,
  page_size: 50,
};

export const LogsSearch: React.FC = () => {
  const [filters, setFilters] = useState<SearchFilters>(DEFAULT_FILTERS);
  // Preserve quick searches launched from the dashboard (e.g. /logs/search?q=1.2.3.4).
  // Reading the value lazily avoids touching window during the initial render in
  // non-browser tooling while still pre-populating the toolbar before the first
  // automatic search runs.
  const [q, setQ] = useState(
    () => (typeof window === 'undefined' ? '' : new URLSearchParams(window.location.search).get('q') || ''),
  );
  const [timeWindow, setTimeWindow] = useState<TimeWindow>('24h');
  const [fromDate, setFromDate] = useState<string>('');
  const [toDate, setToDate] = useState<string>('');
  const [activeQuickTab, setActiveQuickTab] = useState<string>('all');
  const [playbookCategory, setPlaybookCategory] = useState<string>('VPN & Uzak Erişim');
  const [playbookExpanded, setPlaybookExpanded] = useState<boolean>(true);
  const [copyFeedback, setCopyFeedback] = useState<boolean>(false);

  const [logs, setLogs] = useState<FirewallLog[]>([]);
  const [total, setTotal] = useState(0);
  const [hasNext, setHasNext] = useState(false);
  const [loading, setLoading] = useState(false);
  const [facetLoading, setFacetLoading] = useState(false);
  const [facets, setFacets] = useState<FacetResult | null>(null);
  const [selectedLog, setSelectedLog] = useState<FirewallLog | null>(null);

  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [tenantName, setTenantName] = useState<string | null>(null);
  const [correlateOpen, setCorrelateOpen] = useState(false);
  const [correlateSessionId, setCorrelateSessionId] = useState<string | null>(null);
  const [correlateResult, setCorrelateResult] = useState<CorrelateResult | null>(null);
  const [correlateLoading, setCorrelateLoading] = useState(false);

  // Saved Searches
  const [savedSearches, setSavedSearches] = useState<SearchView[]>([]);
  const [saveModalOpen, setSaveModalOpen] = useState(false);
  const [newSearchName, setNewSearchName] = useState('');
  const [savingSearch, setSavingSearch] = useState(false);

  // FortiGate Live VPN Sessions State
  const [vpnData, setVpnData] = useState<{
    active_users: any[];
    history: any[];
    stats: { online_count: number; offline_count: number; total_bandwidth_mb: number };
  }>({
    active_users: [],
    history: [],
    stats: { online_count: 0, offline_count: 0, total_bandwidth_mb: 0 },
  });
  const [vpnSubTab, setVpnSubTab] = useState<'active' | 'history'>('active');
  const [showVpnRawPackets, setShowVpnRawPackets] = useState<string | null>(null);

  const loadVpnData = useCallback(async () => {
    try {
      const res = await getVpnSessions();
      if (res && res.active_users) {
        setVpnData(res);
      }
    } catch {
      // silent
    }
  }, []);

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchSavedSearches = useCallback(async () => {
    try {
      const res = await listSavedSearches('firewall_logs');
      if (Array.isArray(res)) {
        setSavedSearches(res);
      }
    } catch {
      // silent
    }
  }, []);

  useEffect(() => {
    getCurrentScope().then((scope) => {
      if (scope?.tenant_id) setTenantName(scope.tenant_id);
    });
    fetchSavedSearches();
    loadVpnData();
  }, [fetchSavedSearches, loadVpnData]);

  const buildFilters = useCallback(
    (page = 1): SearchFilters => ({
      ...filters,
      q: q || undefined,
      time_window: timeWindow,
      from: timeWindow === 'custom' && fromDate ? fromDate : undefined,
      to: timeWindow === 'custom' && toDate ? toDate : undefined,
      page,
      page_size: 50,
    }),
    [filters, q, timeWindow, fromDate, toDate],
  );

  const doSearch = useCallback(
    async (page = 1, override?: Partial<SearchFilters>) => {
      setLoading(true);
      setError(null);
      try {
        const f = { ...buildFilters(page), ...override, page };
        const result = await searchLogs(f);
        if (page === 1) {
          setLogs(result.items);
        } else {
          setLogs((prev) => [...prev, ...result.items]);
        }
        setTotal(result.total);
        setHasNext(result.has_next);
        setFilters((prev) => ({ ...prev, page }));
      } catch (err: any) {
        setError(err.message || 'Arama başarısız');
      } finally {
        setLoading(false);
      }
    },
    [buildFilters],
  );

  const doFacets = useCallback(async (override?: Partial<SearchFilters>) => {
    setFacetLoading(true);
    try {
      const result = await getFacets({ ...buildFilters(1), ...override, page: 1 });
      setFacets(result);
    } catch {
      // silent
    } finally {
      setFacetLoading(false);
    }
  }, [buildFilters]);

  const handleSearch = useCallback((override?: Partial<SearchFilters>) => {
    setLogs([]);
    doSearch(1, override);
    doFacets(override);
  }, [doSearch, doFacets]);

  // Auto-load last 24h on mount
  useEffect(() => {
    handleSearch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleFilterApply = useCallback(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      handleSearch();
    }, 300);
  }, [handleSearch]);

  const handleFilterClear = useCallback(() => {
    setFilters(DEFAULT_FILTERS);
    setQ('');
    setTimeWindow('24h');
    setFromDate('');
    setToDate('');
    setError(null);
    setSelectedLog(null);
    handleSearch(DEFAULT_FILTERS);
  }, [handleSearch]);

  const applyQuickFilter = useCallback((kind: string) => {
    setActiveQuickTab(kind);
    const next: SearchFilters = { ...DEFAULT_FILTERS };
    let nextQ = '';
    let nextTimeWindow: TimeWindow = '24h';
    if (kind === 'critical') next.severity = ['critical', 'alert', 'emergency', 'error'];
    if (kind === 'blocked') next.action = ['deny', 'block', 'blocked', 'timeout'];
    if (kind === 'vpn') {
      next.log_type = ['vpn'];
      loadVpnData();
    }
    if (kind === 'utm') next.log_type = ['utm', 'webfilter', 'app-ctrl'];
    if (kind === 'admin') { next.log_type = ['event']; nextQ = 'admin'; }
    if (kind === 'last15') nextTimeWindow = '15m';

    setQ(nextQ);
    setTimeWindow(nextTimeWindow);
    setFilters(next);
    handleSearch({ ...next, q: nextQ || undefined, time_window: nextTimeWindow });
  }, [handleSearch, loadVpnData]);

  const handleUserClick = useCallback((username: string) => {
    const next: SearchFilters = { ...filters, user: filters.user === username ? undefined : username };
    setFilters(next);
    handleSearch(next);
  }, [filters, handleSearch]);

  const handleIpClick = useCallback((ip: string) => {
    const next: SearchFilters = { ...filters, src_ip: filters.src_ip === ip ? undefined : ip };
    setFilters(next);
    handleSearch(next);
  }, [filters, handleSearch]);

  const applyPlaybook = useCallback((preset: PlaybookPreset) => {
    const next: SearchFilters = { ...DEFAULT_FILTERS, ...preset.filters };
    setFilters(next);
    if (preset.filters.q) setQ(preset.filters.q);
    else setQ('');
    if (preset.id === 'vpn-ssl-users' || preset.filters.log_type?.includes('vpn')) {
      setActiveQuickTab('vpn');
      loadVpnData();
    }
    handleSearch(next);
  }, [handleSearch, loadVpnData]);

  const handleCopyRaw = useCallback((text: string) => {
    if (!navigator.clipboard) return;
    navigator.clipboard.writeText(text);
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2000);
  }, []);

  const vpnCount = (facets?.log_type || []).find((lt) => lt.value.toLowerCase() === 'vpn')?.count || 0;

  const criticalCount =
    (facets?.severity || [])
      .filter((s) => ['critical', 'alert', 'emergency', 'error'].includes(s.value.toLowerCase()))
      .reduce((acc, x) => acc + x.count, 0) ||
    logs.filter((l) => ['critical', 'alert', 'emergency', 'error'].includes(l.severity?.toLowerCase() || '')).length;

  const blockedCount =
    (facets?.action || [])
      .filter((a) => ['deny', 'block', 'blocked', 'timeout'].includes(a.value.toLowerCase()))
      .reduce((acc, x) => acc + x.count, 0) ||
    logs.filter((l) => ['deny', 'block', 'blocked', 'timeout'].includes(l.action?.toLowerCase() || '')).length;

  const activeUsers = (facets?.user || []).filter((u) => u.value && u.value !== 'undefined' && u.value !== 'null');

  const handleFacetClick = useCallback(
    (facetKey: keyof FacetResult, value: string) => {
      const next = { ...filters };
        if (facetKey === 'vendor') {
          next.vendor = value;
        } else if (facetKey === 'severity') {
          const current = next.severity || [];
          next.severity = current.includes(value) ? current.filter((x) => x !== value) : [...current, value];
        } else if (facetKey === 'log_type') {
          const current = next.log_type || [];
          const ltValue = value as LogType;
          next.log_type = current.includes(ltValue) ? current.filter((x) => x !== ltValue) : [...current, ltValue];
        } else if (facetKey === 'action') {
          const current = next.action || [];
          next.action = current.includes(value) ? current.filter((x) => x !== value) : [...current, value];
        } else if (facetKey === 'src_ip') {
          next.src_ip = next.src_ip === value ? undefined : value;
        } else if (facetKey === 'dst_ip') {
          next.dst_ip = next.dst_ip === value ? undefined : value;
        } else if (facetKey === 'user') {
          next.user = next.user === value ? undefined : value;
        }
      setFilters(next);
      handleSearch(next);
    },
    [filters, handleSearch],
  );

  const handleBucketClick = useCallback(
    (bucketFrom: string, bucketTo: string) => {
      setTimeWindow('custom');
      setFromDate(bucketFrom);
      setToDate(bucketTo);
      setTimeout(() => handleSearch(), 50);
    },
    [handleSearch],
  );

  const handleLoadMore = useCallback(() => {
    const nextPage = (filters.page || 1) + 1;
    doSearch(nextPage);
  }, [filters.page, doSearch]);

  const handleExport = useCallback(async () => {
    setExporting(true);
    try {
      const { blob, filename } = await exportLogs(buildFilters(1), 'csv');
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
    } catch (err: any) {
      setError(err.message || 'Dışa aktarma başarısız');
    } finally {
      setExporting(false);
    }
  }, [buildFilters]);

  const handleCorrelate = useCallback(async (sessionId: string) => {
    setCorrelateSessionId(sessionId);
    setCorrelateOpen(true);
    setCorrelateLoading(true);
    setCorrelateResult(null);
    try {
      const result = await correlateSession(sessionId);
      setCorrelateResult(result);
    } catch {
      setCorrelateResult(null);
    } finally {
      setCorrelateLoading(false);
    }
  }, []);

  const handleSaveSearchSubmit = useCallback(async () => {
    if (!newSearchName.trim()) return;
    setSavingSearch(true);
    try {
      const activeFilters = buildFilters(1);
      await createSavedSearch(newSearchName.trim(), activeFilters, 'firewall_logs');
      setNewSearchName('');
      setSaveModalOpen(false);
      await fetchSavedSearches();
    } catch (err: any) {
      setError(err.message || 'Arama kaydetme başarısız');
    } finally {
      setSavingSearch(false);
    }
  }, [newSearchName, buildFilters, fetchSavedSearches]);

  const handleSelectSavedSearch = useCallback(
    (sv: SearchView) => {
      const qObj = (sv.query || {}) as SearchFilters;
      setFilters(qObj);
      if (qObj.q) setQ(qObj.q);
      if (qObj.time_window) setTimeWindow(qObj.time_window);
      if (qObj.from) setFromDate(qObj.from);
      if (qObj.to) setToDate(qObj.to);
      setTimeout(() => handleSearch(), 50);
    },
    [handleSearch],
  );

  return (
    <div className="space-y-5 pb-8">
      {error && (
        <div
          role="alert"
          className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-200"
        >
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => handleSearch()}
            disabled={loading}
            className="rounded-xl border border-rose-300 bg-white px-3 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-100 disabled:opacity-60 dark:border-rose-800 dark:bg-rose-950/40 dark:text-rose-200"
          >
            Tekrar Dene
          </button>
        </div>
      )}
      {/* 🌟 Modern Enterprise Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 p-6 text-white shadow-2xl border border-white/10">
        <div className="absolute -right-16 -top-24 h-72 w-72 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="absolute -left-16 -bottom-24 h-72 w-72 rounded-full bg-blue-500/10 blur-3xl" />

        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-indigo-400">
              <Activity className="h-4 w-4 text-indigo-400" /> FortiGate Güvenlik & VPN Analiz Merkezi
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Firewall Analyzer</h1>
            <p className="mt-1.5 max-w-2xl text-xs sm:text-sm text-slate-300">
              FortiGate canlı log akışı, VPN kullanıcı oturumları, engellenen tehditler ve güvenlik politikalarını tek merkezden izleyin.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-4 py-2 text-xs font-semibold text-emerald-300 backdrop-blur-md">
              <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-emerald-400" />
              Canlı Veri Akışı Aktif
            </div>
            <button
              onClick={() => handleSearch()}
              className="inline-flex items-center gap-2 rounded-2xl border border-white/20 bg-white/10 px-4 py-2 text-xs font-bold text-white hover:bg-white/20 transition backdrop-blur-md"
            >
              <RotateCcw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              Yenile
            </button>
          </div>
        </div>

        {/* 🎯 Quick Preset Category Pills */}
        <div className="relative mt-6 flex flex-wrap items-center gap-2 pt-2 border-t border-white/10">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 mr-1">Hızlı Filtre:</span>
          {[
            { id: 'all', label: 'Tüm Olaylar' },
            { id: 'vpn', label: `🛡️ VPN & Kullanıcılar ${vpnCount > 0 ? `(${vpnCount.toLocaleString('tr-TR')})` : ''}` },
            { id: 'blocked', label: `🚫 Engellenenler ${blockedCount > 0 ? `(${blockedCount.toLocaleString('tr-TR')})` : ''}` },
            { id: 'critical', label: `⚠️ Kritik & Hatalar ${criticalCount > 0 ? `(${criticalCount.toLocaleString('tr-TR')})` : ''}` },
            { id: 'utm', label: '🌐 Web & UTM' },
            { id: 'last15', label: '⚡ Son 15 Dakika' },
            { id: 'admin', label: '👑 Yönetici Girişleri' },
          ].map((tab) => {
            const isSelected = activeQuickTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => applyQuickFilter(tab.id)}
                className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all duration-200 ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30 scale-105 ring-2 ring-indigo-400/50'
                    : 'bg-white/10 text-slate-200 hover:bg-white/20 hover:text-white border border-white/10'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      <LogsToolbar
        q={q}
        timeWindow={timeWindow}
        from={fromDate}
        to={toDate}
        loading={loading}
        exporting={exporting}
        tenantName={tenantName}
        savedSearches={savedSearches}
        onQChange={setQ}
        onTimeWindowChange={setTimeWindow}
        onFromChange={setFromDate}
        onToChange={setToDate}
        onSearch={() => handleSearch()}
        onExport={handleExport}
        onRefresh={() => handleSearch()}
        onSaveSearchClick={() => setSaveModalOpen(true)}
        onSelectSavedSearch={handleSelectSavedSearch}
      />

      {/* 📊 4 Rich Metric KPI Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div
          onClick={() => applyQuickFilter('all')}
          className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 cursor-pointer hover:border-indigo-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Toplam Olay</span>
            <div className="rounded-2xl bg-indigo-50 p-2.5 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400">
              <Activity className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100">
            {total.toLocaleString('tr-TR')}
          </div>
          <div className="mt-1 text-xs text-slate-500 font-medium">24 saatlik toplam güvenlik olayları</div>
        </div>

        <div
          onClick={() => applyQuickFilter('vpn')}
          className="relative overflow-hidden rounded-3xl border border-indigo-200 bg-gradient-to-br from-indigo-50/50 to-white p-5 shadow-sm dark:border-indigo-900/40 dark:from-indigo-950/20 dark:to-slate-900 cursor-pointer hover:border-indigo-400 transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider dark:text-indigo-400">
              VPN & Kullanıcı Oturumu
            </span>
            <div className="rounded-2xl bg-indigo-600 p-2.5 text-white shadow-md shadow-indigo-600/20 group-hover:scale-110 transition">
              <ShieldAlert className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 text-2xl sm:text-3xl font-extrabold text-indigo-900 dark:text-indigo-200">
            {vpnCount.toLocaleString('tr-TR')}
          </div>
          <div className="mt-1 text-xs text-indigo-600/80 dark:text-indigo-400 font-medium flex items-center gap-1">
            <span>SSL-VPN / IPsec Bağlantıları</span>
            <ArrowRight className="h-3 w-3 inline group-hover:translate-x-1 transition" />
          </div>
        </div>

        <div
          onClick={() => applyQuickFilter('blocked')}
          className="relative overflow-hidden rounded-3xl border border-amber-200 bg-gradient-to-br from-amber-50/40 to-white p-5 shadow-sm dark:border-amber-900/40 dark:from-amber-950/20 dark:to-slate-900 cursor-pointer hover:border-amber-400 transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wider dark:text-amber-400">
              Engellenen Tehditler
            </span>
            <div className="rounded-2xl bg-amber-500 p-2.5 text-white shadow-md shadow-amber-500/20 group-hover:scale-110 transition">
              <Ban className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 text-2xl sm:text-3xl font-extrabold text-amber-900 dark:text-amber-200">
            {blockedCount.toLocaleString('tr-TR')}
          </div>
          <div className="mt-1 text-xs text-amber-700/80 dark:text-amber-400 font-medium flex items-center gap-1">
            <span>Deny & Block Kuralları</span>
            <ArrowRight className="h-3 w-3 inline group-hover:translate-x-1 transition" />
          </div>
        </div>

        <div
          onClick={() => applyQuickFilter('critical')}
          className="relative overflow-hidden rounded-3xl border border-rose-200 bg-gradient-to-br from-rose-50/40 to-white p-5 shadow-sm dark:border-rose-900/40 dark:from-rose-950/20 dark:to-slate-900 cursor-pointer hover:border-rose-400 transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-600 uppercase tracking-wider dark:text-rose-400">
              Kritik & Hatalar
            </span>
            <div className="rounded-2xl bg-rose-600 p-2.5 text-white shadow-md shadow-rose-600/20 group-hover:scale-110 transition">
              <ShieldAlert className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 text-2xl sm:text-3xl font-extrabold text-rose-900 dark:text-rose-200">
            {criticalCount.toLocaleString('tr-TR')}
          </div>
          <div className="mt-1 text-xs text-rose-600/80 dark:text-rose-400 font-medium flex items-center gap-1">
            <span>Güvenlik Uyarıları</span>
            <ArrowRight className="h-3 w-3 inline group-hover:translate-x-1 transition" />
          </div>
        </div>
      </div>

      {/* 👤 Active Detected Users Ribbon */}
      {activeUsers.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50/80 px-4 py-3 dark:border-slate-800 dark:bg-slate-900/80">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 mr-2 flex items-center gap-1.5">
            <Users className="h-4 w-4 text-indigo-500" />
            Aktif Kullanıcılar:
          </span>
          {activeUsers.map((u) => {
            const isUserFiltered = filters.user === u.value;
            return (
              <button
                key={u.value}
                onClick={() => handleUserClick(u.value)}
                className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold transition ${
                  isUserFiltered
                    ? 'bg-indigo-600 text-white ring-2 ring-indigo-400 shadow-md'
                    : 'bg-white border border-slate-200 text-slate-700 hover:border-indigo-300 hover:bg-indigo-50/50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-200'
                }`}
              >
                <span>👤 {u.value}</span>
                <span className="rounded-full bg-slate-100 px-1.5 py-0.2 text-[10px] font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-300">
                  {u.count.toLocaleString('tr-TR')}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* ⚡ Hazır Arama & Analiz Kütüphanesi (SOC Playbooks & Templates) */}
      <div className="rounded-3xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
          <div className="flex items-center gap-2.5">
            <div className="rounded-xl bg-indigo-600 p-2 text-white shadow-md shadow-indigo-600/20">
              <Sparkles className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                Hazır Analiz & Teşhis Kütüphanesi
                <span className="text-[10px] uppercase font-extrabold bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 px-2 py-0.5 rounded-full">
                  Tek Tıkla Sorgula
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                En sık kullanılan FortiGate VPN, güvenlik duvarı, UTM ve yönetici arama şablonları
              </p>
            </div>
          </div>
          <button
            onClick={() => setPlaybookExpanded((prev) => !prev)}
            className="flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 p-1.5 rounded-xl hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition"
          >
            <span>{playbookExpanded ? 'Gizle' : 'Göster'}</span>
            <ChevronDown className={`w-4 h-4 transition-transform ${playbookExpanded ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {playbookExpanded && (
          <div className="p-5 space-y-4">
            {/* Category Switcher Pills */}
            <div className="flex flex-wrap gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              {PLAYBOOK_SECTIONS.map((section) => {
                const isSelected = playbookCategory === section.category;
                const IconComponent = section.icon;
                return (
                  <button
                    key={section.category}
                    onClick={() => setPlaybookCategory(section.category)}
                    className={`inline-flex items-center gap-2 rounded-2xl px-4 py-2 text-xs font-bold transition ${
                      isSelected
                        ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-md'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    <IconComponent className="w-3.5 h-3.5" />
                    <span>{section.category}</span>
                  </button>
                );
              })}
            </div>

            {/* Playbook Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {(PLAYBOOK_SECTIONS.find((s) => s.category === playbookCategory)?.items || []).map((preset) => (
                <div
                  key={preset.id}
                  onClick={() => applyPlaybook(preset)}
                  className="group relative rounded-2xl border border-slate-200 bg-slate-50/50 p-4 hover:border-indigo-400 hover:bg-white hover:shadow-md transition cursor-pointer dark:border-slate-800 dark:bg-slate-950/40 dark:hover:border-indigo-500 dark:hover:bg-slate-900 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 px-2 py-0.5 rounded-full border border-indigo-100 dark:border-indigo-900/40">
                        {preset.badge}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition" />
                    </div>
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 transition">
                      {preset.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-snug">
                      {preset.desc}
                    </p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-800 flex items-center text-[10px] font-bold text-indigo-600 dark:text-indigo-400">
                    <span>⚡ Tek Tıkla Sorgula</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {(q || filters.vendor || filters.log_type?.length || filters.severity?.length || filters.action?.length || filters.src_ip || filters.dst_ip || filters.user || timeWindow !== '24h') && (
        <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-indigo-100 bg-indigo-50/70 px-4 py-2.5 dark:border-indigo-900/40 dark:bg-indigo-950/20">
          <span className="mr-1 text-[11px] font-bold uppercase tracking-wider text-indigo-500">Aktif filtreler:</span>
          {q && <button onClick={() => setQ('')} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Arama: {q} ×</button>}
          {timeWindow !== '24h' && <button onClick={() => setTimeWindow('24h')} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">{timeWindow} ×</button>}
          {filters.vendor && <button onClick={() => setFilters((f) => ({ ...f, vendor: undefined }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Vendor: {filters.vendor} ×</button>}
          {filters.severity?.map((v) => <button key={v} onClick={() => setFilters((f) => ({ ...f, severity: f.severity?.filter((x) => x !== v) }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Severity: {v} ×</button>)}
          {filters.action?.map((v) => <button key={v} onClick={() => setFilters((f) => ({ ...f, action: f.action?.filter((x) => x !== v) }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Action: {v} ×</button>)}
          {filters.src_ip && <button onClick={() => setFilters((f) => ({ ...f, src_ip: undefined }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Kaynak: {filters.src_ip} ×</button>}
          {filters.dst_ip && <button onClick={() => setFilters((f) => ({ ...f, dst_ip: undefined }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Hedef: {filters.dst_ip} ×</button>}
          {filters.user && <button onClick={() => setFilters((f) => ({ ...f, user: undefined }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Kullanıcı: {filters.user} ×</button>}
          <button onClick={handleFilterClear} className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700"><RotateCcw className="h-3 w-3" /> Tümünü Temizle</button>
        </div>
      )}

      {/* Time Activity Histogram */}
      {logs.length > 0 && <LogHistogram logs={logs} histogram={facets?.histogram} onBucketClick={handleBucketClick} />}

      <div className="grid grid-cols-1 gap-5 2xl:grid-cols-[230px_minmax(0,1fr)_260px]">
        <aside className="w-full 2xl:order-1">
          <div className="sticky top-6 space-y-4 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-2"><SlidersHorizontal className="h-4 w-4 text-indigo-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Filtreler</h3>
            </div>
            <LogsFilterPanel
              filters={filters}
              onChange={setFilters}
              onApply={handleFilterApply}
              onClear={handleFilterClear}
            />
          </div>
        </aside>

        <div className="min-w-0 2xl:order-2 space-y-4">
          {activeQuickTab === 'vpn' ? (
            <div className="space-y-4">
              {/* FortiGate Style SSL-VPN Live Users Panel */}
              <div className="rounded-3xl border border-indigo-200 bg-white p-6 shadow-sm dark:border-indigo-900/40 dark:bg-slate-900">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 dark:border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 rounded-2xl">
                      <Lock className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                        FortiGate SSL-VPN & IPsec Canlı Tüneller (Users Ekranı)
                        <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-bold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                          {vpnData.stats.online_count} Canlı Tünel (Online 🟢)
                        </span>
                      </h3>
                      <p className="text-xs text-slate-500">
                        FortiGate Users Mantığı: Sadece son durumu tunnel-up olan ve canlı veri akışı süren kullanıcılar 1'er satır listelenir.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl">
                    <button
                      type="button"
                      onClick={() => setVpnSubTab('active')}
                      className={`px-3 py-1.5 text-xs font-bold rounded-xl transition ${
                        vpnSubTab === 'active'
                          ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      🟢 Canlı Bağlantılar ({vpnData.active_users.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setVpnSubTab('history')}
                      className={`px-3 py-1.5 text-xs font-bold rounded-xl transition ${
                        vpnSubTab === 'history'
                          ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      ⚪ Kapanan Tüneller ({vpnData.history.length})
                    </button>
                  </div>
                </div>

                {/* Table */}
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 dark:bg-slate-950 text-xs font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100 dark:border-slate-800">
                      <tr>
                        <th className="py-3 px-4">Kullanıcı (User)</th>
                        <th className="py-3 px-4">Durum</th>
                        <th className="py-3 px-4">Tünel Sanal IP</th>
                        <th className="py-3 px-4">İlke / Policy</th>
                        <th className="py-3 px-4">Cihaz Gateway</th>
                        <th className="py-3 px-4">Tunnel Up (Giriş)</th>
                        <th className="py-3 px-4">Son Sinyal</th>
                        <th className="py-3 px-4">Aktif Süre</th>
                        <th className="py-3 px-4">Trafik (Veri)</th>
                        <th className="py-3 px-4 text-right">İşlem</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-sans text-xs">
                      {(vpnSubTab === 'active' ? vpnData.active_users : vpnData.history).length === 0 ? (
                        <tr>
                          <td colSpan={10} className="py-8 text-center text-slate-500">
                            {vpnSubTab === 'active' ? 'Şu an bağlı aktif VPN tüneli bulunmuyor.' : 'Geçmiş tünel kaydı bulunmuyor.'}
                          </td>
                        </tr>
                      ) : (
                        (vpnSubTab === 'active' ? vpnData.active_users : vpnData.history).map((u, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/75 dark:hover:bg-slate-800/40 transition">
                            <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white flex items-center gap-2 font-sans">
                              <span className={`w-2.5 h-2.5 rounded-full ${u.status === 'online' ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
                              <span>{u.user}</span>
                            </td>
                            <td className="py-3.5 px-4">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold border ${
                                u.status === 'online'
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800/40'
                                  : 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400'
                              }`}>
                                {u.status === 'online' ? '🟢 Online (Up)' : '⚪ Kapandı (Down)'}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                              {u.virtual_ip}
                            </td>
                            <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 font-sans">
                              {u.policy}
                            </td>
                            <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400 font-sans">
                              {u.device}
                            </td>
                            <td className="py-3.5 px-4 text-slate-500 font-sans">
                              {new Date(u.connected_at).toLocaleString('tr-TR')}
                            </td>
                            <td className="py-3.5 px-4 font-semibold text-emerald-600 dark:text-emerald-400 font-sans">
                              {new Date(u.last_activity).toLocaleTimeString('tr-TR')}
                            </td>
                            <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 font-sans">
                              {u.duration_formatted}
                            </td>
                            <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 font-mono">
                              <span className="text-blue-600">↓ {u.bytes_in_formatted}</span> / <span className="text-amber-600">↑ {u.bytes_out_formatted}</span>
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => {
                                  if (showVpnRawPackets === u.user) {
                                    setShowVpnRawPackets(null);
                                  } else {
                                    setShowVpnRawPackets(u.user);
                                    handleUserClick(u.user);
                                  }
                                }}
                                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:border-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 text-xs font-bold transition"
                              >
                                <span>{showVpnRawPackets === u.user ? 'Paketleri Gizle' : `🔎 Paket Logları (${u.total_events})`}</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Raw Packet List rendered only if user clicked to inspect */}
              {showVpnRawPackets && (
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between px-2">
                    <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                      📊 {showVpnRawPackets} Kullanıcısına Ait Paket Akış Logları
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowVpnRawPackets(null)}
                      className="text-xs text-rose-500 hover:underline font-semibold"
                    >
                      Kapat ×
                    </button>
                  </div>
                  <LogsTable
                    logs={logs}
                    loading={loading}
                    hasNext={hasNext}
                    total={total}
                    onLoadMore={handleLoadMore}
                    onCorrelate={handleCorrelate}
                    onSelectLog={setSelectedLog}
                    onFilterUser={handleUserClick}
                    onFilterIp={handleIpClick}
                  />
                </div>
              )}
            </div>
          ) : (
            <LogsTable
              logs={logs}
              loading={loading}
              hasNext={hasNext}
              total={total}
              onLoadMore={handleLoadMore}
              onCorrelate={handleCorrelate}
              onSelectLog={setSelectedLog}
              onFilterUser={handleUserClick}
              onFilterIp={handleIpClick}
            />
          )}
        </div>

        <aside className="w-full 2xl:order-3">
          <div className="sticky top-6 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1 flex items-center gap-1.5">
              <Layers className="h-4 w-4 text-indigo-500" />
              Dinamik Facetler
            </h3>
            <p className="text-[11px] text-slate-400 mb-3">Filtreye eklemek için tıklayın</p>
            <LogsFacets facets={facets} loading={facetLoading} onFacetClick={handleFacetClick} />
          </div>
        </aside>
      </div>

      {/* 🔍 Slide-over Rich Detail Inspection Drawer with One-Click Actions */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/40 backdrop-blur-[2px]" onClick={() => setSelectedLog(null)}>
          <section className="h-full w-full max-w-2xl overflow-y-auto border-l border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-950" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-200 bg-white/95 px-6 py-5 backdrop-blur dark:border-slate-800 dark:bg-slate-950/95">
              <div>
                <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-indigo-500">Güvenlik Olayı Detayı</div>
                <h3 className="mt-1 text-xl font-extrabold text-slate-900 dark:text-slate-100">{selectedLog.log_type.toUpperCase()} · {selectedLog.action || 'Olay'}</h3>
              </div>
              <button onClick={() => setSelectedLog(null)} className="rounded-2xl p-2.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 transition"><X className="h-5 w-5" /></button>
            </div>

            <div className="space-y-6 p-6">
              {/* ⚡ Tek Tık Aksiyon Butonları */}
              <div className="flex flex-wrap gap-2 p-3 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                {selectedLog.user && (
                  <button
                    onClick={() => {
                      handleUserClick(selectedLog.user!);
                      setSelectedLog(null);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-indigo-600 text-white shadow-sm hover:bg-indigo-700 transition"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>Bu Kullanıcıyı İzle ({selectedLog.user})</span>
                  </button>
                )}
                {selectedLog.src_ip && (
                  <button
                    onClick={() => {
                      handleIpClick(selectedLog.src_ip!);
                      setSelectedLog(null);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-300 transition"
                  >
                    <Globe className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Kaynak IP İzle ({selectedLog.src_ip})</span>
                  </button>
                )}
                <button
                  onClick={() => {
                    handleCorrelate(selectedLog.correlation_id || selectedLog.id);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 transition"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Oturum Korelasyonu</span>
                </button>
                {selectedLog.raw && (
                  <button
                    onClick={() => handleCopyRaw(selectedLog.raw!)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition ml-auto"
                  >
                    {copyFeedback ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copyFeedback ? 'Kopyalandı!' : 'Ham Logu Kopyala'}</span>
                  </button>
                )}
              </div>

              {/* Temel Bilgiler */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  ['Zaman', new Date(selectedLog.timestamp).toLocaleString('tr-TR')],
                  ['Cihaz / Vendor', selectedLog.vendor || 'FortiGate'],
                  ['Severity', selectedLog.severity],
                  ['Kullanıcı (User)', selectedLog.user || '—'],
                  ['Hostname', selectedLog.hostname || '—'],
                  ['Korelasyon ID', selectedLog.correlation_id || '—'],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-slate-800 dark:bg-slate-900">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{label}</div>
                    <div className="mt-1 break-all text-sm font-semibold text-slate-900 dark:text-slate-100">{value}</div>
                  </div>
                ))}
              </div>

              {/* Akış Yönü */}
              <div className="rounded-2xl border border-indigo-200 bg-indigo-50/70 p-4 dark:border-indigo-900/40 dark:bg-indigo-950/20">
                <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">Trafik Akış Yönü</div>
                <div className="mt-2 font-mono text-sm flex items-center gap-2">
                  <span className="font-bold text-indigo-600 dark:text-indigo-300">{selectedLog.src_ip || '—'}{selectedLog.src_port ? `:${selectedLog.src_port}` : ''}</span>
                  <span className="text-slate-400 font-bold">→</span>
                  <span className="font-bold text-amber-600 dark:text-amber-300">{selectedLog.dst_ip || '—'}{selectedLog.dst_port ? `:${selectedLog.dst_port}` : ''}</span>
                </div>
              </div>

              {/* Mesaj / Politika */}
              <div>
                <div className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400">Politika / Mesaj</div>
                <p className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm leading-relaxed text-slate-800 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200">{selectedLog.message || '—'}</p>
              </div>

              {/* Ham Syslog */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400">
                  <span>Ham Syslog Kaydı</span>
                  {selectedLog.raw && (
                    <button onClick={() => handleCopyRaw(selectedLog.raw!)} className="text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 font-semibold text-[11px]">
                      <Copy className="w-3 h-3" /> Kopyala
                    </button>
                  )}
                </div>
                <pre className="max-h-56 overflow-auto whitespace-pre-wrap break-all rounded-2xl bg-slate-950 p-4 text-xs font-mono leading-5 text-emerald-400 border border-slate-800">{selectedLog.raw || 'Ham kayıt yok'}</pre>
              </div>

              {/* Ayrıştırılmış JSON Alanları */}
              {selectedLog.parsed && Object.keys(selectedLog.parsed).length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400">Ayrıştırılmış JSON Alanları</div>
                  <pre className="max-h-72 overflow-auto rounded-2xl bg-slate-100 p-4 text-xs font-mono leading-5 text-slate-800 dark:bg-slate-900 dark:text-slate-200 border border-slate-200 dark:border-slate-800">{JSON.stringify(selectedLog.parsed, null, 2)}</pre>
                </div>
              )}
            </div>
          </section>
        </div>
      )}

      <CorrelateModal
        open={correlateOpen}
        sessionId={correlateSessionId}
        result={correlateResult}
        loading={correlateLoading}
        onClose={() => setCorrelateOpen(false)}
      />

      {/* Save Search Modal */}
      {saveModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-slate-900 dark:text-slate-100 flex items-center">
                <Bookmark className="w-5 h-5 mr-2 text-indigo-600" />
                Aramayı Kaydet
              </h3>
              <button onClick={() => setSaveModalOpen(false)} className="text-slate-400 hover:text-slate-600 rounded-xl p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Arama İsmi</label>
              <input
                type="text"
                value={newSearchName}
                onChange={(e) => setNewSearchName(e.target.value)}
                placeholder="Örn: FortiGate SSL-VPN Oturumları"
                className="mt-2 w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setSaveModalOpen(false)}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 rounded-2xl"
              >
                İptal
              </button>
              <button
                onClick={handleSaveSearchSubmit}
                disabled={savingSearch || !newSearchName.trim()}
                className="px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-2xl flex items-center shadow-lg shadow-indigo-500/25"
              >
                <Save className="w-4 h-4 mr-1.5" />
                {savingSearch ? 'Kaydediliyor...' : 'Kaydet'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
