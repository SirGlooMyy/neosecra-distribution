import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Save,
  Globe,
  Eye,
  Smartphone,
  Edit3,
  ChevronDown,
  Copy,
  Check,
  ShieldCheck,
  Terminal,
  Layers,
  Sparkles,
  RefreshCw,
  ExternalLink,
  Sliders,
} from "lucide-react";
import {
  applyTemplate,
  getCurrentScope,
  getPredefinedTemplates,
  getPortalTemplates,
  updatePortalTemplate,
  getDevices,
} from "../lib/api";
import type { PortalTemplateRecord, PortalTemplateTheme, PortalTemplateUpdatePayload } from "../lib/api";

interface PortalTemplateForm {
  name: string;
  logoText: string;
  welcomeTitle: string;
  welcomeDescription: string;
  primaryColor: string;
  termsText: string;
  supportText: string;
  redirectUrl: string;
  enabledMethods: string[];
  kvkkText: string;
  internetPolicyText: string;
}

const DEFAULT_FORM: PortalTemplateForm = {
  name: "Varsayılan Kurumsal Şablon",
  logoText: "Merkez Kafe WiFi",
  welcomeTitle: "WiFi Ağına Hoş Geldiniz",
  welcomeDescription: "Hızlı internet erişimi için doğrulama yapın.",
  primaryColor: "#2563eb",
  termsText: "Kullanım Koşullarını ve Gizlilik Politikası'nı okudum, onaylıyorum.",
  supportText: "Destek için resepsiyonla iletişime geçin.",
  redirectUrl: "",
  enabledMethods: ["free", "sms", "voucher"],
  kvkkText: "Kişisel verileriniz, 5651 sayılı Kanun ve ilgili mevzuat kapsamında işlenir ve güvenli şekilde saklanır.",
  internetPolicyText: "Bu ağ, yalnızca yetkili kullanıcıların internet erişimi için kullanılmalıdır. Yasa dışı faaliyetlerde bulunulamaz.",
};

const DEFAULT_ENABLED_METHODS = ["sms", "voucher"];
const SUPPORTED_METHODS = new Set([
  "free",
  "sms",
  "tc_sms",
  "voucher",
  "pms",
  "local",
]);

export const AUTH_METHOD_DEFINITIONS = [
  { id: "free", label: "Sözleşme Onayı / Serbest Form (Yönetici Onaylı)", shortLabel: "Sözleşme" },
  { id: "sms", label: "Telefon (SMS)", shortLabel: "SMS" },
  { id: "tc_sms", label: "T.C. Kimlik & SMS", shortLabel: "T.C. Kimlik" },
  { id: "voucher", label: "Bilet / Voucher", shortLabel: "Bilet" },
  { id: "pms", label: "Otel odası (PMS)", shortLabel: "Otel" },
  { id: "local", label: "Manuel kullanıcı adı / şifre", shortLabel: "Kullanıcı" },
];

export const FALLBACK_PREDEFINED_TEMPLATES = [
  {
    id: "hotel_classic",
    name: "Hotel Classic",
    category: "Otel & Konaklama",
    description: "Zarif lacivert & altın sarısı klasik otel teması",
    default_theme: {
      primary_color: "#1a237e",
      secondary_color: "#d4af37",
      bg_color: "#f5f0eb",
      text_color: "#1a1a2e",
      font_family: "'Playfair Display', serif",
      logo_style: "rounded",
      button_style: "pill",
    },
  },
  {
    id: "hotel_modern",
    name: "Hotel Modern",
    category: "Otel & Konaklama",
    description: "Ferah beyaz & turkuaz modern otel tasarımı",
    default_theme: {
      primary_color: "#0d9488",
      secondary_color: "#14b8a6",
      bg_color: "#ffffff",
      text_color: "#1e293b",
      font_family: "'Inter', sans-serif",
      logo_style: "circle",
      button_style: "rounded",
    },
  },
  {
    id: "hotel_resort",
    name: "Hotel Resort & Spa",
    category: "Otel & Konaklama",
    description: "Doğal yeşil & bej huzurlu tatil köyü konsepti",
    default_theme: {
      primary_color: "#2d6a4f",
      secondary_color: "#95d5b2",
      bg_color: "#fefae0",
      text_color: "#1b4332",
      font_family: "'Lato', sans-serif",
      logo_style: "rounded",
      button_style: "rounded",
    },
  },
  {
    id: "residence_premium",
    name: "Residence Premium",
    category: "Rezidans & Yaşam",
    description: "Koyu lacivert kurumsal prestij rezidans teması",
    default_theme: {
      primary_color: "#111827",
      secondary_color: "#374151",
      bg_color: "#f8fafc",
      text_color: "#0f172a",
      font_family: "'Inter', sans-serif",
      logo_style: "square",
      button_style: "sharp",
    },
  },
  {
    id: "residence_family",
    name: "Residence Family",
    category: "Rezidans & Yaşam",
    description: "Sıcak turuncu & krem samimi aile sitesi teması",
    default_theme: {
      primary_color: "#ea580c",
      secondary_color: "#f97316",
      bg_color: "#fff7ed",
      text_color: "#431407",
      font_family: "'Nunito', sans-serif",
      logo_style: "circle",
      button_style: "pill",
    },
  },
  {
    id: "school_campus",
    name: "Üniversite Kampüs",
    category: "Eğitim & Kampüs",
    description: "Akademik mavi & beyaz modern kampüs teması",
    default_theme: {
      primary_color: "#2563eb",
      secondary_color: "#3b82f6",
      bg_color: "#f0f9ff",
      text_color: "#1e3a5f",
      font_family: "'Inter', sans-serif",
      logo_style: "square",
      button_style: "rounded",
    },
  },
  {
    id: "school_library",
    name: "Kütüphane & Araştırma",
    category: "Eğitim & Kampüs",
    description: "Sakin zeytin yeşili okuma & çalışma alanı konsepti",
    default_theme: {
      primary_color: "#4d7c0f",
      secondary_color: "#65a30d",
      bg_color: "#f7fee7",
      text_color: "#1a2e05",
      font_family: "'Merriweather', serif",
      logo_style: "rounded",
      button_style: "rounded",
    },
  },
  {
    id: "cafe_cozy",
    name: "Kahve & Bistro",
    category: "Kafe & Restoran",
    description: "Sıcak kahve tonları & samimi ahşap dokusu",
    default_theme: {
      primary_color: "#78350f",
      secondary_color: "#92400e",
      bg_color: "#fffbeb",
      text_color: "#451a03",
      font_family: "'Playfair Display', serif",
      logo_style: "circle",
      button_style: "pill",
    },
  },
  {
    id: "cafe_bistro",
    name: "Lounge & Gastronomi",
    category: "Kafe & Restoran",
    description: "Kırmızı & antrasit modern restoran tasarımı",
    default_theme: {
      primary_color: "#dc2626",
      secondary_color: "#1e293b",
      bg_color: "#fafafa",
      text_color: "#0f172a",
      font_family: "'Montserrat', sans-serif",
      logo_style: "square",
      button_style: "sharp",
    },
  },
  {
    id: "public_municipal",
    name: "Belediye & Kamu",
    category: "Kamu & Açık Alan",
    description: "Resmi kurumsal mavi & açık gri kamu portalı",
    default_theme: {
      primary_color: "#1d4ed8",
      secondary_color: "#60a5fa",
      bg_color: "#f1f5f9",
      text_color: "#0f172a",
      font_family: "'Inter', sans-serif",
      logo_style: "rounded",
      button_style: "rounded",
    },
  },
  {
    id: "public_park",
    name: "Kent Parkı & Meydan",
    category: "Kamu & Açık Alan",
    description: "Yeşil doğa & açık alan ücretsiz internet portalı",
    default_theme: {
      primary_color: "#15803d",
      secondary_color: "#22c55e",
      bg_color: "#f0fdf4",
      text_color: "#14532d",
      font_family: "'Inter', sans-serif",
      logo_style: "circle",
      button_style: "pill",
    },
  },
  {
    id: "mall_fashion",
    name: "AVM & Alışveriş",
    category: "AVM & Perakende",
    description: "Zarif fuşya & antrasit moda ve alışveriş merkezi",
    default_theme: {
      primary_color: "#c026d3",
      secondary_color: "#e879f9",
      bg_color: "#fdf4ff",
      text_color: "#701a75",
      font_family: "'Montserrat', sans-serif",
      logo_style: "rounded",
      button_style: "pill",
    },
  },
  {
    id: "mall_tech",
    name: "Teknoloji & İnovasyon",
    category: "AVM & Perakende",
    description: "Siber mavi & koyu gri yüksek teknoloji konsepti",
    default_theme: {
      primary_color: "#0284c7",
      secondary_color: "#38bdf8",
      bg_color: "#f0f9ff",
      text_color: "#0c4a6e",
      font_family: "'Inter', sans-serif",
      logo_style: "square",
      button_style: "sharp",
    },
  },
  {
    id: "business_corporate",
    name: "Plaza & Kurumsal Ofis",
    category: "Kurumsal & Plaza",
    description: "Ciddi koyu lacivert profesyonel iş merkezi teması",
    default_theme: {
      primary_color: "#0f172a",
      secondary_color: "#334155",
      bg_color: "#f8fafc",
      text_color: "#020617",
      font_family: "'Inter', sans-serif",
      logo_style: "square",
      button_style: "rounded",
    },
  },
  {
    id: "business_coworking",
    name: "Co-Working & Hub",
    category: "Kurumsal & Plaza",
    description: "Dinamik mor & indigo ortak çalışma alanı teması",
    default_theme: {
      primary_color: "#6366f1",
      secondary_color: "#818cf8",
      bg_color: "#eef2ff",
      text_color: "#312e81",
      font_family: "'Inter', sans-serif",
      logo_style: "rounded",
      button_style: "pill",
    },
  },
];

function getActiveMethodFields(portal: PortalTemplateRecord | null, method: string) {
  if (!portal) return null;
  const backendMethod = method === "tc_sms" ? "tc" : method;
  const methodFieldsMeta = portal.meta?.method_fields;
  if (methodFieldsMeta && typeof methodFieldsMeta === "object" && Array.isArray(methodFieldsMeta[backendMethod]) && methodFieldsMeta[backendMethod].length > 0) {
    const list = methodFieldsMeta[backendMethod].filter((f: any) => f && f.enabled !== false);
    if (list.length > 0) return list;
  }
  if (portal.fields && Array.isArray(portal.fields) && portal.fields.length > 0 && (portal.method === backendMethod || !methodFieldsMeta)) {
    const list = portal.fields.filter((f: any) => f && f.enabled !== false);
    if (list.length > 0) return list;
  }
  return null;
}


function normalizeFormFromPortal(portal?: PortalTemplateRecord | null): PortalTemplateForm {
  const theme = (portal?.theme || {}) as PortalTemplateTheme;
  const enabledMethods = Array.isArray(portal?.meta?.enabled_methods)
    ? portal.meta.enabled_methods
      .filter((item: unknown) => typeof item === "string")
      .map((item: string) => (item === "tc" ? "tc_sms" : item))
      .filter((item: string) => SUPPORTED_METHODS.has(item))
    : portal?.method
      ? [portal.method === "tc" ? "tc_sms" : portal.method].filter((item) => SUPPORTED_METHODS.has(item))
      : DEFAULT_ENABLED_METHODS;

  return {
    name: portal?.name || DEFAULT_FORM.name,
    logoText: String(portal?.meta?.logo_text || theme.title || portal?.name || DEFAULT_FORM.logoText),
    welcomeTitle: String(theme.title || DEFAULT_FORM.welcomeTitle),
    welcomeDescription: String(theme.subtitle || DEFAULT_FORM.welcomeDescription),
    primaryColor: String(theme.primary_color || DEFAULT_FORM.primaryColor),
    termsText: String(theme.terms_text || DEFAULT_FORM.termsText),
    supportText: String(theme.support_text || DEFAULT_FORM.supportText),
    redirectUrl: String(theme.redirect_url || (theme as any).redirectUrl || ""),
    enabledMethods: enabledMethods.length ? enabledMethods : DEFAULT_ENABLED_METHODS,
    kvkkText: String(theme.kvkk_text || (theme as any).kvkkText || DEFAULT_FORM.kvkkText),
    internetPolicyText: String(theme.internet_policy_text || (theme as any).internetPolicyText || DEFAULT_FORM.internetPolicyText),
  };
}

function buildThemePayload(formData: PortalTemplateForm, existingTheme?: PortalTemplateTheme): PortalTemplateTheme {
  return {
    ...(existingTheme || {}),
    primary_color: formData.primaryColor,
    title: formData.welcomeTitle,
    subtitle: formData.welcomeDescription,
    terms_text: formData.termsText,
    support_text: formData.supportText,
    redirect_url: formData.redirectUrl || undefined,
    kvkk_text: formData.kvkkText,
    internet_policy_text: formData.internetPolicyText,
  };
}

function buildUpdatePayload(
  formData: PortalTemplateForm,
  existingMeta?: Record<string, any>,
  existingTheme?: PortalTemplateTheme,
): PortalTemplateUpdatePayload {
  const backendMethods = formData.enabledMethods.map((m) => (m === "tc_sms" ? "tc" : m));
  return {
    name: formData.name,
    method: backendMethods[0] || "free",
    theme: buildThemePayload(formData, existingTheme),
    meta: {
      ...(existingMeta || {}),
      logo_text: formData.logoText,
      enabled_methods: backendMethods,
      custom_fields_mode: "advanced",
    },
  };
}

export const CaptivePortalPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<PortalTemplateForm>(DEFAULT_FORM);
  const [currentPortal, setCurrentPortal] = useState<PortalTemplateRecord | null>(null);
  const [currentPortalId, setCurrentPortalId] = useState<string | null>(null);
  const [currentPortalName, setCurrentPortalName] = useState<string>("");
  const [currentScopeLabel, setCurrentScopeLabel] = useState<string>("Genel Kapsam");
  const [predefinedTemplates, setPredefinedTemplates] = useState<any[]>([]);
  const [selectedPredef, setSelectedPredef] = useState<string>("");
  const [showPredefDropdown, setShowPredefDropdown] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activePreviewMethod, setActivePreviewMethod] = useState<string>("free");
  const [previewTermsAccepted, setPreviewTermsAccepted] = useState(true);
  const [showKvkkModal, setShowKvkkModal] = useState(false);
  const [showPolicyModal, setShowPolicyModal] = useState(false);
  const [devices, setDevices] = useState<any[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  const [redirectCopied, setRedirectCopied] = useState(false);
  const [cliCopied, setCliCopied] = useState(false);

  const selectedDevice = devices.find((d) => String(d.id) === selectedDeviceId) || devices[0];
  const deviceIp = selectedDevice?.management_ip || selectedDevice?.ip_address || "192.168.2.126";

  const captiveRedirectUrl = typeof window !== "undefined"
    ? `${window.location.protocol}//${window.location.hostname}:55175/?portal_id=${currentPortalId || "default"}&nas_ip=${deviceIp}`
    : `http://192.168.2.126:55175/?portal_id=default&nas_ip=${deviceIp}`;

  const fortigateCliCommand = `config user setting
    set auth-type http https
    set auth-cert "Fortinet_Factory"
    set auth-secure-http enable
    set auth-port 1000
    set auth-ssl-port 1003
    set auth-timeout 20
    set captive-portal-type external
    set captive-portal "${captiveRedirectUrl}"
end`;

  const copyToClipboard = async (text: string) => {
    let copied = false;
    if (typeof navigator !== "undefined" && navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
      try {
        await navigator.clipboard.writeText(text);
        copied = true;
      } catch {
        copied = false;
      }
    }
    if (!copied && typeof document !== "undefined") {
      try {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        textArea.style.top = "-999999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        copied = document.execCommand("copy");
        document.body.removeChild(textArea);
      } catch {
        copied = false;
      }
    }
    return copied;
  };

  const copyCaptiveRedirectUrl = async () => {
    await copyToClipboard(captiveRedirectUrl);
    setRedirectCopied(true);
    setTimeout(() => setRedirectCopied(false), 2500);
  };

  const copyCliCommand = async () => {
    await copyToClipboard(fortigateCliCommand);
    setCliCopied(true);
    setTimeout(() => setCliCopied(false), 2500);
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [scope, predefs, rawDevices] = await Promise.all([
          getCurrentScope().catch(() => null),
          getPredefinedTemplates().catch(() => ({ templates: [] })),
          getDevices().catch(() => []),
        ]);

        if (cancelled) return;
        const predefList = Array.isArray(predefs) ? predefs : (predefs?.templates || []);
        setPredefinedTemplates(predefList.length > 0 ? predefList : FALLBACK_PREDEFINED_TEMPLATES);
        setDevices(Array.isArray(rawDevices) ? rawDevices : []);
        if (Array.isArray(rawDevices) && rawDevices.length > 0) {
          setSelectedDeviceId(String(rawDevices[0].id));
        }

        const customerId = scope?.customer_id || "";
        const locationId = scope?.location_id || null;
        setCurrentScopeLabel(
          locationId ? "Lokasyon Kapsamı" : customerId ? "Müşteri Kapsamı" : "Genel Kapsam"
        );

        const list = await getPortalTemplates({
          customer_id: customerId || undefined,
          location_id: locationId || undefined,
        });

        if (cancelled) return;
        const normalizedList = Array.isArray(list) ? list : [];
        if (normalizedList.length > 0) {
          syncCurrentPortal(normalizedList[0]);
        }
      } catch (err: any) {
        if (!cancelled) {
          setErrorMessage(err?.message || "Captive portal şablonları yüklenemedi.");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const syncCurrentPortal = (portal: PortalTemplateRecord) => {
    setCurrentPortal(portal);
    setCurrentPortalId(portal.id);
    setFormData(normalizeFormFromPortal(portal));
    const enabled = normalizeFormFromPortal(portal).enabledMethods;
    if (enabled.length > 0) {
      setActivePreviewMethod(enabled[0]);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPortalId) {
      setErrorMessage("Mevcut portal bulunamadı.");
      return;
    }

    setSaving(true);
    setErrorMessage(null);
    try {
      const updated = await updatePortalTemplate(
        currentPortalId,
        buildUpdatePayload(formData, currentPortal?.meta, currentPortal?.theme)
      );
      syncCurrentPortal(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || "Portal kaydedilemedi.");
    } finally {
      setSaving(false);
    }
  };

  const handleApplyPredefined = async (tplId: string) => {
    if (!tplId) return;
    setSaving(true);
    setShowPredefDropdown(false);
    try {
      const tpl = predefinedTemplates.find((t) => t.id === tplId) || FALLBACK_PREDEFINED_TEMPLATES.find((t) => t.id === tplId);
      if (tpl?.default_theme) {
        setFormData((prev) => ({
          ...prev,
          primaryColor: tpl.default_theme.primary_color || prev.primaryColor,
          // secondary_color, etc could be mapped if they existed in form
        }));
      }
      if (currentPortalId) {
        const updated = await applyTemplate(currentPortalId, tplId);
        if (updated) {
          syncCurrentPortal(updated);
        }
      }
      setSelectedPredef(tplId);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || "Hazır şablon uygulanamadı.");
    } finally {
      setSaving(false);
    }
  };

  const activeCustomFields = getActiveMethodFields(currentPortal, activePreviewMethod);

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Captive Portal Tasarımı
            </h2>
            <span className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <Layers className="h-3 w-3 text-slate-500" />
              {currentScopeLabel}
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Misafir Wi-Fi karşılama ekranını, marka renklerini, form alanlarını ve mevzuat metinlerini özelleştirin.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Apply Template Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowPredefDropdown(!showPredefDropdown)}
              disabled={loading || saving}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
            >
              <Sparkles className="h-3.5 w-3.5 text-blue-500" />
              Hazır Şablonlar <ChevronDown className="h-3 w-3" />
            </button>

            {showPredefDropdown && (
              <div className="absolute right-0 top-full mt-1.5 w-80 max-h-96 overflow-y-auto rounded-xl border border-slate-200 bg-white p-2 shadow-2xl dark:border-slate-800 dark:bg-slate-900 z-50 divide-y divide-slate-100 dark:divide-slate-800">
                <div className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Hazır Sektörel Şablonlar &amp; Temalar
                </div>
                {predefinedTemplates.map((t) => {
                  const theme = t.default_theme || {};
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => handleApplyPredefined(t.id)}
                      className="flex w-full items-center justify-between rounded-lg p-2 text-xs text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-800 text-left transition"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="flex -space-x-1 shrink-0">
                          <span
                            className="h-4 w-4 rounded-full border border-white shadow-xs dark:border-slate-900"
                            style={{ backgroundColor: theme.primary_color || "#2563eb" }}
                          />
                          <span
                            className="h-4 w-4 rounded-full border border-white shadow-xs dark:border-slate-900"
                            style={{ backgroundColor: theme.secondary_color || "#3b82f6" }}
                          />
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-900 dark:text-white truncate flex items-center gap-1.5">
                            {t.name}
                            {t.category && (
                              <span className="rounded bg-slate-100 px-1.5 py-0.2 text-[9px] text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                                {t.category}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 truncate mt-0.5">{t.description}</div>
                        </div>
                      </div>
                      {selectedPredef === t.id && <Check className="h-4 w-4 text-blue-600 shrink-0 ml-2" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => currentPortalId && navigate(`/portal-templates/${currentPortalId}/edit`)}
            disabled={!currentPortalId}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            <Edit3 className="h-3.5 w-3.5 text-slate-500" />
            Gelişmiş Editör
          </button>

          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition disabled:opacity-50"
          >
            <Save className="h-3.5 w-3.5" />
            {saving ? "Kaydediliyor..." : "Tasarımı Kaydet"}
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs font-medium text-emerald-800 dark:border-emerald-900/40 dark:bg-emerald-950/30 dark:text-emerald-300 flex items-center gap-2">
          <Check className="h-4 w-4 text-emerald-600" />
          Captive portal şablon ayarları başarıyla kaydedildi!
        </div>
      )}

      {errorMessage && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs font-medium text-rose-800 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-300">
          {errorMessage}
        </div>
      )}

      {/* 2. FortiGate Redirection Card */}
      <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0 space-y-1 flex-1">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                FortiGate Captive Portal Dış Yönlendirme URL'i
              </h3>
              <span className="rounded-md border border-slate-200 bg-white px-1.5 py-0.5 text-[10px] font-semibold text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                External Portal
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              FortiGate Güvenlik Duvarı üzerinde <strong>User &amp; Authentication &gt; Authentication Settings &gt; Captive Portal</strong> alanına bu adresi tanımlayın.
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              {devices.length > 0 && (
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-semibold text-slate-500">Hedef Cihaz:</span>
                  <select
                    value={selectedDeviceId}
                    onChange={(e) => setSelectedDeviceId(e.target.value)}
                    className="rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs text-slate-800 outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                  >
                    {devices.map((d: any) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.management_ip || d.ip_address || "FortiGate"})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <code className="flex-1 min-w-[280px] block truncate rounded-lg border border-slate-200 bg-white px-3 py-1 font-mono text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200">
                {captiveRedirectUrl}
              </code>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={copyCaptiveRedirectUrl}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition"
            >
              {redirectCopied ? <Check className="h-3.5 w-3.5 text-emerald-300" /> : <Copy className="h-3.5 w-3.5" />}
              {redirectCopied ? "Kopyalandı" : "URL Kopyala"}
            </button>

            <button
              type="button"
              onClick={copyCliCommand}
              title="FortiGate CLI komutunu panoya kopyalar"
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition"
            >
              <Terminal className="h-3.5 w-3.5" />
              {cliCopied ? "CLI Kopyalandı" : "CLI Komutu"}
            </button>
          </div>
        </div>
      </div>

      {/* 3. Form & Live Phone Preview Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Form (7 Cols) */}
        <form
          onSubmit={handleSave}
          className="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs"
        >
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Şablon ve Karşılama Ayarları</h3>
            <span className="text-[11px] text-slate-400">Canlı Önizleme ile senkronizedir</span>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1 sm:col-span-2">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Şablon Adı</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Logo / Marka Başlığı</label>
              <input
                type="text"
                value={formData.logoText}
                onChange={(e) => setFormData((prev) => ({ ...prev, logoText: e.target.value }))}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Karşılama Başlığı</label>
              <input
                type="text"
                value={formData.welcomeTitle}
                onChange={(e) => setFormData((prev) => ({ ...prev, welcomeTitle: e.target.value }))}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
              />
            </div>

            <div className="space-y-1 sm:col-span-2">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Karşılama Açıklaması</label>
              <textarea
                value={formData.welcomeDescription}
                onChange={(e) => setFormData((prev) => ({ ...prev, welcomeDescription: e.target.value }))}
                rows={2}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Marka Rengi (Primary)</label>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  value={formData.primaryColor}
                  onChange={(e) => setFormData((prev) => ({ ...prev, primaryColor: e.target.value }))}
                  className="h-8 w-8 rounded border border-slate-200 dark:border-slate-700 cursor-pointer"
                />
                <input
                  type="text"
                  value={formData.primaryColor}
                  onChange={(e) => setFormData((prev) => ({ ...prev, primaryColor: e.target.value }))}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-mono dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Yönlendirme URL'i (Redirect URL)</label>
              <input
                type="url"
                value={formData.redirectUrl}
                onChange={(e) => setFormData((prev) => ({ ...prev, redirectUrl: e.target.value }))}
                placeholder="https://vdata.com.tr"
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
          </div>

          {/* Enabled Auth Methods */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <label className="font-semibold text-slate-700 dark:text-slate-300 block">
              Etkin Doğrulama Yöntemleri
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {AUTH_METHOD_DEFINITIONS.map((def) => (
                <label
                  key={def.id}
                  className="flex items-center space-x-2 rounded-lg border border-slate-200 bg-slate-50/60 p-2 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950/60 dark:hover:bg-slate-850 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={formData.enabledMethods.includes(def.id)}
                    onChange={() => handleCheckboxChange(def.id)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                  />
                  <span className="text-xs font-medium text-slate-800 dark:text-slate-200">{def.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Policy Texts */}
          <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Sözleşme Onay Metni</label>
              <input
                type="text"
                value={formData.termsText}
                onChange={(e) => setFormData((prev) => ({ ...prev, termsText: e.target.value }))}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
              />
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">KVKK Aydınlatma Metni</label>
                <textarea
                  value={formData.kvkkText}
                  onChange={(e) => setFormData((prev) => ({ ...prev, kvkkText: e.target.value }))}
                  rows={3}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">İnternet Kullanım Politikası</label>
                <textarea
                  value={formData.internetPolicyText}
                  onChange={(e) => setFormData((prev) => ({ ...prev, internetPolicyText: e.target.value }))}
                  rows={3}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition disabled:opacity-50"
            >
              {saving ? "Kaydediliyor..." : "Tasarımı Kaydet"}
            </button>
          </div>
        </form>

        {/* Right Phone Mockup Preview (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="w-full max-w-[340px] rounded-[36px] border-[6px] border-slate-800 bg-slate-900 p-2.5 shadow-2xl">
            {/* Phone Speaker & Camera Notch */}
            <div className="mx-auto mb-2 h-4 w-28 rounded-full bg-slate-800 flex items-center justify-center">
              <div className="h-1.5 w-1.5 rounded-full bg-slate-700 mr-2" />
              <div className="h-1 w-10 rounded-full bg-slate-700" />
            </div>

            {/* Screen Content */}
            <div className="min-h-[520px] rounded-[28px] bg-white p-5 text-slate-900 flex flex-col justify-between overflow-y-auto">
              <div className="space-y-4">
                {/* Brand Header */}
                <div className="text-center space-y-1 pt-2">
                  <div
                    className="mx-auto flex h-10 w-10 items-center justify-center rounded-xl text-white font-bold text-base shadow-sm"
                    style={{ backgroundColor: formData.primaryColor }}
                  >
                    W
                  </div>
                  <h4 className="text-sm font-bold text-slate-900">{formData.logoText}</h4>
                  <p className="text-[11px] text-slate-500 leading-tight">{formData.welcomeDescription}</p>
                </div>

                {/* Method Pills */}
                {formData.enabledMethods.length > 1 && (
                  <div className="flex flex-wrap gap-1 justify-center pt-1">
                    {formData.enabledMethods.map((m) => {
                      const def = AUTH_METHOD_DEFINITIONS.find((d) => d.id === m);
                      const isActive = activePreviewMethod === m;
                      return (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setActivePreviewMethod(m)}
                          className={`px-2 py-1 rounded-md text-[10px] font-semibold transition ${
                            isActive
                              ? "text-white"
                              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                          }`}
                          style={isActive ? { backgroundColor: formData.primaryColor } : {}}
                        >
                          {def?.shortLabel || m}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Form Fields according to active method */}
                <div className="space-y-2.5 pt-1 text-left">
                  {activePreviewMethod === "free" ? (
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">Ad Soyad *</label>
                        <input
                          type="text"
                          readOnly
                          placeholder="Adınız ve Soyadınız"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">Geldiğiniz Birim *</label>
                        <input
                          type="text"
                          readOnly
                          placeholder="Ziyaret ettiğiniz departman"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                      <p className="text-[10px] text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-100">
                        Sözleşme onayınız yönetici tarafından incelendikten sonra internet erişimi açılır.
                      </p>
                    </div>
                  ) : activePreviewMethod === "sms" ? (
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">Telefon Numarası *</label>
                        <input
                          type="text"
                          readOnly
                          placeholder="5XXXXXXXXX"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                    </div>
                  ) : activePreviewMethod === "tc_sms" ? (
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">T.C. Kimlik Numarası *</label>
                        <input
                          type="text"
                          readOnly
                          placeholder="11 haneli T.C. Kimlik No"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">Telefon Numarası *</label>
                        <input
                          type="text"
                          readOnly
                          placeholder="5XXXXXXXXX"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                    </div>
                  ) : activePreviewMethod === "voucher" ? (
                    <div className="space-y-1">
                      <label className="text-[10px] font-semibold text-slate-600">Bilet / Voucher Kodu *</label>
                      <input
                        type="text"
                        readOnly
                        placeholder="Örn: VIP-2026-X"
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                      />
                    </div>
                  ) : activePreviewMethod === "pms" ? (
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">Oda Numarası *</label>
                        <input
                          type="text"
                          readOnly
                          placeholder="Örn: 204"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">Soyadı / Doğum Yılı *</label>
                        <input
                          type="text"
                          readOnly
                          placeholder="Misafir soyadı"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">Kullanıcı Adı *</label>
                        <input
                          type="text"
                          readOnly
                          placeholder="Kullanıcı adı"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-semibold text-slate-600">Şifre *</label>
                        <input
                          type="password"
                          readOnly
                          placeholder="••••••••"
                          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs text-slate-700 outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {/* Terms checkbox */}
                  <label className="flex items-start space-x-2 pt-1 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={previewTermsAccepted}
                      onChange={(e) => setPreviewTermsAccepted(e.target.checked)}
                      className="rounded border-slate-300 mt-0.5 h-3.5 w-3.5"
                      style={{ accentColor: formData.primaryColor }}
                    />
                    <span className="text-[10px] text-slate-600 leading-tight">{formData.termsText}</span>
                  </label>

                  <button
                    type="button"
                    className="w-full rounded-lg py-2 text-xs font-bold text-white shadow-xs"
                    style={{ backgroundColor: formData.primaryColor }}
                  >
                    Doğrula ve İnternete Bağlan
                  </button>
                </div>
              </div>

              {/* Footer Links (KVKK, 5651) */}
              <div className="pt-4 border-t border-slate-100 text-center space-y-1.5">
                <div className="flex items-center justify-center gap-2 text-[10px] text-slate-500 font-medium">
                  <button type="button" onClick={() => setShowKvkkModal(true)} className="underline hover:text-slate-800">
                    KVKK Metni
                  </button>
                  <span>·</span>
                  <button type="button" onClick={() => setShowPolicyModal(true)} className="underline hover:text-slate-800">
                    Kullanım Politikası
                  </button>
                </div>
                <p className="text-[9px] text-slate-400">5651 sayılı Kanun gereği erişim kayıt altına alınmaktadır.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KVKK Preview Modal */}
      {showKvkkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">KVKK Aydınlatma Metni</h3>
              <button
                type="button"
                onClick={() => setShowKvkkModal(false)}
                className="rounded-md p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                ✕
              </button>
            </div>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
              {formData.kvkkText}
            </p>
            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setShowKvkkModal(false)}
                className="rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-blue-700"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Internet Policy Preview Modal */}
      {showPolicyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">İnternet Kullanım Politikası</h3>
              <button
                type="button"
                onClick={() => setShowPolicyModal(false)}
                className="rounded-md p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                ✕
              </button>
            </div>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
              {formData.internetPolicyText}
            </p>
            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setShowPolicyModal(false)}
                className="rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-blue-700"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
