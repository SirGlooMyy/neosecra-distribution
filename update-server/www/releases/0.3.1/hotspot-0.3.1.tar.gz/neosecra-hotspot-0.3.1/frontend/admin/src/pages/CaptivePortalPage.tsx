import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Save, Globe, Eye, Smartphone, Edit3, ChevronDown, MapPin, Plus, CheckCircle2, Copy, Check } from "lucide-react";
import {
  applyTemplate,
  getCurrentScope,
  getPredefinedTemplates,
  getPortalTemplates,
  getLocations,
  getDevices,
  createPortalTemplate,
  updatePortalTemplate,
} from "../lib/api";
import type { PortalTemplateRecord, PortalTemplateTheme, PortalTemplateUpdatePayload } from "../lib/api";

interface PortalTemplateForm {
  name: string;
  logoText: string;
  welcomeTitle: string;
  welcomeDescription: string;
  primaryColor: string;
  termsText: string;
  supportText: string;
  enabledMethods: string[];
  hotspotSubnets: string;
  portalInterface: string;
  managementSubnets: string;
  managementInterface: string;
}

const DEFAULT_FORM: PortalTemplateForm = {
  name: "Varsayılan Cafe Şablonu",
  logoText: "Merkez Kafe WiFi",
  welcomeTitle: "WiFi Ağına Hoş Geldiniz",
  welcomeDescription: "Hızlı internet erişimi için doğrulama yapın.",
  primaryColor: "#4f46e5",
  termsText: "Kullanım Koşullarını ve Gizlilik Politikası'nı okudum, onaylıyorum.",
  supportText: "Destek için resepsiyonla iletişime geçin.",
  enabledMethods: ["sms", "voucher"],
  hotspotSubnets: "",
  portalInterface: "",
  managementSubnets: "",
  managementInterface: "",
};

const DEFAULT_ENABLED_METHODS = ["sms", "voucher"];

function normalizeFormFromPortal(portal?: PortalTemplateRecord | null): PortalTemplateForm {
  const theme = (portal?.theme || {}) as PortalTemplateTheme;
  const network = (portal?.meta?.network || {}) as Record<string, unknown>;
  const toLines = (value: unknown) => Array.isArray(value) ? value.filter((item) => typeof item === "string").join("\n") : String(value || "");
  const enabledMethods = Array.isArray(portal?.meta?.enabled_methods)
    ? portal.meta.enabled_methods.filter((item: unknown) => typeof item === "string")
    : portal?.method
      ? [portal.method]
      : DEFAULT_ENABLED_METHODS;

  return {
    name: portal?.name || DEFAULT_FORM.name,
    logoText: String(portal?.meta?.logo_text || theme.title || portal?.name || DEFAULT_FORM.logoText),
    welcomeTitle: String(theme.title || DEFAULT_FORM.welcomeTitle),
    welcomeDescription: String(theme.subtitle || DEFAULT_FORM.welcomeDescription),
    primaryColor: String(theme.primary_color || DEFAULT_FORM.primaryColor),
    termsText: String(theme.terms_text || DEFAULT_FORM.termsText),
    supportText: String(theme.support_text || DEFAULT_FORM.supportText),
    enabledMethods: enabledMethods.length ? enabledMethods : DEFAULT_ENABLED_METHODS,
    hotspotSubnets: toLines(network.hotspot_subnets),
    portalInterface: String(network.portal_interface || ""),
    managementSubnets: toLines(network.management_subnets),
    managementInterface: String(network.management_interface || ""),
  };
}

function buildThemePayload(formData: PortalTemplateForm): PortalTemplateTheme {
  return {
    primary_color: formData.primaryColor,
    title: formData.welcomeTitle,
    subtitle: formData.welcomeDescription,
    terms_text: formData.termsText,
    support_text: formData.supportText,
  };
}

function buildUpdatePayload(formData: PortalTemplateForm, existingMeta?: Record<string, any>): PortalTemplateUpdatePayload {
  const lines = (value: string) => value.split(/[,\n]/).map((item) => item.trim()).filter(Boolean);
  return {
    name: formData.name,
    theme: buildThemePayload(formData),
    meta: {
      ...(existingMeta || {}),
      logo_text: formData.logoText,
      enabled_methods: formData.enabledMethods,
      network: {
        hotspot_subnets: lines(formData.hotspotSubnets),
        portal_interface: formData.portalInterface.trim(),
        management_subnets: lines(formData.managementSubnets),
        management_interface: formData.managementInterface.trim(),
      },
    },
  };
}

export const CaptivePortalPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<PortalTemplateForm>(DEFAULT_FORM);

  const [activePreviewMethod, setActivePreviewMethod] = useState<string>("sms");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [predefinedList, setPredefinedList] = useState<any[]>([]);
  const [currentPortalId, setCurrentPortalId] = useState<string>("");
  const [currentPortalName, setCurrentPortalName] = useState<string>("");
  const [currentPortal, setCurrentPortal] = useState<PortalTemplateRecord | null>(null);
  const [currentScopeLabel, setCurrentScopeLabel] = useState<string>("Genel kapsam");
  const [locations, setLocations] = useState<any[]>([]);
  const [devices, setDevices] = useState<any[]>([]);
  const [portals, setPortals] = useState<PortalTemplateRecord[]>([]);
  const [selectedLocationId, setSelectedLocationId] = useState<string>("__global__");
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  const [creatingLocationPortal, setCreatingLocationPortal] = useState(false);
  const [showPredefDropdown, setShowPredefDropdown] = useState(false);
  const [selectedPredef, setSelectedPredef] = useState("");
  const [redirectCopied, setRedirectCopied] = useState(false);

  const portalBaseUrl = (import.meta.env.VITE_PORTAL_URL as string | undefined)?.trim()
    || `${window.location.protocol}//${window.location.hostname}:55175`;
  // The portal trusts the UUID of the device registered in our database.
  // Generate a concrete URL from that UUID instead of relying on a FortiOS
  // macro that may contain a serial number or another vendor identifier.
  const captiveRedirectUrl = selectedDeviceId
    ? `${portalBaseUrl.replace(/\/$/, '')}/?device_id=${encodeURIComponent(selectedDeviceId)}`
    : `${portalBaseUrl.replace(/\/$/, '')}/?device_id=<cihaz-UUID>`;

  const copyCaptiveRedirectUrl = async () => {
    try {
      await navigator.clipboard.writeText(captiveRedirectUrl);
      setRedirectCopied(true);
      window.setTimeout(() => setRedirectCopied(false), 1800);
    } catch {
      setRedirectCopied(false);
    }
  };

  useEffect(() => {
    let cancelled = false;

    (async () => {
      setLoading(true);
      setErrorMessage(null);
      try {
        const [scope, data, portalRows, locationRows, deviceRows] = await Promise.all([
          getCurrentScope(),
          getPredefinedTemplates(),
          getPortalTemplates(),
          getLocations(),
          getDevices(),
        ]);
        if (cancelled) return;

        const scopeLocationId = scope?.location_id || null;
        const scopeCustomerId = scope?.customer_id || null;
        setCurrentScopeLabel(
          scopeLocationId
            ? "Lokasyon kapsamı"
            : scopeCustomerId
              ? "Müşteri kapsamı"
              : "Genel kapsam"
        );
        setPredefinedList(data.templates || []);
        setPortals(portalRows || []);
        const accessibleDevices = scopeLocationId
          ? (deviceRows || []).filter((device: any) => device.location_id === scopeLocationId)
          : (deviceRows || []);
        setDevices(accessibleDevices);
        const customerScopedPortals = (portalRows || []).filter((t: PortalTemplateRecord) =>
          !t.location_id && (!scopeCustomerId || t.customer_id === scopeCustomerId)
        );
        const accessibleLocations = scopeLocationId
          ? (locationRows || []).filter((location: any) => location.id === scopeLocationId)
          : (locationRows || []);
        setLocations(accessibleLocations);
        const initialLocationId = scopeLocationId || (accessibleLocations[0]?.id || "__global__");
        setSelectedLocationId(initialLocationId);
        const initialDevices = initialLocationId === "__global__"
          ? accessibleDevices
          : accessibleDevices.filter((device: any) => device.location_id === initialLocationId);
        setSelectedDeviceId((initialDevices[0]?.id as string | undefined) || "");
        const initialCandidates = initialLocationId === "__global__"
          ? customerScopedPortals
          : (portalRows || []).filter((t: PortalTemplateRecord) => t.location_id === initialLocationId);
        const activePortal =
          initialCandidates.find((t: PortalTemplateRecord) => t.is_default) ||
          initialCandidates[0] ||
          null;
        if (activePortal) {
          setCurrentPortal(activePortal);
          setCurrentPortalId(activePortal.id);
          setCurrentPortalName(activePortal.name || "Mevcut portal");
          setFormData(normalizeFormFromPortal(activePortal));
          setSelectedPredef(String(activePortal.meta?.applied_predefined_template_id || activePortal.meta?.predefined_template_id || ""));
        } else {
          setErrorMessage("Kayıtlı portal şablonu bulunamadı.");
        }
      } catch (err) {
        if (!cancelled) {
          setErrorMessage(err instanceof Error ? err.message : "Portal verisi yüklenemedi");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const syncCurrentPortal = (portal: PortalTemplateRecord) => {
    setCurrentPortal(portal);
    setCurrentPortalId(portal.id);
    setCurrentPortalName(portal.name || "Mevcut portal");
    setFormData(normalizeFormFromPortal(portal));
    const enabledMethods = Array.isArray(portal.meta?.enabled_methods)
      ? portal.meta.enabled_methods.filter((item: unknown) => typeof item === "string")
      : [];
    setActivePreviewMethod(
      enabledMethods[0] || portal.method || "sms"
    );
    setSelectedPredef(String(portal.meta?.applied_predefined_template_id || portal.meta?.predefined_template_id || ""));
  };

  const selectLocation = (locationId: string) => {
    setSelectedLocationId(locationId);
    const nextDevices = devices.filter((device) => locationId === "__global__" || device.location_id === locationId);
    setSelectedDeviceId((nextDevices[0]?.id as string | undefined) || "");
    setErrorMessage(null);
    const candidates = portals.filter((portal) => locationId === "__global__"
      ? !portal.location_id
      : portal.location_id === locationId);
    const next = candidates.find((portal) => portal.is_default) || candidates[0] || null;
    if (next) {
      syncCurrentPortal(next);
    } else {
      setCurrentPortal(null);
      setCurrentPortalId("");
      setCurrentPortalName("");
      setFormData(DEFAULT_FORM);
      setActivePreviewMethod(DEFAULT_FORM.enabledMethods[0]);
      setSelectedPredef("");
    }
  };

  const handleCreateLocationPortal = async () => {
    if (!selectedLocationId || selectedLocationId === "__global__") return;
    const location = locations.find((item) => item.id === selectedLocationId);
    if (!location) return;
    const customerDefault = portals.find((portal) => !portal.location_id && portal.customer_id === location.customer_id);
    setCreatingLocationPortal(true);
    setErrorMessage(null);
    try {
      const created = await createPortalTemplate({
        customer_id: location.customer_id,
        location_id: location.id,
        name: `${location.name} Wi-Fi`,
        method: customerDefault?.method || "sms",
        theme: customerDefault?.theme || {},
        fields: customerDefault?.fields || [],
        is_default: true,
        meta: {
          ...(customerDefault?.meta || {}),
          location_name: location.name,
          inherited_from_customer_default: Boolean(customerDefault),
        },
      });
      setPortals((current) => [created, ...current]);
      syncCurrentPortal(created);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : "Lokasyon portalı oluşturulamadı");
    } finally {
      setCreatingLocationPortal(false);
    }
  };

  const handleCheckboxChange = (method: string) => {
    setFormData(prev => {
      const isEnabled = prev.enabledMethods.includes(method);
      const newMethods = isEnabled
        ? prev.enabledMethods.filter((m) => m !== method)
        : [...prev.enabledMethods, method];
      if (isEnabled && activePreviewMethod === method) {
        setActivePreviewMethod(newMethods[0] || "");
      } else if (!isEnabled && !newMethods.includes(activePreviewMethod)) {
        setActivePreviewMethod(newMethods[0] || "");
      }
      return { ...prev, enabledMethods: newMethods };
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPortalId) {
      setErrorMessage("Mevcut portal bulunamadı.");
      return;
    }

    setSaving(true);
    setErrorMessage(null);
    try {
      const updated = await updatePortalTemplate(currentPortalId, buildUpdatePayload(formData, currentPortal?.meta));
      setPortals((current) => current.map((portal) => portal.id === updated.id ? updated : portal));
      syncCurrentPortal(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : "Portal kaydedilemedi");
    } finally {
      setSaving(false);
    }
  };

  const selectedLocation = locations.find((location) => location.id === selectedLocationId);
  const locationPortals = portals.filter((portal) => selectedLocationId === "__global__"
    ? !portal.location_id
    : portal.location_id === selectedLocationId);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Captive Portal Tasarımları</h2>
        <p className="text-sm text-slate-500">
          Misafir Wi-Fi karşılama ekranlarını özelleştirin, renkleri düzenleyin ve kimlik doğrulama yöntemlerini belirleyin.
        </p>
        <div className="mt-2 inline-flex items-center gap-2 rounded-full border border-slate-200 dark:border-slate-800 px-3 py-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
          {currentScopeLabel}
          {currentPortal ? <span className="font-normal opacity-80">· {currentPortal.location_id ? "lokasyon bazlı şablon" : "müşteri genel şablon"}</span> : null}
        </div>
      </div>

      <div className="rounded-2xl border border-indigo-100 bg-indigo-50/60 p-4 dark:border-indigo-900/40 dark:bg-indigo-950/20">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div className="grid flex-1 grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <label className="text-xs font-semibold text-indigo-950 dark:text-indigo-200">
              <span className="mb-1.5 flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> Lokasyon</span>
              <select value={selectedLocationId} onChange={(event) => selectLocation(event.target.value)} className="w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm font-normal text-slate-800 outline-none focus:border-indigo-500 dark:border-indigo-800 dark:bg-slate-900 dark:text-slate-100">
                <option value="__global__">Müşteri geneli (varsayılan)</option>
                {locations.map((location) => <option key={location.id} value={location.id}>{location.name}</option>)}
              </select>
            </label>
            <label className="text-xs font-semibold text-indigo-950 dark:text-indigo-200">
              <span className="mb-1.5 flex items-center gap-1.5"><Globe className="h-3.5 w-3.5" /> FortiGate cihazı (SQL kaydı)</span>
              <select value={selectedDeviceId} onChange={(event) => setSelectedDeviceId(event.target.value)} disabled={!devices.length} className="w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm font-normal text-slate-800 outline-none focus:border-indigo-500 disabled:opacity-60 dark:border-indigo-800 dark:bg-slate-900 dark:text-slate-100">
                {!devices.length && <option value="">Önce Cihazlar ekranından FortiGate ekleyin</option>}
                {devices.filter((device) => selectedLocationId === "__global__" || device.location_id === selectedLocationId).map((device) => <option key={device.id} value={device.id}>{device.name} · {String(device.id).slice(0, 8)}</option>)}
              </select>
            </label>
            <label className="text-xs font-semibold text-indigo-950 dark:text-indigo-200">
              <span className="mb-1.5 flex items-center gap-1.5"><Globe className="h-3.5 w-3.5" /> Bu lokasyonun portalı</span>
              <select value={currentPortalId} onChange={(event) => {
                const next = locationPortals.find((portal) => portal.id === event.target.value);
                if (next) syncCurrentPortal(next);
              }} disabled={!locationPortals.length} className="w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm font-normal text-slate-800 outline-none focus:border-indigo-500 disabled:opacity-60 dark:border-indigo-800 dark:bg-slate-900 dark:text-slate-100">
                {!locationPortals.length && <option value="">Henüz portal yok</option>}
                {locationPortals.map((portal) => <option key={portal.id} value={portal.id}>{portal.name}{portal.is_default ? " · varsayılan" : ""}</option>)}
              </select>
            </label>
          </div>
          <button type="button" onClick={() => void handleCreateLocationPortal()} disabled={!selectedLocation || creatingLocationPortal} className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-3 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50">
            <Plus className="h-4 w-4" /> {creatingLocationPortal ? "Oluşturuluyor..." : "Bu lokasyona portal ekle"}
          </button>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-indigo-800/80 dark:text-indigo-300/80">
          <CheckCircle2 className="h-3.5 w-3.5" />
          {selectedLocation ? `${selectedLocation.name} için ${locationPortals.length} portal tanımlı.` : `${locationPortals.length} müşteri-geneli portal tanımlı.`}
          {selectedLocation && !locationPortals.length && " Varsayılan ayarları kopyalamak için portal ekleyin."}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-indigo-500" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">FortiGate captive portal yönlendirme adresi</h3>
            </div>
            <p className="mt-1 text-xs leading-relaxed text-slate-500">FortiGate dış captive portal ayarında bu adresi doğrudan kullanın. <code>device_id</code>, Hotspot SQL’indeki seçili FortiGate cihaz UUID’sidir; FortiOS makrosuna bağlı değildir.</p>
            <code className="mt-2 block break-all rounded-xl bg-slate-100 px-3 py-2 text-[11px] text-slate-600 dark:bg-slate-950 dark:text-slate-300">{captiveRedirectUrl}</code>
          </div>
          <button type="button" onClick={() => void copyCaptiveRedirectUrl()} disabled={!selectedDeviceId} className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800">
            {redirectCopied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
            {redirectCopied ? "Kopyalandı" : "Adresi kopyala"}
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="p-3 bg-rose-50 dark:bg-rose-950/20 text-rose-800 dark:text-rose-400 border border-rose-100 dark:border-rose-900/50 rounded-xl text-sm font-medium">
          {errorMessage}
        </div>
      )}

      {loading && (
        <div className="p-3 bg-sky-50 dark:bg-sky-950/20 text-sky-800 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50 rounded-xl text-sm font-medium">
          Captive portal ayarları yükleniyor...
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Settings Form */}
        <form onSubmit={handleSave} className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center">
              <Globe className="w-4 h-4 mr-2 text-indigo-500" />
              Şablon Özelleştirme
            </h3>

            <section className="rounded-xl border border-sky-100 bg-sky-50/70 p-4 dark:border-sky-900/40 dark:bg-sky-950/20">
              <div className="flex items-start gap-3">
                <Globe className="mt-0.5 h-4 w-4 shrink-0 text-sky-600" />
                <div className="min-w-0 flex-1">
                  <h4 className="text-sm font-semibold text-sky-950 dark:text-sky-100">VLAN ve ağ yolu</h4>
                  <p className="mt-1 text-xs leading-relaxed text-sky-900/75 dark:text-sky-200/75">
                    Hotspot istemci subnet’i captive portal’a erişen misafir ağıdır. Management subnet’i yalnızca FortiGate API/Syslog erişimi içindir; misafir politikasına eklenmez. Her satıra bir CIDR yazın.
                  </p>
                  <div className="mt-3 grid gap-3 sm:grid-cols-2">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      Hotspot istemci subnet’i (önerilen)
                      <textarea value={formData.hotspotSubnets} onChange={(e) => setFormData((prev) => ({ ...prev, hotspotSubnets: e.target.value }))} rows={2} placeholder="10.50.0.0/24" className="mt-1 w-full rounded-lg border border-sky-200 bg-white px-3 py-2 font-mono text-xs dark:border-sky-800 dark:bg-slate-950" />
                    </label>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      Captive portal interface (opsiyonel)
                      <input value={formData.portalInterface} onChange={(e) => setFormData((prev) => ({ ...prev, portalInterface: e.target.value }))} placeholder="Guest / VLAN50" className="mt-1 w-full rounded-lg border border-sky-200 bg-white px-3 py-2 text-xs dark:border-sky-800 dark:bg-slate-950" />
                    </label>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      Management subnet’i (belge)
                      <textarea value={formData.managementSubnets} onChange={(e) => setFormData((prev) => ({ ...prev, managementSubnets: e.target.value }))} rows={2} placeholder="10.0.0.0/24" className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950" />
                    </label>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      Management interface (opsiyonel)
                      <input value={formData.managementInterface} onChange={(e) => setFormData((prev) => ({ ...prev, managementInterface: e.target.value }))} placeholder="mgmt / port3" className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950" />
                    </label>
                  </div>
                  <p className="mt-2 text-[11px] text-sky-900/70 dark:text-sky-200/70">Portal URL’si hotspot VLAN’dan erişilebilir olmalı; API çağrıları ayrı management yolundan gider.</p>
                </div>
              </div>
            </section>

            {savedSuccess && (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/50 rounded-xl text-sm font-medium">
                Portal şablon ayarları başarıyla kaydedildi!
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Şablon Adı</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Logo Metni</label>
              <input
                type="text"
                value={formData.logoText}
                onChange={(e) => setFormData({ ...formData, logoText: e.target.value })}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Karşılama Başlığı</label>
              <input
                type="text"
                value={formData.welcomeTitle}
                onChange={(e) => setFormData({ ...formData, welcomeTitle: e.target.value })}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Karşılama Açıklaması</label>
              <textarea
                value={formData.welcomeDescription}
                onChange={(e) => setFormData({ ...formData, welcomeDescription: e.target.value })}
                rows={2}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Marka Rengi (Primary)</label>
                <div className="flex items-center space-x-2">
                  <input
                    type="color"
                    value={formData.primaryColor}
                    onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                    className="w-8 h-8 rounded border border-slate-200 dark:border-slate-800 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={formData.primaryColor}
                    onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                    className="w-full px-3 py-1 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-500 block">Doğrulama Yöntemleri</label>
                <div className="space-y-1.5">
                  <label className="flex items-center space-x-2 text-sm text-slate-600 dark:text-slate-400">
                    <input
                      type="checkbox"
                      checked={formData.enabledMethods.includes("sms")}
                      onChange={() => handleCheckboxChange("sms")}
                      className="rounded border-slate-300 dark:border-slate-800 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>Telefon (SMS)</span>
                  </label>
                  <label className="flex items-center space-x-2 text-sm text-slate-600 dark:text-slate-400">
                    <input
                      type="checkbox"
                      checked={formData.enabledMethods.includes("tc_sms")}
                      onChange={() => handleCheckboxChange("tc_sms")}
                      className="rounded border-slate-300 dark:border-slate-800 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>T.C. Kimlik & SMS</span>
                  </label>
                  <label className="flex items-center space-x-2 text-sm text-slate-600 dark:text-slate-400">
                    <input
                      type="checkbox"
                      checked={formData.enabledMethods.includes("voucher")}
                      onChange={() => handleCheckboxChange("voucher")}
                      className="rounded border-slate-300 dark:border-slate-800 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>Bilet / Voucher</span>
                  </label>
                  <label className="flex items-center space-x-2 text-sm text-slate-600 dark:text-slate-400">
                    <input
                      type="checkbox"
                      checked={formData.enabledMethods.includes("pms")}
                      onChange={() => handleCheckboxChange("pms")}
                      className="rounded border-slate-300 dark:border-slate-800 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>Otel odası (PMS)</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Sözleşme / Rıza Metni</label>
              <textarea
                value={formData.termsText}
                onChange={(e) => setFormData({ ...formData, termsText: e.target.value })}
                rows={2}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              {/* Edit Template Button */}
              <button
                type="button"
                onClick={() => currentPortalId && navigate(`/portal-templates/${currentPortalId}/edit`)}
                disabled={!currentPortalId}
                className="inline-flex items-center px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Edit3 className="w-3.5 h-3.5 mr-1.5" />
                {currentPortalId ? `Edit ${currentPortalName}` : "Edit Template"}
              </button>
              {/* Apply Predefined Template Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => !saving && !loading && setShowPredefDropdown(!showPredefDropdown)}
                  disabled={loading || saving}
                  className="inline-flex items-center px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Apply Template <ChevronDown className="w-3 h-3 ml-1" />
                </button>
                {showPredefDropdown && (
                  <div className="absolute left-0 bottom-full mb-1 w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl z-50 max-h-72 overflow-y-auto">
                    {predefinedList.map((t: any) => (
                      <button
                        key={t.id}
                        type="button"
                        disabled={loading || saving}
                        onClick={async () => {
                          setSelectedPredef(t.id);
                          setShowPredefDropdown(false);
                          setFormData(prev => ({
                            ...prev,
                            name: t.name,
                            logoText: t.name,
                            welcomeTitle: t.default_theme?.title || prev.welcomeTitle,
                            welcomeDescription: t.default_theme?.subtitle || prev.welcomeDescription,
                            primaryColor: t.default_theme?.primary_color || prev.primaryColor,
                            termsText: t.default_theme?.terms_text || prev.termsText,
                            supportText: t.default_theme?.support_text || prev.supportText,
                          }));
                          try {
                            if (!currentPortalId) {
                              throw new Error("Mevcut portal bulunamadi.");
                            }
                            setSaving(true);
                            const updated = await applyTemplate(currentPortalId, t.id);
                            if (updated) {
                              syncCurrentPortal(updated);
                            }
                            setSavedSuccess(true);
                            setTimeout(() => setSavedSuccess(false), 3000);
                          } catch (err) {
                            setErrorMessage(err instanceof Error ? err.message : "Şablon uygulanamadı");
                          } finally {
                            setSaving(false);
                          }
                        }}
                        className={`w-full text-left px-3 py-2 text-xs hover:bg-slate-100 dark:hover:bg-slate-800 border-b border-slate-100 dark:border-slate-800 last:border-0 disabled:opacity-40 disabled:cursor-not-allowed ${
                          selectedPredef === t.id ? 'bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600' : ''
                        }`}
                      >
                        <span className="font-semibold">{t.name}</span>
                        <span className="ml-1.5 text-[10px] opacity-50">({t.category})</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <button
              type="submit"
              disabled={loading || saving || !currentPortalId}
              className="inline-flex items-center px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? "Kaydediliyor..." : "Tasarımı Kaydet"}
            </button>
          </div>
        </form>

        {/* Live Mobile Preview */}
        <div className="lg:col-span-5 bg-slate-100 dark:bg-slate-950/60 rounded-3xl p-6 border border-slate-200/60 dark:border-slate-800/80 flex flex-col items-center justify-center space-y-4">
          <div className="flex items-center space-x-2 text-xs font-semibold text-slate-500">
            <Smartphone className="w-4 h-4" />
            <span>Mobil Karşılama Ekranı Canlı Önizlemesi</span>
          </div>

          {/* Smartphone Frame */}
          <div className="w-[300px] h-[550px] bg-slate-900 rounded-[40px] p-3 shadow-2xl border-4 border-slate-950 relative overflow-hidden flex flex-col">
            {/* Camera notch */}
            <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-24 h-4 bg-slate-950 rounded-full z-20 flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
            </div>

            {/* Simulated Phone Screen */}
            <div className="flex-1 bg-slate-50 rounded-[30px] p-4 pt-6 overflow-y-auto flex flex-col justify-between text-slate-800 text-center font-sans select-none">
              <div className="space-y-4">
                {/* Header Logo */}
                <div className="flex flex-col items-center mt-2 space-y-1">
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold"
                    style={{ backgroundColor: formData.primaryColor }}
                  >
                    W
                  </div>
                  <span className="text-xs font-bold tracking-wide uppercase opacity-75">{formData.logoText}</span>
                </div>

                {/* Welcome Titles */}
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-slate-900">{formData.welcomeTitle}</h4>
                  <p className="text-[10px] text-slate-500 leading-normal">{formData.welcomeDescription}</p>
                </div>

                {/* Subform Tabs depending on enabled methods */}
                {formData.enabledMethods.length > 0 ? (
                  <div className="space-y-3">
                    {/* tab header */}
                    <div className="flex border-b border-slate-200">
                      {formData.enabledMethods.includes("sms") && (
                        <button 
                          type="button"
                          onClick={() => setActivePreviewMethod("sms")}
                          className={`flex-1 pb-1 text-[9px] font-bold border-b ${activePreviewMethod === 'sms' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400'}`}
                        >
                          SMS
                        </button>
                      )}
                      {formData.enabledMethods.includes("tc_sms") && (
                        <button 
                          type="button"
                          onClick={() => setActivePreviewMethod("tc_sms")}
                          className={`flex-1 pb-1 text-[9px] font-bold border-b ${activePreviewMethod === 'tc_sms' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400'}`}
                        >
                          T.C. Kimlik
                        </button>
                      )}
                      {formData.enabledMethods.includes("voucher") && (
                        <button 
                          type="button"
                          onClick={() => setActivePreviewMethod("voucher")}
                          className={`flex-1 pb-1 text-[9px] font-bold border-b ${activePreviewMethod === 'voucher' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400'}`}
                        >
                          Bilet
                        </button>
                      )}
                      {formData.enabledMethods.includes("pms") && (
                        <button
                          type="button"
                          onClick={() => setActivePreviewMethod("pms")}
                          className={`flex-1 pb-1 text-[9px] font-bold border-b ${activePreviewMethod === 'pms' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400'}`}
                        >
                          Otel
                        </button>
                      )}
                    </div>

                    {/* Inputs */}
                    <div className="space-y-2 text-left">
                      {activePreviewMethod === "sms" && (
                        <div className="space-y-1">
                          <label className="text-[8px] font-bold text-slate-400">Telefon Numarası</label>
                          <input 
                            disabled 
                            type="text" 
                            placeholder="+90 (5__) ___ __ __" 
                            className="w-full text-[10px] px-2 py-1.5 border border-slate-200 bg-white rounded-lg"
                          />
                        </div>
                      )}

                      {activePreviewMethod === "tc_sms" && (
                        <div className="space-y-1.5">
                          <div className="space-y-0.5">
                            <label className="text-[8px] font-bold text-slate-400">T.C. Kimlik No</label>
                            <input 
                              disabled 
                              type="text" 
                              placeholder="11 haneli T.C. Kimlik" 
                              className="w-full text-[10px] px-2 py-1 border border-slate-200 bg-white rounded-lg"
                            />
                          </div>
                          <div className="space-y-0.5">
                            <label className="text-[8px] font-bold text-slate-400">Telefon Numarası</label>
                            <input 
                              disabled 
                              type="text" 
                              placeholder="+90 (5__) ___ __ __" 
                              className="w-full text-[10px] px-2 py-1 border border-slate-200 bg-white rounded-lg"
                            />
                          </div>
                        </div>
                      )}

                      {activePreviewMethod === "voucher" && (
                        <div className="space-y-1">
                          <label className="text-[8px] font-bold text-slate-400">Bilet Kodu (Voucher)</label>
                          <input 
                            disabled 
                            type="text" 
                            placeholder="Örn: DEMO2026" 
                            className="w-full text-[10px] px-2 py-1.5 border border-slate-200 bg-white rounded-lg"
                          />
                        </div>
                      )}

                      {activePreviewMethod === "pms" && (
                        <div className="space-y-1.5">
                          <div className="space-y-0.5">
                            <label className="text-[8px] font-bold text-slate-400">Oda Numarası</label>
                            <input
                              disabled
                              type="text"
                              placeholder="101"
                              className="w-full text-[10px] px-2 py-1 border border-slate-200 bg-white rounded-lg"
                            />
                          </div>
                          <div className="space-y-0.5">
                            <label className="text-[8px] font-bold text-slate-400">Soyadı</label>
                            <input
                              disabled
                              type="text"
                              placeholder="Misafir soyadı"
                              className="w-full text-[10px] px-2 py-1 border border-slate-200 bg-white rounded-lg"
                            />
                          </div>
                          <p className="text-[8px] leading-snug text-slate-400">PMS ayarları ayrı ekrandan etkinleştirilir; başarılı doğrulama FortiGate oturumunu açar.</p>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-[9px] text-rose-500 font-semibold p-2 border border-rose-100 bg-rose-50 rounded-lg">
                    Lütfen en az bir doğrulama yöntemi seçin.
                  </div>
                )}

                {/* Terms text */}
                <div className="flex items-start space-x-1.5 text-[8px] text-slate-500 text-left">
                  <input type="checkbox" disabled checked className="mt-0.5 rounded text-indigo-600 w-2.5 h-2.5" />
                  <span className="leading-snug">{formData.termsText}</span>
                </div>
              </div>

              {/* Action Button */}
              <div className="space-y-3 mt-4">
                <button
                  type="button"
                  disabled
                  className="w-full text-white text-xs font-semibold py-2 rounded-xl"
                  style={{ backgroundColor: formData.primaryColor }}
                >
                  Bağlan
                </button>
                <p className="text-[8px] text-slate-400 leading-normal">{formData.supportText}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
