import React, { useState, useEffect, useRef } from "react";
import {
  exportFirewallLogs,
  getFirewallLogs,
  getVpnSessions,
  getFirewallAnalyticsSummary,
  getSearchViews,
  createSearchView,
  deleteSearchView,
  type SearchView,
} from "../lib/api";
import {
  Search,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Filter,
  Download,
  Shield,
  KeyRound,
  Activity,
  AlertTriangle,
  Radio,
  Clock,
  ArrowDownLeft,
  ArrowUpRight,
  UserCheck,
  Server,
  Layers,
  Copy,
  Check,
  X,
  ExternalLink,
  ShieldAlert,
  Globe,
  Lock,
} from "lucide-react";

interface FirewallLog {
  id: string;
  timestamp: string;
  vendor: string;
  severity: string;
  hostname: string;
  message: string;
  source_ip: string;
  dest_ip?: string;
  user?: string;
  action?: string;
  log_type?: string;
  log_subtype?: string;
  raw: string;
  source?: string | null;
  correlation_id?: string | null;
  correlation_type?: string | null;
  correlation_reason?: string | null;
  correlation_group_size?: number | null;
}

interface VpnUser {
  user: string;
  virtual_ip: string;
  policy: string;
  device: string;
  connected_at: string;
  last_activity: string;
  duration_seconds: number;
  duration_formatted: string;
  total_events: number;
  bytes_in: number;
  bytes_out: number;
  bytes_in_formatted: string;
  bytes_out_formatted: string;
  status: "online" | "offline";
}

interface AnalyticsSummary {
  total_logs_24h: number;
  denied_events_24h: number;
  bytes_in: number;
  bytes_out: number;
  bytes_in_formatted: string;
  bytes_out_formatted: string;
  security_score: number;
  top_denied_ips: Array<{ ip: string; country: string; count: number }>;
  top_ports: Array<{ port: number; service: string; count: number }>;
  top_apps: Array<{ app: string; hits: number; bytes: number; bytes_formatted: string }>;
  top_countries: Array<{ country: string; hits: number; bytes: number; bytes_formatted: string }>;
  top_sources: Array<{ src_ip: string; os: string; hits: number; bytes: number; bytes_formatted: string }>;
  top_policies: Array<{ policy: string; hits: number; bytes: number; bytes_formatted: string }>;
  top_interfaces?: Array<{ name: string; count: number }>;
  log_types: Array<{ type: string; count: number }>;
  severities: Array<{ severity: string; count: number }>;
}

const VENDORS = ["", "Fortinet", "PaloAlto", "Sophos", "SonicWall", "WatchGuard", "Zyxel", "MikroTik", "DrayTek", "pfSense", "TP-Link", "Aruba", "Ruijie"];
const SEVERITIES = ["", "emergency", "alert", "critical", "error", "warning", "notice", "info", "debug"];
const LOG_TYPES = ["", "traffic", "vpn", "webfilter", "app-ctrl", "utm", "event"];
const ACTIONS = ["", "accept", "deny", "ip-conn", "close", "client-rst", "server-rst", "timeout", "blocked"];

const severityColor: Record<string, string> = {
  emergency: "text-rose-600 bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/30",
  alert: "text-rose-600 bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/30",
  critical: "text-rose-600 bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/30",
  error: "text-red-600 bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900/30",
  warning: "text-amber-600 bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/30",
  notice: "text-blue-600 bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900/30",
  info: "text-slate-600 bg-slate-50 dark:bg-slate-950/30 border-slate-200 dark:border-slate-900/30",
  debug: "text-slate-400 bg-slate-50 dark:bg-slate-950/30 border-slate-200 dark:border-slate-900/30",
};

const actionColor: Record<string, string> = {
  accept: "text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/40",
  deny: "text-rose-700 bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/40",
  drop: "text-rose-700 bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/40",
  blocked: "text-rose-700 bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/40",
  "ip-conn": "text-amber-700 bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/40",
  close: "text-slate-600 bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700",
  "client-rst": "text-orange-700 bg-orange-50 dark:bg-orange-950/40 border-orange-200 dark:border-orange-800/40",
};

function formatLogSummary(log: FirewallLog): string {
  if (!log.message) return "—";
  const raw = log.message;

  const msgMatch = raw.match(/\bmsg="?([^"]+)"?/);
  const serviceMatch = raw.match(/\bservice="?([^"]+)"?/);
  const appMatch = raw.match(/\bapp="?([^"]+)"?/);
  const polMatch = raw.match(/\bpolicyname="?([^"]+)"?/);
  const urlMatch = raw.match(/\burl="?([^"]+)"?/);

  if (msgMatch && msgMatch[1]) {
    let summary = msgMatch[1];
    if (serviceMatch && serviceMatch[1]) summary += ` · ${serviceMatch[1]}`;
    return summary;
  }
  if (urlMatch && urlMatch[1]) {
    return urlMatch[1];
  }
  if (appMatch && appMatch[1]) {
    return appMatch[1];
  }
  if (polMatch && polMatch[1]) {
    return `${polMatch[1]} (${log.action || "flow"})`;
  }
  if (raw.length > 60 && raw.includes("date=")) {
    return `${log.log_type || "traffic"} ${log.action || ""} ${log.source_ip} -> ${log.dest_ip || ""}`;
  }
  return log.message;
}

export const FirewallLogsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"vpn" | "security" | "traffic" | "logs">("logs");
  const [vpnSubTab, setVpnSubTab] = useState<"active" | "history">("active");

  const [vpnData, setVpnData] = useState<{
    active_users: VpnUser[];
    history: VpnUser[];
    stats: { online_count: number; offline_count: number; total_bandwidth_mb: number };
  }>({
    active_users: [],
    history: [],
    stats: { online_count: 0, offline_count: 0, total_bandwidth_mb: 0 },
  });
  const [vpnLoading, setVpnLoading] = useState(false);

  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);

  const [logs, setLogs] = useState<FirewallLog[]>([]);
  const [logsLoading, setLogsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [vendor, setVendor] = useState("");
  const [severity, setSeverity] = useState("");
  const [logType, setLogType] = useState("");
  const [actionFilter, setActionFilter] = useState("");
  const [userFilter, setUserFilter] = useState("");
  const [quickFilter, setQuickFilter] = useState("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [page, setPage] = useState(1);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const [selectedLog, setSelectedLog] = useState<FirewallLog | null>(null);
  const [copiedRaw, setCopiedRaw] = useState(false);

  const [exporting, setExporting] = useState(false);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadVpn = async () => {
    setVpnLoading(true);
    try {
      const data = await getVpnSessions();
      setVpnData(data);
    } catch (err) {
      console.error("VPN sessions fetch error:", err);
    } finally {
      setVpnLoading(false);
    }
  };

  const loadAnalytics = async () => {
    setAnalyticsLoading(true);
    try {
      const data = await getFirewallAnalyticsSummary();
      setAnalytics(data);
    } catch (err) {
      console.error("Firewall analytics fetch error:", err);
    } finally {
      setAnalyticsLoading(false);
    }
  };

  const loadLogs = async () => {
    setLogsLoading(true);
    try {
      const data = await getFirewallLogs({
        vendor,
        severity,
        search,
        log_type: logType,
        action: actionFilter,
        user: userFilter,
        quick_filter: quickFilter !== "all" ? quickFilter : undefined,
        from: fromDate,
        to: toDate,
        page,
        page_size: 25,
      });
      setLogs(data);
    } catch (err) {
      console.error("Logs fetch error:", err);
    } finally {
      setLogsLoading(false);
    }
  };

  useEffect(() => {
    loadAnalytics();
    loadVpn();
    loadLogs();
  }, []);

  useEffect(() => {
    if (activeTab === "logs") {
      loadLogs();
    } else if (activeTab === "vpn") {
      loadVpn();
    } else if (activeTab === "security" || activeTab === "traffic") {
      loadAnalytics();
    }
  }, [activeTab, page, quickFilter, vendor, severity, logType, actionFilter, userFilter]);

  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(() => {
        if (activeTab === "vpn") loadVpn();
        else if (activeTab === "logs") loadLogs();
        else loadAnalytics();
      }, 10000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [autoRefresh, activeTab, vendor, severity, search, logType, actionFilter, quickFilter]);

  const handleQuickFilter = (filterKey: string) => {
    setQuickFilter(filterKey);
    setPage(1);
    setActiveTab("logs");
  };

  const handleCopyRaw = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedRaw(true);
    setTimeout(() => setCopiedRaw(false), 2000);
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const { blob, filename } = await exportFirewallLogs({
        vendor,
        severity,
        search,
        log_type: logType,
        action: actionFilter,
        quick_filter: quickFilter !== "all" ? quickFilter : undefined,
        from: fromDate,
        to: toDate,
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
    } catch (err) {
      console.error(err);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Firewall Analyzer
            </h2>
            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Canlı Log Akışı
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            FortiGate syslog akışı, aktif VPN oturumları ve UTM güvenlik olayları analizi.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-850 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-lg shadow-xs cursor-pointer">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="rounded border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-blue-500 h-3.5 w-3.5"
            />
            Otomatik (10s)
          </label>
          <button
            onClick={() => {
              if (activeTab === "vpn") loadVpn();
              else if (activeTab === "logs") loadLogs();
              else loadAnalytics();
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${vpnLoading || logsLoading || analyticsLoading ? "animate-spin" : ""}`} />
            Yenile
          </button>
          <button
            onClick={handleExport}
            disabled={exporting}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition disabled:opacity-60"
          >
            <Download className={`h-3.5 w-3.5 ${exporting ? "animate-pulse" : ""}`} />
            {exporting ? "Aktarılıyor..." : "Dışa Aktar"}
          </button>
        </div>
      </div>

      {/* 2. Standard 4 KPI Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div
          onClick={() => setActiveTab("vpn")}
          className={`cursor-pointer rounded-xl border p-4 shadow-xs transition-all ${
            activeTab === "vpn" ? "border-blue-600 bg-blue-50/20 dark:bg-blue-950/20" : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
          }`}
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Aktif VPN Oturumları</span>
            <UserCheck className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {vpnData.stats.online_count}
            </span>
            <span className="text-xs font-medium text-emerald-600">çevrimiçi</span>
          </div>
        </div>

        <div
          onClick={() => setActiveTab("logs")}
          className={`cursor-pointer rounded-xl border p-4 shadow-xs transition-all ${
            activeTab === "logs" ? "border-blue-600 bg-blue-50/20 dark:bg-blue-950/20" : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
          }`}
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">24 Saatlik Log Hacmi</span>
            <Layers className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {analytics?.total_logs_24h ? Number(analytics.total_logs_24h).toLocaleString("tr-TR") : "0"}
            </span>
            <span className="text-xs text-slate-500">olay / 24s</span>
          </div>
        </div>

        <div
          onClick={() => setActiveTab("security")}
          className={`cursor-pointer rounded-xl border p-4 shadow-xs transition-all ${
            activeTab === "security" ? "border-blue-600 bg-blue-50/20 dark:bg-blue-950/20" : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
          }`}
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Engellenen Tehditler</span>
            <ShieldAlert className="h-4 w-4 text-rose-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-rose-600 dark:text-rose-400">
              {analytics?.denied_events_24h ? Number(analytics.denied_events_24h).toLocaleString("tr-TR") : "0"}
            </span>
            <span className="text-xs font-medium text-rose-500">Deny / Drop</span>
          </div>
        </div>

        <div
          onClick={() => setActiveTab("traffic")}
          className={`cursor-pointer rounded-xl border p-4 shadow-xs transition-all ${
            activeTab === "traffic" ? "border-blue-600 bg-blue-50/20 dark:bg-blue-950/20" : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
          }`}
        >
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Ağ Trafiği</span>
            <Activity className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white">
              {analytics?.bytes_in_formatted || "0 B"}
            </span>
            <span className="text-xs text-slate-500">/ {analytics?.bytes_out_formatted || "0 B"}</span>
          </div>
        </div>
      </div>

      {/* 3. Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2 text-xs">
        <button
          onClick={() => setActiveTab("vpn")}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold transition ${
            activeTab === "vpn"
              ? "bg-blue-600 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          }`}
        >
          <KeyRound className="h-3.5 w-3.5" /> Canlı VPN &amp; Aktif Tüneller
          {vpnData.stats.online_count > 0 && (
            <span className="ml-1 rounded-full bg-emerald-500 px-1.5 py-0.2 text-[10px] text-white">
              {vpnData.stats.online_count}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab("security")}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold transition ${
            activeTab === "security"
              ? "bg-blue-600 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          }`}
        >
          <ShieldAlert className="h-3.5 w-3.5" /> Güvenlik &amp; Tehdit Analizi
        </button>

        <button
          onClick={() => setActiveTab("traffic")}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold transition ${
            activeTab === "traffic"
              ? "bg-blue-600 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          }`}
        >
          <Activity className="h-3.5 w-3.5" /> Trafik &amp; Protokol Dağılımı
        </button>

        <button
          onClick={() => setActiveTab("logs")}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold transition ${
            activeTab === "logs"
              ? "bg-blue-600 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          }`}
        >
          <Search className="h-3.5 w-3.5" /> Gelişmiş Log Arama
        </button>
      </div>

      {activeTab === "vpn" && (
        <div className="space-y-4 text-xs">
          <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-blue-50 p-2 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
                <Lock className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                  SSL-VPN ve IPsec Aktif Oturum Monitörü
                </h3>
                <p className="text-[11px] text-slate-500">
                  Kullanıcıların son tunnel-up/down durumu ve aktif trafik sinyallerine göre anlık durumu.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 p-1 dark:border-slate-800 dark:bg-slate-950">
              <button
                onClick={() => setVpnSubTab("active")}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold transition ${
                  vpnSubTab === "active"
                    ? "bg-white text-blue-600 shadow-xs dark:bg-slate-800 dark:text-blue-400"
                    : "text-slate-600 hover:text-slate-900 dark:text-slate-400"
                }`}
              >
                Çevrimiçi ({vpnData.active_users.length})
              </button>
              <button
                onClick={() => setVpnSubTab("history")}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold transition ${
                  vpnSubTab === "history"
                    ? "bg-white text-blue-600 shadow-xs dark:bg-slate-800 dark:text-blue-400"
                    : "text-slate-600 hover:text-slate-900 dark:text-slate-400"
                }`}
              >
                Geçmiş ({vpnData.history.length})
              </button>
            </div>
          </div>

          {vpnSubTab === "active" ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Kullanıcı Adı</th>
                      <th className="py-3 px-4">Durum</th>
                      <th className="py-3 px-4">Tünel / Sanal IP</th>
                      <th className="py-3 px-4">İlke / Policy</th>
                      <th className="py-3 px-4">Cihaz</th>
                      <th className="py-3 px-4">Bağlantı Zamanı</th>
                      <th className="py-3 px-4">Son Hareket</th>
                      <th className="py-3 px-4">Aktif Süre</th>
                      <th className="py-3 px-4">İndirme / Yükleme</th>
                      <th className="py-3 px-4">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono text-xs">
                    {vpnData.active_users.length === 0 ? (
                      <tr>
                        <td colSpan={10} className="py-8 text-center text-slate-500 font-sans">
                          {vpnLoading ? "VPN oturumları taranıyor..." : "Şu an aktif çevrimiçi VPN kullanıcısı bulunmuyor."}
                        </td>
                      </tr>
                    ) : (
                      vpnData.active_users.map((user, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/75 dark:hover:bg-slate-800/40 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white font-sans flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            {user.user}
                          </td>
                          <td className="py-3.5 px-4 font-sans">
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800/40">
                              Online 🟢
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-blue-600 dark:text-blue-400 font-bold">
                            {user.virtual_ip}
                          </td>
                          <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 font-sans">
                            {user.policy}
                          </td>
                          <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400 font-sans">
                            {user.device}
                          </td>
                          <td className="py-3.5 px-4 text-slate-500 font-sans">
                            {new Date(user.connected_at).toLocaleString("tr-TR")}
                          </td>
                          <td className="py-3.5 px-4 text-emerald-600 font-sans font-medium">
                            {new Date(user.last_activity).toLocaleTimeString("tr-TR")}
                          </td>
                          <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400 font-sans">
                            {user.duration_formatted}
                          </td>
                          <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300">
                            <span className="text-blue-600">↓ {user.bytes_in_formatted}</span> /{" "}
                            <span className="text-amber-600">↑ {user.bytes_out_formatted}</span>
                          </td>
                          <td className="py-3.5 px-4 font-sans">
                            <button
                              onClick={() => {
                                setUserFilter(user.user);
                                setQuickFilter("vpn");
                                setActiveTab("logs");
                              }}
                              className="text-xs text-blue-600 hover:text-blue-800 dark:hover:text-indigo-400 font-semibold underline"
                            >
                              Logları İncele →
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Kullanıcı Adı</th>
                      <th className="py-3 px-4">Durum</th>
                      <th className="py-3 px-4">Son Tünel IP</th>
                      <th className="py-3 px-4">İlke / Policy</th>
                      <th className="py-3 px-4">İlk Bağlantı</th>
                      <th className="py-3 px-4">Kapanış / Son Sinyal</th>
                      <th className="py-3 px-4">Toplam Trafik</th>
                      <th className="py-3 px-4">Olay Sayısı</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono text-xs">
                    {vpnData.history.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-slate-500 font-sans">
                          Geçmiş VPN oturum kaydı bulunamadı.
                        </td>
                      </tr>
                    ) : (
                      vpnData.history.map((user, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/75 dark:hover:bg-slate-800/40 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-slate-700 dark:text-slate-300 font-sans">
                            {user.user}
                          </td>
                          <td className="py-3.5 px-4 font-sans">
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                              Çevrimdışı ⚪
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-600">{user.virtual_ip}</td>
                          <td className="py-3.5 px-4 text-slate-600 font-sans">{user.policy}</td>
                          <td className="py-3.5 px-4 text-slate-500 font-sans">
                            {new Date(user.connected_at).toLocaleString("tr-TR")}
                          </td>
                          <td className="py-3.5 px-4 text-slate-500 font-sans">
                            {new Date(user.last_activity).toLocaleString("tr-TR")}
                          </td>
                          <td className="py-3.5 px-4 text-slate-600">
                            {user.bytes_in_formatted} / {user.bytes_out_formatted}
                          </td>
                          <td className="py-3.5 px-4 text-slate-500 font-sans">{user.total_events}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === "security" && (
        <div className="space-y-6 text-xs">
          {/* Security Posture Card */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800">
                <span className="text-2xl font-bold">{analytics?.security_score || 96}%</span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">Güvenlik Duruş Skoru (Security Posture)</h3>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800">
                    Korumalı
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Son 24 saatte toplam {analytics?.total_logs_24h.toLocaleString("tr-TR")} olayın {analytics?.denied_events_24h.toLocaleString("tr-TR")}'si güvenlik duvarı tarafından engellendi.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-[11px] text-slate-500">Engellenen Tehdit Oranı</div>
                <div className="text-base font-bold text-amber-600 dark:text-amber-400">
                  %{analytics && analytics.total_logs_24h > 0 ? ((analytics.denied_events_24h / analytics.total_logs_24h) * 100).toFixed(1) : "0"}
                </div>
              </div>
              <div className="w-px h-8 bg-slate-200 dark:bg-slate-800" />
              <div className="text-right">
                <div className="text-[11px] text-slate-500">Hedef Port Hacmi</div>
                <div className="text-base font-bold text-blue-600 dark:text-blue-400">
                  {analytics?.top_ports.length || 0} Aktif Hedef
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Denied Sources */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 text-rose-600 rounded-2xl">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      En Çok Engellenen Dış Saldırganlar (Top Denied IPs)
                    </h3>
                    <p className="text-xs text-slate-500">Firewall WAN arayüzünde düşürülen dış zararlı bağlantı denemeleri.</p>
                  </div>
                </div>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800/60 font-sans">
                {!analytics?.top_denied_ips || analytics.top_denied_ips.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">Engellenen IP kaydı bulunmuyor.</div>
                ) : (
                  analytics.top_denied_ips.map((item, idx) => (
                    <div key={idx} className="py-3 flex items-center justify-between text-xs hover:bg-slate-50/50 dark:hover:bg-slate-800/30 px-2 rounded-xl transition">
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-slate-400 w-4">{idx + 1}.</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">{item.ip}</span>
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-semibold">
                          🌐 {item.country || "Reserved"}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/40 px-2.5 py-1 rounded-xl border border-rose-200 dark:border-rose-900/30">
                          {item.count.toLocaleString("tr-TR")} engelleme
                        </span>
                        <button
                          onClick={() => {
                            setSearch(item.ip);
                            setQuickFilter("denied");
                            setActiveTab("logs");
                          }}
                          className="text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 font-bold"
                        >
                          İncele →
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Top Targeted Attack Ports */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-amber-50 dark:bg-amber-950/40 text-amber-600 rounded-2xl">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      En Çok Hedeflenen Portlar & Zafiyet Taramaları
                    </h3>
                    <p className="text-xs text-slate-500">Güvenlik duvarı üzerinde en yoğun tarama ve dış istek alan servisler.</p>
                  </div>
                </div>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800/60 font-sans">
                {!analytics?.top_ports || analytics.top_ports.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">Hedef port verisi henüz oluşmadı.</div>
                ) : (
                  analytics.top_ports.map((item, idx) => (
                    <div key={idx} className="py-3 flex items-center justify-between text-xs hover:bg-slate-50/50 dark:hover:bg-slate-800/30 px-2 rounded-xl transition">
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-slate-400 w-4">{idx + 1}.</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">{item.service}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-xl">
                          {item.count.toLocaleString("tr-TR")} engelleme
                        </span>
                        <button
                          onClick={() => {
                            setSearch(String(item.port));
                            setQuickFilter("denied");
                            setActiveTab("logs");
                          }}
                          className="text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 font-bold"
                        >
                          Filtrele →
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* MITRE ATT&CK Security Matrix Cards */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-blue-600" />
              MITRE ATT&CK Güvenlik Analiz Matrisi
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  🔍 T1046 - Ağ Servisi Taraması (Reconnaissance)
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Port 10443, 9930 ve 41641 üzerindeki yoğun SYN paketleri otomatik olarak engellendi.
                </p>
                <div className="text-xs font-bold text-emerald-600">✓ Kural Tarafından Drop Edildi</div>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  🔑 T1078 - Yetkili Hesap Giriş Denemesi (Initial Access)
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  SSL-VPN ve FortiGate yönetim portuna yetkisiz kimlik doğrulama denemeleri izleniyor.
                </p>
                <div className="text-xs font-bold text-emerald-600">✓ 2FA / MFA Koruması Aktif</div>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">
                  📡 T1041 - Dışarıya Veri Sızdırma (Exfiltration)
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Olağandışı yüksek bant genişliği çıkışları anlık trafik matrisinde izlenmektedir.
                </p>
                <div className="text-xs font-bold text-emerald-600">✓ Normal Sınırlar İçerisinde</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "traffic" && (
        <div className="space-y-6 text-xs">
          {/* 1. FortiGate Live Gateway & Telemetry Health Card */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 border-b border-slate-100 pb-5 dark:border-slate-800">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-50 border border-blue-100 text-blue-600 rounded-xl dark:bg-blue-950/40 dark:border-blue-900/50 dark:text-blue-400">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">FortiGate Ağ Telemetrisi & Trafik Analizi</h3>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800">
                      Canlı Veri
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Cihaz: <span className="font-mono text-slate-700 dark:text-slate-300">FortiGate-60F</span> · Toplam Log: <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{analytics?.total_logs_24h.toLocaleString("tr-TR") || "0"}</span> · 5651 SHA-256 İmzalı Arşiv: <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Aktif</span>
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 w-full lg:w-auto text-xs">
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-center dark:bg-slate-950 dark:border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-500">Güvenlik Skoru</span>
                  <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">%{analytics?.security_score || 94}</div>
                  <span className="text-[9px] text-slate-400">Korumalı</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-center dark:bg-slate-950 dark:border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-500">İndirme (Download)</span>
                  <div className="text-sm font-bold text-blue-600 dark:text-blue-400 mt-0.5">{analytics?.bytes_in_formatted || "0 B"}</div>
                  <span className="text-[9px] text-slate-400">Gelen Veri</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-center dark:bg-slate-950 dark:border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-500">Yükleme (Upload)</span>
                  <div className="text-sm font-bold text-purple-600 dark:text-purple-400 mt-0.5">{analytics?.bytes_out_formatted || "0 B"}</div>
                  <span className="text-[9px] text-slate-400">Giden Veri</span>
                </div>
              </div>
            </div>

            {/* Real Interface States from FortiGate */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-4 font-sans text-xs">
              {analytics?.top_interfaces && analytics.top_interfaces.length > 0 ? (
                analytics.top_interfaces.map((intf, idx) => (
                  <div key={idx} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between dark:bg-slate-950 dark:border-slate-800">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase">{intf.name}</span>
                      <div className="font-mono font-semibold text-slate-800 dark:text-slate-200 text-xs mt-0.5">{intf.count.toLocaleString("tr-TR")} olay</div>
                    </div>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50" />
                  </div>
                ))
              ) : (
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between dark:bg-slate-950 dark:border-slate-800 col-span-full">
                  <span className="text-xs text-slate-500">Arayüz verileri yükleniyor...</span>
                </div>
              )}
            </div>
          </div>

          {/* 🌟 2. Interactive Network Flow Topology (Flow Matrix from Real Logs) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-blue-50 dark:bg-indigo-950/40 text-blue-600 rounded-2xl">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    FortiView Canlı Trafik & Güvenlik Akış Topolojisi (Flow Matrix)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Yerel ve VPN kaynaklarından çıkan paketlerin güvenlik politikalarından geçerek hedeflere akış şeması.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {/* Column 1: Sources */}
              <div className="space-y-3 bg-slate-50 dark:bg-slate-950/60 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-800">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 pb-2 border-b border-slate-200 dark:border-slate-800">
                  <span>💻</span> 1. En Yoğun Kaynaklar (Top Sources)
                </div>
                <div className="space-y-2">
                  {analytics?.top_sources.slice(0, 3).map((s, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs shadow-xs">
                      <div className="font-bold text-slate-800 dark:text-slate-200 font-mono">{s.src_ip}</div>
                      <div className="text-[11px] text-emerald-600 font-mono font-semibold">
                        {s.bytes_formatted} · {s.hits.toLocaleString("tr-TR")} Hit ({s.os})
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Column 2: Security Policies */}
              <div className="space-y-3 bg-slate-50 dark:bg-slate-950/60 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-800">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 pb-2 border-b border-slate-200 dark:border-slate-800">
                  <span>🛡️</span> 2. Firewall Kuralları (Policies)
                </div>
                <div className="space-y-2">
                  {analytics?.top_policies.slice(0, 3).map((p, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs shadow-xs">
                      <div className="font-bold text-blue-600 dark:text-blue-400 font-mono">{p.policy}</div>
                      <div className="text-[11px] text-slate-600 dark:text-slate-400 font-mono">
                        {p.bytes_formatted} · {p.hits.toLocaleString("tr-TR")} Oturum
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Column 3: Destinations */}
              <div className="space-y-3 bg-slate-50 dark:bg-slate-950/60 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-800">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 pb-2 border-b border-slate-200 dark:border-slate-800">
                  <span>🌐</span> 3. Hedefler & Servisler (Destinations)
                </div>
                <div className="space-y-2">
                  {analytics?.top_countries.slice(0, 3).map((c, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs shadow-xs">
                      <div className="font-bold text-slate-800 dark:text-slate-200">🌐 {c.country}</div>
                      <div className="text-[11px] text-emerald-600 font-mono font-semibold">
                        {c.bytes_formatted} · {c.hits.toLocaleString("tr-TR")} Hit
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* 🌟 3. Top Applications & Top Talkers */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Applications */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-blue-50 dark:bg-indigo-950/40 text-blue-600 rounded-2xl">
                    <Activity className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      En Çok Kullanılan Uygulamalar (Top Applications)
                    </h3>
                    <p className="text-xs text-slate-500">FortiGate App-Ctrl ve protokol bazlı bant genişliği dağılımı.</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 font-sans">
                {!analytics?.top_apps || analytics.top_apps.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">Uygulama verisi taranıyor...</div>
                ) : (
                  analytics.top_apps.map((app, idx) => {
                    const pct = analytics.total_logs_24h > 0 ? Math.round((app.hits / analytics.total_logs_24h) * 100) : 0;
                    return (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between text-xs font-semibold">
                          <span className="font-bold text-slate-800 dark:text-slate-200">{app.app}</span>
                          <span className="text-slate-500 font-mono">
                            {app.bytes_formatted} · {app.hits.toLocaleString("tr-TR")} hit (%{pct})
                          </span>
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div className="bg-indigo-600 h-2 rounded-full transition-all" style={{ width: `${Math.max(pct, 2)}%` }} />
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Top Talkers */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 rounded-2xl">
                    <Server className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      En Çok Trafik Harcayan Cihazlar (Top Talkers)
                    </h3>
                    <p className="text-xs text-slate-500">Yerel ağda en yüksek veri akışı sağlayan kaynak IP ve işletim sistemleri.</p>
                  </div>
                </div>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800/60 font-sans">
                {!analytics?.top_sources || analytics.top_sources.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">Kaynak cihaz verisi taranıyor...</div>
                ) : (
                  analytics.top_sources.map((src, idx) => (
                    <div key={idx} className="py-2.5 flex items-center justify-between text-xs hover:bg-slate-50/50 dark:hover:bg-slate-800/30 px-2 rounded-xl transition">
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-slate-400 w-4">{idx + 1}.</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">{src.src_ip}</span>
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-semibold">
                          💻 {src.os}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold font-mono text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-xl border border-emerald-200 dark:border-emerald-900/30">
                          {src.bytes_formatted}
                        </span>
                        <span className="text-slate-400 font-mono">{src.hits.toLocaleString("tr-TR")} hit</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* 🌟 4. Destination Countries & Policy Hit Matrix */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Destination Countries */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-blue-50 dark:bg-blue-950/40 text-blue-600 rounded-2xl">
                    <Globe className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      Hedef Ülkeler (Destination Geo-IP)
                    </h3>
                    <p className="text-xs text-slate-500">Trafiğin yöneldiği ülkeler ve toplam bant genişliği.</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 font-sans">
                {!analytics?.top_countries || analytics.top_countries.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">Ülke verisi taranıyor...</div>
                ) : (
                  analytics.top_countries.map((c, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs py-2 border-b border-slate-100 dark:border-slate-800/40 last:border-none">
                      <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                        <span>🌐</span> {c.country}
                      </span>
                      <div className="flex items-center gap-3">
                        <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{c.bytes_formatted}</span>
                        <span className="text-slate-400 font-mono">({c.hits.toLocaleString("tr-TR")} hit)</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Policy Hits */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-amber-50 dark:bg-amber-950/40 text-amber-600 rounded-2xl">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      Güvenlik Duvarı İlke Kullanımı (Policy Hits)
                    </h3>
                    <p className="text-xs text-slate-500">Hangi FortiGate kurallarının en çok kullanıldığı ve veri taşıdığı.</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 font-sans">
                {!analytics?.top_policies || analytics.top_policies.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-500">Kural verisi taranıyor...</div>
                ) : (
                  analytics.top_policies.map((p, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs py-2 border-b border-slate-100 dark:border-slate-800/40 last:border-none">
                      <span className="font-bold text-slate-800 dark:text-slate-200 font-mono flex items-center gap-2">
                        <span className="text-indigo-500">🛡️</span> {p.policy}
                      </span>
                      <div className="flex items-center gap-3">
                        <span className="font-mono font-bold text-emerald-600">{p.bytes_formatted}</span>
                        <span className="text-slate-400 font-mono">({p.hits.toLocaleString("tr-TR")} oturum)</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "logs" && (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2 items-center bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-2">Hızlı Filtre:</span>
            {[
              { key: "all", label: "🌐 Tüm Loglar" },
              { key: "denied", label: "🛑 Engellenen Trafik (Deny)" },
              { key: "vpn", label: "🔑 VPN Olayları" },
              { key: "webfilter", label: "🛡️ Web Filtre" },
              { key: "appctrl", label: "📱 Uygulama Kontrolü (App-Ctrl)" },
              { key: "threats", label: "⚠️ Kritik Güvenlik Alarmları" },
            ].map((f) => (
              <button
                key={f.key}
                type="button"
                onClick={() => handleQuickFilter(f.key)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all border ${
                  quickFilter === f.key
                    ? "bg-blue-600 text-white border-blue-600 shadow-sm"
                    : "bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700"
                }`}
              >
                {f.label}
              </button>
            ))}
            <div className="flex flex-1 items-center bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 min-w-[200px] max-w-sm">
              <Search className="w-3.5 h-3.5 text-slate-400 mr-2 shrink-0" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    setPage(1);
                    loadLogs();
                  }
                }}
                placeholder="Log ara (IP, kelime, port... Enter)"
                className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none"
              />
              {search && (
                <button
                  type="button"
                  onClick={() => {
                    setSearch("");
                    setPage(1);
                    loadLogs();
                  }}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs ml-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="ml-auto inline-flex items-center px-3 py-1.5 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <Filter className="w-3.5 h-3.5 mr-1" />
              {showFilters ? "Filtreleri Gizle" : "Detaylı Filtre"}
            </button>
          </div>

          {showFilters && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Genel Arama (IP / Mesaj / Kelime)</label>
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="192.168.2.1, DNS, Connection Failed..."
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Log Tipi (Type)</label>
                  <select
                    value={logType}
                    onChange={(e) => setLogType(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Tümü</option>
                    {LOG_TYPES.filter(Boolean).map((lt) => (
                      <option key={lt} value={lt}>{lt}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Eylem (Action)</label>
                  <select
                    value={actionFilter}
                    onChange={(e) => setActionFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Tümü</option>
                    {ACTIONS.filter(Boolean).map((a) => (
                      <option key={a} value={a}>{a}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Kullanıcı (User)</label>
                  <input
                    type="text"
                    value={userFilter}
                    onChange={(e) => setUserFilter(e.target.value)}
                    placeholder="hasan.cosan, admin..."
                    className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSearch("");
                    setLogType("");
                    setActionFilter("");
                    setUserFilter("");
                    setVendor("");
                    setSeverity("");
                    setQuickFilter("all");
                    setPage(1);
                    loadLogs();
                  }}
                  className="px-4 py-2 text-xs font-semibold border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50"
                >
                  Sıfırla
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPage(1);
                    loadLogs();
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold"
                >
                  Filtreleri Uygula
                </button>
              </div>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Zaman</th>
                    <th className="py-3 px-4">Ciddiyet</th>
                    <th className="py-3 px-4">Tip</th>
                    <th className="py-3 px-4">Eylem</th>
                    <th className="py-3 px-4">Kaynak IP</th>
                    <th className="py-3 px-4">Hedef IP</th>
                    <th className="py-3 px-4">Kullanıcı</th>
                    <th className="py-3 px-4">Cihaz</th>
                    <th className="py-3 px-4">Mesaj / Özet</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono text-xs">
                  {logs.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-slate-500 font-sans">
                        {logsLoading ? "Loglar yükleniyor..." : "Filtreye uygun log kaydı bulunamadı."}
                      </td>
                    </tr>
                  ) : (
                    logs.map((log) => (
                      <tr
                        key={log.id}
                        onClick={() => setSelectedLog(log)}
                        className="hover:bg-blue-50/50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors"
                      >
                        <td className="py-3 px-4 text-slate-500 font-sans whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleTimeString("tr-TR")}
                        </td>
                        <td className="py-3 px-4 font-sans">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-bold uppercase border ${
                              severityColor[log.severity] || severityColor.info
                            }`}
                          >
                            {log.severity}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-700 dark:text-slate-300 uppercase font-bold">
                          {log.log_type || "TRAFFIC"}
                        </td>
                        <td className="py-3 px-4 font-sans">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-bold border uppercase ${
                              actionColor[log.action || ""] || "text-slate-600 bg-slate-100 border-slate-200"
                            }`}
                          >
                            {log.action || "accept"}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">
                          {log.source_ip || "—"}
                        </td>
                        <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                          {log.dest_ip || "—"}
                        </td>
                        <td className="py-3 px-4 font-sans text-blue-600 dark:text-blue-400 font-semibold">
                          {log.user || "—"}
                        </td>
                        <td className="py-3 px-4 font-sans text-slate-500">
                          {log.hostname}
                        </td>
                        <td className="py-3 px-4 font-sans text-slate-600 dark:text-slate-300 truncate max-w-xs" title={log.message}>
                          {formatLogSummary(log)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50">
              <span className="text-xs text-slate-500 font-sans">
                Sayfa {page} ({logs.length} kayıt gösteriliyor)
              </span>
              <div className="flex items-center gap-2">
                <button
                  disabled={page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="px-3 py-1.5 text-xs font-semibold border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-white dark:hover:bg-slate-900 disabled:opacity-40"
                >
                  ← Önceki
                </button>
                <button
                  onClick={() => setPage((p) => p + 1)}
                  className="px-3 py-1.5 text-xs font-semibold border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-white dark:hover:bg-slate-900"
                >
                  Sonraki →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedLog && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/40 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl h-full flex flex-col">
            <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950">
              <div className="flex items-center gap-2.5">
                <span className="p-2 bg-blue-50 dark:bg-indigo-950 text-blue-600 rounded-xl">
                  <Radio className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">Syslog Detay Analizi</h3>
                  <p className="text-xs text-slate-500 font-mono">{selectedLog.id}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedLog(null)}
                className="p-2 rounded-xl text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 flex-1 overflow-y-auto font-sans text-xs">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Eylem</span>
                  <div className="mt-1 font-bold text-sm uppercase">{selectedLog.action || "accept"}</div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Log Tipi</span>
                  <div className="mt-1 font-bold text-sm uppercase">{selectedLog.log_type || "traffic"}</div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Ciddiyet</span>
                  <div className="mt-1 font-bold text-sm uppercase text-amber-600">{selectedLog.severity}</div>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">Cihaz Host</span>
                  <div className="mt-1 font-bold text-sm">{selectedLog.hostname}</div>
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 font-mono">
                <div className="text-xs font-bold text-slate-400 uppercase font-sans">Bağlantı & Uç Noktalar</div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="text-slate-400 text-[11px]">Kaynak IP (Source):</span>
                    <div className="text-sm font-bold text-blue-600 dark:text-blue-400">{selectedLog.source_ip}</div>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px]">Hedef IP (Destination):</span>
                    <div className="text-sm font-bold text-slate-800 dark:text-slate-200">{selectedLog.dest_ip || "0.0.0.0"}</div>
                  </div>
                </div>
                {selectedLog.user && (
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Kimlik / Kullanıcı:</span>
                    <div className="text-sm font-bold text-emerald-600">{selectedLog.user}</div>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Ham Syslog Mesajı (Raw)</span>
                  <button
                    onClick={() => handleCopyRaw(selectedLog.raw)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-800"
                  >
                    {copiedRaw ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedRaw ? "Kopyalandı!" : "Kopyala"}
                  </button>
                </div>
                <div className="p-4 bg-slate-950 text-emerald-400 rounded-2xl font-mono text-xs overflow-x-auto border border-slate-800 leading-relaxed select-all">
                  {selectedLog.raw}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex justify-end">
              <button
                onClick={() => setSelectedLog(null)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900 rounded-xl text-xs font-semibold"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FirewallLogsPage;

