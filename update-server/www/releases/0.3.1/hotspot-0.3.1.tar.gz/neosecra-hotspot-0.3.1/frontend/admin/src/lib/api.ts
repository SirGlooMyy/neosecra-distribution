// Admin API Client
// Prefer same-origin proxy in dev. If a real external API base is provided,
// keep it; otherwise ignore localhost build-time values so LAN/IP access works.
const BUILT_API_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.trim() || '';

function resolveApiBase(): string {
  if (!BUILT_API_BASE) return '';

  try {
    const url = new URL(BUILT_API_BASE);
    if (url.hostname === 'localhost' || url.hostname === '127.0.0.1') {
      return '';
    }
    return BUILT_API_BASE.replace(/\/+$/, '');
  } catch {
    return BUILT_API_BASE.replace(/\/+$/, '');
  }
}

const API_BASE = resolveApiBase();

// List endpoints have existed in two response contracts across deployed
// versions (a bare array and an envelope such as {items/results/data}). Keep
// the client boundary tolerant so a stale backend cannot crash a page with
// `value.map is not a function`. Every page receives a real array.
function asList<T = any>(value: any): T[] {
  if (Array.isArray(value)) return value as T[];
  if (Array.isArray(value?.items)) return value.items as T[];
  if (Array.isArray(value?.results)) return value.results as T[];
  if (Array.isArray(value?.data)) return value.data as T[];
  return [];
}

// Token storage (persisted in localStorage)
let accessToken: string | null = typeof window !== 'undefined' ? localStorage.getItem('admin_access_token') : null;
let currentUser: any | null = null;

// Helpers to get/set tokens in localStorage
const getRefreshToken = () => (typeof window !== 'undefined' ? localStorage.getItem('admin_refresh_token') : null);
const setRefreshToken = (token: string | null) => {
  if (typeof window === 'undefined') return;
  if (token) localStorage.setItem('admin_refresh_token', token);
  else localStorage.removeItem('admin_refresh_token');
};
const setAccessToken = (token: string | null) => {
  accessToken = token;
  if (typeof window === 'undefined') return;
  if (token) localStorage.setItem('admin_access_token', token);
  else localStorage.removeItem('admin_access_token');
};


function isNetworkError(error: any): boolean {
  return error instanceof TypeError || error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError');
}

/** Convert FastAPI/Pydantic and proxy envelopes into a useful string. */
export function formatApiError(payload: unknown, fallback: string): string {
  const detail = payload && typeof payload === 'object'
    ? (payload as Record<string, unknown>).detail ?? payload
    : payload;

  const stringify = (value: unknown): string | undefined => {
    if (typeof value === 'string' && value.trim() && value !== '[object Object]') return value;
    if (Array.isArray(value)) {
      const messages = value.map(stringify).filter((item): item is string => Boolean(item));
      return messages.length ? messages.join(' · ') : undefined;
    }
    if (value && typeof value === 'object') {
      const object = value as Record<string, unknown>;
      const direct = object.message ?? object.msg ?? object.error ?? object.detail;
      if (direct !== undefined) return stringify(direct);
      const loc = Array.isArray(object.loc) ? object.loc.filter(Boolean).join('.') : '';
      const type = typeof object.type === 'string' ? object.type : '';
      if (loc || type) return [loc, type].filter(Boolean).join(': ');
      try {
        const json = JSON.stringify(value);
        return json && json !== '{}' ? json : undefined;
      } catch {
        return undefined;
      }
    }
    if (value == null) return undefined;
    const scalar = String(value);
    return scalar === '[object Object]' ? undefined : scalar;
  };

  return stringify(detail) || fallback;
}

/**
 * Base Fetch Wrapper with Authorization headers & Auto Refresh Token Rotation.
 */
export async function request(path: string, options: RequestInit = {}): Promise<any> {
  const url = `${API_BASE}/api/v1${path}`;
  const headers = new Headers(options.headers || {});
  
  if (accessToken) {
    headers.set('Authorization', `Bearer ${accessToken}`);
  }
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const fetchOptions = { ...options, headers };

  try {
    const response = await fetch(url, fetchOptions);

    if (response.status === 401 && getRefreshToken()) {
      // Attempt token rotation
      console.warn('Access token expired, attempting refresh token rotation...');
      const tokens = await rotateTokens();
      if (tokens) {
        headers.set('Authorization', `Bearer ${tokens.access_token}`);
        const retryResponse = await fetch(url, { ...options, headers });
        if (retryResponse.ok) return retryResponse.json();
      }
    }

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const error = new Error(formatApiError(errorData, `Hata: ${response.status}`)) as Error & {
        status?: number;
      };
      error.status = response.status;
      throw error;
    }

    if (response.status === 204) return null;
    return response.json();
  } catch (err: any) {
    if (isNetworkError(err)) {
      throw err;
    }
    throw err;
  }
}

export async function requestBlob(path: string, options: RequestInit = {}): Promise<Response> {
  const url = `${API_BASE}/api/v1${path}`;
  const headers = new Headers(options.headers || {});

  if (accessToken) {
    headers.set('Authorization', `Bearer ${accessToken}`);
  }
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const fetchOptions = { ...options, headers };
  const response = await fetch(url, fetchOptions);

  if (response.status === 401 && getRefreshToken()) {
    const tokens = await rotateTokens();
    if (tokens) {
      headers.set('Authorization', `Bearer ${tokens.access_token}`);
      const retryResponse = await fetch(url, { ...options, headers });
      if (retryResponse.ok) return retryResponse;
      const retryError = await retryResponse.clone().json().catch(() => ({}));
      throw new Error(formatApiError(retryError, `Hata: ${retryResponse.status}`));
    }
  }

  if (!response.ok) {
    const errorData = await response.clone().json().catch(() => ({}));
    throw new Error(formatApiError(errorData, `Hata: ${response.status}`));
  }

  return response;
}

/**
 * Refreshes tokens using refresh token
 */
async function rotateTokens(): Promise<{ access_token: string } | null> {
  const rfToken = getRefreshToken();
  if (!rfToken) return null;

  try {
    const response = await fetch(`${API_BASE}/api/v1/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: rfToken }),
    });

    if (response.ok) {
      const data = await response.json();
      accessToken = data.access_token;
      setRefreshToken(data.refresh_token);
      return data;
    }
  } catch (err) {
    console.error('Refresh token rotation failed:', err);
  }
  // Logout user on fail
  logout();
  return null;
}

/**
 * Auth APIs
 */
export async function login(email: string, password: string): Promise<any> {
  try {
    const data = await request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    if (data.mfa_required) {
      return data;
    }
    setAccessToken(data.access_token);
    currentUser = data.user;
    setRefreshToken(data.refresh_token);
    return data.user;
  } catch (err: any) {
    throw err;
  }
}

export async function completeMfaLogin(sessionToken: string, code: string): Promise<any> {
  const data = await request('/auth/mfa/complete', {
    method: 'POST',
    body: JSON.stringify({ session_token: sessionToken, code }),
  });
  setAccessToken(data.access_token);
  currentUser = data.user;
  setRefreshToken(data.refresh_token);
  return data.user;
}

export function logout() {
  setAccessToken(null);
  currentUser = null;
  setRefreshToken(null);
  window.location.reload();
}

export async function getCurrentUser(): Promise<any> {
  if (currentUser) return currentUser;
  // Avoid an intentional unauthenticated probe on every public first visit.
  // A refresh token is enough to attempt rotation; without either token the
  // caller is known to be logged out.
  if (!accessToken && !getRefreshToken()) return null;
  try {
    currentUser = await request('/auth/me');
    return currentUser;
  } catch (err: any) {
    // An unauthenticated first visit is an expected state, not an application
    // error. Let App render the public/login route without noisy console logs.
    if (err?.status === 401 || err?.message === 'Kimlik dogrulama gerekiyor') {
      return null;
    }
    if (isNetworkError(err)) {
      return null;
    }
    throw err;
  }
}

export async function updateCurrentUserProfile(data: { email?: string; full_name?: string | null }): Promise<any> {
  const updated = await request('/auth/me', {
    method: 'PATCH',
    body: JSON.stringify(data),
  });
  currentUser = updated;
  return updated;
}

export async function changePassword(currentPassword: string, newPassword: string): Promise<any> {
  return request('/auth/change-password', {
    method: 'POST',
    body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }),
  });
}

export interface CurrentScope {
  role: string | null;
  tenant_id: string | null;
  partner_id: string | null;
  customer_id: string | null;
  location_id: string | null;
  user_id: string | null;
}

export async function getCurrentScope(): Promise<CurrentScope | null> {
  const user = await getCurrentUser();
  if (!user) return null;
  return {
    role: user.role ?? null,
    tenant_id: user.tenant_id ?? null,
    partner_id: user.partner_id ?? null,
    customer_id: user.customer_id ?? null,
    location_id: user.location_id ?? null,
    user_id: user.id ?? null,
  };
}

export async function getCurrentCustomerId(): Promise<string | null> {
  const scope = await getCurrentScope();
  return scope?.customer_id ?? null;
}

/**
 * Customers CRUD
 */
export async function getCustomers(): Promise<any[]> {
  try {
    return asList(await request('/customers'));
  } catch (err) {
    throw err;
  }
}

export async function addCustomer(data: any): Promise<any> {
  return request('/customers', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function deleteCustomer(id: string): Promise<void> {
  await request(`/customers/${id}`, { method: 'DELETE' });
}

/**
 * Locations CRUD
 */
export async function getLocations(): Promise<any[]> {
  try {
    return asList(await request('/locations'));
  } catch (err) {
    throw err;
  }
}

export async function addLocation(data: any): Promise<any> {
  return request('/locations', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function deleteLocation(id: string): Promise<void> {
  await request(`/locations/${id}`, { method: 'DELETE' });
}

/**
 * Devices CRUD
 */
export async function getDevices(): Promise<any[]> {
  try {
    return asList(await request('/devices'));
  } catch (err) {
    throw err;
  }
}

export async function addDevice(data: any): Promise<any> {
  return request('/devices', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function deleteDevice(id: string): Promise<void> {
  await request(`/devices/${id}`, { method: 'DELETE' });
}

export interface DeviceCredentialMetadata {
  device_id: string;
  api_username?: string | null;
  api_vdom?: string | null;
  verify_tls: boolean;
  has_token: boolean;
  has_ssh_key: boolean;
  last_check_ok?: boolean | null;
  last_check_at?: string | null;
}

/** Returns metadata only; the FortiGate token is never sent back. */
export async function getDeviceCredential(id: string): Promise<DeviceCredentialMetadata | null> {
  try {
    return await request(`/devices/${id}/credential`);
  } catch (error: any) {
    if (error?.status === 404) return null;
    throw error;
  }
}

/** Stores/rotates the credential; secrets are encrypted by the API. */
export async function setDeviceCredential(id: string, data: {
  api_token?: string;
  api_username?: string;
  api_vdom?: string;
  ssh_key?: string;
  verify_tls?: boolean;
}): Promise<DeviceCredentialMetadata> {
  return await request(`/devices/${id}/credential`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function testDeviceConnection(id: string): Promise<{ success: boolean; message: string }> {
  const response = await request(`/devices/${id}/test-connection`, { method: 'POST' });
  return {
    success: Boolean(response?.ok ?? response?.success ?? false),
    message: formatApiError(response?.message, 'Cihaz bağlantısı test edildi.'),
  };
}

export async function refreshDeviceInfo(id: string): Promise<any> {
  // Device discovery is the canonical adapter operation. The old
  // /refresh-info alias never existed in the backend and caused a 404 from
  // the Devices page.
  return await request(`/devices/${id}/discover`, { method: 'POST' });
}

export async function syncActiveSessions(id: string): Promise<any> {
  // Query the firewall directly; reconciliation of individual sessions uses
  // the session-level sync endpoint and is intentionally not faked here.
  return await request(`/sessions/active-on-device/${id}`);
}

/**
 * Sessions CRUD
 */
export async function getSessions(): Promise<any[]> {
  try {
    return asList(await request('/sessions'));
  } catch (err) {
    throw err;
  }
}

export async function getSessionCorrelation(id: string): Promise<any> {
  return await request(`/sessions/${id}/correlation`);
}

export async function closeSession(id: string, reason?: string): Promise<void> {
  await request(`/sessions/${id}/close`, {
    method: 'POST',
    body: JSON.stringify(reason ? { reason } : {}),
  });
}

export async function retryAuthorization(id: string): Promise<any> {
  return await request(`/sessions/${id}/retry-authorization`, { method: 'POST' });
}

export async function syncSessionWithDevice(id: string): Promise<any> {
  return await request(`/sessions/${id}/sync-device`, { method: 'POST' });
}

/**
 * 5651 Logs & Cryptographic Archive API
 */
export async function getLogArchives(recordType?: string): Promise<any[]> {
  try {
    const qs = recordType ? `?record_type=${encodeURIComponent(recordType)}` : '';
    return asList(await request(`/logs-5651${qs}`));
  } catch (err) {
    throw err;
  }
}

export async function buildLogArchive(data: any): Promise<any> {
  return request('/logs-5651/build', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function verifyLogChain(recordType = 'session_archive'): Promise<any> {
  return await request(`/logs-5651/verify?record_type=${encodeURIComponent(recordType)}`);
}

export async function verifySingleArchive(recordId: string): Promise<any> {
  return await request(`/logs-5651/${recordId}/verify`);
}

export async function downloadArchivePdf(recordId: string): Promise<Blob> {
  const response = await requestBlob(`/logs-5651/${recordId}/download`);
  return await response.blob();
}

export async function downloadArchiveRaw(recordId: string): Promise<Blob> {
  const response = await requestBlob(`/logs-5651/${recordId}/download-raw`);
  return await response.blob();
}

export async function downloadArchiveZip(recordId: string): Promise<Blob> {
  const response = await requestBlob(`/logs-5651/${recordId}/download-zip`);
  return await response.blob();
}

export async function exportCourtEvidence(sessionId: string, customerId?: string): Promise<any> {
  const qs = customerId ? `?customer_id=${encodeURIComponent(customerId)}` : '';
  return await request(`/logs-5651/evidence/export/${sessionId}${qs}`, { method: 'POST' });
}

/**
 * Licenses CRUD
 */
export async function getLicenses(): Promise<any[]> {
  try {
    return asList(await request('/licenses'));
  } catch (err) {
    throw err;
  }
}

export async function addLicense(data: any): Promise<any> {
  return request('/licenses', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function toggleLicenseActive(id: string): Promise<any> {
  return request(`/licenses/${id}/toggle`, { method: 'POST' });
}

/**
 * Portal Templates (admin)
 */
export interface PortalTemplateTheme {
  primary_color?: string | null;
  secondary_color?: string | null;
  bg_color?: string | null;
  text_color?: string | null;
  font_family?: string | null;
  logo_style?: string | null;
  button_style?: string | null;
  layout?: string | null;
  bg_image_url?: string | null;
  logo_url?: string | null;
  title?: string | null;
  subtitle?: string | null;
  footer?: string | null;
  terms_text?: string | null;
  support_text?: string | null;
  internet_policy_text?: string | null;
  internet_policy_url?: string | null;
  kvkk_text?: string | null;
  kvkk_url?: string | null;
  [key: string]: any;
}

export interface PortalTemplateRecord {
  id: string;
  customer_id: string;
  location_id?: string | null;
  name: string;
  method: string;
  is_default: boolean;
  theme: PortalTemplateTheme;
  fields: any[];
  success_message?: string | null;
  terms_url?: string | null;
  meta: Record<string, any>;
  is_active: boolean;
  revision?: number;
  revision_action?: string | null;
  revision_updated_at?: string | null;
  revision_updated_by?: string | null;
  created_at: string;
}

export interface PortalTemplateUpdatePayload {
  name?: string;
  method?: string;
  theme?: PortalTemplateTheme;
  fields?: any[];
  success_message?: string | null;
  terms_url?: string | null;
  meta?: Record<string, any>;
  is_default?: boolean;
}

export interface PortalTemplateRevisionRecord {
  revision: number;
  action: string;
  saved_at: string;
  saved_by?: string | null;
  is_active: boolean;
  name: string;
  method: string;
  is_default: boolean;
  theme: PortalTemplateTheme;
  fields: any[];
  success_message?: string | null;
  terms_url?: string | null;
  meta: Record<string, any>;
}

export interface PortalTemplateHistoryResponse {
  template_id: string;
  current_revision: number;
  history_count: number;
  current: PortalTemplateRevisionRecord;
  history: PortalTemplateRevisionRecord[];
}

export async function getPortalTemplates(): Promise<PortalTemplateRecord[]> {
  try {
    return asList<PortalTemplateRecord>(await request('/portal', { method: 'GET' }));
  } catch {
    return [];
  }
}

export async function getPortalTemplate(id: string): Promise<PortalTemplateRecord> {
  return request(`/portal/${id}`, { method: 'GET' });
}

export async function createPortalTemplate(data: {
  customer_id: string;
  location_id?: string | null;
  name: string;
  method?: string;
  theme?: PortalTemplateTheme;
  fields?: any[];
  is_default?: boolean;
  meta?: Record<string, any>;
}): Promise<PortalTemplateRecord> {
  return request('/portal', {
    method: 'POST',
    body: JSON.stringify({
      name: data.name,
      customer_id: data.customer_id,
      location_id: data.location_id ?? null,
      method: data.method || 'sms',
      theme: data.theme || {},
      fields: data.fields || [],
      is_default: data.is_default ?? true,
      meta: data.meta || {},
    }),
  });
}

export async function updatePortalTemplate(id: string, data: PortalTemplateUpdatePayload): Promise<PortalTemplateRecord> {
  return request(`/portal/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function getPortalTemplateHistory(id: string): Promise<PortalTemplateHistoryResponse> {
  return request(`/portal/${id}/history`, { method: 'GET' });
}

export async function restorePortalTemplateRevision(id: string, revision: number): Promise<PortalTemplateRecord> {
  return request(`/portal/${id}/history/${revision}/restore`, { method: 'POST' });
}

export async function getPredefinedTemplates(): Promise<any> {
  try {
    return await request('/portal/templates/predefined', { method: 'GET' });
  } catch {
    return { templates: [], categories: [] };
  }
}

export async function getTemplatePreview(templateId: string, method?: string, lang?: string): Promise<string> {
  const params = new URLSearchParams();
  if (method) params.set('method', method);
  if (lang) params.set('lang', lang);
  const qs = params.toString();
  try {
    const response = await fetch(`${API_BASE}/api/v1/portal/templates/preview/${templateId}${qs ? '?' + qs : ''}`, {
      headers: { 'Accept': 'text/html' },
    });
    if (!response.ok) throw new Error('Preview fetch failed');
    return await response.text();
  } catch {
    return '<html><body><p>Preview unavailable</p></body></html>';
  }
}

export async function applyTemplate(portalId: string, templateId: string): Promise<any> {
  return await request(`/portal/${portalId}/apply-template/${templateId}`, { method: 'POST' });
}

export async function getPortalI18n(lang: string): Promise<any> {
  try {
    const url = `${API_BASE}/portal/public/i18n?lang=${encodeURIComponent(lang)}`;
    const res = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('i18n fetch failed');
    return await res.json();
  } catch {
    return { lang, translations: {}, available_languages: { tr: 'Türkçe', en: 'English' } };
  }
}

/**
 * Public marketing content
 */
export interface PublicAsset {
  id: string;
  section: string;
  slug: string;
  version: string;
  title: string;
  category?: string | null;
  summary?: string | null;
  body: string;
  asset_url?: string | null;
  checksum?: string | null;
  file_size_kb?: number | null;
  is_current: boolean;
  sort_order: number;
  workflow_status?: string | null;
  meta?: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface PublicContentAssetPayload {
  section: 'release_notes' | 'downloads' | 'docs' | 'kb' | 'partner';
  slug: string;
  version: string;
  title: string;
  category?: string | null;
  summary?: string | null;
  body: string;
  asset_url?: string | null;
  checksum?: string | null;
  file_size_kb?: number | null;
  is_current?: boolean;
  sort_order?: number;
  workflow_status?: string | null;
  meta?: Record<string, any>;
}

export interface PublicMarketplaceSnapshot {
  brand: {
    name: string;
    tagline: string;
    summary: string;
    support_email: string;
    sales_email: string;
    portal_url: string;
    version: string;
  };
  stats: {
    release_count: number;
    download_count: number;
    doc_count: number;
    kb_count: number;
    partner_count: number;
    latest_release_version?: string | null;
    latest_download_version?: string | null;
  };
  highlights: string[];
  featured_release?: PublicAsset | null;
  sections: Record<string, PublicAsset[]>;
}

export interface PublicInquiryPayload {
  inquiry_type: 'partner' | 'trial' | 'contact';
  source_tab?: string | null;
  name: string;
  email: string;
  phone?: string | null;
  company: string;
  role?: string | null;
  message: string;
  meta?: Record<string, any>;
}

export interface PublicInquiryRecord {
  id: string;
  reference_code: string;
  inquiry_type: 'partner' | 'trial' | 'contact' | string;
  source_tab?: string | null;
  status: string;
  name: string;
  email: string;
  phone?: string | null;
  company: string;
  role?: string | null;
  message: string;
  meta?: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface PublicTrialProvisionResult {
  inquiry_id: string;
  reference_code: string;
  inquiry_status: string;
  lifecycle_action?: string;
  renewal_count?: number;
  renewed_at?: string | null;
  previous_license_expires_at?: string | null;
  cleaned_at?: string | null;
  cleanup_reason?: string | null;
  tenant_id: string;
  tenant_slug: string;
  tenant_name: string;
  tenant_is_demo: boolean;
  customer_id: string;
  customer_name: string;
  location_id: string;
  location_name: string;
  device_id: string;
  device_name: string;
  portal_template_id: string;
  portal_template_name: string;
  portal_method: string;
  license_id: string;
  license_plan: string;
  license_is_trial: boolean;
  license_expires_at?: string | null;
  voucher_batch_id: string;
  voucher_prefix: string;
  voucher_code?: string | null;
  provisioned_at: string;
  message: string;
}

export async function getPublicMarketplaceSnapshot(): Promise<PublicMarketplaceSnapshot> {
  return await request('/public-content/marketplace');
}

export async function getPublicReleaseHistory(slug: string, includeDrafts = false): Promise<PublicAsset[]> {
  const query = new URLSearchParams();
  if (includeDrafts) query.set('include_drafts', 'true');
  const qs = query.toString();
  return asList<PublicAsset>(await request(`/public-content/releases/${slug}/history${qs ? `?${qs}` : ''}`));
}

export async function submitPublicInquiry(data: PublicInquiryPayload): Promise<any> {
  return await request('/public-content/inquiries', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function getPublicInquiries(params?: {
  inquiry_type?: string;
  status?: string;
  limit?: number;
  offset?: number;
}): Promise<PublicInquiryRecord[]> {
  const query = new URLSearchParams();
  if (params?.inquiry_type) query.set('inquiry_type', params.inquiry_type);
  if (params?.status) query.set('status', params.status);
  if (typeof params?.limit === 'number') query.set('limit', String(params.limit));
  if (typeof params?.offset === 'number') query.set('offset', String(params.offset));
  const qs = query.toString();
  return asList<PublicInquiryRecord>(await request(`/public-content/inquiries${qs ? `?${qs}` : ''}`));
}

export async function updatePublicInquiryStatus(id: string, status: string): Promise<PublicInquiryRecord> {
  return request(`/public-content/inquiries/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
}

export async function provisionTrialInquiry(id: string): Promise<PublicTrialProvisionResult> {
  return request(`/public-content/inquiries/${id}/provision-trial`, {
    method: 'POST',
  });
}

export async function renewTrialInquiry(id: string, extraDays = 14): Promise<PublicTrialProvisionResult> {
  const query = new URLSearchParams();
  query.set('extra_days', String(extraDays));
  return request(`/public-content/inquiries/${id}/renew-trial?${query.toString()}`, {
    method: 'POST',
  });
}

export async function getPublicContentAssets(params?: {
  section?: string;
  include_inactive?: boolean;
}): Promise<PublicAsset[]> {
  const query = new URLSearchParams();
  if (params?.section) query.set('section', params.section);
  if (typeof params?.include_inactive === 'boolean') query.set('include_inactive', String(params.include_inactive));
  const qs = query.toString();
  return asList<PublicAsset>(await request(`/public-content/assets${qs ? `?${qs}` : ''}`));
}

export async function searchPublicContentAssets(params?: {
  q?: string;
  section?: string;
  include_inactive?: boolean;
  kb_type?: string;
  workflow_status?: string;
  limit?: number;
}): Promise<PublicAsset[]> {
  const query = new URLSearchParams();
  if (params?.q) query.set('q', params.q);
  if (params?.section) query.set('section', params.section);
  if (typeof params?.include_inactive === 'boolean') query.set('include_inactive', String(params.include_inactive));
  if (params?.kb_type) query.set('kb_type', params.kb_type);
  if (params?.workflow_status) query.set('workflow_status', params.workflow_status);
  if (typeof params?.limit === 'number') query.set('limit', String(params.limit));
  const qs = query.toString();
  return asList<PublicAsset>(await request(`/public-content/assets/search${qs ? `?${qs}` : ''}`));
}

export async function getPublicContentAssetSuggestions(
  id: string,
  params?: { include_inactive?: boolean; limit?: number },
): Promise<PublicAsset[]> {
  const query = new URLSearchParams();
  if (typeof params?.include_inactive === 'boolean') query.set('include_inactive', String(params.include_inactive));
  if (typeof params?.limit === 'number') query.set('limit', String(params.limit));
  const qs = query.toString();
  return asList<PublicAsset>(await request(`/public-content/assets/${id}/suggestions${qs ? `?${qs}` : ''}`));
}

export async function createPublicContentAsset(data: PublicContentAssetPayload): Promise<PublicAsset> {
  return request('/public-content/assets', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function updatePublicContentAsset(id: string, data: PublicContentAssetPayload): Promise<PublicAsset> {
  return request(`/public-content/assets/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function archivePublicContentAsset(id: string): Promise<PublicAsset> {
  return request(`/public-content/assets/${id}/archive`, {
    method: 'PATCH',
  });
}

/**
 * System / Health
 */
export async function getSystemHealth(): Promise<any> {
  return request('/system/health');
}

// Platform licensing and one-click host update bridge. The backend never
// exposes license private material; these calls return only verified metadata.
export async function getPlatformLicense(): Promise<any> {
  const status = await getPlatformLicenseStatus();
  const license = status?.license;
  return license
    ? { ...license, status: status.license_status || license.status, installation_id: license.installation_id || status.installation_id }
    : { status: status?.license_status || 'NOT_INSTALLED', installation_id: status?.installation_id, enabled_modules: [] };
}

export async function getPlatformLicenseStatus(): Promise<any> {
  try {
    return await request('/licensing/status');
  } catch (error: any) {
    // Older installations keep the legacy pair while the canonical router is
    // introduced. Retry only for a missing route, never for auth/licensing
    // failures returned by the canonical endpoint.
    if (error?.status && error.status !== 404 && error.status !== 405) throw error;
    const [license, usage] = await Promise.all([
      request('/system/license'),
      request('/system/license/usage'),
    ]);
    return {
      product_code: 'hotspot',
      installation_id: license?.installation_id,
      license_status: license?.status === 'NOT_ACTIVATED' ? 'NOT_INSTALLED' : (license?.status || 'INVALID_SIGNATURE'),
      license: license?.status === 'NOT_ACTIVATED' ? null : license,
      usage,
    };
  }
}

export async function activatePlatformLicense(licenseEnvelope: string): Promise<any> {
  return request('/licensing/install', {
    method: 'POST',
    body: JSON.stringify({ license_envelope: licenseEnvelope }),
  });
}

export async function uploadPlatformLicense(file: File): Promise<any> {
  const form = new FormData();
  form.append('file', file);
  return request('/licensing/install/file', { method: 'POST', body: form });
}

export async function validatePlatformLicense(): Promise<any> {
  return request('/licensing/validate', { method: 'POST' });
}

export async function acknowledgePlatformLicense(fingerprint: string, verifierStatus: string): Promise<any> {
  return request('/licensing/ack', {
    method: 'POST',
    body: JSON.stringify({ fingerprint, verifier_status: verifierStatus }),
  });
}

export async function removePlatformLicense(): Promise<void> {
  await request('/licensing', { method: 'DELETE' });
}

export async function getPlatformLicenseUsage(): Promise<any> {
  const status = await getPlatformLicenseStatus();
  return status?.usage || {};
}

export async function getPlatformVersion(): Promise<any> {
  return request('/system/version');
}

export async function getUpdateCapability(): Promise<any> {
  return request('/system/updates/capability');
}

export async function checkPlatformUpdates(): Promise<any> {
  return request('/system/updates/check', { method: 'POST' });
}

export async function runUpdatePreflight(): Promise<any> {
  return request('/system/updates/preflight', { method: 'POST' });
}

export async function startPlatformUpdate(targetVersion: string): Promise<any> {
  const idempotencyKey = typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : `upgrade-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return request('/system/updates/start', {
    method: 'POST',
    headers: { 'Idempotency-Key': idempotencyKey },
    body: JSON.stringify({ target_version: targetVersion }),
  });
}

export async function getUpdateSession(): Promise<any> {
  return request('/system/updates/session');
}

export async function getUpdateHistory(): Promise<any> {
  return request('/system/updates/history');
}

export async function rollbackPlatformUpdate(jobId: string): Promise<any> {
  return request(`/system/updates/jobs/${jobId}/rollback`, { method: 'POST' });
}

export interface SystemUpdateRelease {
  id: string;
  section: string;
  slug: string;
  version: string;
  title: string;
  category?: string | null;
  summary?: string | null;
  body: string;
  asset_url?: string | null;
  checksum?: string | null;
  file_size_kb?: number | null;
  is_current: boolean;
  sort_order: number;
  meta?: Record<string, any>;
  created_at: string;
  updated_at: string;
  release_type: 'feature' | 'fix' | 'security' | 'hotfix' | 'maintenance';
  channel: 'stable' | 'beta' | 'hotfix';
  status: 'draft' | 'published' | 'archived';
  minimum_version?: string | null;
  is_mandatory: boolean;
  upgrade_steps: string[];
  artifact_name?: string | null;
  artifact_ref?: string | null;
  artifact_generated_at?: string | null;
  artifact_size_bytes?: number | null;
  distribution_status?: string | null;
  distribution_manifest_ref?: string | null;
  distribution_manifest_generated_at?: string | null;
  distribution_activation_ref?: string | null;
  distribution_activated_at?: string | null;
  distribution_activated_by?: string | null;
  distribution_targets?: string[];
  published_by?: string | null;
  published_at?: string | null;
  archived_by?: string | null;
  archived_at?: string | null;
}

export interface SystemUpdateSnapshot {
  current_version: string;
  latest_release_version?: string | null;
  latest_published_version?: string | null;
  upgrade_available: boolean;
  release_count: number;
  draft_count: number;
  archived_count: number;
  distribution_status_counts?: Record<string, number>;
  channel_counts?: Record<string, number>;
  latest_distribution_manifest_at?: string | null;
  latest_distribution_activation_at?: string | null;
  highlights: string[];
  featured_release?: SystemUpdateRelease | null;
  releases: SystemUpdateRelease[];
  stored_artifacts: SystemUpdateRelease[];
}

export interface SystemUpdatePayload {
  slug?: string | null;
  version: string;
  title: string;
  summary?: string | null;
  body: string;
  release_type: SystemUpdateRelease['release_type'];
  channel: SystemUpdateRelease['channel'];
  minimum_version?: string | null;
  is_mandatory?: boolean;
  upgrade_steps?: string[];
  artifact_name?: string | null;
  artifact_url?: string | null;
  checksum?: string | null;
  file_size_kb?: number | null;
  sort_order?: number;
  meta?: Record<string, any>;
}

export async function getSystemUpdates(): Promise<SystemUpdateSnapshot> {
  return request('/system/updates');
}

export async function createSystemUpdate(data: SystemUpdatePayload): Promise<SystemUpdateRelease> {
  return request('/system/updates', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function updateSystemUpdate(id: string, data: SystemUpdatePayload): Promise<SystemUpdateRelease> {
  return request(`/system/updates/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function publishSystemUpdate(id: string): Promise<SystemUpdateRelease> {
  return request(`/system/updates/${id}/publish`, {
    method: 'POST',
  });
}

export async function activateSystemUpdate(id: string): Promise<SystemUpdateRelease> {
  return request(`/system/updates/${id}/activate`, {
    method: 'POST',
  });
}

export async function archiveSystemUpdate(id: string): Promise<SystemUpdateRelease> {
  return request(`/system/updates/${id}/archive`, {
    method: 'POST',
  });
}

export async function downloadSystemUpdateBundle(id: string): Promise<{ blob: Blob; filename: string }> {
  const response = await requestBlob(`/system/updates/${id}/bundle`);
  const disposition = response.headers.get('content-disposition') || '';
  const match = disposition.match(/filename="([^"]+)"/i);
  const filename = match?.[1] || `hotspot-update-${id}.zip`;
  return {
    blob: await response.blob(),
    filename,
  };
}

export async function downloadSystemUpdateManifest(id: string): Promise<{ blob: Blob; filename: string }> {
  const response = await requestBlob(`/system/updates/${id}/manifest`);
  const disposition = response.headers.get('content-disposition') || '';
  const match = disposition.match(/filename="([^"]+)"/i);
  const filename = match?.[1] || `hotspot-update-${id}-distribution.json`;
  return {
    blob: await response.blob(),
    filename,
  };
}

/**
 * Backups
 */
export async function listBackups(): Promise<any[]> {
  return asList(await request('/system/backups'));
}

export async function createBackup(type: string = 'full'): Promise<any> {
  return request(`/system/backups?type=${type}`, { method: 'POST' });
}

export async function restoreBackup(id: string): Promise<any> {
  return request(`/system/backups/${id}/restore`, { method: 'POST' });
}

export async function deleteBackup(id: string): Promise<void> {
  await request(`/system/backups/${id}`, { method: 'DELETE' });
}

/**
 * White-Label Branding
 */
export async function getWhitelabelConfig(tenantId?: string, customerId?: string): Promise<any> {
  const params = new URLSearchParams();
  if (tenantId) params.set('tenant_id', tenantId);
  if (customerId) params.set('customer_id', customerId);
  const qs = params.toString();
  return request(`/system/whitelabel${qs ? '?' + qs : ''}`);
}

export async function updateWhitelabelConfig(data: any): Promise<any> {
  return request('/system/whitelabel', {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function uploadBrandAsset(file: File, assetType: string = 'logo', scopeType: string = 'platform', scopeId?: string): Promise<any> {
  const params = new URLSearchParams({ asset_type: assetType, scope_type: scopeType });
  if (scopeId) params.set('scope_id', scopeId);
  const formData = new FormData();
  formData.append('file', file);
  return request(`/system/whitelabel/upload?${params.toString()}`, {
    method: 'POST',
    body: formData,
  });
}

/**
 * Email / SMTP Config
 */
export async function getEmailConfig(customerId?: string): Promise<any> {
  const qs = customerId ? `?customer_id=${customerId}` : '';
  return request(`/system/email/config${qs}`);
}

export async function updateEmailConfig(data: any): Promise<any> {
  return request('/system/email/config', {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function testEmailConfig(configId: string): Promise<any> {
  return request(`/system/email/test?config_id=${configId}`, { method: 'POST' });
}

/**
 * Dashboard Stats
 */
export async function getRealtimeStats(customerId?: string): Promise<any> {
  const qs = customerId ? `?customer_id=${customerId}` : '';
  return request(`/system/dashboard/realtime${qs}`);
}

export async function getTrendData(days: number = 30, customerId?: string): Promise<any> {
  const params = new URLSearchParams({ days: String(days) });
  if (customerId) params.set('customer_id', customerId);
  return request(`/system/dashboard/trends?${params.toString()}`);
}

export async function getOsBrowserStats(periodDays: number = 7, customerId?: string): Promise<any> {
  const params = new URLSearchParams({ period_days: String(periodDays) });
  if (customerId) params.set('customer_id', customerId);
  return request(`/system/dashboard/os-browser?${params.toString()}`);
}

export async function getAuthMethodDistribution(periodDays: number = 30, customerId?: string): Promise<any> {
  const params = new URLSearchParams({ period_days: String(periodDays) });
  if (customerId) params.set('customer_id', customerId);
  return request(`/system/dashboard/auth-methods?${params.toString()}`);
}

export async function getHourlyHeatmap(days: number = 7, customerId?: string): Promise<any> {
  const params = new URLSearchParams({ days: String(days) });
  if (customerId) params.set('customer_id', customerId);
  return request(`/system/dashboard/heatmap?${params.toString()}`);
}

export async function getTopLocations(limit: number = 10, customerId?: string): Promise<any> {
  const params = new URLSearchParams({ limit: String(limit) });
  if (customerId) params.set('customer_id', customerId);
  return request(`/system/dashboard/top-locations?${params.toString()}`);
}

export async function getTopUsers(limit: number = 10, customerId?: string): Promise<any> {
  const params = new URLSearchParams({ limit: String(limit) });
  if (customerId) params.set('customer_id', customerId);
  return request(`/system/dashboard/top-users?${params.toString()}`);
}

/**
 * Single-installation dashboard snapshot.  The backend resolves the
 * installation customer automatically, so callers must not manufacture a
 * customer_id query parameter for a super-admin session.
 */
export async function getDashboardOverview(days: number = 30, customerId?: string): Promise<any> {
  const params = new URLSearchParams({ days: String(days) });
  if (isUuid(customerId)) params.set('customer_id', customerId!);
  return request(`/system/dashboard/overview?${params.toString()}`);
}

function buildFirewallLogParams(filters?: any, includePaging: boolean = true): URLSearchParams {
  const params = new URLSearchParams();
  if (filters?.vendor) params.set('vendor', filters.vendor);
  if (filters?.severity) params.set('severity', filters.severity);
  if (filters?.search) params.set('search', filters.search);
  if (filters?.log_type) params.set('log_type', filters.log_type);
  if (filters?.action) params.set('action', filters.action);
  if (filters?.user) params.set('user', filters.user);
  if (filters?.quick_filter) params.set('quick_filter', filters.quick_filter);
  if (filters?.from) params.set('from', filters.from);
  if (filters?.to) params.set('to', filters.to);
  if (filters?.correlation_window_minutes) {
    params.set('correlation_window_minutes', String(filters.correlation_window_minutes));
  }
  if (includePaging) {
    if (filters?.page) params.set('page', String(filters.page));
    if (filters?.page_size) params.set('page_size', String(filters.page_size));
  }
  return params;
}

/**
 * Firewall Logs & Analyzer
 */
export async function getFirewallLogs(filters?: any): Promise<any[]> {
    const qs = buildFirewallLogParams(filters).toString();
    return asList(await request(`/firewall-logs${qs ? '?' + qs : ''}`));
}

export async function getVpnSessions(): Promise<{
  active_users: any[];
  history: any[];
  stats: { online_count: number; offline_count: number; total_bandwidth_mb: number };
}> {
  return request('/firewall-logs/vpn/sessions');
}

export async function getFirewallAnalyticsSummary(): Promise<{
  total_logs_24h: number;
  denied_events_24h: number;
  bytes_in: number;
  bytes_out: number;
  bytes_in_formatted: string;
  bytes_out_formatted: string;
  security_score: number;
  top_denied_ips: Array<{ ip: string; country: string; count: number }>;
  top_ports: Array<{ port: number; service: string; count: number }>;
  top_apps: Array<{ app: string; hits: number; bytes: number; bytes_formatted: string }>;
  top_countries: Array<{ country: string; hits: number; bytes: number; bytes_formatted: string }>;
  top_sources: Array<{ src_ip: string; os: string; hits: number; bytes: number; bytes_formatted: string }>;
  top_policies: Array<{ policy: string; hits: number; bytes: number; bytes_formatted: string }>;
  log_types: Array<{ type: string; count: number }>;
  severities: Array<{ severity: string; count: number }>;
}> {
  return request('/firewall-logs/analytics/summary');
}

export async function exportFirewallLogs(filters?: any): Promise<{ blob: Blob; filename: string }> {
  const params = buildFirewallLogParams(filters, false);
  const response = await requestBlob(`/firewall-logs/export?${params.toString()}`);
  const disposition = response.headers.get('content-disposition') || '';
  const match = disposition.match(/filename="([^"]+)"/i);
  const filename = match?.[1] || 'firewall-logs-export.zip';
  return {
    blob: await response.blob(),
    filename,
  };
}

export interface SearchView {
  id: string;
  created_by_user_id: string;
  surface: string;
  title: string;
  description?: string | null;
  filters: Record<string, any>;
  is_shared: boolean;
  created_at: string;
  updated_at: string;
}

export async function getSearchViews(surface: string = 'firewall_logs'): Promise<SearchView[]> {
  const qs = new URLSearchParams({ surface });
  return asList<SearchView>(await request(`/search/views?${qs.toString()}`));
}

export async function createSearchView(data: {
  surface?: string;
  title: string;
  description?: string | null;
  filters: Record<string, any>;
  is_shared?: boolean;
}): Promise<SearchView> {
  return await request('/search/views', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateSearchView(id: string, data: Partial<{
  surface: string;
  title: string;
  description: string | null;
  filters: Record<string, any>;
  is_shared: boolean;
}>): Promise<SearchView> {
  return await request(`/search/views/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteSearchView(id: string): Promise<void> {
  await request(`/search/views/${id}`, { method: 'DELETE' });
}

/**
 * Syslog Triggers
 */
export async function getSyslogTriggers(): Promise<any[]> {
  return asList(await request('/syslog/triggers'));
}

export async function getSyslogTriggerStats(): Promise<any> {
  return await request('/syslog/triggers/stats');
}

export async function createTrigger(data: any): Promise<any> {
  return await request('/syslog/triggers', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateTrigger(id: string, data: any): Promise<any> {
  return await request(`/syslog/triggers/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteTrigger(id: string): Promise<void> {
  await request(`/syslog/triggers/${id}`, { method: 'DELETE' });
}

export async function getTriggerEvents(triggerId?: string): Promise<any[]> {
    const qs = triggerId ? `?trigger_id=${triggerId}` : '';
    return asList(await request(`/syslog/triggers/events${qs}`));
}

export async function acknowledgeEvent(eventId: string): Promise<void> {
  await request(`/syslog/triggers/events/${eventId}/acknowledge`, { method: 'POST' });
}

/**
 * Report Scheduler
 */
export async function getReportJobs(): Promise<any[]> {
  return asList(await request('/reports/jobs'));
}

export async function createReportJob(data: any): Promise<any> {
  return await request('/reports/jobs', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateReportJob(id: string, data: any): Promise<any> {
  return await request(`/reports/jobs/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteReportJob(id: string): Promise<void> {
  await request(`/reports/jobs/${id}`, { method: 'DELETE' });
}

export async function runReportNow(id: string): Promise<any> {
  return await request(`/reports/jobs/${id}/run-now`, { method: 'POST' });
}

export async function getReportArchives(): Promise<any[]> {
  return asList(await request('/reports/archives'));
}

export async function downloadArchive(id: string): Promise<void> {
  // The backend returns a file stream, not JSON. Using request() here made
  // every download fail while trying to parse PDF/CSV bytes as JSON. Keep the
  // auth header and perform the same safe object-URL download as other export
  // actions.
  const response = await requestBlob(`/reports/archives/${id}/download`);
  const blob = await response.blob();
  const disposition = response.headers.get('content-disposition') || '';
  const match = disposition.match(/filename=\"([^\"]+)\"/i);
  const filename = match?.[1] || `report-${id}`;
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}

export async function getReportTemplates(): Promise<any[]> {
  return asList(await request('/reports/templates'));
}

export async function getReportSummary(dateFrom?: string, dateTo?: string): Promise<any> {
  const params = new URLSearchParams();
  if (dateFrom) params.set('date_from', dateFrom);
  if (dateTo) params.set('date_to', dateTo);
  const qs = params.toString();
  return await request(`/reports${qs ? '?' + qs : ''}`);
}

export function getSessionsExportUrl(dateFrom?: string, dateTo?: string, format: string = 'csv'): string {
  const params = new URLSearchParams({ format });
  if (dateFrom) params.set('date_from', dateFrom);
  if (dateTo) params.set('date_to', dateTo);
  return `${API_BASE}/api/v1/reports/sessions/export?${params.toString()}`;
}

export function getDifferentiatorReportExportUrl(reportType: string, dateFrom?: string, dateTo?: string, format: string = 'csv'): string {
  const params = new URLSearchParams({ report_type: reportType, format });
  if (dateFrom) params.set('date_from', dateFrom);
  if (dateTo) params.set('date_to', dateTo);
  return `${API_BASE}/api/v1/reports/differentiator/export?${params.toString()}`;
}

export async function downloadReportFile(path: string, filename: string): Promise<void> {
  const response = await requestBlob(path);
  const blob = await response.blob();
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  // Give the browser a tick to start the download before releasing the blob.
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}

/**
 * Download an operator preset with the in-memory access token attached.
 * Opening a URL in a new tab bypasses the Authorization header, so quick
 * reports deliberately use requestBlob and an object URL instead.
 */
export async function downloadQuickReport(
  reportType: string,
  options: { days?: number; dateFrom?: string; dateTo?: string; format?: 'pdf' | 'csv' } = {},
): Promise<void> {
  const params = new URLSearchParams({
    report_type: reportType,
    format: options.format || 'pdf',
    days: String(options.days || 30),
  });
  if (options.dateFrom) params.set('date_from', options.dateFrom);
  if (options.dateTo) params.set('date_to', options.dateTo);
  await downloadReportFile(`/reports/quick/export?${params.toString()}`, `${reportType.replace(/_/g, '-')}.${options.format || 'pdf'}`);
}


/**
 * PMS Config
 */
export async function getPmsConfig(): Promise<any> {
  return await request('/pms/config');
}

export async function updatePmsConfig(data: any): Promise<any> {
  return await request('/pms/config', { method: 'PUT', body: JSON.stringify(data) });
}

export async function testPmsConnection(vendor: string, roomNumber = '101', surname = 'DEMO'): Promise<any> {
  const params = new URLSearchParams({ vendor, room_number: roomNumber, surname });
  return await request(`/pms/test-connection?${params.toString()}`, { method: 'POST' });
}

export async function getCustomSources(): Promise<any[]> {
  return asList(await request('/pms/custom-sources'));
}

export async function createCustomSource(data: any): Promise<any> {
  return await request('/pms/custom-sources', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateCustomSource(id: string, data: any): Promise<any> {
  return await request(`/pms/custom-sources/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteCustomSource(id: string): Promise<void> {
  await request(`/pms/custom-sources/${id}`, { method: 'DELETE' });
}

export async function testCustomSource(id: string): Promise<any> {
  const response = await request(`/pms/custom-sources/${id}/test`, { method: 'POST' });
  return {
    success: Boolean(response?.verified ?? response?.ok ?? response?.success ?? false),
    message: formatApiError(response?.message, 'Özel veri kaynağı bağlantısı başarılı.'),
  };
}

/**
 * Auth Methods (WhatsApp, LDAP, Meeting Codes, Local Users)
 */
export async function getAuthMethodsConfig(): Promise<any> {
  return await request('/auth-methods/config');
}

export async function getSmsAuthStatus(): Promise<any> {
  return await request('/auth-methods/sms');
}

export async function getSmsProviders(): Promise<any> {
  return await request('/auth-methods/sms/providers');
}

export async function getSmsAuthConfig(): Promise<any> {
  return await request('/auth-methods/sms/config');
}

export async function updateSmsAuthConfig(data: any): Promise<any> {
  return await request('/auth-methods/sms/config', { method: 'PUT', body: JSON.stringify(data) });
}

export async function testSmsAuth(phone: string, message?: string): Promise<any> {
  return await request('/auth-methods/sms/test', {
    method: 'POST',
    body: JSON.stringify({ phone, message }),
  });
}

export async function updateWhatsAppConfig(data: any): Promise<any> {
  return await request('/auth-methods/whatsapp', { method: 'PUT', body: JSON.stringify(data) });
}

export async function testWhatsApp(phoneNumber: string): Promise<any> {
  return await request('/auth-methods/whatsapp/test', { method: 'POST', body: JSON.stringify({ phone_number: phoneNumber }) });
}

export async function updateLdapConfig(data: any): Promise<any> {
  return await request('/auth-methods/ldap', { method: 'PUT', body: JSON.stringify(data) });
}

export async function testLdapConnection(): Promise<any> {
  return await request('/auth-methods/ldap/test', { method: 'POST' });
}

export async function getMeetingCodes(): Promise<any[]> {
  return asList(await request('/auth-methods/meeting-codes'));
}

export async function createMeetingCode(data: any): Promise<any> {
  return await request('/auth-methods/meeting-codes', { method: 'POST', body: JSON.stringify(data) });
}

export async function deleteMeetingCode(id: string): Promise<void> {
  await request(`/auth-methods/meeting-codes/${id}`, { method: 'DELETE' });
}

export async function getLocalUsers(): Promise<any[]> {
  return asList(await request('/auth-methods/local-users'));
}

export async function createLocalUser(data: any): Promise<any> {
  return await request('/auth-methods/local-users', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateLocalUser(id: string, data: any): Promise<any> {
  return await request(`/auth-methods/local-users/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteLocalUser(id: string): Promise<void> {
  await request(`/auth-methods/local-users/${id}`, { method: 'DELETE' });
}

/**
 * MFA Settings
 */
export async function getMfaStatus(): Promise<any> {
  return await request('/mfa/status');
}

export async function setupTotp(): Promise<any> {
  return await request('/mfa/setup/totp', { method: 'POST' });
}

export async function verifyTotpSetup(code: string): Promise<any> {
  return await request('/mfa/verify/totp', { method: 'POST', body: JSON.stringify({ code }) });
}

export async function disableMfa(method: string = 'totp'): Promise<any> {
  return await request(`/mfa/${method}`, { method: 'DELETE' });
}

export async function getMfaConfig(): Promise<any> {
  return await request('/mfa/config');
}

export async function updateMfaConfig(data: any): Promise<any> {
  return await request('/mfa/config', { method: 'PUT', body: JSON.stringify(data) });
}

export async function regenerateBackupCodes(): Promise<string[]> {
  const result = await request('/mfa/regenerate-backup-codes', { method: 'POST' });
  return result.codes || [];
}

/**
 * FortiGate VPN MFA (RADIUS Access-Challenge) helpers.
 * The gateway remains the VPN endpoint; these calls only manage the
 * per-user second factor and generate the FreeRADIUS REST snippet.
 */
export async function getVpnMfaConfig(): Promise<any> {
  return await request('/mfa/vpn/config');
}

export async function updateVpnMfaConfig(data: any): Promise<any> {
  return await request('/mfa/vpn/config', { method: 'PUT', body: JSON.stringify(data) });
}

export async function getVpnMfaUsers(): Promise<any[]> {
  return asList(await request('/mfa/vpn/users'));
}

export async function createVpnMfaUser(data: any): Promise<any> {
  return await request('/mfa/vpn/users', { method: 'POST', body: JSON.stringify(data) });
}

export async function setupVpnMfaTotp(id: string): Promise<any> {
  return await request(`/mfa/vpn/users/${id}/totp-setup`, { method: 'POST' });
}

export async function deleteVpnMfaUser(id: string): Promise<void> {
  await request(`/mfa/vpn/users/${id}`, { method: 'DELETE' });
}

export async function generateVpnMfaRadiusConfig(): Promise<{ config: string; customer_id: string }> {
  return await request('/mfa/vpn/generate-config', { method: 'POST' });
}

export async function testVpnRadius(): Promise<any> {
  return await request('/mfa/vpn/test-radius', { method: 'POST' });
}

/**
 * Signing Config (TUBITAK KamuSM)
 */
export async function getSigningConfig(): Promise<any> {
  return await request('/logs-5651/sign/config');
}

export async function updateSigningConfig(data: any): Promise<any> {
  return await request('/logs-5651/sign/config', { method: 'PUT', body: JSON.stringify(data) });
}

export async function testSigningConnection(): Promise<any> {
  // The signing adapter performs its real health check on the next sign
  // operation; keep this button useful without calling a removed endpoint.
  const config = await getSigningConfig();
  return {
    success: Boolean(config?.is_configured),
    message: config?.is_configured ? 'İmza yapılandırması hazır.' : 'İmza yapılandırması henüz tamamlanmamış.',
  };
}

export async function signArchive(id: string): Promise<any> {
  return await request(`/logs-5651/${id}/sign`, { method: 'POST' });
}

export async function signAllArchives(): Promise<any> {
  return await request('/logs-5651/sign-all', { method: 'POST' });
}

export async function sealTodayLogs(customerId?: string): Promise<any> {
  const qs = customerId ? `?customer_id=${customerId}` : '';
  return await request(`/logs-5651/seal-today${qs}`, { method: 'POST' });
}

export async function verifyArchive(id: string): Promise<any> {
  return await request(`/logs-5651/${id}/verify`);
}

export async function getCertificates(): Promise<any[]> {
  // Certificates are represented by the masked signing configuration.  The
  // old standalone certificate registry was removed with the multi-tenant
  // licensing surface.
  return [];
}

export async function getArchiveVerificationResults(): Promise<any[]> {
  return [];
}

/**
 * Firewall Capabilities (Master Prompt §4.3)
 */
export async function getVendorCapabilities(): Promise<any[]> {
  return asList(await request('/devices/capabilities'));
}

export async function getDeviceCapabilities(deviceId: string): Promise<any> {
  try { return await request(`/devices/${deviceId}/capabilities`); }
  catch { return null; }
}

/**
 * Dashboard Extended Stats
 * All dashboard endpoints are mounted under /system/dashboard/ on the backend.
 */
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const isUuid = (value?: string | null): boolean => Boolean(value && UUID_PATTERN.test(value));

export async function getHourlyHeatmapData(customerId?: string, days?: number): Promise<any[]> {
  const params = new URLSearchParams();
  if (days) params.set('days', String(days));
  if (isUuid(customerId)) params.set('customer_id', customerId!);
  const qs = params.toString();
  return asList(await request(`/system/dashboard/hourly-heatmap${qs ? '?' + qs : ''}`));
}

export async function getAuthMethodDistData(customerId?: string, periodDays?: number): Promise<any[]> {
  const params = new URLSearchParams();
  if (periodDays) params.set('period_days', String(periodDays));
  if (isUuid(customerId)) params.set('customer_id', customerId!);
  const qs = params.toString();
  return asList(await request(`/system/dashboard/auth-method-dist${qs ? '?' + qs : ''}`));
}

export async function getDailyTrendData(customerId?: string, days?: number): Promise<any> {
  const params = new URLSearchParams();
  if (days) params.set('days', String(days));
  if (isUuid(customerId)) params.set('customer_id', customerId!);
  const qs = params.toString();
  return await request(`/system/dashboard/daily-trend${qs ? '?' + qs : ''}`);
}

export async function getOsBrowserDistData(customerId?: string, periodDays?: number): Promise<any> {
  const params = new URLSearchParams();
  if (periodDays) params.set('period_days', String(periodDays));
  if (isUuid(customerId)) params.set('customer_id', customerId!);
  const qs = params.toString();
  return await request(`/system/dashboard/os-browser-dist${qs ? '?' + qs : ''}`);
}

export async function getTopLocationsData(customerId?: string, limit?: number): Promise<any[]> {
  const params = new URLSearchParams();
  if (limit) params.set('limit', String(limit));
  if (isUuid(customerId)) params.set('customer_id', customerId!);
  const qs = params.toString();
  return asList(await request(`/system/dashboard/top-locations${qs ? '?' + qs : ''}`));
}

export async function getDashboardExtendedStats(customerId?: string): Promise<any> {
  const qs = isUuid(customerId) ? `?customer_id=${encodeURIComponent(customerId!)}` : '';
  return await request(`/system/dashboard/extended-stats${qs}`);
}

export async function getUserGroups(): Promise<any[]> {
  return asList(await request('/user-groups/groups'));
}

export async function getUserGroupPolicyPreview(customerId: string, locationId?: string | null): Promise<any> {
  const params = new URLSearchParams({ customer_id: customerId });
  if (locationId) params.set('location_id', locationId);
  return await request(`/user-groups/policy-preview?${params.toString()}`);
}

export async function createUserGroup(data: any): Promise<any> {
  return await request('/user-groups/groups', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateUserGroup(id: string, data: any): Promise<any> {
  return await request(`/user-groups/groups/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteUserGroup(id: string): Promise<void> {
  await request(`/user-groups/groups/${id}`, { method: 'DELETE' });
}

export async function getBanRules(): Promise<any[]> {
  return asList(await request('/ban/bans'));
}

export async function createBanRule(data: any): Promise<any> {
  return await request('/ban/bans', { method: 'POST', body: JSON.stringify(data) });
}

export async function deleteBanRule(id: string): Promise<void> {
  await request(`/ban/bans/${id}`, { method: 'DELETE' });
}

export async function getWhitelist(): Promise<any[]> {
  return asList(await request('/ban/whitelist'));
}

export async function createWhitelistEntry(data: any): Promise<any> {
  return await request('/ban/whitelist', { method: 'POST', body: JSON.stringify(data) });
}

export async function deleteWhitelistEntry(id: string): Promise<void> {
  await request(`/ban/whitelist/${id}`, { method: 'DELETE' });
}

// ---- Online Sessions ----
export async function getOnlineSessions(): Promise<any[]> {
  return asList(await request('/sessions/online'));
}

export async function getTrafficTrend(days: number = 30): Promise<any> {
  return await request(`/traffic/traffic/trend?days=${days}`);
}

export async function getTrafficDashboard(): Promise<any> {
  return await request('/traffic/traffic/dashboard');
}

export async function getAlarmEvents(): Promise<any[]> {
  return asList(await request('/alarm/events'));
}

export async function getAlarmStats(): Promise<any> {
  return await request('/alarm/stats');
}

export async function acknowledgeAlarm(eventId: string): Promise<void> {
  await request(`/alarm/events/${eventId}/acknowledge`, { method: 'POST' });
}

export async function getAlarmTrend(days: number = 7): Promise<any[]> {
  return asList(await request(`/alarm/trend?days=${days}`));
}

export async function getPendingSessions(): Promise<any[]> {
  return asList(await request('/sessions/pending'));
}

export async function approveSession(sessionId: string): Promise<any> {
  return await request(`/sessions/${sessionId}/approve`, { method: 'POST' });
}

export async function rejectSession(sessionId: string): Promise<any> {
  return await request(`/sessions/${sessionId}/reject`, { method: 'POST' });
}

// ── Site Bridge ──────────────────────────────────────────────────────────

export async function listBridgeAgents(): Promise<any[]> {
  return asList(await request('/site-bridge/agents'));
}

export async function registerBridgeAgent(data: { agent_id: string; name: string; version?: string }): Promise<any> {
  return await request('/site-bridge/agents/register', { method: 'POST', body: data });
}

export async function dispatchBridgeCommand(data: { agent_id: string; command_type: string; payload?: any }): Promise<any> {
  return await request('/site-bridge/commands', { method: 'POST', body: data });
}

export async function listBridgeCommands(agentId: string): Promise<any[]> {
  return asList(await request(`/site-bridge/commands/${agentId}`));
}
