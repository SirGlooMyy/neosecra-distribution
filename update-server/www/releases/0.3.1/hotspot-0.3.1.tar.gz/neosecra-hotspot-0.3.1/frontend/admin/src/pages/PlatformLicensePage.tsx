import React, { useEffect, useState } from 'react';
import {
  Award,
  CheckCircle2,
  RefreshCw,
  Upload,
  XCircle,
  Copy,
  Check,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Calendar,
  Layers,
  HardDrive,
  Users,
  Server,
  FileCode,
  FileText,
  AlertTriangle,
  Download,
  Info,
  Clock,
  Sparkles,
  Key,
} from 'lucide-react';
import {
  activatePlatformLicense,
  acknowledgePlatformLicense,
  getPlatformLicenseStatus,
  removePlatformLicense,
  uploadPlatformLicense,
  validatePlatformLicense,
} from '../lib/api';

const statusConfig: Record<string, { label: string; bg: string; text: string; border: string; icon: any }> = {
  ACTIVE: {
    label: 'Aktif & Doğrulandı',
    bg: 'bg-emerald-500/10 dark:bg-emerald-500/20',
    text: 'text-emerald-600 dark:text-emerald-400',
    border: 'border-emerald-500/30',
    icon: CheckCircle2,
  },
  TRIAL: {
    label: 'Deneme Sürümü (Trial)',
    bg: 'bg-blue-500/10 dark:bg-blue-500/20',
    text: 'text-blue-600 dark:text-blue-400',
    border: 'border-blue-500/30',
    icon: Sparkles,
  },
  EXPIRING_SOON: {
    label: 'Süresi Yakında Doluyor',
    bg: 'bg-amber-500/10 dark:bg-amber-500/20',
    text: 'text-amber-600 dark:text-amber-400',
    border: 'border-amber-500/30',
    icon: Clock,
  },
  GRACE_PERIOD: {
    label: 'Ek Süre (Grace Period)',
    bg: 'bg-orange-500/10 dark:bg-orange-500/20',
    text: 'text-orange-600 dark:text-orange-400',
    border: 'border-orange-500/30',
    icon: AlertTriangle,
  },
  EXPIRED: {
    label: 'Süresi Doldu',
    bg: 'bg-rose-500/10 dark:bg-rose-500/20',
    text: 'text-rose-600 dark:text-rose-400',
    border: 'border-rose-500/30',
    icon: XCircle,
  },
  INVALID: {
    label: 'Geçersiz Lisans İmzası',
    bg: 'bg-rose-500/10 dark:bg-rose-500/20',
    text: 'text-rose-600 dark:text-rose-400',
    border: 'border-rose-500/30',
    icon: ShieldAlert,
  },
  INVALID_SIGNATURE: {
    label: 'Geçersiz Lisans İmzası',
    bg: 'bg-rose-500/10 dark:bg-rose-500/20',
    text: 'text-rose-600 dark:text-rose-400',
    border: 'border-rose-500/30',
    icon: ShieldAlert,
  },
  INVALID_PRODUCT: {
    label: 'Geçersiz Ürün Lisansı',
    bg: 'bg-rose-500/10 dark:bg-rose-500/20',
    text: 'text-rose-600 dark:text-rose-400',
    border: 'border-rose-500/30',
    icon: ShieldAlert,
  },
  INSTALLATION_MISMATCH: {
    label: 'Kurulum Eşleşmiyor',
    bg: 'bg-rose-500/10 dark:bg-rose-500/20',
    text: 'text-rose-600 dark:text-rose-400',
    border: 'border-rose-500/30',
    icon: ShieldAlert,
  },
  REVOKED: {
    label: 'İptal Edildi',
    bg: 'bg-rose-500/10 dark:bg-rose-500/20',
    text: 'text-rose-600 dark:text-rose-400',
    border: 'border-rose-500/30',
    icon: ShieldAlert,
  },
  NOT_YET_VALID: {
    label: 'Henüz Geçerli Değil',
    bg: 'bg-slate-500/10 dark:bg-slate-500/20',
    text: 'text-slate-600 dark:text-slate-400',
    border: 'border-slate-500/30',
    icon: Clock,
  },
  LEGACY_WARNING: {
    label: 'Legacy HMAC Uyarısı',
    bg: 'bg-amber-500/10 dark:bg-amber-500/20',
    text: 'text-amber-600 dark:text-amber-400',
    border: 'border-amber-500/30',
    icon: AlertTriangle,
  },
  NOT_ACTIVATED: {
    label: 'Lisans Kurulu Değil',
    bg: 'bg-slate-500/10 dark:bg-slate-500/20',
    text: 'text-slate-600 dark:text-slate-400',
    border: 'border-slate-500/30',
    icon: Shield,
  },
};

const moduleTitles: Record<string, { name: string; desc: string }> = {
  portal: { name: 'Karşılama Portalı (Captive Portal)', desc: 'SMS OTP, TCKN ve otel/voucher giriş sayfaları' },
  sessions: { name: 'RADIUS AAA & Oturum Yönetimi', desc: 'Gerçek zamanlı oturum takibi ve yetkilendirme' },
  devices: { name: 'Ağ Cihazı & AP Yönetimi', desc: 'FortiGate, MikroTik, Aruba vb. router ve AP yönetimi' },
  locations: { name: 'Çoklu Lokasyon & Şube', desc: 'Farklı şube ve mekanları tek merkezden yönetme' },
  logs_5651: { name: '5651 Yasal Log & Mühürleme', desc: 'SHA-256 zinciri, Zstandard sıkıştırma ve KamuSM imza' },
  archive: { name: 'WORM Arşiv Ambarı (MinIO)', desc: 'Tahrifatsız ve değiştirilemez arşiv depolama' },
  syslog: { name: 'FortiGate Syslog & UTM Motoru', desc: 'Saniyede binlerce canlı güvenlik duvarı logu' },
  reports: { name: 'Gelişmiş Raporlama & PDF/CSV', desc: 'Kullanım, kota ve adli bilişim denetim raporları' },
  radius: { name: 'RADIUS Entegrasyon Motoru', desc: 'EAP, MS-CHAPv2 ve IEEE 802.1X desteği' },
  vouchers: { name: 'Voucher & Kupon Üretici', desc: 'Süreli ve kotalı misafir Wi-Fi kuponları' },
  sms: { name: 'SMS OTP Sağlayıcıları', desc: 'NetGSM, Twilio, İletiMerkezi vb. SMS entegrasyonu' },
  whatsapp: { name: 'WhatsApp & OTT Giriş', desc: 'Mesajlaşma uygulamalarıyla kimlik doğrulama' },
};

export const PlatformLicensePage: React.FC = () => {
  const [license, setLicense] = useState<any>(null);
  const [usage, setUsage] = useState<any>(null);
  const [envelope, setEnvelope] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [acknowledging, setAcknowledging] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [copiedId, setCopiedId] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const status = await getPlatformLicenseStatus();
      const nextLicense = status?.license
        ? { ...status.license, status: status.license_status || status.license.status, installation_id: status.license.installation_id || status.installation_id }
        : { status: status?.license_status || 'NOT_INSTALLED', installation_id: status?.installation_id, enabled_modules: [] };
      setLicense(nextLicense);
      setUsage(status?.usage || {});
    } catch (error: any) {
      setMessage({ text: error?.message || 'Lisans bilgisi yüklenemedi.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const handleCopyInstallationId = () => {
    const id = license?.installation_id || '';
    if (!id) return;
    navigator.clipboard.writeText(id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2500);
  };

  const install = async () => {
    setSaving(true);
    setMessage(null);
    try {
      if (file) {
        await uploadPlatformLicense(file);
      } else if (envelope.trim()) {
        await activatePlatformLicense(envelope.trim());
      } else {
        throw new Error('Lütfen bir .vlicense/.lic dosyası seçin veya imzalı envelope metnini yapıştırın.');
      }
      setEnvelope('');
      setFile(null);
      setMessage({ text: 'Platform lisansı başarıyla doğrulandı ve etkinleştirildi.', type: 'success' });
      await load();
    } catch (error: any) {
      setMessage({ text: error?.message || 'Lisans yüklenemedi veya geçersiz imza.', type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const validate = async () => {
    setSaving(true);
    setMessage(null);
    try {
      await validatePlatformLicense();
      setMessage({ text: 'Lisans kriptografik imzası ve geçerlilik durumu teyit edildi.', type: 'success' });
      await load();
    } catch (error: any) {
      setMessage({ text: error?.message || 'Lisans doğrulanamadı.', type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const acknowledge = async () => {
    if (!license?.fingerprint || !license?.status) return;
    setAcknowledging(true);
    setMessage(null);
    try {
      await acknowledgePlatformLicense(license.fingerprint, license.status);
      setMessage({ text: 'Lisans teslimatı sunucuya bildirildi.', type: 'success' });
      await load();
    } catch (error: any) {
      setMessage({ text: error?.message || 'Lisans teslimatı onaylanamadı.', type: 'error' });
    } finally {
      setAcknowledging(false);
    }
  };

  const remove = async () => {
    if (!window.confirm('Kurulu platform lisansı kaldırılacak ve sistem lisanssız duruma geçecek. Devam etmek istiyor musunuz?')) return;
    setSaving(true);
    try {
      await removePlatformLicense();
      setMessage({ text: 'Lisans kaldırıldı.', type: 'info' });
      await load();
    } catch (error: any) {
      setMessage({ text: error?.message || 'Lisans kaldırılamadı.', type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const status = license?.status || 'NOT_ACTIVATED';
  const cfg = statusConfig[status] || statusConfig.NOT_ACTIVATED;
  const StatusIcon = cfg.icon;

  const limits = license?.limits || {};
  const maxCustomers = limits.max_customers || license?.max_customers || 0;
  const maxAssets = limits.max_assets || license?.max_assets || 0;
  const maxUsers = limits.max_users || license?.max_users || 0;

  const currentCustomers = usage?.customers || 0;
  const currentDevices = usage?.devices || 0;
  const currentSessions = usage?.sessions || 0;

  const calcPercent = (cur: number, max: number) => {
    if (!max || max <= 0) return null;
    return Math.min(Math.round((cur / max) * 100), 100);
  };

  return (
    <div className="space-y-6">
      {/* 1. Header with standard buttons */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Platform Lisansı
            </h1>
            <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-semibold ${cfg.bg} ${cfg.text}`}>
              <StatusIcon className="h-3.5 w-3.5" />
              {cfg.label}
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            NeoSecra Ed25519 kriptografik lisans doğrulama ve modül yetkilendirme paneli.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={validate}
            disabled={saving || !license?.license_id}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${saving ? 'animate-spin' : ''}`} />
            Yeniden Doğrula
          </button>

          {license?.license_id && (
            <button
              onClick={remove}
              disabled={saving}
              className="inline-flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-400 transition disabled:opacity-50"
            >
              <XCircle className="h-3.5 w-3.5" />
              Lisansı Kaldır
            </button>
          )}
          {license?.fingerprint && (
            <button
              onClick={acknowledge}
              disabled={saving || acknowledging}
              title="Lisans teslimatını sunucuya bildir"
              className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-400 transition disabled:opacity-50"
            >
              <CheckCircle2 className={`h-3.5 w-3.5 ${acknowledging ? 'animate-pulse' : ''}`} />
              {acknowledging ? 'Onaylanıyor...' : 'Teslimatı Onayla'}
            </button>
          )}
        </div>
      </div>

      {/* Alert Message */}
      {message && (
        <div
          className={`p-3.5 rounded-xl text-xs font-medium flex items-center justify-between border ${
            message.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/50'
              : message.type === 'error'
              ? 'bg-rose-50 dark:bg-rose-950/20 text-rose-800 dark:text-rose-400 border-rose-100 dark:border-rose-900/50'
              : 'bg-blue-50 dark:bg-blue-950/20 text-blue-800 dark:text-blue-400 border-blue-100 dark:border-blue-900/50'
          }`}
        >
          <div className="flex items-center gap-2">
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{message.text}</span>
          </div>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-slate-600 text-xs">
            ✕
          </button>
        </div>
      )}

      {/* 2. Standard 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Lisans Sürümü</span>
            <Award className="h-4 w-4 text-indigo-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-lg font-bold text-slate-900 dark:text-white capitalize">
              {license?.edition || (license?.license_id ? 'Enterprise' : 'Community / Lisanssız')}
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            İhraççı: {license?.issuer || 'NeoSecra'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Geçerlilik Bitişi</span>
            <Calendar className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-sm font-bold text-slate-900 dark:text-white">
              {license?.expires_at ? new Date(license.expires_at).toLocaleDateString('tr-TR', { day: '2-digit', month: 'long', year: 'numeric' }) : 'Süresiz'}
            </span>
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1">
            {license?.valid_from ? `Başlangıç: ${new Date(license.valid_from).toLocaleDateString('tr-TR')}` : 'Sistem aktif'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Güncelleme Hakkı</span>
            <Sparkles className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-sm font-bold text-slate-900 dark:text-white">
              {license?.update_entitlement_until ? new Date(license.update_entitlement_until).toLocaleDateString('tr-TR', { day: '2-digit', month: 'long', year: 'numeric' }) : 'Süresiz'}
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            İmzalı dağıtım kanalı
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Kurulum ID</span>
            <Key className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-center justify-between gap-1">
            <span className="font-mono text-xs font-bold text-slate-900 dark:text-white truncate" title={license?.installation_id || ''}>
              {license?.installation_id ? `${license.installation_id.slice(0, 16)}...` : 'Oluşturuluyor...'}
            </span>
            <button
              onClick={handleCopyInstallationId}
              disabled={!license?.installation_id}
              className="p-1 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition rounded hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
              title="Kurulum ID'sini Kopyala"
            >
              {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {copiedId ? 'Kopyalandı!' : 'Donanım / sunucu kimliği'}
          </div>
        </div>
      </div>

      {/* 3. Main Content: Modules & Limits + Upload Box */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column: Modules & Quotas (7 Cols) */}
        <div className="space-y-6 lg:col-span-7">
          {/* Enabled Modules */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Yetkilendirilmiş Sistem Modülleri
              </h3>
              <span className="text-xs text-slate-500">
                {(license?.enabled_modules || []).length} modül aktif
              </span>
            </div>

            {(license?.enabled_modules || []).length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-500">
                Kurulu lisans bulunmadığından modüller temel modda çalışmaktadır.
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {(license?.enabled_modules || []).map((modKey: string) => {
                  const info = moduleTitles[modKey] || { name: modKey, desc: 'Yetkilendirilmiş modül' };
                  return (
                    <div
                      key={modKey}
                      className="flex items-start gap-2.5 rounded-lg border border-slate-100 bg-slate-50/60 p-2.5 dark:border-slate-800 dark:bg-slate-850/40"
                    >
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-xs font-semibold text-slate-900 dark:text-white">{info.name}</div>
                        <div className="text-[10px] text-slate-500 mt-0.5">{info.desc}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Quota & Capacity Usage */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Kapasite ve Kullanım Tüketimi
              </h3>
              <span className="text-xs text-slate-500">Canlı Metrikler</span>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-600 dark:text-slate-400">
                    Müşteri / Kurum Sayısı
                  </span>
                  <span className="text-slate-900 dark:text-white font-mono">
                    {currentCustomers} / {maxCustomers > 0 ? maxCustomers : 'Sınırsız'}
                  </span>
                </div>
                {calcPercent(currentCustomers, maxCustomers) !== null && (
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-blue-600 h-1.5 rounded-full transition-all"
                      style={{ width: `${calcPercent(currentCustomers, maxCustomers)}%` }}
                    />
                  </div>
                )}
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-600 dark:text-slate-400">
                    Ağ Cihazı &amp; AP Sayısı
                  </span>
                  <span className="text-slate-900 dark:text-white font-mono">
                    {currentDevices} / {maxAssets > 0 ? maxAssets : 'Sınırsız'}
                  </span>
                </div>
                {calcPercent(currentDevices, maxAssets) !== null && (
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-emerald-600 h-1.5 rounded-full transition-all"
                      style={{ width: `${calcPercent(currentDevices, maxAssets)}%` }}
                    />
                  </div>
                )}
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-600 dark:text-slate-400">
                    Eşzamanlı Çevrimiçi Kullanıcı (Oturum)
                  </span>
                  <span className="text-slate-900 dark:text-white font-mono">
                    {currentSessions} / {maxUsers > 0 ? maxUsers : 'Sınırsız'}
                  </span>
                </div>
                {calcPercent(currentSessions, maxUsers) !== null && (
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-indigo-600 h-1.5 rounded-full transition-all"
                      style={{ width: `${calcPercent(currentSessions, maxUsers)}%` }}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: License Installation & Verification Box (5 Cols) */}
        <div className="space-y-6 lg:col-span-5">
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 pb-3 dark:border-slate-800">
              Yeni Lisans Yükleme
            </h3>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                if (e.dataTransfer.files?.[0]) {
                  setFile(e.dataTransfer.files[0]);
                }
              }}
              className={`border-2 border-dashed rounded-lg p-4 text-center transition cursor-pointer ${
                dragOver
                  ? 'border-blue-500 bg-blue-50/40 dark:bg-blue-950/30'
                  : file
                  ? 'border-emerald-400 bg-emerald-50/20 dark:bg-emerald-950/20'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <input
                type="file"
                id="license-file"
                accept=".vlicense,.lic,.json,.txt"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                className="hidden"
              />
              <label htmlFor="license-file" className="cursor-pointer block space-y-1">
                <FileCode className={`w-6 h-6 mx-auto ${file ? 'text-emerald-600' : 'text-slate-400'}`} />
                {file ? (
                  <div>
                    <div className="text-xs font-semibold text-slate-900 dark:text-white">{file.name}</div>
                    <div className="text-[10px] text-emerald-600 font-semibold">Dosya seçildi ({(file.size / 1024).toFixed(1)} KB)</div>
                  </div>
                ) : (
                  <div>
                    <div className="text-xs font-medium text-slate-700 dark:text-slate-300">
                      Lisans dosyasını (.vlicense, .lic) seçin veya sürükleyin
                    </div>
                  </div>
                )}
              </label>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block">
                veya İmzalı Envelope JSON Metni
              </label>
              <textarea
                value={envelope}
                onChange={(e) => {
                  setEnvelope(e.target.value);
                  if (e.target.value) setFile(null);
                }}
                rows={3}
                placeholder='{"schema_version": 1, "key_id": "vdata-license-prod-2026-01", "algorithm": "Ed25519", ...}'
                className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono dark:border-slate-700 dark:bg-slate-950 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              onClick={install}
              disabled={saving || (!file && !envelope.trim())}
              className="w-full inline-flex justify-center items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition disabled:opacity-50 shadow-xs"
            >
              {saving ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
              Lisansı Doğrula &amp; Etkinleştir
            </button>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 pb-3 dark:border-slate-800">
              Kriptografik Güvenlik
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Algoritma:</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-white">Ed25519 (RFC 8032)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">Key ID:</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-white truncate max-w-[170px]">
                  {license?.key_id || 'vdata-license-prod-2026-01'}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Müşteri / Kurum:</span>
                <span className="font-semibold text-slate-900 dark:text-white truncate max-w-[170px]">
                  {license?.customer_name || 'NeoSecra Customer'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
