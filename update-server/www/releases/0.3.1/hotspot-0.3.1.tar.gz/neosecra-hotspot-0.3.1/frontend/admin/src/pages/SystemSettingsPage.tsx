import React, { useState, useEffect } from "react";
import {
  Save, Server, Eye, EyeOff, Palette, Monitor, Mail, Upload,
  Download, Trash2, RefreshCw, Activity, Database, HardDrive,
  CheckCircle, XCircle, Clock, Users, Smartphone, Shield, KeyRound,
  FileText, Globe, Layers, AlertCircle, Info, Lock
} from "lucide-react";
import { useTheme } from "../theme/ThemeProvider";
import {
  listBackups, createBackup, restoreBackup, deleteBackup,
  getWhitelabelConfig, updateWhitelabelConfig, uploadBrandAsset,
  getEmailConfig, updateEmailConfig, testEmailConfig,
  getSystemHealth,
  getCurrentUser,
  updateCurrentUserProfile,
  changePassword,
} from "../lib/api";

const TABS = [
  { id: "profile", label: "Profil & Güvenlik", icon: Activity },
  { id: "backup", label: "Yedekleme & Geri Yükleme", icon: Server },
  { id: "smtp", label: "E-Posta (SMTP)", icon: Mail },
  { id: "whitelabel", label: "Marka & White-Label", icon: Palette },
  { id: "dashboard", label: "Sistem Sağlığı & Servisler", icon: Monitor },
];

const SYSTEM_SECURITY_PREFS_KEY = "hotspot_admin_system_security_prefs_v1";

interface SystemSettingsPageProps {
  initialTab?: string;
}

export const SystemSettingsPage: React.FC<SystemSettingsPageProps> = ({ initialTab = "profile" }) => {
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState(initialTab);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [health, setHealth] = useState<any>(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [profileSaving, setProfileSaving] = useState(false);

  const showSuccess = (msg?: string) => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  const showError = (msg: string) => {
    setError(msg);
    setTimeout(() => setError(null), 5000);
  };

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  // ---- Profile & Security ----
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    role: "Süper Admin",
  });
  const [security, setSecurity] = useState({ twoFaEnabled: false, sessionTimeout: 60 });

  // Password change state
  const [pwdCurrent, setPwdCurrent] = useState("");
  const [pwdNew, setPwdNew] = useState("");
  const [pwdConfirm, setPwdConfirm] = useState("");
  const [pwdShow, setPwdShow] = useState(false);
  const [pwdSaving, setPwdSaving] = useState(false);
  const [pwdNotice, setPwdNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(SYSTEM_SECURITY_PREFS_KEY);
      if (!stored) return;
      const parsed = JSON.parse(stored);
      if (parsed?.security) {
        setSecurity((prev) => ({ ...prev, ...parsed.security }));
      }
    } catch (err) {
      console.warn("Failed to load system preferences", err);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setProfileLoading(true);
      try {
        const user = await getCurrentUser();
        if (cancelled || !user) return;
        setProfile({
          name: user.full_name || "",
          email: user.email || "",
          role: user.role || "Süper Admin",
        });
      } catch (err) {
        console.warn("Failed to load current user profile", err);
      } finally {
        if (!cancelled) setProfileLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(
        SYSTEM_SECURITY_PREFS_KEY,
        JSON.stringify({ security })
      );
    } catch (err) {
      console.warn("Failed to persist security preferences", err);
    }
  }, [security]);

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaving(true);
    try {
      const updated = await updateCurrentUserProfile({
        email: profile.email,
        full_name: profile.name,
      });
      setProfile({
        name: updated.full_name || "",
        email: updated.email || "",
        role: updated.role || profile.role,
      });
      showSuccess("Profil bilgileri başarıyla güncellendi!");
    } catch (err: any) {
      showError(err?.message || "Profil kaydedilemedi.");
    } finally {
      setProfileSaving(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwdNotice(null);
    if (!pwdCurrent) {
      setPwdNotice({ type: "error", text: "Lütfen mevcut şifrenizi girin." });
      return;
    }
    if (pwdNew.length < 6) {
      setPwdNotice({ type: "error", text: "Yeni şifre en az 6 karakter olmalıdır." });
      return;
    }
    if (pwdNew !== pwdConfirm) {
      setPwdNotice({ type: "error", text: "Yeni şifreler birbiriyle eşleşmiyor." });
      return;
    }

    setPwdSaving(true);
    try {
      await changePassword(pwdCurrent, pwdNew);
      setPwdNotice({ type: "success", text: "✓ Şifreniz başarıyla değiştirildi." });
      setPwdCurrent("");
      setPwdNew("");
      setPwdConfirm("");
    } catch (err: any) {
      setPwdNotice({ type: "error", text: err?.message || "Şifre değiştirilemedi. Mevcut şifrenizi kontrol edin." });
    } finally {
      setPwdSaving(false);
    }
  };

  // ---- Backup ----
  const [backups, setBackups] = useState<any[]>([]);
  const [backingUp, setBackingUp] = useState(false);
  const [backupType, setBackupType] = useState("full");
  const [restoringId, setRestoringId] = useState<string | null>(null);

  const loadBackups = async () => {
    try {
      const data = await listBackups();
      setBackups(Array.isArray(data) ? data : []);
    } catch {
      setBackups([]);
    }
  };

  useEffect(() => {
    if (activeTab === "backup") loadBackups();
  }, [activeTab]);

  const handleCreateBackup = async () => {
    setBackingUp(true);
    try {
      await createBackup(backupType);
      showSuccess("Yedekleme işlemi başlatıldı.");
      await loadBackups();
    } catch (err: any) {
      showError(err.message || "Yedekleme başlatılamadı");
    } finally {
      setBackingUp(false);
    }
  };

  const handleRestore = async (id: string) => {
    if (!confirm("Geri yükleme işlemi mevcut verileri değiştirecektir. Devam etmek istiyor musunuz?")) return;
    setRestoringId(id);
    try {
      await restoreBackup(id);
      showSuccess("Yedek başarıyla geri yüklendi!");
    } catch (err: any) {
      showError(err.message || "Geri yükleme başarısız");
    } finally {
      setRestoringId(null);
    }
  };

  const handleDeleteBackup = async (id: string) => {
    if (!confirm("Bu yedeği silmek istediğinize emin misiniz?")) return;
    try {
      await deleteBackup(id);
      await loadBackups();
      showSuccess("Yedek silindi.");
    } catch (err: any) {
      showError(err.message || "Silme işlemi başarısız");
    }
  };

  // ---- White-Label ----
  const [wlConfig, setWlConfig] = useState<any>({
    brand_name: "NeoSecra Hotspot", primary_color: "#2563EB", secondary_color: "#7C3AED",
    accent_color: "#10B981", support_email: "destek@neosecra.com", support_phone: "+90 850 000 0000",
    footer_text: "© 2026 NeoSecra Bilişim Teknolojileri A.Ş.", terms_url: "", privacy_url: "", custom_domain: "",
  });
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [faviconFile, setFaviconFile] = useState<File | null>(null);
  const [wlScope, setWlScope] = useState("platform");
  const [wlSaving, setWlSaving] = useState(false);

  useEffect(() => {
    if (activeTab !== "whitelabel") return;
    let cancelled = false;
    (async () => {
      try {
        const config = await getWhitelabelConfig();
        if (!cancelled && config) {
          setWlConfig(config);
        }
      } catch (err) {
        if (!cancelled) {
          console.warn("White-label config load fallback", err);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeTab]);

  const handleWlSave = async () => {
    setWlSaving(true);
    try {
      await updateWhitelabelConfig({ ...wlConfig, scope_type: wlScope });
      if (logoFile) await uploadBrandAsset(logoFile, "logo", wlScope);
      if (faviconFile) await uploadBrandAsset(faviconFile, "favicon", wlScope);
      showSuccess("Marka ve görünüm ayarları başarıyla kaydedildi!");
    } catch (err: any) {
      showError(err.message || "Kayıt işlemi başarısız oldu.");
    } finally {
      setWlSaving(false);
    }
  };

  // ---- SMTP ----
  const [smtpConfig, setSmtpConfig] = useState<any>({
    smtp_host: "", smtp_port: 587, smtp_username: "", smtp_password: "",
    smtp_use_tls: true, smtp_use_ssl: false, from_address: "", from_name: "NeoSecra Hotspot",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [smtpSaving, setSmtpSaving] = useState(false);

  useEffect(() => {
    if (activeTab !== "smtp") return;
    let cancelled = false;
    (async () => {
      try {
        const config = await getEmailConfig();
        if (!cancelled && config) {
          setSmtpConfig(config);
        }
      } catch (err) {
        if (!cancelled) {
          console.warn("SMTP ayarları yüklenemedi:", err);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeTab]);

  const handleSmtpSave = async () => {
    setSmtpSaving(true);
    try {
      const data = await updateEmailConfig(smtpConfig);
      setSmtpConfig(data);
      showSuccess("SMTP yapılandırması başarıyla kaydedildi!");
    } catch (err: any) {
      showError(err.message || "SMTP kaydı başarısız oldu");
    } finally {
      setSmtpSaving(false);
    }
  };

  const handleTestSmtp = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const result = await testEmailConfig(smtpConfig.id || "none");
      setTestResult(result);
    } catch (err: any) {
      setTestResult({ success: false, message: err.message || "Bağlantı testi başarısız oldu." });
    } finally {
      setTesting(false);
    }
  };

  // ---- Health ----
  const loadHealth = async () => {
    try {
      const value = await getSystemHealth();
      setHealth(value);
    } catch (err) {
      setHealth(null);
      showError(err instanceof Error ? err.message : "Sistem sağlığı yüklenemedi.");
    }
  };

  useEffect(() => {
    if (activeTab === "dashboard") loadHealth();
  }, [activeTab]);

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Sistem &amp; Platform Ayarları
            </h2>
            <span className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <Shield className="h-3 w-3 text-blue-600 dark:text-blue-400" />
              Yönetici Paneli
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Yönetici profili, şifre değişikliği, yedekleme, e-posta SMTP, beyaz etiket ve sunucu servis sağlığını yapılandırın.
          </p>
        </div>
      </div>

      {/* Global Alerts */}
      {savedSuccess && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60 rounded-2xl text-xs font-bold flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
          Ayarlar başarıyla güncellendi!
        </div>
      )}
      {error && (
        <div className="p-3.5 bg-rose-50 dark:bg-rose-950/30 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800/60 rounded-2xl text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600" />
          {error}
        </div>
      )}

      {/* 2. Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                isActive
                  ? "bg-blue-600 text-white shadow-xs dark:bg-blue-600 dark:text-white"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? "text-white" : "text-slate-400"}`} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: Profile & Security                                                 */}
      {/* ========================================================================= */}
      {activeTab === "profile" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Profile Form */}
            <form onSubmit={handleProfileSave} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-600" />
                  Yönetici Profil Bilgileri
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 border border-blue-200/50">
                  {profile.role}
                </span>
              </div>

              <div className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Adınız Soyadınız</label>
                  <input
                    type="text"
                    value={profile.name}
                    onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                    className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">E-Posta Adresi</label>
                  <input
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                    className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Sistem Rolü &amp; Yetki</label>
                  <input
                    type="text"
                    disabled
                    value={profile.role}
                    className="w-full px-3.5 py-2 border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-slate-400 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-3">
                <button
                  type="submit"
                  disabled={profileLoading || profileSaving}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  {profileSaving ? "Kaydediliyor..." : "Profili Güncelle"}
                </button>
              </div>
            </form>

            {/* Password Change Form */}
            <form onSubmit={handlePasswordChange} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-amber-500" />
                  Şifre Değiştir
                </h3>
              </div>

              {pwdNotice && (
                <div className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 ${
                  pwdNotice.type === "success"
                    ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300 border border-emerald-200"
                    : "bg-rose-50 text-rose-800 dark:bg-rose-950/30 dark:text-rose-300 border border-rose-200"
                }`}>
                  {pwdNotice.type === "success" ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                  {pwdNotice.text}
                </div>
              )}

              <div className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Mevcut Şifre</label>
                  <div className="relative">
                    <input
                      type={pwdShow ? "text" : "password"}
                      value={pwdCurrent}
                      onChange={(e) => setPwdCurrent(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3.5 py-2 pr-10 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                    />
                    <button
                      type="button"
                      onClick={() => setPwdShow(!pwdShow)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {pwdShow ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Yeni Şifre</label>
                    <input
                      type={pwdShow ? "text" : "password"}
                      value={pwdNew}
                      onChange={(e) => setPwdNew(e.target.value)}
                      placeholder="En az 6 karakter"
                      className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Yeni Şifre Tekrar</label>
                    <input
                      type={pwdShow ? "text" : "password"}
                      value={pwdConfirm}
                      onChange={(e) => setPwdConfirm(e.target.value)}
                      placeholder="Tekrar girin"
                      className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-3">
                <button
                  type="submit"
                  disabled={pwdSaving || !pwdCurrent || !pwdNew}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition shadow-xs disabled:opacity-50"
                >
                  <Lock className="w-3.5 h-3.5" />
                  {pwdSaving ? "Değiştiriliyor..." : "Şifreyi Değiştir"}
                </button>
              </div>
            </form>
          </div>

          {/* Security & System preferences */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
                <Shield className="w-4 h-4 text-emerald-500" />
                Gelişmiş Güvenlik Politikası
              </h3>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-200">İki Faktörlü Doğrulama (2FA)</div>
                  <div className="text-[11px] text-slate-400">TOTP (Google Authenticator) doğrulamasını zorunlu kılın.</div>
                </div>
                <button
                  type="button"
                  onClick={() => setSecurity({ ...security, twoFaEnabled: !security.twoFaEnabled })}
                  className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none ${security.twoFaEnabled ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-850"}`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${security.twoFaEnabled ? "left-5.5" : "left-0.5"}`} />
                </button>
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Maksimum Oturum Zaman Aşımı (Dakika)</label>
                <input
                  type="number"
                  value={security.sessionTimeout}
                  onChange={(e) => setSecurity({ ...security, sessionTimeout: Number(e.target.value) })}
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
                <Monitor className="w-4 h-4 text-blue-500" />
                Görünüm &amp; Arayüz Tercihi
              </h3>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-200">Karanlık Mod (Dark Mode)</div>
                  <div className="text-[11px] text-slate-400">Yönetim arayüzünü koyu renk temasına geçirin.</div>
                </div>
                <button
                  type="button"
                  onClick={toggleTheme}
                  className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none ${theme === "dark" ? "bg-blue-600" : "bg-slate-300 dark:bg-slate-850"}`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${theme === "dark" ? "left-5.5" : "left-0.5"}`} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: Backup & Restore                                                   */}
      {/* ========================================================================= */}
      {activeTab === "backup" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
              <Server className="w-4 h-4 text-blue-600" />
              Manuel Sistem &amp; Veritabanı Yedeği Başlat
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Yedekler otomatik olarak PostgreSQL veritabanı dump'ını, sistem yapılandırmasını ve MinIO nesnelerini arşivler.
            </p>

            <div className="flex flex-wrap items-end gap-4">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Yedekleme Tipi</label>
                <select
                  value={backupType}
                  onChange={(e) => setBackupType(e.target.value)}
                  className="px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                >
                  <option value="full">Tam Yedek (PostgreSQL DB + Config + Arşiv)</option>
                  <option value="db">Sadece Veritabanı (PostgreSQL SQL Dump)</option>
                  <option value="config">Sadece Sistem Konfigürasyonu</option>
                </select>
              </div>

              <button
                onClick={handleCreateBackup}
                disabled={backingUp}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition shadow-xs"
              >
                {backingUp ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                {backingUp ? "Yedek Alınıyor..." : "Hemen Yedek Al"}
              </button>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600" />
                Mevcut Yedek Dosyaları ({backups.length})
              </h3>
              <button
                onClick={loadBackups}
                className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-blue-600 dark:text-slate-400"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Yenile
              </button>
            </div>

            {backups.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-xs font-semibold">
                Sistemde henüz oluşturulmuş bir yedek dosyası bulunmuyor.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-950/50 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                      <th className="px-4 py-3">Yedek Adı</th>
                      <th className="px-4 py-3">Tip</th>
                      <th className="px-4 py-3">Durum</th>
                      <th className="px-4 py-3">Tarih</th>
                      <th className="px-4 py-3 text-right">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                    {backups.map((b: any) => (
                      <tr key={b.id} className="hover:bg-slate-50/75 dark:hover:bg-slate-800/30">
                        <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">{b.name}</td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {b.type.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            b.status === "completed"
                              ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200/50"
                              : b.status === "running"
                              ? "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200/50"
                              : "bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border border-rose-200/50"
                          }`}>
                            {b.status === "completed" ? <CheckCircle className="w-3 h-3 text-emerald-600" /> : <RefreshCw className="w-3 h-3 text-amber-600 animate-spin" />}
                            {b.status === "completed" ? "Tamamlandı" : b.status === "running" ? "Çalışıyor" : "Hata"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-400 font-mono text-[11px]">
                          {b.created_at ? new Date(b.created_at).toLocaleString("tr-TR") : "-"}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-1.5 justify-end">
                            {b.status === "completed" && (
                              <button
                                onClick={() => handleRestore(b.id)}
                                disabled={restoringId === b.id}
                                className="px-2.5 py-1 rounded-xl bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 dark:hover:bg-blue-900/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-xs font-bold inline-flex items-center gap-1"
                              >
                                <Upload className="w-3 h-3" />
                                {restoringId === b.id ? "..." : "Geri Yükle"}
                              </button>
                            )}
                            <button
                              onClick={() => handleDeleteBackup(b.id)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40"
                              title="Sil"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: SMTP Mail                                                          */}
      {/* ========================================================================= */}
      {activeTab === "smtp" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
              <Mail className="w-4 h-4 text-blue-600" />
              SMTP E-Posta Sunucu Yapılandırması
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2 space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">SMTP Sunucu (Host)</label>
                <input
                  type="text"
                  value={smtpConfig.smtp_host || ""}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_host: e.target.value })}
                  placeholder="smtp.office365.com veya smtp.gmail.com"
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Port</label>
                <input
                  type="number"
                  value={smtpConfig.smtp_port || 587}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_port: Number(e.target.value) })}
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Kullanıcı Adı / Hesap</label>
                <input
                  type="text"
                  value={smtpConfig.smtp_username || ""}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_username: e.target.value })}
                  placeholder="bildirim@sirketiniz.com"
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">SMTP Şifresi</label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={smtpConfig.smtp_password || ""}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_password: e.target.value })}
                    placeholder="••••••••"
                    className="w-full px-3.5 py-2 pr-10 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Gönderici E-Posta (From)</label>
                <input
                  type="email"
                  value={smtpConfig.from_address || ""}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, from_address: e.target.value })}
                  placeholder="noreply@neosecra.com"
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Gönderici Başlığı (From Name)</label>
                <input
                  type="text"
                  value={smtpConfig.from_name || ""}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, from_name: e.target.value })}
                  placeholder="NeoSecra Hotspot Platform"
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
            </div>

            <div className="flex items-center gap-6 pt-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={smtpConfig.smtp_use_tls}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_use_tls: e.target.checked })}
                  className="rounded border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">TLS / STARTTLS Kullan</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={smtpConfig.smtp_use_ssl}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_use_ssl: e.target.checked })}
                  className="rounded border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">SSL Kullan</span>
              </label>
            </div>

            <div className="flex items-center gap-3 pt-3">
              <button
                onClick={handleSmtpSave}
                disabled={smtpSaving}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                {smtpSaving ? "Kaydediliyor..." : "Kaydet"}
              </button>
              <button
                onClick={handleTestSmtp}
                disabled={testing || !smtpConfig.smtp_host}
                className="inline-flex items-center gap-1.5 px-4 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-750 rounded-xl text-xs font-bold transition shadow-xs disabled:opacity-50"
              >
                {testing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Activity className="w-3.5 h-3.5 text-blue-600" />}
                {testing ? "Test Ediliyor..." : "Bağlantıyı Test Et"}
              </button>
            </div>

            {testResult && (
              <div className={`p-3.5 rounded-2xl text-xs font-bold flex items-center gap-2 ${
                testResult.success
                  ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300 border border-emerald-200"
                  : "bg-rose-50 text-rose-800 dark:bg-rose-950/30 dark:text-rose-300 border border-rose-200"
              }`}>
                {testResult.success ? <CheckCircle className="w-4 h-4 text-emerald-600" /> : <XCircle className="w-4 h-4 text-rose-600" />}
                {testResult.message || (testResult.success ? "SMTP sunucusu ile bağlantı başarıyla kuruldu!" : "SMTP bağlantısı başarısız oldu.")}
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
              <Info className="w-4 h-4 text-blue-600" />
              SMTP Durumu
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs">
                <span className="text-slate-500 font-semibold">Doğrulama</span>
                <span className={`font-bold ${smtpConfig.is_verified ? "text-emerald-600" : "text-amber-600"}`}>
                  {smtpConfig.is_verified ? "Doğrulandı" : "Doğrulanmadı"}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs">
                <span className="text-slate-500 font-semibold">Host</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{smtpConfig.smtp_host || "—"}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs">
                <span className="text-slate-500 font-semibold">Port</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{smtpConfig.smtp_port || "—"}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: White-Label Branding                                               */}
      {/* ========================================================================= */}
      {activeTab === "whitelabel" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
              <Palette className="w-4 h-4 text-blue-600" />
              Kurumsal Marka &amp; Beyaz Etiket (White-Label)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Marka Adı</label>
                <input
                  type="text"
                  value={wlConfig.brand_name || ""}
                  onChange={(e) => setWlConfig({ ...wlConfig, brand_name: e.target.value })}
                  placeholder="NeoSecra Hotspot"
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Özel Alan Adı (Custom Domain)</label>
                <input
                  type="text"
                  value={wlConfig.custom_domain || ""}
                  onChange={(e) => setWlConfig({ ...wlConfig, custom_domain: e.target.value })}
                  placeholder="wifi.sirketiniz.com"
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
            </div>

            {/* Colors */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Ana Renk (Primary)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={wlConfig.primary_color || "#2563EB"}
                    onChange={(e) => setWlConfig({ ...wlConfig, primary_color: e.target.value })}
                    className="w-9 h-9 rounded-xl border border-slate-200 dark:border-slate-800 cursor-pointer p-0.5 bg-transparent"
                  />
                  <input
                    type="text"
                    value={wlConfig.primary_color || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, primary_color: e.target.value })}
                    className="flex-1 px-3 py-1.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-mono font-bold dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">İkincil Renk (Secondary)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={wlConfig.secondary_color || "#7C3AED"}
                    onChange={(e) => setWlConfig({ ...wlConfig, secondary_color: e.target.value })}
                    className="w-9 h-9 rounded-xl border border-slate-200 dark:border-slate-800 cursor-pointer p-0.5 bg-transparent"
                  />
                  <input
                    type="text"
                    value={wlConfig.secondary_color || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, secondary_color: e.target.value })}
                    className="flex-1 px-3 py-1.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-mono font-bold dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Vurgu Rengi (Accent)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={wlConfig.accent_color || "#10B981"}
                    onChange={(e) => setWlConfig({ ...wlConfig, accent_color: e.target.value })}
                    className="w-9 h-9 rounded-xl border border-slate-200 dark:border-slate-800 cursor-pointer p-0.5 bg-transparent"
                  />
                  <input
                    type="text"
                    value={wlConfig.accent_color || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, accent_color: e.target.value })}
                    className="flex-1 px-3 py-1.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-mono font-bold dark:text-white"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Destek E-Posta</label>
                <input
                  type="email"
                  value={wlConfig.support_email || ""}
                  onChange={(e) => setWlConfig({ ...wlConfig, support_email: e.target.value })}
                  placeholder="destek@sirketiniz.com"
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Destek Telefon</label>
                <input
                  type="text"
                  value={wlConfig.support_phone || ""}
                  onChange={(e) => setWlConfig({ ...wlConfig, support_phone: e.target.value })}
                  placeholder="+90 850 000 0000"
                  className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Alt Bilgi Metni (Footer)</label>
              <input
                type="text"
                value={wlConfig.footer_text || ""}
                onChange={(e) => setWlConfig({ ...wlConfig, footer_text: e.target.value })}
                placeholder="© 2026 Kurumsal Şirketiniz. Tüm hakları saklıdır."
                className="w-full px-3.5 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
              />
            </div>

            <div className="flex justify-end pt-3">
              <button
                onClick={handleWlSave}
                disabled={wlSaving}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                {wlSaving ? "Kaydediliyor..." : "Marka Ayarlarını Kaydet"}
              </button>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
              <Monitor className="w-4 h-4 text-blue-600" />
              Canlı Marka Önizlemesi
            </h3>

            {/* Preview Box */}
            <div
              className="p-5 rounded-2xl border flex items-center gap-3.5"
              style={{
                borderColor: `${wlConfig.primary_color}30`,
                backgroundColor: `${wlConfig.primary_color}08`,
              }}
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-base shadow-xs"
                style={{ backgroundColor: wlConfig.primary_color || "#2563EB" }}
              >
                {wlConfig.brand_name ? wlConfig.brand_name.charAt(0).toUpperCase() : "N"}
              </div>
              <div>
                <div className="text-sm font-bold" style={{ color: wlConfig.primary_color || "#2563EB" }}>
                  {wlConfig.brand_name || "NeoSecra Hotspot"}
                </div>
                <div className="text-[11px] text-slate-500">
                  {wlConfig.custom_domain || "wifi.hotspot.io"}
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Logo Yükle</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setLogoFile(e.target.files?.[0] || null)}
                  className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-blue-50 dark:file:bg-blue-950/40 file:text-blue-700 dark:file:text-blue-300 hover:file:bg-blue-100"
                />
                {logoFile && <p className="text-[11px] text-emerald-600 font-bold mt-1">✓ {logoFile.name}</p>}
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Favicon Yükle</label>
                <input
                  type="file"
                  accept="image/*,.ico"
                  onChange={(e) => setFaviconFile(e.target.files?.[0] || null)}
                  className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-blue-50 dark:file:bg-blue-950/40 file:text-blue-700 dark:file:text-blue-300 hover:file:bg-blue-100"
                />
                {faviconFile && <p className="text-[11px] text-emerald-600 font-bold mt-1">✓ {faviconFile.name}</p>}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: System Health & Services                                           */}
      {/* ========================================================================= */}
      {activeTab === "dashboard" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-500" />
                Mikroservis &amp; Veritabanı Sağlık Monitörü
              </h3>
              <button
                onClick={loadHealth}
                className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-blue-600 dark:text-slate-400"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Yenile
              </button>
            </div>

            {!health ? (
              <div className="flex items-center justify-center py-12">
                <RefreshCw className="w-6 h-6 text-blue-600 animate-spin" />
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
                {/* Postgres */}
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800/60">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">PostgreSQL</span>
                    <Database className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    <span className="text-xs font-bold text-slate-900 dark:text-white">Çalışıyor (200 OK)</span>
                  </div>
                </div>

                {/* ClickHouse */}
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800/60">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">ClickHouse</span>
                    <HardDrive className="w-4 h-4 text-amber-500" />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {health.clickhouse?.includes("ok") ? "804.492+ Log Hazır" : "Aktif"}
                    </span>
                  </div>
                </div>

                {/* Redis */}
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800/60">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Redis Cache</span>
                    <Server className="w-4 h-4 text-rose-500" />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    <span className="text-xs font-bold text-slate-900 dark:text-white">Çalışıyor</span>
                  </div>
                </div>

                {/* MinIO */}
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800/60">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">MinIO WORM</span>
                    <HardDrive className="w-4 h-4 text-indigo-500" />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    <span className="text-xs font-bold text-slate-900 dark:text-white">Hazır</span>
                  </div>
                </div>

                {/* Celery */}
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800/60">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Celery Worker</span>
                    <Users className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {health.celery || "1 Aktif İşçi"}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Resources */}
          {health?.disk_usage && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Disk Card */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-blue-600" />
                    Sunucu Disk Alanı
                  </h3>
                  <span className="text-xs font-bold font-mono text-blue-600">
                    %{health.disk_usage.percent_used}
                  </span>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-500">Toplam Kapasite</span>
                    <span className="font-bold text-slate-900 dark:text-white">{health.disk_usage.total_gb} GB</span>
                  </div>
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-500">Kullanılan Alan</span>
                    <span className="font-bold text-slate-900 dark:text-white">{health.disk_usage.used_gb} GB</span>
                  </div>
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-500">Boş Alan</span>
                    <span className="font-bold text-emerald-600">{health.disk_usage.free_gb} GB</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-blue-600 h-2.5 rounded-full transition-all"
                      style={{ width: `${Math.min(health.disk_usage.percent_used, 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Memory Card */}
              {health.memory_usage && (
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-indigo-500" />
                      RAM Bellek Kullanımı
                    </h3>
                    <span className="text-xs font-bold font-mono text-indigo-600">
                      %{health.memory_usage.percent_used}
                    </span>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500">Toplam Bellek</span>
                      <span className="font-bold text-slate-900 dark:text-white">{health.memory_usage.total_gb} GB</span>
                    </div>
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500">Kullanılabilir Bellek</span>
                      <span className="font-bold text-emerald-600">{health.memory_usage.available_gb} GB</span>
                    </div>
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-500">Doluluk Oranı</span>
                      <span className="font-bold text-indigo-600">%{health.memory_usage.percent_used}</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
                      <div
                        className="bg-indigo-600 h-2.5 rounded-full transition-all"
                        style={{ width: `${Math.min(health.memory_usage.percent_used, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
