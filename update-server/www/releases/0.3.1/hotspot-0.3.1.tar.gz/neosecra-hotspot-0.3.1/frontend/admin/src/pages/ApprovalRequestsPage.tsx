import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  CheckCircle,
  Clock3,
  Mail,
  RefreshCw,
  Search,
  ShieldCheck,
  UserCheck,
  UserX,
  XCircle,
  Layers,
  Check,
} from "lucide-react";
import { approveSession, getPendingSessions, rejectSession } from "../lib/api";

type Decision = "approve" | "reject";

const FIELD_LABELS: Record<string, string> = {
  full_name: "Ad Soyad",
  name_surname: "Ad Soyad",
  ad_soyad: "Ad Soyad",
  first_name: "Ad",
  last_name: "Soyad",
  phone: "Telefon",
  gsm: "Telefon",
  telefon: "Telefon",
  tc_number: "T.C. Kimlik No",
  tc_no: "T.C. Kimlik No",
  tc: "T.C. Kimlik No",
  email: "E-posta Adresi",
  department: "Geldiği Birim / Departman",
  unit: "Geldiği Birim",
  birim: "Geldiği Birim",
  company: "Firma / Kurum Adı",
  firma: "Firma / Kurum Adı",
  visit_reason: "Ziyaret Sebebi",
  visited_person: "Ziyaret Edilen Kişi",
  room_number: "Oda Numarası",
  notes: "Notlar / Açıklama",
};

const getFieldLabel = (key: string) => {
  return FIELD_LABELS[key.toLowerCase()] || key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
};

const formatDate = (value?: string | null) => {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString("tr-TR");
};

const formatValue = (value: unknown) => {
  if (typeof value === "boolean") return value ? "Evet" : "Hayır";
  if (value === null || value === undefined || value === "") return "—";
  return String(value);
};

export const ApprovalRequestsPage: React.FC = () => {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [query, setQuery] = useState("");
  const [decisionId, setDecisionId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (initial = false) => {
    if (initial) setLoading(true);
    else setRefreshing(true);
    setError(null);
    try {
      const pending = await getPendingSessions();
      setRows((pending || []).filter((item: any) => item?.meta?.approval?.required === true));
    } catch (err: any) {
      setError(err?.message || "Onay istekleri yüklenemedi.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load(true);
  }, [load]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter((row) => {
      const formData = row?.meta?.form_data || {};
      return [
        row?.phone,
        row?.mac,
        row?.ip,
        row?.ssid,
        row?.auth_method,
        ...Object.values(formData),
      ].some((value) => String(value ?? "").toLowerCase().includes(needle));
    });
  }, [query, rows]);

  const decide = async (id: string, decision: Decision) => {
    setDecisionId(id);
    setError(null);
    try {
      if (decision === "approve") await approveSession(id);
      else await rejectSession(id);
      setRows((current) => current.filter((row) => String(row.id) !== id));
    } catch (err: any) {
      setError(err?.message || "Onay işlemi tamamlanamadı.");
    } finally {
      setDecisionId(null);
    }
  };

  const total = rows.length;
  const displayed = filtered.length;

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Onay İstekleri
            </h2>
            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
              Yönetici Onayı
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Sözleşme onayı ve serbest formla başvuran misafirlerin yetkilendirme kuyruğu.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => void load()}
            disabled={refreshing}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${refreshing ? "animate-spin" : ""}`} />
            Yenile
          </button>
        </div>
      </div>

      {/* 2. Standard 4 KPI Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Bekleyen İstekler</span>
            <Clock3 className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{total}</span>
            <span className="text-xs text-slate-500">misafir</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Filtrelenen</span>
            <Search className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{displayed}</span>
            <span className="text-xs text-slate-500">kayıt</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Onay Yöntemi</span>
            <UserCheck className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-base font-bold text-slate-900 dark:text-white">Panel / E-Posta</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Güvenlik Kontrolü</span>
            <ShieldCheck className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-base font-bold text-slate-900 dark:text-white">5651 Uyumlu</span>
          </div>
        </div>
      </div>

      {/* 3. Search Bar */}
      <div className="rounded-xl border border-slate-200 bg-white p-2.5 shadow-xs dark:border-slate-800 dark:bg-slate-900 flex items-center gap-3">
        <Search className="h-4 w-4 text-slate-400 shrink-0 ml-2" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Telefon, ad soyad, MAC, IP veya form alanı ile hızlı arama yapın..."
          className="w-full bg-transparent text-xs text-slate-800 outline-none placeholder:text-slate-400 dark:text-slate-200"
        />
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs font-medium text-rose-700 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-400">
          {error}
        </div>
      )}

      {/* 4. Requests List */}
      {loading ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center text-xs text-slate-500 dark:border-slate-800 dark:bg-slate-900">
          Onay istekleri yükleniyor...
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center dark:border-slate-800 dark:bg-slate-900 space-y-2">
          <ShieldCheck className="mx-auto h-8 w-8 text-emerald-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Bekleyen Onay İsteği Yok</h3>
          <p className="text-xs text-slate-500">
            Yeni bir misafir sözleşme onayı veya serbest form doldurduğunda burada görünecektir.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((row) => {
            const formData =
              row?.meta?.form_data && typeof row.meta.form_data === "object" ? row.meta.form_data : {};
            const approval = row?.meta?.approval || {};
            const busy = decisionId === String(row.id);
            const guestName =
              formData.full_name ||
              formData.first_name ||
              formData.ad_soyad ||
              row.phone ||
              (row.mac ? `Misafir (${row.mac})` : "Misafir");
            const phone = row.phone || formData.phone || formData.gsm || formData.telefon;
            const tcNo = formData.tc_number || formData.tc_no || formData.tc;
            const dept =
              formData.department || formData.unit || formData.birim || formData.company || formData.firma;

            return (
              <article
                key={row.id}
                className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900 text-xs space-y-3"
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-2">
                      <UserCheck className="h-4 w-4 text-amber-500" />
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        {formatValue(guestName)}
                      </h3>
                      <span className="rounded-md border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[10px] font-semibold text-amber-700 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-300">
                        Bekliyor
                      </span>
                    </div>

                    <div className="grid grid-cols-1 gap-x-6 gap-y-1 text-slate-500 sm:grid-cols-2 pt-1">
                      <span>Talep Zamanı: {formatDate(row.started_at || row.created_at)}</span>
                      <span>
                        Yöntem: <strong className="text-slate-700 dark:text-slate-300">{row.auth_method || "—"}</strong>
                      </span>
                      <span>Telefon: {phone ? formatValue(phone) : "—"}</span>
                      {tcNo && (
                        <span>
                          T.C. Kimlik: <strong className="text-slate-700 dark:text-slate-300">{formatValue(tcNo)}</strong>
                        </span>
                      )}
                      {dept && (
                        <span>
                          Birim / Kurum: <strong className="text-slate-700 dark:text-slate-300">{formatValue(dept)}</strong>
                        </span>
                      )}
                      <span>
                        MAC / IP: <code>{row.mac || "—"}</code> / <code>{row.ip || "—"}</code>
                      </span>
                      <span>Lokasyon: {row.location_id || "Genel"}</span>
                      <span>Geçerlilik: {formatDate(approval.token_expires_at)}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => void decide(String(row.id), "approve")}
                      disabled={busy}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50 transition shadow-xs"
                    >
                      <CheckCircle className="h-3.5 w-3.5" /> Onayla
                    </button>
                    <button
                      type="button"
                      onClick={() => void decide(String(row.id), "reject")}
                      disabled={busy}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-rose-700 disabled:opacity-50 transition shadow-xs"
                    >
                      <XCircle className="h-3.5 w-3.5" /> Reddet
                    </button>
                  </div>
                </div>

                {/* Form Fields display */}
                {Object.keys(formData).length > 0 && (
                  <div className="border-t border-slate-100 pt-2.5 dark:border-slate-800">
                    <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Gönderilen Form Bilgileri
                    </div>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                      {Object.entries(formData).map(([key, value]) => (
                        <div
                          key={key}
                          className="rounded-lg border border-slate-100 bg-slate-50 p-2 dark:border-slate-800 dark:bg-slate-950"
                        >
                          <div className="text-[10px] font-semibold text-blue-600 dark:text-blue-400">
                            {getFieldLabel(key)}
                          </div>
                          <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5 truncate">
                            {formatValue(value)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
