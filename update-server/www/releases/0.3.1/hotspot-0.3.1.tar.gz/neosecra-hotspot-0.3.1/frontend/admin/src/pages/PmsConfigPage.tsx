import React, { useEffect, useState } from "react";
import {
  CheckCircle2,
  Database,
  Hotel,
  Plug,
  RefreshCw,
  Save,
  ShieldCheck,
  XCircle,
  Building,
  Check,
} from "lucide-react";
import {
  getPmsConfig,
  updatePmsConfig,
  testPmsConnection,
  getCustomSources,
} from "../lib/api";

type PmsConfig = {
  pms_type: string;
  host: string;
  port: number;
  username: string;
  api_key: string;
  password: string;
  db_host: string;
  db_port: number;
  db_name: string;
  db_user: string;
  db_password: string;
  is_active: boolean;
};

const EMPTY_CONFIG: PmsConfig = {
  pms_type: "mock",
  host: "",
  port: 443,
  username: "",
  api_key: "",
  password: "",
  db_host: "",
  db_port: 3306,
  db_name: "",
  db_user: "",
  db_password: "",
  is_active: false,
};

const PMS_VENDORS: Record<string, string> = {
  mock: "Demo / Mock Sağlayıcı",
  opera: "Oracle Opera PMS",
  elektra: "ElektraWeb",
  sispar: "Sispar Otel Otomasyonu",
  fidelio: "Fidelio (Micros)",
  otelplus: "OtelPlus",
  setur: "Setur Entegrasyonu",
  custom: "Özel Veri Kaynağı",
};

export const PmsConfigPage: React.FC = () => {
  const [config, setConfig] = useState<PmsConfig>(EMPTY_CONFIG);
  const [sourceCount, setSourceCount] = useState(0);
  const [testRoom, setTestRoom] = useState("101");
  const [testSurname, setTestSurname] = useState("DEMO");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [testResult, setTestResult] = useState<{ success: boolean; text: string } | null>(null);
  const [lastTestAt, setLastTestAt] = useState<string | null>(null);
  const [lastTestMode, setLastTestMode] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setNotice(null);
    try {
      const [saved, sources] = await Promise.all([
        getPmsConfig().catch(() => null),
        getCustomSources().catch(() => []),
      ]);
      setConfig({ ...EMPTY_CONFIG, ...(saved || {}), api_key: "", password: "", db_password: "" });
      setSourceCount(Array.isArray(sources) ? sources.length : 0);
    } catch (error: any) {
      setNotice({ type: "error", text: error?.message || "PMS ayarları yüklenemedi." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const patch = (next: Partial<PmsConfig>) => setConfig((current) => ({ ...current, ...next }));

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setNotice(null);
    try {
      const payload: Record<string, unknown> = {
        pms_type: config.pms_type,
        host: config.host || null,
        port: config.port || null,
        username: config.username || null,
        db_host: config.db_host || null,
        db_port: config.db_port || null,
        db_name: config.db_name || null,
        db_user: config.db_user || null,
        is_active: config.is_active,
      };
      if (config.api_key) payload.api_key = config.api_key;
      if (config.password) payload.password = config.password;
      if (config.db_password) payload.db_password = config.db_password;
      const saved = await updatePmsConfig(payload);
      setConfig((current) => ({ ...current, ...saved, api_key: "", password: "", db_password: "" }));
      setNotice({ type: "success", text: "PMS ayarları başarıyla kaydedildi." });
      setTimeout(() => setNotice(null), 3500);
    } catch (error: any) {
      setNotice({ type: "error", text: error?.message || "PMS ayarları kaydedilemedi." });
    } finally {
      setSaving(false);
    }
  };

  const test = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const result = await testPmsConnection(config.pms_type, testRoom, testSurname);
      setTestResult({
        success: Boolean(result?.verified ?? result?.success),
        text: result?.message || (result?.verified ? "Misafir kaydı doğrulandı." : "Misafir kaydı doğrulanamadı."),
      });
      setLastTestAt(new Date().toISOString());
      setLastTestMode(config.pms_type || "mock");
    } catch (error: any) {
      setTestResult({ success: false, text: error?.message || "PMS bağlantı testi başarısız." });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Otel / PMS Entegrasyonu
            </h2>
            <span
              className={`inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-[11px] font-medium border ${
                config.is_active
                  ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-900/50"
                  : "bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700"
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${config.is_active ? "bg-emerald-500" : "bg-slate-400"}`} />
              {config.is_active ? "PMS Aktif" : "PMS Devre Dışı"}
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Misafirlerin oda numarası ve soyadıyla doğrulanmasını sağlar ve FortiGate oturumuna bağlar.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={load}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
        </div>
      </div>

      {notice && (
        <div
          className={`flex items-center gap-2 rounded-xl border p-3 text-xs font-medium ${
            notice.type === "success"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-900/40 dark:bg-emerald-950/30 dark:text-emerald-300"
              : "border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-300"
          }`}
        >
          {notice.type === "success" ? <Check className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
          {notice.text}
        </div>
      )}

      {/* 2. 4-Tile KPI Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Entegrasyon Durumu</span>
            <Hotel className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white">
              {config.is_active ? "Etkin" : "Kapalı"}
            </span>
            <span className="text-[11px] text-slate-500">portal yöntemi</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">PMS Sağlayıcısı</span>
            <Building className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-base font-bold text-slate-900 dark:text-white truncate max-w-[170px]">
              {PMS_VENDORS[config.pms_type] || "Demo"}
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Özel Veri Kaynakları</span>
            <Database className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900 dark:text-white">{sourceCount}</span>
            <span className="text-[11px] text-slate-500">kayıtlı</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Son Doğrulama Testi</span>
            <ShieldCheck className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-sm font-bold text-slate-900 dark:text-white">
              {lastTestAt ? (testResult?.success ? "Başarılı" : "Hata") : "Test Edilmedi"}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Main Form & Test Widget Grid */}
      <div className="grid gap-6 lg:grid-cols-12 text-xs">
        {/* Settings Form (7 Cols) */}
        <form
          onSubmit={save}
          className="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">PMS Bağlantı Ayarları</h3>
            <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={config.is_active}
                onChange={(event) => patch({ is_active: event.target.checked })}
                className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
              />
              Portalda "Otel Odası" Girişini Aç
            </label>
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-slate-700 dark:text-slate-300">PMS Yazılımı / Sağlayıcı</label>
            <select
              value={config.pms_type}
              onChange={(event) => patch({ pms_type: event.target.value })}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
            >
              {Object.entries(PMS_VENDORS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">API / DB Host</label>
              <input
                value={config.host}
                onChange={(event) => patch({ host: event.target.value })}
                placeholder="pms.hotel.local"
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Port</label>
              <input
                type="number"
                min={1}
                value={config.port}
                onChange={(event) => patch({ port: Number(event.target.value) })}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">API Kullanıcı Adı</label>
              <input
                value={config.username}
                onChange={(event) => patch({ username: event.target.value })}
                autoComplete="off"
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">API Anahtarı / Şifre</label>
              <input
                type="password"
                value={config.api_key || config.password}
                onChange={(event) => patch({ api_key: event.target.value, password: "" })}
                autoComplete="new-password"
                placeholder="Değiştirmeyecekseniz boş bırakın"
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3 space-y-3 dark:border-slate-800 dark:bg-slate-950/40">
            <div className="font-semibold uppercase tracking-wider text-[10px] text-slate-500">
              Doğrudan Veritabanı Erişimi (Opsiyonel)
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label className="text-slate-600 dark:text-slate-400">DB Host</label>
                <input
                  value={config.db_host}
                  onChange={(event) => patch({ db_host: event.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600 dark:text-slate-400">DB Port</label>
                <input
                  type="number"
                  min={1}
                  value={config.db_port}
                  onChange={(event) => patch({ db_port: Number(event.target.value) })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600 dark:text-slate-400">DB Adı</label>
                <input
                  value={config.db_name}
                  onChange={(event) => patch({ db_name: event.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600 dark:text-slate-400">DB Kullanıcı</label>
                <input
                  value={config.db_user}
                  onChange={(event) => patch({ db_user: event.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="space-y-1 sm:col-span-2">
                <label className="text-slate-600 dark:text-slate-400">DB Şifresi</label>
                <input
                  type="password"
                  value={config.db_password}
                  onChange={(event) => patch({ db_password: event.target.value })}
                  autoComplete="new-password"
                  placeholder="Değiştirmeyecekseniz boş bırakın"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-blue-600 px-4 py-2 font-semibold text-white hover:bg-blue-700 transition disabled:opacity-60"
            >
              {saving ? "Kaydediliyor..." : "Ayarları Kaydet"}
            </button>
          </div>
        </form>

        {/* Test Widget & Info (5 Cols) */}
        <div className="lg:col-span-5 space-y-5">
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3 dark:border-slate-800">
              <ShieldCheck className="h-4 w-4 text-blue-600" />
              <h3 className="font-bold text-slate-900 dark:text-white">Misafir Doğrulama Testi</h3>
            </div>
            <p className="text-slate-500 text-[11px]">
              Oda numarası ve soyadıyla gerçek PMS sorgusunu simüle edin ve yanıtı kontrol edin.
            </p>

            <div className="space-y-2">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Oda Numarası</label>
                <input
                  value={testRoom}
                  onChange={(event) => setTestRoom(event.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Soyadı / Doğum Yılı</label>
                <input
                  value={testSurname}
                  onChange={(event) => setTestSurname(event.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={test}
              disabled={testing || !testRoom || !testSurname}
              className="w-full rounded-lg border border-slate-300 bg-white py-2 font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 flex items-center justify-center gap-1.5"
            >
              {testing ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Plug className="h-3.5 w-3.5" />}
              {testing ? "Test Ediliyor..." : "Doğrulamayı Test Et"}
            </button>

            {testResult && (
              <div
                className={`rounded-lg border p-2.5 text-xs ${
                  testResult.success
                    ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-emerald-300"
                    : "border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900/50 dark:bg-rose-950/20 dark:text-rose-300"
                }`}
              >
                {testResult.text}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
