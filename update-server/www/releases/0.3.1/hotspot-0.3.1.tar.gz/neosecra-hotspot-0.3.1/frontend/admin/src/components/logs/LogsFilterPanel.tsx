import React from 'react';
import type { SearchFilters, LogType } from '../../types/logs';

interface Props {
  filters: SearchFilters;
  onChange: (f: SearchFilters) => void;
  onApply: () => void;
  onClear: () => void;
}

const VENDORS = ['fortigate'];
// FortiGate emits traffic, event, UTM and subtype records. Keep the common
// subtypes available so the analyzer does not hide valid firewall events.
const LOG_TYPES = ['traffic', 'event', 'utm', 'iap', 'anomaly', 'vpn', 'webfilter', 'app-ctrl', 'dns'] as const;
const SEVERITIES = ['emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug'];
const ACTIONS = [
  'accept', 'deny', 'block', 'blocked', 'client-rst', 'server-rst', 'close', 'timeout',
  'auth', 'login', 'logout', 'tunnel-up', 'tunnel-down', 'admin-login', 'monitor',
];

function toggleListItem<T>(list: T[] | undefined, item: T): T[] {
  const arr = list ?? [];
  return arr.includes(item) ? arr.filter((x) => x !== item) : [...arr, item];
}

export const LogsFilterPanel: React.FC<Props> = ({ filters, onChange, onApply, onClear }) => {
  const set = (patch: Partial<SearchFilters>) => onChange({ ...filters, ...patch });

  return (
    <div className="space-y-5">
      {/* Vendor */}
      <div>
        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Vendor</label>
        <select
          value={filters.vendor ?? ''}
          onChange={(e) => set({ vendor: e.target.value || undefined })}
          className="mt-1 w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <option value="">Tümü</option>
          {VENDORS.map((v) => <option key={v} value={v}>{v}</option>)}
        </select>
      </div>

      {/* Log Type */}
      <div>
        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Log Türü</label>
        <div className="mt-1 space-y-1">
          {LOG_TYPES.map((lt) => (
            <label key={lt} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
              <input
                type="checkbox"
                checked={filters.log_type?.includes(lt) ?? false}
                onChange={() => set({ log_type: toggleListItem<LogType>(filters.log_type, lt) })}
                className="rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500"
              />
              {lt}
            </label>
          ))}
        </div>
      </div>

      {/* Severity */}
      <div>
        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Severity</label>
        <div className="mt-1 space-y-1">
          {SEVERITIES.map((s) => (
            <label key={s} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
              <input
                type="checkbox"
                checked={filters.severity?.includes(s) ?? false}
                onChange={() => set({ severity: toggleListItem(filters.severity, s) })}
                className="rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500"
              />
              {s}
            </label>
          ))}
        </div>
      </div>

      {/* Action */}
      <div>
        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Action</label>
        <div className="mt-1 space-y-1">
          {ACTIONS.map((a) => (
            <label key={a} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
              <input
                type="checkbox"
                checked={filters.action?.includes(a) ?? false}
                onChange={() => set({ action: toggleListItem(filters.action, a) })}
                className="rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500"
              />
              {a}
            </label>
          ))}
        </div>
      </div>

      {/* IPs */}
      <div className="space-y-2">
        <div>
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Kaynak IP</label>
          <input
            type="text"
            value={filters.src_ip ?? ''}
            onChange={(e) => set({ src_ip: e.target.value || undefined })}
            placeholder="10.0.0.1"
            className="mt-1 w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Hedef IP</label>
          <input
            type="text"
            value={filters.dst_ip ?? ''}
            onChange={(e) => set({ dst_ip: e.target.value || undefined })}
            placeholder="192.168.1.1"
            className="mt-1 w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Ports */}
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Src Port</label>
          <input
            type="number"
            value={filters.src_port ?? ''}
            onChange={(e) => set({ src_port: e.target.value ? Number(e.target.value) : null })}
            placeholder="443"
            className="mt-1 w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Dst Port</label>
          <input
            type="number"
            value={filters.dst_port ?? ''}
            onChange={(e) => set({ dst_port: e.target.value ? Number(e.target.value) : null })}
            placeholder="80"
            className="mt-1 w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* User */}
      <div>
        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Kullanıcı</label>
        <input
          type="text"
          value={filters.user ?? ''}
          onChange={(e) => set({ user: e.target.value || undefined })}
          placeholder="user@example.com"
          className="mt-1 w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
      </div>

      {/* Buttons */}
      <div className="space-y-2 pt-2">
        <button
          onClick={onApply}
          className="w-full px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-colors"
        >
          Filtreleri Uygula
        </button>
        <button
          onClick={onClear}
          className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
        >
          Temizle
        </button>
      </div>
    </div>
  );
};
