import React, { useState } from "react";
import { login, completeMfaLogin } from "../lib/api";
import { ShieldAlert, ShieldCheck, RefreshCw, KeyRound, Mail, ArrowLeft, Lock } from "lucide-react";

interface Props {
  onLoginSuccess: (user: any) => void;
}

export const LoginPage: React.FC<Props> = ({ onLoginSuccess }) => {
  const isDemoMode = String(import.meta.env.VITE_DEMO_MODE || "").toLowerCase() === "true";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // 2FA / OTP Challenge State
  const [mfaRequired, setMfaRequired] = useState(false);
  const [mfaSessionToken, setMfaSessionToken] = useState<string | null>(null);
  const [otpCode, setOtpCode] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setLoading(true);
    setErrorMsg(null);

    try {
      const res = await login(email, password);
      if (res?.mfa_required) {
        setMfaRequired(true);
        setMfaSessionToken(res.mfa_session_token);
        setErrorMsg(null);
        return;
      }
      onLoginSuccess(res);
    } catch (err: any) {
      setErrorMsg(err.message || "Giriş başarısız oldu. Lütfen bilgilerinizi kontrol edin.");
    } finally {
      setLoading(false);
    }
  };

  const handleMfaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mfaSessionToken || !otpCode) return;

    setLoading(true);
    setErrorMsg(null);

    try {
      const user = await completeMfaLogin(mfaSessionToken, otpCode.trim());
      onLoginSuccess(user);
    } catch (err: any) {
      setErrorMsg(err.message || "Doğrulama kodu hatalı veya süresi dolmuş.");
    } finally {
      setLoading(false);
    }
  };

  const handleBackToLogin = () => {
    setMfaRequired(false);
    setMfaSessionToken(null);
    setOtpCode("");
    setErrorMsg(null);
  };

  return (
    <div className="min-h-screen w-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 p-6 relative overflow-hidden font-sans">
      {/* Decorative background grids/blur blobs */}
      <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-blue-500/10 dark:bg-blue-500/5 blur-3xl" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-indigo-500/10 dark:bg-indigo-500/5 blur-3xl" />

      <div className="max-w-md w-full space-y-6 z-10 animate-fade-in">
        {/* Brand header */}
        <div className="text-center space-y-3">
          <div className="inline-flex bg-gradient-to-tr from-blue-600 to-indigo-600 text-white p-3.5 rounded-2xl shadow-lg shadow-blue-500/20 justify-center items-center">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black tracking-tight text-slate-950 dark:text-slate-50">
            NeoSecra Hotspot
          </h2>
          <p className="text-xs font-semibold text-slate-500">
            Yönetim &amp; 5651 Kriptografik Loglama Platformu
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-xl">
          {errorMsg && (
            <div className="mb-5 p-3.5 bg-rose-50 dark:bg-rose-950/30 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800/60 rounded-2xl text-xs font-bold flex items-start space-x-2 animate-shake">
              <ShieldAlert className="w-4 h-4 flex-shrink-0 text-rose-600 dark:text-rose-400 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {!mfaRequired ? (
            /* Standard Login Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">E-Posta Adresi</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@hotspot.io"
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Şifre</label>
                <div className="relative">
                  <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 inline-flex justify-center items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-sm transition disabled:opacity-50"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                {loading ? "Giriş Yapılıyor..." : "Giriş Yap"}
              </button>
            </form>
          ) : (
            /* 2FA / OTP Verification Form */
            <form onSubmit={handleMfaSubmit} className="space-y-5">
              <div className="text-center space-y-1.5 pb-1">
                <div className="inline-flex p-2.5 rounded-full bg-blue-50 dark:bg-blue-950/50 text-blue-600 mb-1">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  İki Faktörlü Doğrulama (2FA)
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Google Authenticator uygulamanızdaki 6 haneli tek kullanımlık doğrulama kodunu girin.
                </p>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block text-center">
                  6 Haneli OTP Doğrulama Kodu
                </label>
                <input
                  type="text"
                  maxLength={6}
                  autoFocus
                  required
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))}
                  placeholder="000000"
                  className="w-full text-center tracking-[0.4em] font-mono text-xl font-black py-3 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                />
              </div>

              <div className="space-y-2">
                <button
                  type="submit"
                  disabled={loading || otpCode.length < 6}
                  className="w-full inline-flex justify-center items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-sm transition disabled:opacity-50"
                >
                  {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                  {loading ? "Doğrulanıyor..." : "Doğrula & Giriş Yap"}
                </button>

                <button
                  type="button"
                  onClick={handleBackToLogin}
                  className="w-full inline-flex justify-center items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Şifre ile Girişe Geri Dön
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer info */}
        <div className="text-center text-xs text-slate-400">
          {isDemoMode && <p>Demo modu aktif: giriş akışı demo verisiyle çalışıyor.</p>}
          <p className="mt-1 font-mono text-[11px]">v1.0.0 · 5651 Yasal Uyumluluk ve Güvenlik Altyapısı</p>
        </div>
      </div>
    </div>
  );
};
