import React, { useState, useEffect } from "react";
import {
  getLogArchives,
  buildLogArchive,
  verifyLogChain,
  verifySingleArchive,
  downloadArchivePdf,
  downloadArchiveRaw,
  downloadArchiveZip,
  getCurrentCustomerId,
  signArchive,
  signAllArchives,
  sealTodayLogs,
  getSessions,
  getFirewallLogs,
} from "../lib/api";
import {
  Database,
  Plus,
  CheckCircle,
  Search,
  ShieldCheck,
  RefreshCw,
  PenSquare,
  Download,
  FileText,
  FileArchive,
  Layers,
  Lock,
  Calendar,
  AlertTriangle,
  FileCheck,
  Award,
  Clock,
  Eye,
  X,
  ExternalLink,
  UserCheck,
  Globe,
  Activity,
  Filter,
} from "lucide-react";

export const RECORD_TYPE_OPTIONS = [
  { value: "session_archive", label: "İç IP Dağıtım Logları (DHCP / Radius / Portal)" },
  { value: "raw_traffic", label: "Firewall / NAT Trafik Logları (5651)" },
  { value: "auth_event", label: "Kimlik & Kimlik Doğrulama Olayları" },
  { value: "raw_syslog", label: "Ham Güvenlik Duvarı Syslog Kayıtları" },
  { value: "raw_radius", label: "Radius / Muhasebe (Accounting) Logları" },
];

export const getRecordTypeBadge = (type: string) => {
  switch (type) {
    case "session_archive":
      return { label: "İç IP Dağıtım Logu", tone: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800" };
    case "raw_traffic":
      return { label: "NAT / Trafik Logu", tone: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800" };
    case "auth_event":
      return { label: "Doğrulama / Auth Logu", tone: "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800" };
    case "raw_syslog":
      return { label: "Firewall Syslog", tone: "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800" };
    case "raw_radius":
      return { label: "Radius Accounting", tone: "bg-cyan-50 text-cyan-700 border-cyan-200 dark:bg-cyan-950/40 dark:text-cyan-300 dark:border-cyan-800" };
    default:
      return { label: type, tone: "bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" };
  }
};

interface LogArchive {
  id: string;
  customerName: string;
  periodStart: string;
  periodEnd: string;
  date: string;
  chainSeq: number;
  recordType: string;
  recordCount: number;
  fileSizeKb: number;
  contentHash: string;
  currHash: string;
  prevHash: string;
  isSigned: boolean;
  signatureTime: string | null;
  signatureOrigin: string | null;
  signMethod: string | null;
}

export const LogsPage: React.FC = () => {
  const [archives, setArchives] = useState<LogArchive[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [recordTypeFilter, setRecordTypeFilter] = useState("all");
  const [activeTab, setActiveTab] = useState<"archives" | "search" | "chain" | "compliance">("archives");
  const [showAddForm, setShowAddForm] = useState(false);
  const [currentCustomerId, setCurrentCustomerId] = useState("");

  // Action states
  const [building, setBuilding] = useState(false);
  const [verifyingChain, setVerifyingChain] = useState(false);
  const [chainResult, setChainResult] = useState<any | null>(null);
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [singleVerifyResult, setSingleVerifyResult] = useState<{ id: string; ok: boolean; message: string } | null>(null);
  const [signingId, setSigningId] = useState<string | null>(null);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [sealingToday, setSealingToday] = useState(false);
  const [signingAll, setSigningAll] = useState(false);
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Log Viewer Modal state
  const [showViewerModal, setShowViewerModal] = useState(false);
  const [viewArchive, setViewArchive] = useState<{ archive: LogArchive; records: any[] } | null>(null);
  const [viewerLoading, setViewerLoading] = useState(false);
  const [viewerSearch, setViewerSearch] = useState("");

  // Forensic Search state
  const [forensicQuery, setForensicQuery] = useState({
    ip: "",
    port: "",
    userOrMac: "",
    dateFrom: "",
    dateTo: "",
  });
  const [forensicResults, setForensicResults] = useState<{ sessions: any[]; logs: any[] } | null>(null);
  const [searchingForensics, setSearchingForensics] = useState(false);

  const [formData, setFormData] = useState({
    customerId: "",
    date: new Date().toISOString().split("T")[0],
    recordType: "session_archive",
  });

  const loadArchives = async () => {
    setLoading(true);
    try {
      const archData = await getLogArchives();

      const mapped: LogArchive[] = (archData || []).map((a: any) => ({
        id: String(a.id),
        customerName: a.customer_name || "Kurumsal Müşteri",
        periodStart: a.period_start,
        periodEnd: a.period_end,
        date: a.period_start ? new Date(a.period_start).toLocaleDateString("tr-TR") : "—",
        chainSeq: Number(a.chain_seq ?? 1),
        recordType: a.record_type || "session_archive",
        recordCount: Number(a.item_count ?? 0),
        fileSizeKb: Math.round(Number(a.content_size ?? 0) / 1024),
        contentHash: String(a.content_hash || ""),
        currHash: String(a.curr_hash || ""),
        prevHash: String(a.prev_hash || ""),
        isSigned: Boolean(a.signature_value),
        signatureTime: a.signature_time || null,
        signatureOrigin: a.signature_origin || null,
        signMethod: a.sign_method || null,
      }));

      setArchives(mapped);
    } catch (err: any) {
      console.error("5651 archives fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadArchives();
  }, []);

  useEffect(() => {
    (async () => {
      const customerId = await getCurrentCustomerId();
      if (customerId) {
        setCurrentCustomerId(customerId);
        setFormData((prev) => (prev.customerId ? prev : { ...prev, customerId }));
      }
    })();
  }, []);

  const filteredArchives = archives.filter((a) => {
    const matchesSearch =
      !search ||
      a.customerName.toLowerCase().includes(search.toLowerCase()) ||
      a.contentHash.toLowerCase().includes(search.toLowerCase()) ||
      a.currHash.toLowerCase().includes(search.toLowerCase()) ||
      a.date.includes(search);

    const matchesType =
      recordTypeFilter === "all" || a.recordType === recordTypeFilter;

    return matchesSearch && matchesType;
  });

  const handleBuildArchive = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.date) return;

    setBuilding(true);
    setNotice(null);

    try {
      const start = new Date(formData.date);
      start.setHours(0, 0, 0, 0);
      const end = new Date(formData.date);
      end.setHours(23, 59, 59, 999);

      await buildLogArchive({
        ...(formData.customerId ? { customer_id: formData.customerId } : {}),
        period_start: start.toISOString(),
        period_end: end.toISOString(),
        record_type: formData.recordType || "session_archive",
      });

      setNotice({
        type: "success",
        text: `${formData.date} tarihli 5651 log arşivi başarıyla derlendi ve SHA-256 zincirine eklendi.`,
      });
      setShowAddForm(false);
      await loadArchives();
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "Arşiv oluşturulurken bir hata meydana geldi.",
      });
    } finally {
      setBuilding(false);
    }
  };

  const handleVerifyFullChain = async () => {
    setVerifyingChain(true);
    setChainResult(null);
    setNotice(null);

    try {
      const res = await verifyLogChain();
      setChainResult(res);
      const isOk = Boolean(res?.ok || res?.valid || res?.chain_valid);
      if (isOk) {
        setNotice({
          type: "success",
          text: `✓ ${res?.message || `Bütünlük zinciri doğrulandı: ${res?.total_records ?? archives.length} arşiv bloğunda hiçbir tahrifat veya eksiklik tespit edilmedi.`}`,
        });
      } else {
        setNotice({
          type: "error",
          text: `⚠️ Bütünlük uyarısı: ${res?.message || `${res?.broken_link_count ?? 1} blokta uyuşmazlık tespit edildi!`}`,
        });
      }
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "Zincir bütünlüğü denetlenirken hata oluştu.",
      });
    } finally {
      setVerifyingChain(false);
    }
  };

  const handleVerifySingle = async (id: string) => {
    setVerifyingId(id);
    try {
      const res = await verifySingleArchive(id);
      const ok = Boolean(res?.content_hash_valid && res?.chain_link_valid);
      setSingleVerifyResult({
        id,
        ok,
        message: ok
          ? "✓ İçerik SHA-256 özeti ve zincir bağlantısı doğrulandı. Tahrifat yok."
          : "⚠️ İçerik veya zincir bağlantısında uyuşmazlık!",
      });
    } catch (err: any) {
      setSingleVerifyResult({
        id,
        ok: false,
        message: err?.message || "Doğrulama başarısız oldu.",
      });
    } finally {
      setVerifyingId(null);
    }
  };

  const handleSignArchive = async (id: string) => {
    setSigningId(id);
    setNotice(null);
    try {
      await signArchive(id);
      setNotice({
        type: "success",
        text: "Arşiv zaman damgası / e-imza ile başarıyla mühürlendi.",
      });
      await loadArchives();
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "İmzalama başarısız oldu. KamuSM yapılandırmasını kontrol edin.",
      });
    } finally {
      setSigningId(null);
    }
  };

  const handleSealToday = async () => {
    setSealingToday(true);
    setNotice(null);
    try {
      const res = await sealTodayLogs(currentCustomerId || undefined);
      setNotice({
        type: "success",
        text: `✓ Bugünkü oturum ve güvenlik duvarı logları derlendi ve ${res?.length || 2} adet blok kriptografik olarak mühürlendi / imzalandı.`,
      });
      await loadArchives();
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "Canlı loglar mühürlenirken bir hata oluştu.",
      });
    } finally {
      setSealingToday(false);
    }
  };

  const handleSignAll = async () => {
    setSigningAll(true);
    setNotice(null);
    try {
      const res = await signAllArchives();
      setNotice({
        type: "success",
        text: `✓ ${res?.signed_count || 0} adet imzasız arşiv başarıyla TÜBİTAK/Yerel sertifika ile mühürlendi.`,
      });
      await loadArchives();
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "Toplu imzalama gerçekleştirilemedi.",
      });
    } finally {
      setSigningAll(false);
    }
  };

  const handleDownloadPdf = async (a: LogArchive) => {
    setDownloadingId(a.id);
    try {
      const blob = await downloadArchivePdf(a.id);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `5651_arsiv_${a.chainSeq}_${a.date.replace(/\./g, "-")}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "PDF raporu indirilemedi.",
      });
    } finally {
      setDownloadingId(null);
    }
  };

  const handleDownloadRaw = async (a: LogArchive) => {
    setDownloadingId(a.id);
    try {
      const blob = await downloadArchiveRaw(a.id);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `5651_raw_archive_${a.chainSeq}_${a.date.replace(/\./g, "-")}.jsonl`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "Ham arşiv dosyası indirilemedi.",
      });
    } finally {
      setDownloadingId(null);
    }
  };

  const handleDownloadZip = async (a: LogArchive) => {
    setDownloadingId(a.id);
    try {
      const blob = await downloadArchiveZip(a.id);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `5651_Delil_Paketi_${a.chainSeq}_${a.date.replace(/\./g, "-")}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "5651 ZIP Delil Paketi indirilemedi.",
      });
    } finally {
      setDownloadingId(null);
    }
  };

  const handleInspectArchive = async (a: LogArchive) => {
    setViewerLoading(true);
    setShowViewerModal(true);
    setViewArchive({ archive: a, records: [] });
    setViewerSearch("");
    try {
      const blob = await downloadArchiveRaw(a.id);
      const text = await blob.text();
      const parsed = text
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean)
        .map((line) => {
          try {
            return JSON.parse(line);
          } catch {
            return { raw: line };
          }
        });
      setViewArchive({ archive: a, records: parsed });
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "Arşiv kayıtları okunamadı.",
      });
    } finally {
      setViewerLoading(false);
    }
  };

  const handleForensicSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSearchingForensics(true);
    setForensicResults(null);
    try {
      const [sessionsRes, logsRes] = await Promise.all([
        getSessions({
          search: forensicQuery.userOrMac || forensicQuery.ip || undefined,
          page_size: 50,
        }).catch(() => []),
        getFirewallLogs({
          src_ip: forensicQuery.ip || undefined,
          dst_ip: forensicQuery.ip || undefined,
          src_port: forensicQuery.port ? parseInt(forensicQuery.port) : undefined,
          dst_port: forensicQuery.port ? parseInt(forensicQuery.port) : undefined,
          page_size: 50,
        }).catch(() => ({ logs: [] })),
      ]);

      const sessions = Array.isArray(sessionsRes) ? sessionsRes : (sessionsRes as any)?.sessions || [];
      const logs = Array.isArray(logsRes) ? logsRes : (logsRes as any)?.logs || (logsRes as any)?.records || [];

      setForensicResults({ sessions, logs });
    } catch (err: any) {
      setNotice({
        type: "error",
        text: err?.message || "Delil sorgusu sırasında hata oluştu.",
      });
    } finally {
      setSearchingForensics(false);
    }
  };


  const signedCount = archives.filter((a) => a.isSigned).length;
  const totalRecords = archives.reduce((sum, a) => sum + a.recordCount, 0);

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              5651 Log &amp; Kriptografik Arşiv
            </h2>
            <span className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <ShieldCheck className="h-3 w-3 text-emerald-500" />
              Mevzuat Uyumlu &amp; SHA-256 Mühürlü
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            İç IP dağıtım logları (DHCP/Radius/Portal) ve NAT trafik kayıtları günlük olarak SHA-256 özet zinciri ve TÜBİTAK KamuSM zaman damgasıyla saklanır.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {archives.some((a) => !a.isSigned) && (
            <button
              onClick={handleSignAll}
              disabled={signingAll}
              className="inline-flex items-center gap-1.5 rounded-lg border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/40 px-3 py-2 text-xs font-bold text-amber-800 dark:text-amber-300 hover:bg-amber-100 transition shadow-xs disabled:opacity-50"
              title="Sistemde henüz imzalanmamış tüm arşivleri tek tıkla mühürle"
            >
              <PenSquare className={`h-3.5 w-3.5 text-amber-600 ${signingAll ? "animate-spin" : ""}`} />
              {signingAll ? "İmzalanıyor..." : `Tümünü İmzala (${archives.filter((a) => !a.isSigned).length})`}
            </button>
          )}

          <button
            onClick={handleSealToday}
            disabled={sealingToday}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-emerald-700 transition disabled:opacity-50"
            title="Bugünün tüm canlı oturum ve güvenlik duvarı loglarını hemen mühürle ve imzala"
          >
            <ShieldCheck className={`h-3.5 w-3.5 ${sealingToday ? "animate-spin" : ""}`} />
            {sealingToday ? "Mühürleniyor..." : "Canlı Logları İmzala & Mühürle"}
          </button>

          <button
            onClick={handleVerifyFullChain}
            disabled={verifyingChain}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            <Lock className={`h-3.5 w-3.5 text-blue-600 ${verifyingChain ? "animate-pulse" : ""}`} />
            {verifyingChain ? "Bütünlük Denetleniyor..." : "Zinciri Doğrula"}
          </button>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <Plus className="h-3.5 w-3.5" />
            Özel Tarihli Derle
          </button>
        </div>
      </div>

      {/* 2. Standard 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Mühürlü Arşiv</span>
            <Database className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{archives.length}</span>
            <span className="text-xs text-slate-500">günlük dosya</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Zaman Damgalı</span>
            <Award className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{signedCount}</span>
            <span className="text-xs text-slate-500">KamuSM mühürlü</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Arşivlenen Kayıt</span>
            <FileText className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{totalRecords.toLocaleString("tr-TR")}</span>
            <span className="text-xs text-slate-500">oturum / NAT</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Bütünlük Durumu</span>
            <ShieldCheck className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">Doğrulandı</span>
            <span className="text-xs text-slate-500">Tahrifat yok</span>
          </div>
        </div>
      </div>

      {/* 3. Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-1">
        <div className="flex gap-1">
          <button
            onClick={() => setActiveTab("archives")}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold border-b-2 transition ${
              activeTab === "archives"
                ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            Günlük 5651 Arşivleri ({archives.length})
          </button>
          <button
            onClick={() => setActiveTab("search")}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold border-b-2 transition ${
              activeTab === "search"
                ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            Savcılık / BTK Delil Arama
          </button>
          <button
            onClick={() => setActiveTab("chain")}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold border-b-2 transition ${
              activeTab === "chain"
                ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Kriptografik Bütünlük Denetimi
          </button>
          <button
            onClick={() => setActiveTab("compliance")}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold border-b-2 transition ${
              activeTab === "compliance"
                ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            5651 Yasal Uyumluluk Kılavuzu
          </button>
        </div>
      </div>


      {/* Notice Banner */}
      {notice && (
        <div
          className={`p-4 rounded-2xl text-xs font-semibold flex justify-between items-center ${
            notice.type === "success"
              ? "bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800"
              : "bg-rose-50 text-rose-800 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800"
          }`}
        >
          <span>{notice.text}</span>
          <button
            onClick={() => setNotice(null)}
            className="text-slate-400 hover:text-slate-600 dark:hover:text-white"
          >
            ✕
          </button>
        </div>
      )}

      {/* Manual Build Archive Modal / Form */}
      {showAddForm && (
        <form
          onSubmit={handleBuildArchive}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 animate-in fade-in zoom-in-95 duration-200"
        >
          <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                5651 Zaman Damgalı Günlük Arşiv Derleme
              </h3>
              <p className="text-xs text-slate-500">
                Her gece otomatik çalışır, manuel tetikleme de yapabilirsiniz.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-xs text-slate-400 hover:text-slate-600"
            >
              Kapat
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400">Arşivlenecek Gün</label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400">Log Türü</label>
              <select
                value={formData.recordType}
                onChange={(e) => setFormData({ ...formData, recordType: e.target.value })}
                className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {RECORD_TYPE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400">Kurulum Müşterisi</label>
              <div className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-xs text-slate-500 font-mono">
                {currentCustomerId || "Otomatik atanır (VDATA)"}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={building}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center shadow-md shadow-blue-600/20"
            >
              {building && <RefreshCw className="w-3.5 h-3.5 mr-2 animate-spin" />}
              {building ? "İmzalanıyor ve Mühürleniyor..." : "Zaman Damgalı Arşiv Oluştur"}
            </button>
          </div>
        </form>
      )}

      {/* 🌟 Tab 1: Daily Archives Table */}
      {activeTab === "archives" && (
        <div className="space-y-4">
          {/* Filter and Search Bar */}
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Tarih, müşteri adı veya SHA-256 hash ile ara..."
                className="w-full pl-10 pr-4 py-2 bg-transparent text-xs focus:outline-none dark:text-white"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={recordTypeFilter}
                onChange={(e) => setRecordTypeFilter(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold"
              >
                <option value="all">Tüm Log Türleri</option>
                {RECORD_TYPE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>

              <button
                onClick={loadArchives}
                className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-blue-600 dark:hover:bg-slate-800"
                title="Yenile"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm">
            {loading ? (
              <div className="flex justify-center items-center py-16 space-x-2">
                <RefreshCw className="w-6 h-6 text-blue-500 animate-spin" />
                <span className="text-xs font-bold text-slate-500">5651 log arşivleri yükleniyor...</span>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs font-sans">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-950/50 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                      <th className="px-5 py-3.5">Blok / Sıra</th>
                      <th className="px-5 py-3.5">Arşiv Dönemi</th>
                      <th className="px-5 py-3.5">Log Türü</th>
                      <th className="px-5 py-3.5">Kayıt Hacmi</th>
                      <th className="px-5 py-3.5">SHA-256 İçerik Özeti</th>
                      <th className="px-5 py-3.5">Zaman Damgası Durumu</th>
                      <th className="px-5 py-3.5 text-right">Yasal İşlemler</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                    {filteredArchives.map((a) => {
                      const isVerifying = verifyingId === a.id;
                      const isSigning = signingId === a.id;
                      const isDownloading = downloadingId === a.id;
                      const verifyInfo = singleVerifyResult?.id === a.id ? singleVerifyResult : null;

                      return (
                        <tr
                          key={a.id}
                          className="hover:bg-slate-50/75 dark:hover:bg-slate-800/30 transition-colors"
                        >
                          <td className="px-5 py-4 font-mono font-bold text-slate-800 dark:text-slate-200">
                            #{a.chainSeq}
                          </td>

                          <td className="px-5 py-4 font-medium">
                            <div className="font-bold text-slate-900 dark:text-slate-100">{a.date}</div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              {new Date(a.periodStart).toLocaleTimeString("tr-TR")} -{" "}
                              {new Date(a.periodEnd).toLocaleTimeString("tr-TR")}
                            </div>
                          </td>

                          <td className="px-5 py-4">
                            {(() => {
                              const badge = getRecordTypeBadge(a.recordType);
                              return (
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold border ${badge.tone}`}>
                                  {badge.label}
                                </span>
                              );
                            })()}
                          </td>

                          <td className="px-5 py-4">
                            <div className="font-bold text-slate-800 dark:text-slate-200">
                              {a.recordCount.toLocaleString("tr-TR")} oturum
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              {a.fileSizeKb > 1024
                                ? `${(a.fileSizeKb / 1024).toFixed(2)} MB`
                                : `${a.fileSizeKb} KB`} (zstd)
                            </div>
                          </td>

                          <td className="px-5 py-4 font-mono text-[11px] text-slate-600 dark:text-slate-400">
                            <div
                              className="max-w-[180px] truncate font-bold text-slate-800 dark:text-slate-200 cursor-pointer"
                              title={`SHA-256 İçerik Özeti: ${a.contentHash}\nBlok Hash: ${a.currHash}\nÖnceki Blok: ${a.prevHash}`}
                            >
                              {a.contentHash}
                            </div>
                            <div className="text-[10px] text-slate-400 truncate max-w-[180px]">
                              Blok: {a.currHash.slice(0, 16)}...
                            </div>
                          </td>

                          <td className="px-5 py-4">
                            {a.isSigned ? (
                              <div className="space-y-0.5">
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200/50">
                                  <CheckCircle className="w-3 h-3 text-emerald-600" />
                                  {a.signatureOrigin === "kamusm"
                                    ? "KamuSM Mühürlü"
                                    : a.signatureOrigin === "localfile"
                                    ? "Yerel Sertifika"
                                    : "Kriptografik İmzalı"}
                                </span>
                                <div className="text-[10px] text-slate-400">
                                  {a.signatureTime
                                    ? new Date(a.signatureTime).toLocaleString("tr-TR")
                                    : "İmzalandı"}
                                </div>
                              </div>
                            ) : (
                              <div className="space-y-0.5">
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200/50">
                                  <Clock className="w-3 h-3 text-amber-600" />
                                  İmza Bekliyor
                                </span>
                              </div>
                            )}
                          </td>

                          <td className="px-5 py-4 text-right">
                            <div className="inline-flex items-center gap-1.5 justify-end">
                              {/* Gözat / Log Viewer */}
                              <button
                                onClick={() => handleInspectArchive(a)}
                                className="px-2.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-xs font-bold flex items-center gap-1 transition"
                                title="Arşiv Kayıtlarını Satır Satır Ekranda Görüntüle"
                              >
                                <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                                Gözat
                              </button>

                              {/* Single Verify */}
                              <button
                                onClick={() => handleVerifySingle(a.id)}
                                disabled={isVerifying}
                                className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 transition"
                                title="Kriptografik Bütünlüğü Doğrula"
                              >
                                <ShieldCheck className={`w-4 h-4 ${isVerifying ? "animate-spin" : ""}`} />
                              </button>

                              {/* Download PDF */}
                              <button
                                onClick={() => handleDownloadPdf(a)}
                                disabled={isDownloading}
                                className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center gap-1 transition"
                                title="Resmi 5651 PDF Raporu İndir"
                              >
                                <FileText className="w-3.5 h-3.5 text-rose-500" />
                                PDF
                              </button>

                              {/* Download Raw */}
                              <button
                                onClick={() => handleDownloadRaw(a)}
                                disabled={isDownloading}
                                className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center gap-1 transition"
                                title="Ham İmzalı Arşiv Dosyasını İndir (.jsonl.zst)"
                              >
                                <Download className="w-3.5 h-3.5 text-blue-500" />
                                Ham
                              </button>

                              {/* Download ZIP Package */}
                              <button
                                onClick={() => handleDownloadZip(a)}
                                disabled={isDownloading}
                                className="px-2.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-xs font-bold flex items-center gap-1 transition"
                                title="5651 Yasal Delil Paketini İndir (.ZIP - PDF + Ham Log + Kriptografik İmza + Bilirkişi Rehberi)"
                              >
                                <FileArchive className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                                ZIP Paketi
                              </button>

                              {/* Sign Button */}
                              {!a.isSigned && (
                                <button
                                  onClick={() => handleSignArchive(a.id)}
                                  disabled={isSigning}
                                  className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs transition"
                                  title="Zaman Damgası ile İmzala"
                                >
                                  <PenSquare className="w-3.5 h-3.5" />
                                  {isSigning ? "..." : "İmzala"}
                                </button>
                              )}
                            </div>

                            {/* Verification message popup under the row if active */}
                            {verifyInfo && (
                              <div
                                className={`text-[10px] font-bold mt-1 text-right ${
                                  verifyInfo.ok ? "text-emerald-600" : "text-rose-600"
                                }`}
                              >
                                {verifyInfo.message}
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}

                    {filteredArchives.length === 0 && (
                      <tr>
                        <td colSpan={7} className="px-6 py-16 text-center text-slate-500">
                          <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-3 text-slate-400">
                            <FileArchive className="w-6 h-6" />
                          </div>
                          <div className="font-bold text-sm text-slate-700 dark:text-slate-300">
                            5651 log arşivi bulunamadı
                          </div>
                          <p className="text-xs text-slate-400 mt-1">
                            Yukarıdaki "Günlük Arşiv Derle" butonunu kullanarak dilediğiniz günün arşivini anında mühürleyebilirsiniz.
                          </p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 🌟 Tab 2: Forensic & Court Evidence Search */}
      {activeTab === "search" && (
        <div className="space-y-6">
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Search className="w-4 h-4 text-blue-600" />
                  Savcılık / Emniyet / BTK 5651 Delil Sorgulama Motoru
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Adli veya idari soruşturmalarda talep edilen IP, Port, MAC veya T.C. Kimlik bilgisine ait oturum ve NAT trafik kayıtlarını saniyeler içinde bulun.
                </p>
              </div>
            </div>

            <form onSubmit={handleForensicSearch} className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">Hedef IP / Dış IP</label>
                <input
                  type="text"
                  placeholder="örn: 85.105.23.11"
                  value={forensicQuery.ip}
                  onChange={(e) => setForensicQuery({ ...forensicQuery, ip: e.target.value })}
                  className="mt-1 w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-850 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">Hedef Port / Kaynak Port</label>
                <input
                  type="text"
                  placeholder="örn: 443, 80, 54321"
                  value={forensicQuery.port}
                  onChange={(e) => setForensicQuery({ ...forensicQuery, port: e.target.value })}
                  className="mt-1 w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-850 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">Kullanıcı / T.C. / Tel / MAC</label>
                <input
                  type="text"
                  placeholder="örn: 12345678901, bc:24:11..."
                  value={forensicQuery.userOrMac}
                  onChange={(e) => setForensicQuery({ ...forensicQuery, userOrMac: e.target.value })}
                  className="mt-1 w-full px-3 py-2 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-850 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  disabled={searchingForensics}
                  className="w-full flex items-center justify-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition shadow-xs"
                >
                  <Search className={`w-3.5 h-3.5 ${searchingForensics ? "animate-spin" : ""}`} />
                  {searchingForensics ? "Sorgulanıyor..." : "Delil Kayıtlarını Ara"}
                </button>
              </div>
            </form>
          </div>

          {/* Forensic Results */}
          {forensicResults && (
            <div className="space-y-4 animate-in fade-in duration-200">
              {/* Matched Identity Sessions */}
              <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4 text-emerald-500" />
                    Eşleşen İç IP &amp; Kimlik Dağıtım Kayıtları ({forensicResults.sessions.length})
                  </h4>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50/80 text-[10px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                        <th className="px-3 py-2">Yerel IP</th>
                        <th className="px-3 py-2">MAC Adresi</th>
                        <th className="px-3 py-2">Kullanıcı / T.C. / Tel</th>
                        <th className="px-3 py-2">Başlangıç Zamanı</th>
                        <th className="px-3 py-2">Bitiş Zamanı</th>
                        <th className="px-3 py-2">Doğrulama Metodu</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {forensicResults.sessions.map((s, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                          <td className="px-3 py-2 font-mono font-bold text-blue-600">{s.ip_address || s.ip || "—"}</td>
                          <td className="px-3 py-2 font-mono text-slate-700 dark:text-slate-300">{s.mac_address || s.mac || "—"}</td>
                          <td className="px-3 py-2 font-medium text-slate-900 dark:text-white">{s.username || s.identity || s.phone || "—"}</td>
                          <td className="px-3 py-2 text-slate-500 font-mono">{s.started_at || s.created_at ? new Date(s.started_at || s.created_at).toLocaleString("tr-TR") : "—"}</td>
                          <td className="px-3 py-2 text-slate-500 font-mono">{s.ended_at ? new Date(s.ended_at).toLocaleString("tr-TR") : "Aktif Oturum"}</td>
                          <td className="px-3 py-2 text-slate-500 uppercase">{s.auth_method || "SMS OTP"}</td>
                        </tr>
                      ))}
                      {forensicResults.sessions.length === 0 && (
                        <tr>
                          <td colSpan={6} className="py-4 text-center text-slate-500">
                            Eşleşen oturum veya iç IP tahsis kaydı bulunamadı.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Matched Firewall NAT Records */}
              <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Globe className="w-4 h-4 text-blue-500" />
                    Eşleşen Firewall / NAT Trafik Kayıtları ({forensicResults.logs.length})
                  </h4>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50/80 text-[10px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                        <th className="px-3 py-2">Zaman</th>
                        <th className="px-3 py-2">Kaynak IP &amp; Port</th>
                        <th className="px-3 py-2">Hedef IP &amp; Port</th>
                        <th className="px-3 py-2">NAT Dış IP</th>
                        <th className="px-3 py-2">Eylem</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {forensicResults.logs.map((l, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                          <td className="px-3 py-2 font-mono text-slate-500">{l.event_time ? new Date(l.event_time).toLocaleString("tr-TR") : "—"}</td>
                          <td className="px-3 py-2 font-mono font-bold text-slate-800 dark:text-slate-200">{l.src_ip || l.srcip || "—"}:{l.src_port || l.srcport || "—"}</td>
                          <td className="px-3 py-2 font-mono font-bold text-blue-600">{l.dst_ip || l.dstip || "—"}:{l.dst_port || l.dstport || "—"}</td>
                          <td className="px-3 py-2 font-mono text-slate-600 dark:text-slate-400">{l.trans_ip || l.nat_ip || "—"}</td>
                          <td className="px-3 py-2 font-semibold text-emerald-600">{l.action || "allow"}</td>
                        </tr>
                      ))}
                      {forensicResults.logs.length === 0 && (
                        <tr>
                          <td colSpan={5} className="py-4 text-center text-slate-500">
                            Eşleşen güvenlik duvarı veya NAT trafik kaydı bulunamadı.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 🌟 Tab 3: Cryptographic Hash Chain Audit */}
      {activeTab === "chain" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-50 dark:bg-blue-950/40 text-blue-600 rounded-2xl">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    5651 Değiştirilemez Hash Zinciri & Blok Denetimi
                  </h3>
                  <p className="text-xs text-slate-500">
                    Her günlük arşiv bir önceki günün kriptografik SHA-256 özetine bağlanır. Geçmişe dönük log silinmesi veya değiştirilmesi zinciri anında kırar.
                  </p>
                </div>
              </div>

              <button
                onClick={handleVerifyFullChain}
                disabled={verifyingChain}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-xs font-bold shadow-md shadow-blue-600/20"
              >
                {verifyingChain ? "Denetleniyor..." : "Bütünlüğü Şimdi Denetle"}
              </button>
            </div>

            {/* Visual Blockchain Style Blocks */}
            <div className="space-y-4 pt-2">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 flex items-center justify-center font-bold font-mono">
                    #0
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">GENESIS BLOCK (Başlangıç Düğümü)</div>
                    <div className="text-[10px] text-slate-400 font-mono">0000000000000000000000000000000000000000000000000000000000000000</div>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">
                  ✓ Doğrulandı
                </span>
              </div>

              {archives.map((a) => (
                <div
                  key={a.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs hover:border-blue-300 transition"
                >
                  <div className="flex items-start md:items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold font-mono shrink-0">
                      #{a.chainSeq}
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white text-sm">{a.date} Arşivi</span>
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-300 font-mono">
                          {a.recordCount} Oturum Kaydı
                        </span>
                      </div>
                      <div className="font-mono text-[10px] text-slate-500 space-y-0.5">
                        <div>Önceki Hash: <span className="text-slate-400">{a.prevHash}</span></div>
                        <div>İçerik Hash: <span className="text-blue-600 dark:text-blue-400 font-bold">{a.contentHash}</span></div>
                        <div>Mühür Hash: <span className="text-slate-700 dark:text-slate-300">{a.currHash}</span></div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end md:self-center shrink-0">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200/40">
                      ✓ Zincir Bağlantısı Tam
                    </span>
                    <button
                      onClick={() => handleDownloadPdf(a)}
                      className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold"
                    >
                      PDF Raporu
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 🌟 Tab 4: Legal Compliance Guide */}
      {activeTab === "compliance" && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 text-amber-600 rounded-2xl">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                5651 Sayılı Kanun ve Toplu Kullanım Sağlayıcı Yükümlülükleri
              </h3>
              <p className="text-xs text-slate-500">
                Otel, kafe, restoran, yurt, kampüs ve kurumsal Wi-Fi işleten tüm kurumların yasal sorumlulukları.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-sans">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-2">
              <h4 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                <span className="text-blue-600">1.</span> İç IP Dağıtım Loglarının Tutulması
              </h4>
              <p>
                Kullanıcıların yerel ağda hangi IP ve MAC adresini hangi tarih-saat aralığında kullandığı, T.C. Kimlik No, Pasaport veya SMS doğrulama kaydıyla birlikte eşleştirilerek saklanmalıdır. NeoSecra bu eşleştirmeyi her oturumda otomatik yapar.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-2">
              <h4 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                <span className="text-emerald-600">2.</span> Zaman Damgası ile Günlük Mühürleme
              </h4>
              <p>
                Oluşturulan log dosyalarının geriye dönük değiştirilmediğini kanıtlamak için Yerel Kriptografik Sertifika veya TÜBİTAK KamuSM / RFC 3161 zaman damgasıyla her gün mühürlenmesi zorunludur.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-2">
              <h4 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                <span className="text-amber-600">3.</span> En Az İki Yıl Saklama Süresi
              </h4>
              <p>
                Loglar en az 2 yıl boyunca tahrifata karşı korumalı (WORM / Object Lock) olarak saklanmalı ve yetkili kolluk kuvveti veya savcılık talebi halinde eksiksiz ibraz edilebilmelidir.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-2">
              <h4 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                <span className="text-rose-600">4.</span> Adli Delil İbraz Paketi (ZIP/PDF)
              </h4>
              <p>
                Resmi makamlar bir IP/MAC adresiyle ilgili soruşturma başlattığında, tek tıkla o döneme ait zaman damgalı PDF raporu ve ham log dosyası adli paket olarak ihraç edilebilir.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 🌟 Log Viewer Modal */}
      {showViewerModal && viewArchive && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-5xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Arşiv #{viewArchive.archive.chainSeq} Kayıt Gözatıcı ({viewArchive.archive.date})
                  </h3>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${getRecordTypeBadge(viewArchive.archive.recordType).tone}`}>
                    {getRecordTypeBadge(viewArchive.archive.recordType).label}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5 font-mono">
                  SHA-256: {viewArchive.archive.contentHash.slice(0, 32)}...
                </p>
              </div>

              <button
                onClick={() => setShowViewerModal(false)}
                className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search filter in viewer */}
            <div className="p-3 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5" />
                <input
                  type="text"
                  placeholder="Arşiv içeriğinde IP, MAC, Kullanıcı veya Port ara..."
                  value={viewerSearch}
                  onChange={(e) => setViewerSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-5">
              {viewerLoading ? (
                <div className="flex justify-center items-center py-24 space-x-2 text-slate-500 text-xs font-semibold">
                  <RefreshCw className="w-5 h-5 text-blue-500 animate-spin" />
                  <span>Kriptografik arşiv çözülüyor ve kayıtlar yükleniyor...</span>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs font-sans">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-950/50 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                        <th className="px-3 py-2">#</th>
                        <th className="px-3 py-2">IP / Kaynak</th>
                        <th className="px-3 py-2">MAC / Hedef</th>
                        <th className="px-3 py-2">Kullanıcı / Detay</th>
                        <th className="px-3 py-2">Zaman Aralığı</th>
                        <th className="px-3 py-2 text-right">Veri Hacmi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {viewArchive.records
                        .filter((r) => {
                          if (!viewerSearch) return true;
                          const s = JSON.stringify(r).toLowerCase();
                          return s.includes(viewerSearch.toLowerCase());
                        })
                        .slice(0, 200)
                        .map((r, i) => (
                          <tr key={i} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                            <td className="px-3 py-2 font-mono text-slate-400">{i + 1}</td>
                            <td className="px-3 py-2 font-mono font-bold text-slate-800 dark:text-slate-200">
                              {r.ip_address || r.ip || r.src_ip || r.srcip || "—"}
                              {r.src_port ? `:${r.src_port}` : ""}
                            </td>
                            <td className="px-3 py-2 font-mono text-slate-600 dark:text-slate-400">
                              {r.mac_address || r.mac || r.dst_ip || r.dstip || "—"}
                              {r.dst_port ? `:${r.dst_port}` : ""}
                            </td>
                            <td className="px-3 py-2 text-slate-700 dark:text-slate-300">
                              {r.username || r.identity || r.phone || r.user || r.log_type || "Misafir Oturumu"}
                            </td>
                            <td className="px-3 py-2 font-mono text-slate-500 text-[11px]">
                              {r.started_at || r.event_time || r.timestamp ? new Date(r.started_at || r.event_time || r.timestamp).toLocaleTimeString("tr-TR") : "—"}
                            </td>
                            <td className="px-3 py-2 font-mono text-right text-slate-600 dark:text-slate-400">
                              {r.bytes_total ? `${(r.bytes_total / 1024).toFixed(1)} KB` : "—"}
                            </td>
                          </tr>
                        ))}
                      {viewArchive.records.length === 0 && (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-500 text-xs">
                            Arşiv içinde kayıt bulunamadı.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 flex justify-between items-center text-xs">
              <span className="text-slate-500">
                Toplam Kayıt: <strong className="text-slate-800 dark:text-slate-200">{viewArchive.records.length}</strong>
              </span>
              <button
                onClick={() => setShowViewerModal(false)}
                className="px-4 py-1.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl font-bold"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

