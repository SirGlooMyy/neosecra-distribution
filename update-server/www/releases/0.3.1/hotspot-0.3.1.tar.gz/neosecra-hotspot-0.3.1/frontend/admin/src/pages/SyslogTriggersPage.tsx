import React, { useState, useEffect } from "react";
import { getSyslogTriggers, getSyslogTriggerStats, createTrigger, updateTrigger, deleteTrigger, getTriggerEvents, acknowledgeEvent } from "../lib/api";
import { Plus, Edit3, Trash2, CheckCircle2, XCircle, Bell, AlertTriangle, Activity, RefreshCw } from "lucide-react";

const MATCH_TYPES = ["keyword", "regex", "severity"];
const CHANNELS = ["email", "sms", "webhook"];

const formatChannelConfig = (channel: string, config: any): string => {
  if (!config) return "";
  if (typeof config === "string") {
    try {
      return formatChannelConfig(channel, JSON.parse(config));
    } catch {
      return config;
    }
  }
  if (channel === "email") {
    if (Array.isArray(config.to)) return config.to.join(", ");
    return config.to || "";
  }
  if (channel === "sms") {
    return config.phone || "";
  }
  if (channel === "webhook") {
    return config.url || "";
  }
  return JSON.stringify(config, null, 2);
};

const parseChannelConfig = (channel: string, value: string): Record<string, any> => {
  const raw = value.trim();
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object") return parsed;
  } catch {
    // fall through to channel-specific parsing
  }
  if (channel === "email") {
    const to = raw.split(/[,\n;]/).map((item) => item.trim()).filter(Boolean);
    return { to };
  }
  if (channel === "sms") {
    return { phone: raw };
  }
  if (channel === "webhook") {
    return { url: raw };
  }
  return { value: raw };
};

export const SyslogTriggersPage: React.FC = () => {
  const [triggers, setTriggers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingTrigger, setEditingTrigger] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"triggers" | "events">("triggers");
  const [events, setEvents] = useState<any[]>([]);
  const [triggerStats, setTriggerStats] = useState<any | null>(null);
  const [form, setForm] = useState({ name: "", match_type: "keyword", pattern: "", severity_threshold: "", channel: "email", channel_config: "", cooldown_minutes: 15, is_active: true });

  const loadAll = async () => {
    setLoading(true);
    try {
      const [triggerData, statsData, eventData] = await Promise.all([
        getSyslogTriggers(),
        getSyslogTriggerStats(),
        getTriggerEvents(),
      ]);
      setTriggers(Array.isArray(triggerData) ? triggerData : []);
      setTriggerStats(statsData || null);
      setEvents(Array.isArray(eventData) ? eventData : []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadAll(); }, []);

  const openCreate = () => {
    setEditingTrigger(null);
    setForm({ name: "", match_type: "keyword", pattern: "", severity_threshold: "", channel: "email", channel_config: "", cooldown_minutes: 15, is_active: true });
    setShowModal(true);
  };

  const openEdit = (t: any) => {
    setEditingTrigger(t);
    setForm({
      name: t.name,
      match_type: t.match_type,
      pattern: t.pattern || t.match_pattern || "",
      severity_threshold: t.severity_threshold || "",
      channel: t.channel,
      channel_config: formatChannelConfig(t.channel, t.channel_config),
      cooldown_minutes: t.cooldown_minutes,
      is_active: t.is_active,
    });
    setShowModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...form,
      severity_threshold: form.severity_threshold || null,
      channel_config: parseChannelConfig(form.channel, form.channel_config),
    };
    try {
      if (editingTrigger) {
        const updated = await updateTrigger(editingTrigger.id, payload);
        setTriggers(triggers.map(t => t.id === editingTrigger.id ? updated : t));
      } else {
        const created = await createTrigger(payload);
        setTriggers([created, ...triggers]);
      }
      setShowModal(false);
    } catch (err) { console.error(err); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Bu tetikleyiciyi silmek istediğinize emin misiniz?")) return;
    try {
      await deleteTrigger(id);
      setTriggers(triggers.filter(t => t.id !== id));
    } catch (err) { console.error(err); }
  };

  const handleAcknowledge = async (id: string) => {
    try {
      await acknowledgeEvent(id);
      setEvents(events.map(e => e.id === id ? { ...e, acknowledged: true, acknowledged_at: new Date().toISOString() } : e));
    } catch (err) { console.error(err); }
  };

  const summary = {
    total: triggerStats?.total_triggers ?? triggers.length,
    active: triggerStats?.active_triggers ?? triggers.filter((t) => t.is_active).length,
    eventsToday: triggerStats?.total_events ?? 0,
    lastTriggered: (triggerStats?.triggers || []).filter((t: any) => t.last_event).sort((a: any, b: any) => new Date(b.last_event).getTime() - new Date(a.last_event).getTime())[0],
  };

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Syslog Tetikleyicileri
            </h2>
            <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700 dark:border-slate-750 dark:bg-slate-800 dark:text-slate-300">
              <Bell className="h-3 w-3 text-blue-500" />
              Otomatik Uyarı Kuralları
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Firewall loglarında anahtar kelime, regex veya önem seviyesine göre anlık e-posta, SMS ve webhook bildirimleri üretin.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadAll}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
          {activeTab === "triggers" && (
            <button
              onClick={openCreate}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
            >
              <Plus className="h-3.5 w-3.5" /> Yeni Tetikleyici
            </button>
          )}
        </div>
      </div>

      {/* 2. Standard 4 KPI Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Tetikleyici</span>
            <Bell className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{summary.total}</span>
            <span className="text-xs text-slate-500">kural</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Aktif Kurallar</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{summary.active}</span>
            <span className="text-xs text-slate-500">aktif</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Bugünkü Olaylar</span>
            <Activity className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{summary.eventsToday}</span>
            <span className="text-xs text-slate-500">tetiklenme</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Son Tetiklenme</span>
            <AlertTriangle className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-base font-bold text-slate-900 dark:text-white">
              {summary.lastTriggered ? new Date(summary.lastTriggered.last_event).toLocaleTimeString("tr-TR") : "—"}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2 text-xs">
        <button
          onClick={() => setActiveTab("triggers")}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold transition ${
            activeTab === "triggers"
              ? "bg-blue-600 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          }`}
        >
          <Bell className="h-3.5 w-3.5" /> Tetikleyici Kuralları
        </button>
        <button
          onClick={() => setActiveTab("events")}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold transition ${
            activeTab === "events"
              ? "bg-blue-600 text-white shadow-xs"
              : "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          }`}
        >
          <Activity className="h-3.5 w-3.5" /> Olay Kayıtları &amp; Bildirimler
        </button>
      </div>

      {activeTab === "triggers" && (
        <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
          {loading ? (
            <div className="flex justify-center items-center py-12 space-x-2">
              <RefreshCw className="w-6 h-6 text-indigo-500 animate-spin" />
              <span className="text-sm font-medium text-slate-500">Yükleniyor...</span>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Ad</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Eşleşme Tipi</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Desen</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Kanal</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Bekleme (dk)</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Durum</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {triggers.map((t) => (
                    <tr key={t.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-slate-900 dark:text-slate-100">{t.name}</td>
                      <td className="px-6 py-4 text-sm">{t.match_type === "keyword" ? "Anahtar Kelime" : t.match_type === "regex" ? "Regex" : "Severity"}</td>
                      <td className="px-6 py-4 text-sm font-mono text-xs text-slate-500 max-w-[200px] truncate">{t.pattern || t.match_pattern || t.severity_threshold || "-"}</td>
                      <td className="px-6 py-4 text-sm">{t.channel === "webhook" ? "Webhook" : t.channel === "sms" ? "SMS" : "E-Posta"}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">
                        <div className="flex flex-col">
                          <span>{t.cooldown_minutes} dk</span>
                          <span className="text-[11px] text-slate-400">{t.last_triggered_at ? `Son: ${new Date(t.last_triggered_at).toLocaleString("tr-TR")}` : "Henüz tetiklenmedi"}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${t.is_active ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30" : "bg-slate-100 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700"}`}>
                          {t.is_active ? "Aktif" : "Pasif"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right space-x-1">
                        <button onClick={() => openEdit(t)} className="inline-flex items-center p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl transition-colors">
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(t.id)} className="inline-flex items-center p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {triggers.length === 0 && (
                    <tr><td colSpan={7} className="px-6 py-12 text-center text-slate-500">Henüz tetikleyici tanımlanmamış.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === "events" && (
        <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Zaman</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Mesaj</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Bildirim</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Durum</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {events.map((e) => (
                  <tr key={e.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                    <td className="px-6 py-4 text-sm text-slate-500">{new Date(e.timestamp || e.triggered_at).toLocaleString("tr-TR")}</td>
                    <td className="px-6 py-4 text-sm text-slate-800 dark:text-slate-200">
                      <div className="space-y-1">
                        <div className="font-medium">{e.trigger_name || e.title || "Alarm"}</div>
                        <div className="text-slate-500">{e.message}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <div className="flex flex-col gap-1">
                        <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">{e.delivery_channel || "—"}</span>
                        <span className="text-[11px] text-slate-400">{e.delivery_target || "-"}</span>
                        <span className={`text-[10px] uppercase font-bold ${e.delivery_status === 'sent' ? 'text-emerald-600 dark:text-emerald-400' : e.delivery_status === 'failed' ? 'text-rose-600 dark:text-rose-400' : 'text-amber-600 dark:text-amber-400'}`}>
                          {e.delivery_status || 'pending'}
                        </span>
                        {e.delivery_detail && <span className="text-[11px] text-slate-400 max-w-[16rem] truncate" title={e.delivery_detail}>{e.delivery_detail}</span>}
                        {e.delivered_at && <span className="text-[11px] text-slate-400">{new Date(e.delivered_at).toLocaleString("tr-TR")}</span>}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {e.acknowledged ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30">
                          <CheckCircle2 className="w-3 h-3 mr-1" /> Onaylandı
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 border border-amber-100 dark:border-amber-900/30">
                          <AlertTriangle className="w-3 h-3 mr-1" /> Bekliyor
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      {!e.acknowledged && (
                        <button onClick={() => handleAcknowledge(e.id)} className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 rounded-xl transition-colors">
                          <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Onayla
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {events.length === 0 && (
                  <tr><td colSpan={5} className="px-6 py-12 text-center text-slate-500">Henüz tetiklenen olay yok.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              {editingTrigger ? "Tetikleyici Düzenle" : "Yeni Tetikleyici"}
            </h3>
            <form onSubmit={handleSave} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Tetikleyici Adı</label>
                <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Eşleşme Tipi</label>
                <select value={form.match_type} onChange={(e) => setForm({ ...form, match_type: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="keyword">Anahtar Kelime (Keyword)</option>
                  <option value="regex">Regex</option>
                  <option value="severity">Severity Eşleşmesi</option>
                </select>
              </div>
              {form.match_type !== "severity" ? (
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Desen / Anahtar Kelime</label>
                  <input type="text" required value={form.pattern} onChange={(e) => setForm({ ...form, pattern: e.target.value })}
                    placeholder={form.match_type === "regex" ? "Örn: HA.*(failover|switch)" : "Örn: CPU usage"}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              ) : (
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Severity Eşiği</label>
                  <select value={form.severity_threshold} onChange={(e) => setForm({ ...form, severity_threshold: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="emergency">Emergency</option>
                    <option value="alert">Alert</option>
                    <option value="critical">Critical</option>
                    <option value="error">Error</option>
                    <option value="warning">Warning</option>
                    <option value="notice">Notice</option>
                  </select>
                </div>
              )}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Bildirim Kanalı</label>
                <select value={form.channel} onChange={(e) => setForm({ ...form, channel: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="email">E-Posta</option>
                  <option value="sms">SMS</option>
                  <option value="webhook">Webhook</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">{form.channel === "email" ? "E-Posta Adres(ler)i" : form.channel === "sms" ? "Telefon Numarası" : "Webhook URL"}</label>
                <input type="text" required value={form.channel_config} onChange={(e) => setForm({ ...form, channel_config: e.target.value })}
                  placeholder={form.channel === "email" ? "örn: it@hotspot.local" : form.channel === "sms" ? "örn: +905321112233" : "örn: https://hooks.slack.com/..."}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Bekleme Süresi (dakika)</label>
                <input type="number" value={form.cooldown_minutes} onChange={(e) => setForm({ ...form, cooldown_minutes: Number(e.target.value) })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                <input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
                  className="rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500" />
                Aktif
              </label>
              <div className="flex justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800">İptal</button>
                <button type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold">
                  {editingTrigger ? "Güncelle" : "Oluştur"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
