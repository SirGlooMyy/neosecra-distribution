import React, { useState } from "react";
import {
  Zap,
  MapPin,
  Shield,
  Sliders,
  CheckCircle2,
  Copy,
  ExternalLink,
  ChevronRight,
  ChevronLeft,
  Wifi,
  Server,
  Lock,
  Smartphone,
  UserCheck,
  Hotel,
  Ticket,
  AlertCircle,
} from "lucide-react";
import { request } from "../lib/api";

interface QuickSetupResult {
  success: boolean;
  message: string;
  location_id: string;
  location_name: string;
  device_id: string;
  group_id: string;
  portal_id: string;
  portal_url: string;
  radius_server_ip: string;
  radius_auth_port: number;
  radius_acct_port: number;
  radius_shared_secret: string;
  cli_snippet: string;
  instructions: string[];
}

export const QuickSetupWizardPage: React.FC = () => {
  const [step, setStep] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [result, setResult] = useState<QuickSetupResult | null>(null);

  // Form State
  const [locationName, setLocationName] = useState<string>("Merkez Şube");
  const [capacityProfile, setCapacityProfile] = useState<string>("medium");
  const [gatewayType, setGatewayType] = useState<string>("fortigate");
  const [gatewayIp, setGatewayIp] = useState<string>("192.168.1.1");
  const [sharedSecret, setSharedSecret] = useState<string>("RadiusSecret123!");

  // Step 2: Auth & QoS
  const [authMethods, setAuthMethods] = useState<string[]>([
    "tc_sms",
    "sms",
    "pms",
    "voucher",
    "free",
  ]);
  const [sessionTimeout, setSessionTimeout] = useState<number>(120);
  const [downloadSpeed, setDownloadSpeed] = useState<number>(10);
  const [uploadSpeed, setUploadSpeed] = useState<number>(2);
  const [dailyQuota, setDailyQuota] = useState<number>(2048);
  const [enable5651, setEnable5651] = useState<boolean>(true);

  // Step 3: Portal
  const [portalTitle, setPortalTitle] = useState<string>("Hoş Geldiniz");
  const [portalWelcome, setPortalWelcome] = useState<string>(
    "Güvenli internet erişimi için lütfen doğrulama yöntemini seçerek giriş yapınız."
  );

  const toggleAuthMethod = (method: string) => {
    if (authMethods.includes(method)) {
      if (authMethods.length > 1) {
        setAuthMethods(authMethods.filter((m) => m !== method));
      }
    } else {
      setAuthMethods([...authMethods, method]);
    }
  };

  const handleCopyCli = () => {
    if (!result?.cli_snippet) return;
    navigator.clipboard.writeText(result.cli_snippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCompleteSetup = async () => {
    setLoading(true);
    setError(null);
    try {
      const payload = {
        location_name: locationName,
        capacity_profile: capacityProfile,
        gateway_type: gatewayType,
        gateway_ip: gatewayIp,
        shared_secret: sharedSecret,
        auth_methods: authMethods,
        session_timeout_minutes: sessionTimeout,
        download_speed_mbps: downloadSpeed,
        upload_speed_mbps: uploadSpeed,
        daily_data_quota_mb: dailyQuota,
        portal_title: portalTitle,
        portal_welcome_text: portalWelcome,
        enable_5651_sealing: enable5651,
      };

      const res = await request("/system/quick-setup", {
        method: "POST",
        body: JSON.stringify(payload),
      });

      setResult(res);
      setStep(4);
    } catch (err: any) {
      setError(err?.message || "Hızlı kurulum işlemi sırasında bir hata oluştu.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-1 border-b border-slate-200 pb-5 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <div className="rounded-lg bg-indigo-600 p-2 text-white shadow-md shadow-indigo-500/20">
            <Zap className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Hızlı Kurulum & Dağıtım Sihirbazı (3 Adımda Yayına Al)
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Yeni bir otel, kafe veya işletme ağını RADIUS, 5651 mühürleme ve karşılama portalı ile dakikalar içinde kurun.
            </p>
          </div>
        </div>
      </div>

      {/* Stepper Bar */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { num: 1, label: "Lokasyon & Ağ Cihazı", icon: MapPin },
          { num: 2, label: "Kimlik & Hız (QoS)", icon: Sliders },
          { num: 3, label: "Karşılama Portalı", icon: Shield },
          { num: 4, label: "Canlı Yayın & CLI", icon: CheckCircle2 },
        ].map((s) => {
          const Icon = s.icon;
          const isDone = step > s.num;
          const isCurrent = step === s.num;
          return (
            <div
              key={s.num}
              className={`flex items-center gap-2 rounded-xl border p-3 transition-all ${
                isCurrent
                  ? "border-indigo-600 bg-indigo-50/50 text-indigo-700 dark:border-indigo-500 dark:bg-indigo-950/20 dark:text-indigo-300"
                  : isDone
                  ? "border-emerald-200 bg-emerald-50/30 text-emerald-700 dark:border-emerald-800/40 dark:bg-emerald-950/10 dark:text-emerald-300"
                  : "border-slate-200 bg-slate-50/50 text-slate-400 dark:border-slate-800 dark:bg-slate-900/30"
              }`}
            >
              <div
                className={`flex h-7 w-7 items-center justify-center rounded-lg text-xs font-bold ${
                  isCurrent
                    ? "bg-indigo-600 text-white shadow-sm"
                    : isDone
                    ? "bg-emerald-600 text-white"
                    : "bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400"
                }`}
              >
                {isDone ? <CheckCircle2 className="h-4 w-4" /> : s.num}
              </div>
              <div className="hidden flex-col sm:flex">
                <span className="text-[11px] font-bold leading-tight">{s.label}</span>
                <span className="text-[9px] text-slate-400">Adım {s.num}</span>
              </div>
            </div>
          );
        })}
      </div>

      {error && (
        <div className="flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 p-4 text-xs font-medium text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/20 dark:text-rose-300">
          <AlertCircle className="h-4 w-4 shrink-0 text-rose-500" />
          {error}
        </div>
      )}

      {/* Step 1: Location & Gateway */}
      {step === 1 && (
        <div className="space-y-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              1. Adım: Lokasyon ve Ağ Gateway Bilgileri
            </h2>
            <p className="text-xs text-slate-500">
              Bu kurulumun uygulanacağı şube adını ve gateway (firewall/router) tipini seçin.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Lokasyon / Şube Adı
              </label>
              <input
                type="text"
                value={locationName}
                onChange={(e) => setLocationName(e.target.value)}
                placeholder="Örn. Kadıköy Şube, Grand Hotel Spa"
                className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Kapasite Profili
              </label>
              <select
                value={capacityProfile}
                onChange={(e) => setCapacityProfile(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                <option value="small">Küçük İşletme / Kafe (1 - 50 Eşzamanlı Kullanıcı)</option>
                <option value="medium">Orta Ölçekli İşletme / Butik Otel (50 - 250 Kullanıcı)</option>
                <option value="large">Büyük Tesis / AVM / Kampüs (250+ Kullanıcı)</option>
              </select>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Ağ Cihazı / Gateway Üreticisi
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "fortigate", label: "FortiGate", icon: Server },
                  { id: "mikrotik", label: "MikroTik", icon: Server },
                  { id: "unifi", label: "UniFi / AP", icon: Wifi },
                ].map((g) => {
                  const Icon = g.icon;
                  const isSel = gatewayType === g.id;
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => setGatewayType(g.id)}
                      className={`flex flex-col items-center justify-center gap-1 rounded-xl border p-3 text-center transition-all ${
                        isSel
                          ? "border-indigo-600 bg-indigo-50/50 text-indigo-700 dark:border-indigo-500 dark:bg-indigo-950/30 dark:text-indigo-300 ring-2 ring-indigo-500/20 font-bold"
                          : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span className="text-xs">{g.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Gateway IP Adresi & Secret
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={gatewayIp}
                  onChange={(e) => setGatewayIp(e.target.value)}
                  placeholder="192.168.1.1"
                  className="w-1/2 rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
                <input
                  type="password"
                  value={sharedSecret}
                  onChange={(e) => setSharedSecret(e.target.value)}
                  placeholder="RADIUS Secret"
                  className="w-1/2 rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-indigo-500/20 hover:bg-indigo-700 transition"
            >
              Devam Et: Kimlik ve Hız Limitleri
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Auth & QoS */}
      {step === 2 && (
        <div className="space-y-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              2. Adım: Kimlik Doğrulama & Hız (QoS) Politikaları
            </h2>
            <p className="text-xs text-slate-500">
              Misafirlerin ağa hangi yöntemlerle girebileceğini ve hız/kota limitlerini belirleyin.
            </p>
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Aktif Edilecek Doğrulama Yöntemleri
            </label>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
              {[
                { id: "tc_sms", label: "T.C. Kimlik + SMS", icon: UserCheck },
                { id: "sms", label: "Yalnızca SMS OTP", icon: Smartphone },
                { id: "pms", label: "Otel Odası (PMS)", icon: Hotel },
                { id: "voucher", label: "Kupon (Voucher)", icon: Ticket },
                { id: "free", label: "Sözleşmeli Ücretsiz", icon: Wifi },
              ].map((m) => {
                const Icon = m.icon;
                const active = authMethods.includes(m.id);
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => toggleAuthMethod(m.id)}
                    className={`flex flex-col items-center justify-center gap-1.5 rounded-xl border p-3 text-center transition-all ${
                      active
                        ? "border-indigo-600 bg-indigo-50/50 text-indigo-700 dark:border-indigo-500 dark:bg-indigo-950/30 dark:text-indigo-300 ring-2 ring-indigo-500/20 font-bold"
                        : "border-slate-200 bg-slate-50/50 text-slate-500 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="text-xs">{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3 border-t border-slate-100 pt-4 dark:border-slate-800">
            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                İndirme Hızı (Download)
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={downloadSpeed}
                  onChange={(e) => setDownloadSpeed(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400">Mbps</span>
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Yükleme Hızı (Upload)
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={uploadSpeed}
                  onChange={(e) => setUploadSpeed(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400">Mbps</span>
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Maksimum Oturum Süresi
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={sessionTimeout}
                  onChange={(e) => setSessionTimeout(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400">Dakika</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50/50 p-4 dark:border-slate-800 dark:bg-slate-850">
            <div className="flex items-center gap-3">
              <Shield className="h-5 w-5 text-indigo-600" />
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-white">
                  5651 Sayılı Kanun Kapsamında Günlük Kriptografik Mühürleme
                </div>
                <div className="text-[11px] text-slate-500">
                  Her gün 23:59'da logları SHA-256 zinciri ve zaman damgasıyla otomatik mühürler.
                </div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={enable5651}
              onChange={(e) => setEnable5651(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
            />
          </div>

          <div className="flex justify-between pt-4">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            >
              <ChevronLeft className="h-4 w-4" />
              Geri
            </button>
            <button
              type="button"
              onClick={() => setStep(3)}
              className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-indigo-500/20 hover:bg-indigo-700 transition"
            >
              Devam Et: Karşılama Portalı
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Portal Theme & Preview */}
      {step === 3 && (
        <div className="space-y-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              3. Adım: Karşılama Portalı & Önizleme
            </h2>
            <p className="text-xs text-slate-500">
              Misafirlerin Wi-Fi'a bağlandığında göreceği portal başlık ve metinlerini yapılandırın.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <div className="space-y-4">
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Portal Başlığı
                </label>
                <input
                  type="text"
                  value={portalTitle}
                  onChange={(e) => setPortalTitle(e.target.value)}
                  placeholder="Örn. Grand Hotel Wi-Fi Ağına Hoş Geldiniz"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Açıklama / Karşılama Metni
                </label>
                <textarea
                  rows={4}
                  value={portalWelcome}
                  onChange={(e) => setPortalWelcome(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50/50 p-3 text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>
            </div>

            {/* Live Preview Mock Card */}
            <div className="rounded-2xl border border-slate-200 bg-gradient-to-b from-indigo-50/50 to-white p-5 shadow-inner dark:border-slate-800 dark:from-slate-950 dark:to-slate-900">
              <div className="text-center">
                <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-500/20">
                  <Wifi className="h-5 w-5" />
                </div>
                <div className="text-sm font-bold text-slate-900 dark:text-white">
                  {portalTitle || "Hoş Geldiniz"}
                </div>
                <div className="mt-1 text-[11px] text-slate-500 leading-relaxed">
                  {portalWelcome}
                </div>

                <div className="mt-4 space-y-2">
                  <div className="rounded-xl border border-slate-200 bg-white p-2.5 text-[11px] font-semibold text-slate-700 shadow-sm dark:border-slate-800 dark:bg-slate-800 dark:text-slate-200">
                    📱 Telefon Numaranız ile Giriş
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-2.5 text-[11px] font-semibold text-slate-700 shadow-sm dark:border-slate-800 dark:bg-slate-800 dark:text-slate-200">
                    🏨 Oda No & Soyad ile Giriş
                  </div>
                </div>

                <div className="mt-4 text-[9px] text-slate-400">
                  5651 Sayılı Kanun Uyarınca Bağlantı Loglarınız Mühürlenmektedir.
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            >
              <ChevronLeft className="h-4 w-4" />
              Geri
            </button>
            <button
              type="button"
              onClick={handleCompleteSetup}
              disabled={loading}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-2.5 text-xs font-bold text-white shadow-md shadow-emerald-500/20 hover:bg-emerald-700 disabled:opacity-50 transition"
            >
              {loading ? "Kurulum Yapılıyor..." : "Kurulumu Tamamla ve Yayına Al 🚀"}
            </button>
          </div>
        </div>
      )}

      {/* Step 4: Success & CLI Snippets */}
      {step === 4 && result && (
        <div className="space-y-6 rounded-2xl border border-emerald-200 bg-white p-6 shadow-sm dark:border-emerald-950/40 dark:bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
              <CheckCircle2 className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Kurulum Başarıyla Tamamlandı!
              </h2>
              <p className="text-xs text-slate-500">
                Lokasyon '{result.location_name}' ve gateway yapılandırması hazırlandı.
              </p>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-3 dark:border-slate-800 dark:bg-slate-850">
              <div className="text-[10px] text-slate-400">Portal URL</div>
              <a
                href={result.portal_url}
                target="_blank"
                rel="noreferrer"
                className="mt-0.5 flex items-center gap-1 text-xs font-bold text-indigo-600 hover:underline"
              >
                Canlı Portalı Aç <ExternalLink className="h-3 w-3" />
              </a>
            </div>

            <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-3 dark:border-slate-800 dark:bg-slate-850">
              <div className="text-[10px] text-slate-400">RADIUS Sunucu IP & Port</div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                {result.radius_server_ip} : {result.radius_auth_port}
              </div>
            </div>

            <div className="rounded-xl border border-slate-100 bg-slate-50/50 p-3 dark:border-slate-800 dark:bg-slate-850">
              <div className="text-[10px] text-slate-400">Shared Secret</div>
              <div className="text-xs font-mono font-bold text-slate-900 dark:text-white">
                {result.radius_shared_secret}
              </div>
            </div>
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                Cihaz CLI Yapılandırma Komutları ({gatewayType.toUpperCase()})
              </span>
              <button
                type="button"
                onClick={handleCopyCli}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-[11px] font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              >
                <Copy className="h-3.5 w-3.5" />
                {copied ? "Kopyalandı!" : "Komutları Kopyala"}
              </button>
            </div>
            <pre className="overflow-x-auto rounded-xl bg-slate-950 p-4 font-mono text-[11px] text-emerald-400 leading-relaxed">
              {result.cli_snippet}
            </pre>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={() => {
                setStep(1);
                setResult(null);
              }}
              className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            >
              Yeni Bir Şube Daha Kur
            </button>
            <a
              href="/dashboard"
              className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
            >
              Yönetim Paneline Dön
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
