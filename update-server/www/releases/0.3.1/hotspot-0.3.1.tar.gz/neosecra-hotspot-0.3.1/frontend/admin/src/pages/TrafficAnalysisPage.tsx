import React, { useState, useEffect, useRef } from "react";
import { getTrafficTrend, getTrafficDashboard, getSessions } from "../lib/api";
import {
  ArrowRight,
  BarChart2,
  TrendingUp,
  Download,
  Wifi,
  Users,
  Clock,
  Gauge,
  MapPin,
  PieChart,
  RefreshCw,
  Activity,
  ArrowDownUp,
  Radio,
  UserCheck,
  ShieldAlert,
} from "lucide-react";

export const TrafficAnalysisPage: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [dashboard, setDashboard] = useState<any>(null);
  const [liveSessions, setLiveSessions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState(30);
  const [autoRefreshSec, setAutoRefreshSec] = useState<number>(10);
  const [lastRefreshed, setLastRefreshed] = useState<Date>(new Date());
  const [activeTab, setActiveTab] = useState<"charts" | "live_stream">("charts");

  const load = async (showSpinner = true) => {
    if (showSpinner) setLoading(true);
    try {
      const [trend, dash, sessions] = await Promise.all([
        getTrafficTrend(period).catch(() => null),
        getTrafficDashboard().catch(() => null),
        getSessions({ page_size: 20 }).catch(() => []),
      ]);
      if (trend) setData(trend);
      if (dash) setDashboard(dash);
      setLiveSessions(Array.isArray(sessions) ? sessions : (sessions as any)?.sessions || []);
      setLastRefreshed(new Date());
    } catch (err) {
      console.error(err);
    } finally {
      if (showSpinner) setLoading(false);
    }
  };

  useEffect(() => {
    load(true);
  }, [period]);

  // Auto-refresh timer
  useEffect(() => {
    if (autoRefreshSec <= 0) return;
    const interval = setInterval(() => {
      load(false);
    }, autoRefreshSec * 1000);
    return () => clearInterval(interval);
  }, [autoRefreshSec, period]);

  const formatBytes = (b: number) => {
    if (!b || isNaN(b)) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    let i = 0;
    let val = b;
    while (val >= 1024 && i < units.length - 1) {
      val /= 1024;
      i++;
    }
    return `${val.toFixed(1)} ${units[i]}`;
  };

  const maxBytes = data?.daily?.length
    ? Math.max(...data.daily.map((d: any) => d.bytes_in + d.bytes_out))
    : 1;

  if (loading && !data) {
    return (
      <div className="flex items-center justify-center gap-2 py-24 text-sm text-slate-500">
        <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
        Canlı ağ trafiği verileri yükleniyor...
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Standard Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Trafik Analizi &amp; Bant Genişliği
            </h2>
            <span className="inline-flex items-center gap-1.5 rounded-md border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 dark:border-emerald-900/50 dark:bg-emerald-950/40 dark:text-emerald-300">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Canlı Ağ Akışı
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Gerçek zamanlı indirme/yükleme bant genişliği, aktif misafir akışları ve lokasyon kapasite metrikleri.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Auto refresh select */}
          <div className="flex items-center gap-1.5 text-xs text-slate-500 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1.5 bg-white dark:bg-slate-900">
            <Radio className="w-3.5 h-3.5 text-blue-500" />
            <select
              value={autoRefreshSec}
              onChange={(e) => setAutoRefreshSec(parseInt(e.target.value))}
              className="bg-transparent text-xs font-semibold focus:outline-none dark:text-slate-200 cursor-pointer"
            >
              <option value={5}>5 sn Canlı</option>
              <option value={10}>10 sn Canlı</option>
              <option value={30}>30 sn Canlı</option>
              <option value={0}>Durdur</option>
            </select>
          </div>

          <select
            value={period}
            onChange={(e) => setPeriod(parseInt(e.target.value))}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 shadow-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value={7}>Son 7 Gün</option>
            <option value={30}>Son 30 Gün</option>
            <option value={90}>Son 90 Gün</option>
            <option value={180}>Son 6 Ay</option>
            <option value={365}>Son 365 Gün (Yıllık Trend & Kapasite)</option>
          </select>

          <button
            type="button"
            onClick={() => load(true)}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
        </div>
      </div>

      {/* 2. Standard 4-Tile Metric Cards */}
      {data?.summary && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Trafik</span>
              <TrendingUp className="h-4 w-4 text-blue-500" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">
                {formatBytes(data.summary.total_bytes_in + data.summary.total_bytes_out)}
              </span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Oturum</span>
              <Wifi className="h-4 w-4 text-emerald-500" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                {data.summary.total_sessions.toLocaleString("tr-TR")}
              </span>
              <span className="text-xs text-slate-500">oturum</span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Tekil Cihaz</span>
              <Users className="h-4 w-4 text-slate-400" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">
                {data.summary.unique_macs.toLocaleString("tr-TR")}
              </span>
              <span className="text-xs text-slate-500">MAC</span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Pik Eşzamanlı</span>
              <Gauge className="h-4 w-4 text-blue-500" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {data.summary.peak_concurrent}
              </span>
              <span className="text-xs text-slate-500">anlık misafir</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. Navigation Tabs: Overview vs Live Flow */}
      <div className="flex border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveTab("charts")}
          className={`px-4 py-2 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition ${
            activeTab === "charts"
              ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          }`}
        >
          <BarChart2 className="w-3.5 h-3.5" />
          Trafik Eğilimleri &amp; Top Talkers
        </button>
        <button
          onClick={() => setActiveTab("live_stream")}
          className={`px-4 py-2 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition ${
            activeTab === "live_stream"
              ? "border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          Canlı Ağ Akışları ({liveSessions.length})
        </button>
      </div>

      {activeTab === "charts" && (
        <>
          {/* 3. Daily Traffic Chart */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Günlük Trafik Akışı (Son {period} Gün)
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                Son Güncelleme: {lastRefreshed.toLocaleTimeString("tr-TR")}
              </span>
            </div>
            <div className="relative h-44">
              <div className="absolute inset-0 flex items-end space-x-1.5">
                {data?.daily?.map((d: any, i: number) => {
                  const total = d.bytes_in + d.bytes_out;
                  const pct = maxBytes > 0 ? (total / maxBytes) * 100 : 0;
                  return (
                    <div
                      key={i}
                      className="flex-1 flex flex-col items-center group relative"
                      title={`${d.date}: ${formatBytes(total)} (Giriş: ${formatBytes(d.bytes_in)}, Çıkış: ${formatBytes(d.bytes_out)})`}
                    >
                      <div
                        className="w-full bg-blue-500/80 hover:bg-blue-600 rounded-t transition-all cursor-pointer"
                        style={{ height: `${Math.max(pct, 4)}%` }}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="flex justify-between text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 font-mono">
              <span>{data?.daily?.[0]?.date || "Başlangıç"}</span>
              <span>{data?.daily?.[data?.daily?.length - 1]?.date || "Bugün"}</span>
            </div>
          </div>

          {/* 4. Hourly & Top Talkers */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Hourly Traffic */}
            <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Saatlik Trafik Dağılımı (Son 24s)
              </h3>
              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {data?.hourly?.map((h: any, i: number) => {
                  const maxH = Math.max(
                    ...(data?.hourly?.map((x: any) => x.bytes_in + x.bytes_out) || [1])
                  );
                  const pct = maxH > 0 ? ((h.bytes_in + h.bytes_out) / maxH) * 100 : 0;
                  return (
                    <div key={i} className="flex items-center gap-2.5 text-xs">
                      <span className="w-12 text-right font-mono text-slate-500">{h.hour}</span>
                      <div className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
                        <div
                          className="bg-blue-600 h-full rounded-full transition-all"
                          style={{ width: `${Math.max(pct, 2)}%` }}
                        />
                      </div>
                      <span className="w-20 text-right font-mono font-semibold text-slate-700 dark:text-slate-300">
                        {formatBytes(h.bytes_in + h.bytes_out)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Top Talkers */}
            <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                En Yüksek Trafik Kullananlar (Top Talkers)
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                      <th className="px-3 py-2.5">#</th>
                      <th className="px-3 py-2.5">MAC</th>
                      <th className="px-3 py-2.5">Kullanıcı / Tel</th>
                      <th className="px-3 py-2.5">Download</th>
                      <th className="px-3 py-2.5">Upload</th>
                      <th className="px-3 py-2.5">Oturum</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {data?.top_talkers?.map((t: any, i: number) => (
                      <tr key={i} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                        <td className="px-3 py-2 font-bold text-slate-400">#{t.rank || i + 1}</td>
                        <td className="px-3 py-2 font-mono text-[11px] font-semibold text-slate-800 dark:text-slate-200">
                          {t.mac}
                        </td>
                        <td className="px-3 py-2 text-slate-600 dark:text-slate-300">
                          {t.phone || "Misafir"}
                        </td>
                        <td className="px-3 py-2 text-emerald-600 dark:text-emerald-400 font-mono font-medium">
                          {formatBytes(t.bytes_out)}
                        </td>
                        <td className="px-3 py-2 text-blue-600 dark:text-blue-400 font-mono font-medium">
                          {formatBytes(t.bytes_in)}
                        </td>
                        <td className="px-3 py-2 font-mono text-slate-500">{t.session_count || 1}</td>
                      </tr>
                    ))}
                    {(!data?.top_talkers || data.top_talkers.length === 0) && (
                      <tr>
                        <td colSpan={6} className="py-6 text-center text-xs text-slate-500">
                          Trafik verisi bulunmuyor.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* 5. Auth Method Distribution & Top Locations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {dashboard?.auth_method_distribution && (
              <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-blue-600" />
                  Doğrulama Yöntemi Dağılımı
                </h3>
                <div className="space-y-3">
                  {Object.entries(dashboard.auth_method_distribution).map(
                    ([method, pct]: [string, any]) => (
                      <div key={method} className="flex items-center gap-3 text-xs">
                        <span className="w-32 font-medium text-slate-700 dark:text-slate-300 truncate">
                          {method}
                        </span>
                        <div className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
                          <div
                            className="bg-blue-600 h-full rounded-full transition-all"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="w-12 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                          %{pct}
                        </span>
                      </div>
                    )
                  )}
                </div>
              </div>
            )}

            {dashboard?.top_locations && dashboard.top_locations.length > 0 && (
              <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  En Yoğun Lokasyonlar
                </h3>
                <div className="space-y-3">
                  {dashboard.top_locations.map((loc: any, i: number) => {
                    const maxB = Math.max(
                      ...dashboard.top_locations.map((x: any) => x.total_bytes || 0),
                      1
                    );
                    const pct = ((loc.total_bytes || 0) / maxB) * 100;
                    return (
                      <div key={i} className="flex items-center gap-3 text-xs">
                        <span className="w-5 font-bold text-slate-400">#{i + 1}</span>
                        <div className="flex-1">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="font-medium text-slate-800 dark:text-slate-200">
                              {loc.name || loc.location_id || "-"}
                            </span>
                            <span className="font-mono text-slate-500">
                              {formatBytes(loc.total_bytes)} ({loc.sessions || 1} oturum)
                            </span>
                          </div>
                          <div className="bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                            <div
                              className="bg-blue-600 h-full rounded-full transition-all"
                              style={{ width: `${Math.max(pct, 2)}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {/* Live Stream Tab */}
      {activeTab === "live_stream" && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-slate-900 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-500" />
                Gerçek Zamanlı Misafir Ağ Akışı (Live Stream)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Cihazların canlı IP/MAC adresleri, veri transfer hacimleri ve bağlantı süreleri.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500">
              {autoRefreshSec > 0 ? `${autoRefreshSec}s periyodla canlı akıyor` : "Canlı akış duraklatıldı"}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/80 text-[10px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-3 py-2.5">Durum</th>
                  <th className="px-3 py-2.5">Yerel IP</th>
                  <th className="px-3 py-2.5">MAC Adresi</th>
                  <th className="px-3 py-2.5">Kullanıcı / Tel</th>
                  <th className="px-3 py-2.5">Doğrulama</th>
                  <th className="px-3 py-2.5">Download (RX)</th>
                  <th className="px-3 py-2.5">Upload (TX)</th>
                  <th className="px-3 py-2.5">Başlangıç Zamanı</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {liveSessions.map((s: any, idx: number) => (
                  <tr key={idx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                    <td className="px-3 py-2">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200/50">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        {s.status === "active" ? "Aktif" : s.status || "Aktif"}
                      </span>
                    </td>
                    <td className="px-3 py-2 font-mono font-bold text-blue-600">
                      {s.ip || s.ip_address || "—"}
                    </td>
                    <td className="px-3 py-2 font-mono text-slate-700 dark:text-slate-300">
                      {s.mac || s.mac_address || "—"}
                    </td>
                    <td className="px-3 py-2 font-medium text-slate-900 dark:text-white">
                      {s.username || s.identity || s.phone || "Misafir"}
                    </td>
                    <td className="px-3 py-2 text-slate-500 uppercase font-mono text-[11px]">
                      {s.auth_method || "—"}
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold text-emerald-600">
                      {formatBytes(s.bytes_out || 0)}
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold text-blue-600">
                      {formatBytes(s.bytes_in || 0)}
                    </td>
                    <td className="px-3 py-2 text-slate-500 font-mono text-[11px]">
                      {s.started_at || s.created_at
                        ? new Date(s.started_at || s.created_at).toLocaleTimeString("tr-TR")
                        : "—"}
                    </td>
                  </tr>
                ))}
                {liveSessions.length === 0 && (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-500 text-xs">
                      Aktif misafir akışı bulunamadı.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};


