import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  Save, ArrowLeft, Monitor, Smartphone, Palette, Type, Image, Layers,
  GripVertical, Eye, Check, X, ChevronDown,
  Plus, Trash2, ArrowUp, ArrowDown, Copy, Globe,
} from 'lucide-react';
import {
  getPredefinedTemplates,
  applyTemplate,
  getPortalTemplate,
  getPortalTemplateHistory,
  restorePortalTemplateRevision,
  updatePortalTemplate,
  getDevices,
} from '../lib/api';
import type {
  PortalTemplateHistoryResponse,
  PortalTemplateRecord,
  PortalTemplateUpdatePayload,
  PortalTemplateTheme,
} from '../lib/api';

// ── Types ────────────────────────────────────────────────────────────────────

interface TemplateTheme {
  primary_color: string;
  secondary_color: string;
  bg_color: string;
  text_color: string;
  font_family: string;
  logo_style: 'circle' | 'rounded' | 'square';
  button_style: 'pill' | 'rounded' | 'sharp';
  layout: 'centered' | 'wide' | 'split';
  bg_image_url: string;
  logo_url: string;
  title: string;
  subtitle: string;
  footer: string;
  termsText?: string;
  supportText?: string;
  internetPolicyText?: string;
  kvkkText?: string;
  redirect_url?: string;
  redirect_delay_seconds?: number;
  remember_mac_enabled?: boolean;
  mac_remember_days?: number;
}

interface FormField {
  key?: string;
  name: string;
  type: string;
  required: boolean;
  label: string;
  enabled?: boolean;
  placeholder?: string;
  validation?: string;
  order?: number;
  options?: Array<{ label: string; value: string }>;
}

interface PredefinedTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  default_theme: TemplateTheme;
}

const DEFAULT_THEME: TemplateTheme = {
  primary_color: '#4f46e5',
  secondary_color: '#7c3aed',
  bg_color: '#f8fafc',
  text_color: '#0f172a',
  font_family: "'Inter', 'Segoe UI', sans-serif",
  logo_style: 'circle',
  button_style: 'pill',
  layout: 'centered',
  bg_image_url: '',
  logo_url: '',
  title: 'Kablosuz Ağa Hoş Geldiniz',
  subtitle: 'İnternet erişimi için lütfen kimliğinizi doğrulayın.',
  footer: 'Yardım için resepsiyon ile iletişime geçin.',
  internetPolicyText: 'İnternet kullanım politikasını okudum, kabul ediyorum.',
  kvkkText: 'KVKK aydınlatma metnini okudum, kişisel verilerimin işlenmesini kabul ediyorum.',
  redirect_url: '',
  redirect_delay_seconds: 3,
  remember_mac_enabled: true,
  mac_remember_days: 3,
};

const FONTS = [
  { value: "'Inter', 'Segoe UI', sans-serif", label: 'Inter (Modern)' },
  { value: "'Playfair Display', serif", label: 'Playfair Display (Elegant)' },
  { value: "'Montserrat', 'Segoe UI', sans-serif", label: 'Montserrat (Modern)' },
  { value: "'Nunito', 'Segoe UI', sans-serif", label: 'Nunito (Friendly)' },
  { value: "'Poppins', 'Segoe UI', sans-serif", label: 'Poppins (Bold)' },
  { value: "'Merriweather', Georgia, serif", label: 'Merriweather (Serif)' },
  { value: "'Source Sans Pro', 'Segoe UI', sans-serif", label: 'Source Sans (Clean)' },
  { value: "'Lato', 'Segoe UI', sans-serif", label: 'Lato (Clean)' },
  { value: "'Roboto', sans-serif", label: 'Roboto (Standard)' },
  { value: "'Georgia', serif", label: 'Georgia (Classic)' },
];

const LOGO_STYLES = [
  { value: 'circle', label: 'Yuvarlak' },
  { value: 'rounded', label: 'Yuvarlatılmış' },
  { value: 'square', label: 'Kare' },
];

const BUTTON_STYLES = [
  { value: 'pill', label: 'Oval' },
  { value: 'rounded', label: 'Yuvarlatılmış' },
  { value: 'sharp', label: 'Keskin' },
];

const LAYOUTS = [
  { value: 'centered', label: 'Ortalanmış' },
  { value: 'wide', label: 'Geniş' },
  { value: 'split', label: 'İki kolon' },
];

const CAPTIVE_PORTAL_METHODS = ['free', 'sms', 'tc', 'voucher', 'pms', 'local'] as const;

function normalizeEnabledMethods(raw: unknown, fallback: string): string[] {
  const values = Array.isArray(raw) ? raw : [];
  const normalized = values
    .map(value => String(value || '').trim().toLowerCase() === 'tc_sms' ? 'tc' : String(value || '').trim().toLowerCase())
    .filter((value, index, all) => CAPTIVE_PORTAL_METHODS.includes(value as typeof CAPTIVE_PORTAL_METHODS[number]) && all.indexOf(value) === index);
  const defaultMethod = fallback === 'tc_sms' ? 'tc' : fallback;
  if (CAPTIVE_PORTAL_METHODS.includes(defaultMethod as typeof CAPTIVE_PORTAL_METHODS[number]) && !normalized.includes(defaultMethod)) {
    normalized.unshift(defaultMethod);
  }
  return normalized.length ? normalized : ['sms'];
}

const METHOD_LABELS: Record<string, string> = {
  free: 'Sözleşme / Rıza Metni (Serbest Form & Yönetici Onayı)',
  sms: 'Telefon (SMS Doğrulama)',
  tc: 'T.C. Kimlik & SMS',
  voucher: 'Bilet / Voucher Kodu',
  pms: 'Otel Odası (PMS Entegrasyonu)',
  local: 'Manuel Kullanıcı Adı / Şifre',
};

const METHOD_FIELD_DEFS: Record<string, FormField[]> = {
  sms: [{ name: 'phone', type: 'tel', required: true, label: 'Telefon Numarası', enabled: true, placeholder: '05xx xxx xx xx', validation: 'tr_phone', order: 1 }],
  tc: [
    { name: 'tc_number', type: 'text', required: true, label: 'T.C. Kimlik Numarası', validation: 'tr_tc' },
    { name: 'phone', type: 'tel', required: true, label: 'Telefon Numarası', validation: 'tr_phone', placeholder: '05xx xxx xx xx' },
  ],
  voucher: [{ name: 'voucher_code', type: 'text', required: true, label: 'Bilet / Voucher Kodu' }],
  free: [],
  pms: [
    { name: 'room_number', type: 'text', required: true, label: 'Oda Numarası' },
    // Keep the key aligned with the public flow schema.  The previous
    // `surname` key rendered correctly but could never be submitted to the
    // PMS verifier, which expects `surname_or_birth`.
    { name: 'surname_or_birth', type: 'text', required: true, label: 'Soyad / Doğum Yılı' },
  ],
  local: [
    { name: 'username', type: 'text', required: true, label: 'Kullanıcı Adı' },
    { name: 'password', type: 'password', required: true, label: 'Şifre' },
  ],
};

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, ch => {
    switch (ch) {
      case '&':
        return '&amp;';
      case '<':
        return '&lt;';
      case '>':
        return '&gt;';
      case '"':
        return '&quot;';
      case "'":
        return '&#39;';
      default:
        return ch;
    }
  });
}

function escapeCssUrl(value: string): string {
  return encodeURI(value).replace(/[()"]/g, ch => {
    switch (ch) {
      case '(':
        return '%28';
      case ')':
        return '%29';
      case '"':
        return '%22';
      default:
        return ch;
    }
  });
}

function cloneMethodFields(method: string): FormField[] {
  return (METHOD_FIELD_DEFS[method] || []).map((field, index) => ({ enabled: true, placeholder: '', validation: 'none', order: index + 1, ...field, key: field.name }));
}

function normalizeMethodFields(fields: any[] | undefined | null, method: string): FormField[] {
  const canonical = cloneMethodFields(method);
  if (!fields || !fields.length) {
    return canonical;
  }

  return fields.map((field, index) => {
    const fallback = canonical[index];
    return {
      name: String(field?.name || fallback?.name || `field_${index + 1}`),
      key: String(field?.key || field?.name || fallback?.name || `field_${index + 1}`),
      type: String(field?.type || fallback?.type || 'text'),
      required: Boolean(field?.required ?? fallback?.required ?? false),
      label: String(field?.label || fallback?.label || field?.name || `Alan ${index + 1}`),
      enabled: Boolean(field?.enabled ?? true),
      placeholder: String(field?.placeholder || fallback?.placeholder || ''),
      validation: String(field?.validation || fallback?.validation || 'none'),
      order: Number(field?.order || index + 1),
      options: Array.isArray(field?.options)
        ? field.options
            .map((option: any) => typeof option === 'string' ? { label: option, value: option } : { label: String(option?.label || option?.value || ''), value: String(option?.value || option?.label || '') })
            .filter((option: { label: string; value: string }) => option.label && option.value)
        : fallback?.options,
    };
  });
}

function fieldsForPortalMethod(record: PortalTemplateRecord | null | undefined, method: string): any[] | undefined {
  if (!record) return undefined;
  const byMethod = record.meta?.method_fields;
  if (byMethod && typeof byMethod === 'object') {
    const candidates = method === 'tc' ? [method, 'tc_sms'] : [method];
    const matched = candidates.find(candidate => Array.isArray(byMethod[candidate]));
    if (matched) return byMethod[matched];
  }
  return method === record.method ? record.fields : undefined;
}

function normalizeTheme(theme?: Partial<PortalTemplateTheme> | null): TemplateTheme {
  const { terms_text, support_text, internet_policy_text, kvkk_text, ...rest } = theme || {};
  const legacyTerms = terms_text ?? (theme as TemplateTheme | undefined)?.termsText;
  return {
    ...DEFAULT_THEME,
    ...rest,
    termsText: legacyTerms,
    supportText: support_text ?? (theme as TemplateTheme | undefined)?.supportText,
    internetPolicyText: internet_policy_text ?? (theme as TemplateTheme | undefined)?.internetPolicyText ?? legacyTerms,
    kvkkText: kvkk_text ?? (theme as TemplateTheme | undefined)?.kvkkText ?? DEFAULT_THEME.kvkkText,
  };
}

function formatRevisionTime(value?: string | null): string {
  if (!value) return 'Bilinmiyor';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return 'Bilinmiyor';
  return parsed.toLocaleString('tr-TR', {
    dateStyle: 'short',
    timeStyle: 'short',
  });
}

function revisionActionLabel(value?: string | null): string {
  const labels: Record<string, string> = {
    updated: 'Güncellendi',
    created: 'Oluşturuldu',
    applied_template: 'Hazır şablon uygulandı',
    restored: 'Geri alındı',
    current: 'Geçerli sürüm',
  };
  return labels[value || ''] || value || 'Geçerli sürüm';
}

function methodLabel(value?: string | null): string {
  const labels: Record<string, string> = {
    sms: 'SMS',
    tc: 'T.C. + SMS',
    voucher: 'Bilet / voucher',
    pms: 'Otel kaydı',
    local: 'Yerel kullanıcı',
    free: 'Sözleşme onayı',
  };
  return labels[value || ''] || 'SMS';
}

function toPortalThemePayload(theme: TemplateTheme): PortalTemplateTheme {
  const { termsText, supportText, internetPolicyText, kvkkText, ...rest } = theme;
  return {
    ...rest,
    // Send empty values as well so clearing a field in the editor actually
    // persists instead of leaving the previous server value in place.
    terms_text: termsText || '',
    support_text: supportText || '',
    internet_policy_text: internetPolicyText || termsText || '',
    kvkk_text: kvkkText || '',
  };
}

// ── Preview HTML generator (inline) ──────────────────────────────────────────

function generatePreviewHtml(
  theme: TemplateTheme,
  method: string,
  fields: FormField[],
  successMessage: string,
  approvalRequired: boolean,
  approvalMessage: string,
): string {
  const radius = theme.button_style === 'pill' ? '9999px' : theme.button_style === 'rounded' ? '12px' : '6px';
  const logoRadius = theme.logo_style === 'circle' ? '50%' : theme.logo_style === 'rounded' ? '12px' : '4px';
  const isSplit = theme.layout === 'split';
  const isWide = theme.layout === 'wide';
  const activeFields = (fields.length ? fields : cloneMethodFields(method)).filter(field => field.enabled !== false);
  const fieldsHtml = activeFields.length
    ? activeFields.map(field => `
      <div class="field">
        <label for="${escapeHtml(field.name)}">${escapeHtml(field.label)}${field.required ? ' *' : ''}</label>
        <input type="${escapeHtml(field.type)}" id="${escapeHtml(field.name)}" placeholder="${escapeHtml(field.placeholder || field.label)}" ${field.required ? 'required' : ''} />
      </div>
    `).join('')
    : '<p class="field-hint">Bu yöntem için ek alan gerekmiyor.</p>';

  const backgroundStyle = theme.bg_image_url
    ? `background-image: linear-gradient(135deg, rgba(15, 23, 42, 0.45), rgba(15, 23, 42, 0.85)), url("${escapeCssUrl(theme.bg_image_url)}"); background-size: cover; background-position: center;`
    : `background: linear-gradient(135deg, ${theme.secondary_color}10, ${theme.primary_color}1a);`;

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Outfit:wght@400;600;700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: ${theme.font_family};
      color: ${theme.text_color};
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      ${backgroundStyle}
    }
    
    .container {
      display: flex;
      width: 100%;
      min-height: 100vh;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    
    ${isSplit ? `
    .container {
      padding: 0;
      flex-direction: row;
    }
    .left-pane {
      flex: 1.2;
      background: linear-gradient(135deg, ${theme.primary_color}, ${theme.secondary_color});
      ${theme.bg_image_url ? `background-image: linear-gradient(135deg, rgba(0,0,0,0.2), rgba(0,0,0,0.6)), url("${escapeCssUrl(theme.bg_image_url)}"); background-size: cover; background-position: center;` : ''}
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      padding: 48px;
      color: #ffffff;
      min-height: 100vh;
    }
    .left-pane h2 { font-size: 28px; font-weight: 800; line-height: 1.2; margin-bottom: 8px; font-family: 'Outfit', sans-serif; text-shadow: 0 2px 10px rgba(0,0,0,0.2); }
    .left-pane p { font-size: 15px; opacity: 0.9; text-shadow: 0 1px 5px rgba(0,0,0,0.2); }
    .right-pane {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 32px;
      background: #ffffff;
      min-height: 100vh;
    }
    .card {
      background: transparent !important;
      box-shadow: none !important;
      backdrop-filter: none !important;
      border: none !important;
      max-width: 360px !important;
      padding: 0 !important;
    }
    @media (max-width: 640px) {
      .left-pane { display: none; }
      .right-pane { flex: 1; background: ${theme.bg_color}; }
      .card {
        background: rgba(255,255,255,0.85) !important;
        backdrop-filter: blur(16px) !important;
        border: 1px solid rgba(255, 255, 255, 0.4) !important;
        box-shadow: 0 8px 32px rgba(0,0,0,0.06) !important;
        padding: 32px 24px !important;
      }
    }
    ` : ''}

    .card {
      background: rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.4);
      border-radius: 24px;
      padding: 36px 32px;
      max-width: ${isWide ? '480px' : '380px'};
      width: 100%;
      box-shadow: 0 10px 40px rgba(15, 23, 42, 0.08);
      text-align: center;
      transition: all 0.3s ease;
    }
    
    .logo-container {
      width: 60px;
      height: 60px;
      background: linear-gradient(135deg, ${theme.primary_color}, ${theme.secondary_color});
      color: #ffffff;
      border-radius: ${logoRadius};
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 26px;
      font-weight: 700;
      margin: 0 auto 16px;
      box-shadow: 0 4px 15px ${theme.primary_color}40;
    }
    
    .logo-img {
      width: auto;
      height: 60px;
      border-radius: ${logoRadius};
      object-fit: contain;
      margin-bottom: 16px;
    }
    
    h1 {
      font-size: 20px;
      font-weight: 700;
      margin-bottom: 6px;
      letter-spacing: -0.5px;
      font-family: 'Outfit', sans-serif;
    }
    
    p.sub {
      font-size: 13px;
      opacity: 0.65;
      margin-bottom: 24px;
      line-height: 1.5;
    }
    
    .field {
      margin-bottom: 16px;
      text-align: left;
    }
    
    .field label {
      display: block;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.75px;
      opacity: 0.5;
      margin-bottom: 6px;
    }
    
    .field input {
      width: 100%;
      padding: 12px 14px;
      font-size: 14px;
      border: 1.5px solid rgba(15, 23, 42, 0.08);
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.75);
      outline: none;
      font-family: inherit;
      transition: all 0.2s ease;
    }
    
    .field input:focus {
      border-color: ${theme.primary_color};
      background: #ffffff;
      box-shadow: 0 0 0 4px ${theme.primary_color}1c;
    }

    .field-hint {
      margin: 18px 0;
      font-size: 12px;
      color: ${theme.text_color};
      opacity: 0.7;
    }
    
    .btn {
      width: 100%;
      padding: 14px;
      background: linear-gradient(135deg, ${theme.primary_color}, ${theme.secondary_color});
      color: #ffffff;
      border: none;
      border-radius: ${radius};
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
      box-shadow: 0 4px 15px ${theme.primary_color}33;
      transition: all 0.2s ease;
    }
    
    .btn:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 20px ${theme.primary_color}4d;
    }
    
    .btn:active {
      transform: translateY(0);
    }
    
    .terms {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      margin: 20px 0;
      font-size: 11px;
      text-align: left;
      opacity: 0.7;
      line-height: 1.4;
    }
    
    .terms input[type="checkbox"] {
      margin-top: 2px;
      width: 14px;
      height: 14px;
      accent-color: ${theme.primary_color};
    }
    
    .support {
      font-size: 11px;
      opacity: 0.72;
      margin-top: 10px;
      line-height: 1.4;
    }

    .success {
      margin-top: 14px;
      font-size: 11px;
      font-weight: 700;
      color: ${theme.primary_color};
      line-height: 1.4;
    }

    .terms-link {
      margin-top: 8px;
      font-size: 11px;
      line-height: 1.4;
    }

    .terms-link a {
      color: ${theme.primary_color};
      text-decoration: none;
    }
    
    .footer {
      font-size: 11px;
      opacity: 0.5;
      margin-top: 16px;
      line-height: 1.4;
    }
  </style>
</head>
<body>
  <div class="container">
    ${isSplit ? `
    <div class="left-pane">
      <h2>${escapeHtml(theme.title)}</h2>
      <p>${escapeHtml(theme.subtitle)}</p>
    </div>
    <div class="right-pane">
    ` : ''}
    
    <div class="card">
      ${theme.logo_url
        ? `<img src="${escapeHtml(theme.logo_url)}" class="logo-img" />`
        : `<div class="logo-container">${escapeHtml(theme.title.substring(0, 1))}</div>`
      }
      ${!isSplit ? `
      <h1>${escapeHtml(theme.title)}</h1>
      <p class="sub">${escapeHtml(theme.subtitle)}</p>
      ` : ''}

      ${fieldsHtml}
      
      ${method === 'free' ? `
      <div class="terms">
        <input type="checkbox" checked />
        <span><strong>Sözleşme Onayı</strong><br />${escapeHtml(theme.termsText || 'Kullanım koşullarını okudum, kabul ediyorum.')}</span>
      </div>
      ${approvalRequired ? `<p class="success">${escapeHtml(approvalMessage || 'Yönetici onayından sonra internet erişimi açılır.')}</p>` : ''}
      ` : `
      <div class="terms">
        <input type="checkbox" checked />
        <span>${escapeHtml(theme.internetPolicyText || theme.termsText || 'İnternet kullanım politikasını okudum, kabul ediyorum.')}</span>
      </div>
      <div class="terms">
        <input type="checkbox" checked />
        <span>${escapeHtml(theme.kvkkText || 'KVKK aydınlatma metnini okudum ve kabul ediyorum.')}</span>
      </div>
      `}
      
      ${successMessage ? `<p class="success">${escapeHtml(successMessage)}</p>` : ''}
      ${theme.supportText ? `<p class="support">${escapeHtml(theme.supportText)}</p>` : ''}
      <button class="btn">İnternete Bağlan</button>
      <p class="footer">${escapeHtml(theme.footer)}</p>
    </div>
    
    ${isSplit ? `</div>` : ''}
  </div>
</body>
</html>`;
}

// ── Component ────────────────────────────────────────────────────────────────

interface TemplateEditorPageProps {
  portalId?: string;
  onBack?: () => void;
}

export const TemplateEditorPage: React.FC<TemplateEditorPageProps> = ({ portalId, onBack }) => {
  const [templateName, setTemplateName] = useState('Portal şablonu');
  const [theme, setTheme] = useState<TemplateTheme>(DEFAULT_THEME);
  const [method, setMethod] = useState('sms');
  const [enabledMethods, setEnabledMethods] = useState<string[]>(['sms']);
  const [methodFields, setMethodFields] = useState<FormField[]>(cloneMethodFields('sms'));
  const [successMessage, setSuccessMessage] = useState('');
  const [approvalRequired, setApprovalRequired] = useState(false);
  const [managerEmails, setManagerEmails] = useState('');
  const [approvalMessage, setApprovalMessage] = useState('Yönetici onayından sonra internet erişiminiz açılacaktır.');
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('mobile');
  const [activeTab, setActiveTab] = useState<'design' | 'fields' | 'legal'>('design');
  const [saved, setSaved] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoadingTemplate, setIsLoadingTemplate] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [predefinedList, setPredefinedList] = useState<PredefinedTemplate[]>([]);
  const [selectedPredef, setSelectedPredef] = useState('');
  const [showPredefDropdown, setShowPredefDropdown] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [redirectCopied, setRedirectCopied] = useState(false);
  const [devices, setDevices] = useState<any[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [portalTemplate, setPortalTemplate] = useState<PortalTemplateRecord | null>(null);
  const [revisionHistory, setRevisionHistory] = useState<PortalTemplateHistoryResponse | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const portalBaseUrl = (import.meta.env.VITE_PORTAL_URL as string | undefined)?.trim()
    || `${window.location.protocol}//${window.location.hostname}:55175`;
  const captiveRedirectUrl = selectedDeviceId
    ? `${portalBaseUrl.replace(/\/$/, '')}/?device_id=${encodeURIComponent(selectedDeviceId)}`
    : `${portalBaseUrl.replace(/\/$/, '')}/?device_id=<cihaz-UUID>`;

  const copyCaptiveRedirectUrl = async () => {
    let copied = false;
    if (navigator.clipboard && window.isSecureContext) {
      try {
        await navigator.clipboard.writeText(captiveRedirectUrl);
        copied = true;
      } catch {
        copied = false;
      }
    }
    if (!copied) {
      try {
        const textArea = document.createElement("textarea");
        textArea.value = captiveRedirectUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        textArea.style.top = "-999999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        copied = document.execCommand('copy');
        textArea.remove();
      } catch {
        copied = false;
      }
    }
    if (copied) {
      setRedirectCopied(true);
      window.setTimeout(() => setRedirectCopied(false), 1800);
    }
  };

  useEffect(() => {
    (async () => {
      const data = await getPredefinedTemplates();
      setPredefinedList(data.templates || []);
    })();
  }, []);

  useEffect(() => {
    getDevices().then(rows => setDevices(rows || [])).catch(() => setDevices([]));
  }, []);

  useEffect(() => {
    if (!portalTemplate) return;
    const scoped = devices.filter(device => !portalTemplate.location_id || device.location_id === portalTemplate.location_id);
    setSelectedDeviceId(current => scoped.some(device => device.id === current) ? current : String(scoped[0]?.id || ''));
  }, [portalTemplate, devices]);

  useEffect(() => {
    if (!portalId) return;

    let cancelled = false;
    setPortalTemplate(null);
    setRevisionHistory(null);
    setTemplateName('Portal şablonu');
    setSelectedPredef('');
    setTheme(DEFAULT_THEME);
    setMethod('sms');
    setEnabledMethods(['sms']);
    setMethodFields(cloneMethodFields('sms'));
    setSuccessMessage('');
    setApprovalRequired(false);
    setManagerEmails('');
    setApprovalMessage('Yönetici onayından sonra internet erişiminiz açılacaktır.');

    const loadPortalTemplate = async () => {
      setIsLoadingTemplate(true);
      setErrorMessage(null);
      try {
        const record = await getPortalTemplate(portalId);
        if (cancelled) return;
        setPortalTemplate(record);
        setTemplateName(record.name || 'Portal şablonu');
        setTheme(normalizeTheme(record.theme));
        const recordMethod = record.method || 'sms';
        setMethod(recordMethod);
        const normalizedMethods = normalizeEnabledMethods(record.meta?.enabled_methods, recordMethod);
        setEnabledMethods(normalizedMethods);
        setMethodFields(normalizeMethodFields(fieldsForPortalMethod(record, recordMethod), recordMethod));
        setSuccessMessage(record.success_message || '');
        const approval = record.meta?.approval || {};
        setApprovalRequired(Boolean(approval.required || normalizedMethods.includes('free')));
        setManagerEmails(Array.isArray(approval.manager_emails) ? approval.manager_emails.join(', ') : String(approval.manager_emails || ''));
        setApprovalMessage(String(approval.message || 'Yönetici onayından sonra internet erişiminiz açılacaktır.'));
        const presetId = record.meta?.applied_predefined_template_id || record.meta?.predefined_template_id;
        setSelectedPredef(typeof presetId === 'string' ? presetId : '');
        try {
          const history = await getPortalTemplateHistory(portalId);
          if (!cancelled) {
            setRevisionHistory(history);
          }
        } catch {
          if (!cancelled) {
            setRevisionHistory(null);
          }
        }
      } catch (err) {
        if (!cancelled) {
          setErrorMessage(err instanceof Error ? err.message : 'Portal şablonu yüklenemedi');
        }
      } finally {
        if (!cancelled) setIsLoadingTemplate(false);
      }
    };

    loadPortalTemplate();

    return () => {
      cancelled = true;
    };
  }, [portalId]);

  const previewHtml = useMemo(() => {
    return generatePreviewHtml(theme, method, methodFields, successMessage, approvalRequired, approvalMessage);
  }, [theme, method, methodFields, successMessage, approvalRequired, approvalMessage]);

  const updatePreview = useCallback(() => {
    if (iframeRef.current) {
      iframeRef.current.srcdoc = previewHtml;
    }
  }, [previewHtml]);

  useEffect(() => {
    updatePreview();
  }, [updatePreview]);

  const handleColorChange = (key: keyof TemplateTheme, value: string) => {
    setTheme(prev => ({ ...prev, [key]: value }));
  };

  const handleTextChange = (key: keyof TemplateTheme, value: string) => {
    setTheme(prev => ({ ...prev, [key]: value }));
  };

  const handleFontChange = (value: string) => {
    setTheme(prev => ({ ...prev, font_family: value }));
  };

  const handleSelectChange = (key: keyof TemplateTheme, value: string) => {
    setTheme(prev => ({ ...prev, [key]: value }));
  };

  const handleMethodChange = (value: string) => {
    setMethod(value);
    if (value === 'free') setApprovalRequired(true);
    const savedFields = fieldsForPortalMethod(portalTemplate, value);
    setMethodFields(normalizeMethodFields(savedFields, value));
  };

  const handleEnabledMethodChange = (value: string) => {
    setEnabledMethods(previous => {
      const isEnabled = previous.includes(value);
      if (isEnabled && previous.length === 1) {
        setErrorMessage('En az bir doğrulama yöntemi etkin kalmalıdır.');
        return previous;
      }
      const next = isEnabled ? previous.filter(item => item !== value) : [...previous, value];
      if (!isEnabled && value === 'free') {
        setApprovalRequired(true);
        setMethod('free');
        setMethodFields(normalizeMethodFields(fieldsForPortalMethod(portalTemplate, 'free'), 'free'));
      }
      if (!next.includes(method)) {
        const nextMethod = next[0] || 'sms';
        setMethod(nextMethod);
        setMethodFields(normalizeMethodFields(fieldsForPortalMethod(portalTemplate, nextMethod), nextMethod));
      }
      setErrorMessage(null);
      return next;
    });
  };

  const handleFieldChange = (index: number, key: keyof FormField, value: string | boolean) => {
    setMethodFields(prev => prev.map((field, fieldIndex) => (
      fieldIndex === index ? { ...field, [key]: value } : field
    )));
  };

  const addField = () => {
    const index = methodFields.length + 1;
    setMethodFields(prev => [...prev, {
      key: `custom_${index}`,
      name: `custom_${index}`,
      type: 'text',
      required: false,
      enabled: true,
      label: `Yeni alan ${index}`,
      placeholder: '',
      validation: 'none',
      order: index,
      options: [],
    }]);
  };

  const removeField = (index: number) => {
    setMethodFields(prev => prev.filter((_, itemIndex) => itemIndex !== index).map((field, itemIndex) => ({ ...field, order: itemIndex + 1 })));
  };

  const moveField = (index: number, direction: -1 | 1) => {
    setMethodFields(prev => {
      const nextIndex = index + direction;
      if (nextIndex < 0 || nextIndex >= prev.length) return prev;
      const next = [...prev];
      [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
      return next.map((field, itemIndex) => ({ ...field, order: itemIndex + 1 }));
    });
  };

  const refreshRevisionHistory = async () => {
    if (!portalId) return null;
    try {
      const history = await getPortalTemplateHistory(portalId);
      setRevisionHistory(history);
      return history;
    } catch {
      return null;
    }
  };

  const syncTemplateRecord = (record: PortalTemplateRecord, history?: PortalTemplateHistoryResponse | null) => {
    setPortalTemplate(record);
    setTemplateName(record.name || 'Portal şablonu');
    setTheme(normalizeTheme(record.theme));
    const recordMethod = record.method || 'sms';
    setMethod(recordMethod);
    const normalizedMethods = normalizeEnabledMethods(record.meta?.enabled_methods, recordMethod);
    setEnabledMethods(normalizedMethods);
    setMethodFields(normalizeMethodFields(fieldsForPortalMethod(record, recordMethod), recordMethod));
    setSuccessMessage(record.success_message || '');
    const approval = record.meta?.approval || {};
    setApprovalRequired(Boolean(approval.required || normalizedMethods.includes('free')));
    setManagerEmails(Array.isArray(approval.manager_emails) ? approval.manager_emails.join(', ') : String(approval.manager_emails || ''));
    setApprovalMessage(String(approval.message || 'Yönetici onayından sonra internet erişiminiz açılacaktır.'));
    if (history) {
      setRevisionHistory(history);
    }
    const presetId = record.meta?.applied_predefined_template_id || record.meta?.predefined_template_id;
    setSelectedPredef(typeof presetId === 'string' ? presetId : '');
  };

  const handleApplyPredefined = async (templateId: string) => {
    const tmpl = predefinedList.find(t => t.id === templateId);
    if (tmpl) {
      const nextTheme = { ...DEFAULT_THEME, ...tmpl.default_theme, title: tmpl.name };
      setTheme(nextTheme);
      setSelectedPredef(templateId);
      setShowPredefDropdown(false);

      if (portalId) {
        setIsSaving(true);
        setErrorMessage(null);
        try {
          const updated = await applyTemplate(portalId, templateId);
          if (updated) {
            syncTemplateRecord(updated as PortalTemplateRecord, await refreshRevisionHistory());
          }
          setSaved(true);
          setTimeout(() => setSaved(false), 2000);
        } catch (err) {
          setErrorMessage(err instanceof Error ? err.message : 'Şablon uygulanamadı');
        } finally {
          setIsSaving(false);
        }
      }
    }
  };

  const handleSave = async () => {
    if (!portalId) {
      setErrorMessage("Lütfen önce bir portal seçin");
      return;
    }

    const methodsToSave = normalizeEnabledMethods(enabledMethods, method);
    const selectedMethod = methodsToSave.includes(method) ? method : methodsToSave[0];
    const payload: PortalTemplateUpdatePayload = {
      name: templateName.trim() || 'Portal şablonu',
      method: selectedMethod,
      theme: toPortalThemePayload(theme),
      fields: methodFields,
      success_message: successMessage || null,
      terms_url: null,
      meta: {
        ...(portalTemplate?.meta || {}),
        method_fields: {
          ...((portalTemplate?.meta?.method_fields || {}) as Record<string, FormField[]>),
          [selectedMethod]: methodFields,
        },
        // Preserve the complete guest-facing method selection. The field
        // editor changes one method at a time; it must not silently disable
        // the other methods configured in the portal.
        enabled_methods: methodsToSave,
        approval: {
          // The free/contract method always requires manager approval.
          required: approvalRequired || methodsToSave.includes('free'),
          manager_emails: managerEmails.split(',').map(item => item.trim()).filter(Boolean),
          message: approvalMessage.trim() || 'Yönetici onayından sonra internet erişiminiz açılacaktır.',
        },
      },
    };

    setIsSaving(true);
    setErrorMessage(null);

    try {
      const updated = await updatePortalTemplate(portalId, payload);
      syncTemplateRecord(updated, await refreshRevisionHistory());
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Şablon kaydedilemedi');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRestoreRevision = async (revision: number) => {
    if (!portalId) return;

    setIsSaving(true);
    setErrorMessage(null);

    try {
      const updated = await restorePortalTemplateRevision(portalId, revision);
      syncTemplateRecord(updated, await refreshRevisionHistory());
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Revizyon geri alınamadı');
    } finally {
      setIsSaving(false);
    }
  };

  const previewClasses = previewMode === 'mobile'
    ? 'w-[300px] h-[550px] rounded-[40px] p-3 border-4 border-slate-800 bg-slate-900 shadow-2xl'
    : 'w-full h-[550px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white shadow-lg';

  return (
    <div className="min-h-[calc(100vh-8rem)] h-full flex flex-col overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
        <div className="flex items-center gap-3">
          {onBack && (
            <button onClick={onBack} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <h2 className="text-lg font-bold tracking-tight">
              {portalTemplate?.name || 'Portal şablonu düzenleyici'}
            </h2>
            <p className="text-[11px] text-slate-400">
              {portalTemplate
                ? `${portalTemplate.location_id ? 'Lokasyon portalı' : 'Müşteri varsayılanı'} · Revizyon ${portalTemplate.revision ?? 1} · ${methodLabel(portalTemplate.method)}`
                : 'Portal şablonu düzenleniyor'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <button
              onClick={() => setShowPredefDropdown(!showPredefDropdown)}
              className="px-3 py-1.5 text-xs font-semibold border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-1"
            >
              Hazır şablon seç <ChevronDown className="w-3 h-3" />
            </button>
            {showPredefDropdown && (
              <div className="absolute right-0 mt-1 w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl z-50 max-h-80 overflow-y-auto">
                {predefinedList.map(t => (
                  <button
                    key={t.id}
                    onClick={() => handleApplyPredefined(t.id)}
                    className={`w-full text-left px-3 py-2 text-xs hover:bg-slate-100 dark:hover:bg-slate-800 border-b border-slate-100 dark:border-slate-800 last:border-0 ${
                      selectedPredef === t.id ? 'bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600' : ''
                    }`}
                  >
                    <span className="font-semibold">{t.name}</span>
                    <span className="ml-2 text-[10px] opacity-50">({t.category})</span>
                    <p className="text-[10px] opacity-40 mt-0.5">{t.description}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex bg-slate-100 dark:bg-slate-800 rounded-xl p-0.5">
            <button
              onClick={() => setPreviewMode('desktop')}
              className={`p-1.5 rounded-lg transition-colors ${previewMode === 'desktop' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'hover:bg-slate-200 dark:hover:bg-slate-700'}`}
            >
              <Monitor className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPreviewMode('mobile')}
              className={`p-1.5 rounded-lg transition-colors ${previewMode === 'mobile' ? 'bg-white dark:bg-slate-700 shadow-sm' : 'hover:bg-slate-200 dark:hover:bg-slate-700'}`}
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>
          <button
            onClick={handleSave}
            disabled={isSaving || isLoadingTemplate}
            className="inline-flex items-center px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="w-3.5 h-3.5 mr-1.5" />
            {isSaving ? 'Kaydediliyor...' : 'Kaydet'}
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="px-6 py-2 bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 text-xs font-semibold flex items-center gap-2 border-b border-rose-100 dark:border-rose-900/30">
          <X className="w-3.5 h-3.5" />
          {errorMessage}
        </div>
      )}

      {isLoadingTemplate && (
        <div className="px-6 py-2 bg-sky-50 dark:bg-sky-950/20 text-sky-700 dark:text-sky-400 text-xs font-semibold flex items-center gap-2 border-b border-sky-100 dark:border-sky-900/30">
          <Eye className="w-3.5 h-3.5" />
          Portal şablonu yükleniyor...
        </div>
      )}

      {saved && (
        <div className="px-6 py-2 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 text-xs font-semibold flex items-center gap-2 border-b border-emerald-100 dark:border-emerald-900/30">
          <Check className="w-3.5 h-3.5" /> Şablon başarıyla kaydedildi.
        </div>
      )}

      <div className="mx-4 mt-3 rounded-xl border border-indigo-200 bg-indigo-50/70 px-4 py-3 dark:border-indigo-900/50 dark:bg-indigo-950/20 sm:mx-6">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <p className="text-xs font-bold text-indigo-950 dark:text-indigo-100">FortiGate captive portal yönlendirme adresi</p>
            <p className="mt-1 text-[11px] leading-relaxed text-indigo-900/70 dark:text-indigo-200/70">
              FortiGate dış captive portal ayarında bu adresi kullanın. <code>device_id</code>, Hotspot SQL’indeki seçili FortiGate cihaz UUID’sidir.
            </p>
            <select
              value={selectedDeviceId}
              onChange={event => setSelectedDeviceId(event.target.value)}
              disabled={!devices.length}
              className="mt-2 w-full max-w-sm rounded-lg border border-indigo-200 bg-white/80 px-2.5 py-2 text-[11px] text-indigo-950 outline-none focus:border-indigo-500 disabled:opacity-60 dark:border-indigo-800 dark:bg-slate-950/60 dark:text-indigo-100"
            >
              {!devices.length && <option value="">Önce Cihazlar ekranından FortiGate ekleyin</option>}
              {devices.filter(device => !portalTemplate?.location_id || device.location_id === portalTemplate.location_id).map(device => (
                <option key={device.id} value={device.id}>{device.name} · {String(device.id).slice(0, 8)}</option>
              ))}
            </select>
            <code className="mt-2 block break-all rounded-lg bg-white/80 px-2.5 py-2 text-[11px] text-indigo-950 dark:bg-slate-950/60 dark:text-indigo-100">{captiveRedirectUrl}</code>
          </div>
          <button type="button" onClick={() => void copyCaptiveRedirectUrl()} disabled={!selectedDeviceId} className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-lg border border-indigo-200 bg-white px-3 py-2 text-[11px] font-semibold text-indigo-700 hover:bg-indigo-50 disabled:cursor-not-allowed disabled:opacity-50 dark:border-indigo-800 dark:bg-slate-900 dark:text-indigo-200 dark:hover:bg-indigo-950/40">
            <Copy className="h-3.5 w-3.5" /> {redirectCopied ? 'Kopyalandı' : 'Adresi kopyala'}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 min-h-0 flex overflow-hidden bg-slate-100/70 dark:bg-slate-950/50">
        {/* Live preview */}
        <div className="min-w-0 flex-1 flex flex-col overflow-hidden border-r border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80">
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-100">Canlı önizleme</p>
              <p className="text-[11px] text-slate-500">Misafir portalının son kullanıcı görünümü</p>
            </div>
            <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-semibold text-slate-500 dark:bg-slate-800 dark:text-slate-300">
              {previewMode === 'mobile' ? 'Mobil görünüm' : 'Masaüstü görünüm'}
            </span>
          </div>
          <div className="flex-1 bg-slate-200/70 dark:bg-slate-950 flex items-center justify-center p-8 overflow-auto">
          <div className={previewClasses}>
            <div className={`w-full h-full ${previewMode === 'mobile' ? 'rounded-[30px]' : 'rounded-lg'} overflow-hidden bg-white`}>
              <iframe
                ref={iframeRef}
                srcDoc={previewHtml}
                title="Template Preview"
                className="w-full h-full border-0"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
          </div>
          </div>
        </div>

        {/* Right Panel: Settings */}
        <div className="w-[min(43%,450px)] min-w-[360px] shrink-0 bg-white dark:bg-slate-900 overflow-y-auto">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Şablon durumu</p>
                <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  v{revisionHistory?.current_revision ?? portalTemplate?.revision ?? 1}
                </p>
                <p className="text-[11px] text-slate-500">
                  {revisionActionLabel(revisionHistory?.current.action || portalTemplate?.revision_action || 'current')} ·{' '}
                  {formatRevisionTime(revisionHistory?.current.saved_at || portalTemplate?.revision_updated_at)}
                </p>
              </div>
              <div
                className={`rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider ${
                  portalTemplate?.is_active
                    ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400'
                    : 'bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400'
                }`}
              >
                {portalTemplate?.is_active ? 'Aktif' : 'Duraklatıldı'}
              </div>
            </div>

            {revisionHistory?.history?.length ? (
              <details className="mt-3 group" open={showHistory} onToggle={event => setShowHistory((event.currentTarget as HTMLDetailsElement).open)}>
                <summary className="flex cursor-pointer list-none items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-[11px] font-semibold text-slate-600 marker:hidden dark:border-slate-800 dark:text-slate-300">
                  <span>Revizyon geçmişi ({revisionHistory.history.length})</span>
                  <ChevronDown className="h-3.5 w-3.5 transition-transform group-open:rotate-180" />
                </summary>
              <div className="mt-2 space-y-2 max-h-52 overflow-y-auto pr-1">
                {[...revisionHistory.history].reverse().slice(0, 5).map(item => (
                  <div key={item.revision} className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40 p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                          Rev {item.revision} · {revisionActionLabel(item.action)}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {formatRevisionTime(item.saved_at)} · {item.saved_by || 'system'}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRestoreRevision(item.revision)}
                        disabled={isSaving || isLoadingTemplate}
                        className="text-[10px] font-semibold text-indigo-600 hover:text-indigo-500 disabled:opacity-40"
                      >
                        Geri al
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              </details>
            ) : (
              <p className="mt-3 text-[11px] text-slate-400">
                Henüz geçmiş revizyon yok.
              </p>
            )}
          </div>

          {/* Tabs */}
          <div className="flex border-b border-slate-200 dark:border-slate-800">
            {[
              { id: 'design' as const, label: 'Görünüm' },
              { id: 'fields' as const, label: 'Form alanları' },
              { id: 'legal' as const, label: 'Onay ve KVKK' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-2.5 text-xs font-semibold transition-colors ${
                  activeTab === tab.id
                    ? 'text-indigo-600 border-b-2 border-indigo-600'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="p-4 space-y-4">
            {activeTab === 'design' && (
              <>
                <Section title="Şablon kimliği" icon={<Type className="w-3.5 h-3.5" />}>
                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Şablon adı</label>
                  <input
                    value={templateName}
                    onChange={event => setTemplateName(event.target.value)}
                    className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />
                </Section>

                {/* Colors */}
                <Section title="Renkler" icon={<Palette className="w-3.5 h-3.5" />}>
                  <ColorRow label="Ana renk" value={theme.primary_color} onChange={v => handleColorChange('primary_color', v)} />
                  <ColorRow label="İkincil renk" value={theme.secondary_color} onChange={v => handleColorChange('secondary_color', v)} />
                  <ColorRow label="Arka plan" value={theme.bg_color} onChange={v => handleColorChange('bg_color', v)} />
                  <ColorRow label="Metin" value={theme.text_color} onChange={v => handleColorChange('text_color', v)} />
                </Section>

                {/* Typography */}
                <Section title="Metinler" icon={<Type className="w-3.5 h-3.5" />}>
                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Yazı tipi</label>
                  <select
                    value={theme.font_family}
                    onChange={e => handleFontChange(e.target.value)}
                    className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  >
                    {FONTS.map(f => (
                      <option key={f.value} value={f.value}>{f.label}</option>
                    ))}
                  </select>

                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Başlık</label>
                  <input
                    value={theme.title}
                    onChange={e => handleTextChange('title', e.target.value)}
                    className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />

                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Açıklama</label>
                  <input
                    value={theme.subtitle}
                    onChange={e => handleTextChange('subtitle', e.target.value)}
                    className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />

                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Alt bilgi</label>
                  <input
                    value={theme.footer}
                    onChange={e => handleTextChange('footer', e.target.value)}
                    className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />
                </Section>

                {/* Style */}
                <Section title="Stil" icon={<Layers className="w-3.5 h-3.5" />}>
                  <SelectRow label="Logo biçimi" value={theme.logo_style} options={LOGO_STYLES} onChange={v => handleSelectChange('logo_style', v)} />
                  <SelectRow label="Buton biçimi" value={theme.button_style} options={BUTTON_STYLES} onChange={v => handleSelectChange('button_style', v)} />
                  <SelectRow label="Yerleşim" value={theme.layout} options={LAYOUTS} onChange={v => handleSelectChange('layout', v)} />
                </Section>

                {/* Media */}
                <Section title="Görseller" icon={<Image className="w-3.5 h-3.5" />}>
                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Logo bağlantısı</label>
                  <input
                    value={theme.logo_url}
                    onChange={e => handleTextChange('logo_url', e.target.value)}
                    placeholder="https://example.com/logo.png"
                    className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />

                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Arka plan görseli</label>
                  <input
                    value={theme.bg_image_url}
                    onChange={e => handleTextChange('bg_image_url', e.target.value)}
                    placeholder="https://example.com/bg.jpg"
                    className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />
                </Section>

                {/* Redirect / Target Website */}
                <Section title="Giriş Sonrası Yönlendirme" icon={<Globe className="w-3.5 h-3.5" />}>
                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Yönlendirme Web Sitesi (URL)</label>
                  <input
                    type="url"
                    value={theme.redirect_url || ''}
                    onChange={e => handleTextChange('redirect_url', e.target.value)}
                    placeholder="https://vdata.com.tr"
                    className="w-full mt-1 px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />
                  <p className="mt-1 text-[11px] text-slate-400">Giriş başarılı olduğunda misafirin otomatik yönlendirileceği web sitesi.</p>

                  <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Yönlendirme Gecikmesi (Saniye)</label>
                  <input
                    type="number"
                    min={0}
                    max={60}
                    value={theme.redirect_delay_seconds ?? 3}
                    onChange={e => handleTextChange('redirect_delay_seconds', Number(e.target.value))}
                    placeholder="3"
                    className="w-full mt-1 px-2.5 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />
                </Section>

                {/* MAC Bypass / Remember Device */}
                <Section title="Cihazı Hatırla / MAC Yetkilendirme" icon={<Smartphone className="w-3.5 h-3.5" />}>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">Otomatik Giriş (MAC Bypass)</div>
                      <div className="text-[11px] text-slate-400">Tekrar gelen misafirleri login formu sormadan otomatik bağla.</div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={theme.remember_mac_enabled ?? true}
                        onChange={e => handleTextChange('remember_mac_enabled', e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>

                  {(theme.remember_mac_enabled ?? true) && (
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                      <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Cihaz Hatırlama Süresi</label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {[
                          { label: "1 Gün", days: 1 },
                          { label: "3 Gün", days: 3 },
                          { label: "5 Gün", days: 5 },
                          { label: "7 Gün", days: 7 },
                          { label: "15 Gün", days: 15 },
                          { label: "30 Gün", days: 30 },
                        ].map(item => (
                          <button
                            key={item.days}
                            type="button"
                            onClick={() => handleTextChange('mac_remember_days', item.days)}
                            className={`px-2 py-1.5 text-xs font-medium rounded-lg border transition ${
                              (theme.mac_remember_days ?? 3) === item.days
                                ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-500 text-indigo-700 dark:text-indigo-300 font-semibold'
                                : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 text-slate-600 dark:text-slate-300'
                            }`}
                          >
                            {item.label}
                          </button>
                        ))}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Seçilen gün boyunca ({theme.mac_remember_days ?? 3} gün) misafir WiFi kapsama alanına girdiğinde hiçbir doğrulama yapmadan doğrudan internete çıkar.
                      </p>
                    </div>
                  )}
                </Section>
              </>
            )}

            {activeTab === 'fields' && (
              <Section title="Form alanları" icon={<GripVertical className="w-3.5 h-3.5" />}>
                <p className="text-xs text-slate-500 mb-3">Portal formunu burada tamamen özelleştirebilirsin. Alanlar sadece aktif ve zorunlu işaretlendiği şekilde doğrulanır.</p>
                <div className="mb-4 rounded-xl border border-indigo-100 bg-indigo-50/60 p-3 dark:border-indigo-900/40 dark:bg-indigo-950/20">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">Portalda gösterilen doğrulama yöntemleri</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-indigo-900/70 dark:text-indigo-200/70">Bir yöntemin alanlarını düzenlemek için aşağıdan seçin. Kaydettiğinizde diğer etkin yöntemler korunur.</p>
                  <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {CAPTIVE_PORTAL_METHODS.map(item => (
                      <label key={item} className="flex cursor-pointer items-center gap-2 rounded-lg border border-indigo-100 bg-white/80 px-2.5 py-2 text-[11px] font-semibold text-slate-700 hover:border-indigo-300 dark:border-indigo-900/40 dark:bg-slate-900/60 dark:text-slate-200">
                        <input
                          type="checkbox"
                          checked={enabledMethods.includes(item)}
                          onChange={() => handleEnabledMethodChange(item)}
                          className="h-3.5 w-3.5 accent-indigo-600"
                        />
                        <span>{METHOD_LABELS[item] || item}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Doğrulama yöntemi</label>
                <select
                  value={method}
                  onChange={e => handleMethodChange(e.target.value)}
                  className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg font-medium"
                >
                  {CAPTIVE_PORTAL_METHODS.map(m => (
                    <option key={m} value={m}>{METHOD_LABELS[m] || m}</option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-2">Yöntem değiştirildiğinde o yöntemin başlangıç alanları yüklenir; sonrasında alan ekleyip kaldırabilirsin.</p>

                {methodFields.some(field => (field.key || field.name) === 'phone' && field.enabled === false) && (
                  <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 dark:border-amber-900/40 dark:bg-amber-950/20 p-3 text-[11px] text-amber-700 dark:text-amber-300">
                    Telefon alanı kapalı. SMS doğrulaması veya 5651 kullanıcı korelasyonu için telefon alanını açık tutman önerilir.
                  </div>
                )}

                <div className="space-y-2 pt-2">
                          {methodFields.length ? methodFields.map((field, index) => (
                    <div key={`field-${index}`} className={`rounded-xl border p-3 ${field.enabled === false ? 'border-slate-200 bg-slate-100/60 opacity-60 dark:border-slate-800 dark:bg-slate-950/20' : 'border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-950/40'}`}>
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <GripVertical className="w-3.5 h-3.5 text-slate-400" />
                          <div>
                            <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">{field.label || field.name}</p>
                            <p className="text-[10px] text-slate-400">{field.key || field.name}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <button type="button" title="Yukarı taşı" onClick={() => moveField(index, -1)} disabled={index === 0} className="p-1 rounded hover:bg-white dark:hover:bg-slate-800 disabled:opacity-25"><ArrowUp className="w-3 h-3" /></button>
                          <button type="button" title="Aşağı taşı" onClick={() => moveField(index, 1)} disabled={index === methodFields.length - 1} className="p-1 rounded hover:bg-white dark:hover:bg-slate-800 disabled:opacity-25"><ArrowDown className="w-3 h-3" /></button>
                          <button type="button" title="Alanı kaldır" onClick={() => removeField(index)} className="p-1 rounded text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30"><Trash2 className="w-3 h-3" /></button>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 mt-3">
                        <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Anahtar
                          <input value={field.key || field.name} onChange={e => {
                            const nextKey = e.target.value;
                            setMethodFields(prev => prev.map((item, itemIndex) => itemIndex === index ? { ...item, key: nextKey, name: nextKey } : item));
                          }} className="w-full mt-1 px-2 py-1.5 text-xs normal-case font-normal border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg" />
                        </label>
                        <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Tip
                          <select value={field.type} onChange={e => handleFieldChange(index, 'type', e.target.value)} className="w-full mt-1 px-2 py-1.5 text-xs normal-case font-normal border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg">
                            {['text', 'tel', 'email', 'number', 'date', 'password', 'url', 'textarea', 'select', 'checkbox'].map(type => <option key={type} value={type}>{type}</option>)}
                          </select>
                        </label>
                      </div>
                      <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Alan etiketi</label>
                      <input
                        value={field.label}
                        onChange={e => handleFieldChange(index, 'label', e.target.value)}
                        className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                      />
                      <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Giriş ipucu</label>
                      <input
                        value={field.placeholder || ''}
                        onChange={e => handleFieldChange(index, 'placeholder', e.target.value)}
                        placeholder="Misafire gösterilecek ipucu"
                        className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                      />
                      <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Validasyon</label>
                      <select
                        value={field.validation || 'none'}
                        onChange={e => handleFieldChange(index, 'validation', e.target.value)}
                        className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                      >
                        <option value="none">Yok</option><option value="tr_phone">Türkiye telefonu</option><option value="tr_tc">T.C. kimlik</option><option value="email">E-posta</option><option value="digits">Sadece rakam</option>
                      </select>
                      {field.type === 'select' && (
                        <>
                          <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Seçenekler</label>
                          <textarea
                            value={(field.options || []).map(option => `${option.label}|${option.value}`).join('\n')}
                            onChange={e => handleFieldChange(index, 'options', e.target.value.split('\n').map(line => line.trim()).filter(Boolean).map(line => {
                              const [label, value] = line.split('|');
                              return { label: (label || value || '').trim(), value: (value || label || '').trim() };
                            }).filter(option => option.label && option.value) as any)}
                            placeholder="Misafir|guest\nPersonel|staff"
                            rows={3}
                            className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                          />
                          <p className="text-[10px] text-slate-400">Her satırda <code>etiket|değer</code> biçimini kullan.</p>
                        </>
                      )}
                      <div className="flex items-center gap-4 mt-3">
                        <label className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-500"><input type="checkbox" checked={field.enabled !== false} onChange={() => handleFieldChange(index, 'enabled', field.enabled === false)} /> Göster</label>
                        <label className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-500"><input type="checkbox" checked={Boolean(field.required)} onChange={() => handleFieldChange(index, 'required', !field.required)} /> Zorunlu</label>
                      </div>
                    </div>
                  )) : (
                    <p className="text-xs text-slate-400">Bu yöntem için ek alan gerekmiyor.</p>
                  )}
                </div>
                <button type="button" onClick={addField} className="mt-3 w-full inline-flex items-center justify-center gap-1.5 rounded-xl border border-dashed border-indigo-300 px-3 py-2 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 dark:border-indigo-800 dark:text-indigo-400 dark:hover:bg-indigo-950/20"><Plus className="w-3.5 h-3.5" /> Özel alan ekle</button>
              </Section>
            )}

            {activeTab === 'legal' && (
              <Section title="Onay ve KVKK" icon={<Eye className="w-3.5 h-3.5" />}>
                <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Başarılı giriş mesajı</label>
                <textarea
                  value={successMessage}
                  onChange={e => setSuccessMessage(e.target.value)}
                  placeholder="Bağlantınız başarıyla oluşturuldu."
                  rows={2}
                  className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                />
                <p className="text-[10px] text-slate-400 mt-1">Doğrulama sonrası misafire gösterilir.</p>

                <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-950/30">
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-200">İnternet kullanım politikası</p>
                  <p className="mt-1 text-[10px] leading-relaxed text-slate-500">Misafir internete bağlanmadan önce bu metni kabul eder.</p>
                  <textarea
                    value={theme.internetPolicyText || theme.termsText || ''}
                    onChange={e => setTheme(prev => ({ ...prev, internetPolicyText: e.target.value, termsText: e.target.value }))}
                    placeholder="İnternet kullanım politikasını okudum, kabul ediyorum."
                    rows={3}
                    className="w-full mt-2 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />
                </div>

                <div className="mt-3 rounded-xl border border-slate-200 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-950/30">
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-200">KVKK aydınlatma metni</p>
                  <p className="mt-1 text-[10px] leading-relaxed text-slate-500">Kişisel verilerin işlenmesine ilişkin metni ayrı tutun.</p>
                  <textarea
                    value={theme.kvkkText || ''}
                    onChange={e => handleTextChange('kvkkText', e.target.value)}
                    placeholder="KVKK aydınlatma metnini okudum, kişisel verilerimin işlenmesini kabul ediyorum."
                    rows={3}
                    className="w-full mt-2 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                  />
                </div>

                <label className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider mt-3 block">Destek metni</label>
                <textarea
                  value={theme.supportText || ''}
                  onChange={e => handleTextChange('supportText', e.target.value)}
                  placeholder="Yardıma ihtiyacınız varsa resepsiyon ile iletişime geçin."
                  rows={3}
                  className="w-full mt-1 px-2 py-1.5 text-xs border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg"
                />

                <div className="mt-5 rounded-2xl border border-indigo-200 bg-indigo-50/60 p-3 dark:border-indigo-900/50 dark:bg-indigo-950/20">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold text-indigo-900 dark:text-indigo-200">Yönetici onayı</p>
                      <p className="mt-1 text-[10px] leading-relaxed text-indigo-700 dark:text-indigo-300">Açıkken doğrulanan misafir FortiGate'e gönderilmez; yönetici paneli veya e-posta onayından sonra erişim açılır.</p>
                    </div>
                    <input type="checkbox" checked={approvalRequired} onChange={e => setApprovalRequired(e.target.checked)} className="mt-1 h-4 w-4 accent-indigo-600" />
                  </div>
                  {approvalRequired && (
                    <div className="mt-3 space-y-2.5">
                      <label className="text-[10px] font-semibold uppercase tracking-wider text-indigo-800 dark:text-indigo-300">Onay e-postaları</label>
                      <input value={managerEmails} onChange={e => setManagerEmails(e.target.value)} placeholder="yonetici@firma.com, resepsiyon@firma.com" className="w-full mt-1 px-2 py-1.5 text-xs border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-800 rounded-lg" />
                      <p className="text-[10px] text-indigo-700/70 dark:text-indigo-400/80">Virgülle ayır. Boş bırakırsan müşteri iletişim e-postası kullanılır.</p>
                      <label className="text-[10px] font-semibold uppercase tracking-wider text-indigo-800 dark:text-indigo-300">Misafire gösterilecek mesaj</label>
                      <textarea value={approvalMessage} onChange={e => setApprovalMessage(e.target.value)} rows={2} className="w-full mt-1 px-2 py-1.5 text-xs border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-800 rounded-lg" />
                    </div>
                  )}
                </div>
              </Section>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Sub-components ───────────────────────────────────────────────────────────

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-2 text-slate-500 dark:text-slate-400">
        {icon}
        <h4 className="text-[11px] font-bold uppercase tracking-wider">{title}</h4>
      </div>
      <div className="space-y-2.5">{children}</div>
    </div>
  );
}

function ColorRow({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-xs text-slate-500">{label}</span>
      <div className="flex items-center gap-1.5">
        <input type="color" value={value} onChange={e => onChange(e.target.value)} className="w-7 h-7 rounded border border-slate-200 dark:border-slate-700 cursor-pointer" />
        <input value={value} onChange={e => onChange(e.target.value)} className="w-20 px-1.5 py-1 text-[10px] font-mono border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded" />
      </div>
    </div>
  );
}

function SelectRow({ label, value, options, onChange }: { label: string; value: string; options: { value: string; label: string }[]; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-xs text-slate-500">{label}</span>
      <select value={value} onChange={e => onChange(e.target.value)} className="text-xs px-2 py-1 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg">
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function CheckboxToggle({ label, defaultChecked }: { label: string; defaultChecked?: boolean }) {
  const [checked, setChecked] = useState(defaultChecked ?? false);
  return (
    <label className="flex items-center gap-2 cursor-pointer">
      <div
        onClick={() => setChecked(!checked)}
        className={`w-8 h-4 rounded-full transition-colors relative ${checked ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'}`}
      >
        <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full shadow transition-transform ${checked ? 'translate-x-4' : 'translate-x-0.5'}`} />
      </div>
      <span className="text-xs text-slate-500">{label}</span>
    </label>
  );
}
