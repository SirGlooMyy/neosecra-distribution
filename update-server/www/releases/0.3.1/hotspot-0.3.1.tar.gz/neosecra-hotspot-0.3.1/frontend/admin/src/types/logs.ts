export type TimeWindow = '15m' | '1h' | '24h' | '7d' | 'custom';

export type LogType = 'traffic' | 'event' | 'utm' | 'iap' | 'anomaly' | 'vpn' | 'webfilter' | 'app-ctrl' | 'dns';

export interface FirewallLog {
  id: string;
  timestamp: string;
  vendor: string;
  hostname: string | null;
  log_type: LogType;
  log_subtype: string | null;
  severity: string;
  action: string;
  message: string;
  src_ip: string;
  dst_ip: string;
  src_port: number | null;
  dst_port: number | null;
  user: string | null;
  hostname: string | null;
  message: string;
  raw: string;
  parsed: Record<string, unknown>;
  correlation_id: string | null;
  correlation_type: string | null;
  correlation_reason: string | null;
  correlation_group_size: number | null;
}

export interface SearchFilters {
  q?: string;
  time_window?: TimeWindow;
  vendor?: string;
  log_type?: LogType[];
  severity?: string[];
  action?: string[];
  src_ip?: string;
  dst_ip?: string;
  src_port?: number | null;
  dst_port?: number | null;
  user?: string;
  from?: string;
  to?: string;
  page?: number;
  page_size?: number;
}

export interface SearchResponse {
  items: FirewallLog[];
  total: number;
  page: number;
  page_size: number;
  has_next: boolean;
}

export interface FacetItem {
  value: string;
  count: number;
}

export interface FacetResult {
  vendor: FacetItem[];
  severity: FacetItem[];
  log_type: FacetItem[];
  action: FacetItem[];
  histogram?: { timestamp: string; count: number }[];
}

export interface CorrelateResult {
  session_id: string;
  items: FirewallLog[];
  total: number;
}

export interface SearchView {
  id: string;
  name: string;
  query: Record<string, unknown>;
  surface: string;
  created_at?: string;
}
