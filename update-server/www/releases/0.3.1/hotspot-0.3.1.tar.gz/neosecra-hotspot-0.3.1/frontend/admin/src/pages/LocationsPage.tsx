import React, { useState, useEffect } from "react";
import { getLocations, addLocation, deleteLocation, getCurrentScope } from "../lib/api";
import { Plus, Trash2, Search, MapPin, RefreshCw, X, Radio, Server, CheckCircle2 } from "lucide-react";

interface Location {
  id: string;
  customer_id?: string;
  name: string;
  customerName: string;
  ssid: string;
  timezone: string;
  devicesCount: number;
  status: string;
}

export const LocationsPage: React.FC = () => {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    defaultSsid: "",
    timezone: "Europe/Istanbul",
  });
  const [installationCustomerId, setInstallationCustomerId] = useState<string | null>(null);

  const loadLocations = async () => {
    setLoading(true);
    try {
      const data = await getLocations();
      setLocations((data || []).map((location: any) => ({
        ...location,
        id: String(location.id),
        customer_id: location.customer_id,
        customerName: location.customer_name || location.customer_id || "Kurulum müşterisi",
        ssid: location.default_ssid || "—",
        timezone: location.timezone || "Europe/Istanbul",
        devicesCount: Number(location.devices_count ?? location.devicesCount ?? 0),
        status: location.status || "online",
      })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLocations();
    getCurrentScope().then((scope) => {
      if (scope?.customer_id) setInstallationCustomerId(scope.customer_id);
    }).catch(() => undefined);
  }, []);

  const filtered = locations.filter(
    (l) =>
      l.name.toLowerCase().includes(search.toLowerCase()) ||
      l.customerName.toLowerCase().includes(search.toLowerCase()) ||
      l.ssid.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.defaultSsid) return;

    try {
      const newLoc = await addLocation({
        name: formData.name,
        ...(installationCustomerId ? { customer_id: installationCustomerId } : {}),
        default_ssid: formData.defaultSsid,
        timezone: formData.timezone,
      });
      setLocations([{ ...newLoc, customerName: newLoc.customer_id || "Kurulum müşterisi", ssid: newLoc.default_ssid || "—", devicesCount: 0, status: "online" }, ...locations]);
      setFormData({ name: "", defaultSsid: "", timezone: "Europe/Istanbul" });
      setShowAddModal(false);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`"${name}" lokasyonunu silmek istediğinize emin misiniz?`)) {
      try {
        await deleteLocation(id);
        setLocations(locations.filter((l) => l.id !== id));
      } catch (err) {
        console.error(err);
      }
    }
  };

  const totalDevices = locations.reduce((sum, l) => sum + l.devicesCount, 0);

  return (
    <div className="space-y-6">
      {/* 1. Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Lokasyon Yönetimi
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Wi-Fi ağlarının yayınlandığı fiziksel noktaları, SSID yapılandırmalarını ve zaman dilimlerini yönetin.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadLocations}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-850 dark:text-slate-200 dark:hover:bg-slate-800 transition shadow-xs"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${loading ? "animate-spin" : ""}`} />
            Yenile
          </button>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
          >
            <Plus className="h-3.5 w-3.5" /> Yeni Lokasyon
          </button>
        </div>
      </div>

      {/* 2. 4-Tile Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Toplam Lokasyon</span>
            <MapPin className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{locations.length}</span>
            <span className="text-xs text-slate-500">nokta</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Bağlı Cihazlar</span>
            <Server className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{totalDevices}</span>
            <span className="text-xs text-slate-500">cihaz</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Yayınlanan SSID</span>
            <Radio className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {new Set(locations.map((l) => l.ssid).filter((s) => s && s !== "—")).size}
            </span>
            <span className="text-xs text-slate-500">farklı SSID</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">Hizmet Durumu</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-base font-bold text-emerald-600 dark:text-emerald-400">Tümü Aktif</span>
          </div>
        </div>
      </div>

      {/* 3. Search Bar */}
      <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-xs dark:border-slate-800 dark:bg-slate-900">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Lokasyon adı, SSID veya müşteri filtrele..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500 focus:bg-white dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:focus:bg-slate-900"
          />
        </div>
      </div>

      {/* 4. Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900">
        {loading ? (
          <div className="flex items-center justify-center py-12 text-slate-500">
            <RefreshCw className="h-5 w-5 animate-spin text-blue-500 mr-2" />
            <span className="text-xs">Lokasyonlar yükleniyor...</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-4 py-3">Lokasyon Adı</th>
                  <th className="px-4 py-3">Müşteri</th>
                  <th className="px-4 py-3">SSID</th>
                  <th className="px-4 py-3">Saat Dilimi</th>
                  <th className="px-4 py-3">Cihaz Sayısı</th>
                  <th className="px-4 py-3">Durum</th>
                  <th className="px-4 py-3 text-right">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition">
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                      {l.name}
                    </td>
                    <td className="px-4 py-3 text-slate-500">{l.customerName}</td>
                    <td className="px-4 py-3">
                      <span className="font-mono rounded bg-slate-100 px-2 py-0.5 text-[11px] dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {l.ssid}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-500">{l.timezone}</td>
                    <td className="px-4 py-3 font-medium text-slate-700 dark:text-slate-300">{l.devicesCount} Cihaz</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-semibold border ${
                        l.status === 'online'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800'
                          : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800'
                      }`}>
                        {l.status === 'online' ? 'Aktif' : 'Uyarı'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => handleDelete(l.id, l.name)}
                        className="rounded-md p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-slate-800"
                        title="Lokasyonu Sil"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-xs text-slate-500">
                      Arama kriterlerinize uygun lokasyon bulunamadı.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 5. Add Location Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleAddSubmit} className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Yeni Lokasyon Ekle</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 text-xs">
              <div className="space-y-1 sm:col-span-2">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Lokasyon Adı *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Örn: Kadıköy Şube, Teras Kat"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Default SSID (Kablosuz Ağ) *</label>
                <input
                  type="text"
                  required
                  value={formData.defaultSsid}
                  onChange={(e) => setFormData({ ...formData, defaultSsid: e.target.value })}
                  placeholder="Örn: Sirket_Misafir_Wifi"
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">Saat Dilimi</label>
                <select
                  value={formData.timezone}
                  onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-800"
                >
                  <option value="Europe/Istanbul">Europe/Istanbul (GMT+3)</option>
                  <option value="Europe/London">Europe/London (GMT+0)</option>
                  <option value="Europe/Berlin">Europe/Berlin (GMT+1)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                İptal
              </button>
              <button
                type="submit"
                className="rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-700 transition"
              >
                Lokasyonu Kaydet
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
