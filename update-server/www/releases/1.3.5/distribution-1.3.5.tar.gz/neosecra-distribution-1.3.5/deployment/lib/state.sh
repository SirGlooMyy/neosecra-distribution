#!/usr/bin/env bash
# State management helpers for the NeoSecra Assessment deployment.
# Source after common.sh
set -Euo pipefail

# Write installed version
write_installed_version() {
  local version="$1"
  mkdir -p "$STATE_DIR"
  echo "$version" > "${STATE_DIR}/installed-version"
  echo "$version" > "${STATE_DIR}/active-release"
}

# Read installed version
read_installed_version() {
  if [[ -f "${STATE_DIR}/installed-version" ]]; then
    cat "${STATE_DIR}/installed-version"
  else
    echo "none"
  fi
}

# Create release directory
create_release_dir() {
  local version="$1"
  local dir; dir=$(release_dir "$version")
  mkdir -p "$dir"
  echo "$dir"
}

# Switch current symlink
switch_current() {
  local version="$1"
  local target; target=$(release_dir "$version")

  # Save previous
  if [[ -L "$(current_symlink)" ]]; then
    local old; old=$(readlink "$(current_symlink)")
    ln -sfn "$old" "$(previous_symlink)"
  fi

  ln -sfn "$target" "$(current_symlink)"
  ok "Active release switched to ${version}"
}

# Create install state directories
create_install_dirs() {
  mkdir -p \
    "${RELEASES_DIR}" \
    "${SHARED_DIR}/reports" \
    "${SHARED_DIR}/uploads" \
    "${SHARED_DIR}/certificates" \
    "${STATE_DIR}" \
    "${BACKUP_ROOT}" \
    "${JOURNAL_DIR}" \
    "${LOG_DIR}" \
    "${CREDENTIAL_DIR}"

  # Secure credential directory
  chmod 0700 "$CREDENTIAL_DIR" 2>/dev/null || true
}

# Write upgrade journal
write_journal() {
  local file="$1" previous="${2:-}" status="${3:-completed}"
  mkdir -p "$JOURNAL_DIR"
  cat > "${JOURNAL_DIR}/${file}" << JOURNAL
{
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "product": "${PRODUCT}",
  "edition": "${EDITION}",
  "previous_version": "${previous}",
  "status": "${status}"
}
JOURNAL
  ok "Journal: ${JOURNAL_DIR}/${file}"
}

# Read most recent journal entry's previous_version
journal_previous_version() {
  local latest
  latest="$(ls -t "${JOURNAL_DIR}" 2>/dev/null | head -1)" || return 1
  [[ -n "$latest" ]] || return 1
  python3 -c "import json; d=json.load(open('${JOURNAL_DIR}/${latest}')); print(d.get('previous_version',''))" 2>/dev/null || \
    grep -o '"previous_version"[[:space:]]*:[[:space:]]*"\([^"]*\)"' "${JOURNAL_DIR}/${latest}" 2>/dev/null | sed -E 's/.*"([^"]+)".*/\1/' || return 1
}

write_install_state() {
  local version="$1" phase="$2" status="$3"
  mkdir -p "$STATE_DIR"
  cat > "${STATE_DIR}/install-${version}.state" << STATE
timestamp=$(date -u +%Y-%m-%dT%H:%M:%SZ)
product=${PRODUCT}
edition=${EDITION}
version=${version}
phase=${phase}
status=${status}
STATE
}

# Check if already installed
is_installed() {
  [[ -f "${STATE_DIR}/installed-version" ]] && [[ -d "$(current_symlink)" ]]
}
