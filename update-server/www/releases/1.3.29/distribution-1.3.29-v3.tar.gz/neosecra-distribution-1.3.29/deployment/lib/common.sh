#!/usr/bin/env bash
# Shared helpers for the NeoSecra Assessment deployment scripts.
# Sourced by install/upgrade/backup/smoke-tests scripts.
set -Euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
V1_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# --- Product identity ---
PRODUCT="neosecra-security-health"
EDITION="security-health"
PROJECT="neosecra-assessment"
PROJECT_NAME="${PROJECT}"

# --- Install target ---
INSTALL_ROOT="/opt/neosecra/assessment"
RELEASES_DIR="${INSTALL_ROOT}/releases"
SHARED_DIR="${INSTALL_ROOT}/shared"
STATE_DIR="${INSTALL_ROOT}/state"
BACKUP_ROOT="${INSTALL_ROOT}/backups"
JOURNAL_DIR="${INSTALL_ROOT}/upgrade-journal"
CREDENTIAL_DIR="${INSTALL_ROOT}/credentials"
LOG_DIR="${INSTALL_ROOT}/logs"
COMPOSE_PROJECT="${PROJECT_NAME}"

# --- Resolve key paths from V1_ROOT ---
COMPOSE_FILE="${V1_ROOT}/docker-compose.v1.yml"
ENV_FILE="${V1_ROOT}/.env.v1"
ENV_EXAMPLE="${V1_ROOT}/.env.v1.example"
VERSION_FILE="${V1_ROOT}/VERSION"
MANIFEST_FILE="${V1_ROOT}/release-manifest.yaml"

# --- Image registry (kendi sunucumuz — ghcr bagimliligi kalmadi) ---
GHCR_REGISTRY="registry.neosecra.com"
GHCR_NAMESPACE=""

# --- Logging ---
if [[ -t 2 ]]; then
  _C_RED=$'\033[31m'; _C_YEL=$'\033[33m'; _C_GRN=$'\033[32m'; _C_DIM=$'\033[2m'; _C_RST=$'\033[0m'
else
  _C_RED=''; _C_YEL=''; _C_GRN=''; _C_DIM=''; _C_RST=''
fi

log()  { printf '%s[info]%s  %s\n'  "$_C_DIM" "$_C_RST" "$*" >&2; }
ok()   { printf '%s[ok]%s    %s\n'  "$_C_GRN" "$_C_RST" "$*" >&2; }
warn() { printf '%s[warn]%s  %s\n'  "$_C_YEL" "$_C_RST" "$*" >&2; }
err()  { printf '%s[error]%s %s\n'  "$_C_RED" "$_C_RST" "$*" >&2; }

die() { err "$1"; exit "${2:-1}"; }

# --- Version ---
read_version() {
  if [[ -f "$VERSION_FILE" ]]; then
    local v; v="$(tr -d '[:space:]' < "$VERSION_FILE")"
    # Tolerate key=value format (some older releases shipped "VERSION=x.y.z").
    v="${v#VERSION=}"
    echo "${v:-unknown}"
  else
    echo "unknown"
  fi
}

# --- Docker ---
# Sudo fallback: the operator user (neosecra) is not in the docker group on
# production installs — install/upgrade run as root, but the management CLI
# (neosecra status/version/...) runs as the operator and must transparently
# use sudo, otherwise every compose call silently fails (status → NOT RUNNING).
_DOCKER_NEEDS_SUDO=""
if ! command docker info >/dev/null 2>&1; then
  _DOCKER_NEEDS_SUDO="1"
fi
docker() {
  if [[ -n "$_DOCKER_NEEDS_SUDO" ]]; then
    if [[ -n "${SUDO_ASKPASS:-}" ]]; then
      command sudo -A docker "$@"
    else
      command sudo docker "$@"
    fi
  else
    command docker "$@"
  fi
}
require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "required command not found: $1" 2
}

require_compose_v2() {
  require_cmd docker
  docker compose version >/dev/null 2>&1 || \
    die "docker compose v2 plugin not available" 2
}

compose() {
  docker compose \
    --project-name "$PROJECT_NAME" \
    --project-directory "$V1_ROOT" \
    --env-file "$ENV_FILE" \
    -f "$COMPOSE_FILE" \
    "$@"
}

run_compose() {
  compose "$@"
}

stack_is_running() {
  run_compose ps --status running -q 2>/dev/null | grep -q . || return 1
}

port_is_free() {
  local port="$1"
  if command -v ss >/dev/null 2>&1; then
    ! ss -ltn 2>/dev/null | awk '{print $4}' | grep -qE "[.:]${port}\$" && return 0 || return 1
  elif command -v netstat >/dev/null 2>&1; then
    ! netstat -ltn 2>/dev/null | awk '{print $4}' | grep -qE "[.:]${port}\$" && return 0 || return 1
  fi
  return 0
}

port_belongs_to_project() {
  local port="$1" project="${2:-$COMPOSE_PROJECT}"
  docker ps --format '{{.Names}} {{.Ports}}' 2>/dev/null | \
    awk -v p=":${port}->" -v proj="$project" '$0 ~ p && $1 ~ proj {found=1} END {exit !found}'
}

existing_volumes() {
  docker volume ls -q --filter "name=${COMPOSE_PROJECT}_" 2>/dev/null || true
}

# --- Env ---
env_value() {
  local key="$1" default="${2:-}"
  [[ -f "$ENV_FILE" ]] || { echo "$default"; return; }
  local val
  val=$(grep -E "^${key}=" "$ENV_FILE" 2>/dev/null | tail -n1 | cut -d= -f2- || true)
  echo "${val:-$default}"
}

env_file_value() {
  local file="$1" key="$2" default="${3:-}" val
  [[ -f "$file" ]] || { echo "$default"; return; }
  val=$(grep -E "^${key}=" "$file" 2>/dev/null | tail -n1 | cut -d= -f2- || true)
  echo "${val:-$default}"
}

random_hex() {
  local bytes="$1"
  if command -v openssl >/dev/null 2>&1; then
    openssl rand -hex "$bytes"
  else
    python3 -c "import secrets; print(secrets.token_hex(${bytes}))"
  fi
}

random_admin_password() {
  local candidate
  for _ in $(seq 1 30); do
    candidate="Ns1!$(random_hex 24)"
    if admin_password_is_valid "$candidate"; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  printf 'Ns1!%s' "$(random_hex 32)"
}

admin_password_is_valid() {
  local value="${1:-}" lower
  lower="${value,,}"
  [[ ${#value} -ge 12 ]] || return 1
  is_placeholder_value "$value" && return 1
  [[ "$value" != "Admin123!" && "$value" != "Admin123!sec" && "$value" != "CHANGE_ME_ADMIN_PASSWORD_12_CHARS_MIN" ]] || return 1
  for weak in password 123456 changeme admin123 qwerty letmein; do
    [[ "$lower" != *"$weak"* ]] || return 1
  done
  [[ "$value" =~ [A-Z] ]] || return 1
  [[ "$value" =~ [a-z] ]] || return 1
  [[ "$value" =~ [0-9] ]] || return 1
  [[ "$value" =~ [^a-zA-Z0-9] ]] || return 1
  return 0
}

ensure_env_admin_password() {
  local current
  current="$(env_value FIRST_ADMIN_PASSWORD "")"
  if ! admin_password_is_valid "$current"; then
    if [[ "${NEOSECRA_ROTATE_INITIAL_ADMIN:-0}" == "1" ]]; then
      rotate_initial_admin_password
      return 0
    fi
    if [[ -n "$current" ]]; then
      warn "FIRST_ADMIN_PASSWORD does not satisfy production complexity but is already set; preserving existing credential without rotation. Set NEOSECRA_ROTATE_INITIAL_ADMIN=1 to rotate."
      return 0
    fi
    upsert_env_value FIRST_ADMIN_PASSWORD "$(random_admin_password)"
    warn "FIRST_ADMIN_PASSWORD was empty/invalid for production and was regenerated; credential file updated"
  fi
}

rotate_initial_admin_password() {
  upsert_env_value FIRST_ADMIN_PASSWORD "$(random_admin_password)"
  write_initial_admin_credentials
  ok "Initial admin password rotated; credential file updated"
}

upsert_env_value() {
  local key="$1" value="$2" tmp
  tmp="$(mktemp)"
  awk -v k="$key" -v v="$value" '
    BEGIN { done=0 }
    $0 ~ "^" k "=" { print k "=" v; done=1; next }
    { print }
    END { if (!done) print k "=" v }
  ' "$ENV_FILE" > "$tmp"
  mv "$tmp" "$ENV_FILE"
  chmod 0600 "$ENV_FILE"
}

ensure_env_value() {
  local key="$1" value="$2" current
  current="$(env_value "$key" "")"
  if [[ -z "$current" ]] || is_placeholder_value "$current"; then
    upsert_env_value "$key" "$value"
  fi
}

release_image_ref() {
  local service="$1" fallback="$2" ref=""
  if declare -F manifest_image_ref >/dev/null 2>&1; then
    ref="$(manifest_image_ref "$service" 2>/dev/null || true)"
  fi
  printf '%s' "${ref:-$fallback}"
}

apply_release_image_refs() {
  local version backend_image worker_image frontend_image
  version="${1:-$(read_version)}"
  if [[ "$version" == "$(read_version)" ]]; then
    backend_image="$(release_image_ref backend "registry.neosecra.com/security-health-backend:${version}")"
    worker_image="$(release_image_ref worker "$backend_image")"
    frontend_image="$(release_image_ref frontend "registry.neosecra.com/security-health-frontend:${version}")"
  else
    backend_image="registry.neosecra.com/security-health-backend:${version}"
    worker_image="$backend_image"
    frontend_image="registry.neosecra.com/security-health-frontend:${version}"
  fi

  upsert_env_value NEOSECRA_VERSION "$version"
  upsert_env_value BACKEND_IMAGE "$backend_image"
  upsert_env_value WORKER_IMAGE "$worker_image"
  upsert_env_value FRONTEND_IMAGE "$frontend_image"
}

ensure_env_secret() {
  local key="$1" bytes="$2" current
  current="$(env_value "$key" "")"
  if [[ -z "$current" ]] || is_placeholder_value "$current"; then
    upsert_env_value "$key" "$(random_hex "$bytes")"
  fi
}

# --- Frontend TLS ---
# Generate the per-install self-signed cert nginx serves on :443 (TLS is
# mandatory — admin credentials must never cross the LAN in cleartext).
# Idempotent: existing cert/key are kept (upgrades, re-runs).
ensure_frontend_tls() {
  local tls_dir="${V1_ROOT}/config/tls"
  local crt="${tls_dir}/server.crt" key="${tls_dir}/server.key"
  if [[ -s "$crt" && -s "$key" ]]; then
    return 0
  fi
  if ! command -v openssl >/dev/null 2>&1; then
    die "openssl bulunamadi — frontend TLS sertifikasi uretilemedi (openssl kurun)" 4
  fi
  mkdir -p "$tls_dir"
  # SAN: every routable host IP + loopback, so both LAN and Tailscale access work.
  local san="IP:127.0.0.1,DNS:localhost" ip
  while read -r ip; do
    [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ && "$ip" != "127.0.0.1" ]] && san="${san},IP:${ip}"
  done < <(hostname -I 2>/dev/null | tr ' ' '\n' | sort -u)
  openssl req -x509 -newkey rsa:2048 -nodes \
    -keyout "$key" -out "$crt" -days 825 \
    -subj "/CN=neosecra.local" \
    -addext "subjectAltName=${san}" 2>/dev/null \
    || die "TLS sertifikasi uretilemedi (openssl req basarisiz)" 4
  chmod 0600 "$key"
  chmod 0644 "$crt"
  ok "Frontend TLS sertifikasi uretildi: ${crt} (SAN: ${san})"
  warn "Self-signed sertifika — tarayici ilk giriste guven uyariasi gosterir (kabul edip devam edin)"
}

ensure_initial_admin_email() {
  local current
  current="$(env_value FIRST_ADMIN_EMAIL "")"
  if [[ -z "$current" ]] || is_placeholder_value "$current" || [[ "$current" == "admin@neosecra.local" ]]; then
    upsert_env_value FIRST_ADMIN_EMAIL "admin@neosecra.io"
  fi
}

initialize_env_file() {
  local version frontend_port postgres_password backup_path
  version="$(read_version)"

  umask 077
  if [[ -f "$ENV_FILE" ]]; then
    backup_path="${ENV_FILE}.backup-$(date -u +%Y%m%dT%H%M%SZ)"
    cp -a "$ENV_FILE" "$backup_path"
    chmod 0600 "$backup_path" 2>/dev/null || true
    log ".env.v1 backup created: ${backup_path}"
    warn "Mevcut .env.v1 yedeklendi (VERİ KAYBINA KARŞI saklanır): ${backup_path}"
  else
    mkdir -p "$(dirname "$ENV_FILE")"
    : > "$ENV_FILE"
    chmod 0600 "$ENV_FILE"
  fi

  ensure_env_value POSTGRES_IMAGE "postgres:15.18-alpine3.24"
  ensure_env_value REDIS_IMAGE "redis:7.4.9-alpine3.21"
  apply_release_image_refs
  ensure_env_value OPENVAS_IMAGE "immauss/openvas:26.07.12.01"

  ensure_env_value POSTGRES_USER "neosecra"
  ensure_env_secret POSTGRES_PASSWORD 24
  ensure_env_value POSTGRES_DB "neosecra_assessment"
  ensure_env_value REDIS_URL "redis://redis:6379/0"
  ensure_env_secret SECRET_KEY 48
  ensure_env_secret OTP_SECRET 48
  ensure_initial_admin_email
  ensure_env_admin_password
  ensure_env_secret ADMIN_RECOVERY_KEY 32

  ensure_env_value POSTGRES_PORT "25433"
  ensure_env_value REDIS_PORT "23639"
  ensure_env_value BACKEND_PORT "23800"
  ensure_env_value FRONTEND_PORT "23300"
  ensure_env_value FRONTEND_TLS_PORT "23443"
  ensure_env_value NEOSECRA_EDITION "security_health"
  ensure_env_value VITE_NEOSECRA_EDITION "security-health"
  ensure_env_value ENVIRONMENT "production"

  postgres_password="$(env_value POSTGRES_PASSWORD "")"
  ensure_env_value DATABASE_URL "postgresql+asyncpg://neosecra:${postgres_password}@postgres:5432/neosecra_assessment"
  frontend_port="$(env_value FRONTEND_PORT "23300")"
  frontend_tls_port="$(env_value FRONTEND_TLS_PORT "23443")"
  ensure_env_value BACKEND_CORS_ORIGINS "https://localhost:${frontend_tls_port},https://127.0.0.1:${frontend_tls_port},http://localhost:${frontend_port},http://127.0.0.1:${frontend_port}"

  ensure_env_value ALGORITHM "HS256"
  ensure_env_value ACCESS_TOKEN_EXPIRE_MINUTES "15"
  ensure_env_value REFRESH_TOKEN_EXPIRE_DAYS "7"
  ensure_env_value UPLOAD_DIR "/app/uploads"
  ensure_env_value REPORT_DIR "/app/reports"
  ensure_env_value DATA_RETENTION_ENABLED "true"
  ensure_env_value DATA_RETENTION_DAYS "365"
  ensure_env_value DATA_RETENTION_FAILED_DAYS "90"

  # Update channel (git'siz müşteri update akışı) — backend bunlar olmadan
  # fail-closed boş döner ("Sisteminiz Güncel" yanılsaması). Public key
  # minisign imza doğrulaması için kullanılır; CA bundle boş bırakılırsa
  # sistem trust store kullanılır (update.neosecra.com Cloudflare/Google CA).
  ensure_env_value UPGRADE_CHANNEL_URL "https://update.neosecra.com/channels/assessment-stable.json"
  ensure_env_value UPGRADE_CHANNEL_PUBLIC_KEY "/etc/neosecra/ca/update-neosecra-com.pub"

  ensure_env_value NOTIFICATION_ENABLED "false"
  ensure_env_value SMTP_PORT "587"
  ensure_env_value SMTP_USE_TLS "true"
  ensure_env_value SMTP_FROM_ADDRESS "noreply@neosecra.local"
  ensure_env_value SMTP_FROM_NAME "NeoSecra Security Platform"
  ensure_env_value PRODUCT_NAME "NeoSecra"
  ensure_env_value PRODUCT_FULL_NAME "NeoSecra Assessment"
  ensure_env_value DEEPSEEK_API_BASE_URL "https://api.deepseek.com/v1/chat/completions"
  ensure_env_value DEEPSEEK_MODEL "deepseek-chat"

  ensure_env_value OV_USER "admin"
  ensure_env_secret OV_PASSWORD 24
  ensure_env_value OPENVAS_SSH_PORT "23922"
  ensure_env_value OPENVAS_GSAD_PORT "23992"
  ensure_env_value OPENVAS_HOST "openvas"
  ensure_env_value OPENVAS_PORT "22"
  ensure_env_value OPENVAS_USER "gvm"
  ensure_env_secret OPENVAS_PASS 24
  ensure_env_value OPENVAS_GMP_USER "admin"
  ensure_env_secret OPENVAS_GMP_PASS 24
  ensure_env_value OPENVAS_CONFIG_ID "daba56c8-73ec-11df-a475-002264764cea"
  ensure_env_value OPENVAS_MOCK "false"
  ensure_env_value OPENVAS_KNOWN_HOSTS ""

  write_initial_admin_credentials
  ok ".env.v1 initialized"
}

write_initial_admin_credentials() {
  local credential_file="${CREDENTIAL_DIR}/initial-admin"
  mkdir -p "$CREDENTIAL_DIR"
  chmod 0700 "$CREDENTIAL_DIR"
  {
    printf 'FIRST_ADMIN_EMAIL=%s\n' "$(env_value FIRST_ADMIN_EMAIL "")"
    printf 'FIRST_ADMIN_PASSWORD=%s\n' "$(env_value FIRST_ADMIN_PASSWORD "")"
    printf 'ADMIN_RECOVERY_KEY=%s\n' "$(env_value ADMIN_RECOVERY_KEY "")"
  } > "$credential_file"
  chmod 0600 "$credential_file"
  ok "Initial admin credential file: ${credential_file}"
}

redact_sensitive_output() {
  sed -E \
    -e 's#(postgresql(\+asyncpg)?://[^:[:space:]]+:)[^@[:space:]]+@#\1<redacted>@#g' \
    -e 's#(Authorization:[[:space:]]*(Bearer|token)[[:space:]]+)[A-Za-z0-9._-]+#\1<redacted>#Ig' \
    -e 's#([A-Za-z0-9_]*(PASSWORD|SECRET|TOKEN|KEY|DATABASE_URL|REDIS_URL)[A-Za-z0-9_]*=)[^[:space:]]+#\1<redacted>#Ig'
}

print_service_diagnostics() {
  warn "Redacted service status:"
  run_compose ps --all 2>&1 | redact_sensitive_output >&2 || true
  warn "Redacted recent service logs:"
  run_compose logs --tail=160 "$@" 2>&1 | redact_sensitive_output >&2 || true
}

postgres_auth_succeeds() {
  local password="$1" pguser pgdb
  pguser="$(env_value POSTGRES_USER neosecra)"
  pgdb="$(env_value POSTGRES_DB neosecra_assessment)"
  [[ -n "$password" ]] || return 1

  printf '%s\n' "$password" | run_compose exec -T postgres sh -c \
    'IFS= read -r PGPASSWORD; export PGPASSWORD; psql -h 127.0.0.1 -U "$1" -d "$2" -tAc "select 1" >/dev/null' \
    sh "$pguser" "$pgdb" >/dev/null 2>&1
}

sync_database_url_password() {
  local password="$1" pguser pgdb
  pguser="$(env_value POSTGRES_USER neosecra)"
  pgdb="$(env_value POSTGRES_DB neosecra_assessment)"
  upsert_env_value DATABASE_URL "postgresql+asyncpg://${pguser}:${password}@postgres:5432/${pgdb}"
}

sql_literal_escape() {
  local value="$1"
  printf "%s" "${value//\'/\'\'}"
}

sql_identifier_escape() {
  local value="$1"
  printf "%s" "${value//\"/\"\"}"
}

reset_postgres_password_to_env() {
  local current pguser pgdb escaped_user escaped_password
  current="$(env_value POSTGRES_PASSWORD "")"
  pguser="$(env_value POSTGRES_USER neosecra)"
  pgdb="$(env_value POSTGRES_DB neosecra_assessment)"
  escaped_user="$(sql_identifier_escape "$pguser")"
  escaped_password="$(sql_literal_escape "$current")"

  [[ -n "$current" ]] || return 1
  printf 'ALTER USER "%s" WITH PASSWORD '\''%s'\'';\n' "$escaped_user" "$escaped_password" | \
    run_compose exec -T postgres psql -U "$pguser" -d "$pgdb" >/dev/null 2>&1
}

backend_database_url_succeeds() {
  run_compose run --rm --no-deps -T backend python -c '
import asyncio
import os
import sys

import asyncpg

url = os.environ.get("DATABASE_URL", "")
if not url:
    sys.exit(2)
if url.startswith("postgresql+asyncpg://"):
    url = "postgresql://" + url[len("postgresql+asyncpg://"):]

async def main():
    conn = await asyncpg.connect(url)
    try:
        await conn.fetchval("select 1")
    finally:
        await conn.close()

asyncio.run(main())
' >/dev/null 2>&1
}

ensure_assessment_schema_compatibility() {
  local pguser pgdb
  pguser="$(env_value POSTGRES_USER neosecra)"
  pgdb="$(env_value POSTGRES_DB neosecra_assessment)"

  if ! run_compose exec -T postgres psql -v ON_ERROR_STOP=1 -U "$pguser" -d "$pgdb" >/dev/null <<'SQL'
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY,
  user_id UUID NULL REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  resource_type VARCHAR(50),
  resource_id VARCHAR(255),
  ip_address VARCHAR(45),
  user_agent VARCHAR(500),
  details JSON,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS ix_audit_logs_created_at ON audit_logs(created_at);
SQL
  then
    return 1
  fi
  ok "Assessment schema compatibility verified"
}

sync_initial_admin_credentials() {
  log "Synchronizing initial admin credential with database..."
  if ! run_compose run --rm --no-deps -T backend python - <<'PY' >/dev/null
import asyncio
import sys
import uuid
from datetime import datetime, timezone

from sqlalchemy import select, update

from app.config import settings
from app.core.auth.jwt import hash_password, verify_password
from app.database import async_session_factory
from app.shared.models import AuditLog, User, UserSession


ADMIN_ROLES = {"admin", "super_admin", "mssp_admin"}


async def main() -> int:
    email = (settings.first_admin_email or "").strip().lower()
    password = settings.first_admin_password or ""
    if not email or not password:
        print("initial admin email/password is not configured", file=sys.stderr)
        return 2

    async with async_session_factory() as session:
        result = await session.execute(select(User).where(User.email == email))
        user = result.scalar_one_or_none()
        legacy_email_migrated = False
        if user is None and email == "admin@neosecra.io":
            legacy_result = await session.execute(select(User).where(User.email == "admin@neosecra.local"))
            user = legacy_result.scalar_one_or_none()
            if user is not None:
                user.email = email
                legacy_email_migrated = True
        created = False
        password_changed = False

        if user is None:
            user = User(
                id=uuid.uuid4(),
                email=email,
                hashed_password=hash_password(password),
                full_name="System Admin",
                role="admin",
                is_active=True,
                force_password_change=True,
            )
            session.add(user)
            await session.flush()
            created = True
            password_changed = True
        else:
            # Existing admin: NEVER overwrite the password, force_password_change,
            # or 2FA settings during sync/upgrade. The user-managed password and
            # second-factor config must persist across upgrades. Only apply a
            # minimal safety net so a disabled/locked admin can be recovered:
            # ensure the admin role and that the account is active.
            if user.role not in ADMIN_ROLES:
                user.role = "admin"
            if not user.is_active:
                user.is_active = True

        if password_changed:
            await session.execute(
                update(UserSession)
                .where(UserSession.user_id == user.id, UserSession.is_revoked == False)
                .values(
                    is_revoked=True,
                    revoked_at=datetime.now(timezone.utc),
                    revoke_reason="installer_initial_admin_sync",
                )
            )

        session.add(
            AuditLog(
                id=uuid.uuid4(),
                user_id=user.id,
                action="admin.initial_credential_sync",
                resource_type="user",
                resource_id=str(user.id),
                details={
                    "email": email,
                    "created": created,
                    "password_changed": password_changed,
                    "legacy_email_migrated": legacy_email_migrated,
                    "source": "installer",
                },
            )
        )
        await session.commit()
    return 0


raise SystemExit(asyncio.run(main()))
PY
  then
    return 1
  fi
  ok "Initial admin credential synchronized with database"
}

wait_frontend_http() {
  local timeout="${1:-120}" frontend_port tls_port code code_tls
  frontend_port="$(env_value FRONTEND_PORT 23300)"
  tls_port="$(env_value FRONTEND_TLS_PORT 23443)"
  log "Waiting for frontend HTTPS on 127.0.0.1:${tls_port} (timeout ${timeout}s)..."
  for _ in $(seq 1 "$timeout"); do
    code_tls="$(curl -sk --max-time 3 -o /dev/null -w '%{http_code}' "https://127.0.0.1:${tls_port}" 2>/dev/null || true)"
    if [[ "$code_tls" =~ ^(200|301|302|304)$ ]]; then
      # HTTP port must redirect to HTTPS (or at least answer /health)
      code="$(curl -s --max-time 3 -o /dev/null -w '%{http_code}' "http://127.0.0.1:${frontend_port}/health" 2>/dev/null || true)"
      ok "Frontend responds (HTTPS ${code_tls}, HTTP health ${code})"
      return 0
    fi
    sleep 1
  done
  return 1
}

wait_frontend_api_proxy() {
  local timeout="${1:-120}" tls_port code
  tls_port="$(env_value FRONTEND_TLS_PORT 23443)"
  log "Waiting for frontend API proxy on 127.0.0.1:${tls_port} (timeout ${timeout}s)..."
  for _ in $(seq 1 "$timeout"); do
    code="$(curl -sk --max-time 3 -o /dev/null -w '%{http_code}' "https://127.0.0.1:${tls_port}/api/v1/health" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then
      ok "Frontend API proxy responds (HTTPS 200)"
      return 0
    fi
    sleep 1
  done
  return 1
}

verify_initial_admin_login_via_frontend() {
  log "Verifying initial admin login through frontend API proxy..."
  run_compose run --rm --no-deps -T backend python - <<'PY' >/dev/null
import json
import ssl
import sys
import urllib.error
import urllib.request

from app.config import settings

payload = json.dumps({
    "email": settings.first_admin_email,
    "password": settings.first_admin_password,
}).encode()

# Frontend terminates TLS with a per-install self-signed cert — skip
# verification here (identity is not the point of this smoke check).
request = urllib.request.Request(
    "https://frontend/api/v1/auth/login",
    data=payload,
    headers={"Content-Type": "application/json"},
    method="POST",
)

try:
    ctx = ssl._create_unverified_context()
    with urllib.request.urlopen(request, timeout=10, context=ctx) as response:
        status = response.getcode()
        body = response.read(8192)
except urllib.error.HTTPError as exc:
    print(f"initial admin login returned HTTP {exc.code}", file=sys.stderr)
    sys.exit(1)
except Exception as exc:
    print(f"initial admin login request failed: {type(exc).__name__}", file=sys.stderr)
    sys.exit(1)

if status != 200:
    print(f"initial admin login returned HTTP {status}", file=sys.stderr)
    sys.exit(1)

try:
    data = json.loads(body.decode())
except Exception:
    print("initial admin login returned invalid JSON", file=sys.stderr)
    sys.exit(1)

if not data.get("access_token"):
    print("initial admin login did not return an access token", file=sys.stderr)
    sys.exit(1)
PY
  ok "Initial admin login verified through frontend API proxy"
}

reconcile_postgres_password() {
  local current
  current="$(env_value POSTGRES_PASSWORD "")"
  [[ -n "$current" ]] || die "POSTGRES_PASSWORD is empty; cannot verify database authentication" 12

  warn "Synchronizing PostgreSQL user password with .env.v1 without resetting persistent data"
  reset_postgres_password_to_env || die "PostgreSQL password mismatch; failed to update existing database user password. Persistent data was not reset." 12
  postgres_auth_succeeds "$current" || die "PostgreSQL password update did not pass TCP authentication. Persistent data was not reset." 12
  sync_database_url_password "$current"
  backend_database_url_succeeds || die "Backend DATABASE_URL authentication failed after PostgreSQL password synchronization. Persistent data was not reset." 12
  ok "PostgreSQL and backend DATABASE_URL authentication verified"
}

warn_if_placeholders() {
  [[ -f "$ENV_FILE" ]] || return 0
  local key value failed=0
  while IFS='=' read -r key value; do
    [[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue
    if is_placeholder_value "$value"; then
      warn "${key} contains a placeholder value"
      failed=1
    fi
  done < "$ENV_FILE"
  return "$failed"
}

is_placeholder_value() {
  local value="${1:-}" lower
  lower="${value,,}"
  [[ -z "$value" ]] && return 1
  [[ "$lower" == *change_me* ]] && return 0
  [[ "$lower" == *replace_me* ]] && return 0
  [[ "$lower" == "password" ]] && return 0
  [[ "$lower" == "secret" ]] && return 0
  [[ "$lower" == "example" ]] && return 0
  [[ "$value" == \<*\> ]] && return 0
  return 1
}

require_env_value() {
  local key="$1" value
  value="$(env_value "$key" "")"
  [[ -n "$value" ]] || { err "${key} is EMPTY"; return 1; }
  if is_placeholder_value "$value"; then
    err "${key} is PLACEHOLDER"
    return 1
  fi
  return 0
}

validate_image_ref() {
  local key="$1" ref
  ref="$(env_value "$key" "")"
  [[ -n "$ref" ]] || { err "${key} is EMPTY"; return 1; }
  [[ "$ref" != *latest* ]] || { err "${key} must not use latest"; return 1; }
  [[ "$ref" != *'<<'* && "$ref" != *'>>'* ]] || { err "${key} contains an unstamped placeholder"; return 1; }
  if [[ "$ref" != *@sha256:* && "$ref" != *:* ]]; then
    err "${key} must include an exact tag or digest"
    return 1
  fi
  if [[ "$ref" =~ [A-Z] ]]; then
    err "${key} contains uppercase characters in an image reference"
    return 1
  fi
  return 0
}

validate_env_file() {
  [[ -f "$ENV_FILE" ]] || { err ".env.v1 missing: ${ENV_FILE}"; return 1; }

  local failed=0
  for key in \
    POSTGRES_USER POSTGRES_PASSWORD POSTGRES_DB DATABASE_URL REDIS_URL \
    SECRET_KEY OTP_SECRET FIRST_ADMIN_EMAIL FIRST_ADMIN_PASSWORD ADMIN_RECOVERY_KEY \
    BACKEND_CORS_ORIGINS POSTGRES_PORT REDIS_PORT BACKEND_PORT FRONTEND_PORT \
    NEOSECRA_EDITION VITE_NEOSECRA_EDITION \
    POSTGRES_IMAGE REDIS_IMAGE BACKEND_IMAGE WORKER_IMAGE FRONTEND_IMAGE OPENVAS_IMAGE
  do
    require_env_value "$key" || failed=1
  done

  for key in POSTGRES_IMAGE REDIS_IMAGE BACKEND_IMAGE WORKER_IMAGE FRONTEND_IMAGE OPENVAS_IMAGE; do
    validate_image_ref "$key" || failed=1
  done

  [[ "$(env_value NEOSECRA_EDITION "")" == "security_health" ]] || { err "NEOSECRA_EDITION must be security_health"; failed=1; }
  [[ "$(env_value VITE_NEOSECRA_EDITION "")" == "security-health" ]] || { err "VITE_NEOSECRA_EDITION must be security-health"; failed=1; }
  if ! admin_password_is_valid "$(env_value FIRST_ADMIN_PASSWORD "")"; then
    if [[ "${NEOSECRA_ROTATE_INITIAL_ADMIN:-0}" == "1" ]]; then
      err "FIRST_ADMIN_PASSWORD does not satisfy production complexity; set NEOSECRA_ROTATE_INITIAL_ADMIN=0 or fix the password"
      failed=1
    elif [[ -n "$(env_value FIRST_ADMIN_PASSWORD "")" ]]; then
      warn "FIRST_ADMIN_PASSWORD does not satisfy production complexity; preserving existing credential"
    else
      err "FIRST_ADMIN_PASSWORD does not satisfy production complexity"
      failed=1
    fi
  fi

  return "$failed"
}

# --- Lock ---
LOCK_FILE="${STATE_DIR}/.install.lock"
acquire_lock() {
  mkdir -p "$STATE_DIR"
  if ! mkdir "$LOCK_FILE" 2>/dev/null; then
    die "Another install/upgrade is in progress (lock: ${LOCK_FILE})" 5
  fi
}
release_lock() { rmdir "$LOCK_FILE" 2>/dev/null || true; }

# --- Upgrade failure recovery ---
# Start previous release's compose when upgrade fails mid-flight.
# Reads previous version from journal or state, then starts compose
# from that release's deployment directory.
recover_previous_release() {
  local prev_ver prev_dir
  prev_ver="$(read_installed_version 2>/dev/null || true)"
  [[ -n "$prev_ver" && "$prev_ver" != "none" ]] || prev_ver="$(journal_previous_version 2>/dev/null || true)"
  [[ -n "$prev_ver" && "$prev_ver" != "none" ]] || { warn "Cannot determine previous version for recovery — services may be down."; return 1; }

  prev_dir="$(release_dir "$prev_ver")"
  if [[ ! -d "$prev_dir" ]]; then
    warn "Previous release directory missing: ${prev_dir}"
    return 1
  fi

  log "Recovering: starting compose from ${prev_ver} (${prev_dir})..."
  if [[ -f "${prev_dir}/.env.v1" && -f "${prev_dir}/docker-compose.v1.yml" ]]; then
    (
      export V1_ROOT="${prev_dir}"
      export COMPOSE_FILE="${prev_dir}/docker-compose.v1.yml"
      export ENV_FILE="${prev_dir}/.env.v1"
      cd "$prev_dir"
      docker compose \
        --project-name "$COMPOSE_PROJECT" \
        --project-directory "$prev_dir" \
        --env-file "${prev_dir}/.env.v1" \
        -f "${prev_dir}/docker-compose.v1.yml" \
        up -d 2>/dev/null || warn "Recovery compose up failed — manual intervention may be needed"
    )
    ok "Recovery: previous release compose started (${prev_ver})"
  else
    warn "Previous release missing .env.v1 or docker-compose.v1.yml — cannot recover compose"
    return 1
  fi
}

# --- Path helpers ---
release_dir() { echo "${RELEASES_DIR}/${1}"; }
current_symlink() { echo "${INSTALL_ROOT}/current"; }
previous_symlink() { echo "${INSTALL_ROOT}/previous"; }
