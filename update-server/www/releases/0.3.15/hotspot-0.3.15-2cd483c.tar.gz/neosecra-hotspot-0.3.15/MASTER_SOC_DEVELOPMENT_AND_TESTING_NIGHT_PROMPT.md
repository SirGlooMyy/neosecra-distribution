# NEOSECRA SOC — MASTER GELİŞTİRME & DERİN TEST GECE ÇALIŞMA MOTORU (UNIFIED ROADMAP)

> **Kullanım Amacı:** Bu prompt, NeoSecra SOC'u piyasadaki devlerle (Microsoft Sentinel, Cortex XSOAR, SOCFortress) yarışabilecek **"Assessment + SOC XDR Füzyonuna"** ulaştırmak için hem **6 Stratejik Yeni Özelliğin Geliştirilmesini (Kodlanmasını)** hem de **6 Derin Test/Sertleştirme Fazını** içeren otonom gece çalışma yönergesidir.

---

```markdown
# GÖREV: NeoSecra SOC — Next-Gen XDR/MDR Vizyonu: 6 Stratejik Modülün Kodlanması, 8 Katmanlı Derin Test ve Release Mühendisliği (/goal)

Sen NeoSecra SOC projesinde görevli Baş Kıdemli Güvenlik Mimarı ve Sistem Mühendisisin.
Bu geceki hedefin; projenin 8 katmanlı SOC hedefini (`soc.jfif` ve `SOC-MASTER-CONTEXT-2026-08-23.md`) temel alarak, platformu piyasadaki en gelişmiş hibrit XDR/MDR gücüne ulaştıracak **6 Stratejik Geliştirme Paketini kodlamak** ve ardından **6 Derin Test Fazı** ile platformu sabaha kadar eksiksiz bir Release Candidate haline getirmektir.

---

## ⛔ DEĞİŞTİRİLEMEZ GÜVENLİK VE MİMARİ KURALLAR
1. `AGENTS.md` ve `.ai-ops/project-memory/SOC-MASTER-CONTEXT-2026-08-23.md` dosyalarındaki kurallar mutlaktır.
2. Canlı `10.34.99.11` sunucusuna kesinlikle yetkisiz SSH/deploy/restart YAPMA. Tüm geliştirmeleri, testleri ve paketlemeleri yerel depoda (`/home/sirgloomy/projects/neosecra-soc`) gerçekleştir.
3. CoPilot / OSSIEM yalnızca karşılaştırma referansıdır; runtime bağımlılığı yapma.
4. Sahte (mock-only) başarı raporlama; her faz için gerçek kodlama, pytest/frontend test çıktıları ve dosya bazlı kanıtlar üret.
5. Dirty worktree'yi koru, `git reset --hard` veya `git clean` kullanma.

---

# 🚀 BÖLÜM 1: GELİŞTİRİLECEK (KODLANACAK) 6 STRATEJİK XDR MODÜLÜ

### 1. MODÜL: ASSESSMENT ↔ SOC "XDR FÜZYONU" (EXPOSURE-AWARE ALERTING)
- **Problem:** SIEM/SOC (Wazuh/Graylog) alarm aldığında varlığın zafiyetini bilmez; Zafiyet tarayıcısı ise canlı saldırıyı bilmez.
- **Kodlanacak Mimari:**
  - `backend/app/modules/soc/exposure_service.py` servisini yaz/tamamla: Bir varlık (host/IP) için alarm geldiğinde Assessment DB'sinden (OpenVAS/CVE zafiyet tarama sonuçları ve açık portlar) varlığın risk profilini çek.
  - Eğer varlık üzerinde kritik CVE veya açık port varsa, alarmın önem derecesini otomatik `P1-Critical` seviyesine yükselt ve metadata'ya `exposure_context` ekle.
  - Frontend `SOCExposureCard.tsx` bileşenini `SOCAlertDetail.tsx` ve `SOCIncidentDetail.tsx` sayfalarına bağla: Analiste *"🔥 KRİTİK MARUZİYET: Bu varlık üzerinde taranmış CVE-2024-XXXX ve açık SSL-VPN portu mevcut!"* rozetini göster.

### 2. MODÜL: TEK TIKLA AKTİF MÜDAHALE (1-CLICK ACTIVE RESPONSE CATALOG)
- **Kodlanacak Mimari:**
  - `backend/app/modules/soc/response_actions/` motorunu ve API'lerini tamamla (`POST /api/v1/soc/actions/execute`):
    1. **FortiGate'te Engelle (IP Block):** FortiGate REST API'sine bağlanıp saldırgan IP'yi `SOC-Block-List` adres grubuna ekleyen idempotent servis.
    2. **Kullanıcıyı Kilitle (AD/M365 Account Freeze):** Şüpheli kullanıcının oturumlarını sonlandıran ve hesabı donduran aksiyon.
    3. **Endpoint İzolasyonu (Velociraptor/Wazuh):** Hedef makinenin ağ bağlantısını tek tıkla kesen VQL/API tetikleyicisi.
  - Frontend `SOCResponseActions.tsx` bileşenini aktif onay modalları (`Confirm Modal`) ve tek tıkla Geri Alma (`Rollback / Unblock`) desteğiyle olay ekranlarına bağla.

### 3. MODÜL: OTONOM L1 ANALİST (NEOSECRA AI CO-PILOT & AUTO-TRIAGE)
- **Kodlanacak Mimari:**
  - Olay (Incident) açıldığı anda arka planda tetiklenen otonom triyaj ajanı (`backend/app/modules/ai/triage_engine.py`):
    1. İlgili alarmların ham loglarını toplar.
    2. OpenCTI/MISP'ten IP/Domain/Hash tehdit istihbaratını sorgular.
    3. Velociraptor'dan ilgili makinenin son çalışan process ve ağ bağlantılarını çeker.
  - Vaka detayına otomatik Markdown formatında *"L1 Triyaj & Kök Neden Analiz Raporu (RCA)"* ekleyen servisi bağla. Frontend `SOCAITriagePanel.tsx` ile analiste tek tıkla aksiyon önerileri sun.

### 4. MODÜL: PROAKTİF TEHDİT AVCILIĞI (RETROACTIVE THREAT HUNTING)
- **Kodlanacak Mimari:**
  - OpenCTI veya MISP'e yeni bir kritik IOC (Hash/IP/Domain) eklendiğinde arka planda çalışan avcılık motoru (`backend/app/modules/soc/threat_hunting.py`):
    1. **Velociraptor VQL Hunt:** Tüm uç noktalarda hash/dosya taraması başlatır.
    2. **Graylog Geriye Dönük Arama:** Son 30 günlük loglarda bu IOC'yi arar.
    3. Eşleşme bulunursa otomatik *"Geriye Dönük Tehdit Tespiti (Retroactive Incident)"* vakası açar.

### 5. MODÜL: C-LEVEL BİRLEŞİK YÖNETİCİ GÜVENLİK RAPORU (EXECUTIVE PDF REPORT)
- **Kodlanacak Mimari:**
  - `backend/app/modules/soc/reports/executive_report.py` servisini yaz:
    - **Risk & Postür (Assessment):** Ay boyunca kapatılan zafiyetler ve postür skoru değişimi.
    - **Tehdit & Olay (SOC):** Engellenen saldırı sayısı, açılan vakalar, ortalama müdahale süresi (MTTA/MTTR).
    - **Mevzuat Uyumluluğu:** ISO 27001, KVKK, NIST kontrolleri kapsama yüzdesi.
  - PDF ve Markdown export endpoint'lerini (`GET /api/v1/soc/reports/executive/export`) oluştur.

### 6. MODÜL: SALDIRI YOLU ANALİZİ (ATTACK PATH VISUALIZER)
- **Kodlanacak Mimari:**
  - Frontend `@xyflow/react` tabanlı grafiği genişlet: Active Directory Tier-0 yetki atlamalarını ve ağ segmentasyonunu grafiğe giydir.
  - Saldırganın ele geçirdiği normal kullanıcıdan Domain Admin veya kritik veritabanına giden en kısa saldırı yolunu grafikte kırmızı uyarı oklarıyla vurgula.

---

# 🧪 BÖLÜM 2: 6 DERİN TEST, STRES VE SERTLEŞTİRME FAZI

### 🔄 FAZ 1: REALTIME SSE & ALARM AKIŞI STRES TESTİ
- `backend/app/modules/soc/realtime.py` Redis Streams mekanizmasını 1.000+ anlık alarm ile test et. Bağlantı kopması ve heartbeat stabilitesini doğrula.
- `/api/v1/soc/alerts/stream` statik rotasının çakışmasız çalıştığını kanıtla.

### 🔄 FAZ 2: KONEKTÖRLER, FAIL-CLOSED & DEAD-LETTER QUEUE
- Graylog, Wazuh, TheHive, MISP kapalıyken sistemin 500 hatası vermediğini, istekleri `SOCDeadLetters` tablosuna güvenle attığını test et.
- 20 farklı Sigma kuralının derleyici (`adapters.py` / `factory.py`) testlerini tamamla.

### 🔄 FAZ 3: WORKER IDEMPOTENCY & CRASH RECOVERY
- 50 yinelenen alarm geldiğinde mükerrer incident/log açılmadığını (`idempotent processing`) doğrula.
- Worker çökmesi durumunda Redis cursor üzerinden veri kaybı olmadan devam edildiğini test et.

### 🔄 FAZ 4: OWASP API GÜVENLİĞİ & 5-ROL RBAC/IDOR FUZZING
- 5 rolün (`super_admin` .. `customer_viewer`), 80+ API endpoint'i üzerindeki izinlerini test et.
- Müşterilerin iç TheHive/Graylog URL'lerini göremeyeceğini (`customer_safe` redaction) ve A müşterisinin B müşterisi verisine erişemeyeceğini (IDOR 403/404) doğrula.

### 🔄 FAZ 5: FRONTEND E2E PLAYWRIGHT TESTLERİ (300+ TEST)
- Tüm sayfalarda (`Dashboard`, `Alerts`, `Incidents`, `Telemetry`, `Asset Inventory`, `Settings`) 0 konsol hatası olduğunu doğrula. Test sayısını 300+ üzerine çıkar.

### 🔄 FAZ 6: RELEASE CANDIDATE & SABAH DEPLOY BETİĞİ
- `release/build-release.sh` paketlemesini ve `images.lock` hash doğrulamasını tamamla.
- Sabah SSH açıldığında tek tıkla çalışacak, canlıdaki eski backend imajını güncelleyecek ve otomatik rollback korumalı `release/deploy-pilot.sh` betiğini hazırla.

---

## 📊 SABAH ÇIKIŞ RAPORU (FINISH REPORT)
Görevi tamamladığında şu başlıkları içeren detaylı bir rapor sun:
1. Geliştirilen 6 yeni modülün kodları ve API sözleşmeleri.
2. Pytest ve Frontend testlerinin tam sayıları (Pass / Fail / Skip).
3. OWASP/IDOR ve Fuzzing test sonuçları.
4. Sabah canlıya tek komutla geçiş için hazır olan deploy komutu.

<!-- GOAL_COMPLETE -->
```
