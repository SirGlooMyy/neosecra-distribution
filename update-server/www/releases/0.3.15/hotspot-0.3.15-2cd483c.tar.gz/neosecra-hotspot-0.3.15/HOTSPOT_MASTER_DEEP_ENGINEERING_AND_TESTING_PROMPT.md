# NEOSECRA HOTSPOT — 10 SAATLİK DERİN MÜHENDİSLİK, MANTIK DENETİMİ VE FIREWALL ANALYZER MASTER PROMPT

> **Kullanım Amacı:** Bu yönerge, NeoSecra Hotspot platformundaki 23+ Web Admin sayfasını, 10 farklı Captive Portal kimlik doğrulama akışını, canlı FortiGate güvenlik duvarı etkileşimlerini ve zayıf kalan **Firewall Syslog / UTM / Trafik Analyzer ve 5651 Korelasyon Motorunu** sıfırdan zirveye taşımak üzere hazırlanmış en üst seviye otonom gece mühendislik promptudur.

---

```markdown
# GÖREV: NeoSecra Hotspot — Tüm Sayfaların Fonksiyonel Denetimi, 10 Giriş Yönteminin Mantık Mimarisi, Firewall Analyzer Geliştirmesi ve 5651 Yasal Entegrasyon (/goal)

Sen NeoSecra Hotspot, Captive Portal ve Ağ Güvenliği Mimarisinden sorumlu Baş Sistem ve Güvenlik Mühendisisin.
Bu geceki görevin; birim testleri koşturup geçmek değil, sistemin **tüm sayfalarını, kullanıcı arayüzü reaktif durumlarını, portal form akışlarını, canlı FortiGate (192.168.2.1) CMDB yönetimini ve Firewall Log Analyzer motorunu** satır satır incelemek, eksik veya hatalı iş mantıklarını düzeltmek ve sistemi yarın sabahki canlı kabul testlerine %100 kusursuz hazırlamaktır.

---

## ⛔ DEĞİŞTİRİLEMEZ İLKELER VE CANLI ÇEVRE BİLGİLERİ
1. **Canlı Cihazlar:**
   - **Hedef Sunucu:** `192.168.2.126` (Docker konteynerleri: `neosecra-hotspot-api-1`, `neosecra-hotspot-portal-1`, `neosecra-hotspot-admin-1`, `neosecra-hotspot-postgres-1`)
   - **Canlı Gateway:** `192.168.2.1:4443` (Fortinet FortiGate 60F v7.4.9)
   - **Cihaz UUID:** `d5020e73-ed2f-46c6-a1ea-20210d3acb92`
   - **Docker Ağı:** `172.18.0.0/16` (FreeRADIUS iç test istemcisi)
2. **Sıfır Sahte (Mock) Başarı:** Hiçbir fonksiyonel test "mock" ile geçiştirilemez. Gerçek API çağrıları, gerçek veritabanı durumları ve gerçek FortiGate grup üyelikleri doğrulanacaktır.
3. **Dirty Worktree Korunumu:** `git reset --hard` veya `git clean` kesinlikle kullanılmayacaktır.

---

# 📱 FAZ 1: CAPTIVE PORTAL 10 KİMLİK DOĞRULAMA YÖNTEMİNİN DERİN MANTIK DENETİMİ

Captive portal (`frontend/portal/src/` ve `backend/app/modules/portal/flow.py`) üzerindeki her bir kimlik doğrulama yöntemini aşağıdaki sınır durumlarına (edge-cases) göre incele ve düzelt:

### 1.1. Toplantı Kodu ile Giriş (`MeetingLoginForm.tsx`)
- **Özel Kod Korunumu:** Yönetim panelinde girilen kod (örn. `VDATA2026`) hiçbir zaman rastgele harf dizisine dönüştürülmemelidir.
- **Harf Duyarsızlığı:** İstemci `vdata2026` veya `VDATA2026` girdiğinde birebir eşleşmelidir.
- **Yönetici Onayı Muafiyeti:** Şablonda "Yönetici Onayı Zorunlu" seçili olsa bile, önceden tanımlanmış toplantı kodu yönetici e-posta onayına TAKILMADAN doğrudan `status: active` ve `authorize_ok: true` almalıdır.
- **Form Alanı Hatası Önleme:** Şablonda Ad Soyad zorunlu olsa bile toplantı formu bu alanları istemediğinden backend doğrulamasında `400 Bad Request` alması engellenmelidir.

### 1.2. Serbest (Free) Giriş & Dinamik Form Alanları (`DynamicPortalForm.tsx`)
- **Dinamik Alan Toplama:** Şablona eklenen özel alanlar (örn. "Geldiginiz Birim", "Ziyaret Edilen Kişi", "Plaka No") portalda eksiksiz render edilmeli, zorunluluk kontrolleri çalışmalı ve `guest_sessions` tablosunun `form_data` JSON kolonuna eksiksiz yazılmalıdır.
- **Yönetici Onay Akışı:** Yönetici onayı aktifse oturum `pending` kalmalı, yöneticiye giden e-posta veya `/portal/public/approval/{id}` linkinden onay verildiğinde FortiGate'te internet anında açılmalıdır.

### 1.3. Cihazı Hatırla / MAC Auth Bypass (Auto Welcome-Back)
- **Mekanizma:** Kullanıcıya gruptan 3 gün izin verilmişse, bu süre içinde portal URL'sini tekrar açtığında (`?client_mac=3E:BD:...`), `/portal/public/context` endpoint'i `auto_authorized: true` dönmelidir.
- **Portal Davranışı:** Portal form sormamalı; *"Hoş Geldiniz Hasan Bey, internet erişiminiz aktif (Kalan süre: 2 gün)"* kartı ve tek tıkla *"İnternete Devam Et"* butonu göstermelidir.

### 1.4. SMS / OTP ve T.C. Kimlik Doğrulama (`TcSmsLoginForm.tsx`, `PhoneLoginForm.tsx`)
- **SMS OTP:** 60 saniyelik geri sayım sayacı, SMS servis sağlayıcı (Netgsm, Mutlucell, İletiMerkezi, Twilio) hata verdiğinde kullanıcıya anlamlı hata mesajı gösterimi.
- **T.C. Kimlik Algoritması:** NVI modülü aktifse 11 haneli T.C. algoritma doğrulaması ve NVI SOAP servisi üzerinden Ad-Soyad-Doğum Yılı teyidi.

### 1.5. Bilet / Voucher ile Giriş (`VoucherLoginForm.tsx`)
- **Bilet Yönetimi:** Toplu üretilen biletlerin kota kontrolü (örn. 500 MB veya 8 saat), tek kullanımlık biletlerin ikinci kez kullanımının engellenmesi, süresi biten biletin otomatik sonlandırılması.

### 1.6. Yerel Kullanıcılar & Dahili RADIUS (`LocalLoginForm.tsx`, `RadiusLoginForm.tsx`)
- **Yerel Kullanıcı Girişi:** Panelde tanımlanan kullanıcı adı/şifre ile anında oturum açma.
- **Dahili FreeRADIUS:** Captive portal üzerinden girilen kullanıcı adı/şifrenin Docker içi FreeRADIUS servisi üzerinden `Access-Accept` alarak yetkilendirilmesi.

### 1.7. Başarılı Giriş Sonrası Web Sitesine Yönlendirme (Redirect URL)
- Giriş tamamlandıktan sonra şablonda tanımlı olan web sitesine (örn. `https://www.vdata.com.tr`) veya kullanıcının gitmek istediği orijinal URL'ye (`target_url`) 3 saniye içinde otomatik yönlendirme yapılması.

---

# 🛡️ FAZ 2: CANLI FORTIGATE ENTEGRASYONU VE OTURUM YÖNETİMİ SERTLEŞTİRMESİ

`backend/app/modules/firewall_adapters/fortigate.py` ve `backend/app/modules/sessions/` modüllerini incele:

### 2.1. Kusursuz Oturum İptali (Full IP Sweep Cleanup)
- **Sorun:** Daha önce sadece tek bir nesne adı silindiği için eski oturumların adres nesneleri FortiGate `Guest` grubunda kalıyor ve cihazın interneti kesilmiyordu.
- **Kesin Mantık:** `revoke_guest` fonksiyonu çağrıldığında:
  1. FortiGate CMDB `firewall/address` taranacak,
  2. İstemci IP'sine (`10.34.98.x`) ait olan `hsess-*` ve statik TÜM adres nesneleri bulunacak,
  3. `Guest` ve `hotspot-allowed` adres gruplarından çıkarılacak,
  4. Tüm bu adres nesneleri CMDB'den silinecektir (`Guest []`, `hotspot-allowed []` garantisi).

### 2.2. Dinamik Grup Süreleri ve Bant Genişliği Limitleri
- **Kullanıcı Grubu Entegrasyonu:** Kullanıcı hangi gruba dahilse (örn. "Misafir 3 Günlük", "VIP 10 Mbps"), `expires_at` süresi dinamik hesaplanmalı (`şimdi + grup_gün_sayısı`).
- **Trafik Şekillendirme (Traffic Shaper):** FortiGate üzerinde kullanıcı bazlı veya grup bazlı bant genişliği (Down/Up) kuralı eşleştirmesi doğrulanmalıdır.

### 2.3. Periyodik Oturum Süre Kontrolcüsü (Session Expiry Worker)
- `backend/app/modules/sessions/tasks.py` içindeki periyodik worker'ın süresi dolan oturumları tespit edip FortiGate'ten otomatik düşürdüğünü (auto-revoke) test et.

---

# 📊 FAZ 3: FIREWALL ANALYZER, SYSLOG VE LOG ARAMA MOTORUNU GÜÇLENDİRME (KRİTİK)

Şu an zayıf kalan **Firewall Analyzer** modülünü tam teşekküllü bir SIEM/Analyzer seviyesine çıkar:

### 3.1. FortiGate Canlı Syslog Ayrıştırıcısı (`backend/app/modules/syslog/parsers.py`)
FortiGate'ten gelen raw log dizilerini eksiksiz parse eden parser'ı güçlendir:
- **Trafik Logları (`type=traffic`):** `srcip`, `dstip`, `srcport`, `dstport`, `proto`, `action` (`allow`, `deny`, `close`, `timeout`), `sentbyte`, `rcvdbyte`, `duration`, `service`, `app`, `policyid`.
- **UTM / Güvenlik Logları (`type=utm`):**
  - **Web Filter (`subtype=webfilter`):** `url`, `hostname`, `catdesc` (Kategori), `action` (`passthrough`, `block`).
  - **Antivirus & IPS (`subtype=virus`, `subtype=ips`):** `virus`, `attack`, `severity`, `action` (`blocked`, `monitored`).
- **VPN Logları (`type=event`, `subtype=vpn`):** `user`, `remip`, `tunneltype`, `action` (`tunnel-up`, `tunnel-down`, `ssl-login-fail`).

### 3.2. Yüksek Performanslı Log Arama Motoru (`FirewallLogsPage.tsx`, `LogsSearch.tsx`)
- **Arama Yetenekleri:**
  - **IP & Port Arama:** Kaynak IP (`10.34.98.100`), Hedef IP (`8.8.8.8`), Port (`443`) veya CIDR aralığı (`10.34.98.0/24`).
  - **Zaman Aralığı:** "Son 15 Dakika", "Son 1 Saat", "Son 24 Saat", "Bugün", "Özel Tarih Seçici".
  - **Filtre Kombinasyonları:** `Vendor=Fortinet` + `Severity=Warning/Error` + `Action=Deny`.
- **Log Detay Çekmecesi (Drawer):** Tıklanan logun tüm key-value çiftlerini, raw metnini ve ilişkili 5651 kullanıcı bilgisini gösteren yan çekmece.
- **Dışa Aktarma (Export):** Filtrelenen logları CSV ve JSON formatında dışa aktarma (`Download` butonu).

### 3.3. Trafik Analitiği ve Dashboard Görselleştirme (`TrafficAnalysisPage.tsx`)
Syslog ve oturum verilerini işleyen dinamik analitik grafikleri tamamla:
1. **Top 10 Bant Genişliği Tüketen Kullanıcı/Cihaz** (İsim, MAC, IP, Toplam GB, İndirme/Yükleme oranı).
2. **Top 10 Ziyaret Edilen Domain ve Web Kategorileri** (Örn. Sosyal Medya, Haberler, Video/Yayın, Tehdit/Kumar).
3. **Protokol ve Port Dağılımı Grafiği** (HTTPS %70, DNS %10, QUIC %10, Diğer %10).
4. **Saatlik Trafik Yoğunluğu (Traffic Heatmap)**: Günün hangi saatlerinde hattın doygunluğa ulaştığını gösteren trend grafiği.
5. **Engellenen Tehditler Özeti**: FortiGate tarafından engellenen zararlı bağlantı ve saldırı girişimleri paneli.

---

# ⚖️ FAZ 4: 5651 YASAL LOG ZİNCİRİ, NAT EŞLEŞTİRME VE ZAMAN DAMGASI

`backend/app/modules/logs_5651/` modülünü yasal mevzuat standartlarına göre denetle:

1. **NAT + Kimlik Korelasyonu (DHCP & Auth Binding):**
   - Misafirin kimlik bilgisi (Ad Soyad, T.C., MAC, Telefon, Giriş Yöntemi) ile FortiGate'ten akan NAT oturum loglarının (`srcip` + `srcport` + `dstip` + `dstport` + `timestamp`) `correlation_id` üzerinden tam eşleştiğini doğrula.
2. **SHA-256 Hash Zinciri ve WORM Arşiv:**
   - Günlük oluşturulan 5651 log dosyalarının SHA-256 özetlerinin zincirleme (`hash_chain`) bağlandığını, değiştirilemez (WORM) MinIO veya yerel depoya arşivlendiğini test et.
3. **Zaman Damgası (TÜBİTAK / KamuSM / OpenSSL RFC 3161):**
   - İmzalanan log dosyalarının `.ts` zaman damgası doğrulama servisini (`verify_service.py`) test et.

---

# 🖥️ FAZ 5: WEB YÖNETİM PANELİ 23+ SAYFANIN TEK TEK İŞLEV DENETİMİ

`frontend/admin/src/pages/` altındaki tüm sayfaları tek tek aç, backend API'leri ile reaktif durumlarını doğrula:

1. `SessionsPage.tsx`: Oturum tablosu, filtreler, manuel oturum açma, canlı oturum iptali, FortiGate durumu.
2. `UsersPage.tsx`: Yerel kullanıcı listesi, ekleme modalı, düzenleme, silme ve duplicate reaktivasyon.
3. `UserGroupsPage.tsx`: Grup oluşturma, dinamik süre atama (gün/ay), hız limiti tanımları.
4. `AuthMethodsPage.tsx`: 10 yöntemin açma/kapama anahtarları, Toplantı kodları yönetimi, Dahili RADIUS test butonu.
5. `TemplateEditorPage.tsx`: Renk paleti, logo yükleme, form alanı ekleme, dinamik iframe önizleme, yönlendirme linki.
6. `DevicesPage.tsx`: Ağ geçitleri, FortiGate API bağlantı testi, arayüz ve IP havuz ayarları.
7. `ApprovalRequestsPage.tsx`: Bekleyen misafir onay talepleri, SMS/E-posta ile onay verme simülasyonu.
8. `FirewallLogsPage.tsx` & `LogsSearch.tsx`: Syslog arama, filtreleme, otomatik yenileme (Live stream), CSV export.
9. `TrafficAnalysisPage.tsx`: Top kullanıcılar, protokol pasta grafikleri, bant genişliği kullanım trendleri.
10. `SigningConfigPage.tsx`: 5651 imzalama anahtarları, sertifika yükleme, günlük arşiv listesi.
11. `SyslogTriggersPage.tsx`: Belirli bir IP engellendiğinde veya saldırı logu geldiğinde alarm üretme tetikleyicileri.
12. `SyslogPage.tsx`: UDP 514 listener durumu, anlık gelen paket sayısı ve throughput göstergesi.
13. `PlatformLicensePage.tsx`: Ed25519 lisans geçerliliği, cihaz ve kullanıcı kotalarının kontrolü.
14. `ReportSchedulerPage.tsx` & `ReportsPage.tsx`: Otomatik PDF/Excel rapor planlayıcı ve geçmiş rapor indirme.
15. `LocationsPage.tsx`, `PmsConfigPage.tsx`, `AlarmDashboardPage.tsx`, `SettingsPage.tsx`, `DashboardPage.tsx`.

---

# 🧪 FAZ 6: GERÇEK CANLI KABUL TESTİ (E2E SUITE ÇALIŞTIRMA)

1. Tüm düzeltmeleri backend ve frontend konteynerlerine derle ve canlıya aktar:
   ```bash
   npm --prefix frontend/portal run build
   npm --prefix frontend/admin run build
   # Canlı container'ları güncelle ve yeniden başlat
   ```
2. Python ve HTTP tabanlı master test betiği ile tüm senaryoları canlı test cihazı (`10.34.98.100` / `3E:BD:48:91:54:27`) üzerinden koştur:
   - Toplantı Kodu ile Giriş -> FortiGate `Guest` grubuna eklendi mi? (Evet)
   - Panelden Oturum İptali -> FortiGate'ten IP silindi mi? (Evet, `Guest []`)
   - Cihazı Hatırla -> Portal tekrar açıldığında tek tıkla devam ediyor mu? (Evet)
   - Dahili FreeRADIUS -> Test butonu yeşil mi? (Evet)
   - Syslog Parser -> FortiGate UTM/Trafik logları doğru kolonlara ayrıştı mı? (Evet)

---

## 📊 SABAH ÇIKIŞ RAPORU (FINISH REPORT)
Görevi tamamladığında kullanıcıya şu başlıkları içeren şeffaf ve eksiksiz bir rapor sun:
1. Düzeltilen Captive Portal akışları ve form mantıkları.
2. FortiGate adapter'da yapılan canlı temizlik (IP sweep) ve süre optimizasyonları.
3. Firewall Analyzer ve Syslog arama motoruna kazandırılan yeni filtreler ve analitik paneller.
4. 23 Admin sayfasında yapılan iyileştirmeler.
5. Canlı test sonuçları (PASS / FAIL listesi).

<!-- GOAL_COMPLETE -->
```
