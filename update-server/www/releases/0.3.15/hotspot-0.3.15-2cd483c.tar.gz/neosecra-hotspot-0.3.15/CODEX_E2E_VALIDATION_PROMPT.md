# Master E2E Test & Doğrulama Promptu (Codex / Antigravity)

Bu dosya, NeoSecra Hotspot platformunun tüm modüllerini, uç sınır durumlarını (edge case) ve FortiGate güvenlik duvarı entegrasyonunu uçtan uca test etmek için hazırlanmış **Master Doğrulama Yönergesi**dir.

---

```markdown
# GÖREV: NeoSecra Hotspot & FortiGate Entegrasyonu Uçtan Uca (E2E) Tam Modül Denetimi ve Regresyon Testi

Aşağıdaki tüm modülleri, kimlik doğrulama yöntemlerini ve güvenlik duvarı (FortiGate) entegrasyonlarını uçtan uca test et. Tespit edilen tüm özel sınır durumlarını (edge case) doğrula ve her bir adım için [PASS / FAIL] raporu üret. Hata bulunursa otomatik olarak kodda ve canlı sunucuda düzelt.

---

### 🎯 1. MODÜL: TOPLANTI KODLARI (MEETING CODES)
1. **Özel Kod Tanımlama:** Yönetim panelinden girilen özel kodun (örn. `VDATA2026`) rastgele harflere dönüşmeden birebir veritabanına kaydedildiğini doğrula.
2. **Büyük/Küçük Harf & Lokasyon Esnekliği:** Kodun harf duyarsız (`vdata2026` ve `VDATA2026`) ve `location_id` bağımsız tüm bağlı cihazlarda doğrulandığını test et.
3. **Yönetici Onayı Muafiyeti:** Şablonda "Yönetici Onayı Zorunlu" açık olsa bile, önceden tanımlı toplantı kodunun yönetici e-posta onayına TAKILMADAN doğrudan internet erişimi verdiğini (`status: active`, `authorize_ok: true`) doğrula.
4. **Captive Portal Akışı:** Portal ekranından `verifyAndStart` akışının çağrıldığını ve FortiGate üzerinde istemci IP'sinin allow grubuna eklendiğini teyit et.

---

### 🎯 2. MODÜL: YEREL KULLANICILAR (LOCAL AUTH)
1. **Kullanıcı Oluşturma:** Yeni yerel kullanıcı (`username`, `password`, `display_name`, `email`) oluşturmayı test et.
2. **Silme & Tekrar Oluşturma (409 Conflict Önleme):** Oluşturulan kullanıcıyı sil. Ardından aynı kullanıcı adı ile tekrar kullanıcı ekle. Sistemin `409 Conflict: Bu kullanıcı adı zaten mevcut` hatası vermediğini, kaydı başarıyla yeniden aktif ettiğini doğrula.
3. **Boş Kullanıcı Adı Validasyonu:** Boşluk veya `""` kullanıcı adı gönderildiğinde backend'in 400 Bad Request döndüğünü kontrol et.

---

### 🎯 3. MODÜL: OTURUM YÖNETİMİ, YASAKLAMA VE FORTIGATE SİLME (REVOKE CLEANUP)
1. **Oturum Yetkilendirme:** Giriş yapan bir IP'nin FortiGate `Guest` ve `hotspot-allowed` adres gruplarına başarıyla eklendiğini kontrol et.
2. **Oturum İptali / Yasaklama:** Panelden oturum "İptal Edildi" veya "Yasaklandı" durumuna getirildiğinde:
   - FortiGate üzerinde o IP'ye ait tüm geçmiş `hsess-*` adres nesnelerinin bulunduğunu,
   - `Guest` ve `hotspot-allowed` gruplarından IP'nin derhal çıkarıldığını,
   - Adres nesnelerinin tamamen silindiğini ve FortiGate'te hiçbir artık kayıt kalmadığını (`Guest []`, `hotspot-allowed []`) doğrula.
3. **Cihazı Hatırla / MAC Auth Bypass:** 
   - İzin süresi (örn. 3 gün) devam eden bir cihaz portal URL'sini tekrar açtığında (`?client_mac=...`), sistemin `auto_authorized: true` dönerek kullanıcıya "Tekrar Hoş Geldiniz" ekranı sunduğunu ve tekrar form doldurtmadan internetini aktif tuttuğunu test et.

---

### 🎯 4. MODÜL: DAHİLİ FREERADIUS & VPN MFA
1. **Dahili RADIUS Bağlantı Testi:** `/api/v1/auth-methods/vpn/test-radius` endpoint'ini çağırarak Dahili FreeRADIUS servisinin yeşil yanıt verdiğini (`ok: true`, "Dahili RADIUS yanıt verdi") doğrula.
2. **Docker Ağı İstemci Eşleşmesi:** API container'ı (`172.18.0.0/16`) üzerinden FreeRADIUS'a gönderilen UDP 1812 paketlerinin `runtime/clients.conf` dosyasındaki tanımlı secret ile sorunsuz eşleştiğini ve timeout yaşanmadığını doğrula.

---

### 🎯 5. MODÜL: ŞABLON EDİTÖRÜ VE CANLI ÖNİZLEME (PORTAL TEMPLATES)
1. **Canlı Önizleme Render (Beyaz Ekran Kontrolü):** `/portal-templates/{id}/edit` sayfası ilk açıldığında iframe'in `srcDoc` üzerinden sıfır gecikmeyle anında render edildiğini doğrula.
2. **Dinamik Yönlendirme Linki:** FortiGate yönlendirme linkinin seçilen cihaz UUID'si ile birlikte hatasız üretildiğini ve "Adresi Kopyala" butonunun panoya yazdığını test et.
3. **Dinamik Form Alanları:** Şablona eklenen özel alanların (Geldiginiz Birim vb.) hem portalda doğru render edildiğini hem de 5651 log tablosuna eksiksiz yazıldığını doğrula.

---

### 🎯 6. MODÜL: DİĞER KİMLİK DOĞRULAMA YÖNTEMLERİ
- **SMS / T.C. Kimlik:** OTP kodu gönderme ve doğrulama akışı.
- **Bilet / Voucher:** Bilet kodu ile giriş ve süre tanımları.
- **Serbest (Free) Giriş:** Ad Soyad / Birim ile anında giriş ve yönetici onay akışı.

---

### 📊 RAPORLAMA FORMATI:
Testleri çalıştırdıktan sonra sonuçları şu formatta özetle:
- [✅ PASS / ❌ FAIL] Modül Adı — Detay / Oturum ID / FortiGate Durumu
- Tespit edilen bir hata varsa, hatanın sebebi ve uygulanan düzeltmeyi belirt.
```

---

### 🚀 Otomatik Test Betiğini Çalıştırma
İstediğiniz zaman tek bir komutla tüm canlı testleri koşturabilirsiniz:
```bash
python3 /home/sirgloomy/.gemini/antigravity-cli/brain/d25f68d5-a2d0-4bd8-a47e-240dbd907bd3/scratch/live_hotspot_suite.py
```
