# Kalan İşler — Hotspot Platform (Sprint 11 Sonrası)

## ✅ Sprint 06-11 — Tamamlananlar

- [x] **Sprint 06** — Backend test baseline (384 passed, 10 pre-existing failure kaydı)
- [x] **Sprint 07** — FortiLogger syslog MVP (TCP 514 receiver, RFC 5424 parser, FirewallLog)
- [x] **Sprint 07b** — Detaylı log search backend (GIN index, 4 endpoint, facets, correlate, export)
- [x] **Sprint 08** — SubGate captive portal (Fake FortiGate server, SMS/Voucher auth, session correlation)
- [x] **Sprint 09** — SignLogger hash chain + local cert CAdES + MinIO WORM
- [x] **Sprint 10** — E2E integration (MVP full flow, multi-tenant isolation, BTK export, performance smoke)
- [x] **Sprint 11** — Quality-close docs (final.md, DECISIONS.md, TODO.md, CLAUDE.md, events.jsonl, active-task.yaml)

- [x] **Frontend porting (NeoSecra Assessment GUI → Hotspot admin)**: Unified Log Search v2 & Differentiator Reports UI porting completed.
- [x] **RADIUS CoA (Change of Authorization)**: Disconnect & Rate Limit CoA implemented in `app/modules/radius/coa.py`.
- [x] **Real RADIUS Client Integration**: Packet-level Access/Accounting validation implemented in `app/modules/radius/client.py`.
- [x] **Multi-vendor Firewall Adapters**: Base adapter pattern & PaloAlto/MikroTik adapters completed.
- [x] **Multi-tenant & Health Check Hardening**: Scope enforcement, admin MFA default ON, and extended health checks (ClickHouse+MinIO) verified.

## P1 — Yüksek Öncelik

- [ ] **Firewall adapter skeleton** (11/12 vendor stub):
  - `paloalto`, `mikrotik`, `sophos`, `pfsense`, `watchguard`
  - `hp_procurve`, `cisco_like`, `generic_snmp`, `tplink`, `zyxel`, `draytek`, `aruba`, `ruijie`
  - Sadece `FortiGate` gerçek, geri kalan `raise NotImplementedError`
  - Yapılması gereken: ortak interface tanımı + 1 örnek vendor daha implement et
- [x] **Site Bridge agent hardening**:
  - `site-bridge/bridge/main.py` tek dosya 247 satır → modüler yapı (`enrollment.py`, `mtls.py`, `heartbeat.py`, `queue.py`, `main.py`)
  - Birim testler (`site-bridge/tests/`) tamamlandı.
- [ ] **Pyrad/radiusclient entegrasyonu**:
  - `test_radius_connection` sadece string kontrol ediyor, gerçek RADIUS paketi yok
  - Kütüphane ekle, gerçek Access-Request/Accounting-Request gönder

## P2 — Orta Öncelik

- [ ] **CI E2E job doğrulama**:
  - GitHub Actions'da `e2e` job tanımlandı ama çalıştırılmadı
  - `docker compose up` ile postgres+redis+uvicorn+vite start → playwright test
  - Push sonrası yeşil mi kontrol et
- [ ] **MFA default ON**:
  - Seed'de admin kullanıcılar için `is_2fa_enabled=True`
  - Login response'da `mfa_required: true` döner
  - 10 dk, 1 satır config + 1 test
- [ ] **Visual regression** (Playwright screenshot diff):
  - Login sayfası, dashboard, portal config, MFA ayarları
  - Baseline oluştur + CI gate
  - Yeni framework, ~3-5 gün
- [ ] **Portal browser full flow**:
  - Mevcut: 3 test (loading, config API, DOM render)
  - Eksik: gerçek voucher submit + redirect test

## P3 — Düşük Öncelik

- [ ] **Challenge dashboard approve/reject butonu**:
  - Admin pending challenge'ı onaylasın/reddetsin
  - API eklenecek (şu an sadece read-only)
- [ ] **FreeRADIUS multi-client support**:
  - Şu an `clients.conf`'da sadece `localhost` ve `docker-net`
  - Gerçek FortiGate için ayrı client entry
- [ ] **Demo tenant VPN MFA user seed**:
  - `seed_demo.py`'ye `vpnuser` ekle (manuel insert yerine)
- [ ] **Log search UX iyileştirme**:
  - `FirewallLogsPage.tsx` zengin (14 vendor + 8 severity + correlation)
  - Ama kullanıcı test etmemiş, UX feedback gerekebilir
- [ ] **Real SMS provider entegrasyonu**:
  - 6 provider stub (Netgsm, Twilio, MessageBird, RelatedDigital, Telsam, SMS)
  - Console provider yeterli demo için ama prod'da gerçek gerekir
- [ ] **Real email provider**:
  - `aiosmtplib` ile SMTP, console fallback
  - Prod'da SMTP yapılandırması gerekir
- [ ] **5651 log signing test**:
  - MinIO WORM 730d compose'da var, ayakta değil
  - `test_archive_5651_signing.py` yeşil ama gerçek MinIO kanıtı yok
- [ ] **Docker compose multi-profile**:
  - SaaS profile (site-bridge) + default profile ayrı
  - SaaS hiç çalıştırılmadı
- [ ] **NAT correlation (MAC-based)**:
  - Kod yazılmış, gerçek NAT ortamında doğrulanmamış
- [ ] **API documentation (OpenAPI)**:
  - Mevcut 189 route, dokümantasyon zenginleştirilebilir
- [ ] **Production security hardening**:
  - Rate limiting Redis down senaryosu test edilmemiş
  - Secrets encryption (Fernet key rotation)
  - Admin 2FA enforcement
- [ ] **Monitoring / Health checks**:
  - Mevcut: `GET /health` → DB+Redis OK
  - Eksik: Celery worker, MinIO, ClickHouse health
- [ ] **Frontend test expansion**:
  - Admin vitest: sadece StatusBadge (3 test)
  - Portal vitest: sadece AuthMethodSelector (3 test)
  - Bütün komponentler için test yazılmalı
