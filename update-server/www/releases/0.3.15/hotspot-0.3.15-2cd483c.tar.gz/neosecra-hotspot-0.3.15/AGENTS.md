## Mandatory Global NeoSecra Platform Contract

## Mandatory Stateless Cold Start

Every task starts with zero conversation history. Never rely on a previous session, resume capability, prior chat context or model memory.

Before processing the user request:

1. Read `/home/sirgloomy/AGENTS.md`.
2. Read `/home/sirgloomy/.codex/memory/neosecra-platform/00-PLATFORM-INDEX.md`.
3. Read this repository's `AGENTS.md`.
4. Read `.ai-ops/current-checkpoint.md`.
5. Determine the current branch, HEAD and dirty state.
6. Compare current HEAD with the reviewed HEAD in global memory.
7. Select the relevant NeoSecra skill.
8. Load only memory files required by that skill.
9. Inspect actual code before making implementation claims.
10. Continue the user's task without asking them to repeat prior project context.

At task completion, update the repository checkpoint so the next stateless task can continue from disk.

---

Before working in this repository, read and follow:

`/home/sirgloomy/AGENTS.md`

This repository is one module or infrastructure component of the NeoSecra
platform. The global file defines shared platform, authorization, security,
tenant, evidence, GUI, reporting, licensing, distribution, memory, skill,
testing and deployment rules.

The repository-specific rules below refine the global contract for this module.
They must not be used to reject an explicit user instruction that is allowed by
the global precedence rules.

---

# AGENTS.md — Worker Kuralları (Hotspot)

> Bu dosya hem OpenCode hem Cline worker'ları için bağlam disiplinini sabitler.
> Symlink: `.clinerules -> AGENTS.md`. Worker her görevde bunu okur.

## Repo Bağlamı
- **Repo yolu:** `/home/sirgloomy/projects/Hotspot`
- **Branch:** `feature/hotspot-mvp-readiness` (MVP run'ı burada)
- **Run ID:** `RUN-20260727-001`
- **Task contract:** `.agent/runs/RUN-20260727-001/task.yaml`
- **Design:** `docs/plans/2026-07-27-mvp-fortigate-design.md`
- **Diğer worker yoktur** — aynı cwd'de tek worker.

## Test Komutları (sırasıyla)
```bash
# 1. Kök 5651 smoke (4 dosya) — hızlı, önce bunu koş
cd /home/sirgloomy/projects/Hotspot && \
  backend/.venv-linux/bin/python -m pytest -q -p no:cacheprovider

# 2. Tam backend suite (IDOR + auth + portal dahil) — uzun
cd /home/sirgloomy/projects/Hotspot/backend && \
  .venv-linux/bin/python -m pytest tests/ -q --tb=line -p no:cacheprovider

# 3. Frontend build (admin)
cd /home/sirgloomy/projects/Hotspot/frontend/admin && npm run build

# 4. Docker compose (default profile)
cd /home/sirgloomy/projects/Hotspot && \
  docker compose -p hotspot-run-20260727-001 up -d

# 5. E2E integration tests (3s, Docker servisleri gerekli)
cd /home/sirgloomy/projects/Hotspot && \
  backend/.venv-linux/bin/python -m pytest backend/tests/e2e/ -v -p no:cacheprovider
```

## Bilinen Baseline (2026-07-27)
- **Kök 5651 smoke:** **53 passed in 0.96s** ✅ (test_archive_5651_signing,
  test_signing_service, test_report_service_5651, test_archive_service)
- **Tam backend suite:** **500 passed, 10 failed (pre-existing pdf+portal_voucher), 21 skipped** ✅
  — 10 pre-existing failure aynı kalır, regression yok.
- **E2E suite:** **15 passed in 3.22s** ✅ — 6 dosya, real Docker servisler.
  Docker compose up olmalı (postgres:55432, minio:59002).
- **Frontend build:** ölçülmedi.
- **Docker compose:** AYAKTA ✅ — `docker ps` ile kontrol et.

## Mutlak Yasaklar (CLAUDE.md kural 1-12 özeti)
1. Tenant isolation ASLA bypass — her sorgu scope filtreli (ScopeContext).
2. API token'ı response içinde dönme; plaintext saklama.
3. 5651 log/arşiv **append-only** — `UPDATE`/`DELETE` yok, event eklenir.
4. Vendor özel kodu (FortiGate) core service'e gömeME — adapter pattern korunur.
5. Migration geri dönüşü olmayan dönüşüm içermez.
6. `git push` YAPMA — sadece commit; push beyden (kullanıcı onayı ile).
7. `curl -k` YASAK — TLS her zaman doğrulanır.
8. Secret/token/key prompt'a girME, repoya commit ETME.
9. Detached HEAD'te commit yapMA — `git branch --show-current` ile doğrula.
10. `rm`, `git reset --hard`, `truncate -s 0` gibi yıkıcı komutlar kullanıcı
    onayı ister.

## Doğrulama Zorunluluğu (her execute sonrası)
Worker "yaptım" derse DUR — kanıt senin elinde olmalı:
1. `git status` — tree temiz mi, değişen dosyalar allowed_paths içinde mi?
2. `git diff --stat` — scope'a uygun mu?
3. `git log --oneline -5` — commit var mı, mesaj formatı doğru mu?
4. Testleri **kendin koş** (yukarıdaki komutlarla) — worker'ın claim'ine güvenme.
5. Script/endpoint'i bizzat çalıştır (dummy input ile).
6. Worker timeout ile öldüyse (finishReason: error): dirty tree'yi kurtar,
   değişiklikleri `git stash` ile sakla, korumaya al.

## Commit Mesaj Formatı
```
<type>(<scope>): <özet>

<body, ne/neden>

Run-ID: RUN-20260727-001
```
Örnek:
```
feat(syslog): RFC 5424 parser + DB insert

FortiLogger MVP syslog receiver eklendi. traffic/event/utm type ayrımı
yapılır, tenant scope filtresi uygulanır. 3 unit test eklendi.

Run-ID: RUN-20260727-001
```

## Push Politikası
- Bey (ana oturum) push eder — worker ETMEZ.
- İstisna: kullanıcı açıkça "push yap" demişse.

## Rapor İçeriği (worker bitince döndürmesi gereken)
```yaml
status: DONE | PARTIAL | BLOCKED
summary: <2-3 cümle>
changed_files:
  - <dosya yolu>
tests_run:
  - command: <komut>
    exit_code: <kod>
    passed: <n>
    failed: <n>
risks: []
next_action: <önerilen sonraki adım>
```

## T3 Path'ler (risk-policy.yaml)
Bu path'lerde değişiklik T3'tür, security-auditor çağrılır:
- `backend/app/modules/logs_5651/**`, `archive/**`
- `backend/app/**/tenants/**`, `partners/**`, `customers/**`, `locations/**`
- `backend/app/**/identity/**`, `radius/**`, `sessions/**`
- `backend/app/**/firewall_adapters/**`, `secret*`, `crypto*`, `token*`
- `backend/app/**/auth*/**`, `rbac*`, `permission*`, `mfa*`
- `backend/alembic/versions/**`
- `backend/app/**/syslog/**`
- `**/.env*`, `docker-compose*.yml`, `infra/**`

## Bilinen Tuzaklar (NeoSecra tecrübesinden)
1. **Timeout ölümü** — worker uzun işte ölebilir. `--auto-approve true` + prompt'ta
   timeout ver. Dirty tree'yi kurtar.
2. **Test env eksik** — `.venv-linux` doğru venv; başka venv'lerde dependency eksik.
   Collection errorları = env sorunu, kod hatası değil.
3. **Baseline yanılgısı** — kök smoke 53 passed, ama tam suite bilinmiyor. Pre-existing
   failure'lar regression değildir; net ayrım yap.
4. **Detached HEAD** — görev başında `git branch --show-current` ile doğrula,
   `feature/hotspot-mvp-readiness` üzerinde değilsen DUR.
