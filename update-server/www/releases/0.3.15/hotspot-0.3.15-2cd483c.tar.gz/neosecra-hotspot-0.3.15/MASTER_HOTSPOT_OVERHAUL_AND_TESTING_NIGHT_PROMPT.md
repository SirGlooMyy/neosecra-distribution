# NEOSECRA HOTSPOT — MASTER GECE İNCELEME, FONKSİYONEL İYİLEŞTİRME VE FIREWALL ANALYZER GÜÇLENDİRME MOTORU

> **Kullanım Amacı:** Bu prompt, Hotspot platformundaki tüm sayfaları, captive portal mantık akışlarını ve zayıf kalan **Firewall Analyzer / Syslog / 5651 Log arama motorunu** sabaha kadar derinlemesine incelemek, eksik mantıkları kodlamak ve yarınki canlı testlerde sistemin %100 pürüzsüz çalışmasını sağlamak için hazırlanmıştır.

---

```markdown
# GÖREV: NeoSecra Hotspot — Tüm Sayfaların Fonksiyonel Mantık Denetimi, Captive Portal Akışları ve Firewall Analyzer Güçlendirmesi (/goal)

Sen NeoSecra Hotspot ve Ağ Güvenlik Mimarisinden sorumlu Baş Mühendissin.
Bu geceki görevin; sadece birim (unit) testleri geçmek değil, platformun **işlevsel olarak %100 hatasız ve mantık hatasız** çalıştığından emin olmaktır. Canlıda FortiGate (192.168.2.1) ve zengin log kaynakları mevcuttur. 
Aşağıdaki 4 ana modülü sayfa sayfa, yöntem yöntem inceleyecek, eksik veya hatalı mantıkları backend ve frontend'de düzelteceksin.

---

## ⛔ TEMEL ÇALIŞMA PRENSİPLERİ
1. Sahte veya mock-only onay yok; her ekranın gerçekten işlevini yerine getirdiğini (API, veritabanı, frontend reaktif durumu) doğrula.
2. Canlı FortiGate entegrasyonunda artık adres nesnesi kalmayacak şekilde tam temizlik (IP sweep) mantığını koru.
3. Değişiklikleri hem backend (`/home/sirgloomy/projects/Hotspot/backend`) hem frontend (`frontend/admin` ve `frontend/portal`) tarafında kalıcı olarak uygula.

---

# 🖥️ BÖLÜM 1: WEB YÖNETİM PANELİ SAYFA SAYFA MANTIK DENETİMİ (ADMIN PANEL)

Aşağıdaki tüm sayfaları tek tek ele al ve işlevselliğini %100 doğrula:

1. **Oturum Yönetimi (`SessionsPage.tsx`):**
   - Arama ve filtrelerin (IP, MAC, İsim, T.C., Durum) doğru çalıştığını doğrula.
   - "İptal Et" / "Yasakla" butonuna basıldığında hem DB'de oturumun kapandığını hem de FortiGate'ten o IP'ye ait TÜM adres nesnelerinin anında silindiğini teyit et.
   - Dinamik grup sürelerinin (örn. 3 gün, 5 gün) oturum bitiş tarihine (`expires_at`) doğru yansıdığını kontrol et.

2. **Kullanıcılar & Yerel Hesaplar (`UsersPage.tsx`):**
   - Kullanıcı ekleme, şifre değiştirme, silme ve **silinen bir kullanıcıyı aynı isimle tekrar eklerken `409 Conflict` hatası almadan aktif etme** mantığını doğrula.

3. **Kullanıcı Grupları & Dinamik Süreler (`UserGroupsPage.tsx`):**
   - Gruplara tanımlanan sürelerin (1 gün, 3 gün, 1 hafta, 3 ay vb.) ve bant genişliği limitlerinin (Download/Upload Mbps) yeni bağlanan kullanıcılara otomatik uygulanmasını sağla.

4. **Kimlik Doğrulama Yöntemleri (`AuthMethodsPage.tsx`):**
   - **Toplantı Kodları:** Özel kod (örn. `VDATA2026`) girildiğinde kodun bozulmadan saklanması, büyük/küçük harf duyarsızlığı ve kota takibi.
   - **Dahili FreeRADIUS:** Paneldeki "Dahili RADIUS Test Et" butonunun Docker içi `172.18.0.0/16` ağından UDP 1812 testi yapıp yeşil yandığını doğrula.
   - **SMS / T.C. Kimlik / Bilet (Voucher):** Tüm ayarların DB'ye kaydedildiğini ve ilgili portal formlarına yansıdığını test et.

5. **Şablon Editörü (`TemplateEditorPage.tsx`):**
   - Canlı önizleme iframe'inin ilk açılışta beyaz kalmadan anında yüklenmesi (`srcDoc` render).
   - Form Alanları düzenleyicisinde (Ad Soyad, Birim vb.) ekleme/çıkarma/zorunlu yapma değişikliklerinin anında portala yansıması.
   - "Yönlendirme Linki" (Redirect URL) ve "FortiGate Captive Portal Adresi" kopyalama butonlarının hatasız çalışması.

6. **Cihaz Yönetimi (`DevicesPage.tsx`):**
   - FortiGate cihazı için "Bağlantıyı Test Et" butonunun API Token ile sağlıklı iletişim kurduğunu doğrula.

7. **Yönetici Onay Talepleri (`ApprovalRequestsPage.tsx`):**
   - Bekleyen taleplerde "Onayla" tıklandığında kullanıcının anında `active` duruma geçip FortiGate'te internetinin açıldığını, "Reddet" tıklandığında engellendiğini test et.

---

# 📱 BÖLÜM 2: CAPTIVE PORTAL UÇTAN UCA MANTIK AKIŞLARI (PORTAL UI)

Captive portal üzerindeki her bir giriş yöntemini mantık hatalarına karşı denetle:

1. **Toplantı Kodu ile Giriş (`MeetingLoginForm.tsx`):**
   - Şablonda "Yönetici Onayı Zorunlu" olsa bile, toplantı kodunun yönetici onayına TAKILMADAN doğrudan interneti açtığını (`authorize_ok: true`) doğrula.
   - Şablondaki Ad Soyad gibi form alanları toplantı ekranında sorulmadığı için arka planda 400 Bad Request almasını engelleyen mapping'i koru.

2. **Serbest (Free) Giriş & Dinamik Form Alanları:**
   - Ad Soyad ve "Geldiginiz Birim" gibi dinamik form alanlarının eksiksiz alındığını ve 5651 loglarına yazıldığını doğrula.

3. **Cihazı Hatırla / MAC Auth Bypass (Auto Welcome-Back):**
   - Grup süresi (örn. 3 gün) devam eden bir cihaz portal URL'sini tekrar açtığında (`?client_mac=...`), sistemin `auto_authorized: true` dönerek kullanıcıya tekrar form doldurtmadan "Erişiminiz Devam Ediyor / İnternete Bağlan" butonu sunmasını doğrula.

4. **Başarılı Giriş Sonrası Web Sitesine Yönlendirme:**
   - Giriş tamamlandıktan sonra şablonda belirlenen web sitesine (örn. `vdata.com.tr`) otomatik yönlenmesini sağla.

5. **SMS / OTP & T.C. Kimlik Doğrulama:**
   - OTP sayacı (60 sn geri sayım), hatalı kod uyarısı ve T.C. kimlik algoritma kontrolünün pürüzsüz çalıştığını doğrula.

---

# 🛡️ BÖLÜM 3: FIREWALL ANALYZER & 5651 LOG MOTORUNU GÜÇLENDİRME (KRİTİK GELİŞTİRME)

Firewall Analyzer ve Log arama tarafı şu an zayıf durumdadır. Aşağıdaki geliştirmeleri yaparak güçlü bir SIEM/Analyzer seviyesine çıkar:

1. **FortiGate Canlı Syslog Ayrıştırıcı (Parser Hardening):**
   - `backend/app/modules/syslog/parsers.py` içinde FortiGate trafik, UTM (Web Filter, Antivirus, IPS) ve VPN loglarını eksiksiz parse eden mantığı güçlendir:
     - `srcip`, `dstip`, `srcport`, `dstport`, `proto`, `action` (accept/deny/close), `sentbyte`, `rcvdbyte`, `duration`, `service`, `app`, `hostname/url`.

2. **Gelişmiş Log Arama ve Filtreleme (`FirewallLogsPage.tsx` & `LogsSearch.tsx`):**
   - ClickHouse / PostgreSQL üzerindeki arama sorgularını hızlandır.
   - Operatörün tek tıkla şu filtreleri uygulayabilmesini sağla:
     - **IP Filtresi:** Kaynak IP (`10.34.98.*`) veya Hedef IP araması.
     - **Zaman Filtresi:** Son 15 dakika, 1 saat, 24 saat, Özel Tarih Aralığı.
     - **Aksiyon Filtresi:** İzin verilenler (`Accept`), Engellenenler (`Deny/Block`).
     - **Tehdit / Güvenlik Filtresi:** Sadece UTM / Tehdit loglarını listele.

3. **Trafik Analizi ve Görselleştirme (`TrafficAnalysisPage.tsx`):**
   - Canlı syslog verisinden beslenen şu görsel panelleri eksiksiz çalışır hale getir:
     - **En Çok Bant Genişliği Tüketen Kullanıcılar (Top 10 Users / MACs by Bytes)**.
     - **En Çok Ziyaret Edilen Siteler / Domainler (Top Web Categories & Domains)**.
     - **Protokol Dağılımı:** HTTPS, DNS, HTTP, SSH, Diğer.
     - **Saatlik Trafik Yoğunluğu (Peak Traffic Hours)** grafiği.

4. **5651 Yasal Log Zinciri & Zaman Damgası (`SigningConfigPage.tsx`):**
   - Hotspot kullanıcı kimlik bilgileri (IP-MAC-Zaman-TC-İsim) ile FortiGate NAT/Trafik loglarının `correlation_id` üzerinden tam eşleştiğini doğrula.
   - Gün sonu loglarının SHA-256 zinciri ile hash'lendiğini ve WORM/MinIO arşivine kilitlendiğini test et.

---

# 📊 BÖLÜM 4: ÇIKIŞ & DOĞRULAMA RAPORU (FINISH REPORT)

Sabah testler başladığında sıfır sürpriz olması için raporunda şunları sun:
1. Web Yönetim Panelinde düzeltilen sayfalar ve mantık hataları.
2. Captive Portal'da test edilen tüm giriş yöntemleri (Toplantı, Serbest, SMS, TC, MAC Bypass).
3. Firewall Analyzer'da eklenen/güçlendirilen parser ve log arama yetenekleri.
4. Canlı FortiGate ile yapılan oturum açma/kapatma (sweep) teyidi.

<!-- GOAL_COMPLETE -->
```
