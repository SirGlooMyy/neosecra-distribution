#!/usr/bin/env python3
"""Run all 5651-related tests."""
import subprocess
import sys
import os

os.chdir("/home/sirgloomy/projects/Hotspot/backend")
os.environ["PYTHONPATH"] = "/home/sirgloomy/projects/Hotspot/backend"

test_files = [
    "tests/test_archive_5651_signing.py",
    "tests/test_signing_service.py",
    "tests/test_report_service_5651.py",
    "tests/test_archive_service.py",
]

exit_code = 0
for tf in test_files:
    print(f"\n{'='*70}")
    print(f"RUNNING: {tf}")
    print(f"{'='*70}")
    result = subprocess.run(
        [sys.executable, "-m", "pytest", tf, "-v", "--tb=short", "--no-header", "-p", "no:warnings"],
        capture_output=True, text=True, cwd="/home/sirgloomy/projects/Hotspot/backend",
        timeout=120
    )
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr[:2000])
    print(f"EXIT CODE: {result.returncode}")
    if result.returncode != 0:
        exit_code = 1

sys.exit(exit_code)

