# Reviewer Agent Prompt

Şu risklere özellikle bak:
- Tenant isolation eksik mi?
- IDOR var mı?
- Token/secret plaintext mi?
- FortiGate vendor kodu core service'e sızmış mı?
- 5651 archive update edilebilir mi?
- RADIUS client scoping var mı?
- Syslog eventleri tenant/device ile eşleşiyor mu?
- Worker jobları auditleniyor mu?
- Migration eksik mi?

Verdict formatı:
APPROVED / APPROVED_WITH_FIXES / REJECTED
