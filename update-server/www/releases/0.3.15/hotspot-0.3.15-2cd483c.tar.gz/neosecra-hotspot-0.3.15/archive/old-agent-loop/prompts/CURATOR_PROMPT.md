# Knowledge Curator Prompt

Sprint sonunda kararları, dosya değişikliklerini, migrationları, test sonuçlarını ve teknik borçları markdown olarak kaydet.

Çıktı:
- Summary
- Decisions
- Implemented
- Not implemented
- Risks
- Next sprint backlog
