# HOTSPOT ACCESS PLATFORM — ULTIMATE MASTER PROMPT

> Bu belge, projeyi basit bir hotspot arayüzünden; 5651 arşivleme, yüksek hızlı log analizi, captive portal, RADIUS/802.1X, SSL/IPsec VPN MFA, Windows Login MFA, NAC, firewall entegrasyonları, kullanıcı politikaları, raporlama ve çok kiracılı bayi yönetimi sunan ticari bir erişim ve güvenlik platformuna dönüştürmek için ana uygulama promptudur.

---

## 0. ANA TALİMAT

Sen; ürün mimarı, kıdemli backend mühendisi, kıdemli frontend mühendisi, ağ güvenliği mühendisi, RADIUS uzmanı, firewall entegrasyon mühendisi, veri platformu mühendisi, DevOps/SRE, test mühendisi ve güvenlik denetçisi rollerini birlikte üstlenen bir uygulama ajanısın.

Bu repoda yarım ekranlar, mock veriler, birbirinden kopuk modüller veya yalnızca görünür frontend oluşturmak kabul edilmez. Görevin, mevcut kodu koruyarak ve geliştirerek uçtan uca çalışan, test edilmiş, dokümante edilmiş, üretime yakın bir ürün ortaya çıkarmaktır.

Temel hedef:

```text
Firewall / VPN / Switch / AP / Windows Endpoint
                    ↓
Syslog + RADIUS + Accounting + Vendor API + Agent
                    ↓
Hotspot Access Platform
                    ↓
Kimlik doğrulama + MFA + Yetkilendirme + Oturum + Korelasyon
                    ↓
Hızlı Arama + 5651 Arşiv + İmza + Rapor + Alarm
```

Her modül için şu beş katman eksiksiz bulunmalıdır:

1. Veri modeli ve migration
2. Domain service ve güvenlik kuralları
3. API ve background worker
4. Operasyonel frontend ekranı
5. Otomatik test, gözlemlenebilirlik ve dokümantasyon

Bir sayfanın açılması tamamlanmış sayılmaz. Sayfa gerçek API ile çalışmalı; loading, empty, error, permission, validation, optimistic işlem veya refresh davranışları tanımlı olmalıdır.

---

## 1. BAŞLANGIÇ PROTOKOLÜ

Kod yazmadan önce:

1. `CLAUDE.md`, `DECISIONS.md`, `AGENT_TASK.md`, `README.md`, `docs/`, `prompts/` ve ilgili uygulama dizinlerini oku.
2. `git status --short` ile kullanıcıya ait değişiklikleri belirle; ilgisiz değişiklikleri silme veya ezme.
3. Backend router, model, migration, worker, adapter ve test envanteri çıkar.
4. Admin ve portal uygulamalarındaki route, sayfa, API çağrısı, mock veri ve placeholder envanteri çıkar.
5. Docker Compose, PostgreSQL, Redis, MinIO, RADIUS, syslog ve varsa ClickHouse/OpenSearch hazırlığını incele.
6. Mevcut modülleri yeniden yazma; çalışan temelleri genişlet.
7. Gerçek durum ile bu master prompt arasındaki farkları bir gap tablosuna dönüştür.
8. Bağımlılık sırasına göre faz planı hazırla.
9. Aynı anda yalnızca bir migration zinciri ve bir domain sınırı üzerinde çalış.
10. Her faz sonunda build ve ilgili testler geçmeden sonraki faza geçme.

Plan aşağıdaki kolonları içermelidir:

| Faz | Domain | Backend | Frontend | Worker/Adapter | Migration | Test | Risk | Durum |
|---|---|---|---|---|---|---|---|---|

---

## 2. DEĞİŞMEZ MİMARİ KURALLARI

### 2.1 Multi-tenant izolasyon

- Her iş kaydı tenant/customer/location kapsamına bağlı olmalıdır.
- Kullanıcıdan gelen `tenant_id`, `customer_id`, `location_id` doğrudan güvenilir kabul edilmez.
- Scope, authenticated actor ve RBAC üzerinden doğrulanmalıdır.
- Liste, detay, güncelleme, silme, export ve background job yollarının tamamı IDOR korumalıdır.
- Super admin dışındaki kullanıcılar başka tenant verisini tahmin edilebilir UUID ile görememelidir.
- Tenant izolasyonu için pozitif ve negatif otomatik test yazılmalıdır.

### 2.2 Adapter-first firewall entegrasyonu

- Vendor özel kod domain service, router veya frontend içine dağılmamalıdır.
- FortiGate, Sophos, SonicWall, WatchGuard, Palo Alto, MikroTik, pfSense, Zyxel, DrayTek, Aruba, TP-Link, Ruijie ve yeni üreticiler adapter registry üzerinden çalışmalıdır.
- Her adapter capability bildirimi yapmalıdır.
- Desteklenmeyen operasyon açık hata döndürmeli; sessiz başarı kabul edilmez.

Örnek capability sözleşmesi:

```python
class FirewallCapabilities:
    external_captive_portal: bool
    radius_authentication: bool
    radius_accounting: bool
    radius_coa: bool
    disconnect_message: bool
    mac_auth_bypass: bool
    local_guest_users: bool
    vpn_radius_mfa: bool
    active_session_query: bool
    authorize_guest_api: bool
    revoke_guest_api: bool
    config_backup: bool
    syslog: bool
    api_health: bool
```

### 2.3 Append-only güvenlik kayıtları

- 5651 arşiv kayıtları, audit eventleri, MFA attempt kayıtları ve kritik erişim eventleri append-only yaklaşımında tutulmalıdır.
- Hash zinciri geçmiş kaydı güncelleyerek yeniden oluşturulamaz.
- Arşiv objesi üzerine yazılamaz; aynı içerik idempotent anahtar kullanabilir.
- Kritik kayıtların hard delete endpoint'i bulunmamalıdır.
- Retention işlemi yasal minimum, hold, korelasyon ve imza durumunu kontrol etmeden veri silemez.

### 2.4 Gizli bilgi yönetimi

- RADIUS secret, firewall token, LDAP bind password, SMTP ve SMS credential şifreli saklanmalıdır.
- API cevaplarında secret hiçbir zaman geri dönmemelidir; yalnızca `configured`, `last_rotated_at`, `test_status` gösterilmelidir.
- Loglarda OTP, parola, token, private key veya tam TCKN bulunmamalıdır.
- UI secret alanları tekrar doldurulabilir ama mevcut değer gösterilmez.

### 2.5 Idempotency ve audit

- Kullanıcı açma, authorize, revoke, OTP gönderme, archive build, report generate ve config push işlemleri idempotency key desteklemelidir.
- Kritik aksiyonlarda actor, tenant, hedef kaynak, önceki/yeni durum, IP, user-agent, correlation-id ve sonuç audit edilmelidir.

---

## 3. ÜRÜN MODÜLLERİ VE MENÜ OMURGASI

Admin panel aşağıdaki ana bilgi mimarisini kullanmalıdır:

1. Genel Bakış
2. Organizasyon
   - Tenantlar
   - Bayiler
   - Müşteriler
   - Lokasyonlar
   - Lisanslar
3. Altyapı
   - Cihazlar
   - Firewall Entegrasyonları
   - Switch ve AP Yönetimi
   - Bağlantı Sağlığı
   - Konfigürasyon Yedekleri
4. Hotspot
   - Captive Portal Tasarımları
   - Doğrulama Yöntemleri
   - Kullanıcılar
   - Online Kullanıcılar
   - Onay Bekleyenler
   - Whitelist / Blacklist
   - Kullanıcı Grupları
   - Voucher / Toplantı Kodları
   - PMS Entegrasyonları
   - Dil ve Sözleşmeler
5. Erişim ve NAC
   - RADIUS Sunucusu
   - NAS İstemcileri
   - RADIUS Authentication Logları
   - RADIUS Accounting
   - 802.1X Enterprise
   - VLAN Politikaları
   - EAP Kuralları
   - MAC Authentication Bypass
   - Karantina
6. MFA
   - VPN MFA
   - Windows Login MFA
   - MFA Kullanıcıları
   - MFA Grupları ve Politikaları
   - OTP Sağlayıcıları
   - TOTP Cihazları
   - MFA Logları
7. Log Yönetimi
   - Canlı Syslog
   - Hızlı Log Arama
   - Trafik Analizi
   - Alarm ve Trigger
   - 5651 Arşivleri
   - İmza ve Doğrulama
   - Saklama Politikaları
8. Raporlama
   - Rapor Kataloğu
   - Rapor Oluşturucu
   - Zamanlanmış Raporlar
   - Rapor Arşivi
9. Sistem
   - Yöneticiler ve RBAC
   - SMS
   - SMTP
   - LDAP/AD
   - Bildirimler
   - Worker ve Servis Durumu
   - Backup/Restore
   - Audit Log
   - Sistem Ayarları

Menü permission bazlı filtrelenmeli; URL'yi doğrudan açmak permission kontrolünü aşmamalıdır.

---

## 4. FIREWALL ONBOARDING VE CAPABILITY MOTORU

### 4.1 Cihaz ekleme sihirbazı

Cihaz ekleme tek bir genel form olmamalıdır. En az şu adımlar bulunmalıdır:

1. Üretici, ürün ailesi, model ve firmware seçimi
2. Lokasyon, yönetim IP/FQDN, VDOM/tenant/context seçimi
3. Kullanım senaryoları:
   - Syslog toplama
   - External Captive Portal
   - RADIUS hotspot
   - SSL/IPsec VPN MFA
   - 802.1X/NAC
   - Aktif oturum sorgulama
   - Konfigürasyon yedekleme
4. Credential ve güvenli bağlantı bilgileri
5. Capability sonucu ve desteklenmeyen özellik uyarıları
6. Firewall tarafında uygulanacak GUI/CLI reçetesi
7. Bağlantı testi
8. Syslog test eventi
9. RADIUS Access-Request testi
10. Authorize/revoke test kullanıcısı
11. Sonuç özeti ve aktivasyon

### 4.2 Bağlantı testi

Test sonucu tek yeşil/kırmızı ikon olmamalıdır:

- DNS resolve
- TCP/TLS erişimi
- Sertifika doğrulaması
- API authentication
- Yetki kapsamı
- Cihaz seri/model/firmware keşfi
- Syslog receiver erişimi
- RADIUS UDP/TCP/RadSec erişimi
- Saat/NTP farkı
- Son başarılı test
- Ayrıntılı ancak secret içermeyen hata

### 4.3 Capability matrisi

Backend capability endpoint'i üretmeli ve frontend cihaz detayında göstermelidir. UI, desteklenmeyen butonu çalışıyor gibi göstermemelidir.

### 4.4 Kurulum reçeteleri

Her vendor için sürümlenebilir kurulum rehberi üret:

- Ön koşullar
- Ağ topolojisi
- Açılması gereken portlar
- Firewall GUI adımları
- Güvenli CLI örneği
- Gerekli user group/policy
- External portal URL formatı
- RADIUS NAS IP ve secret yerleşimi
- Accounting/CoA ayarı
- Walled garden/exempt adresler
- TLS sertifikası
- Test prosedürü
- Geri alma prosedürü
- Sık hata ve çözüm

---

## 5. CAPTIVE PORTAL UÇTAN UCA AKIŞI

### 5.1 Temel akış

```text
Client Wi-Fi/LAN'a bağlanır
→ Firewall HTTP/HTTPS isteğini yakalar
→ External Captive Portal URL'sine redirect eder
→ Portal signed context'i doğrular
→ Tenant/location/device/template/policy çözülür
→ Kullanıcı doğrulama yöntemini tamamlar
→ Platform policy ve lisans kontrolü yapar
→ Firewall adapter veya RADIUS ile authorize edilir
→ Accounting oturumu başlar
→ Online kullanıcı ekranına yansır
→ Timeout/kota/admin/revoke olayıyla oturum kapanır
→ Accounting stop ve korelasyon arşive işlenir
```

### 5.2 Portal context

Context en az şunları taşımalıdır:

- device_id ve adapter/vendor
- location/customer/tenant
- client MAC ve IP
- NAS IP
- SSID/interface/VLAN
- original URL
- firewall challenge/session token
- timestamp, nonce, expiry
- HMAC veya asymmetric signature

Context manipülasyonu, replay ve başka cihaz token'ı kullanımı engellenmelidir.

### 5.3 Doğrulama yöntemleri

- Ücretsiz/sözleşme kabulü
- Telefon + SMS OTP
- E-posta OTP
- TCKN + telefon + OTP
- Yabancı kimlik/pasaport
- Lokal kullanıcı adı/parola
- LDAP/Active Directory
- Voucher/bilet/toplantı kodu
- PMS oda/soyad/pasaport kombinasyonu
- WhatsApp OTP
- Sponsor/yönetici onayı
- MAC bypass/whitelist

Yöntemler tenant/lokasyon/portal bazında sıralanabilir ve açılıp kapatılabilir olmalıdır.

### 5.4 Portal tasarım editörü

- Hazır şablon galerisi
- Masaüstü/mobil canlı önizleme
- Logo, arka plan, overlay ve opaklık
- Font, renk, kart, input ve buton stilleri
- Doğrulama yöntemlerinin sıralaması
- Dil seçici
- KVKK, kullanım koşulları ve açık rıza metinleri
- Metni açmadan onay verememe seçeneği
- Başarı, hata ve bakım ekranları
- Redirect hedefi
- Versiyonlama, taslak, yayınlama ve rollback
- Lokasyona veya cihaza atama

### 5.5 Authorize ve revoke

Authorize sonucu şu durumlardan biri olmalıdır:

- `authorized`
- `pending_approval`
- `denied_policy`
- `denied_quota`
- `denied_blacklist`
- `device_offline`
- `adapter_error`
- `expired_context`

Başarı yalnızca DB kaydı açılması değildir. Firewall/RADIUS onayı doğrulanmadan kullanıcı online gösterilmemelidir.

Revoke kaynakları:

- Kullanıcı manuel düşürme
- Admin düşürme
- Session timeout
- Idle timeout
- Kota
- Hesap bitiş tarihi
- Blacklist
- Cihaz health kaybı
- CoA/Disconnect
- Firewall reconciliation

---

## 6. HOTSPOT KULLANICI OPERASYONLARI

### 6.1 Kullanıcı ekranı sekmeleri

1. Tüm Kullanıcılar
2. Online
3. Offline/Geçmiş
4. Onay Bekleyenler
5. Manuel Kullanıcılar
6. Whitelist
7. Blacklist
8. Voucher/Toplantı Kodları

### 6.2 Kullanıcı alanları

- Kullanıcı adı
- Ad/soyad
- Maskeli telefon/e-posta/TCKN
- Auth yöntemi
- Kullanıcı grubu
- Tenant/customer/location/device
- MAC/IP/NAS IP/SSID
- İlk/son giriş
- Hesap başlangıç/bitiş
- Online durumu
- Kullanılan süre ve trafik
- Eşzamanlı cihaz sayısı
- Onay durumu
- Risk/ban durumu

### 6.3 Operasyonlar

- Manuel kullanıcı oluştur/düzenle/pasifleştir
- Güvenli rastgele parola üret
- İlk girişte parola değiştirme
- Süre uzat
- Kota ekle
- Kullanıcı grubunu değiştir
- MAC'e sabitle
- Oturumu düşür
- Tüm oturumları düşür
- Whitelist/blacklist'e ekle
- Sponsor onayı ver/reddet
- CSV import/export
- Audit geçmişi

### 6.4 Kullanıcı grupları

Her grup:

- Ad/açıklama
- Vendor/firewall profili
- Session timeout
- Idle timeout
- Hesap geçerlilik süresi
- Download/upload Mbps
- Günlük/saatlik/aylık kota
- Eşzamanlı kullanıcı ve cihaz sınırı
- Redirect URL
- VLAN/role/group mapping
- Gün/saat erişim takvimi
- İçerik/policy profili
- Karantina davranışı
- Aktif/pasif

### 6.5 Whitelist/blacklist

Kural tipi:

- MAC
- Telefon hash/maskeli eşleşme
- Kullanıcı
- IP/CIDR
- Cihaz fingerprint
- Voucher

Kural; kapsam, sebep, başlangıç/bitiş, oluşturan kişi ve audit bilgisi taşımalıdır. Whitelist, firewall tarafındaki bypass ile platform DB durumunu reconcile etmelidir.

---

## 7. VPN MFA VE WINDOWS LOGIN MFA

### 7.1 VPN MFA akışı

```text
FortiClient veya VPN client
→ Firewall/VPN gateway kullanıcı adı + parola alır
→ RADIUS Access-Request platforma gelir
→ NAS, kullanıcı, grup ve MFA politikası çözülür
→ Birincil parola LDAP/AD/lokal kaynakta doğrulanır
→ OTP challenge oluşturulur
→ SMS/e-posta/TOTP/push kanalı uygulanır
→ Kod doğrulanır
→ Access-Accept + vendor/group/VLAN attribute
  veya Access-Reject
→ Accounting start/interim/stop işlenir
```

VPN MFA, captive portal modülüne bağımlı olmamalıdır.

### 7.2 MFA kanalı politikası

Desteklenecek modlar:

- SMS only
- Email only
- TOTP only
- SMS primary, email fallback
- Email primary, SMS fallback
- Kullanıcıya kayıtlı kanallar arasından seçim
- Grup bazlı kanal zorunluluğu
- Acil tek kullanımlık recovery code
- Belirli trusted network/device için kontrollü bypass

Fallback yalnızca gönderim teknik olarak başarısızsa veya policy izin veriyorsa çalışmalı; yanlış OTP girildi diye otomatik kanal değiştirilmemelidir.

### 7.3 OTP güvenliği

- Kriptografik güvenli rastgele kod
- Configurable 6–8 hane
- 2–5 dakika TTL
- Tek kullanım
- Hash'li saklama
- Kullanıcı/NAS/IP/device bazlı rate limit
- Maksimum deneme
- Replay koruması
- Cooldown ve lockout
- Mesajda parola veya hassas bilgi yok
- Gönderim ve doğrulama audit kaydı

### 7.4 Birincil kimlik kaynakları

- Active Directory/LDAP
- Platform lokal kullanıcıları
- Harici RADIUS proxy
- Firewall lokal kullanıcı senkronizasyonu (adapter destekliyorsa)

### 7.5 MFA kullanıcı ekranları

- Kullanıcılar
- Gruplar
- Telefon/e-posta doğrulama durumu
- Birincil identity source
- MFA yöntemi
- TOTP enrollment
- Recovery codes
- Trusted devices
- Son başarılı/başarısız giriş
- Lock/unlock
- Token reset
- Toplu import ve AD sync

### 7.6 Windows Login MFA

Windows agent güvenli enrollment ile platforma bağlanmalıdır:

- Device certificate veya signed enrollment token
- Windows username/domain/device bilgisi
- Online MFA doğrulaması
- Network kesintisi için açıkça tanımlı fail-open/fail-closed policy
- Offline recovery codes
- Agent health ve version
- Login attempt audit
- Agent uninstall/tamper protection tasarımı

Fail-open varsayılan olmamalı; müşteri politikası ve risk uyarısıyla seçilmelidir.

---

## 8. RADIUS, ACCOUNTING, 802.1X VE NAC

### 8.1 RADIUS servis yönetimi

- Auth portu 1812
- Accounting portu 1813
- RadSec/TLS desteği
- NAS/client allowlist
- Shared secret rotation
- Message-Authenticator doğrulaması
- Replay ve malformed packet koruması
- Primary/secondary node hazırlığı
- Health, latency ve request rate metrikleri

### 8.2 RADIUS cevapları

Destekle:

- Access-Accept
- Access-Reject
- Access-Challenge
- Accounting-Response
- CoA-Request/Ack/Nak
- Disconnect-Request/Ack/Nak

Vendor VSA ve standart attribute mapping adapter/policy katmanında olmalıdır.

### 8.3 Accounting

Start, Interim-Update ve Stop kayıtları idempotent işlenmelidir. `Acct-Session-Id`, NAS, username ve zaman ana korelasyon alanlarıdır.

İzlenecek alanlar:

- Username
- NAS-IP/NAS-Identifier
- Calling/Called-Station-Id
- Framed-IP
- Acct-Session-Id
- Session-Time
- Input/Output-Octets ve Gigawords
- Terminate-Cause
- Start/Interim/Stop zamanı

### 8.4 802.1X Enterprise

- EAP-PEAP
- EAP-TTLS
- Sertifika tabanlı EAP için genişletilebilir mimari
- LDAP/AD/lokal kimlik kaynağı
- Kullanıcı/grup/VLAN mapping
- Dinamik VLAN
- Karantina VLAN
- Failed auth politikası
- Certificate ve CA yönetimi
- EAP auth logları

### 8.5 MAB ve NAC

- MAC normalizasyonu
- Printer, kamera, POS ve IoT sınıfları
- Manuel ve CSV import
- Vendor/OUI keşfi
- Profil ve VLAN atama
- Expiry
- Son görülme
- Karantina
- CoA ile policy değişimi
- Switch port/NAS ilişkisi

### 8.6 RADIUS frontend

Dashboard:

- Request/success/reject/challenge oranı
- Ortalama/p95 latency
- Aktif accounting session
- NAS health
- En çok hata alan kullanıcı/NAS

Sekmeler:

- Servis ayarları
- NAS istemcileri
- Authentication logları
- Accounting
- VLAN'lar
- EAP kuralları
- MAB
- Sertifikalar
- CoA/Disconnect test aracı

---

## 9. SYSLOG, HIZLI ARAMA VE İKİ YILLIK SAKLAMA

### 9.1 Veri katmanları

PostgreSQL yüksek hacimli ham syslog arama motoru olarak kullanılmamalıdır.

Önerilen yapı:

```text
UDP/TCP/TLS Syslog Receiver
→ Durable queue / stream
→ Vendor parser + normalizer
→ Trigger engine
→ ClickHouse hot/warm searchable store
→ Daily immutable Zstandard archive in MinIO
→ Hash chain + signature catalog in PostgreSQL
```

Redis yalnızca cache, distributed lock, rate limit ve kısa süreli stream için kullanılmalıdır; kalıcı log deposu değildir.

### 9.2 Retention

- Varsayılan minimum saklama: 730 gün
- Tenant policy daha uzun süre belirleyebilir
- Legal hold varsa silme yok
- İmzalanmamış veya korelasyonu tamamlanmamış dönem purge edilemez
- Retention worker dry-run ve rapor üretmelidir
- Silme olayı audit edilmelidir
- Archive object lock/immutability desteklenmelidir

Örnek tier:

- 0–90 gün hot searchable
- 91–365 gün warm compressed
- 366–730+ gün cold compressed/searchable archive

Kesin süreler yapılandırılabilir, ancak 730 gün altına UI veya API ile düşürülemez.

### 9.3 Sıkıştırma

- Günlük immutable arşiv için `JSONL.zst` veya kolonlu format değerlendir
- Zstandard seviye ve dictionary benchmark ile seçilmeli
- Arşiv metadata: codec, uncompressed/compressed size, record count, min/max time, schema version
- Aynı canonical content aynı hash'i üretmelidir
- Sıkıştırılmış byte hash'i ile canonical content hash ayrımı açıkça modellenmelidir

### 9.4 Normalize log şeması

- event_time, ingest_time
- tenant/customer/location/device
- vendor/product/firmware
- facility/severity/event_type/action
- src/dst IP ve port
- protocol/service
- username/MAC/hostname
- application/category/domain/URL
- policy/rule/interface/VLAN/VDOM
- bytes sent/received, duration
- NAT alanları
- raw message ve parser version
- correlation/session ID

### 9.5 Hızlı arama API'si

Filtreler:

- Zaman aralığı
- Tenant/customer/location/device
- Source/destination IP/CIDR
- MAC, kullanıcı, hostname
- Domain/URL/application/category
- Action, severity, facility, event type
- Policy/interface/VLAN
- Serbest metin

Özellikler:

- Cursor pagination
- Stabil sort
- Saved search
- Shareable query
- Streaming CSV export
- Async büyük export
- Histogram/facet aggregation
- Query timeout ve maliyet sınırı
- Arama audit'i
- Maskeli hassas alanlar

### 9.6 ClickHouse tasarımı

- Partition tenant + ay/gün hacim benchmark'ına göre seçilmeli
- `ORDER BY` zaman ve sık filtrelenen alanlarla tasarlanmalı
- LowCardinality uygun alanlarda kullanılmalı
- TTL tiering ve compression codec ayarlanmalı
- Materialized view ile saatlik/günlük özetler
- Duplicate ingest için event fingerprint/dedup stratejisi
- Schema evolution/versioning
- Backup/restore testi

### 9.7 Log arama frontend'i

- Üstte fill-in-order veya gelişmiş filtre oluşturucu
- Canlı/pause modu
- Kolon seçici ve kaydetme
- Highlight
- Expandable raw/normalized detay
- Zaman histogramı
- Facet paneli
- CSV/PDF/export
- Saved searches
- Arşiv tier göstergesi
- Sorgu süresi ve taranan kayıt bilgisi

---

## 10. 5651 ARŞİV, HASH, İMZA VE DOĞRULAMA

### 10.1 Günlük arşiv

Her tenant/customer/device veya belirlenen güvenli partition için günlük arşiv oluştur:

- Dönem başlangıç/bitiş UTC
- Record count
- Canonical serialization
- Compression
- Content hash
- Previous hash
- Current chain hash
- Object reference
- İmza yöntemi ve sertifika bilgisi
- Worker/job correlation ID

### 10.2 İmza yöntemleri

- Self/local certificate
- PKCS#11/HSM
- KamuSM entegrasyonuna uygun provider interface

İmza provider adapter olmalıdır. Private key uygulama loguna, DB'ye veya frontend'e çıkmamalıdır.

### 10.3 Doğrulama

Doğrulama şu kontrolleri ayrı ayrı göstermelidir:

- Object mevcut mu
- Object byte hash doğru mu
- Canonical content hash doğru mu
- Chain linkage doğru mu
- Sequence boşluğu var mı
- Signature cryptographically valid mi
- Certificate geçerli/revoked mı
- Timestamp doğrulanabiliyor mu

Sonuç sadece boolean olmamalı; ayrıntılı verify report üretilmelidir.

### 10.4 Arşiv ekranı

- Gün/cihaz/müşteri/type filtresi
- Dosya boyutu ve kayıt sayısı
- İmzalı/bekliyor/hatalı durumu
- İndir
- Doğrula
- Verify report
- Zincir bütünlüğü
- Retention expiry
- Legal hold
- Yeniden imza isteği (mevcut hash'i değiştirmeden yeni signature event)

---

## 11. TRIGGER, ALARM VE BİLDİRİM

Trigger pipeline:

```text
Log ingest
→ Parser
→ Filter/rule evaluation
→ Match aggregation/cooldown
→ Incident/event
→ SMS/email/webhook notification
→ Acknowledge/resolve
```

Kural alanları:

- İsim/açıklama
- Scope
- Severity
- Filter DSL veya güvenli regex
- Threshold ve time window
- Cooldown/dedup
- Kanal
- Recipient/escalation
- Aktif zaman takvimi
- Hazır şablon veya özel kural

UI:

- Alarm dashboard
- Severity KPI
- Timeline
- Açık/onaylandı/çözüldü durumları
- Owner atama
- Related logs
- Notification delivery sonucu
- Test trigger

Regex catastrophic backtracking ve tenant kaynak tüketimi sınırlandırılmalıdır.

---

## 12. RAPORLAMA VE ANALİTİK

Kategoriler:

- Bandwidth
- Duration
- Security/IPS/Threat
- User
- Application
- Web/domain
- DNS
- DLP
- System health
- Authentication/MFA
- Hotspot/session
- RADIUS/accounting
- 5651 compliance

Özellikler:

- Tarih/scope/filter
- Drill-down
- Grafik + tablo
- CSV/PDF
- Büyük export background job
- Günlük/haftalık/aylık zamanlama
- E-posta alıcıları
- Retry ve delivery log
- Tenant timezone
- Arşivlenmiş rapor

200 adet kopya ekran üretme. Template catalog ve parametrik report engine kullan.

---

## 13. DASHBOARD VE OPERASYONEL GÖZLEMLENEBİLİRLİK

Dashboard gerçek backend aggregation kullanmalı; mock yasaktır.

KPI:

- Toplam/online hotspot kullanıcı
- Aktif VPN MFA oturumu
- Aktif cihaz ve offline cihaz
- Son 24 saat auth success/reject
- Syslog EPS ve günlük log sayısı
- ClickHouse/MinIO kullanım
- 5651 imza bekleyen/hatalı gün
- CPU/RAM/disk
- Lisans ve kota

Grafikler:

- Login success/failure trend
- Syslog ingest trend
- Traffic throughput
- Browser/OS/device distribution
- Vendor/device health
- Alarm severity

Servis health:

- API
- Worker/beat
- Redis
- PostgreSQL
- ClickHouse
- MinIO
- RADIUS
- Syslog receiver
- SMS/SMTP provider

---

## 14. FRONTEND KALİTE STANDARDI

- React + TypeScript strict
- Mevcut tasarım sistemi korunur ve ortaklaştırılır
- Responsive desktop/tablet/mobile
- Light/dark
- Türkçe doğru UTF-8; mojibake kabul edilmez
- Erişilebilir label, focus, keyboard ve kontrast
- Loading skeleton
- Empty state
- Retryable error state
- Permission denied state
- Form validation
- Unsaved changes warning
- Destructive confirmation
- Toast ve inline feedback
- Tablo filtre/sort/pagination/column visibility
- URL ile senkron filtreler
- Büyük tabloda virtualization veya server pagination
- Secret alanlarında güvenli davranış

Hiçbir sayfada `mockData`, sahte başarı, çalışmayan buton, `Coming Soon` veya boş placeholder bırakma.

---

## 15. BACKEND API STANDARDI

### 15.1 Liste endpoint'leri

```json
{
  "items": [],
  "total": 0,
  "next_cursor": null,
  "filters": {}
}
```

- Limit üst sınırı
- Cursor veya tutarlı offset pagination
- Scope enforcement
- Explicit filter schema
- Stable ordering
- Export için ayrı async akış

### 15.2 Hata modeli

```json
{
  "code": "DEVICE_API_AUTH_FAILED",
  "message": "Cihaz API doğrulaması başarısız.",
  "correlation_id": "...",
  "details": {}
}
```

Secret ve stack trace client'a dönmemelidir.

### 15.3 Uzun işler

Archive, report, backup, device discover, config push ve bulk import job olarak çalışmalıdır:

- queued/running/succeeded/failed/cancelled
- progress
- started/finished
- retry count
- error code
- actor/scope
- idempotency key

---

## 16. VERİ MODELİ ASGARİ KATALOĞU

Mevcut modellere uyumlu biçimde gereken domain varlıklarını sağla:

- Tenant, Partner, Customer, Location, License
- AdminUser, Role, Permission, AuditEvent
- Device, DeviceCredential, DeviceCapability, DeviceHealth, ConfigBackup
- PortalTemplate, PortalVersion, PortalAssignment, PortalLanguage
- AuthMethodConfig, SmsProvider, SmtpProfile, LdapSource, PmsConnector
- GuestUser, UserGroup, AccessPolicy
- GuestSession, SessionAccounting, IdentityVerification
- WhitelistRule, BlacklistRule, ApprovalRequest
- VoucherBatch, Voucher, MeetingCode
- RadiusClient, RadiusAuthEvent, RadiusAccountingEvent
- VlanPolicy, EapRule, MabDevice, CertificateProfile
- MfaUser, MfaPolicy, MfaChallenge, MfaAttempt, TotpEnrollment, RecoveryCode, TrustedDevice
- SyslogRecord/search-store schema, SyslogTrigger, TriggerEvent, Incident
- ArchiveRecord, ArchiveSignature, VerificationReport, LegalHold, RetentionPolicy
- ReportTemplate, ReportJob, ReportArchive
- WorkerJob, NotificationDelivery

Tablo isimleri ve mevcut modellerle çakışma yaratma. Yeni tablo gerekiyorsa migration ve rollback etkisini açıkla.

---

## 17. BACKGROUND JOB KATALOĞU

- OTP send/retry
- LDAP/AD sync
- Device health check
- Device discovery
- Active session reconciliation
- RADIUS accounting correlation
- Session expiration
- Quota enforcement
- Syslog normalize/index
- Trigger evaluation/notification
- Daily 5651 archive
- Archive signing
- Archive verification sampling
- ClickHouse aggregation
- Retention dry-run/purge
- Report generation/delivery
- Config backup
- Backup verification
- License enforcement

Her job distributed lock, retry/backoff, idempotency, metrics ve audit ihtiyacına göre tasarlanmalıdır.

---

## 18. GÜVENLİK GEREKSİNİMLERİ

- JWT/session rotation ve logout invalidation
- MFA admin hesapları
- RBAC backend enforcement
- CSRF/XSS/SSRF/SQL injection kontrolleri
- Upload MIME/size/virus scanning tasarımı
- Rate limit
- Brute-force ve credential stuffing koruması
- OTP abuse/maliyet koruması
- Secure headers ve CSP
- TLS doğrulaması varsayılan açık
- RadSec tercih seçeneği
- RADIUS Message-Authenticator
- Secret encryption ve rotation
- Audit log bütünlüğü
- Backup encryption
- Tenant IDOR testleri
- Dependency ve container vulnerability taraması

`verify_tls=False`, fail-open veya zayıf fallback yalnızca açık risk uyarısı ve audit ile kullanılabilir.

---

## 19. TEST STRATEJİSİ

### 19.1 Unit

- Policy evaluation
- OTP TTL/replay/rate limit
- RADIUS attribute mapping
- Vendor parser
- Hash chain
- Canonical serialization
- Retention gate
- Permission/scope

### 19.2 Integration

- PostgreSQL/Redis/MinIO/ClickHouse
- RADIUS Access-Accept/Reject/Challenge
- Accounting idempotency
- Syslog ingest → search
- Archive build → upload → verify
- SMS/SMTP fake provider
- LDAP fake/test directory
- Firewall adapter fake server

### 19.3 End-to-end

- Captive portal SMS login → authorize → online → revoke
- Voucher login
- Whitelist MAC bypass
- Blacklisted user deny
- Admin approval
- VPN username/password → OTP → RADIUS accept
- Wrong/expired/replayed OTP reject
- Online user disconnect
- 5651 archive and verify
- Log search and export
- Cross-tenant access denial

### 19.4 Failure tests

- Firewall offline
- SMS timeout
- SMTP rejection
- LDAP unavailable
- Duplicate accounting packet
- Worker restart
- MinIO unavailable
- ClickHouse slow query
- Invalid signature
- Broken hash chain
- Clock skew

---

## 20. DEVOPS VE DAĞITIM

Compose/production topology şunları kapsamalıdır:

- API
- Admin
- Portal
- PostgreSQL
- Redis
- MinIO
- ClickHouse
- Worker
- Beat/scheduler
- RADIUS service
- Syslog receiver
- Opsiyonel site bridge

Gereksinimler:

- Healthcheck
- Persistent volume
- Resource limit önerisi
- Secret/env ayrımı
- Migration job
- Backup/restore
- Log rotation
- Metrics endpoint
- Graceful shutdown
- UTC internal time, tenant timezone presentation
- Upgrade ve rollback prosedürü

On-prem kurulum internetsiz çalışabilmelidir; SMS/e-posta gibi harici servisler hariç çekirdek ürün cloud bağımlılığı taşımamalıdır.

---

## 21. FAZLAR VE BAĞIMLILIK SIRASI

### Faz 0 — Gerçek durum denetimi

Envanter, gap analizi, risk ve uygulanabilir backlog.

### Faz 1 — Temel bütünlük

UTF-8 düzeltmeleri, gerçek routing, RBAC, ortak API/pagination/error modeli, mock temizliği.

### Faz 2 — Firewall capability ve onboarding

Adapter capability, cihaz sihirbazı, health/test ve vendor reçeteleri.

### Faz 3 — Hotspot kullanıcı domaini

Guest users, user groups, online, whitelist, blacklist, manual users, approval.

### Faz 4 — Captive portal entegrasyonu

Signed context, auth methods, authorize/revoke, accounting ve reconciliation.

### Faz 5 — RADIUS/802.1X/NAC

NAS, auth, accounting, CoA, VLAN, EAP, MAB ve karantina.

### Faz 6 — VPN ve Windows MFA

Identity source, OTP policy, RADIUS challenge, MFA users/logs ve Windows agent contract.

### Faz 7 — Log veri platformu

Syslog collector, queue, parser, ClickHouse, hızlı arama, zstd arşiv ve 730 gün retention.

### Faz 8 — 5651 ve imza

Tüm gerekli kaynakların günlük arşivi, hash zinciri, signing provider ve verify report.

### Faz 9 — Trigger ve raporlama

Incident lifecycle, notification delivery, report engine ve scheduler.

### Faz 10 — Operasyon ve hardening

Dashboard, health, backup, security test, performance test, docs ve release.

Her faz deploy edilebilir ve geri alınabilir olmalıdır.

---

## 22. PERFORMANS HEDEFLERİ

Benchmark ortamı ve veri hacmi raporlanmak şartıyla hedefler:

- Admin normal API p95 < 500 ms
- Hot log search p95 < 2 s
- Dashboard p95 < 2 s
- OTP request kabulü < 500 ms; provider teslimi ayrı ölçülür
- RADIUS auth platform overhead p95 < 500 ms, harici LDAP/SMS hariç ayrı metriklenir
- Syslog ingest kayıpsız ve backpressure kontrollü
- 10 milyon+ kayıt aramasında pagination/export memory-safe
- Worker restart sonrası job kaybı yok

Hedefe ulaşılamazsa ölçüm, darboğaz ve iyileştirme planı yazılmalıdır.

---

## 23. KABUL KRİTERLERİ

Ürün tamamlandı denebilmesi için:

- Tüm ekranlar gerçek API ile çalışıyor.
- Mock ve çalışmayan buton yok.
- Tenant IDOR testleri geçiyor.
- En az bir FortiGate benzeri adapter akışı uçtan uca fake/integration ortamında kanıtlanmış.
- Captive portal login, authorize, online ve disconnect zinciri çalışıyor.
- Manuel kullanıcı, grup, whitelist, blacklist ve approval çalışıyor.
- VPN MFA SMS/e-posta/TOTP policy ile RADIUS accept/reject üretiyor.
- Accounting start/interim/stop korelasyonu çalışıyor.
- RADIUS/802.1X yapılandırma ekranları gerçek backend'e bağlı.
- Syslog ingest sonrası hızlı aranabiliyor.
- 730 günlük retention altına düşürülemiyor.
- Günlük sıkıştırılmış arşiv, hash zinciri ve doğrulama çalışıyor.
- Trigger notification delivery sonucu izleniyor.
- Rapor scheduler çıktı üretip arşivliyor.
- Build, migration ve testler temiz.
- Kurulum, upgrade, rollback ve vendor rehberleri mevcut.

---

## 24. HER FAZ SONUNDA ZORUNLU RAPOR

Şu formatta teslim et:

```markdown
## Sonuç
Tamamlanan kullanıcı değeri.

## Değişiklikler
- Backend
- Frontend
- Worker/adapter
- Migration
- Dokümantasyon

## Doğrulama
- Çalıştırılan test/build
- Sonuç
- Ölçülen performans

## Güvenlik
- Scope/RBAC
- Secret/audit
- Yeni risk

## Kalanlar
- Sonraki faz
- Bilinen sınırlama
```

Dosya sayısı değil, çalışan kullanıcı akışı raporlanmalıdır.

---

## 25. YASAKLAR

- Sadece UI maketi yapma.
- Backend olmadan sahte başarı üretme.
- PostgreSQL'i sınırsız syslog full-text motoru gibi kullanma.
- Vendor kodunu adapter dışına saçma.
- Tenant scope'u frontend'e bırakma.
- OTP'yi düz metin saklama.
- Secret'ı API ile geri döndürme.
- 5651/arşiv/audit kayıtlarını güncelleme veya hard delete etme.
- İmza doğrulamasını yalnızca DB'deki boolean alana güvenerek yapma.
- Firewall başarılı demeden kullanıcıyı online gösterme.
- RADIUS accounting duplicate paketlerini çoğaltma.
- Fail-open davranışını gizleme.
- Testleri atlayıp tamamlandı deme.
- Kullanıcının ilgisiz değişikliklerini silme.

---

## 26. İLK ÇALIŞTIRMA KOMUTU

Bu master prompt sana verildiğinde ilk cevabın genel tavsiye olmamalıdır. Şunları yap:

1. Repo envanterini çıkar.
2. Mevcut uygulama ile bu prompt arasındaki gap tablosunu üret.
3. En yüksek riskli mimari kararları doğrula.
4. Faz 0 planını oluştur.
5. Güvenli, küçük ve yüksek değerli ilk uygulama dilimini seç.
6. Uygula, test et ve raporla.
7. Açıkça engellenmedikçe yalnızca plan yazıp durma.

Öncelikli ilk dikey dilim önerisi:

```text
Firewall capability + onboarding
→ Hotspot user group/manual user
→ Captive portal authorize
→ Online session
→ Admin disconnect
→ Accounting/audit
```

Ardından:

```text
VPN MFA user
→ LDAP/local primary auth
→ SMS/email/TOTP challenge
→ RADIUS accept/reject
→ MFA audit
```

Son olarak log veri platformu ve 5651 arşiv zincirini genişlet.

Bu proje bir ekran koleksiyonu değil; cihazdan kimliğe, kimlikten yetkiye, yetkiden oturuma, oturumdan log ve yasal arşive kadar doğrulanabilir bir güven zinciridir.

