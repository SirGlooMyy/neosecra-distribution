# Kalan İşler ve Uygulama Sırası

## Bilinen başlangıç durumu — mutlaka yeniden doğrula

Bu bilgi yalnızca başlangıç ipucudur, kanıt değildir:

- Beklenen çalışma branch'i: `feature/hotspot-mvp-readiness`
- Voucher dikey dilimi daha önce doğrulanmış görünüyor.
- Bilinen voucher commitleri: `dd1013a`, `025f306`, `36e4adc`, `ec7f50d`.
- FortiGate dilimi kısmi doğrulanmış görünüyor.
- Bilinen FortiGate commitleri: `7c141ff`, `dd00efb`.
- Son güvenilir FortiGate tablosunda browser E2E yazılmış fakat çalıştırılmamıştı.
- Backend tam regresyonda 403 testten 388 passed, 8 failed, 8 skipped raporlanmıştı.
- Voucher integration testlerinde rate-limit kaynaklı 8 hata görülmüştü.
- Simulator integration testlerinde 8 skip görülmüştü.
- Global dashboard'un eski kaldığı kullanıcı tarafından özellikle belirtilmişti.

HEAD ve repo içeriği farklıysa güncel gerçekliği kullan.

## Faz 0 — Baseline ve envanter

- Repo talimatlarını (`AGENTS.md`, README, compose/env örnekleri, CI) bul.
- Backend, admin, portal, worker, DB, Redis, RADIUS ve simulator servislerini haritala.
- Endpoint, model, migration ve frontend route envanteri çıkar.
- Bozuk/skip testleri isim ve kök neden bazında sınıflandır.
- Temiz kurulum komutunu doğrula; migration head ve servis health durumunu kaydet.

## Faz 1 — Voucher koruma regresyonu

- Voucher verify → consent → session akışını gerçek backend ve DB ile çalıştır.
- Paralel submit idempotency, tek voucher/tek session, tenant/location izolasyonu ve Redis kesintisini doğrula.
- Portal browser ve admin session browser testlerini gerçek API ile çalıştır.
- Daha önce yeşil olan akışı bozan rate-limit/test izolasyonu problemini düzelt.

## Faz 2 — FortiGate authorization lifecycle

- Cihaz CRUD, bağlantı testi ve yetkilendirme aksiyonlarının gerçek backend'e bağlı olduğunu doğrula.
- HTTP simulator başarı, timeout, auth failure, malformed response ve unreachable senaryolarını sağlamalı.
- Authorization durumu DB'de `pending/success/failed/revoked` benzeri açık bir lifecycle ile kalıcı olmalı.
- Tekrarlı istekler idempotent ve tenant/location scoped olmalı.
- Devices ve Sessions UI aksiyonları loading/success/error durumlarını göstermeli; destructive işlem confirmation istemeli.
- Playwright testi mock kullanmadan UI → backend → simulator → DB zincirini doğrulamalı.
- Gerçek FortiGate erişimi varsa ayrı `REAL_DEVICE_VERIFIED` kanıtı üret; yoksa simulator sonucunu açıkça `SIMULATOR_VERIFIED` yaz.

## Faz 3 — SMS doğrulama

- Provider adapter arayüzü, timeout/retry ve güvenli hata haritalaması oluştur/doğrula.
- OTP üretimi güçlü, hash'li, süreli, tek kullanımlık ve deneme limitli olmalı.
- Replay, brute force, paralel submit, tenant izolasyonu ve provider kesintisi test edilmeli.
- Portal browser akışı gerçek backend ile doğrulanmalı.
- Gerçek provider credential yoksa local simulator ile integration kapısını kapat; gerçek provider kapısını `EXTERNAL_BLOCKED` bırak.

## Faz 4 — RADIUS / FreeRADIUS

- PAP/CHAP veya projenin desteklediği auth yöntemlerini açıkça belgeleyip doğrula.
- Access-Accept, Access-Reject, accounting start/interim/stop ve duplicate packet idempotency testleri yaz/çalıştır.
- Session DB kayıtları ile RADIUS accounting tutarlı olmalı.
- NAS/tenant/location isolation, shared-secret yönetimi ve hatalı paket davranışı doğrulanmalı.
- Container tabanlı gerçek FreeRADIUS integration tercih edilir; yalnız unit mock yeterli değildir.

## Faz 5 — 5651 ve delil bütünlüğü

- Ham erişim kayıtları değiştirilemez/audit edilebilir biçimde saklanmalı.
- Hash chain veya eşdeğer bütünlük mekanizması; export sonrası doğrulama aracı olmalı.
- Saat kaynağı/timezone, saklama politikası, maskeleme ve yetkili erişim açık olmalı.
- Log değişikliği/tahrifi negatif testle tespit edilmeli.
- Harici zaman damgası/imza servisi yoksa bu kısım `EXTERNAL_BLOCKED`; kriptografik bütünlük simülasyonu gerçek yasal damga diye sunulamaz.
- Hukuki uygunluk iddiası yalnız teknik uygulamayla verilmemeli; nihai hukuk incelemesi açık risk olmalı.

## Faz 6 — Global dashboard

- Eski dashboard'u gerçek operasyon verisine bağla.
- En azından tenant/location filtreli şu metrikleri sağla: aktif session, bugün doğrulanan kullanıcı, başarısız doğrulama, cihaz health, authorization failure, SMS failure, RADIUS reject, log pipeline durumu.
- Kart → detay/drill-down bağlantıları çalışmalı.
- Loading, empty, partial failure ve permission-denied durumları tasarlanmalı.
- Global admin ile tenant admin görünümü server-side RBAC ile ayrılmalı.
- Responsive davranış ve temel erişilebilirlik test edilmeli.
- Dashboard Playwright testleri gerçek backend fixture'larıyla çalışmalı; statik sayı veya mock API yasaktır.

## Faz 7 — Güvenlik ve operasyon

- Authentication/session/cookie/CORS/CSRF yaklaşımını incele ve kritik açıkları kapat.
- RBAC matrisi, IDOR, cross-tenant ve cross-location testlerini bütün kritik endpointlere uygula.
- Audit loglarda actor, action, target, tenant, timestamp, result ve correlation ID bulunmalı.
- Secret ve PII log sızıntısı taraması yap.
- Rate limit fail-open/fail-closed kararlarını endpoint riskine göre uygula ve Redis outage testleri yaz.
- Health/readiness, structured logging, migration rollback ve backup/restore runbooklarını doğrula.

## Faz 8 — Release kapısı

- Sıfırdan compose build/up ve migration çalıştır.
- Backend full suite, admin/portal unit testleri, lint/typecheck/build ve bütün gerçek-backend Playwright suitelerini çalıştır.
- Testleri en az bir kez temiz DB ile çalıştır.
- Kritik/High açık, başarısız zorunlu test veya açıklanmamış skip varsa MVP verified verme.
- Release tag önerisi, rollback ve bilinen risklerle final raporu oluştur.
