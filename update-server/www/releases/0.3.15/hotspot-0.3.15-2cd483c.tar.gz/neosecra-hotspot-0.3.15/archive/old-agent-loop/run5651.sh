#!/bin/sh
cd /home/sirgloomy/projects/Hotspot/backend
PYTHONPATH=/home/sirgloomy/projects/Hotspot/backend python3 run_5651_tests.py
