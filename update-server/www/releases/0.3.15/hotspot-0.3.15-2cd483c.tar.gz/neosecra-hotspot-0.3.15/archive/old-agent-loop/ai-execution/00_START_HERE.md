# Hotspot MVP — AI Çalıştırma Paketi

Bu klasörü Hotspot projesinin kök dizinine `.ai-execution/` adıyla kopyala.

AI ajana yalnızca aşağıdaki metni ver:

> Bu repoda `.ai-execution/01_MASTER_PROMPT.md` dosyasını aç ve eksiksiz uygula. Diğer `.ai-execution/*.md` dosyaları bağlayıcı çalışma sözleşmesidir. Benden ara onay istemeden güvenli ve geri alınabilir işlemlerle ilerle. Her aşamada checkpoint ve kanıt üret. Başarısız, atlanmış veya çalıştırılmamış hiçbir testi başarılı gösterme. İş bitince yalnızca `.ai-execution/reports/FINAL_MVP_REPORT.md` dosyasının yolunu, nihai verdict'i ve commit hash'lerini bildir.

Bu görev terminal bir görevdir: bütün erişilebilir proje işleri ve blocker kabul kapıları tamamlanana kadar durma. Bir slice, sprint, commit veya test grubundan sonra cevap verme; otomatik olarak sıradaki eksik faza geç. Bağlam kesilirse `04_CHECKPOINT.md` üzerinden devam et.

## Beklenen çıktı

Ajansal çalışma sonunda şu dosya oluşmalıdır:

`/.ai-execution/reports/FINAL_MVP_REPORT.md`

Çalışma yarıda kesilirse yeni ajan aynı başlangıç cümlesiyle devam eder; ajan `04_CHECKPOINT.md` dosyasından kaldığı yeri bulur.

## Önemli

“%100” yalnızca `03_ACCEPTANCE_GATES.md` içindeki tüm zorunlu kapılar gerçek kanıtla geçtiğinde kullanılabilir. Harici FortiGate, SMS sağlayıcısı veya mevzuat/zaman damgası servisi yoksa ilgili sonuç `EXTERNAL_BLOCKED` olur; simülatör sonucu gerçek cihaz/sağlayıcı sonucu diye sunulamaz.
