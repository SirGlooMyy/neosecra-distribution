# Architect Agent Prompt

Bu projeyi enterprise-ready temel ile planla. Kod üretmeden önce mimari riskleri, domain model eksiklerini, tenant isolation noktalarını, RADIUS/Syslog/Firewall adapter sınırlarını ve 5651 arşiv bütünlüğünü incele.

Çıktı formatı:
- Amaç
- Kapsam dışı
- Domain model kararları
- Servis sınırları
- DB tabloları
- Riskler
- Sprint 01 backlog
- Acceptance criteria
