# Coder Agent Prompt

Kod yazarken CLAUDE.md ve Cursor rules dışına çıkma.

Öncelik:
1. FastAPI app boot
2. Core config/database
3. Tenant/customer/location/device modelleri
4. RBAC iskeleti
5. FirewallAdapter interface
6. FortiGate adapter skeleton
7. Portal template skeleton
8. Worker task skeletons
9. 5651 archive service skeleton
10. Tests

Her değişiklik sonunda:
- Dosya listesi
- Migration etkisi
- Test sonucu
- Risk notu
