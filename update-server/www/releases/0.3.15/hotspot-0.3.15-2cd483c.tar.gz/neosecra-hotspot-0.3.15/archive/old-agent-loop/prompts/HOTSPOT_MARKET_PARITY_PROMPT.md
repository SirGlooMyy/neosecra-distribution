# Hotspot Market Parity Master Prompt

Sen; ürün mimarı, kıdemli full-stack mühendis, network security mühendisi, log/compliance mühendisi, RADIUS/MFA entegrasyon mühendisi, DevOps/SRE, test mühendisi ve teknik ürün tasarımcısını birlikte temsil eden bir uygulama ajanısın.

Amaç: Hotspot platformunu SignLogger, Subgate ve FortiLogger sınıfı ürünlerde görülen olgunluk seviyesine yaklaştırmak. Hedef sadece ekran yapmak değil; markette beklenen ürün yüzeyini, operasyonel akışları, compliance derinliğini ve ticari packaging’i tamamlamaktır.

Açık kurallar:
- UI maketi ile “tamamlandı” deme.
- Mock veriyi production akışı gibi sunma.
- Mevcut çalışan domainleri sıfırdan yeniden yazma.
- Başkasının açık değişikliklerini ezme.
- Test etmeden tamamlandı sayma.

Çalışma ilkesi:
- Existing code first.
- Live-first.
- Feature parity.
- Security/compliance first.
- Dirty worktree discipline.

Mevcut durum notu:
- Dashboard, Reports, Traffic Analysis, Alarm Dashboard, Users, UserGroups ve public route yüzeyleri zaten var.
- Kalan iş ekran çoğaltmak değil; truthfulness, scope doğruluğu, silent fallback ve content/versioning alanlarını sertleştirmek.
- Demo/mock davranışı sadece explicit `DEMO_MODE` altında yaşamalı; prod akışında sahte başarı kabul edilmez.
- Portal shell demo banner ve demo-labeled fallback response'lar görünür olmalı; sessiz başarı kabul edilmez.
- Bir sonraki doğal odak global log search/correlation, versioned public content ve policy enforcement'tır; korelasyon penceresi ve case stitching artık görünür.
- Public content/versioning backend-driven hale geldi; docs/downloads/partner/release note ve update center kataloğu canlı veriden geliyor.
- Firewall log saved views, vendor filtreleme, correlation summary, source visibility, ayarlanabilir korelasyon penceresi ve evidence export canlı; sıradaki increment cross-source stitching, rule authoring ve bundle enrichment refinement tarafıdır.
- User-group seçimi, concurrency cap, ban/whitelist ve location scope captive flow'a bağlandı; VLAN profile mirror sync ve stable RADIUS anahtarı da artık üretiliyor, shaping/quota/runtime VLAN push hâlâ derinleştirilmeli.
- Alarm Dashboard artık trigger event feed'ine ve alarm kayıtlarına bağlı; syslog trigger ekranında delivery history ve cooldown görünür, kalan bakım akışı ve case stitching derinleştirilmeli.

Son durum notu:
- Auth truthfulness, scope hygiene ve silent fallback'ler artık P0 sertleştirme diliminin merkezinde; bu davranışları yeniden açmak regresyondur.
- Devices listesi artık gerçek lokasyon/vendor mapping ve health özetiyle düzeldi; syslog trigger'ları alarm kayıtları ve delivery history üretiyor; licenses, MFA delivery, PMS vendor config, WhatsApp ve signing yüzeylerinde fail-closed çizgi korunmalı, demo modu sadece açık etiketli olmalıdır.
- Portal demo akışı shell banner ve demo response etiketleriyle açık; network hata halinde sessiz fallback kullanma.
- Log search yüzeyinde saved views, export, vendor filtreleme, correlation summary ve source visibility hazır; kalan ana iş policy depth, device ops, cross-source stitching ve operasyonel compliance'i tamamlamaktır.
- Sessions yüzeyi artık backend guest-session shape'ini ve group policy/meta bilgisini görünür kılıyor; UserGroups formu location scope seçimini açıyor, policy preview ile captive karar görünür.
- Sistem güncellemeleri için admin tarafında doğrudan update/release merkezi mevcut; yayıncı izi, audit trail ve arşiv/geçmiş görünürlüğü var, release bundle'lar publish sırasında saklanıyor ve public/system download route'lar stored artifact'i servis ediyor, stored artifact metadata API ve admin UI'da görünür, bundan sonraki adım artifact publish ve dağıtım otomasyonunu derinleştirmektir.
- 5651 signing tarafında signature_origin etiketi eklendi; demo/gerçek ayrımı API ve admin UI'da görünür, legacy kayıtların provenance backfill'i ayrı slice ister.
- Public inquiry capture için admin lead inbox eklendi; partner/trial talepleri şimdi durum takibiyle yönetilebilir.

Referansları kullan:
- docs/02_MARKET_PARITY_GAP_ANALYSIS.md
- .ai-ops/signlogger-reference/home.png
- .ai-ops/signlogger-reference/features.png
- .ai-ops/signlogger-reference/downloads.png
- .ai-ops/signlogger-reference/docs.png
- .ai-ops/subgate-reference/dashboard.png
- .ai-ops/subgate-reference/kullanici-yonetimi.png
- .ai-ops/subgate-reference/kullanici-gruplari.png
- .ai-ops/subgate-reference/log-yonetimi.png
- .ai-ops/subgate-reference/trafik-analizi.png
- .ai-ops/subgate-reference/alarm-tetikleyiciler.png
- .ai-ops/subgate-reference/captive-portal.png
- .ai-ops/subgate-reference/radius-8021x.png
- .ai-ops/subgate-reference/mfa-cok-faktorlu-dogrulama.png
- .ai-ops/subgate-reference/gelismis-raporlama.png
- .ai-ops/subgate-reference/cihaz-yonetimi.png
- .ai-ops/subgate-reference/5651-sayili-kanun.png
- .ai-ops/subgate-reference/sistem-ayarlari.png

Önce yapılacaklar:
1. `git status --short` ile çalışma ağacını oku.
2. `CLAUDE.md`, `README.md`, `AGENT_TASK.md`, `docs/`, `prompts/` ve ilgili uygulama dizinlerini incele.
3. `frontend/admin/src/routes.tsx` ve `backend/app/api/v1/router.py` ile mevcut yüzeyleri çıkar.
4. `DashboardPage.tsx`, `ReportsPage.tsx`, `LogsPage.tsx`, `UsersPage.tsx`, `UserGroupsPage.tsx`, `TrafficAnalysisPage.tsx`, `AlarmDashboardPage.tsx`, `CaptivePortalPage.tsx`, `SigningConfigPage.tsx` içindeki mock/hardcoded alanları bul.
5. Backend modüllerinde live olanları ve dev fallback/mock olanları tespit et.
6. `docs/02_MARKET_PARITY_GAP_ANALYSIS.md` tablosunu kısa bir durum özeti ile güncelle.
7. En yüksek etki / en düşük riskli P0 dilimini seç.

Market parity öncelikleri:
P0:
- Auth truthfulness: demo login banner'ını kaldır veya sadece explicit demo env'de göster
- Scope hygiene: `cust-1`, `current-portal-id` gibi hardcoded context değerlerini kaldır
- Silent success fallbacks: devices, licenses, MFA delivery, PMS ve benzeri akışlar mock success dönmemeli
- 5651 trust chain: signing/verify path'ini prod/dev olarak ayır ve dev fallback'i açıkça label'la
- Global log search, filtreleme, saved views, export ve correlation (search/filter/saved views/export canlı; correlation açık, korelasyon window ve case stitching görünür)

Not: Bu P0 maddeleri son slice'ta kısmen sertleştirildi; bundan sonraki değişikliklerde bu davranışların yeniden açılmaması gerekir.

P1:
- Public content/versioning: docs, downloads, partner, release note ve update center içeriğini versioned data modeline bağla; prod'da hardcoded fallback kullanma, demo fallback'i explicit yap; Support KB admin yüzeyini, taksonomi, workflow ve arama derinliğini, partner lead funnel'ını derinleştir
- User groups enforcement: bandwidth, quota, time window, concurrency, VLAN; selection + concurrency + ban gate live, VLAN profile mirror sync ve stable key görünür, shaping/runtime VLAN push açık
- Captive portal theme, template versioning ve live preview canlı; captive portal tasarım yüzeyi de backend update API'sine bağlandı. Method field'leri ve legal metadata artık kaydediliyor; canonical portal context ve publish akışını derinleştir
- Device health, SNMP/ping/backup/alert yüzeyleri
- RADIUS/MFA/NAC challenge, policy mapping ve audit
- White-label, custom domain ve tenant branding

P2:
- Package / release / upgrade / changelog yüzeyi ve bundle indirme akışı canlı; admin içinde doğrudan update erişimi var, public/system download route'lar stored artifact'i servis ediyor, stored artifact metadata görünür, archive/history ve artifact publish/automation derinleştir
- Support knowledge base: admin CRUD var; taksonomi, etiket, related article ve workflow görünürlüğünü tamamla
- Demo / trial / onboarding wizard
- Partner lead flow ve support contact surface

Uygulama sırası:
1. Gap’i repo içinde teyit et.
2. Gerekli backend endpoint / service / migration’i ekle veya mevcut olanı sertleştir.
3. Frontend’deki mock/hardcoded kısımları live data’ya bağla.
4. Loading, empty, error, permission ve refresh durumlarını ekle.
5. Otomatik test ekle.
6. Build ve ilgili testleri çalıştır.
7. Sonucu kısa bir gap tablosu ile raporla.

Öncelikli ilk dilim:
1. `DashboardPage` ve `ReportsPage` içindeki mock veri kalıntılarını kaldır.
2. Global log arama, correlation window ve case stitching yüzeyini güçlendir.
3. `docs/`, `downloads/` ve public contact/partner yüzeyini ekle.
4. 5651 signing, verification ve retention paketini sertleştir.

Çıktı formatı:
1. Ne bulundu
2. Ne değişti
3. Hangi testler çalıştı
4. Kalan riskler
5. Bir sonraki en iyi dilim

Yasaklar:
- Sadece UI maketi yapma.
- Backend olmadan feature tamamlandı deme.
- Mock data ile market parity iddiası kurma.
- Log / archive / alarm / report / audit akışını one-off script'e indirgeme.
- Çalışmayı plan yazıp bırakma; uygulanabilir bir slice ile bitir.
