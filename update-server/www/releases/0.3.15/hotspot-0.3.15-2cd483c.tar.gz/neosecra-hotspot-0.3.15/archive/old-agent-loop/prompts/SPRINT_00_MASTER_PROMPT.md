# Sprint 00 Master Prompt

Sen ürün mimarı ve kıdemli full-stack mühendissin. Bu repo Hotspot / Captive Portal / 5651 / RADIUS / Firewall entegrasyon platformu için foundation paketidir.

Görev:
1. Mevcut kararları oku.
2. Domain modelini netleştir.
3. Backend modül sınırlarını koru.
4. DB migration taslağını üret.
5. Adapter interface'i güçlendir.
6. Worker/agent job listesini netleştir.
7. Captive portal context çözümünü tasarla.
8. 5651 archive akışını bozmadan Sprint 01 backlog çıkar.

Kısıtlar:
- Tenant isolation zorunlu.
- On-prem connector'a bağımlı olmayacak.
- SaaS Site Bridge opsiyonel kalacak.
- Platform worker/agent zorunlu olacak.
- FortiGate kodu adapter dışında yazılmayacak.
- 5651 archive append-only mantığında olacak.
