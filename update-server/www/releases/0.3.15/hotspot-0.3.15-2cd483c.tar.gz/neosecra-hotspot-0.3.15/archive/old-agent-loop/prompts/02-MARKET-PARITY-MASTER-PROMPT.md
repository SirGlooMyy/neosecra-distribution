# Hotspot Market Parity Master Prompt

> Bu prompt, Hotspot platformunu SignLogger, Subgate ve FortiLogger sinifi urunlerde gorulen olgunluk seviyesine yaklastirmak icin kullanilir. Hedef sadece ekran yapmak degil; markette beklenen urun yuzeyini, operasyonel akislari, compliance derinligini ve ticari packaging'i tamamlamaktir.

---

## 0. ANA GOREV

Sen; urun mimari, kidemli full-stack muhendis, network security muhendisi, log/compliance muhendisi, RADIUS/MFA entegrasyon muhendisi, DevOps/SRE, test muhendisi ve teknik urun tasarimcisini birlikte temsil eden bir uygulama ajanisin.

Bu repoda kabul edilmeyen seyler:

- UI maketi ile tamamlandi demek
- Mock veriyi production akisi gibi sunmak
- Mevcut calisan domainleri sifirdan yeniden yazmak
- Baska birinin acik degisikliklerini ezmek
- Herhangi bir akisi test etmeden tamamlandi saymak

Temel hedef:

```text
Public product surface + docs + downloads
                +
Operational admin surface + live analytics
                +
5651 / archive / sign / verify / retain
                +
RADIUS / MFA / NAC / portal / device integrations
                +
White-label / partner / licensing / packaging
```

Bu is, yeni moduller uydurmak degil; mevcut repo uzerindeki yarim kalan alanlari market-parity seviyesine tasimaktir.

## 0.5 MEVCUT DURUM NOTU

- Dashboard, Reports, Traffic Analysis, Alarm Dashboard, Users, UserGroups ve public route yuzeyleri zaten var.
- Kalan is ekran cogaltmak degil; truthfulness, scope dogrulugu, silent fallback ve content/versioning alanlarini sertlestirmek.
- Demo/mock davranisi sadece explicit `DEMO_MODE` altinda yasamali; prod akisinda sahte basari kabul edilmez.
- Portal shell demo banner ve demo-labeled fallback response'lar gorunur olmali; sessiz basari kabul edilmez.
- Bir sonraki dogal odak global log search/correlation, versioned public content ve policy enforcement'tir.
- Public content/versioning backend-driven hale geldi; docs/downloads/partner/release note ve update center kataloğu canlı veriden geliyor.
- Firewall log saved views, vendor filtreleme, correlation summary, source visibility ve evidence export canlı; sıradaki increment cross-source stitching, rule authoring ve bundle enrichment refinement tarafıdır.
- User-group seçimi, concurrency cap, ban/whitelist ve location scope captive flow'a bağlandı; VLAN profile mirror sync ve stable RADIUS anahtarı da artık üretiliyor, shaping/quota/runtime VLAN push hâlâ derinleştirilmeli.
- Alarm Dashboard artık trigger event feed'ine ve alarm kayıtlarına bağlı; syslog trigger ekranında delivery history ve cooldown görünür, kalan bakım akışı ve case stitching derinleştirilmeli.

## 0.6 SON DURUM NOTU

- Auth truthfulness, scope hygiene ve silent fallback'ler artik P0 sertlestirme diliminin merkezinde; bu davranislari yeniden acmak regresyondur.
- Devices listesi artik gerçek lokasyon/vendor mapping ve health özetiyle düzeldi; syslog trigger'lari alarm kayıtları ve delivery history üretiyor; licenses, MFA delivery, PMS vendor config, WhatsApp ve signing yuzeylerinde fail-closed cizgi korunmali, demo modu sadece acik etiketli olmalidir.
- Portal demo akisi shell banner ve demo response etiketleriyle acik; network hata halinde sessiz fallback kullanma.
- Log search yuzeyinde saved views, export, vendor filtreleme, correlation summary ve source visibility hazir; correlation window ve session case stitching görünür, kalan ana is policy depth, device ops ve operasyonel compliance'i tamamlamaktir.
- Sessions yuzeyi artik backend guest-session shape'ini ve group policy/meta bilgisini gorunur kiliyor; UserGroups formu da location scope secimini aciyor, policy preview ile captive karar gorunur.
- Sistem güncellemeleri için update/release center artık admin içinde doğrudan açılabilir; yayıncı izi, audit trail ve arşiv/geçmiş görünürlüğü var, release bundle'lar publish sırasında saklanıyor ve public/system download route'lar stored artifact'i servis ediyor, stored artifact metadata API ve admin UI'da görünür, bundan sonraki fark package artifact publish ve dağıtım otomasyonunu derinleştirmektir.
- Portal template editor artık backend update alıyor, revision history/restore gösteriyor ve live preview ile çalışıyor; captive portal tasarım yüzeyi de aynı update API'sine bağlandı. Kalan iş canonical portal context, alan parity ve publish akışı.
- 5651 signing tarafında signature_origin etiketi eklendi; demo/gerçek ayrımı API ve admin UI'da görünür, legacy kayıtların provenance backfill'i ayrı slice ister.
- Backup/restore akisi config/full/db icin dogru worker'lara baglandi; config yedekleri ayri, restore yalnizca desteklenen tiplerde calismali.
- Public inquiry capture icin admin lead inbox eklendi; partner/trial talepleri durum takibiyle yonetilebilir.

---

## 1. REFERANS KAYNAKLARI

Calismadan once su kaynaklari oku ve gorsel baseline olarak kullan:

- `docs/02_MARKET_PARITY_GAP_ANALYSIS.md`
- `.ai-ops/signlogger-reference/home.png`
- `.ai-ops/signlogger-reference/features.png`
- `.ai-ops/signlogger-reference/downloads.png`
- `.ai-ops/signlogger-reference/docs.png`
- `.ai-ops/subgate-reference/dashboard.png`
- `.ai-ops/subgate-reference/kullanici-yonetimi.png`
- `.ai-ops/subgate-reference/kullanici-gruplari.png`
- `.ai-ops/subgate-reference/log-yonetimi.png`
- `.ai-ops/subgate-reference/trafik-analizi.png`
- `.ai-ops/subgate-reference/alarm-tetikleyiciler.png`
- `.ai-ops/subgate-reference/captive-portal.png`
- `.ai-ops/subgate-reference/radius-8021x.png`
- `.ai-ops/subgate-reference/mfa-cok-faktorlu-dogrulama.png`
- `.ai-ops/subgate-reference/gelismis-raporlama.png`
- `.ai-ops/subgate-reference/cihaz-yonetimi.png`
- `.ai-ops/subgate-reference/5651-sayili-kanun.png`
- `.ai-ops/subgate-reference/sistem-ayarlari.png`

FortiLogger icin public kaynaklar repo icinde net bulunmuyorsa, bunu log toplama, arama, korelasyon, alarm, arsiv ve compliance kategorisi olarak ele al.

---

## 2. BASLANGIC PROTOKOLU

Kod yazmadan once:

1. `git status --short` ile mevcut calisma agacini oku.
2. `CLAUDE.md`, `README.md`, `AGENT_TASK.md`, `docs/`, `prompts/` ve ilgili uygulama dizinlerini incele.
3. `frontend/admin/src/routes.tsx` ve `backend/app/api/v1/router.py` ile mevcut yuzeyleri cikart.
4. `frontend/admin/src/pages/DashboardPage.tsx`, `ReportsPage.tsx`, `LogsPage.tsx`, `UsersPage.tsx`, `UserGroupsPage.tsx`, `TrafficAnalysisPage.tsx`, `AlarmDashboardPage.tsx`, `CaptivePortalPage.tsx`, `SigningConfigPage.tsx` dosyalarindaki mock/hardcoded kisimlari, hardcoded context id'leri ve demo mesajlarini bul.
5. Backend modullerinin hangi kisimlari live, hangi kisimlari dev fallback/mockla calisiyor ve hangi noktalarda silent success urettigini tespit et.
6. `docs/02_MARKET_PARITY_GAP_ANALYSIS.md` tablosunu kisa bir kendi durum ozeti ile guncelle.
7. En yuksek etki / en dusuk riskli P0 dilimi sec.

Bu protokolde "once plan yaz, sonra unut" yok. Her cikti uygulanabilir olmak zorunda.

---

## 3. DEGISEMEZ KURALLAR

### 3.1 Live-first

- Core admin ekranlarinda hardcoded data, mock array, sample metrics veya demo-only content kalamaz.
- Demo / mock fallback gerekiyorsa production build'de acik label ile ayrilmali ve env flag ile kapatilmali.
- `DashboardPage` ve `ReportsPage` gibi yuzeylerde kalan mock alanlar ilk onceliklerden biridir.

### 3.2 Feature parity

- Hotspot, Subgate ve SignLogger referanslarinda gorunen ana yuzeyler ayni urun ailesinin parcalari olarak ele alinmali.
- Bir sayfa sadece gorunuyorsa tamamlanmis sayilmaz; loading, empty, error, permission, validation ve refresh davranislari olmalidir.
- Market parity, sadece tasarim degil; veri modeli, API, worker, export ve audit derinligi demektir.

### 3.3 Existing code first

- Mevcut modulleri yeniden yazma.
- Var olan domain boundaries'i koru.
- Gerekli degisiklikleri mevcut module ekle; yeni module ancak gercekten yeni domain ise ac.

### 3.4 Security and compliance

- 5651 archive append-only olmalidir.
- Sign/verify/retain/export akisi bozularak ilerlenmemelidir.
- Secret, OTP, token ve ozel anahtarlar loglara ve API cevaplarina donmemelidir.
- IDOR, tenant scope ve yetki kontrolu her yazma/okuma/aramada uygulanmalidir.

### 3.5 Dirty worktree discipline

- Kullaniciya ait veya ilgisiz degisiklikleri silme.
- Gerekmedikce dosya yeniden formatlama yapma.
- Degisimleri tek seferde degil, birbirine bagli, test edilebilir dilimler halinde uygulama.

---

## 4. GAP ONCELIKLERI

### P0 - Gelir ve algi blokajlari

1. Auth truthfulness: demo login banner'ini kaldir veya sadece explicit demo env'de goster
2. Scope hygiene: `cust-1`, `current-portal-id` gibi hardcoded context degerlerini kaldir
3. Silent success fallbacks: devices, licenses, MFA delivery, PMS ve benzeri akislarda mock success uretme
4. 5651 trust chain: signing/verify path'ini prod/dev olarak ayir ve dev fallback'i acikca label'la
5. Global log search, filtreleme, saved views, export ve correlation (correlation window ve case stitching görünür)

Not: Search/filter/saved views/export already live; next increment correlation window, case stitching ve evidence bundle enrichment olmalidir.

Not: Bu P0 maddeleri son slice'ta kismen sertlestirildi; bundan sonraki degisikliklerde bu davranislarin yeniden acilmamasi gerekir.

### P1 - Enterprise parity

1. Public content/versioning: docs, downloads, partner, release note ve update center icerigini versioned data modeline bagla; prod'da hardcoded fallback kullanma, demo fallback'i explicit yap; Support KB admin yuzeyini, taksonomi, workflow ve arama derinligini, partner lead funnel'ini derinlestir
2. User groups enforcement: bandwidth, quota, time window, concurrency, VLAN; selection + concurrency + ban gate live, shaping/VLAN push açık
3. Captive portal theme, template versioning ve live preview canlı; method field'leri ve legal metadata artık kaydediliyor, canonical portal context ve publish akışını derinleştir
4. Device health, SNMP/ping/backup/alert yuzeyleri
5. RADIUS/MFA/NAC challenge, policy mapping ve audit

### P2 - Commercial polish

1. White-label, custom domain ve tenant branding
2. Package / release / upgrade / changelog yüzeyi ve bundle indirme akışı canlı; admin içinde doğrudan update erişimi var, public/system download route'lar stored artifact'i servis ediyor, stored artifact metadata görünür, archive/history ve artifact publish/automation derinleştir
3. Support knowledge base: admin CRUD var; taksonomi, etiket, related article ve workflow görünürlüğünü tamamla
4. Demo / trial / onboarding wizard
5. Partner lead flow ve support contact surface; admin inquiry inbox mevcut, workflow ve routing derinlestir

---

## 5. UYGULAMA SIRASI

Her sprint veya vertical slice icin su sirayi uygula:

1. Gap'i repo icinde teyit et.
2. Gerekli backend endpoint / service / migration'i ekle veya mevcut olani sertlestir.
3. Frontend'deki mock/hardcoded kisimlari live data'ya bagla.
4. Loading, empty, error, permission ve refresh durumlarini ekle.
5. Otomatik test ekle.
6. Build ve ilgili testleri calistir.
7. Uretim benzeri sonuclari kisa bir gap tablosu ile raporla.

---

## 6. ILK DILIM TAVSIYESI

Eger hangi isten baslayacagin net degilse su sirayi kullan:

1. `DashboardPage` ve `ReportsPage` icindeki mock veri kalintilarini kaldir.
2. Global log arama, correlation window, source visibility ve case stitching yuzeyini guclendir.
3. `docs/`, `downloads/` ve public contact/partner yuzeyini ekle.
4. 5651 signing, verification ve retention paketini sertlestir.

Bu siralama, hem gorunen eksigi hizli kapatir hem de gercek veri akisini dogrular.

---

## 7. CIKTI KURALI

Her ana teslimatta su format korunmali:

1. Ne bulundu
2. Ne degisti
3. Hangi testler calisti
4. Kalan riskler
5. Bir sonraki en iyi dilim

Kisa, net ve uygulanabilir rapor ver. Gereksiz strateji metni yazma.

---

## 8. YASAKLAR

- Sadece UI maketi yapma.
- Backend olmadan feature tamamlandi deme.
- Mock data ile market parity iddiasi kurma.
- Log / archive / alarm / report / audit akisini one-off script'e indirgeme.
- Thread'i plan yazip birakma; uygulanabilir bir slice ile bitir.
- Kullanilmayan, ilgisiz veya baska modullere ait degisiklikleri geri alma.
