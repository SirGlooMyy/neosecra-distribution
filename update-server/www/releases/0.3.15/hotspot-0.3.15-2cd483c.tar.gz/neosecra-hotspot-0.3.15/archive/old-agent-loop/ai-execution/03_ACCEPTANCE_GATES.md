# Kabul Kapıları ve Kanıt Standardı

## Kanıt seviyeleri

| Seviye | Anlamı | MVP kapısında kullanım |
|---|---|---|
| STATIC_INSPECTED | Kod/config okundu | Tek başına yeterli değil |
| UNIT_VERIFIED | İzole test geçti | İş mantığı için gerekli, tek başına yeterli değil |
| INTEGRATION_VERIFIED | Gerçek DB/Redis/container bileşeniyle geçti | Backend kapılarında gerekli |
| SIMULATOR_VERIFIED | Dış sistemin protokol simülatörüyle geçti | Lab öncesi kabul, gerçek cihaz değildir |
| BROWSER_E2E_VERIFIED | Mock olmadan browser → API → DB/dış bileşen zinciri geçti | Kullanıcı akışlarında gerekli |
| REAL_EXTERNAL_VERIFIED | Gerçek cihaz/sağlayıcıyla geçti | Üretim iddiası gereken entegrasyonlarda gerekli |
| EXTERNAL_BLOCKED | Credential/cihaz/ücretli servis yok | Dürüst engel; başarı değildir |

## Genel PASS koşulu

Bir kapı ancak şu şartların tamamıyla PASS olabilir:

- Komut gerçekten çalıştırıldı.
- Exit code `0`.
- Beklenen assertion sayıları raporlandı.
- Zorunlu testlerde beklenmeyen skip/xfail/deselected yok.
- Kanıt logu veya rapor artefact yolu mevcut.
- Test mock'suz olmak zorundaysa mock kullanılmadığı kontrol edildi.
- Tenant/location ve negatif hata yolları test edildi.

## Zorunlu kapılar

| ID | Kapı | Asgari kanıt | Blocker |
|---|---|---|---|
| G01 | Clean install + migrations | Compose health, migration head, temiz DB | Evet |
| G02 | Voucher lifecycle | Integration + browser E2E + DB assertions | Evet |
| G03 | Voucher concurrency/isolation | Paralel submit + tenant/location negatifleri | Evet |
| G04 | FortiGate simulator lifecycle | Integration + browser E2E + DB assertions | Evet |
| G05 | FortiGate gerçek cihaz | Gerçek lab cihazı | MVP için koşullu; production-ready için evet |
| G06 | SMS güvenli OTP | Unit + integration + browser E2E | Evet |
| G07 | SMS gerçek provider | Gerçek provider | MVP için koşullu; production-ready için evet |
| G08 | RADIUS authentication/accounting | FreeRADIUS container integration | Evet |
| G09 | 5651 teknik bütünlük | Tamper testi + export doğrulama | Evet |
| G10 | Harici timestamp/signature | Gerçek servis | Koşullu/external |
| G11 | Global dashboard | Gerçek backend browser E2E + RBAC | Evet |
| G12 | RBAC/IDOR/tenant isolation | Kritik endpoint matrisi | Evet |
| G13 | Redis/outage/error behavior | Kesinti ve recovery testleri | Evet |
| G14 | Full backend regression | 0 failed, 0 error | Evet |
| G15 | Frontend quality | Unit + lint + typecheck + production build | Evet |
| G16 | Full real-backend browser suite | 0 failed, mock yok | Evet |
| G17 | Security release review | Critical/High açık yok | Evet |
| G18 | Rollback/operations | Migration rollback + runbook | Evet |

## Nihai verdict algoritması

- Bütün blocker kapılar PASS, yalnız gerçek dış sistem credential/cihaz kapıları eksik: `HOTSPOT_MVP_EXTERNAL_BLOCKED`.
- Bütün blocker kapılar PASS ve gerekli gerçek dış sistem kapıları da PASS: `HOTSPOT_MVP_VERIFIED`.
- Uygulama ilerlemiş fakat en az bir blocker FAIL/SKIP/NOT_RUN: `HOTSPOT_MVP_PARTIALLY_VERIFIED`.
- Temel kurulum çalışmıyor, veri bütünlüğü bozuk veya güvenli ilerleme mümkün değil: `HOTSPOT_MVP_FAILED`.

`HOTSPOT_MVP_VERIFIED` raporunda failed/error sıfır olmalıdır. Skip/deselected yalnız önceden tanımlı, gerekçeli ve blocker olmayan testlerde kabul edilir.
