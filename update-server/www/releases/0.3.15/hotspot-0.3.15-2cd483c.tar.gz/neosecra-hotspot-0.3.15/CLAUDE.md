# CLAUDE.md - Hotspot Platform Engineering Rules

Bu repo ticari bir Hotspot / Captive Portal / 5651 Loglama / RADIUS / Firewall entegrasyon platformudur.

## Mutlak Kurallar
1. Tenant isolation asla bypass edilmeyecek.
2. Tüm API sorguları tenant/partner/customer/location scope ile filtrelenecek.
3. Firewall API tokenları plaintext saklanmayacak; encryption layer kullanılacak.
4. 5651 log ve arşiv kayıtları sonradan değiştirilemez kabul edilecek; update yerine append-only event yaklaşımı kullanılacak.
5. Syslog, RADIUS, API eventleri korelasyon olmadan silinmeyecek.
6. Captive portal akışı kullanıcı, lokasyon, cihaz ve portal template context olmadan başlamayacak.
7. Adapter pattern bozulmayacak; FortiGate özel kodu genel service içine gömülmeyecek.
8. Site Bridge ile Platform Worker karıştırılmayacak.
9. On-prem model connector'a bağımlı olmayacak.
10. SaaS model Site Bridge kullanmadan da çalışabilir; fakat güvenli bridge senaryosu desteklenecek.
11. Her migration geri dönüş ve veri güvenliği açısından gözden geçirilecek.
12. Security-first: RBAC, audit, 2FA, rate limit, token blacklist, secrets encryption.

## Stack
- Backend: FastAPI + SQLAlchemy 2.x + Alembic
- DB: PostgreSQL
- Cache/Queue: Redis
- Worker: Celery
- Object Storage: MinIO/S3
- RADIUS: FreeRADIUS integration
- Syslog: async collector service
- Frontend Admin: React + TypeScript + Tailwind
- Portal: React/Next.js style template engine
- Search later: OpenSearch / ClickHouse

## Kodlama Standartları
- Modül bazlı yapı korunacak: `backend/app/modules/<domain>`.
- Her modülde mümkünse `models.py`, `schemas.py`, `service.py`, `router.py`, `repository.py` ayrımı kullanılacak.
- Cross-module erişim service layer üzerinden yapılacak.
- IDOR testleri yazılacak.
- Her endpoint için role/permission kontrolü olacak.
- Audit log kritik admin işlemleri için zorunlu.

## Domain Sınırları
- `tenants`: tenant, partner, customer, location hiyerarşisi
- `devices`: firewall/gateway cihazları
- `firewall_adapters`: vendor API ve parser katmanı
- `portal`: captive portal template ve auth akışı
- `radius`: RADIUS auth/accounting eventleri
- `syslog`: raw log collection ve parse pipeline
- `sessions`: guest session ve correlation
- `identity`: SMS, TC validation, voucher
- `logs_5651`: arşiv, hash, export, rapor
- `licensing`: lisans/limit/kota
- `workers`: async jobs ve scheduler
- `site_bridge`: SaaS bridge registration/control

## Yasaklar
- Vendor özel mantığı core service içine gömme.
- Tenant filtresiz listeleme yapma.
- API tokenı response içinde döndürme.
- 5651 arşiv hashini update etme.
- Background job sonucunu audit/event olmadan değiştirme.
- `delete` ile kritik log verisi silme; soft delete veya retention policy kullan.

## Mevcut Durum (Sprint Checkpoint)
* **Sprint 03 (Tamamlandı):** Alembic migration (`bd3a07a1583c`) üretildi, veritabanı şeması hazır. `seed_demo.py` tamamlandı.
* **Sprint 04 (Tamamlandı):** Auth, JWT, RBAC izinleri (`GET /permissions`), `ScopeContext` izolasyon altyapısı ve 5 demo kullanıcı hazırlandı. `passlib`/`bcrypt` yaması uygulandı.
* **Sprint 05 (Tamamlandı):** Captive Portal Frontend'inin mock API yerine backend API'lerine (`GET /portal/config`, SMS/Voucher verify, vb.) entegrasyonu tamamlandı. `location_id` parametresi opsiyonelleştirildi (ilk aktif lokasyon fallback) ve `locationId` response'a eklendi.
* **Sprint 06 (Tamamlandı):** Backend test baseline — 384 passed, 10 pre-existing failure kaydı. Kök 5651 smoke: 53 passed.
* **Sprint 07 (Tamamlandı):** FortiLogger syslog MVP — TCP 514 receiver, RFC 5424 parser, FirewallLog model, tenant-scoped ingest. 27 yeni test.
* **Sprint 07b (Tamamlandı):** Detaylı log search backend — GIN index, 4 endpoint (search/facets/correlate/export), 31 yeni test.
* **Sprint 08 (Tamamlandı):** SubGate captive portal — Fake FortiGate server ile redirect→SMS verify→authorize_guest→session log akışı.
* **Sprint 09 (Tamamlandı):** SignLogger — SHA256 hash chain, local PKCS#12 CAdES imza, MinIO WORM GOVERNANCE 730d.
* **Sprint 10 (Tamamlandı):** E2E integration — 15 test (MVP full flow, multi-tenant isolation, failure scenarios, BTK export, performance smoke). Toplam: 515 passed.
* **Sprint 11 (Tamamlandı):** Quality-close dokümantasyon — final.md, DECISIONS.md, TODO.md, CLAUDE.md, events.jsonl, active-task.yaml. Terminal status: PARTIAL.
* **2026-07-29 Gece kapanışı (RUN-20260727-001, terminal: PARTIAL):** Platform lisansı (envelope verify + INVALID_PRODUCT + router enforcement, 15 test), signed upgrade kanalı (hotspot-stable, 38 test), admin Platform Lisansı/Yükseltme sayfaları (37/37 vitest), run stack 10/10 healthy (api wedge + healthcheck bütçesi fix'li). 4 commit push'lu (65986b2..f9af495, backend 1045/0). Backlog NEEDS_HUMAN: KamuSM, cihaz labı, sms/whatsapp gating, 11 vendor adapter, RADIUS CoA.

