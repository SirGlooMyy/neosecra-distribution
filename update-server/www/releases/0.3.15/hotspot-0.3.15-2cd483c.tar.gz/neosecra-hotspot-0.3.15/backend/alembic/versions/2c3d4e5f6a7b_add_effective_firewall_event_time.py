"""persist indexed effective firewall event timestamp

Revision ID: 2c3d4e5f6a7b
Revises: 1b2c3d4e5f6a
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "2c3d4e5f6a7b"
down_revision: Union[str, None] = "1b2c3d4e5f6a"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # PostgreSQL does not permit timezone-aware expressions in a generated
    # column because timestamptz arithmetic is not marked immutable. Keep the
    # normalized value persisted instead and maintain it with a small trigger;
    # this still gives the analyzer a plain btree predicate and works across
    # PostgreSQL 14-16.
    op.add_column(
        "firewall_logs",
        sa.Column("effective_event_time", sa.DateTime(timezone=True), nullable=True),
    )
    op.execute(
        """
        UPDATE firewall_logs
        SET effective_event_time = CASE
            WHEN (parsed_fields ->> 'tz') = '+0300'
             AND event_time > received_at + interval '5 minutes'
            THEN event_time - interval '3 hours'
            ELSE coalesce(event_time, received_at)
        END
        """
    )
    op.execute(
        """
        CREATE OR REPLACE FUNCTION set_firewall_effective_event_time()
        RETURNS trigger LANGUAGE plpgsql AS $$
        BEGIN
            NEW.effective_event_time := CASE
                WHEN (NEW.parsed_fields ->> 'tz') = '+0300'
                 AND NEW.event_time > NEW.received_at + interval '5 minutes'
                THEN NEW.event_time - interval '3 hours'
                ELSE coalesce(NEW.event_time, NEW.received_at)
            END;
            RETURN NEW;
        END;
        $$
        """
    )
    op.execute(
        """
        CREATE TRIGGER trg_firewall_effective_event_time
        BEFORE INSERT OR UPDATE OF event_time, received_at, parsed_fields
        ON firewall_logs FOR EACH ROW
        EXECUTE FUNCTION set_firewall_effective_event_time()
        """
    )
    # The analyzer scopes by customer in normal operation and by tenant for
    # global support accounts.  Build both access paths concurrently on the
    # live table so neither scope falls back to a sequential scan.
    op.create_index(
        "ix_firewall_logs_customer_effective_event",
        "firewall_logs",
        ["customer_id", sa.text("effective_event_time DESC")],
    )
    op.create_index(
        "ix_firewall_logs_tenant_effective_event",
        "firewall_logs",
        ["tenant_id", sa.text("effective_event_time DESC")],
    )


def downgrade() -> None:
    op.drop_index("ix_firewall_logs_tenant_effective_event", table_name="firewall_logs")
    op.drop_index("ix_firewall_logs_customer_effective_event", table_name="firewall_logs")
    op.execute("DROP TRIGGER IF EXISTS trg_firewall_effective_event_time ON firewall_logs")
    op.execute("DROP FUNCTION IF EXISTS set_firewall_effective_event_time()")
    op.drop_column("firewall_logs", "effective_event_time")
