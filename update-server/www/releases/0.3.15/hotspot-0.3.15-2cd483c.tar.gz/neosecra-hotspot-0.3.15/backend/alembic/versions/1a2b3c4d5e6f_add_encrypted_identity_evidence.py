"""store encrypted 5651 identity evidence envelope

Revision ID: 1a2b3c4d5e6f
Revises: e1f2a3b4c5d6
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "1a2b3c4d5e6f"
down_revision: Union[str, None] = "e1f2a3b4c5d6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "identity_verifications",
        sa.Column("identity_evidence_encrypted", sa.String(length=4000), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("identity_verifications", "identity_evidence_encrypted")
