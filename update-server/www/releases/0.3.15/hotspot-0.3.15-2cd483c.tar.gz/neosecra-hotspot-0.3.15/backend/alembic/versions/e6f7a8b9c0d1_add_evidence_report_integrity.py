"""Add immutable report/evidence envelopes and persisted status history.

Revision ID: e6f7a8b9c0d1
Revises: 4e5f6a7b8c9d
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "e6f7a8b9c0d1"
down_revision: Union[str, None] = "4e5f6a7b8c9d"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _json_default() -> sa.TextClause:
    return sa.text("'{}'::jsonb")


def upgrade() -> None:
    # Existing rows are deliberately pending/unverified.  They must be
    # re-verified before a PDF or evidence package can be published.
    op.add_column(
        "archive_records_5651",
        sa.Column("status", sa.String(length=20), server_default="pending", nullable=False),
    )
    op.add_column("archive_records_5651", sa.Column("error_message", sa.Text(), nullable=True))
    op.add_column(
        "archive_records_5651",
        sa.Column("storage_verified", sa.Boolean(), server_default=sa.text("false"), nullable=False),
    )
    op.add_column(
        "archive_records_5651",
        sa.Column("signature_valid", sa.Boolean(), server_default=sa.text("false"), nullable=False),
    )
    op.create_index("ix_archive_records_5651_status", "archive_records_5651", ["status"])

    op.add_column(
        "report_archives",
        sa.Column("schema_version", sa.String(length=20), server_default="1.0", nullable=False),
    )
    op.add_column("report_archives", sa.Column("tenant_id", sa.UUID(), nullable=True))
    op.add_column(
        "report_archives",
        sa.Column("sha256_hash", sa.String(length=64), server_default="", nullable=False),
    )
    op.add_column(
        "report_archives",
        sa.Column("provenance", postgresql.JSONB(), server_default=_json_default(), nullable=False),
    )
    op.add_column(
        "report_archives",
        sa.Column("envelope", postgresql.JSONB(), server_default=_json_default(), nullable=False),
    )
    op.add_column("report_archives", sa.Column("idempotency_key", sa.String(length=255), nullable=True))
    op.create_index("ix_report_archives_tenant_id", "report_archives", ["tenant_id"])
    op.create_index("ix_report_archives_sha256_hash", "report_archives", ["sha256_hash"])
    op.create_index("ix_report_archives_idempotency_key", "report_archives", ["idempotency_key"])

    op.create_table(
        "report_job_status_history",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("job_id", sa.UUID(), nullable=False),
        sa.Column("customer_id", sa.UUID(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("attempt", sa.Integer(), server_default="1", nullable=False),
        sa.Column("idempotency_key", sa.String(length=255), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("details", postgresql.JSONB(), server_default=_json_default(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["job_id"], ["report_jobs.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["customer_id"], ["customers.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_report_job_status_history_status", "report_job_status_history", ["status"])
    op.create_index("ix_report_job_status_history_job_id", "report_job_status_history", ["job_id"])
    op.create_index("ix_report_job_status_history_customer_id", "report_job_status_history", ["customer_id"])
    op.create_index("ix_report_job_status_history_idempotency_key", "report_job_status_history", ["idempotency_key"])

    op.create_table(
        "evidence_exports",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("session_id", sa.UUID(), nullable=False),
        sa.Column("customer_id", sa.UUID(), nullable=False),
        sa.Column("tenant_id", sa.UUID(), nullable=False),
        sa.Column("status", sa.String(length=20), server_default="pending", nullable=False),
        sa.Column("package_ref", sa.String(length=500), nullable=True),
        sa.Column("file_size", sa.BigInteger(), server_default="0", nullable=False),
        sa.Column("content_hash", sa.String(length=64), server_default="", nullable=False),
        sa.Column("schema_version", sa.String(length=20), server_default="1.0", nullable=False),
        sa.Column("sha256_hash", sa.String(length=64), server_default="", nullable=False),
        sa.Column("provenance", postgresql.JSONB(), server_default=_json_default(), nullable=False),
        sa.Column("envelope", postgresql.JSONB(), server_default=_json_default(), nullable=False),
        sa.Column("idempotency_key", sa.String(length=255), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["session_id"], ["guest_sessions.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["customer_id"], ["customers.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_evidence_exports_status", "evidence_exports", ["status"])
    op.create_index("ix_evidence_exports_content_hash", "evidence_exports", ["content_hash"])
    op.create_index("ix_evidence_exports_sha256_hash", "evidence_exports", ["sha256_hash"])
    op.create_index("ix_evidence_exports_idempotency_key", "evidence_exports", ["idempotency_key"])
    op.create_index(
        "uq_evidence_exports_customer_session_idempotency",
        "evidence_exports",
        ["customer_id", "session_id", "idempotency_key"],
        unique=True,
    )

    op.create_table(
        "evidence_export_status_history",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("export_id", sa.UUID(), nullable=False),
        sa.Column("session_id", sa.UUID(), nullable=False),
        sa.Column("customer_id", sa.UUID(), nullable=False),
        sa.Column("tenant_id", sa.UUID(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("attempt", sa.Integer(), server_default="1", nullable=False),
        sa.Column("idempotency_key", sa.String(length=255), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("details", postgresql.JSONB(), server_default=_json_default(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["export_id"], ["evidence_exports.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["session_id"], ["guest_sessions.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["customer_id"], ["customers.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_evidence_export_status_history_status", "evidence_export_status_history", ["status"])
    op.create_index("ix_evidence_export_status_history_export_id", "evidence_export_status_history", ["export_id"])
    op.create_index("ix_evidence_export_status_history_customer_id", "evidence_export_status_history", ["customer_id"])
    op.create_index("ix_evidence_export_status_history_idempotency_key", "evidence_export_status_history", ["idempotency_key"])


def downgrade() -> None:
    op.drop_index("ix_evidence_export_status_history_idempotency_key", table_name="evidence_export_status_history")
    op.drop_index("ix_evidence_export_status_history_customer_id", table_name="evidence_export_status_history")
    op.drop_index("ix_evidence_export_status_history_export_id", table_name="evidence_export_status_history")
    op.drop_index("ix_evidence_export_status_history_status", table_name="evidence_export_status_history")
    op.drop_table("evidence_export_status_history")
    op.drop_index("uq_evidence_exports_customer_session_idempotency", table_name="evidence_exports")
    op.drop_index("ix_evidence_exports_idempotency_key", table_name="evidence_exports")
    op.drop_index("ix_evidence_exports_sha256_hash", table_name="evidence_exports")
    op.drop_index("ix_evidence_exports_content_hash", table_name="evidence_exports")
    op.drop_index("ix_evidence_exports_status", table_name="evidence_exports")
    op.drop_table("evidence_exports")
    op.drop_index("ix_report_job_status_history_idempotency_key", table_name="report_job_status_history")
    op.drop_index("ix_report_job_status_history_customer_id", table_name="report_job_status_history")
    op.drop_index("ix_report_job_status_history_job_id", table_name="report_job_status_history")
    op.drop_index("ix_report_job_status_history_status", table_name="report_job_status_history")
    op.drop_table("report_job_status_history")
    op.drop_index("ix_report_archives_idempotency_key", table_name="report_archives")
    op.drop_index("ix_report_archives_sha256_hash", table_name="report_archives")
    op.drop_index("ix_report_archives_tenant_id", table_name="report_archives")
    op.drop_column("report_archives", "idempotency_key")
    op.drop_column("report_archives", "envelope")
    op.drop_column("report_archives", "provenance")
    op.drop_column("report_archives", "sha256_hash")
    op.drop_column("report_archives", "tenant_id")
    op.drop_column("report_archives", "schema_version")
    op.drop_index("ix_archive_records_5651_status", table_name="archive_records_5651")
    op.drop_column("archive_records_5651", "signature_valid")
    op.drop_column("archive_records_5651", "storage_verified")
    op.drop_column("archive_records_5651", "error_message")
    op.drop_column("archive_records_5651", "status")
