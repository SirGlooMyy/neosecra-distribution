"""add RFC 2866 accounting counters to radius events

Revision ID: 1b2c3d4e5f6a
Revises: 1a2b3c4d5e6f
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "1b2c3d4e5f6a"
down_revision: Union[str, None] = "1a2b3c4d5e6f"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("radius_events", sa.Column("acct_input_octets", sa.BigInteger(), nullable=True))
    op.add_column("radius_events", sa.Column("acct_output_octets", sa.BigInteger(), nullable=True))
    op.add_column("radius_events", sa.Column("acct_session_time", sa.Integer(), nullable=True))
    op.add_column("radius_events", sa.Column("acct_terminate_cause", sa.String(length=64), nullable=True))
    op.add_column("radius_events", sa.Column("acct_interim_interval", sa.Integer(), nullable=True))


def downgrade() -> None:
    op.drop_column("radius_events", "acct_interim_interval")
    op.drop_column("radius_events", "acct_terminate_cause")
    op.drop_column("radius_events", "acct_session_time")
    op.drop_column("radius_events", "acct_output_octets")
    op.drop_column("radius_events", "acct_input_octets")
