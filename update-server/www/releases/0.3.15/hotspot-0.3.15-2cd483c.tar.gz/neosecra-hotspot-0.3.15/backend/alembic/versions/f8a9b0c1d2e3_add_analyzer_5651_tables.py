"""Add tenant-scoped 5651/network Analyzer storage.

Raw and normalized events are separate, content-addressed projections.  The
database protects evidence rows with forced RLS and append-only triggers;
operational retry state and saved views remain mutable by design.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "f8a9b0c1d2e3"
down_revision: Union[str, None] = "e6f7a8b9c0d1"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _json_default() -> sa.TextClause:
    return sa.text("'{}'::jsonb")


def _uuid(name: str, *, nullable: bool = False) -> sa.Column:
    return sa.Column(name, sa.UUID(), nullable=nullable)


def upgrade() -> None:
    op.create_table(
        "analyzer_raw_events",
        _uuid("id"),
        _uuid("tenant_id"),
        _uuid("customer_id"),
        sa.Column("source_name", sa.String(length=255), nullable=False),
        sa.Column("source_type", sa.String(length=50), nullable=False),
        sa.Column("transport", sa.String(length=20), server_default="syslog", nullable=False),
        sa.Column("source_ip", sa.String(length=64), nullable=True),
        sa.Column("received_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("raw_payload", sa.Text(), nullable=False),
        sa.Column("raw_sha256", sa.String(length=64), nullable=False),
        sa.Column("idempotency_key", sa.String(length=255), nullable=False),
        sa.Column("parser_version", sa.String(length=40), server_default="fortigate-v1", nullable=False),
        sa.Column("status", sa.String(length=20), server_default="received", nullable=False),
        sa.Column("retention_until", sa.DateTime(timezone=True), nullable=False),
        sa.Column("provenance", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("content_size", sa.BigInteger(), server_default="0", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("tenant_id", "customer_id", "idempotency_key", name="uq_analyzer_raw_tenant_idempotency"),
    )

    op.create_table(
        "analyzer_normalized_events",
        _uuid("id"),
        _uuid("raw_event_id"),
        _uuid("tenant_id"),
        _uuid("customer_id"),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("received_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("source_name", sa.String(length=255), nullable=False),
        sa.Column("source_type", sa.String(length=50), nullable=False),
        sa.Column("transport", sa.String(length=20), server_default="syslog", nullable=False),
        sa.Column("vendor", sa.String(length=50), server_default="fortigate", nullable=False),
        sa.Column("category", sa.String(length=50), server_default="event", nullable=False),
        sa.Column("subtype", sa.String(length=80), nullable=True),
        sa.Column("severity", sa.String(length=20), server_default="info", nullable=False),
        sa.Column("action", sa.String(length=80), nullable=True),
        sa.Column("source_ip_address", sa.String(length=64), nullable=True),
        sa.Column("destination_ip_address", sa.String(length=64), nullable=True),
        sa.Column("source_mac", sa.String(length=32), nullable=True),
        sa.Column("destination_mac", sa.String(length=32), nullable=True),
        sa.Column("source_port", sa.Integer(), nullable=True),
        sa.Column("destination_port", sa.Integer(), nullable=True),
        sa.Column("identity", sa.String(length=255), nullable=True),
        sa.Column("session_id", sa.String(length=120), nullable=True),
        sa.Column("nat_source_ip", sa.String(length=64), nullable=True),
        sa.Column("nat_destination_ip", sa.String(length=64), nullable=True),
        sa.Column("nat_source_port", sa.Integer(), nullable=True),
        sa.Column("nat_destination_port", sa.Integer(), nullable=True),
        sa.Column("dns_query", sa.String(length=255), nullable=True),
        sa.Column("dns_answers", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("firewall_policy_id", sa.Integer(), nullable=True),
        sa.Column("firewall_policy_name", sa.String(length=255), nullable=True),
        sa.Column("bytes_sent", sa.BigInteger(), nullable=True),
        sa.Column("bytes_received", sa.BigInteger(), nullable=True),
        sa.Column("duration_seconds", sa.Integer(), nullable=True),
        sa.Column("fields", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("normalized_sha256", sa.String(length=64), nullable=False),
        sa.Column("parser_version", sa.String(length=40), server_default="fortigate-v1", nullable=False),
        sa.Column("provenance", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("retention_until", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("raw_event_id", name="uq_analyzer_normalized_raw_event"),
        sa.ForeignKeyConstraint(["raw_event_id"], ["analyzer_raw_events.id"], ondelete="RESTRICT"),
    )

    op.create_table(
        "analyzer_ingest_failures",
        _uuid("id"),
        _uuid("raw_event_id"),
        _uuid("tenant_id"),
        _uuid("customer_id"),
        sa.Column("error_code", sa.String(length=80), nullable=False),
        sa.Column("error_message", sa.String(length=2000), nullable=False),
        sa.Column("attempts", sa.Integer(), server_default="1", nullable=False),
        sa.Column("status", sa.String(length=20), server_default="pending", nullable=False),
        sa.Column("next_retry_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_attempt_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("replayed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("provenance", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["raw_event_id"], ["analyzer_raw_events.id"], ondelete="RESTRICT"),
    )

    op.create_table(
        "analyzer_source_health",
        _uuid("id"),
        _uuid("tenant_id"),
        _uuid("customer_id"),
        sa.Column("source_name", sa.String(length=255), nullable=False),
        sa.Column("source_type", sa.String(length=50), nullable=False),
        sa.Column("status", sa.String(length=30), server_default="unknown", nullable=False),
        sa.Column("last_received_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_parsed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_failure_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_error_code", sa.String(length=80), nullable=True),
        sa.Column("received_count", sa.BigInteger(), server_default="0", nullable=False),
        sa.Column("parsed_count", sa.BigInteger(), server_default="0", nullable=False),
        sa.Column("parser_failure_count", sa.BigInteger(), server_default="0", nullable=False),
        sa.Column("lag_seconds", sa.Integer(), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("tenant_id", "customer_id", "source_name", name="uq_analyzer_source_health_tenant_source"),
    )

    op.create_table(
        "analyzer_legal_holds",
        _uuid("id"),
        _uuid("tenant_id"),
        _uuid("customer_id"),
        _uuid("raw_event_id", nullable=True),
        _uuid("normalized_event_id", nullable=True),
        sa.Column("action", sa.String(length=20), nullable=False),
        sa.Column("reason", sa.String(length=1000), nullable=False),
        _uuid("actor_id", nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["raw_event_id"], ["analyzer_raw_events.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(["normalized_event_id"], ["analyzer_normalized_events.id"], ondelete="RESTRICT"),
    )

    op.create_table(
        "analyzer_evidence_exports",
        _uuid("id"),
        _uuid("tenant_id"),
        _uuid("customer_id"),
        sa.Column("period_start", sa.DateTime(timezone=True), nullable=True),
        sa.Column("period_end", sa.DateTime(timezone=True), nullable=True),
        sa.Column("package_ref", sa.String(length=500), nullable=False),
        sa.Column("content_hash", sa.String(length=64), nullable=False),
        sa.Column("file_size", sa.BigInteger(), server_default="0", nullable=False),
        sa.Column("status", sa.String(length=20), server_default="ready", nullable=False),
        sa.Column("schema_version", sa.String(length=20), server_default="1.0", nullable=False),
        sa.Column("provenance", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("envelope", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("idempotency_key", sa.String(length=255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("tenant_id", "customer_id", "idempotency_key", name="uq_analyzer_evidence_tenant_idempotency"),
    )

    op.create_table(
        "analyzer_reports",
        _uuid("id"),
        _uuid("tenant_id"),
        _uuid("customer_id"),
        sa.Column("period_start", sa.DateTime(timezone=True), nullable=True),
        sa.Column("period_end", sa.DateTime(timezone=True), nullable=True),
        sa.Column("report_type", sa.String(length=80), nullable=False),
        sa.Column("schema_version", sa.String(length=20), server_default="1.0", nullable=False),
        sa.Column("generated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("sha256_hash", sa.String(length=64), nullable=False),
        sa.Column("provenance", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("snapshot", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("idempotency_key", sa.String(length=255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("tenant_id", "customer_id", "idempotency_key", name="uq_analyzer_report_tenant_idempotency"),
    )

    op.create_table(
        "analyzer_saved_views",
        _uuid("id"),
        _uuid("tenant_id"),
        _uuid("customer_id"),
        _uuid("created_by_user_id"),
        sa.Column("title", sa.String(length=255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("filters", postgresql.JSONB(astext_type=sa.Text()), server_default=_json_default(), nullable=False),
        sa.Column("is_shared", sa.Boolean(), server_default=sa.text("false"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["created_by_user_id"], ["users.id"], ondelete="CASCADE"),
    )

    indexes = {
        "analyzer_raw_events": [
            ("tenant_id",), ("customer_id",), ("source_name",), ("source_type",),
            ("received_at",), ("raw_sha256",), ("status",), ("retention_until",), ("created_at",),
        ],
        "analyzer_normalized_events": [
            ("raw_event_id",), ("tenant_id",), ("customer_id",), ("occurred_at",), ("received_at",),
            ("source_name",), ("source_type",), ("vendor",), ("category",), ("subtype",), ("severity",),
            ("action",), ("source_ip_address",), ("destination_ip_address",), ("source_mac",),
            ("destination_mac",), ("identity",), ("session_id",), ("nat_source_ip",), ("dns_query",),
            ("firewall_policy_id",), ("normalized_sha256",), ("retention_until",), ("created_at",),
        ],
        "analyzer_ingest_failures": [
            ("raw_event_id",), ("tenant_id",), ("customer_id",), ("error_code",), ("status",),
            ("next_retry_at",), ("created_at",),
        ],
        "analyzer_source_health": [
            ("tenant_id",), ("customer_id",), ("source_name",), ("status",),
        ],
        "analyzer_legal_holds": [
            ("tenant_id",), ("customer_id",), ("raw_event_id",), ("normalized_event_id",), ("action",),
            ("actor_id",), ("created_at",),
        ],
        "analyzer_evidence_exports": [
            ("tenant_id",), ("customer_id",), ("content_hash",), ("status",), ("created_at",),
        ],
        "analyzer_reports": [
            ("tenant_id",), ("customer_id",), ("report_type",), ("sha256_hash",), ("created_at",),
        ],
        "analyzer_saved_views": [
            ("tenant_id",), ("customer_id",), ("created_by_user_id",), ("is_shared",), ("created_at",),
        ],
    }
    for table, columns in indexes.items():
        for column in columns:
            op.create_index(f"ix_{table}_{column[0]}", table, list(column), unique=False)

    # RLS is deliberately explicit and forced.  Application predicates remain
    # useful for SQLite/test doubles and for partner/location joins, while
    # PostgreSQL provides the final storage-layer boundary.
    tenant_tables = (
        "analyzer_raw_events", "analyzer_normalized_events", "analyzer_ingest_failures",
        "analyzer_source_health", "analyzer_legal_holds", "analyzer_evidence_exports",
        "analyzer_reports", "analyzer_saved_views",
    )
    policy_template = """
        current_setting('app.is_super_admin', true) = 'true'
        OR (
            (nullif(current_setting('app.tenant_id', true), '') IS NULL
             OR {table}.tenant_id::text = current_setting('app.tenant_id', true))
            AND (
                (nullif(current_setting('app.customer_id', true), '') IS NOT NULL
                 AND {table}.customer_id::text = current_setting('app.customer_id', true))
                OR (nullif(current_setting('app.partner_id', true), '') IS NOT NULL
                    AND EXISTS (SELECT 1 FROM customers c
                                WHERE c.id = {table}.customer_id
                                  AND c.partner_id::text = current_setting('app.partner_id', true)
                                  AND c.tenant_id::text = current_setting('app.tenant_id', true)))
                OR (nullif(current_setting('app.location_id', true), '') IS NOT NULL
                    AND EXISTS (SELECT 1 FROM locations l
                                WHERE l.id = current_setting('app.location_id', true)::uuid
                                  AND l.customer_id = {table}.customer_id
                                  AND EXISTS (SELECT 1 FROM customers c
                                              WHERE c.id = l.customer_id
                                                AND c.tenant_id::text = current_setting('app.tenant_id', true))))
                OR (nullif(current_setting('app.tenant_id', true), '') IS NOT NULL
                    AND nullif(current_setting('app.customer_id', true), '') IS NULL
                    AND nullif(current_setting('app.partner_id', true), '') IS NULL
                    AND nullif(current_setting('app.location_id', true), '') IS NULL
                    AND {table}.tenant_id::text = current_setting('app.tenant_id', true))
            )
        )
    """
    for table in tenant_tables:
        policy_body = policy_template.format(table=table)
        op.execute(sa.text(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY"))
        op.execute(sa.text(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY"))
        op.execute(sa.text(f"CREATE POLICY {table}_tenant_isolation ON {table} USING ({policy_body}) WITH CHECK ({policy_body})"))

    immutable_tables = (
        "analyzer_raw_events", "analyzer_normalized_events", "analyzer_legal_holds",
        "analyzer_evidence_exports", "analyzer_reports",
    )
    op.execute(
        sa.text(
            """
            CREATE OR REPLACE FUNCTION analyzer_immutable_guard() RETURNS trigger
            LANGUAGE plpgsql AS $$
            BEGIN
                IF TG_TABLE_NAME = 'analyzer_raw_events' THEN
                    IF NEW.tenant_id IS DISTINCT FROM OLD.tenant_id
                       OR NEW.customer_id IS DISTINCT FROM OLD.customer_id
                       OR NEW.source_name IS DISTINCT FROM OLD.source_name
                       OR NEW.source_type IS DISTINCT FROM OLD.source_type
                       OR NEW.transport IS DISTINCT FROM OLD.transport
                       OR NEW.source_ip IS DISTINCT FROM OLD.source_ip
                       OR NEW.received_at IS DISTINCT FROM OLD.received_at
                       OR NEW.raw_payload IS DISTINCT FROM OLD.raw_payload
                       OR NEW.raw_sha256 IS DISTINCT FROM OLD.raw_sha256
                       OR NEW.idempotency_key IS DISTINCT FROM OLD.idempotency_key
                       OR NEW.parser_version IS DISTINCT FROM OLD.parser_version
                       OR NEW.retention_until IS DISTINCT FROM OLD.retention_until
                       OR NEW.provenance IS DISTINCT FROM OLD.provenance
                       OR NEW.content_size IS DISTINCT FROM OLD.content_size
                       OR NEW.id IS DISTINCT FROM OLD.id THEN
                        RAISE EXCEPTION 'Analyzer raw evidence is immutable';
                    END IF;
                    RETURN NEW;
                END IF;
                RAISE EXCEPTION 'Analyzer evidence rows are append-only';
            END;
            $$
            """
        )
    )
    for table in immutable_tables:
        op.execute(
            sa.text(
                f"CREATE TRIGGER {table}_immutable_guard BEFORE UPDATE OR DELETE ON {table} "
                "FOR EACH ROW EXECUTE FUNCTION analyzer_immutable_guard()"
            )
        )


def downgrade() -> None:
    tables = (
        "analyzer_saved_views", "analyzer_reports", "analyzer_evidence_exports", "analyzer_legal_holds",
        "analyzer_source_health", "analyzer_ingest_failures", "analyzer_normalized_events", "analyzer_raw_events",
    )
    for table in tables:
        op.execute(sa.text(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}"))
    for table in tables:
        # Index names are deterministic; dropping the table also removes them.
        op.drop_table(table)
    op.execute(sa.text("DROP FUNCTION IF EXISTS analyzer_immutable_guard()"))
