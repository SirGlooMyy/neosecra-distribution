"""add configurable VPN MFA SMS template

Revision ID: 3d4e5f6a7b8c
Revises: 2c3d4e5f6a7b
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "3d4e5f6a7b8c"
down_revision: Union[str, None] = "2c3d4e5f6a7b"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "vpn_mfa_config",
        sa.Column(
            "sms_template",
            sa.String(length=500),
            nullable=True,
            server_default="VPN giriş doğrulama kodunuz: {code}",
        ),
    )


def downgrade() -> None:
    op.drop_column("vpn_mfa_config", "sms_template")
