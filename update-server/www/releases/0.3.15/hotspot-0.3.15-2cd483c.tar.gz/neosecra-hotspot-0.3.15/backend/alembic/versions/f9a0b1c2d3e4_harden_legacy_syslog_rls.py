"""Harden legacy syslog ownership and PostgreSQL RLS.

The foundation schema predates the tenant contract: ``syslog_records`` was
nullable and had no storage-layer policy.  This migration resolves only rows
whose hostname/source has exactly one registered tenant.  Every other row is
kept in place as an explicit quarantine record with its original payload and
candidate set; no ownership is guessed and no row is discarded.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "f9a0b1c2d3e4"
down_revision: Union[str, None] = "f8a9b0c1d2e3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_CANDIDATE_CTE = """
WITH candidate_rows AS (
    SELECT sr.id, c.tenant_id
    FROM syslog_records sr
    JOIN devices d ON d.name = sr.hostname AND d.is_active = TRUE
    JOIN locations l ON l.id = d.location_id AND l.is_active = TRUE
    JOIN customers c ON c.id = l.customer_id AND c.is_active = TRUE
    WHERE sr.tenant_id IS NULL
      AND sr.tenant_resolution_source = 'legacy_existing'
    UNION
    SELECT sr.id, c.tenant_id
    FROM syslog_records sr
    JOIN syslog_sources ss ON ss.identifier = sr.hostname
    JOIN devices d ON d.id = ss.device_id AND d.is_active = TRUE
    JOIN locations l ON l.id = d.location_id AND l.is_active = TRUE
    JOIN customers c ON c.id = l.customer_id AND c.is_active = TRUE
    WHERE sr.tenant_id IS NULL
      AND sr.tenant_resolution_source = 'legacy_existing'
), candidate_sets AS (
    SELECT id,
           min(tenant_id::text)::uuid AS tenant_id,
           count(*)::integer AS candidate_count,
           array_agg(tenant_id::text ORDER BY tenant_id::text) AS candidates
    FROM candidate_rows
    GROUP BY id
)
"""


def upgrade() -> None:
    op.add_column(
        "syslog_records",
        sa.Column("claimed_tenant_id", sa.UUID(), nullable=True),
    )
    op.add_column(
        "syslog_records",
        sa.Column(
            "tenant_resolution_status",
            # Keep the migration schema aligned with the ORM so future
            # quarantine states can be introduced without truncation risk.
            sa.String(length=32),
            server_default=sa.text("'resolved'"),
            nullable=False,
        ),
    )
    op.add_column(
        "syslog_records",
        sa.Column("tenant_resolution_reason", sa.String(length=64), nullable=True),
    )
    op.add_column(
        "syslog_records",
        sa.Column(
            "tenant_resolution_candidates",
            postgresql.JSONB(astext_type=sa.Text()),
            server_default=sa.text("'[]'::jsonb"),
            nullable=False,
        ),
    )
    op.add_column(
        "syslog_records",
        sa.Column(
            "tenant_resolution_source",
            sa.String(length=32),
            server_default=sa.text("'legacy_existing'"),
            nullable=False,
        ),
    )

    # An invalid historical tenant is retained in claimed_tenant_id and made
    # explicitly unresolved before the FK is created.  Valid non-null values
    # are never overwritten merely because their source is no longer active.
    op.execute(
        sa.text(
            """
            UPDATE syslog_records
            SET claimed_tenant_id = tenant_id,
                tenant_id = NULL,
                tenant_resolution_status = 'quarantined',
                tenant_resolution_reason = 'invalid_existing_tenant',
                tenant_resolution_source = 'invalid_existing'
            WHERE tenant_id IS NOT NULL
              AND NOT EXISTS (
                  SELECT 1 FROM tenants t WHERE t.id = syslog_records.tenant_id
              )
            """
        )
    )

    # Deterministic backfill: exactly one distinct tenant is required.  The
    # customer/device itself may be duplicated, but tenant ownership may not.
    op.execute(
        sa.text(
            _CANDIDATE_CTE
            + """
            UPDATE syslog_records sr
            SET tenant_id = cs.tenant_id,
                tenant_resolution_status = 'resolved',
                tenant_resolution_reason = NULL,
                tenant_resolution_candidates = to_jsonb(cs.candidates),
                tenant_resolution_source = 'deterministic_backfill'
            FROM candidate_sets cs
            WHERE sr.id = cs.id
              AND sr.tenant_id IS NULL
              AND sr.tenant_resolution_source = 'legacy_existing'
              AND cs.candidate_count = 1
            """
        )
    )

    # Preserve unresolved rows in the legacy table.  RLS hides them from every
    # scoped caller, while a super-admin can inspect the explicit reason and
    # candidate evidence before assigning ownership through a controlled job.
    op.execute(
        sa.text(
            _CANDIDATE_CTE
            + """
            UPDATE syslog_records sr
            SET tenant_resolution_status = 'quarantined',
                tenant_resolution_reason = 'ambiguous_tenant',
                tenant_resolution_candidates = to_jsonb(cs.candidates),
                tenant_resolution_source = 'quarantine'
            FROM candidate_sets cs
            WHERE sr.id = cs.id
              AND sr.tenant_id IS NULL
              AND sr.tenant_resolution_source = 'legacy_existing'
              AND cs.candidate_count > 1
            """
        )
    )
    op.execute(
        sa.text(
            _CANDIDATE_CTE
            + """
            UPDATE syslog_records sr
            SET tenant_resolution_status = 'quarantined',
                tenant_resolution_reason = 'no_deterministic_tenant',
                tenant_resolution_candidates = '[]'::jsonb,
                tenant_resolution_source = 'quarantine'
            WHERE sr.tenant_id IS NULL
              AND sr.tenant_resolution_source = 'legacy_existing'
              AND NOT EXISTS (SELECT 1 FROM candidate_sets cs WHERE cs.id = sr.id)
            """
        )
    )

    # The temporary legacy default is no longer needed after existing rows
    # have been classified.  New application inserts must carry an explicit
    # provenance value (the API uses ``api_ingest``) rather than looking like
    # pre-migration data.
    op.alter_column(
        "syslog_records",
        "tenant_resolution_source",
        server_default=sa.text("'api_ingest'"),
    )

    op.create_foreign_key(
        "fk_syslog_records_tenant_id",
        "syslog_records",
        "tenants",
        ["tenant_id"],
        ["id"],
        ondelete="RESTRICT",
    )
    op.create_check_constraint(
        "ck_syslog_records_tenant_resolution",
        "syslog_records",
        "(tenant_id IS NOT NULL AND tenant_resolution_status = 'resolved') "
        "OR (tenant_id IS NULL AND tenant_resolution_status = 'quarantined')",
    )
    op.create_index(
        "ix_syslog_records_tenant_resolution_status",
        "syslog_records",
        ["tenant_resolution_status"],
    )
    op.create_index(
        "ix_syslog_records_tenant_resolution_reason",
        "syslog_records",
        ["tenant_resolution_reason"],
    )
    op.create_index(
        "ix_syslog_records_tenant_resolution_source",
        "syslog_records",
        ["tenant_resolution_source"],
    )

    # A missing/malformed app.tenant_id never grants access.  Super-admins may
    # read/delete quarantined evidence, but every INSERT/UPDATE still requires
    # a concrete resolved tenant so an unowned row cannot be created through
    # the application role.
    scoped_read = """
        current_setting('app.is_super_admin', true) = 'true'
        OR (
            tenant_id IS NOT NULL
            AND tenant_resolution_status = 'resolved'
            AND nullif(current_setting('app.tenant_id', true), '') IS NOT NULL
            AND tenant_id::text = current_setting('app.tenant_id', true)
        )
    """
    scoped_write = """
        tenant_id IS NOT NULL
        AND tenant_resolution_status = 'resolved'
        AND (
            current_setting('app.is_super_admin', true) = 'true'
            OR (
                nullif(current_setting('app.tenant_id', true), '') IS NOT NULL
                AND tenant_id::text = current_setting('app.tenant_id', true)
            )
        )
    """
    op.execute(sa.text("ALTER TABLE syslog_records ENABLE ROW LEVEL SECURITY"))
    op.execute(sa.text("ALTER TABLE syslog_records FORCE ROW LEVEL SECURITY"))
    op.execute(
        sa.text(
            f"CREATE POLICY syslog_records_select ON syslog_records "
            f"FOR SELECT USING ({scoped_read})"
        )
    )
    op.execute(
        sa.text(
            f"CREATE POLICY syslog_records_insert ON syslog_records "
            f"FOR INSERT WITH CHECK ({scoped_write})"
        )
    )
    op.execute(
        sa.text(
            f"CREATE POLICY syslog_records_update ON syslog_records "
            f"FOR UPDATE USING ({scoped_read}) WITH CHECK ({scoped_write})"
        )
    )
    op.execute(
        sa.text(
            f"CREATE POLICY syslog_records_delete ON syslog_records "
            f"FOR DELETE USING ({scoped_read})"
        )
    )


def downgrade() -> None:
    for policy in (
        "syslog_records_delete",
        "syslog_records_update",
        "syslog_records_insert",
        "syslog_records_select",
    ):
        op.execute(sa.text(f"DROP POLICY IF EXISTS {policy} ON syslog_records"))
    op.execute(sa.text("ALTER TABLE syslog_records NO FORCE ROW LEVEL SECURITY"))
    op.execute(sa.text("ALTER TABLE syslog_records DISABLE ROW LEVEL SECURITY"))

    op.drop_index("ix_syslog_records_tenant_resolution_reason", table_name="syslog_records")
    op.drop_index("ix_syslog_records_tenant_resolution_status", table_name="syslog_records")
    op.drop_index("ix_syslog_records_tenant_resolution_source", table_name="syslog_records")
    op.drop_constraint(
        "ck_syslog_records_tenant_resolution", "syslog_records", type_="check"
    )
    op.drop_constraint("fk_syslog_records_tenant_id", "syslog_records", type_="foreignkey")

    # Restore the pre-migration representation.  Deterministically backfilled
    # rows return to NULL; an invalid claimed value is restored exactly.
    op.execute(
        sa.text(
            """
            UPDATE syslog_records
            SET tenant_id = CASE
                WHEN tenant_resolution_source = 'deterministic_backfill' THEN NULL
                WHEN tenant_resolution_source = 'invalid_existing' THEN claimed_tenant_id
                ELSE tenant_id
            END
            WHERE tenant_resolution_source IN ('deterministic_backfill', 'invalid_existing')
            """
        )
    )
    op.drop_column("syslog_records", "tenant_resolution_source")
    op.drop_column("syslog_records", "tenant_resolution_candidates")
    op.drop_column("syslog_records", "tenant_resolution_reason")
    op.drop_column("syslog_records", "tenant_resolution_status")
    op.drop_column("syslog_records", "claimed_tenant_id")
