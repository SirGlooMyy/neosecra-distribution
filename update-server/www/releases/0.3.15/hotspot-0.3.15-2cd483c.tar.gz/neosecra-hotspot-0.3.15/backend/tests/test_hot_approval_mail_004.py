"""Focused regression tests for HOT-APPROVAL-MAIL-004."""
from __future__ import annotations

import hashlib
import html as html_lib
import re
import uuid
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest import mock
from urllib.parse import parse_qs, urlsplit

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from app.core.config import settings
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.portal.approval import (
    ApprovalLinkConfigurationError,
    build_approval_urls,
    render_approval_email,
    resolve_public_base_url,
    session_status_projection,
)
from app.modules.portal import public_router
from app.modules.sessions import service as sessions_service
from app.modules.sessions.schemas import GuestSessionOut
from app.modules.system import email_service


def _request(
    *,
    headers: dict[str, str] | None = None,
    client: tuple[str, int] = ("127.0.0.1", 1234),
    root_path: str = "",
) -> Request:
    raw_headers = [(key.lower().encode(), value.encode()) for key, value in (headers or {}).items()]
    return Request({
        "type": "http",
        "method": "GET",
        "path": "/portal/public/approval",
        "raw_path": b"/portal/public/approval",
        "query_string": b"",
        "headers": raw_headers,
        "client": client,
        "server": ("internal", 8000),
        "scheme": "http",
        "root_path": root_path,
    })


class _Result:
    def __init__(self, value):
        self.value = value

    def scalar_one_or_none(self):
        return self.value


class _Db:
    def __init__(self, session):
        self.session = session
        self.commits = 0

    async def execute(self, _statement):
        return _Result(self.session)

    async def get(self, _model, _id):
        return self.session

    async def flush(self):
        return None

    async def commit(self):
        self.commits += 1

    async def refresh(self, _session):
        return None


def _session(
    *,
    token: str,
    expires_at: datetime | None = None,
    customer_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
):
    session_id = uuid.uuid4()
    customer_id = customer_id or uuid.uuid4()
    return SimpleNamespace(
        id=session_id,
        customer_id=customer_id,
        device_id=device_id,
        mac="AA:BB:CC:DD:EE:FF",
        ip="192.0.2.10",
        phone=None,
        started_at=datetime.now(timezone.utc),
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        status="pending",
        authorize_ok=False,
        authorization_status="pending",
        authorization_attempts=0,
        authorization_error_message=None,
        external_session_id=None,
        ended_at=None,
        meta={"approval": {
            "required": True,
            "status": "pending",
            "token_hash": hashlib.sha256(token.encode()).hexdigest(),
            "token_binding_hash": hashlib.sha256(f"{session_id}:{token}".encode()).hexdigest(),
            "token_expires_at": (expires_at or datetime.now(timezone.utc) + timedelta(minutes=30)).isoformat(),
            "approval_correlation_id": str(uuid.uuid4()),
            "source": "public_link",
        }},
    )


def test_approval_url_encodes_token_and_preserves_proxy_path(monkeypatch):
    monkeypatch.setattr(settings, "PORTAL_PUBLIC_BASE_URL", "https://access.example.test/neosecra/")
    session_id = uuid.uuid4()
    token = "generated-token+/=?"
    urls = build_approval_urls(session_id, token)
    parsed = urlsplit(urls["approve"])
    assert parsed.scheme == "https"
    assert parsed.netloc == "access.example.test"
    assert parsed.path == f"/neosecra/portal/public/approval/{session_id}"
    assert parse_qs(parsed.query) == {"token": [token], "decision": ["approve"]}
    assert "/portal/public/approval/" in urls["reject"]
    content = render_approval_email(
        approve_url=urls["approve"],
        reject_url=urls["reject"],
        requester="Ada",
        location="Lobby",
        requested_at=None,
        expires_at=None,
    )
    assert f"/neosecra/portal/public/approval/{session_id}" in content.html


def test_reverse_proxy_headers_are_explicitly_trusted(monkeypatch):
    monkeypatch.setattr(settings, "PORTAL_PUBLIC_BASE_URL", "")
    monkeypatch.setattr(settings, "ENVIRONMENT", "development")
    monkeypatch.setattr(settings, "PORTAL_TRUST_PROXY_HEADERS", True)
    monkeypatch.setattr(settings, "PORTAL_TRUSTED_PROXY_IPS", "127.0.0.1")
    request = _request(headers={
        "x-forwarded-proto": "https",
        "x-forwarded-host": "wifi.example.test",
        "x-forwarded-prefix": "/customer-a",
    })
    assert resolve_public_base_url(request) == "https://wifi.example.test/customer-a"


def test_proxy_headers_fail_closed_without_allowlist(monkeypatch):
    monkeypatch.setattr(settings, "PORTAL_PUBLIC_BASE_URL", "")
    monkeypatch.setattr(settings, "ENVIRONMENT", "development")
    monkeypatch.setattr(settings, "PORTAL_TRUST_PROXY_HEADERS", True)
    monkeypatch.setattr(settings, "PORTAL_TRUSTED_PROXY_IPS", "")
    with pytest.raises(ApprovalLinkConfigurationError):
        resolve_public_base_url(_request(headers={"x-forwarded-host": "wifi.example.test"}))


def test_untrusted_forwarded_headers_fail_closed_when_proxy_mode_is_enabled(monkeypatch):
    monkeypatch.setattr(settings, "PORTAL_PUBLIC_BASE_URL", "")
    monkeypatch.setattr(settings, "ENVIRONMENT", "development")
    monkeypatch.setattr(settings, "PORTAL_TRUST_PROXY_HEADERS", True)
    monkeypatch.setattr(settings, "PORTAL_TRUSTED_PROXY_IPS", "10.0.0.0/8")
    with pytest.raises(ApprovalLinkConfigurationError):
        resolve_public_base_url(_request(headers={"x-forwarded-host": "evil.example.test"}))


def test_production_requires_configured_public_origin(monkeypatch):
    monkeypatch.setattr(settings, "PORTAL_PUBLIC_BASE_URL", "")
    monkeypatch.setattr(settings, "ENVIRONMENT", "production")
    with pytest.raises(ApprovalLinkConfigurationError):
        resolve_public_base_url(_request())


def test_email_has_corporate_summary_both_ctas_and_plain_text_without_visible_token():
    token = "generated-only-token"
    content = render_approval_email(
        approve_url=f"https://access.test/portal/public/approval/{uuid.uuid4()}?token={token}&decision=approve",
        reject_url=f"https://access.test/portal/public/approval/{uuid.uuid4()}?token={token}&decision=reject",
        requester="Ada <script>alert(1)</script>",
        location="Lobby & Cafe",
        requested_at=datetime(2026, 8, 31, 10, 0, tzinfo=timezone.utc),
        expires_at=datetime(2026, 8, 31, 10, 30, tzinfo=timezone.utc),
    )
    assert "NeoSecra" in content.html
    assert "viewport" in content.html
    assert "Talep sahibi" in content.html and "Konum" in content.html
    assert content.html.count("role=\"button\"") == 2
    assert "<script>" not in content.html
    hrefs = [html_lib.unescape(item) for item in re.findall(r'href="([^"]+)"', content.html)]
    assert len(hrefs) == 2
    assert {parse_qs(urlsplit(item).query)["decision"][0] for item in hrefs} == {"approve", "reject"}
    assert all(parse_qs(urlsplit(item).query)["token"][0] == token for item in hrefs)
    visible = re.sub(r"<[^>]+>", " ", html_lib.unescape(content.html))
    assert token not in visible
    assert token not in content.text
    assert "Erişimi onayla:" in content.text and "Erişimi reddet:" in content.text


def test_email_renderer_rejects_tracking_or_non_http_action_urls():
    base = "https://access.test/portal/public/approval/" + str(uuid.uuid4())
    with pytest.raises(ApprovalLinkConfigurationError):
        render_approval_email(
            approve_url=f"{base}?token=generated-only-token&decision=approve&utm_source=mail",
            reject_url=f"{base}?token=generated-only-token&decision=reject",
            requester="Ada",
            location="Lobby",
            requested_at=None,
            expires_at=None,
        )
    with pytest.raises(ApprovalLinkConfigurationError):
        render_approval_email(
            approve_url="javascript:alert(1)?token=generated-only-token&decision=approve",
            reject_url=f"{base}?token=generated-only-token&decision=reject",
            requester="Ada",
            location="Lobby",
            requested_at=None,
            expires_at=None,
        )


@pytest.mark.asyncio
async def test_get_landing_never_mutates_and_escapes_hidden_token(monkeypatch):
    monkeypatch.setattr(settings, "DISABLE_RATE_LIMIT", True)
    token = "generated-token-<x>"
    session = _session(token=token)
    db = _Db(session)
    request = _request()
    response = await public_router.manager_approval_link(
        session.id, request, token=token, decision="approve", db=db
    )
    assert response.status_code == 200
    assert session.status == "pending"
    assert db.commits == 0
    assert "value=\"generated-token-&lt;x&gt;\"" in response.body.decode()
    rendered = response.body.decode()
    assert 'action="' in rendered
    assert "?token=" not in rendered.split("<form", 1)[1].split(">", 1)[0]


@pytest.mark.asyncio
async def test_public_token_tamper_replay_opposite_and_idempotency(monkeypatch):
    token = "generated-token-123456789"
    session = _session(token=token, device_id=uuid.uuid4())
    db = _Db(session)
    monkeypatch.setattr(sessions_service, "log_audit", mock.AsyncMock())
    monkeypatch.setattr(
        "app.modules.firewall_adapters.service.authorize_guest_service",
        mock.AsyncMock(return_value=SimpleNamespace(ok=True, message="authorized")),
    )

    with pytest.raises(HTTPException) as tamper:
        await sessions_service.approve_session_by_token(db, session.id, token + "x")
    assert tamper.value.status_code == 403

    first = await sessions_service.approve_session_by_token(db, session.id, token, decision="approve")
    assert first.status == "active"
    assert first.meta["approval"]["decision"] == "approve"
    assert first.meta["approval"]["token_used_at"]
    commits = db.commits
    replay = await sessions_service.approve_session_by_token(db, session.id, token, decision="approve")
    assert replay is session
    assert db.commits == commits

    with pytest.raises(HTTPException) as opposite:
        await sessions_service.approve_session_by_token(db, session.id, token, decision="reject")
    assert opposite.value.status_code == 409

    with pytest.raises(HTTPException) as whitespace_tamper:
        await sessions_service.approve_session_by_token(db, session.id, token + " ", decision="approve")
    assert whitespace_tamper.value.status_code == 403


@pytest.mark.asyncio
async def test_expired_token_is_terminal_and_audited(monkeypatch):
    token = "generated-token-expired"
    session = _session(token=token, expires_at=datetime.now(timezone.utc) - timedelta(seconds=1))
    db = _Db(session)
    audit = mock.AsyncMock()
    monkeypatch.setattr(sessions_service, "log_audit", audit)
    with pytest.raises(HTTPException) as expired:
        await sessions_service.approve_session_by_token(db, session.id, token)
    assert expired.value.status_code == 410
    assert session.meta["approval"]["status"] == "expired"
    with pytest.raises(HTTPException) as replay:
        await sessions_service.approve_session_by_token(db, session.id, token)
    assert replay.value.status_code == 410
    assert audit.await_args.kwargs["tenant_id"] == str(session.customer_id)
    assert "token" not in str(audit.await_args.kwargs["details"]).lower()


@pytest.mark.asyncio
async def test_used_token_cannot_be_replayed_after_expiry(monkeypatch):
    token = "generated-token-used-expired"
    session = _session(
        token=token,
        expires_at=datetime.now(timezone.utc) - timedelta(seconds=1),
    )
    session.meta["approval"].update(
        {
            "status": "pending",
            "decision": "approve",
            "decision_at": datetime.now(timezone.utc).isoformat(),
            "token_used_at": datetime.now(timezone.utc).isoformat(),
            "last_attempt_status": "failed",
        }
    )
    db = _Db(session)
    with pytest.raises(HTTPException) as exc:
        await sessions_service.approve_session_by_token(db, session.id, token)
    assert exc.value.status_code == 410
    assert session.status == "pending"


@pytest.mark.asyncio
async def test_unknown_decision_is_fail_closed(monkeypatch):
    monkeypatch.setattr(settings, "DISABLE_RATE_LIMIT", True)
    session = _session(token="generated-token-unknown")
    db = _Db(session)
    response = await public_router.process_manager_approval(
        session.id,
        _request(),
        token="generated-token-unknown",
        decision="maybe",
        db=db,
    )
    assert response.status_code == 400
    assert session.status == "pending"


@pytest.mark.asyncio
async def test_cross_session_binding_rejects_same_digest(monkeypatch):
    token = "generated-token-cross-tenant"
    first = _session(token=token)
    second = _session(token=token)
    # Simulate a tampered/copied legacy digest: the new binding hash must stop
    # a bearer token from authorizing another session.
    second.meta["approval"]["token_binding_hash"] = first.meta["approval"]["token_binding_hash"]
    db = _Db(second)
    with pytest.raises(HTTPException) as exc:
        await sessions_service.approve_session_by_token(db, second.id, token)
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_smtp_message_contains_explicit_plain_and_html_alternatives(monkeypatch):
    captured = {}

    class FakeSMTP:
        def __init__(self, *_args, **_kwargs):
            pass

        def ehlo(self):
            return None

        def send_message(self, message):
            captured["message"] = message

        def quit(self):
            return None

    cfg = SimpleNamespace(
        smtp_password_encrypted=None,
        from_address="noreply@example.test",
        from_name="NeoSecra Hotspot",
        smtp_use_ssl=False,
        smtp_use_tls=False,
        smtp_host="smtp.example.test",
        smtp_port=25,
        smtp_username=None,
    )
    monkeypatch.setattr(email_service, "get_config", mock.AsyncMock(return_value=cfg))
    monkeypatch.setattr("smtplib.SMTP", FakeSMTP)
    ok = await email_service.send_email(
        "manager@example.test",
        "NeoSecra Hotspot | Yönetici onayı gerekli",
        "<p>HTML CTA</p>",
        db=mock.AsyncMock(),
        text_body="Plain CTA",
    )
    assert ok is True
    message = captured["message"]
    payload = message.get_payload()
    assert len(payload) == 2
    assert payload[0].get_content_type() == "text/plain"
    assert payload[0].get_payload(decode=True).decode().strip() == "Plain CTA"
    assert payload[1].get_content_type() == "text/html"


@pytest.mark.asyncio
async def test_smtp_rejects_header_control_characters_without_connecting(monkeypatch):
    smtp = mock.Mock()
    monkeypatch.setattr("smtplib.SMTP", smtp)
    ok = await email_service.send_email(
        "manager@example.test\r\nBcc: attacker@example.test",
        "NeoSecra approval",
        "<p>body</p>",
        db=mock.AsyncMock(),
    )
    assert ok is False
    smtp.assert_not_called()


def test_session_create_audit_projection_redacts_bearer_and_manager_pii():
    projection = sessions_service._approval_audit_projection({
        "form_data": {"full_name": "Ada", "phone": "+905551112233"},
        "approval": {
            "required": True,
            "status": "pending",
            "token_hash": "digest-only",
            "poll_token_hash": "poll-digest",
            "manager_emails": ["manager@example.test"],
            "token_expires_at": "2026-08-31T10:30:00+00:00",
            "approval_correlation_id": "corr-123",
        },
    })
    rendered = str(projection)
    assert "digest-only" not in rendered
    assert "poll-digest" not in rendered
    assert "manager@example.test" not in rendered
    assert "full_name" not in rendered
    assert projection["approval"]["approval_correlation_id"] == "corr-123"


def test_session_api_projection_redacts_approval_digests():
    safe = GuestSessionOut.redact_approval_secrets({
        "approval": {
            "token_hash": "digest",
            "token_binding_hash": "binding",
            "poll_token_hash": "poll",
            "manager_emails": ["manager@example.test"],
            "status": "pending",
        },
        "group_policy": {"name": "Guest"},
    })
    assert safe["approval"] == {"status": "pending"}
    assert safe["group_policy"] == {"name": "Guest"}


def test_polling_projection_fails_closed_and_never_trusts_approval_metadata():
    session = SimpleNamespace(
        id=uuid.uuid4(),
        status="pending",
        authorize_ok=False,
        authorization_status="pending",
        ended_at=None,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
        meta={"approval": {"required": True, "status": "approved"}},
    )
    with pytest.raises(ValueError):
        session_status_projection(session, token=None)

    poll_token = "poll-token-for-status"
    session.meta["approval"]["poll_token_hash"] = hashlib.sha256(poll_token.encode()).hexdigest()
    projection = session_status_projection(session, poll_token)
    assert projection["is_active"] is False
    assert projection["approval_status"] == "pending"
    assert projection["authorize_ok"] is False

    session.status = "active"
    session.authorize_ok = False
    session.authorization_status = "authorized"
    stale_projection = session_status_projection(session, poll_token)
    assert stale_projection["status"] == "pending"
    assert stale_projection["authorization_status"] == "pending"
    assert stale_projection["approval_status"] == "pending"


def test_polling_projection_surfaces_expired_approval_token_without_mutation():
    session = SimpleNamespace(
        id=uuid.uuid4(),
        status="pending",
        authorize_ok=False,
        authorization_status="pending",
        ended_at=None,
        # The guest lease can outlive the manager decision token.
        expires_at=datetime.now(timezone.utc) + timedelta(hours=2),
        meta={
            "approval": {
                "required": True,
                "status": "pending",
                "token_expires_at": (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(),
            }
        },
    )
    poll_token = "poll-token-expiry"
    session.meta["approval"]["poll_token_hash"] = hashlib.sha256(poll_token.encode()).hexdigest()
    projection = session_status_projection(session, poll_token)
    assert projection["status"] == "pending"
    assert projection["approval_status"] == "expired"
    assert session.meta["approval"]["status"] == "pending"


@pytest.mark.asyncio
async def test_public_status_route_requires_poll_token(monkeypatch):
    monkeypatch.setattr(settings, "DISABLE_RATE_LIMIT", True)
    session = SimpleNamespace(
        id=uuid.uuid4(),
        status="pending",
        authorize_ok=False,
        authorization_status="pending",
        ended_at=None,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
        meta={"approval": {"required": True}},
    )
    db = _Db(session)
    with pytest.raises(HTTPException) as exc:
        await public_router.portal_session_status(session.id, _request(), token=None, db=db)
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_public_status_route_requires_poll_token_for_active_sessions(monkeypatch):
    monkeypatch.setattr(settings, "DISABLE_RATE_LIMIT", True)
    session = SimpleNamespace(
        id=uuid.uuid4(),
        status="active",
        authorize_ok=True,
        authorization_status="authorized",
        ended_at=None,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
        meta={},
    )
    db = _Db(session)
    with pytest.raises(HTTPException) as exc:
        await public_router.portal_session_status(session.id, _request(), token=None, db=db)
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_landing_form_keeps_forwarded_mount_prefix(monkeypatch):
    monkeypatch.setattr(settings, "DISABLE_RATE_LIMIT", True)
    monkeypatch.setattr(settings, "PORTAL_PUBLIC_BASE_URL", "")
    monkeypatch.setattr(settings, "ENVIRONMENT", "development")
    monkeypatch.setattr(settings, "PORTAL_TRUST_PROXY_HEADERS", True)
    monkeypatch.setattr(settings, "PORTAL_TRUSTED_PROXY_IPS", "127.0.0.1")
    token = "generated-token-proxy-prefix"
    session = _session(token=token)
    db = _Db(session)
    request = _request(
        headers={
            "x-forwarded-proto": "https",
            "x-forwarded-host": "access.example.test",
            "x-forwarded-prefix": "/customer-a",
        }
    )
    response = await public_router.manager_approval_link(
        session.id, request, token=token, decision="approve", db=db
    )
    body = response.body.decode()
    assert f'action="/customer-a/portal/public/approval/{session.id}"' in body


@pytest.mark.asyncio
async def test_failed_firewall_consumes_public_decision_but_admin_can_retry(monkeypatch):
    token = "generated-token-firewall-failure"
    session = _session(token=token)
    session.device_id = uuid.uuid4()
    db = _Db(session)
    monkeypatch.setattr(sessions_service, "log_audit", mock.AsyncMock())
    adapter = mock.AsyncMock(
        side_effect=[
            SimpleNamespace(ok=False, message="provider detail"),
            SimpleNamespace(ok=True, message="authorized"),
        ]
    )
    monkeypatch.setattr(
        "app.modules.firewall_adapters.service.authorize_guest_service", adapter
    )

    first = await sessions_service.approve_session_by_token(
        db, session.id, token, decision="approve"
    )
    assert first.status == "pending"
    assert first.authorize_ok is False
    assert first.meta["approval"]["decision"] == "approve"
    assert first.meta["approval"]["token_used_at"]
    assert first.meta["approval"]["decision_outcome"] == "authorization_failed"

    retried = await sessions_service.approve_session(
        db,
        session.id,
        ScopeContext(level=TenantLevel.CUSTOMER, customer_id=session.customer_id),
        actor_id=uuid.uuid4(),
    )
    assert retried.status == "active"
    assert retried.meta["approval"]["status"] == "approved"

    replay = await sessions_service.approve_session_by_token(
        db, session.id, token, decision="approve"
    )
    assert replay is session
    assert adapter.await_count == 2


@pytest.mark.asyncio
async def test_public_router_approval_response_security_headers(monkeypatch):
    monkeypatch.setattr(settings, "DISABLE_RATE_LIMIT", True)
    token = "generated-token-sec-headers"
    session = _session(token=token)
    db = _Db(session)
    request = _request()

    response = await public_router.manager_approval_link(
        session.id, request, token=token, decision="approve", db=db
    )
    assert response.status_code == 200
    assert response.headers["cache-control"] == "no-store, max-age=0"
    assert response.headers["pragma"] == "no-cache"
    assert response.headers["referrer-policy"] == "no-referrer"
    assert response.headers["x-frame-options"] == "DENY"
    assert response.headers["x-content-type-options"] == "nosniff"
    assert "default-src 'none'" in response.headers["content-security-policy"]


@pytest.mark.asyncio
async def test_public_router_post_process_approval_lifecycle_e2e(monkeypatch):
    monkeypatch.setattr(settings, "DISABLE_RATE_LIMIT", True)
    token = "generated-token-post-e2e"
    session = _session(token=token, device_id=uuid.uuid4())
    db = _Db(session)
    monkeypatch.setattr(sessions_service, "log_audit", mock.AsyncMock())
    monkeypatch.setattr(
        "app.modules.firewall_adapters.service.authorize_guest_service",
        mock.AsyncMock(return_value=SimpleNamespace(ok=True, message="authorized")),
    )

    # POST Approve
    resp = await public_router.process_manager_approval(
        session.id, _request(), token=token, decision="approve", db=db
    )
    assert resp.status_code == 200
    assert "onaylandı" in resp.body.decode()
    assert session.status == "active"
    assert session.meta["approval"]["decision"] == "approve"

    # POST Replay (Idempotent)
    resp_replay = await public_router.process_manager_approval(
        session.id, _request(), token=token, decision="approve", db=db
    )
    assert resp_replay.status_code == 200
    assert "onaylandı" in resp_replay.body.decode()

    # POST Conflicting Decision (Reject on approved session) -> 409
    resp_conflict = await public_router.process_manager_approval(
        session.id, _request(), token=token, decision="reject", db=db
    )
    assert resp_conflict.status_code == 409
    assert "Hotspot onayı işlenemedi" in resp_conflict.body.decode()


@pytest.mark.asyncio
async def test_public_router_post_reject_lifecycle_e2e(monkeypatch):
    monkeypatch.setattr(settings, "DISABLE_RATE_LIMIT", True)
    token = "generated-token-reject-e2e"
    session = _session(token=token)
    db = _Db(session)
    monkeypatch.setattr(sessions_service, "log_audit", mock.AsyncMock())

    # POST Reject
    resp = await public_router.process_manager_approval(
        session.id, _request(), token=token, decision="reject", db=db
    )
    assert resp.status_code == 200
    assert "reddedildi" in resp.body.decode()
    assert session.status == "closed"
    assert session.meta["approval"]["decision"] == "reject"


def test_base_url_host_poisoning_and_control_chars(monkeypatch):
    monkeypatch.setattr(settings, "PORTAL_PUBLIC_BASE_URL", "")
    monkeypatch.setattr(settings, "ENVIRONMENT", "development")
    monkeypatch.setattr(settings, "PORTAL_TRUST_PROXY_HEADERS", True)
    monkeypatch.setattr(settings, "PORTAL_TRUSTED_PROXY_IPS", "127.0.0.1")

    with pytest.raises(ApprovalLinkConfigurationError):
        resolve_public_base_url(_request(headers={"x-forwarded-host": "evil.com\r\nInjected-Header: 1"}))

    with pytest.raises(ApprovalLinkConfigurationError):
        resolve_public_base_url(_request(headers={"x-forwarded-host": "evil.com", "x-forwarded-prefix": "/path//traversal/.."}))
