"""Regression coverage for the traffic materialization SQL expressions."""
from __future__ import annotations

import asyncio

from sqlalchemy.dialects import postgresql

from app.modules.traffic.aggregation import aggregate_traffic


class _Result:
    def scalars(self):
        return self

    def all(self):
        return []


class _Database:
    def __init__(self):
        self.statements = []

    async def execute(self, statement):
        self.statements.append(statement)
        return _Result()

    async def commit(self):
        return None


def test_aggregate_traffic_reuses_date_trunc_bind_parameters():
    db = _Database()
    result = asyncio.run(aggregate_traffic(db, lookback_hours=1))

    assert result == {"sessions": 0, "hourly_buckets": 0, "daily_buckets": 0}
    assert len(db.statements) == 5

    # The SELECT and GROUP BY sides must share one bind parameter for each
    # bucket expression. Separate date_trunc() calls produce date_trunc_2 and
    # PostgreSQL can reject the resulting aggregate as not grouped.
    for statement in db.statements[2:]:
        compiled = statement.compile(dialect=postgresql.dialect())
        bucket_params = [key for key in compiled.params if key.startswith("date_trunc_")]
        assert bucket_params == ["date_trunc_1"]
