"""Traffic module integration tests — trend, dashboard, permissions."""
import uuid
from datetime import datetime, timezone

import pytest
import unittest.mock as mock
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.traffic.models import TopTalker

client = TestClient(app)


@pytest.fixture(autouse=True)
def _mock_redis():
    with mock.patch("app.core.security._get_redis", return_value=mock.AsyncMock()) as mr:
        mr.return_value.get.return_value = None
        mr.return_value.exists.return_value = 0
        yield


def _user(role="super_admin", customer_id=None):
    return User(
        id=uuid.uuid4(), email="admin@test.io", hashed_password="x",
        role=role, is_active=True,
        tenant_id=None, partner_id=None, customer_id=customer_id, location_id=None,
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[],
    )


now = datetime.now(timezone.utc)


def _mock_talker(**kw):
    t = mock.MagicMock(spec=TopTalker)
    t.mac = kw.get("mac", "AA:BB:CC:DD:EE:FF")
    t.phone = kw.get("phone", "5551234567")
    t.bytes_in = kw.get("bytes_in", 500000)
    t.bytes_out = kw.get("bytes_out", 1000000)
    t.session_count = kw.get("session_count", 25)
    t.rank = kw.get("rank", 1)
    return t


class TestTrafficTrend:
    def test_returns_data(self):
        cid = uuid.uuid4()
        db = mock.AsyncMock()

        # hourly: r.all() returns list of tuples
        hourly_rows = [(now, 1000, 2000, 10, 5)]
        # daily: r.all() returns list of tuples (date, sum_bytes_in, sum_bytes_out, sum_sessions, max_peak)
        daily_rows = [(now.date(), 10000, 20000, 50, 20)]
        # top_talkers: r.scalars().all()
        talkers = [_mock_talker()]
        # summary: r.one() returns a tuple
        summary_row = (100000, 200000, 500, 30, 15.5, 80)

        def execute_side_effect(q):
            r = mock.MagicMock()
            if hasattr(q, 'where'):
                str(q.where_clause) if hasattr(q, 'where_clause') else ""
            if any("TopTalker" in str(a) for a in getattr(q, 'froms', [])):
                r.scalars.return_value.all.return_value = talkers
            else:
                r.all.return_value = hourly_rows
            return r

        r1 = mock.MagicMock()
        r1.all.return_value = hourly_rows
        r2 = mock.MagicMock()
        r2.all.return_value = daily_rows
        r3 = mock.MagicMock()
        r3.scalars.return_value.all.return_value = talkers
        r4 = mock.MagicMock()
        r4.one.return_value = summary_row

        db.execute = mock.AsyncMock(side_effect=[r1, r2, r3, r4])

        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user(customer_id=cid)

        resp = client.get("/api/v1/traffic/traffic/trend?days=7")
        app.dependency_overrides.clear()
        assert resp.status_code == 200
        data = resp.json()
        assert "hourly" in data
        assert "daily" in data
        assert "top_talkers" in data
        assert "summary" in data

    def test_empty_data(self):
        cid = uuid.uuid4()
        db = mock.AsyncMock()

        empty_res = mock.MagicMock()
        empty_res.all.return_value = []
        empty_res.scalars.return_value.all.return_value = []
        empty_res.one.return_value = (0, 0, 0, 0, None, 0)
        empty_res.scalar.return_value = 0

        db.execute = mock.AsyncMock(return_value=empty_res)

        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user(customer_id=cid)

        resp = client.get("/api/v1/traffic/traffic/trend")
        app.dependency_overrides.clear()
        assert resp.status_code == 200
        data = resp.json()
        assert data["hourly"] == []
        assert data["daily"] == []


class TestTrafficDashboard:
    def test_returns_data(self):
        cid = uuid.uuid4()
        db = mock.AsyncMock()
        talkers = [_mock_talker()]

        r1 = mock.MagicMock()
        r1.scalar.return_value = 1500000
        r2 = mock.MagicMock()
        r2.scalar.return_value = 50000000
        r3 = mock.MagicMock()
        r3.all.return_value = [(now.date(), 50000, 100000)]
        r4 = mock.MagicMock()
        r4.all.return_value = [(uuid.uuid4(), 2000000)]
        r5 = mock.MagicMock()
        r5.scalars.return_value.all.return_value = talkers

        db.execute = mock.AsyncMock(side_effect=[r1, r2, r3, r4, r5])

        app.dependency_overrides[get_db] = lambda: db
        app.dependency_overrides[get_current_user] = lambda: _user(customer_id=cid)

        resp = client.get("/api/v1/traffic/traffic/dashboard")
        app.dependency_overrides.clear()
        assert resp.status_code == 200
        data = resp.json()
        assert "total_bandwidth" in data
        assert "current_throughput" in data
        assert "daily_usage" in data
        assert "top_talkers" in data
