"""Focused checks for HOT-LEGACY-RLS-CLOSURE-009.

PostgreSQL checks are opt-in via ``SYSLOG_RLS_TEST_DATABASE_URL``.  The normal
repository suite remains database-free and reports those checks as
``SKIPPED (PG_REQUIRED)`` when no isolated PostgreSQL fixture is configured.
"""
from __future__ import annotations

import os
from pathlib import Path
import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest
from sqlalchemy import text
from sqlalchemy.exc import MultipleResultsFound

from app.modules.tenants.models import Tenant  # noqa: F401 - register FK target
from app.modules.syslog.models import SyslogRecord
from app.modules.syslog.repository import (
    resolve_firewall_log_context,
    resolve_tenant_for_hostname,
)
from app.modules.syslog.service import _record_tenant_id
from app.core.rls import set_syslog_context


MIGRATION_PATH = (
    Path(__file__).resolve().parents[1]
    / "alembic"
    / "versions"
    / "f9a0b1c2d3e4_harden_legacy_syslog_rls.py"
)


def _migration_source() -> str:
    return MIGRATION_PATH.read_text(encoding="utf-8")


def test_legacy_model_retains_quarantine_provenance_and_tenant_fk():
    tenant_column = SyslogRecord.__table__.c.tenant_id
    assert any(str(fk.column) == "tenants.id" for fk in tenant_column.foreign_keys)
    assert SyslogRecord.__table__.c.tenant_resolution_status.nullable is False
    assert SyslogRecord.__table__.c.tenant_resolution_candidates.nullable is False
    assert SyslogRecord.__table__.c.tenant_resolution_source.nullable is False
    assert SyslogRecord.__table__.c.claimed_tenant_id.nullable is True


def test_migration_backfill_is_deterministic_and_downgrade_is_reversible():
    source = _migration_source()
    assert 'down_revision: Union[str, None] = "f8a9b0c1d2e3"' in source
    status_start = source.index('"tenant_resolution_status"')
    status_end = source.index('"tenant_resolution_reason"')
    assert "sa.String(length=32)" in source[status_start:status_end]
    assert "candidate_count = 1" in source
    assert "ambiguous_tenant" in source
    assert "no_deterministic_tenant" in source
    assert "invalid_existing_tenant" in source
    assert "tenant_resolution_candidates" in source
    assert "ix_syslog_records_tenant_resolution_source" in source
    assert "server_default=sa.text(\"'api_ingest'\")" in source
    assert "ALTER TABLE syslog_records FORCE ROW LEVEL SECURITY" in source
    assert "ALTER TABLE syslog_records NO FORCE ROW LEVEL SECURITY" in source
    for policy in (
        "syslog_records_select",
        "syslog_records_insert",
        "syslog_records_update",
        "syslog_records_delete",
    ):
        assert f"CREATE POLICY {policy}" in source
    # Downgrade restores deterministic backfills and invalid historical claims
    # rather than silently dropping the original representation.
    assert "tenant_resolution_source = 'deterministic_backfill' THEN NULL" in source
    assert "tenant_resolution_source = 'invalid_existing' THEN claimed_tenant_id" in source


@pytest.mark.asyncio
async def test_hostname_ambiguity_fails_closed():
    db = AsyncMock()
    result = MagicMock()
    result.one_or_none.side_effect = MultipleResultsFound()
    db.execute.return_value = result

    assert await resolve_tenant_for_hostname(db, "shared-firewall") is None
    assert db.execute.await_count == 1


@pytest.mark.asyncio
async def test_firewall_context_ambiguity_fails_closed():
    db = AsyncMock()
    result = MagicMock()
    result.one_or_none.side_effect = MultipleResultsFound()
    db.execute.return_value = result

    assert await resolve_firewall_log_context(db, "shared-firewall", None) is None
    assert db.execute.await_count == 1


@pytest.mark.asyncio
async def test_single_tenant_fallback_does_not_choose_oldest_customer(monkeypatch):
    from app.modules.syslog import repository

    monkeypatch.setattr(repository.settings, "SINGLE_TENANT_MODE", True)
    db = AsyncMock()
    no_match = MagicMock()
    no_match.one_or_none.return_value = None
    no_match_source = MagicMock()
    no_match_source.one_or_none.return_value = None
    no_match_hostname = MagicMock()
    no_match_hostname.one_or_none.return_value = None
    no_match_source_fallback = MagicMock()
    no_match_source_fallback.one_or_none.return_value = None
    fallback = MagicMock()
    fallback.all.return_value = [
        (uuid.uuid4(), uuid.uuid4()),
        (uuid.uuid4(), uuid.uuid4()),
    ]
    db.execute.side_effect = [
        no_match,
        no_match_source,
        no_match_hostname,
        no_match_source_fallback,
        fallback,
    ]

    assert await resolve_firewall_log_context(db, "unknown-firewall", None) is None


def test_unowned_legacy_record_cannot_enter_worker_processing():
    record = SyslogRecord(id=uuid.uuid4(), message="unresolved", tenant_id=None)
    with pytest.raises(ValueError, match="no resolved tenant"):
        _record_tenant_id(record)


def test_trigger_worker_requires_explicit_tenant_context():
    from app.modules.workers.tasks import trigger_syslog_alerts

    result = trigger_syslog_alerts.run(str(uuid.uuid4()))
    assert result == {"ok": False, "error": "tenant context required"}


def test_trigger_worker_rejects_malformed_tenant_context():
    from app.modules.workers.tasks import trigger_syslog_alerts

    result = trigger_syslog_alerts.run(str(uuid.uuid4()), "not-a-uuid")
    assert result == {"ok": False, "error": "invalid record or tenant id"}


@pytest.mark.asyncio
async def test_syslog_context_rejects_missing_tenant_before_session_use():
    db = MagicMock()
    with pytest.raises(ValueError, match="tenant context is required"):
        await set_syslog_context(db, None)


@pytest.mark.asyncio
async def test_syslog_batch_reapplies_context_after_each_trigger_commit(monkeypatch):
    from app.modules.syslog import service

    tenant_id = uuid.uuid4()
    records = [
        SyslogRecord(id=uuid.uuid4(), tenant_id=tenant_id, message="one"),
        SyslogRecord(id=uuid.uuid4(), tenant_id=tenant_id, message="two"),
    ]
    db = AsyncMock()
    set_context = AsyncMock()
    fire = AsyncMock(return_value=[])
    monkeypatch.setattr(service, "set_syslog_context", set_context)
    monkeypatch.setattr(service, "fire_triggers", fire)
    monkeypatch.setattr(service.settings, "CLICKHOUSE_ENABLED", False)

    await service.process_syslog_batch(db, records)

    assert set_context.await_count == 2
    assert all(call.args == (db, tenant_id) for call in set_context.await_args_list)
    assert fire.await_count == 2


@pytest.mark.asyncio
async def test_syslog_batch_rolls_back_failed_trigger_before_next_context(monkeypatch):
    from app.modules.syslog import service

    tenant_id = uuid.uuid4()
    records = [
        SyslogRecord(id=uuid.uuid4(), tenant_id=tenant_id, message="one"),
        SyslogRecord(id=uuid.uuid4(), tenant_id=tenant_id, message="two"),
    ]
    db = AsyncMock()
    set_context = AsyncMock()
    fire = AsyncMock(side_effect=[RuntimeError("trigger failed"), []])
    monkeypatch.setattr(service, "set_syslog_context", set_context)
    monkeypatch.setattr(service, "fire_triggers", fire)
    monkeypatch.setattr(service.settings, "CLICKHOUSE_ENABLED", False)

    await service.process_syslog_batch(db, records)

    assert db.rollback.await_count == 1
    assert set_context.await_count == 2
    assert fire.await_count == 2


def test_trigger_worker_rejects_cross_tenant_record(monkeypatch):
    from app.modules.workers import tasks

    requested_tenant = uuid.uuid4()
    stored_tenant = uuid.uuid4()
    record = SyslogRecord(
        id=uuid.uuid4(),
        tenant_id=stored_tenant,
        message="cross-tenant",
    )
    db = AsyncMock()
    db.get.return_value = record

    class _Session:
        async def __aenter__(self):
            return db

        async def __aexit__(self, exc_type, exc, tb):
            return False

    monkeypatch.setattr(tasks, "WorkerSession", _Session)
    result = tasks.trigger_syslog_alerts.run(str(record.id), str(requested_tenant))
    assert result == {"ok": False, "error": "tenant scope mismatch"}
    db.get.assert_awaited_once()


@pytest.mark.skipif(
    not os.environ.get("SYSLOG_RLS_TEST_DATABASE_URL"),
    reason="PG_REQUIRED: SYSLOG_RLS_TEST_DATABASE_URL is not configured",
)
@pytest.mark.asyncio
async def test_postgres_non_superuser_cannot_insert_cross_tenant_row():
    from sqlalchemy.ext.asyncio import create_async_engine

    engine = create_async_engine(os.environ["SYSLOG_RLS_TEST_DATABASE_URL"])
    try:
        async with engine.connect() as conn:
            role = await conn.execute(
                text(
                    "SELECT rolsuper FROM pg_roles "
                    "WHERE rolname = current_user"
                )
            )
            if role.scalar_one_or_none() is True:
                pytest.skip("PG_REQUIRED: configured role is a superuser")

            await conn.execute(text("SELECT set_config('app.is_super_admin', 'true', true)"))
            tenant_rows = await conn.execute(
                text(
                    "SELECT DISTINCT tenant_id FROM syslog_records "
                    "WHERE tenant_id IS NOT NULL LIMIT 2"
                )
            )
            tenants = [row[0] for row in tenant_rows.fetchall()]
            if len(tenants) < 2:
                pytest.skip("PG_REQUIRED: isolated fixture needs two tenant records")

            await conn.execute(text("SELECT set_config('app.is_super_admin', 'false', true)"))
            await conn.execute(
                text("SELECT set_config('app.tenant_id', :tenant_id, true)"),
                {"tenant_id": str(tenants[0])},
            )
            with pytest.raises(Exception) as exc_info:
                await conn.execute(
                    text(
                        "INSERT INTO syslog_records "
                        "(id, tenant_id, message) VALUES "
                        "(:id, :tenant_id, :message)"
                    ),
                    {
                        "id": str(uuid.uuid4()),
                        "tenant_id": str(tenants[1]),
                        "message": "cross-tenant write must fail",
                    },
                )
            assert "row-level security" in str(exc_info.value).lower()
            await conn.rollback()
    finally:
        await engine.dispose()


@pytest.mark.skipif(
    not os.environ.get("SYSLOG_RLS_TEST_DATABASE_URL"),
    reason="PG_REQUIRED: SYSLOG_RLS_TEST_DATABASE_URL is not configured",
)
@pytest.mark.asyncio
async def test_postgres_syslog_rls_is_forced_and_missing_context_is_empty():
    from sqlalchemy.ext.asyncio import create_async_engine

    engine = create_async_engine(os.environ["SYSLOG_RLS_TEST_DATABASE_URL"])
    try:
        async with engine.connect() as conn:
            role = await conn.execute(
                text(
                    "SELECT rolsuper FROM pg_roles "
                    "WHERE rolname = current_user"
                )
            )
            if role.scalar_one_or_none() is True:
                pytest.skip("PG_REQUIRED: configured role is a superuser")

            rel = await conn.execute(
                text(
                    "SELECT relrowsecurity, relforcerowsecurity "
                    "FROM pg_class WHERE relname = 'syslog_records'"
                )
            )
            row = rel.one()
            assert row[0] is True
            assert row[1] is True

            policies = await conn.execute(
                text(
                    "SELECT policyname FROM pg_policies "
                    "WHERE tablename = 'syslog_records'"
                )
            )
            assert {
                item[0] for item in policies.fetchall()
            } >= {
                "syslog_records_select",
                "syslog_records_insert",
                "syslog_records_update",
                "syslog_records_delete",
            }

            await conn.execute(text("SELECT set_config('app.is_super_admin', 'false', true)"))
            await conn.execute(text("SELECT set_config('app.tenant_id', '', true)"))
            visible = await conn.execute(text("SELECT count(*) FROM syslog_records"))
            assert visible.scalar_one() == 0
    finally:
        await engine.dispose()


@pytest.mark.skipif(
    not os.environ.get("SYSLOG_RLS_TEST_DATABASE_URL"),
    reason="PG_REQUIRED: SYSLOG_RLS_TEST_DATABASE_URL is not configured",
)
@pytest.mark.asyncio
async def test_postgres_syslog_rls_cross_tenant_rows_are_invisible():
    from sqlalchemy.ext.asyncio import create_async_engine

    engine = create_async_engine(os.environ["SYSLOG_RLS_TEST_DATABASE_URL"])
    try:
        async with engine.connect() as conn:
            role = await conn.execute(
                text(
                    "SELECT rolsuper FROM pg_roles "
                    "WHERE rolname = current_user"
                )
            )
            if role.scalar_one_or_none() is True:
                pytest.skip("PG_REQUIRED: configured role is a superuser")

            # Use the trusted migration/test harness context to discover two
            # fixture tenants, then clear it before asserting the scoped read.
            await conn.execute(text("SELECT set_config('app.is_super_admin', 'true', true)"))
            tenant_rows = await conn.execute(
                text(
                    "SELECT DISTINCT tenant_id FROM syslog_records "
                    "WHERE tenant_id IS NOT NULL LIMIT 2"
                )
            )
            tenants = [row[0] for row in tenant_rows.fetchall()]
            if len(tenants) < 2:
                pytest.skip("PG_REQUIRED: isolated fixture needs two tenant records")

            await conn.execute(text("SELECT set_config('app.is_super_admin', 'false', true)"))
            await conn.execute(
                text("SELECT set_config('app.tenant_id', :tenant_id, true)"),
                {"tenant_id": str(tenants[0])},
            )
            cross = await conn.execute(
                text("SELECT count(*) FROM syslog_records WHERE tenant_id = :tenant_id"),
                {"tenant_id": tenants[1]},
            )
            assert cross.scalar_one() == 0
    finally:
        await engine.dispose()
