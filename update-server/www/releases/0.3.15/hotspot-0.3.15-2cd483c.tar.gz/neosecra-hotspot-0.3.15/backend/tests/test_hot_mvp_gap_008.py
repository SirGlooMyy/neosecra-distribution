"""Focused regression coverage for HOT-MVP-GAP-008 security closures."""
from __future__ import annotations

import logging
import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import HTTPException, Request

from app.core.ingest_auth import require_ingest_api_key
from app.modules.auth.models import User
from app.modules.auth.router import list_admin_users
from app.modules.syslog.schemas import SyslogRecordCreate
from app.api.v1.endpoints import syslog as syslog_endpoint


def _request(*, supplied_key: str = "", client_host: str = "203.0.113.10") -> Request:
    headers = [(b"x-api-key", supplied_key.encode("utf-8"))] if supplied_key else []
    return Request(
        {
            "type": "http",
            "method": "POST",
            "path": "/api/v1/syslog/records",
            "headers": headers,
            "client": (client_host, 5514),
            "scheme": "http",
            "query_string": b"",
        }
    )


def test_ingest_auth_log_never_contains_key_material(caplog):
    supplied = "supplied-ingest-secret"
    expected = "configured-ingest-secret"
    caplog.set_level(logging.INFO, logger="app.core.ingest_auth")

    with pytest.raises(HTTPException) as exc_info:
        require_ingest_api_key(
            _request(supplied_key=supplied),
            expected_key=expected,
            service="Syslog",
        )

    assert exc_info.value.status_code == 401
    assert supplied not in caplog.text
    assert expected not in caplog.text
    assert "supplied_present=True" in caplog.text
    assert "expected_configured=True" in caplog.text


@pytest.mark.asyncio
async def test_admin_user_listing_is_partner_and_tenant_scoped():
    tenant_id = uuid.uuid4()
    partner_id = uuid.uuid4()
    actor = User(
        id=uuid.uuid4(),
        email="partner@example.test",
        hashed_password="unused",
        role="partner_admin",
        tenant_id=tenant_id,
        partner_id=partner_id,
        is_active=True,
    )
    db = AsyncMock()
    result = MagicMock()
    result.scalars.return_value.all.return_value = []
    db.execute.return_value = result

    assert await list_admin_users(db=db, current_user=actor) == []

    statement = db.execute.await_args.args[0]
    compiled = statement.compile()
    assert compiled.params["partner_id_1"] == partner_id
    assert compiled.params["tenant_id_1"] == tenant_id


@pytest.mark.asyncio
async def test_admin_user_listing_fails_closed_without_assignment():
    actor = User(
        id=uuid.uuid4(),
        email="unassigned@example.test",
        hashed_password="unused",
        role="customer_admin",
        tenant_id=uuid.uuid4(),
        customer_id=None,
        is_active=True,
    )
    db = AsyncMock()

    assert await list_admin_users(db=db, current_user=actor) == []
    db.execute.assert_not_awaited()


@pytest.mark.asyncio
async def test_legacy_syslog_persists_resolved_tenant(monkeypatch):
    resolved_tenant = uuid.uuid4()
    body = SyslogRecordCreate(
        tenant_id=resolved_tenant,
        hostname="registered-firewall",
        message="allow",
    )
    db = MagicMock()
    db.commit = AsyncMock()
    db.refresh = AsyncMock()
    monkeypatch.setattr(
        syslog_endpoint,
        "require_ingest_api_key",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(
        syslog_endpoint,
        "resolve_firewall_log_context",
        AsyncMock(return_value=(resolved_tenant, uuid.uuid4(), uuid.uuid4())),
    )

    record = await syslog_endpoint.create_syslog_record(
        body=body,
        request=_request(supplied_key="configured"),
        db=db,
    )

    assert record.tenant_id == resolved_tenant
    assert record.tenant_resolution_source == "api_ingest"
    db.add.assert_called_once_with(record)
    db.commit.assert_awaited_once()
    db.refresh.assert_awaited_once_with(record)


@pytest.mark.asyncio
async def test_legacy_syslog_rejects_mismatched_or_unknown_tenant(monkeypatch):
    body = SyslogRecordCreate(tenant_id=uuid.uuid4(), hostname="registered-firewall", message="deny")
    db = AsyncMock()
    monkeypatch.setattr(
        syslog_endpoint,
        "require_ingest_api_key",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(
        syslog_endpoint,
        "resolve_firewall_log_context",
        AsyncMock(return_value=(uuid.uuid4(), uuid.uuid4(), uuid.uuid4())),
    )

    with pytest.raises(HTTPException) as mismatch:
        await syslog_endpoint.create_syslog_record(body=body, request=_request(), db=db)
    assert mismatch.value.status_code == 403
    db.add.assert_not_called()

    monkeypatch.setattr(
        syslog_endpoint,
        "resolve_firewall_log_context",
        AsyncMock(return_value=None),
    )
    with pytest.raises(HTTPException) as unknown:
        await syslog_endpoint.create_syslog_record(
            body=body.model_copy(update={"tenant_id": None}),
            request=_request(),
            db=db,
        )
    assert unknown.value.status_code == 403


@pytest.mark.asyncio
async def test_legacy_syslog_rolls_back_when_commit_fails(monkeypatch):
    resolved_tenant = uuid.uuid4()
    body = SyslogRecordCreate(hostname="registered-firewall", message="allow")
    db = MagicMock()
    db.commit = AsyncMock(side_effect=RuntimeError("database unavailable"))
    db.rollback = AsyncMock()
    monkeypatch.setattr(
        syslog_endpoint,
        "require_ingest_api_key",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(
        syslog_endpoint,
        "resolve_firewall_log_context",
        AsyncMock(return_value=(resolved_tenant, uuid.uuid4(), uuid.uuid4())),
    )

    with pytest.raises(RuntimeError, match="database unavailable"):
        await syslog_endpoint.create_syslog_record(body=body, request=_request(), db=db)

    db.rollback.assert_awaited_once()
    db.refresh.assert_not_called()
