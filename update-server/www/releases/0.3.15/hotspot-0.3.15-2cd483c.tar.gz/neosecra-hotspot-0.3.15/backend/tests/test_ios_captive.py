"""Tests for Apple iOS/macOS captive portal detection endpoints."""
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


class TestHotspotDetect:
    def test_hotspot_detect_no_token_returns_redirect(self):
        r = client.get("/hotspot-detect.html", follow_redirects=False)
        assert r.status_code in (302, 307)
        assert r.headers.get("location", "").startswith("/")

    def test_hotspot_detect_with_arbitrary_token_does_not_grant_access(self):
        r = client.get(
            "/hotspot-detect.html",
            headers={"X-Portal-Token": "valid-token-123"},
            follow_redirects=False,
        )
        assert r.status_code in (302, 307)
        assert "Success" not in r.text

    def test_hotspot_detect_preserves_probe_query(self):
        r = client.get(
            "/hotspot-detect.html?device_id=not-a-token&userip=10.0.0.8",
            follow_redirects=False,
        )
        assert r.status_code in (302, 307)
        assert "device_id=not-a-token" in r.headers.get("location", "")
        assert "userip=10.0.0.8" in r.headers.get("location", "")


class TestGenerate204:
    def test_generate_204_no_token_returns_redirect(self):
        r = client.get("/generate_204", follow_redirects=False)
        assert r.status_code in (302, 307)
        assert r.headers.get("location", "").startswith("/")

    def test_generate_204_with_arbitrary_token_does_not_grant_access(self):
        r = client.get(
            "/generate_204",
            headers={"X-Portal-Token": "valid-token-123"},
            follow_redirects=False,
        )
        assert r.status_code in (302, 307)


class TestNcsiTxt:
    def test_ncsi_txt_no_token_returns_redirect(self):
        r = client.get("/ncsi.txt", follow_redirects=False)
        assert r.status_code in (302, 307)
        assert r.headers.get("location", "").startswith("/")

    def test_ncsi_txt_with_arbitrary_token_does_not_grant_access(self):
        r = client.get(
            "/ncsi.txt",
            headers={"X-Portal-Token": "valid-token-123"},
            follow_redirects=False,
        )
        assert r.status_code in (302, 307)
