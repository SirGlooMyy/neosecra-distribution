"""Foreigner/passport validation service tests."""
import pytest

from app.modules.foreigner.service import (
    validate_passport,
    send_email_verification,
    verify_email_code,
)


class TestValidatePassport:
    @pytest.mark.asyncio
    async def test_valid_passport(self):
        result = await validate_passport(
            passport_number="AB123456",
            country="TR",
            full_name="Ahmet Yilmaz",
        )
        assert result is True

    @pytest.mark.asyncio
    async def test_valid_passport_us(self):
        result = await validate_passport(
            passport_number="123456789",
            country="US",
            full_name="John Doe",
        )
        assert result is True

    @pytest.mark.asyncio
    async def test_invalid_country(self):
        result = await validate_passport(
            passport_number="AB123456",
            country="XX",
            full_name="Test User",
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_passport_too_short(self):
        result = await validate_passport(
            passport_number="AB12",
            country="TR",
            full_name="Test User",
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_empty_full_name(self):
        result = await validate_passport(
            passport_number="AB123456",
            country="TR",
            full_name="",
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_passport_number_whitespace_handling(self):
        result = await validate_passport(
            passport_number="  AB123456  ",
            country="  tr  ",
            full_name="Ahmet Yilmaz",
        )
        assert result is True

    @pytest.mark.asyncio
    async def test_unknown_country_lowercase(self):
        result = await validate_passport(
            passport_number="AB123456",
            country="nonexistent",
            full_name="Test User",
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_other_country_code(self):
        """OTHER is a valid catch-all country code."""
        result = await validate_passport(
            passport_number="AB123456",
            country="OTHER",
            full_name="Stateless Person",
        )
        assert result is True


class TestEmailVerification:
    @pytest.mark.asyncio
    async def test_send_email_verification(self):
        result = await send_email_verification("test@example.com", "123456")
        # No SMTP configuration is present in the unit-test process.  The
        # production contract is fail-closed; only an explicit demo mode may
        # acknowledge delivery without a provider.
        assert result is False

    @pytest.mark.asyncio
    async def test_verify_email_code_match(self):
        result = verify_email_code("123456", "123456")
        assert result is True

    def test_verify_email_code_mismatch(self):
        result = verify_email_code("123456", "654321")
        assert result is False

    def test_verify_email_code_whitespace_handling(self):
        result = verify_email_code("  123456  ", "123456")
        assert result is True

    def test_verify_email_code_empty(self):
        result = verify_email_code("", "")
        assert result is True
