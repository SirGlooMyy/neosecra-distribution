"""test_radius_connection — gerçek RADIUS paket gönderimi testleri."""
from __future__ import annotations

from unittest import mock

import pytest

from app.modules.radius.service import test_radius_connection as radius_connection
from app.modules.radius import service as radius_service


@pytest.mark.asyncio
async def test_conn_empty_params():
    assert not await radius_connection("", "secret")
    assert not await radius_connection("1.2.3.4", "")
    assert not await radius_connection("", "")


@pytest.mark.asyncio
async def test_conn_short_secret():
    assert not await radius_connection("1.2.3.4", "abc")


@pytest.mark.asyncio
async def test_conn_no_pyrad_fallback():
    """pyrad yoksa bağlantı testi kullanılabilir bir sonuç döndürmemelidir."""
    with mock.patch("app.modules.radius.service._HAS_PYRAD", False):
        assert not await radius_connection("1.2.3.4", "testing123")


@pytest.mark.asyncio
async def test_conn_timeout():
    """pyrad Timeout => False."""
    client_mock = mock.MagicMock()
    # Must be a real Exception subclass so `except pyrad.client.Timeout` works
    client_mock.SendPacket.side_effect = TimeoutError("RADIUS timeout")
    pyrad_mock = mock.MagicMock()
    pyrad_mock.client.Timeout = TimeoutError
    pyrad_mock.client.Client.return_value = client_mock

    with mock.patch.object(radius_service, "_HAS_PYRAD", True), \
         mock.patch.object(radius_service, "pyrad", pyrad_mock, create=True):
        assert not await radius_connection("10.0.0.1", "secret")


@pytest.mark.asyncio
async def test_conn_success():
    """pyrad yanit alirsa => True."""
    client_mock = mock.MagicMock()
    fake_reply = mock.MagicMock()
    fake_reply.code = 2  # Access-Accept
    client_mock.SendPacket.return_value = fake_reply
    pyrad_mock = mock.MagicMock()
    pyrad_mock.client.Timeout = TimeoutError
    pyrad_mock.client.Client.return_value = client_mock

    with mock.patch.object(radius_service, "_HAS_PYRAD", True), \
         mock.patch.object(radius_service, "pyrad", pyrad_mock, create=True):
        assert await radius_connection("10.0.0.1", "secret")


@pytest.mark.asyncio
async def test_conn_generic_error():
    """Beklenmeyen hata => False."""
    client_mock = mock.MagicMock()
    client_mock.SendPacket.side_effect = ConnectionError("refused")
    pyrad_mock = mock.MagicMock()
    pyrad_mock.client.Timeout = TimeoutError
    pyrad_mock.client.Client.return_value = client_mock

    with mock.patch.object(radius_service, "_HAS_PYRAD", True), \
         mock.patch.object(radius_service, "pyrad", pyrad_mock, create=True):
        assert not await radius_connection("10.0.0.1", "secret")
