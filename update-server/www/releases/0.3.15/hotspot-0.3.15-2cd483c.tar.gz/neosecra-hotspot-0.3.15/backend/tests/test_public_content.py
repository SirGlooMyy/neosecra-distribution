"""Public content module tests."""
from __future__ import annotations

import io
import json
import zipfile
import uuid
from datetime import datetime, timezone
from unittest import mock

import pytest
from fastapi.testclient import TestClient

from app.core.config import settings
from app.core.database import get_db
from app.main import app
from app.modules.public_content.models import PublicAsset
from app.modules.public_content.schemas import PublicAssetOut, PublicInquiryCreate
from app.modules.public_content import service


class _ScalarResult:
    def __init__(self, rows):
        self._rows = rows

    def scalars(self):
        return self

    def all(self):
        return self._rows

    def scalar_one_or_none(self):
        return self._rows[0] if self._rows else None


client = TestClient(app)


@pytest.mark.asyncio
async def test_marketplace_snapshot_falls_back_to_seeded_defaults():
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([]))

    snapshot = await service.get_marketplace_snapshot(db)

    assert snapshot.brand.name == "Hotspot Logging Suite"
    assert snapshot.stats.release_count >= 1
    assert snapshot.stats.download_count >= 2
    assert snapshot.sections["docs"]
    assert snapshot.featured_release is not None
    assert snapshot.featured_release.version == settings.VERSION
    assert snapshot.featured_release.asset_url == f"/api/v1/public-content/releases/{snapshot.featured_release.slug}/download?version={snapshot.featured_release.version}"


@pytest.mark.asyncio
async def test_get_download_asset_adds_download_url():
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="downloads",
        slug="site-bridge-connector-linux-x64",
        version="2.4.1",
        title="Site Bridge Connector",
        category="Agent",
        summary="Yerel ağ ile Hotspot arasındaki güvenli köprü ajanı.",
        body="Bundle",
        asset_url=None,
        checksum="abc123",
        file_size_kb=18200,
        is_current=True,
        sort_order=10,
        meta={},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))

    result = await service.get_download_asset(db, slug=asset.slug, version=asset.version)

    assert result is not None
    assert result.asset_url == f"/api/v1/public-content/downloads/{asset.slug}/download?version={asset.version}"


@pytest.mark.asyncio
async def test_get_release_asset_adds_release_url():
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="hotspot-platform",
        version="0.2.0",
        title="Hotspot Platform 0.2.0",
        category="Release Notes",
        summary="Yayınlı sürüm",
        body="Release body",
        asset_url=None,
        checksum="abc123",
        file_size_kb=0,
        is_current=True,
        sort_order=100,
        meta={"workflow_status": "published", "release_type": "feature", "channel": "stable"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))

    result = await service.get_release_asset(db, slug=asset.slug, version=asset.version)

    assert result is not None
    assert result.asset_url == f"/api/v1/public-content/releases/{asset.slug}/download?version={asset.version}"


@pytest.mark.asyncio
async def test_get_release_asset_allows_explicit_archived_version():
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="hotspot-platform",
        version="0.1.0",
        title="Hotspot Platform 0.1.0",
        category="Release Notes",
        summary="Arşivlenmiş sürüm",
        body="Release body",
        asset_url=None,
        checksum="abc123",
        file_size_kb=0,
        is_current=False,
        sort_order=100,
        meta={"workflow_status": "archived", "release_type": "feature", "channel": "stable"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))

    result = await service.get_release_asset(db, slug=asset.slug, version=asset.version)

    assert result is not None
    assert result.workflow_status == "archived"
    assert result.asset_url == f"/api/v1/public-content/releases/{asset.slug}/download?version={asset.version}"


@pytest.mark.asyncio
async def test_get_download_asset_allows_explicit_archived_version():
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="downloads",
        slug="site-bridge-connector-linux-x64",
        version="2.3.0",
        title="Site Bridge Connector 2.3.0",
        category="Agent",
        summary="Arşivlenmiş paket",
        body="Bundle",
        asset_url=None,
        checksum="abc123",
        file_size_kb=18200,
        is_current=False,
        sort_order=10,
        meta={"workflow_status": "archived"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))

    result = await service.get_download_asset(db, slug=asset.slug, version=asset.version)

    assert result is not None
    assert result.workflow_status == "archived"
    assert result.asset_url == f"/api/v1/public-content/downloads/{asset.slug}/download?version={asset.version}"


@pytest.mark.asyncio
async def test_list_public_release_history_excludes_drafts_and_keeps_archives():
    current = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="hotspot-platform",
        version="0.3.0",
        title="Hotspot Platform 0.3.0",
        category="Release Notes",
        summary="Canlı sürüm",
        body="Current release body",
        asset_url=None,
        checksum="abc123",
        file_size_kb=0,
        is_current=True,
        sort_order=100,
        meta={"workflow_status": "published", "release_type": "feature", "channel": "stable"},
        created_at=datetime(2026, 7, 13, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, 12, tzinfo=timezone.utc),
    )
    archived = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="hotspot-platform",
        version="0.2.0",
        title="Hotspot Platform 0.2.0",
        category="Release Notes",
        summary="Arşiv sürüm",
        body="Archived release body",
        asset_url=None,
        checksum="def456",
        file_size_kb=0,
        is_current=False,
        sort_order=90,
        meta={"workflow_status": "archived", "release_type": "fix", "channel": "stable"},
        created_at=datetime(2026, 7, 12, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 12, 12, tzinfo=timezone.utc),
    )
    draft = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="hotspot-platform",
        version="0.4.0",
        title="Hotspot Platform 0.4.0",
        category="Release Notes",
        summary="Taslak sürüm",
        body="Draft release body",
        asset_url=None,
        checksum="ghi789",
        file_size_kb=0,
        is_current=False,
        sort_order=80,
        meta={"workflow_status": "draft", "release_type": "feature", "channel": "beta"},
        created_at=datetime(2026, 7, 14, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 14, 12, tzinfo=timezone.utc),
    )
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([current, archived, draft]))

    result = await service.list_public_release_history(db, slug="hotspot-platform")

    assert [item.version for item in result] == ["0.3.0", "0.2.0"]
    assert [item.workflow_status for item in result] == ["published", "archived"]
    assert result[0].asset_url == "/api/v1/public-content/releases/hotspot-platform/download?version=0.3.0"
    assert result[1].asset_url == "/api/v1/public-content/releases/hotspot-platform/download?version=0.2.0"


def test_build_download_bundle_contains_manifest_and_readme():
    asset = PublicAssetOut(
        id=uuid.uuid4(),
        section="downloads",
        slug="verify-tool",
        version="1.1.0",
        title="5651 XML Damga Doğrulayıcı",
        category="CLI Tool",
        summary="İmzalı log paketlerini çevrimdışı doğrular.",
        body="KamuSM bundle",
        asset_url="/api/v1/public-content/downloads/verify-tool/download?version=1.1.0",
        checksum="deadbeef",
        file_size_kb=8500,
        is_current=True,
        sort_order=10,
        meta={"bundle": "verify-tool"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )

    bundle, filename = service.build_download_bundle(asset)
    assert filename == "verify-tool-1.1.0.zip"

    with zipfile.ZipFile(io.BytesIO(bundle), "r") as archive:
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
        readme = archive.read("README.txt").decode("utf-8")

    assert manifest["slug"] == "verify-tool"
    assert manifest["version"] == "1.1.0"
    assert "5651 XML Damga Doğrulayıcı" in readme
    assert "KamuSM bundle" in readme


def test_download_release_bundle_endpoint_streams_zip():
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="hotspot-platform",
        version="0.3.0",
        title="Hotspot Platform 0.3.0",
        category="Release Notes",
        summary="Yayınlı sürüm",
        body="Release body",
        asset_url=None,
        checksum="abc123",
        file_size_kb=0,
        is_current=True,
        sort_order=100,
        meta={"workflow_status": "published", "release_type": "feature", "channel": "stable"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))

    app.dependency_overrides[get_db] = lambda: db
    try:
        response = client.get(f"/api/v1/public-content/releases/{asset.slug}/download?version={asset.version}")
    finally:
        app.dependency_overrides.clear()

    assert response.status_code == 200
    assert response.headers["content-disposition"].startswith('attachment; filename="hotspot-update-0.3.0-')
    with zipfile.ZipFile(io.BytesIO(response.content), "r") as archive:
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))

    assert manifest["version"] == "0.3.0"
    assert manifest["artifact_url"] == f"/api/v1/public-content/releases/{asset.slug}/download?version={asset.version}"


def test_list_release_history_endpoint_streams_versions():
    current = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="hotspot-platform",
        version="0.3.0",
        title="Hotspot Platform 0.3.0",
        category="Release Notes",
        summary="Canlı sürüm",
        body="Current release body",
        asset_url=None,
        checksum="abc123",
        file_size_kb=0,
        is_current=True,
        sort_order=100,
        meta={"workflow_status": "published", "release_type": "feature", "channel": "stable"},
        created_at=datetime(2026, 7, 13, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, 12, tzinfo=timezone.utc),
    )
    archived = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="hotspot-platform",
        version="0.2.0",
        title="Hotspot Platform 0.2.0",
        category="Release Notes",
        summary="Arşiv sürüm",
        body="Archived release body",
        asset_url=None,
        checksum="def456",
        file_size_kb=0,
        is_current=False,
        sort_order=90,
        meta={"workflow_status": "archived", "release_type": "fix", "channel": "stable"},
        created_at=datetime(2026, 7, 12, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 12, 12, tzinfo=timezone.utc),
    )
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([current, archived]))

    app.dependency_overrides[get_db] = lambda: db
    try:
        response = client.get("/api/v1/public-content/releases/hotspot-platform/history")
    finally:
        app.dependency_overrides.clear()

    assert response.status_code == 200
    payload = response.json()
    assert [item["version"] for item in payload] == ["0.3.0", "0.2.0"]
    assert [item["workflow_status"] for item in payload] == ["published", "archived"]


@pytest.mark.asyncio
async def test_submit_public_inquiry_returns_reference_code():
    db = mock.AsyncMock()
    db.add = mock.MagicMock()
    db.flush = mock.AsyncMock()
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()

    body = PublicInquiryCreate(
        inquiry_type="trial",
        source_tab="partner",
        name="  Ahmet Yılmaz  ",
        email="  ahmet@example.com  ",
        phone="  +905551112233  ",
        company="  Example A.Ş.  ",
        role="  client  ",
        message="  Demo talebi istiyorum.  ",
    )

    result = await service.submit_public_inquiry(db, body)

    assert result.status == "new"
    assert result.reference_code.startswith("PQ-")
    inquiry = db.add.call_args.args[0]
    assert inquiry.inquiry_type == "trial"
    assert inquiry.source_tab == "partner"
    assert inquiry.email == "ahmet@example.com"
    assert inquiry.company == "Example A.Ş."
