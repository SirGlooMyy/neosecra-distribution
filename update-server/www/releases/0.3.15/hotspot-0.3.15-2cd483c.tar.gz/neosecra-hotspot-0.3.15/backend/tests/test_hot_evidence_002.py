"""HOT-EVIDENCE-002 negative, provenance, and idempotency tests."""
from __future__ import annotations

import asyncio
import hashlib
import io
import json
import sys
import types
import uuid
import zipfile
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest import mock

import pytest
from fastapi import HTTPException

from app.core.config import settings
from app.modules.logs_5651.models import (
    ArchiveRecord,
    EVIDENCE_STATUS_FAILED,
    EvidenceExport,
    EvidenceExportStatusHistory,
)
from app.modules.logs_5651.report_service import (
    generate_court_evidence_package,
    generate_5651_pdf,
    generate_archive_zip_package,
    inspect_evidence_package,
    save_evidence_package,
)
from app.modules.logs_5651.router import _authorize_customer_access
from app.modules.logs_5651.verify_service import verify_export_package
from app.modules.reports.envelope import (
    build_evidence_envelope,
    build_report_envelope,
    verify_envelope,
)
from app.modules.reports.scheduler_service import record_job_status
from app.modules.reports.models import ReportJobStatusHistory
from app.modules.reports import service as reports_service
from app.core.tenant import ScopeContext, TenantLevel


def _package() -> bytes:
    files = {
        "session.json": b'{"session_id":"s1"}',
        "syslog_records.jsonl": b"",
        "radius_events.jsonl": b"",
        "archive_chain.json": b"[]",
    }
    manifest = {
        "package_type": "5651_court_evidence",
        "schema_version": "1.0",
        "session_id": "s1",
        "customer_id": "c1",
        "tenant_id": "t1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "files": list(files),
        "sha256_hashes": {name: hashlib.sha256(payload).hexdigest() for name, payload in files.items()},
    }
    from app.modules.reports.envelope import envelope_hash

    manifest["sha256_hash"] = envelope_hash(manifest)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, payload in files.items():
            zf.writestr(name, payload)
        zf.writestr("evidence_manifest.json", json.dumps(manifest))
    return buf.getvalue()


def test_evidence_envelope_is_immutable_and_tamper_detected():
    now = datetime.now(timezone.utc)
    envelope = build_evidence_envelope(
        export_id=uuid.uuid4(),
        evidence_type="5651_court_evidence",
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        session_id=uuid.uuid4(),
        generated_at=now,
        package_hash="a" * 64,
        files={"session.json": "b" * 64},
    )
    assert verify_envelope(envelope)
    envelope["package_hash"] = "c" * 64
    assert not verify_envelope(envelope)


def test_report_envelope_contains_sha256_provenance():
    envelope = build_report_envelope(
        report_id=uuid.uuid4(),
        module="hotspot",
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        generated_at=datetime.now(timezone.utc),
        reporting_period={"start": "2026-01-01", "end": "2026-01-02"},
        data={"rows": []},
        provenance={"source": "test"},
    )
    assert verify_envelope(envelope)
    assert envelope["provenance"]["source"] == "test"


def test_inspect_evidence_package_rejects_file_tamper():
    package = _package()
    tampered = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(package), "r") as source, zipfile.ZipFile(tampered, "w") as target:
        for name in source.namelist():
            payload = source.read(name)
            if name == "session.json":
                payload = b'{"session_id":"tampered"}'
            target.writestr(name, payload)
    with pytest.raises(ValueError, match="SHA-256 mismatch"):
        inspect_evidence_package(tampered.getvalue())


def test_verify_export_package_legacy_is_explicit_compatibility(tmp_path):
    path = tmp_path / "legacy.zip"
    with zipfile.ZipFile(path, "w") as zf:
        for name, payload in {
            "session.json": b"{}",
            "syslog_records.jsonl": b"",
            "radius_events.jsonl": b"",
            "archive_chain.json": b"[]",
        }.items():
            zf.writestr(name, payload)
        zf.writestr("evidence_manifest.json", json.dumps({"package_type": "5651_court_evidence"}))
    result = verify_export_package(str(path))
    assert result["valid"] is True
    assert result["integrity_verified"] is False
    assert result["compatibility_mode"] == "legacy_unhashed"


@pytest.mark.asyncio
async def test_save_evidence_package_is_idempotent_and_never_overwrites(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "EVIDENCE_STORAGE_PATH", str(tmp_path))
    payload = _package()
    sid = uuid.uuid4()
    cid = uuid.uuid4()
    refs = await asyncio.gather(
        save_evidence_package(payload, sid, cid),
        save_evidence_package(payload, sid, cid),
    )
    assert refs[0] == refs[1]
    path = refs[0][6:]
    with open(path, "rb") as fh:
        assert hashlib.sha256(fh.read()).hexdigest() == hashlib.sha256(payload).hexdigest()


@pytest.mark.asyncio
async def test_court_evidence_missing_tenant_fails_closed():
    session = SimpleNamespace(id=uuid.uuid4(), customer_id=uuid.uuid4())
    db = mock.AsyncMock()
    db.get = mock.AsyncMock(side_effect=[session, None])
    with pytest.raises(HTTPException) as exc:
        await generate_court_evidence_package(db, session.id, session.customer_id)
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_court_evidence_legacy_unverified_archive_fails_closed():
    session = SimpleNamespace(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        location_id=None,
        device_id=None,
        identity_verification_id=None,
        voucher_id=None,
        phone=None,
        mac=None,
        ip=None,
        nas_ip=None,
        ssid=None,
        auth_method="sms",
        status="active",
        started_at=None,
        ended_at=None,
        expires_at=None,
        radius_session_id=None,
        bytes_in=0,
        bytes_out=0,
        authorize_ok=True,
        authorize_message=None,
        group_id=None,
        meta={},
    )
    customer = SimpleNamespace(tenant_id=uuid.uuid4())
    unverified_archive = SimpleNamespace(customer_id=session.customer_id)
    empty = mock.MagicMock()
    empty.scalars.return_value.all.return_value = [unverified_archive]
    db = mock.AsyncMock()
    db.get = mock.AsyncMock(side_effect=[session, customer])
    db.execute = mock.AsyncMock(return_value=empty)
    with pytest.raises(HTTPException) as exc:
        await generate_court_evidence_package(db, session.id, session.customer_id)
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_5651_pdf_publication_missing_tenant_fails_closed():
    archive = SimpleNamespace(
        customer_id=uuid.uuid4(),
        status="ready",
        storage_verified=True,
        signature_valid=True,
    )
    result = mock.MagicMock()
    result.scalar_one_or_none.return_value = None
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=result)
    with pytest.raises(HTTPException) as exc:
        await generate_5651_pdf(
            db,
            customer_id=archive.customer_id,
            period_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
            period_end=datetime(2026, 1, 2, tzinfo=timezone.utc),
            archive_records=[archive],
            require_ready=True,
        )
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_5651_pdf_publication_without_archive_fails_closed():
    db = mock.AsyncMock()
    with pytest.raises(HTTPException) as exc:
        await generate_5651_pdf(
            db,
            customer_id=uuid.uuid4(),
            period_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
            period_end=datetime(2026, 1, 2, tzinfo=timezone.utc),
            archive_records=[],
            require_ready=True,
        )
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_5651_zip_archive_customer_mismatch_fails_closed():
    requested_customer_id = uuid.uuid4()
    archive = SimpleNamespace(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        status="ready",
        storage_verified=True,
        signature_valid=True,
    )
    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=archive)
    with pytest.raises(HTTPException) as exc:
        await generate_archive_zip_package(db, archive.id, requested_customer_id)
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_evidence_customer_idor_is_rejected():
    scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=uuid.uuid4())
    with pytest.raises(HTTPException) as exc:
        await _authorize_customer_access(mock.AsyncMock(), scope, uuid.uuid4())
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_report_retry_idempotency_returns_existing_ready_archive():
    job = SimpleNamespace(
        id=uuid.uuid4(), customer_id=uuid.uuid4(), report_type="daily",
        template_id=None, format="csv", trigger="daily", last_run_at=None,
    )
    existing = SimpleNamespace(status="ready", id=uuid.uuid4())
    result = mock.MagicMock()
    result.scalar_one_or_none.return_value = existing
    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=job)
    db.execute = mock.AsyncMock(return_value=result)
    returned = await __import__("app.modules.reports.scheduler_service", fromlist=["generate_report"]).generate_report(
        db, job.id, idempotency_key="retry-key"
    )
    assert returned is existing
    db.add.assert_not_called()


def test_json_pdf_parity_uses_the_same_report_snapshot(monkeypatch):
    report = {
        "title": "Parity",
        "description": "snapshot",
        "period_start": datetime(2026, 1, 1, tzinfo=timezone.utc),
        "period_end": datetime(2026, 1, 2, tzinfo=timezone.utc),
        "generated_at": datetime(2026, 1, 2, tzinfo=timezone.utc),
        "metrics": [("Sessions", "2")],
        "columns": ["id", "status"],
        "rows": [["s1", "active"], ["s2", "ended"]],
        "notes": [],
    }
    captured = {}

    def fake_pdf(**kwargs):
        captured.update(kwargs)
        return b"pdf"

    fake_module = types.ModuleType("app.modules.reports.pdf_generator")
    fake_module.create_corporate_pdf = fake_pdf
    monkeypatch.setitem(sys.modules, "app.modules.reports.pdf_generator", fake_module)
    csv_text = reports_service.build_quick_csv(report)
    reports_service.build_quick_pdf(report)
    assert "s1,active" in csv_text
    assert captured["metrics"] == report["metrics"]
    assert captured["tables"][0]["headers"] == report["columns"]
    assert captured["tables"][0]["rows"] == report["rows"]


@pytest.mark.asyncio
async def test_status_history_is_append_only_and_tenant_bound():
    job = SimpleNamespace(id=uuid.uuid4(), customer_id=uuid.uuid4())
    db = mock.AsyncMock()
    db.add = mock.MagicMock()
    await record_job_status(db, job, "queued", attempt=1, idempotency_key="retry-1")
    await record_job_status(db, job, "failed", attempt=1, idempotency_key="retry-1", error_message="storage")
    await record_job_status(db, job, "retry", attempt=2, idempotency_key="retry-1")
    rows = [call.args[0] for call in db.add.call_args_list if isinstance(call.args[0], ReportJobStatusHistory)]
    assert [row.status for row in rows] == ["queued", "failed", "retry"]
    assert all(row.customer_id == job.customer_id for row in rows)


def test_failed_evidence_model_cannot_be_ready_by_default():
    export = EvidenceExport(
        id=uuid.uuid4(),
        session_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        status=EVIDENCE_STATUS_FAILED,
        error_message="storage unavailable",
    )
    assert export.status == EVIDENCE_STATUS_FAILED
    assert export.package_ref is None
