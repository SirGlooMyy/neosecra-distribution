from datetime import datetime, timezone

from app.shared.licensing.contract import license_status, update_entitlement_expired


def test_contract_rejects_malformed_grace_and_expiry_boundary():
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    base = {"valid_from": "2025-12-31T00:00:00Z", "expires_at": now.isoformat()}
    assert license_status(base, now) == "EXPIRED"
    assert license_status({**base, "expires_at": "2025-12-31T00:00:00Z", "grace_period_days": "x"}, now) == "INVALID_SIGNATURE"
    assert update_entitlement_expired({"update_entitlement_until": now.isoformat()}, now) is True


def test_legacy_warning_is_a_canonical_non_time_status():
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    payload = {"status": "LEGACY_WARNING", "valid_from": "bad", "expires_at": "bad"}
    assert license_status(payload, now) == "LEGACY_WARNING"
