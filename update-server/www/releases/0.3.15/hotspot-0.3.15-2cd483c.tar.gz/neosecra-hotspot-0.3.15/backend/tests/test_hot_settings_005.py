import uuid
import unittest.mock as mock
import pytest
from httpx import AsyncClient, ASGITransport

from app.main import app
from app.core.database import get_db
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.system.models import PlatformSetting

def _make_admin_user(role="super_admin"):
    uid = uuid.uuid4()
    return User(
        id=uid,
        email="superadmin@neosecra.com",
        full_name="Super Admin",
        hashed_password="hashed",
        role=role,
        is_active=True,
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        is_2fa_enabled=False,
    )

def _build_mock_db():
    mock_db = mock.AsyncMock()
    settings_store = {}

    async def execute_side(stmt):
        stmt_str = str(stmt)
        result = mock.MagicMock()
        if "platform_settings" in stmt_str:
            setting_obj = settings_store.get("general_settings")
            result.scalar_one_or_none.return_value = setting_obj
            scalar_res = mock.MagicMock()
            scalar_res.first.return_value = setting_obj
            scalar_res.all.return_value = [setting_obj] if setting_obj else []
            result.scalars.return_value = scalar_res
        elif "audit_logs" in stmt_str:
            result.scalar_one_or_none.return_value = None
            scalar_res = mock.MagicMock()
            scalar_res.all.return_value = []
            result.scalars.return_value = scalar_res
        else:
            result.scalar_one_or_none.return_value = None
            scalar_res = mock.MagicMock()
            scalar_res.first.return_value = None
            scalar_res.all.return_value = []
            result.scalars.return_value = scalar_res
        return result

    def add_side(entity):
        if isinstance(entity, PlatformSetting):
            settings_store[entity.key] = entity

    mock_db.execute.side_effect = execute_side
    mock_db.add = mock.MagicMock(side_effect=add_side)
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()
    return mock_db

@pytest.fixture(autouse=True)
def _mock_redis():
    store = {}
    async def get_side(key):
        return store.get(key)
    async def setex_side(key, ttl, val):
        store[key] = val
        return True
    async def delete_side(key):
        store.pop(key, None)
        return True

    r = mock.AsyncMock()
    r.get.side_effect = get_side
    r.set.side_effect = lambda k, v: True
    r.setex.side_effect = setex_side
    r.delete.side_effect = delete_side
    r.incr.return_value = 1
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield

@pytest.mark.asyncio
async def test_get_general_settings():
    admin = _make_admin_user("super_admin")
    mock_db = _build_mock_db()

    app.dependency_overrides[get_db] = lambda: mock_db
    app.dependency_overrides[get_current_user] = lambda: admin
    try:
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as ac:
            response = await ac.get("/api/v1/system/settings/general")
            assert response.status_code == 200
            data = response.json()
            assert "org_name" in data
            assert "site_name" in data
            assert "timezone" in data
            assert "locale" in data
            assert "session_timeout_minutes" in data
            assert "version_tag" in data
            assert data["session_timeout_minutes"] >= 5
    finally:
        app.dependency_overrides.pop(get_db, None)
        app.dependency_overrides.pop(get_current_user, None)

@pytest.mark.asyncio
async def test_update_general_settings_optimistic_concurrency():
    admin = _make_admin_user("super_admin")
    mock_db = _build_mock_db()

    app.dependency_overrides[get_db] = lambda: mock_db
    app.dependency_overrides[get_current_user] = lambda: admin
    try:
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as ac:
            # 1. Read default settings (version_tag is 1)
            res1 = await ac.get("/api/v1/system/settings/general")
            assert res1.status_code == 200
            current = res1.json()
            current_version = current.get("version_tag", 1)

            # 2. Update with version_tag=1 -> succeeds and increments to 2
            payload = {
                "org_name": "NeoSecra Campus Hotspot",
                "site_name": "Istanbul HQ",
                "timezone": "Europe/Istanbul",
                "locale": "tr-TR",
                "session_timeout_minutes": 120,
                "two_fa_enforced": True,
                "ip_allowlist": ["192.168.1.0/24"],
                "version_tag": current_version
            }
            res2 = await ac.put("/api/v1/system/settings/general", json=payload)
            assert res2.status_code == 200
            updated = res2.json()
            assert updated["org_name"] == "NeoSecra Campus Hotspot"
            assert updated["version_tag"] == current_version + 1

            # 3. Try to update again with old version_tag=1 -> returns 409 Conflict
            stale_payload = {
                "org_name": "Conflict Attempt",
                "session_timeout_minutes": 60,
                "version_tag": current_version  # stale version 1 while stored is 2
            }
            res3 = await ac.put("/api/v1/system/settings/general", json=stale_payload)
            assert res3.status_code == 409
            assert "güncellenmiş" in res3.json()["detail"] or "Conflict" in res3.json()["detail"] or "Çakışma" in res3.json()["detail"]
    finally:
        app.dependency_overrides.pop(get_db, None)
        app.dependency_overrides.pop(get_current_user, None)

@pytest.mark.asyncio
async def test_get_settings_audit_trail():
    admin = _make_admin_user("super_admin")
    mock_db = _build_mock_db()

    app.dependency_overrides[get_db] = lambda: mock_db
    app.dependency_overrides[get_current_user] = lambda: admin
    try:
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as ac:
            response = await ac.get("/api/v1/system/settings/audit?limit=10")
            assert response.status_code == 200
            items = response.json()
            assert isinstance(items, list)
    finally:
        app.dependency_overrides.pop(get_db, None)
        app.dependency_overrides.pop(get_current_user, None)
