"""Regression coverage for migration-compatible VPN MFA log projections."""

import uuid
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.modules.mfa import router as mfa_router
from app.modules.radius.models import RadiusChallenge


@pytest.mark.asyncio
async def test_vpn_otp_logs_does_not_select_or_expose_plaintext_code(monkeypatch):
    """The endpoint must work with the f0e1d2c3b4a5 schema."""
    assert "otp_code" not in RadiusChallenge.__table__.columns

    customer_id = uuid.uuid4()
    now = datetime.now(timezone.utc)
    records = [
        SimpleNamespace(
            id=uuid.uuid4(),
            username="sms-user",
            mfa_method="sms",
            nas_ip="10.0.0.10",
            verified=False,
            expires_at=now + timedelta(minutes=5),
            consumed_at=None,
            created_at=now,
            attempt_count=0,
        ),
        SimpleNamespace(
            id=uuid.uuid4(),
            username="totp-user",
            mfa_method="totp",
            nas_ip="10.0.0.11",
            verified=True,
            expires_at=now - timedelta(minutes=1),
            consumed_at=now,
            created_at=now - timedelta(minutes=6),
            attempt_count=1,
        ),
    ]
    scalar_result = MagicMock()
    scalar_result.scalars.return_value.all.return_value = records
    db = AsyncMock()
    db.execute.return_value = scalar_result
    monkeypatch.setattr(
        mfa_router,
        "_customer_for_mfa",
        AsyncMock(return_value=customer_id),
    )

    result = await mfa_router.get_vpn_otp_logs(
        user=SimpleNamespace(customer_id=customer_id),
        db=db,
        limit=50,
    )

    assert [item["otp_code"] for item in result] == ["—", "TOTP"]
    assert all("123456" not in item["otp_code"] for item in result)
    assert all("code_hash" not in item for item in result)
