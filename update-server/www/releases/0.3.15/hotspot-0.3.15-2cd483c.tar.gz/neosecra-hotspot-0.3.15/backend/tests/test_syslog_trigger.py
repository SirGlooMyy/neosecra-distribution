"""Syslog Trigger/Alert servis testleri."""
import pytest
import uuid
import unittest.mock as mock
from datetime import datetime, timedelta, timezone

from app.modules.syslog.models import SyslogRecord, SyslogTrigger
from app.modules.syslog.trigger_service import (
    _match_trigger,
    _webhook_target_is_public,
    evaluate_syslog,
    fire_triggers,
    create_trigger,
    delete_trigger,
    acknowledge_trigger,
    trigger_log,
    MATCH_TYPE_KEYWORD,
    MATCH_TYPE_REGEX,
    MATCH_TYPE_SEVERITY,
    MATCH_TYPE_VENDOR,
    CHANNEL_WEBHOOK,
    CHANNEL_EMAIL,
)


def _make_record(message: str = "", severity: int = 5, app_name: str = "", hostname: str = ""):
    return SyslogRecord(
        id=uuid.uuid4(),
        message=message,
        severity=severity,
        app_name=app_name,
        hostname=hostname,
        facility=1,
        tenant_id=uuid.uuid4(),
    )


def _make_trigger(
    match_type=MATCH_TYPE_KEYWORD,
    match_pattern="error",
    severity_threshold=None,
    channel=CHANNEL_WEBHOOK,
    cooldown_minutes=5,
    is_active=True,
):
    return SyslogTrigger(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        name="Test Trigger",
        description="Test",
        match_type=match_type,
        match_pattern=match_pattern,
        severity_threshold=severity_threshold,
        channel=channel,
        channel_config={"url": "http://example.com/webhook"},
        cooldown_minutes=cooldown_minutes,
        is_active=is_active,
        last_triggered_at=None,
    )


def test_keyword_match():
    """Keyword match should find pattern in message."""
    record = _make_record(message="This is an error in the system")
    trigger = _make_trigger(match_type=MATCH_TYPE_KEYWORD, match_pattern="error")
    assert _match_trigger(trigger, record) == "error"


def test_keyword_no_match():
    """Keyword match should return None when pattern not found."""
    record = _make_record(message="Everything is fine")
    trigger = _make_trigger(match_type=MATCH_TYPE_KEYWORD, match_pattern="error")
    assert _match_trigger(trigger, record) is None


def test_regex_match():
    """Regex match should find pattern in message."""
    record = _make_record(message="Failed password for user admin from 10.0.0.1")
    trigger = _make_trigger(match_type=MATCH_TYPE_REGEX, match_pattern=r"\d+\.\d+\.\d+\.\d+")
    result = _match_trigger(trigger, record)
    assert result == "10.0.0.1"


def test_regex_no_match():
    """Regex match should return None when pattern not found."""
    record = _make_record(message="No IP address here")
    trigger = _make_trigger(match_type=MATCH_TYPE_REGEX, match_pattern=r"\d+\.\d+\.\d+\.\d+")
    assert _match_trigger(trigger, record) is None


def test_regex_invalid_pattern():
    """Invalid regex pattern should not crash, returns None."""
    record = _make_record(message="test")
    trigger = _make_trigger(match_type=MATCH_TYPE_REGEX, match_pattern=r"[invalid")
    assert _match_trigger(trigger, record) is None


def test_severity_match():
    """Severity match should trigger when record severity <= threshold."""
    record = _make_record(severity=3)
    trigger = _make_trigger(match_type=MATCH_TYPE_SEVERITY, severity_threshold=5)
    result = _match_trigger(trigger, record)
    assert result is not None
    assert "severity=3" in result


def test_severity_no_match():
    """Severity match should return None when record severity > threshold."""
    record = _make_record(severity=7)
    trigger = _make_trigger(match_type=MATCH_TYPE_SEVERITY, severity_threshold=5)
    assert _match_trigger(trigger, record) is None


def test_vendor_match():
    """Vendor match should find pattern in app_name or message."""
    record = _make_record(message="FortiGate session timeout", app_name="fortigate")
    trigger = _make_trigger(match_type=MATCH_TYPE_VENDOR, match_pattern="fortigate")
    assert _match_trigger(trigger, record) == "fortigate"


@pytest.mark.asyncio
async def test_webhook_target_rejects_private_and_non_http(monkeypatch):
    """Tenant webhook config must not turn the worker into an SSRF proxy."""
    private_info = [(2, 1, 6, "", ("127.0.0.1", 80))]
    monkeypatch.setattr(
        "app.modules.syslog.trigger_service.socket.getaddrinfo",
        lambda *args, **kwargs: private_info,
    )
    assert not await _webhook_target_is_public("http://internal.example/hook")
    assert not await _webhook_target_is_public("file:///etc/passwd")
    assert not await _webhook_target_is_public("http://user:pass@example.com/hook")


@pytest.mark.asyncio
async def test_webhook_target_allows_public_https(monkeypatch):
    """A resolvable public HTTPS endpoint remains a supported destination."""
    public_info = [(2, 1, 6, "", ("93.184.216.34", 443))]
    monkeypatch.setattr(
        "app.modules.syslog.trigger_service.socket.getaddrinfo",
        lambda *args, **kwargs: public_info,
    )
    assert await _webhook_target_is_public("https://example.com/hooks/alert")


def test_cooldown():
    """Trigger with recent last_triggered_at should be skipped."""
    record = _make_record(message="error critical")
    trigger = _make_trigger(
        match_type=MATCH_TYPE_KEYWORD,
        match_pattern="error",
        cooldown_minutes=10,
    )
    trigger.last_triggered_at = datetime.now(timezone.utc) - timedelta(minutes=1)

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.all.return_value = [trigger]
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    import asyncio
    result = asyncio.run(evaluate_syslog(mock_db, record))
    assert len(result) == 0


@pytest.mark.asyncio
async def test_create_trigger():
    """Create trigger should persist and validate match_type/channel."""
    mock_db = mock.AsyncMock()
    mock_db.add = mock.MagicMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()

    trigger = await create_trigger(mock_db, {
        "customer_id": uuid.uuid4(),
        "name": "Test Alert",
        "description": "Test",
        "match_type": MATCH_TYPE_KEYWORD,
        "match_pattern": "error",
        "channel": CHANNEL_EMAIL,
        "channel_config": {"to": ["admin@test.com"]},
        "cooldown_minutes": 5,
        "is_active": True,
    })
    assert trigger is not None


@pytest.mark.asyncio
async def test_create_trigger_invalid_match_type():
    """Invalid match_type should raise 400."""
    mock_db = mock.AsyncMock()

    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc:
        await create_trigger(mock_db, {
            "match_type": "invalid",
            "channel": CHANNEL_EMAIL,
        })
    assert exc.value.status_code == 400


@pytest.mark.asyncio
async def test_create_trigger_invalid_channel():
    """Invalid channel should raise 400."""
    mock_db = mock.AsyncMock()

    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc:
        await create_trigger(mock_db, {
            "match_type": MATCH_TYPE_KEYWORD,
            "match_pattern": "error",
            "channel": "invalid_channel",
        })
    assert exc.value.status_code == 400


@pytest.mark.asyncio
async def test_trigger_log():
    """trigger_log should create a TriggerEvent."""
    mock_db = mock.AsyncMock()
    mock_db.add = mock.MagicMock()
    mock_db.flush = mock.AsyncMock()

    event = await trigger_log(
        mock_db,
        trigger_id=uuid.uuid4(),
        syslog_record_id=uuid.uuid4(),
        matched_value="test match",
    )
    assert event is not None
    assert event.matched_value == "test match"


@pytest.mark.asyncio
async def test_fire_triggers_creates_alarm_event(monkeypatch):
    record = _make_record(message="FortiGate auth failure", severity=3, app_name="fortigate", hostname="fw-1")
    trigger = _make_trigger(match_type=MATCH_TYPE_VENDOR, match_pattern="fortigate", channel=CHANNEL_EMAIL)
    trigger.customer_id = uuid.uuid4()

    mock_db = mock.AsyncMock()
    mock_db.add = mock.MagicMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()

    mock_scalar = mock.MagicMock()
    mock_scalar.scalars.return_value = mock_scalar
    mock_scalar.all.return_value = [trigger]
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    alarm_create = mock.AsyncMock(return_value=mock.MagicMock(id=uuid.uuid4()))
    monkeypatch.setattr("app.modules.alarm.service.create_alarm", alarm_create)
    monkeypatch.setattr(
        "app.modules.syslog.trigger_service._send_email_alert",
        mock.AsyncMock(
            return_value={
                "channel": CHANNEL_EMAIL,
                "status": "sent",
                "target": "admin@test.com",
                "detail": "ok",
                "delivered_at": datetime.now(timezone.utc),
            }
        ),
    )

    events = await fire_triggers(mock_db, record)

    assert len(events) == 1
    assert events[0].delivery_channel == CHANNEL_EMAIL
    assert events[0].delivery_status == "sent"
    assert events[0].delivery_target == "admin@test.com"
    alarm_create.assert_awaited_once()
    kwargs = alarm_create.await_args.kwargs
    assert kwargs["severity"] == "warning"
    assert kwargs["title"] == trigger.name
    assert kwargs["trigger_id"] == trigger.id


@pytest.mark.asyncio
async def test_acknowledge_trigger_not_found():
    """Acknowledge non-existent event should raise 404."""
    mock_db = mock.AsyncMock()
    mock_db.get = mock.AsyncMock(return_value=None)

    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc:
        await acknowledge_trigger(mock_db, uuid.uuid4(), uuid.uuid4())
    assert exc.value.status_code == 404


@pytest.mark.asyncio
async def test_delete_trigger_not_found():
    """Delete non-existent trigger should raise 404."""
    mock_db = mock.AsyncMock()
    mock_db.get = mock.AsyncMock(return_value=None)

    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc:
        await delete_trigger(mock_db, uuid.uuid4())
    assert exc.value.status_code == 404
