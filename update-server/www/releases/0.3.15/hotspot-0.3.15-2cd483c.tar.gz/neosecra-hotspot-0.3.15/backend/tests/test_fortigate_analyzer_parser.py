"""Regression coverage for FortiGate records shown by the unified analyzer."""

import sys
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parents[1]))

from app.modules.firewall_adapters.fortigate import parse_syslog_event
from app.modules.search.service import _effective_firewall_log_type
from app.modules.syslog.parsers import parse_firewall_syslog
from app.modules.syslog.models import FirewallLog


@pytest.mark.parametrize(
    ("raw", "expected_type", "expected_action"),
    [
        (
            'date=2026-08-24 time=18:10:00 devname=FGT type=event subtype=vpn '
            'level=notice action=tunnel-up remip=10.20.0.11 tunnelip=10.212.0.2 '
            'user=alice tunnelid=12345 logdesc="SSL VPN tunnel up"',
            "vpn",
            "tunnel-up",
        ),
        (
            'date=2026-08-24 time=18:10:00 devname=FGT type=vpn subtype=ipsec '
            'level=notice action=tunnel-down remip=10.20.0.12 user=bob',
            "vpn",
            "tunnel-down",
        ),
        (
            'date=2026-08-24 time=18:10:00 type=utm subtype=webfilter '
            'level=warning action=blocked srcip=10.0.0.2 dstip=8.8.8.8',
            "webfilter",
            "blocked",
        ),
        (
            'date=2026-08-24 time=18:10:00 type=utm subtype=app-ctrl '
            'level=notice action=blocked srcip=10.0.0.2 dstip=8.8.8.8',
            "app-ctrl",
            "blocked",
        ),
    ],
)
def test_fortigate_categories_are_stable(raw, expected_type, expected_action):
    result = parse_syslog_event(raw)
    assert result["log_type"] == expected_type
    assert result["action"] == expected_action


def test_vpn_fields_use_fortigate_names_and_keep_human_message():
    result = parse_syslog_event(
        'date=2026-08-24 time=18:10:00 devname=FGT type=event subtype=vpn '
        'level=notice eventtype=sslvpn-login remip=10.20.0.11 tunnelip=10.212.0.2 '
        'username=alice tunnelid=abc123 msg="SSL VPN login"'
    )
    assert result["log_type"] == "vpn"
    assert result["src_ip"] == "10.20.0.11"
    assert result["dst_ip"] == "10.212.0.2"
    assert result["user"] == "alice"
    assert result["session_id"] == "abc123"
    assert result["action"] == "sslvpn-login"
    assert result["parsed_fields"]["msg"] == "SSL VPN login"


def test_analyzer_does_not_classify_user_auth_event_as_vpn():
    """A user field alone is common on auth/traffic records, not VPN proof."""
    row = FirewallLog(
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        log_type="event",
        log_subtype="auth",
        severity="notice",
        action="auth",
        user="guest-101",
        raw_syslog="type=event subtype=auth action=auth user=guest-101",
        parsed_fields={"type": "event", "subtype": "auth", "action": "auth", "user": "guest-101"},
    )
    assert _effective_firewall_log_type(row) == "event"


def test_pfsense_filterlog_uses_action_direction_and_network_tuple():
    result = parse_firewall_syslog(
        "filterlog: 4,,,1000000103,em0,match,block,in,4,0x0,,64,12345,0,none,6,tcp,60,"
        "10.0.0.2,8.8.8.8,51542,443,,-",
        "pfsense",
    )
    assert result["vendor"] == "pfsense"
    assert result["policyid"] == 1000000103
    assert result["action"] == "deny"
    assert result["log_subtype"] == "in"
    assert result["proto"] == "tcp"
    assert result["src_ip"] == "10.0.0.2"
    assert result["dst_ip"] == "8.8.8.8"
    assert result["src_port"] == 51542
    assert result["dst_port"] == 443


def test_cisco_asa_teardown_is_canonicalized():
    result = parse_firewall_syslog(
        "%ASA-6-302014: Teardown TCP connection 42 for inside:10.0.0.2/51542"
        " to outside:8.8.8.8/443 duration 0:00:03 bytes 1200",
        "cisco_asa",
    )
    assert result["vendor"] == "cisco_asa"
    assert result["log_type"] == "traffic"
    assert result["action"] == "close"
    assert result["session_id"] == "42"
    assert result["sentbyte"] == 1200
