"""Focused repository checks for HOT-5651-ANALYZER-007."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

import pytest
from fastapi import HTTPException

from app.core.database import Base
from app.core.rbac import has_permission
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.analyzer.models import (
    AnalyzerEvidenceExport,
    AnalyzerIngestFailure,
    AnalyzerLegalHold,
    AnalyzerNormalizedEvent,
    AnalyzerRawEvent,
    AnalyzerReport,
    AnalyzerSavedView,
    AnalyzerSourceHealth,
)
from app.modules.analyzer.schemas import AnalyzerSearchParams
from app.modules.analyzer.service import (
    PARSER_VERSION,
    _assert_idempotent_payload,
    _json_hash,
    _parse_event,
    _request_hash,
    _report_snapshot,
    _search_clauses,
    _ingest_request_hash,
    report_csv,
    scope_clause,
)


def test_parser_produces_network_projection_with_provenance_fields():
    raw = (
        'date=2026-08-31 time=14:12:13 tz="+0300" devname="edge-fw" '
        'type=traffic srcip=10.0.0.4 dstip=1.1.1.1 srcport=443 dstport=53 '
        'srcmac=AA:BB:CC:DD:EE:FF user=guest policyid=7 action=accept '
        'transip=192.0.2.10 transport=54321 qname=example.org '
        'dns_answers=93.184.216.34 sessionid=abc123'
    )
    event = _parse_event(raw, "firewall")
    assert event["source_name"] == "edge-fw"
    assert event["category"] == "traffic"
    assert event["source_ip_address"] == "10.0.0.4"
    assert event["nat_source_ip"] == "192.0.2.10"
    assert event["dns_query"] == "example.org"
    assert event["occurred_at"].tzinfo == timezone.utc
    assert event["occurred_at"].hour == 11  # +03:00 converted to UTC
    assert PARSER_VERSION == "fortigate-v1"


def test_parser_rejects_unrecognized_payload_and_supports_vendor_hint():
    with pytest.raises(ValueError, match="PARSER_UNRECOGNIZED_PAYLOAD"):
        _parse_event("not a syslog payload", "firewall")
    mikrotik = _parse_event("firewall,info accept src=10.0.0.4 dst=1.1.1.1", "mikrotik")
    assert mikrotik["vendor"] == "mikrotik"
    assert mikrotik["action"] == "accept"


def test_normalized_fields_never_retain_raw_message_or_secrets():
    raw = 'firewall,info accept src=10.0.0.4 password="do-not-store" token=abc'
    event = _parse_event(raw, "mikrotik")
    assert "raw_message" not in event["fields"]
    assert "raw" not in event["fields"]
    assert event["fields"]["password"] == "[redacted]"
    assert event["fields"]["token"] == "[redacted]"

    rfc_event = _parse_event(
        '<34>1 2026-08-31T14:12:13Z edge-fw app - - password=do-not-store srcip=10.0.0.4',
        "firewall",
    )
    assert "do-not-store" not in str(rfc_event["fields"])


def test_scope_clause_fails_closed_for_unassigned_scope():
    tenant = uuid.uuid4()
    clause = scope_clause(AnalyzerNormalizedEvent, ScopeContext(TenantLevel.CUSTOMER, customer_id=tenant, allowed=True))
    assert str(clause.left) == "analyzer_normalized_events.customer_id"
    denied = scope_clause(AnalyzerNormalizedEvent, ScopeContext(TenantLevel.CUSTOMER, allowed=False))
    assert str(denied) in {"false", "false"}


def test_broad_operator_report_projection_can_be_narrowed_to_customer():
    customer_id = uuid.uuid4()
    clauses = _search_clauses(
        AnalyzerSearchParams(),
        ScopeContext(TenantLevel.GLOBAL),
        customer_id=customer_id,
    )
    assert any(str(clause).endswith("customer_id = :customer_id_1") for clause in clauses)


def test_content_idempotency_fingerprint_ignores_generated_receive_time():
    args = {
        "tenant_id": uuid.uuid4(),
        "customer_id": uuid.uuid4(),
        "raw_sha256": "a" * 64,
        "source_name": "edge-fw",
        "source_type": "firewall",
        "transport": "syslog",
        "source_ip": "192.0.2.5",
    }
    first = _ingest_request_hash(**args, received_at=datetime(2026, 8, 31, tzinfo=timezone.utc), include_received_at=False)
    second = _ingest_request_hash(**args, received_at=datetime(2026, 9, 1, tzinfo=timezone.utc), include_received_at=False)
    assert first == second


def test_analyzer_metadata_contains_all_storage_boundaries():
    expected = {
        "analyzer_raw_events", "analyzer_normalized_events", "analyzer_ingest_failures",
        "analyzer_source_health", "analyzer_legal_holds", "analyzer_evidence_exports",
        "analyzer_reports", "analyzer_saved_views",
    }
    assert expected.issubset(Base.metadata.tables)
    assert AnalyzerRawEvent.__table__.c.raw_payload.type.length is None
    assert AnalyzerNormalizedEvent.__table__.c.raw_event_id is not None
    assert "uq_analyzer_raw_tenant_idempotency" in {
        constraint.name for constraint in AnalyzerRawEvent.__table__.constraints
    }
    raw_unique = next(
        constraint for constraint in AnalyzerRawEvent.__table__.constraints
        if constraint.name == "uq_analyzer_raw_tenant_idempotency"
    )
    assert {column.name for column in raw_unique.columns} == {"tenant_id", "customer_id", "idempotency_key"}
    health_unique = next(
        constraint for constraint in AnalyzerSourceHealth.__table__.constraints
        if constraint.name == "uq_analyzer_source_health_tenant_source"
    )
    assert {column.name for column in health_unique.columns} == {"tenant_id", "customer_id", "source_name"}


def test_permissions_separate_read_and_write_surfaces():
    assert has_permission("customer_admin", "analyzer.read")
    assert has_permission("customer_admin", "analyzer.hold")
    assert has_permission("location_manager", "analyzer.read")
    assert not has_permission("location_manager", "analyzer.write")
    assert not has_permission("location_manager", "analyzer.raw.read")
    assert not has_permission("support", "analyzer.raw.read")


def test_report_snapshot_and_csv_are_explicit_about_evidence_limitations():
    event_id = uuid.uuid4()
    event = {
        "id": event_id,
        "raw_event_id": uuid.uuid4(),
        "tenant_id": uuid.uuid4(),
        "customer_id": uuid.uuid4(),
        "occurred_at": datetime.now(timezone.utc),
        "received_at": datetime.now(timezone.utc),
        "source_name": "edge-fw",
        "source_type": "firewall",
        "transport": "syslog",
        "vendor": "fortigate",
        "category": "traffic",
        "severity": "info",
        "raw_sha256": "a" * 64,
        "normalized_sha256": "b" * 64,
        "parser_version": PARSER_VERSION,
        "retention_until": datetime.now(timezone.utc),
        "provenance": {"raw_payload": "stored_separately"},
        "fields": {},
        "source_ip": "10.0.0.4",
        "destination_ip": "1.1.1.1",
        "source_mac": None,
        "identity": "guest",
        "session_id": "s1",
        "action": "accept",
    }
    from app.modules.analyzer.schemas import AnalyzerEventOut

    model = AnalyzerEventOut.model_validate(event)
    snapshot = _report_snapshot([model], report_type="network_analyzer", from_time=None, to_time=None)
    assert snapshot["evidence_status"] == "verified_projection"
    assert "yasal uygunluk" in " ".join(snapshot["limitations"])
    report = AnalyzerReport(
        id=uuid.uuid4(), tenant_id=model.tenant_id, customer_id=model.customer_id,
        report_type="network_analyzer", schema_version="1.0", generated_at=datetime.now(timezone.utc),
        sha256_hash=_json_hash(snapshot), provenance={}, snapshot={"snapshot": snapshot}, idempotency_key="test",
    )
    assert "source_name" in report_csv(report)


def test_idempotency_fingerprint_rejects_payload_reuse():
    first = AnalyzerReport(
        id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        report_type="network_analyzer",
        schema_version="1.0",
        generated_at=datetime.now(timezone.utc),
        sha256_hash="a" * 64,
        provenance={"request_hash": "stored"},
        snapshot={},
        idempotency_key="same-key",
    )
    assert _request_hash({"tenant_id": "t", "idempotency_key": "same-key"}) == _request_hash(
        {"tenant_id": "t", "idempotency_key": "other-key"}
    )
    _assert_idempotent_payload(first, "stored")
    with pytest.raises(HTTPException) as exc_info:
        _assert_idempotent_payload(first, "different")
    assert exc_info.value.status_code == 409
