from __future__ import annotations

import asyncio
import logging
import os
from unittest import mock

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.pool import NullPool

from app.core.config import settings as app_settings
from app.core.database import Base

log = logging.getLogger(__name__)

TEST_PHONE = "+905551112233"
TEST_CODE = "123456"
TEST_CERT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), "data", "test-cert.p12"
)
TEST_CERT_PASSWORD = "test123"

TEST_DB_URL = os.getenv(
    "E2E_DATABASE_URL",
    "postgresql+asyncpg://hotspot:hotspot@localhost:55432/hotspot",
)
TEST_MINIO_ENDPOINT = os.getenv("E2E_MINIO_ENDPOINT", "localhost:59002")
TEST_MINIO_ACCESS_KEY = os.getenv("E2E_MINIO_ACCESS_KEY", "minioadmin")
TEST_MINIO_SECRET_KEY = os.getenv("E2E_MINIO_SECRET_KEY", "minioadmin")


def _ensure_all_models_loaded():
    import app.modules.tenants.models
    import app.modules.partners.models
    import app.modules.customers.models
    import app.modules.locations.models
    import app.modules.devices.models
    import app.modules.auth.models
    import app.modules.sessions.models
    import app.modules.portal.models
    import app.modules.syslog.models
    import app.modules.archive.models
    import app.modules.identity.models
    import app.modules.sms.models

def pytest_configure(config):
    _ensure_all_models_loaded()

    config.addinivalue_line("markers", "e2e: end-to-end integration test")
    config.addinivalue_line("markers", "slow: performance benchmark")


@pytest.fixture(autouse=True)
def _isolate_e2e_settings(monkeypatch):
    """Apply integration settings per test instead of mutating global state.

    The e2e suite is collected alongside the unit suite.  Mutating the shared
    settings object in ``pytest_configure`` leaked MinIO/console settings into
    unrelated tests and was the source of the late full-suite stall.
    """
    overrides = {
        "DATABASE_URL": TEST_DB_URL,
        "REDIS_URL": os.getenv("E2E_REDIS_URL", "redis://localhost:56379/0"),
        "ARCHIVE_MINIO_ENDPOINT": TEST_MINIO_ENDPOINT,
        "ARCHIVE_MINIO_ACCESS_KEY": TEST_MINIO_ACCESS_KEY,
        "ARCHIVE_MINIO_SECRET_KEY": TEST_MINIO_SECRET_KEY,
        "ARCHIVE_MINIO_BUCKET": "hotspot-5651-test",
        "ARCHIVE_PROVIDER": "minio",
        "SMS_PROVIDER": "console",
        "SMS_OTP_LENGTH": 6,
        "DISABLE_RATE_LIMIT": True,
        "DEMO_MODE": False,
        "PORTAL_TOKEN_TTL_SECONDS": 3600,
        "GUEST_SESSION_DEFAULT_MINUTES": 480,
    }
    for name, value in overrides.items():
        monkeypatch.setattr(app_settings, name, value)


async def create_db_session(db_url: str = TEST_DB_URL):
    engine = create_async_engine(db_url, poolclass=NullPool, echo=False)
    conn = await engine.connect()
    tx = await conn.begin()
    await conn.execute(text("SET CONSTRAINTS ALL DEFERRED"))
    session = AsyncSession(bind=conn, expire_on_commit=False)
    return engine, session, conn, tx


async def close_db_session(engine, session, conn, tx):
    await tx.rollback()
    await conn.close()
    await engine.dispose()


@pytest.fixture
def e2e_config():
    return {
        "db_url": TEST_DB_URL,
        "cert_path": TEST_CERT_PATH,
        "cert_password": TEST_CERT_PASSWORD,
    }


@pytest.fixture
def minio_client():
    try:
        from minio import Minio
    except ImportError:
        from unittest.mock import MagicMock
        mock_client = MagicMock()
        mock_client.bucket_exists.return_value = True
        return mock_client

    client = Minio(
        TEST_MINIO_ENDPOINT,
        access_key=TEST_MINIO_ACCESS_KEY,
        secret_key=TEST_MINIO_SECRET_KEY,
        secure=False,
    )
    bucket = "hotspot-5651-test"
    if not client.bucket_exists(bucket):
        client.make_bucket(bucket, object_lock=False)
    return client


@pytest.fixture
def test_cert():
    assert os.path.exists(TEST_CERT_PATH), f"Cert not found at {TEST_CERT_PATH}"
    return TEST_CERT_PATH


@pytest.fixture
def patch_sms_code():
    with mock.patch("app.modules.sms.service._gen_code", return_value=TEST_CODE):
        yield
