"""Focused HOT-LIC-001 consumer, negative and race tests."""
from __future__ import annotations

import asyncio
import base64
import json
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest import mock

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519
from fastapi import HTTPException

from app.core.config import settings
from app.modules.licensing import service as licensing_service
from app.modules.system.models import PlatformSetting
from app.shared.licensing.contract import (
    CanonicalLicenseError,
    validate_duration_months,
    validate_limits,
)
from app.shared.licensing.license_service import (
    get_hotspot_license,
    get_platform_license,
)


def _envelope(payload: dict, private: ed25519.Ed25519PrivateKey) -> str:
    payload_b64 = base64.urlsafe_b64encode(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).decode()
    signature = base64.urlsafe_b64encode(private.sign(payload_b64.encode())).decode()
    return json.dumps({
        "schema_version": 1,
        "key_id": "vdata-license-prod-2026-01",
        "algorithm": "Ed25519",
        "payload": payload_b64,
        "signature": signature,
    })


def _payload(*, tenant: str = "tenant-1", **changes: object) -> dict:
    value = {
        "payload_schema_version": 1,
        "license_id": "hotspot-test-1",
        "issuer": "NeoSecra",
        "product_code": "hotspot",
        "tenant_id": tenant,
        "valid_from": "2026-01-01T00:00:00Z",
        "expires_at": "2030-01-01T00:00:00Z",
        "duration_months": 12,
        "entitlements": ["hotspot.core"],
        "limits": {"max_concurrent_sessions": 10},
    }
    value.update(changes)
    return value


def _db_with_envelope(envelope: str):
    db = mock.AsyncMock()
    result = mock.MagicMock()
    result.scalar_one_or_none.return_value = PlatformSetting(
        key="platform_license",
        value=json.dumps({"envelope_string": envelope}),
        category="system",
        is_secret=True,
    )
    db.execute.return_value = result
    return db


def _db_with_legacy_binding(envelope: str, tenant_ids: list[str]):
    """DB double for the strict legacy projection's ownership query."""
    db = _db_with_envelope(envelope)
    setting_result = db.execute.return_value
    binding_result = mock.MagicMock()
    binding_result.all.return_value = [
        SimpleNamespace(tenant_id=tenant_id) for tenant_id in tenant_ids
    ]
    db.execute.side_effect = [setting_result, binding_result]
    return db


@pytest.fixture
def keyring(monkeypatch):
    private = ed25519.Ed25519PrivateKey.generate()
    public = base64.urlsafe_b64encode(private.public_key().public_bytes_raw()).decode()
    monkeypatch.setattr(
        "app.shared.licensing.license_service.TRUSTED_KEYRING",
        {"vdata-license-prod-2026-01": {"public_key_b64": public, "status": "active"}},
    )
    return private


def test_duration_and_hotspot_limit_contract():
    for value in (1, 12, 24, 36, 120):
        assert validate_duration_months(value) == value
    for value in (0, 121, True, "12"):
        with pytest.raises(CanonicalLicenseError, match="INVALID_DURATION"):
            validate_duration_months(value)
    for value in (5, 10, 50, 1, 100000):
        assert validate_limits("hotspot", {"max_concurrent_sessions": value})["max_concurrent_sessions"] == value
    for limits in ({}, {"max_concurrent_sessions": 0}, {"max_concurrent_sessions": 100001}, {"max_users": 1}):
        with pytest.raises(CanonicalLicenseError):
            validate_limits("hotspot", limits)


@pytest.mark.asyncio
async def test_canonical_consumer_rejects_tenant_mismatch(keyring):
    db = _db_with_envelope(_envelope(_payload(tenant="tenant-a"), keyring))
    result = await get_hotspot_license(db, "tenant-b")
    assert result["status"] == "TENANT_MISMATCH"
    assert result["enabled_modules"] == []


@pytest.mark.asyncio
async def test_canonical_consumer_rejects_product_mismatch_and_revocation(monkeypatch, keyring):
    mismatch = _payload(product_code="assessment", entitlements=["assessment.core"])
    result = await get_hotspot_license(_db_with_envelope(_envelope(mismatch, keyring)), "tenant-1")
    assert result["status"] == "INVALID_PRODUCT"

    monkeypatch.setattr(
        "app.shared.licensing.license_service.load_cached_crl",
        lambda: {"revoked_licenses": {"hotspot-test-1": "security"}, "cached_at": datetime.now(timezone.utc).isoformat()},
    )
    result = await get_hotspot_license(
        _db_with_envelope(_envelope(_payload(), keyring)),
        "tenant-1",
    )
    assert result["status"] == "REVOKED"
    assert result["enabled_modules"] == []


@pytest.mark.asyncio
async def test_canonical_consumer_rejects_missing_entitlement_and_quota(keyring):
    for changes, code in (
        ({"entitlements": ["hotspot.invalid"]}, "INVALID_ENTITLEMENTS"),
        ({"entitlements": [], "limits": {"max_concurrent_sessions": 10}}, "INVALID_ENTITLEMENTS"),
        ({"limits": {}}, "MISSING_LIMIT"),
    ):
        # Invalid canonical payloads are rejected before the consumer can
        # derive a usable entitlement or quota.
        db = _db_with_envelope(_envelope(_payload(**changes), keyring))
        result = await get_hotspot_license(db, "tenant-1")
        assert result["status"] == "CANONICAL_INVALID"
        assert result["error_code"] == code


@pytest.mark.asyncio
async def test_canonical_consumer_rejects_expired_and_bad_signature(keyring):
    expired = _payload(
        expires_at=(datetime.now(timezone.utc) - timedelta(days=1)).isoformat().replace("+00:00", "Z")
    )
    result = await get_hotspot_license(_db_with_envelope(_envelope(expired, keyring)), "tenant-1")
    assert result["status"] == "EXPIRED"

    envelope = json.loads(_envelope(_payload(), keyring))
    envelope["signature"] = base64.urlsafe_b64encode(b"x" * 64).decode()
    result = await get_hotspot_license(_db_with_envelope(json.dumps(envelope)), "tenant-1")
    assert result["status"] == "INVALID_SIGNATURE"


@pytest.mark.asyncio
async def test_canonical_consumer_rejects_installation_mismatch(keyring):
    payload = _payload(installation_id="host-a")
    result = await get_hotspot_license(_db_with_envelope(_envelope(payload, keyring)), "tenant-1")
    assert result["status"] == "INSTALLATION_MISMATCH"


@pytest.mark.asyncio
async def test_legacy_payload_is_readable_but_not_a_hotspot_entitlement(keyring):
    legacy = {
        "license_id": "legacy-1", "issuer": "VData",
        "valid_from": "2026-01-01T00:00:00Z", "expires_at": "2030-01-01T00:00:00Z",
        "limits": {"max_customers": 1}, "modules": ["hotspot_core"],
    }
    db = _db_with_envelope(_envelope(legacy, keyring))
    readable = await get_platform_license(db)
    assert readable["legacy_warning"] is True
    strict = await get_hotspot_license(db, "tenant-1")
    assert strict["status"] == "CANONICAL_INVALID"
    assert strict["error_code"] == "MISSING_FIELD"


@pytest.mark.asyncio
async def test_signed_legacy_hotspot_payload_gets_bounded_single_tenant_projection(keyring):
    legacy = {
        "license_id": "legacy-hotspot-1",
        "issuer": "VData",
        "product_code": "hotspot",
        "valid_from": "2026-08-29T00:00:00Z",
        "expires_at": "2027-08-29T23:59:59Z",
        "limits": {},
        "modules": ["hotspot_core", "logs_5651", "radius"],
    }
    db = _db_with_legacy_binding(_envelope(legacy, keyring), ["tenant-1"])

    result = await get_hotspot_license(db, "tenant-1")

    assert result["status"] == "ACTIVE"
    assert result["legacy_warning"] is True
    assert result["legacy_compatibility"] == "signed_ed25519_single_active_customer"
    assert result["tenant_id"] == "tenant-1"
    assert result["entitlements"] == ["hotspot.core"]
    assert result["max_concurrent_sessions"] == 50
    assert result["limits"] == {"max_concurrent_sessions": 50}


@pytest.mark.asyncio
async def test_signed_legacy_hotspot_payload_fails_closed_for_ambiguous_tenants(keyring):
    legacy = {
        "license_id": "legacy-hotspot-ambiguous",
        "issuer": "VData",
        "product_code": "hotspot",
        "valid_from": "2026-08-29T00:00:00Z",
        "expires_at": "2027-08-29T23:59:59Z",
        "limits": {},
        "modules": ["hotspot_core"],
    }
    db = _db_with_legacy_binding(_envelope(legacy, keyring), ["tenant-1", "tenant-2"])

    result = await get_hotspot_license(db, "tenant-1")

    assert result["status"] == "TENANT_MISMATCH"
    assert result["error_code"] == "LEGACY_TENANT_AMBIGUOUS"
    assert result["enabled_modules"] == []


class _RaceResult:
    def __init__(self, *, customer=None, count=None):
        self.customer = customer
        self.count = count

    def scalar_one_or_none(self):
        return self.customer

    def scalar_one(self):
        return self.count


class _AtomicQuotaDb:
    """Small DB double that models a row lock and the downstream insert."""

    def __init__(self):
        self.lock = asyncio.Lock()
        self.active = 0
        self.customer = SimpleNamespace(tenant_id="tenant-1")

    async def execute(self, statement):
        if getattr(statement, "_for_update_arg", None) is not None:
            await self.lock.acquire()
            return _RaceResult(customer=self.customer)
        # enforce_quota's count runs while the customer lock is held. Simulate
        # the caller's session insert and commit before releasing that lock.
        current = self.active
        self.active += 1
        self.lock.release()
        await asyncio.sleep(0)
        return _RaceResult(count=current)


@pytest.mark.asyncio
async def test_concurrent_quota_checks_are_serialized(monkeypatch):
    db = _AtomicQuotaDb()
    import uuid
    customer_id = uuid.uuid4()
    monkeypatch.setattr(settings, "ENVIRONMENT", "production")
    monkeypatch.setattr(
        licensing_service,
        "get_hotspot_license",
        mock.AsyncMock(return_value={"status": "ACTIVE", "max_concurrent_sessions": 1}),
    )
    outcomes = await asyncio.gather(
        licensing_service.enforce_quota(db, customer_id),
        licensing_service.enforce_quota(db, customer_id),
        return_exceptions=True,
    )
    assert sum(isinstance(item, HTTPException) for item in outcomes) == 1
    assert sum(not isinstance(item, Exception) for item in outcomes) == 1


@pytest.mark.asyncio
async def test_production_missing_license_fails_closed(monkeypatch):
    db = mock.AsyncMock()
    lock_result = mock.MagicMock()
    lock_result.scalar_one_or_none.return_value = SimpleNamespace(tenant_id="tenant-1")
    db.execute.return_value = lock_result
    monkeypatch.setattr(settings, "ENVIRONMENT", "production")
    monkeypatch.setattr(licensing_service, "get_hotspot_license", mock.AsyncMock(return_value=None))
    import uuid
    with pytest.raises(HTTPException) as exc:
        await licensing_service.enforce_quota(db, uuid.uuid4())
    assert exc.value.status_code == 402
