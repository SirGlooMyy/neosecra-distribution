from app.modules.radius.runtime import _quote_secret, _render_client
from pathlib import Path


def test_runtime_client_block_validates_network_and_quotes_secret():
    block = _render_client("fortigate_demo", "192.168.2.1", "shared secret")
    assert "client fortigate_demo" in block
    assert "ipaddr = 192.168.2.1" in block
    assert 'secret = "shared secret"' in block


def test_runtime_secret_rejects_control_characters():
    try:
        _quote_secret("bad\nsecret")
    except ValueError:
        pass
    else:
        raise AssertionError("control characters must not reach clients.conf")


def test_freeradius_rest_forwards_api_key_from_environment():
    """Every REST leg must authenticate to the API, including accounting."""
    config = Path(__file__).parents[2] / "infra" / "freeradius" / "sites-enabled" / "default"
    text = config.read_text(encoding="utf-8")
    assert '&REST-HTTP-Header := "X-API-Key: $ENV{RADIUS_API_KEY}"' in text
    assert text.count('&REST-HTTP-Header := "X-API-Key: $ENV{RADIUS_API_KEY}"') >= 2
    assert "&State" in text
    assert "Auth-Type := MFA" in text
    assert "Auth-Type Challenge" in text
    assert "            challenge" in text
    rest = (Path(__file__).parents[2] / "infra" / "freeradius" / "mods-available" / "rest").read_text(encoding="utf-8")
    assert "/vpn/challenge/verify\"" in rest
    assert "/vpn/challenge/init\"" in rest
    assert "body = \"json\"" in rest
    assert 'data = "{\\"state\\":' in rest


def test_compose_passes_radius_api_key_without_default_secret():
    compose = (Path(__file__).parents[2] / "docker-compose.yml").read_text(encoding="utf-8")
    assert "RADIUS_API_KEY: ${RADIUS_API_KEY:-}" in compose
    assert compose.count("RADIUS_API_KEY: ${RADIUS_API_KEY:-}") >= 2


def test_runtime_uses_actual_api_source_address_for_internal_probe():
    source = (Path(__file__).parents[1] / "app" / "modules" / "radius" / "runtime.py").read_text(encoding="utf-8")
    assert "probe.connect((settings.RADIUS_INTERNAL_HOST, settings.RADIUS_INTERNAL_PORT))" in source
    assert "f" + '"{internal_source_ip}/32"' in source
    assert "172.18.0.0/16" not in source
