"""archive_service.py tests — content hash, compression, upload."""
import json
import os
import uuid
from datetime import datetime, timezone

import pytest

from app.modules.logs_5651.archive_service import (
    content_hash,
    compress,
    decompress,
    read_archive_payload,
    serialize_jsonl,
    _object_key,
    _COMPRESSION_EXT,
    is_compatibility_reference,
)


def test_content_hash_deterministic():
    data = b"test content"
    assert content_hash(data) == content_hash(data)


def test_content_hash_different():
    assert content_hash(b"foo") != content_hash(b"bar")


def test_content_hash_length():
    h = content_hash(b"anything")
    assert len(h) == 64
    assert isinstance(h, str)


def test_compress_decompress_zstd_roundtrip():
    data = b"Hotspot archive test data " * 100
    compressed = compress(data)
    assert len(compressed) < len(data)
    assert compressed != data
    decompressed = decompress(compressed)
    assert decompressed == data


def test_compress_decompress_reversible():
    data = b"simple data"
    assert decompress(compress(data)) == data


def test_compress_empty():
    assert decompress(compress(b"")) == b""


def test_serialize_jsonl_empty():
    result = serialize_jsonl([])
    assert result == b""


def test_serialize_jsonl_single():
    records = [{"id": "1", "value": "test"}]
    result = serialize_jsonl(records)
    expected = json.dumps(records[0], default=str, ensure_ascii=False)
    assert result == expected.encode("utf-8")


def test_serialize_jsonl_multiple():
    records = [{"a": 1}, {"b": 2}]
    result = serialize_jsonl(records)
    lines = result.split(b"\n")
    assert len(lines) == 2
    assert json.loads(lines[0]) == {"a": 1}
    assert json.loads(lines[1]) == {"b": 2}


def test_object_key_format():
    cid = uuid.uuid4()
    ps = datetime(2026, 6, 15, 10, 30, tzinfo=timezone.utc)
    chash = "abc123" + "0" * 58
    key = _object_key(cid, ps, chash)
    assert str(cid) in key
    assert "20260615" in key
    assert key.endswith(_COMPRESSION_EXT)
    assert chash in key


def test_object_key_unique_per_hash():
    cid = uuid.uuid4()
    ps = datetime(2026, 6, 15, tzinfo=timezone.utc)
    k1 = _object_key(cid, ps, "hash1" + "0" * 59)
    k2 = _object_key(cid, ps, "hash2" + "0" * 59)
    assert k1 != k2


def test_upload_local(temp_archive_dir, monkeypatch):
    from app.core.config import settings
    from app.modules.logs_5651.archive_service import upload

    monkeypatch.setattr(settings, "ARCHIVE_PROVIDER", "local")
    monkeypatch.setattr(settings, "ARCHIVE_LOCAL_DIR", temp_archive_dir)

    content = b"test archive payload"
    cid = uuid.uuid4()
    ps = datetime(2026, 7, 1, tzinfo=timezone.utc)
    ref = upload(content, customer_id=cid, period_start=ps)
    assert ref.startswith("local:")
    path = ref[6:]
    assert os.path.exists(path)
    assert read_archive_payload(ref) == content


def test_upload_none_provider(monkeypatch):
    from app.core.config import settings
    from app.modules.logs_5651.archive_service import upload

    monkeypatch.setattr(settings, "ARCHIVE_PROVIDER", "none")
    content = b"test payload"
    cid = uuid.uuid4()
    ps = datetime(2026, 7, 1, tzinfo=timezone.utc)
    ref = upload(content, customer_id=cid, period_start=ps)
    assert ref.startswith("none:")
    assert is_compatibility_reference(ref) is True
    assert content_hash(content) in ref
    assert read_archive_payload(ref) is None


def test_upload_none_provider_is_forbidden_in_production(monkeypatch):
    from app.core.config import settings
    from app.modules.logs_5651.archive_service import upload

    monkeypatch.setattr(settings, "ARCHIVE_PROVIDER", "none")
    monkeypatch.setattr(settings, "ENVIRONMENT", "production")
    with pytest.raises(RuntimeError, match="compatibility-only"):
        upload(b"test payload", customer_id=uuid.uuid4(), period_start=datetime(2026, 7, 1, tzinfo=timezone.utc))
