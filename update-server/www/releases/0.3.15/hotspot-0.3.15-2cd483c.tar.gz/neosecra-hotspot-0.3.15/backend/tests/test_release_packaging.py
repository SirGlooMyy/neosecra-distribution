"""Regression coverage for the signed Hotspot source archive boundary."""

from __future__ import annotations

import subprocess
import tarfile
from pathlib import Path


def test_build_release_excludes_runtime_and_certificate_artifacts(tmp_path: Path) -> None:
    """The release archive must not carry local test/runtime secrets."""

    root = Path(__file__).resolve().parents[2]
    archive = tmp_path / "hotspot-0.0.0.tar.gz"
    subprocess.run(
        [str(root / "scripts" / "build-release.sh"), "0.0.0", str(archive)],
        cwd=root,
        check=True,
        capture_output=True,
        text=True,
    )

    with tarfile.open(archive, "r:gz") as bundle:
        names = bundle.getnames()

    assert any(name.endswith("/docker-compose.yml") for name in names)
    assert any(name.endswith("/backend/.env.example") for name in names)
    assert not any(
        name.endswith((".p12", ".pfx", ".jks"))
        or "/test-results/" in name
        or name.endswith("/test-results")
        for name in names
    )
    assert not any(name.endswith("/.env") for name in names)
