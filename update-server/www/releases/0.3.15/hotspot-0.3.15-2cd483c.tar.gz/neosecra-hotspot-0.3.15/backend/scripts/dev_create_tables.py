"""DEV-ONLY bootstrap: create all tables from model metadata.

Use this so the docker-compose dev stack has a working schema out of the box,
because the alembic versions/ directory is still empty (no migrations generated
yet). create_all is idempotent (CREATE IF NOT EXISTS) and safe to re-run.

PRODUCTION MUST NOT use this — it bypasses the migration history. Prod runs
`alembic upgrade head` against reviewed migration files. This script merely
removes the "no tables" friction for local/docker dev.

Run:  python scripts/dev_create_tables.py
      (or DEV_CREATE_TABLES=1 via docker-entrypoint.sh)
"""
import asyncio

from sqlalchemy.ext.asyncio import create_async_engine

from app.core.config import settings
from app.core.database import Base

# Mirror the model imports in alembic/env.py so metadata sees every table.
import app.modules.tenants.models  # noqa: F401
import app.modules.partners.models  # noqa: F401
import app.modules.customers.models  # noqa: F401
import app.modules.locations.models  # noqa: F401
import app.modules.audit.models  # noqa: F401
import app.modules.auth.models  # noqa: F401
import app.modules.devices.models  # noqa: F401
import app.modules.portal.models  # noqa: F401
import app.modules.sms.models  # noqa: F401
import app.modules.vouchers.models  # noqa: F401
import app.modules.identity.models  # noqa: F401
import app.modules.sessions.models  # noqa: F401
import app.modules.logs_5651.models  # noqa: F401
import app.modules.licensing.models  # noqa: F401
import app.modules.analyzer.models  # noqa: F401
# radius/syslog/archive/reports/workers/site_bridge/firewall_adapters are stubs
# (no __tablename__) today, so they add no tables; env.py omits them for parity.


async def main() -> None:
    engine = create_async_engine(settings.DATABASE_URL, pool_pre_ping=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    await engine.dispose()
    print("[dev] tables ensured from metadata")


if __name__ == "__main__":
    asyncio.run(main())
