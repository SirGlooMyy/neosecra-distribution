"""Alarm dashboard endpoints — Real firewall security incidents & stats."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.alarm import service as alarm_service
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=403, detail="Yetkisiz islem")


def _serialize_alarm_event(event, trigger_name: str | None = None) -> dict:
    return {
        "id": str(event.id),
        "customer_id": str(event.customer_id) if getattr(event, "customer_id", None) else None,
        "location_id": str(event.location_id) if getattr(event, "location_id", None) else None,
        "trigger_id": str(event.trigger_id) if getattr(event, "trigger_id", None) else None,
        "trigger_name": trigger_name or getattr(event, "trigger_name", None),
        "severity": getattr(event, "severity", None),
        "title": getattr(event, "title", None),
        "message": getattr(event, "message", None),
        "source": getattr(event, "source", None),
        "acknowledged": getattr(event, "acknowledged", False),
        "acknowledged_at": event.acknowledged_at.isoformat() if getattr(event, "acknowledged_at", None) else None,
        "acknowledged_by": str(event.acknowledged_by) if getattr(event, "acknowledged_by", None) else None,
        "event_time": event.event_time.isoformat() if getattr(event, "event_time", None) else None,
        "timestamp": event.event_time.isoformat() if getattr(event, "event_time", None) else None,
    }


@router.get("/events", summary="List alarm events with severity filter")
async def list_alarm_events(
    severity: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    return await alarm_service.list_real_alarm_events(
        db, customer_id=scope.customer_id, severity=severity, limit=limit, offset=offset
    )


@router.post("/events/{event_id}/acknowledge", summary="Acknowledge an alarm event")
async def acknowledge_alarm(
    event_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.write")
    return await alarm_service.acknowledge_alarm(db, event_id, user.id)


@router.get("/stats", summary="Get alarm event statistics")
async def get_alarm_stats(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    return await alarm_service.get_alarm_stats(db, customer_id=scope.customer_id)


@router.get("/trend", summary="Get alarm event trend data over time")
async def get_alarm_trend(
    days: int = Query(14, ge=1, le=90),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    return await alarm_service.get_alarm_trend(db, customer_id=scope.customer_id, days=days)
