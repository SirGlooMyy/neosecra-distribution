"""Business logic for licensing + quota enforcement (Mutlak Kural #12).

Quota enforcement is the captive-flow gate: before a guest session is created
the portal calls enforce_quota(customer_id). The platform's signed canonical
Hotspot license is mandatory; there is no trial/unlimited production fallback.
Legacy ``CustomerLicense`` rows remain available for admin compatibility, but
they are not an authorization source for guest sessions.

Daily counters are computed from GuestSession rows in the live DB (no separate
counter table to drift out of sync); this is a read check, it never mutates
5651/session data (Mutlak Kural #4/#5 — append-only / no purge).
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import func, not_, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.licensing import repository
from app.modules.licensing.models import UNLIMITED, CustomerLicense
from app.modules.licensing.schemas import LicenseUpsert, QuotaStatus
from app.modules.sessions.models import GuestSession, STATUS_ACTIVE
from app.shared.licensing.license_service import get_hotspot_license

log = logging.getLogger(__name__)


async def get_for_customer(db: AsyncSession, customer_id: uuid.UUID) -> CustomerLicense | None:
    return await repository.get_for_customer(db, customer_id)


async def _day_start_utc(now: datetime | None = None) -> datetime:
    """00:00 of today in UTC — the daily-cap window."""
    n = now or datetime.now(timezone.utc)
    return n.replace(hour=0, minute=0, second=0, microsecond=0)


async def quota_status(
    db: AsyncSession, customer_id: uuid.UUID, *, now: datetime | None = None
) -> QuotaStatus:
    """Snapshot the customer's live canonical quota.

    A legacy ``CustomerLicense`` row is still exposed for development/admin
    compatibility, but a resolved customer in production must have a valid
    signed ``hotspot.core`` license.
    """
    lic = await repository.get_for_customer(db, customer_id)
    n = now or datetime.now(timezone.utc)
    day_start = await _day_start_utc(n)

    active_count = (
        await db.execute(
            select(func.count())
            .select_from(GuestSession)
            .where(
                GuestSession.customer_id == customer_id,
                GuestSession.status == STATUS_ACTIVE,
            )
        )
    ).scalar_one()

    daily_used = (
        await db.execute(
            select(func.count())
            .select_from(GuestSession)
            .where(
                GuestSession.customer_id == customer_id,
                GuestSession.started_at >= day_start,
            )
        )
    ).scalar_one()

    customer = await db.get(Customer, customer_id)
    if customer is None and str(getattr(settings, "ENVIRONMENT", "production")).lower() not in {"development", "test"}:
        return QuotaStatus(
            customer_id=customer_id,
            active_guests_quota=0,
            active_count=int(active_count or 0),
            active_remaining=0,
            max_sessions_per_day=None,
            daily_used=int(daily_used or 0),
            daily_remaining=None,
            session_minutes_default=None,
            expired=False,
            active=False,
            within_quota=False,
        )
    if customer is not None:
        canonical = await get_hotspot_license(db, str(customer.tenant_id), now=n)
        if canonical and canonical.get("status") == "ACTIVE":
            quota = int(canonical["max_concurrent_sessions"])
            return QuotaStatus(
                customer_id=customer_id,
                active_guests_quota=quota,
                active_count=int(active_count or 0),
                active_remaining=max(0, quota - int(active_count or 0)),
                max_sessions_per_day=None,
                daily_used=int(daily_used or 0),
                daily_remaining=None,
                session_minutes_default=None,
                expired=False,
                active=True,
                within_quota=int(active_count or 0) < quota,
            )
        if str(getattr(settings, "ENVIRONMENT", "production")).lower() not in {"development", "test"}:
            return QuotaStatus(
                customer_id=customer_id,
                active_guests_quota=0,
                active_count=int(active_count or 0),
                active_remaining=0,
                max_sessions_per_day=None,
                daily_used=int(daily_used or 0),
                daily_remaining=None,
                session_minutes_default=None,
                expired=bool(canonical and canonical.get("status") == "EXPIRED"),
                active=False,
                within_quota=False,
            )

    if lic is None:
        return QuotaStatus(
            customer_id=customer_id,
            active_guests_quota=UNLIMITED,
            active_count=int(active_count or 0),
            active_remaining=UNLIMITED,
            max_sessions_per_day=None,
            daily_used=int(daily_used or 0),
            daily_remaining=None,
            session_minutes_default=None,
            expired=False,
            active=True,
            within_quota=True,
        )

    quota = lic.active_guests_quota
    remaining = UNLIMITED if quota == UNLIMITED else max(0, quota - int(active_count or 0))
    daily_quota = lic.max_sessions_per_day
    daily_remaining = (
        None
        if daily_quota is None or daily_quota == UNLIMITED
        else max(0, daily_quota - int(daily_used or 0))
    )
    expired = bool(lic.expires_at and lic.expires_at <= n)
    active = bool(lic.is_active and not expired)

    over_active = quota != UNLIMITED and int(active_count or 0) >= quota
    over_daily = (
        daily_quota is not None
        and daily_quota != UNLIMITED
        and int(daily_used or 0) >= daily_quota
    )
    within_quota = active and not (over_active or over_daily)

    return QuotaStatus(
        customer_id=customer_id,
        active_guests_quota=quota,
        active_count=int(active_count or 0),
        active_remaining=remaining,
        max_sessions_per_day=daily_quota,
        daily_used=int(daily_used or 0),
        daily_remaining=daily_remaining,
        session_minutes_default=lic.session_minutes_default,
        expired=expired,
        active=active,
        within_quota=within_quota,
    )


async def enforce_quota(
    db: AsyncSession,
    customer_id: uuid.UUID,
    *,
    phone: str | None = None,
    mac: str | None = None,
) -> QuotaStatus:
    """Atomically reserve the right to create one active guest session.

    The customer row is locked for the surrounding transaction.  The portal
    keeps this transaction open through session insertion, so concurrent
    requests serialize before counting active sessions and cannot oversubscribe
    ``max_concurrent_sessions``.
    """
    customer_result = await db.execute(
        select(Customer).where(Customer.id == customer_id).with_for_update()
    )
    customer = customer_result.scalar_one_or_none()
    if customer is None or not getattr(customer, "tenant_id", None):
        # Keep isolated service-unit fixtures (which do not model customers)
        # compatible; real portal requests always resolve a customer first.
        if str(getattr(settings, "ENVIRONMENT", "production")).lower() not in {"development", "test"}:
            raise HTTPException(
                status_code=status.HTTP_402_PAYMENT_REQUIRED,
                detail="Lisans gerekli (hotspot.core)",
            )
        qs = await quota_status(db, customer_id)
        if not qs.active:
            raise HTTPException(
                status_code=status.HTTP_402_PAYMENT_REQUIRED,
                detail="Lisans gecersiz veya eksik",
            )
        return qs

    license_data = await get_hotspot_license(db, str(customer.tenant_id))
    if not license_data:
        if str(getattr(settings, "ENVIRONMENT", "production")).lower() in {"development", "test"}:
            # Compatibility boundary for existing local/E2E fixtures that do
            # not install a platform license. This branch is unreachable in
            # production and never applies to an invalid signed payload.
            qs = await quota_status(db, customer_id)
            if qs.active and qs.within_quota:
                return qs
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Lisans gerekli (hotspot.core)",
        )
    if license_data.get("status") != "ACTIVE":
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Lisans gecersiz, suresi dolmus, iptal edilmis veya tenant ile uyumsuz",
        )
    limit = license_data.get("max_concurrent_sessions")
    if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Lisans eszamanli oturum kotasi gecersiz",
        )

    now = datetime.now(timezone.utc)
    active_filters = [
        GuestSession.customer_id == customer_id,
        GuestSession.status == STATUS_ACTIVE,
        GuestSession.ended_at.is_(None),
        or_(GuestSession.expires_at.is_(None), GuestSession.expires_at > now),
    ]
    # Reconnects from the same identity replace the previous lease in
    # ``create_session``; do not reject them merely because they occupy the
    # customer's final slot.
    identity = []
    if phone:
        identity.append(GuestSession.phone == phone)
    if mac:
        identity.append(GuestSession.mac == mac.strip().upper())
    if identity:
        active_filters.append(not_(or_(*identity)))
    active_count = int((await db.execute(
        select(func.count())
        .select_from(GuestSession)
        .where(*active_filters)
    )).scalar_one() or 0)
    if active_count >= limit:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Musteri eszamanli oturum kotasini asti",
        )

    return QuotaStatus(
        customer_id=customer_id,
        active_guests_quota=limit,
        active_count=active_count,
        active_remaining=max(0, limit - active_count),
        max_sessions_per_day=None,
        daily_used=0,
        daily_remaining=None,
        session_minutes_default=None,
        expired=False,
        active=True,
        within_quota=True,
    )


def session_duration_minutes(qs: QuotaStatus, default_minutes: int) -> int:
    """License override wins, else the caller default (settings)."""
    return qs.session_minutes_default if qs.session_minutes_default else default_minutes


# ---- admin upsert + scoped views -------------------------------------------
async def _authorize_customer(
    db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext
) -> Customer:
    """Load + IDOR-check the customer against the caller scope."""
    cust = (
        await db.execute(select(Customer).where(Customer.id == customer_id))
    ).scalar_one_or_none()
    if not cust:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Musteri bulunamadi"
        )
    if scope.level == TenantLevel.GLOBAL:
        return cust
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        if cust.partner_id != scope.partner_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Bu musteri sizin partner kapsaminizda degil",
            )
        return cust
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        if cust.id != scope.customer_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Yalnizca kendi musteri lisansinizi yonetebilirsiniz",
            )
        return cust
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN, detail="Lisans yonetimi yetkisiz"
    )


async def upsert_license(
    db: AsyncSession,
    customer_id: uuid.UUID,
    body: LicenseUpsert,
    scope: ScopeContext,
    actor_id: uuid.UUID,
    request: Request | None = None,
) -> CustomerLicense:
    """Create or PATCH the 1:1 license row for a customer (IDOR-guarded)."""
    await _authorize_customer(db, customer_id, scope)
    lic = await repository.get_for_customer(db, customer_id)

    if lic is None:
        lic = CustomerLicense(customer_id=customer_id)
        created = True
    else:
        created = False

    data = body.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(lic, key, value)
    db.add(lic)
    await db.flush()
    await log_audit(
        db,
        "license.upserted" if not created else "license.created",
        "customer_license",
        str(lic.id),
        str(actor_id) if actor_id else None,  # type: ignore[arg-type]
        request,
        details={"customer_id": str(customer_id), "created": created, "changed": list(data.keys())},
    )
    await db.commit()
    await db.refresh(lic)
    return lic


async def _scoped_customer_ids(db: AsyncSession, scope: ScopeContext) -> list[uuid.UUID] | None:
    """Customer ids visible to the scope. None = GLOBAL (no filter)."""
    if scope.level == TenantLevel.GLOBAL:
        return None
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        res = await db.execute(
            select(Customer.id).where(Customer.partner_id == scope.partner_id)
        )
        return list(res.scalars().all())
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return [scope.customer_id]
    return []


async def list_licenses(db: AsyncSession, scope: ScopeContext) -> list[dict]:
    ids = await _scoped_customer_ids(db, scope)
    stmt = select(CustomerLicense, Customer.name.label("customer_name")).join(
        Customer, Customer.id == CustomerLicense.customer_id
    )
    if ids is not None:
        stmt = stmt.where(CustomerLicense.customer_id.in_(ids))
    stmt = stmt.order_by(CustomerLicense.created_at.desc())
    res = await db.execute(stmt)
    out = []
    for lic, name in res.all():
        out.append({
            "id": lic.id,
            "customer_id": lic.customer_id,
            "customer_name": name,
            "active_guests_quota": lic.active_guests_quota,
            "max_sessions_per_day": lic.max_sessions_per_day,
            "session_minutes_default": lic.session_minutes_default,
            "expires_at": lic.expires_at,
            "is_trial": lic.is_trial,
            "is_active": lic.is_active,
            "plan": lic.plan,
            "meta": lic.meta,
            "created_at": lic.created_at,
            "updated_at": lic.updated_at,
        })
    return out


async def get_license(
    db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext
) -> dict:
    await _authorize_customer(db, customer_id, scope)
    stmt = select(CustomerLicense, Customer.name.label("customer_name")).join(
        Customer, Customer.id == CustomerLicense.customer_id
    ).where(CustomerLicense.customer_id == customer_id)
    res = await db.execute(stmt)
    row = res.one_or_none()
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bu musteri icin lisans kaydi yok (signed platform license gerekli)",
        )
    lic, name = row
    return {
        "id": lic.id,
        "customer_id": lic.customer_id,
        "customer_name": name,
        "active_guests_quota": lic.active_guests_quota,
        "max_sessions_per_day": lic.max_sessions_per_day,
        "session_minutes_default": lic.session_minutes_default,
        "expires_at": lic.expires_at,
        "is_trial": lic.is_trial,
        "is_active": lic.is_active,
        "plan": lic.plan,
        "meta": lic.meta,
        "created_at": lic.created_at,
        "updated_at": lic.updated_at,
    }


async def check_radius_enterprise_enabled(db: AsyncSession, customer_id: uuid.UUID) -> bool:
    """Musterinin RADIUS Enterprise (802.1X) ozelliginin aktif olup
    olmadigini kontrol et. Lisans kaydi yoksa config'deki genel
    RADIUS_ENTERPRISE_ENABLED ayarina bakar.

    Args:
        db: Veritabani oturumu.
        customer_id: Musteri ID.

    Returns:
        True ozellik aktif, False kapali.
    """
    from app.core.config import settings

    if not settings.RADIUS_ENTERPRISE_ENABLED:
        return False
    lic = await repository.get_for_customer(db, customer_id)
    if lic is None:
        return settings.RADIUS_ENTERPRISE_ENABLED
    return bool(lic.is_active and lic.is_radius_enterprise)
