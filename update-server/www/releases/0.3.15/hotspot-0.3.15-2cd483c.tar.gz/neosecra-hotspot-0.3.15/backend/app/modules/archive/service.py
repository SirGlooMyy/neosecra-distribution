import hashlib
import io
import json
import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.rls import set_syslog_context
from app.modules.archive.hash_chain import (
    GENESIS_HASH,
    compute_chain_hash,
    verify_chain,
)
from app.modules.archive.models import (
    CHUNK_STATUS_FAILED,
    CHUNK_STATUS_PENDING,
    CHUNK_STATUS_SIGNED,
    CHUNK_STATUS_UPLOADED,
    CHUNK_STATUS_VERIFIED,
    ArchiveChunk,
)
from app.modules.archive.repository import (
    create_chunk,
    get_chunk,
    get_latest_chunk,
)
from app.modules.archive.schemas import BuildResult, VerifyResult

log = logging.getLogger(__name__)


async def _collect_logs_for_period(
    db: AsyncSession,
    customer_id: uuid.UUID,
    period_start: datetime,
    period_end: datetime,
) -> list[dict]:
    logs: list[dict] = []

    from app.modules.customers.models import Customer
    from app.modules.sessions.models import GuestSession
    from app.modules.syslog.models import FirewallLog, SyslogRecord
    from sqlalchemy import select

    customer = await db.get(Customer, customer_id)
    tenant_id = getattr(customer, "tenant_id", None) if customer else None
    if tenant_id is None:
        raise ValueError("tenant provenance unavailable for archive build")
    await set_syslog_context(db, tenant_id)

    fw_res = await db.execute(
        select(FirewallLog).where(
            FirewallLog.customer_id == customer_id,
            FirewallLog.received_at >= period_start,
            FirewallLog.received_at < period_end,
        )
    )
    for fl in fw_res.scalars().all():
        logged_at = fl.event_time or fl.received_at
        logs.append(
            {
                "type": "firewall_log",
                "id": str(fl.id),
                "logged_at": logged_at.isoformat() if logged_at else None,
                "src_ip": fl.src_ip,
                "dst_ip": fl.dst_ip,
                "action": fl.action,
                "proto": fl.proto,
                "src_port": fl.src_port,
                "dst_port": fl.dst_port,
                "policy_id": fl.policyid,
            }
        )

    sess_res = await db.execute(
        select(GuestSession).where(
            GuestSession.customer_id == customer_id,
            GuestSession.started_at >= period_start,
            GuestSession.started_at < period_end,
        )
    )
    for gs in sess_res.scalars().all():
        logs.append(
            {
                "type": "guest_session",
                "id": str(gs.id),
                "logged_at": gs.started_at.isoformat() if gs.started_at else None,
                "ended_at": gs.ended_at.isoformat() if gs.ended_at else None,
                "mac": gs.mac,
                "ip": gs.ip,
                "phone": gs.phone,
                "status": gs.status,
            }
        )

    sys_res = await db.execute(
        select(SyslogRecord).where(
            SyslogRecord.tenant_id == tenant_id,
            SyslogRecord.created_at >= period_start,
            SyslogRecord.created_at < period_end,
        )
    )
    for sl in sys_res.scalars().all():
        logs.append(
            {
                "type": "syslog",
                "id": str(sl.id),
                "logged_at": sl.created_at.isoformat() if sl.created_at else None,
                "facility": sl.facility,
                "severity": sl.severity,
                "message": sl.message[:500] if sl.message else None,
            }
        )

    logs.sort(key=lambda x: (x.get("logged_at") or "", x.get("id") or ""))
    return logs


def _compute_content_hash(chunk_json: str) -> str:
    return hashlib.sha256(chunk_json.encode("utf-8")).hexdigest()


def _build_minio_key(
    customer_id: uuid.UUID,
    period_start: datetime,
    chunk_id: uuid.UUID,
) -> str:
    ps = period_start.astimezone(timezone.utc).strftime("%Y/%m/%d")
    return f"{customer_id}/{ps}/{chunk_id}.json"


async def build_chunk_for_period(
    db: AsyncSession,
    customer_id: uuid.UUID,
    period_start: datetime,
    period_end: datetime,
) -> BuildResult:
    logs = await _collect_logs_for_period(db, customer_id, period_start, period_end)

    latest = await get_latest_chunk(db, customer_id)
    prev_hash = latest.curr_hash if latest else GENESIS_HASH

    final_hash, intermediate_hashes = compute_chain_hash(logs, prev_hash)

    chunk_data = {
        "logs": logs,
        "chain": {
            "prev_hash": prev_hash,
            "curr_hash": final_hash,
            "intermediate_hashes": intermediate_hashes,
        },
        "period": {
            "start": period_start.isoformat(),
            "end": period_end.isoformat(),
        },
        "customer_id": str(customer_id),
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    chunk_json = json.dumps(chunk_data, sort_keys=True, ensure_ascii=False)
    content_hash_val = _compute_content_hash(chunk_json)

    chunk = ArchiveChunk(
        customer_id=customer_id,
        period_start=period_start,
        period_end=period_end,
        log_count=len(logs),
        content_hash=content_hash_val,
        curr_hash=final_hash,
        prev_hash=prev_hash,
        intermediate_hashes=intermediate_hashes,
        status=CHUNK_STATUS_PENDING,
        content_size=len(chunk_json.encode("utf-8")),
        meta={"_chunk_json": chunk_json},
    )
    await create_chunk(db, chunk)

    from app.modules.audit.service import log_audit

    await log_audit(
        db,
        "archive.chunk_built",
        "archive_chunk",
        str(chunk.id),
        None,
        details={
            "customer_id": str(customer_id),
            "log_count": len(logs),
            "curr_hash": final_hash,
        },
    )

    return BuildResult(
        chunk_id=chunk.id,
        customer_id=customer_id,
        period_start=period_start,
        period_end=period_end,
        log_count=len(logs),
        curr_hash=final_hash,
        status=chunk.status,
    )


async def sign_chunk_with_local_cert(
    db: AsyncSession,
    chunk: ArchiveChunk,
    cert_path: str,
    cert_password: str,
) -> ArchiveChunk:
    from app.modules.logs_5651.signing_service import _sign_with_local_cert

    content_to_sign = f"{chunk.curr_hash}:{chunk.content_hash}:{chunk.period_start.isoformat()}:{chunk.period_end.isoformat()}"
    content_hash_for_sig = hashlib.sha256(
        content_to_sign.encode()
    ).hexdigest()

    try:
        sig_result = _sign_with_local_cert(
            content_hash_for_sig, cert_path, cert_password
        )
    except Exception as exc:
        chunk.status = CHUNK_STATUS_FAILED
        chunk.meta = {**(chunk.meta or {}), "error": f"signature failed: {exc}"}
        await db.flush()
        raise

    chunk.signature_value = sig_result["signature_value"]
    chunk.signature_time = sig_result.get("signing_time") or datetime.now(
        timezone.utc
    )
    chunk.certificate_serial = sig_result.get("certificate_serial", "")
    chunk.sign_method = "localfile"
    chunk.status = CHUNK_STATUS_SIGNED
    await db.flush()

    from app.modules.audit.service import log_audit

    await log_audit(
        db,
        "archive.chunk_signed",
        "archive_chunk",
        str(chunk.id),
        None,
        details={
            "customer_id": str(chunk.customer_id),
            "sign_method": "localfile",
            "certificate_serial": chunk.certificate_serial,
        },
    )

    return chunk


async def upload_to_minio_worm(
    chunk: ArchiveChunk,
    content_bytes: bytes | None = None,
) -> str:
    if content_bytes is None:
        chunk_json = (chunk.meta or {}).get("_chunk_json")
        if not chunk_json:
            raise ValueError("Chunk has no embedded JSON payload in meta")
        content_bytes = chunk_json.encode("utf-8")

    key = _build_minio_key(
        chunk.customer_id, chunk.period_start, chunk.id
    )

    bucket = settings.ARCHIVE_MINIO_BUCKET or "hotspot-5651"

    use_minio = (settings.ARCHIVE_PROVIDER or "local").lower() == "minio"

    if use_minio:
        try:
            from minio import Minio

            client = Minio(
                settings.ARCHIVE_MINIO_ENDPOINT,
                access_key=settings.ARCHIVE_MINIO_ACCESS_KEY,
                secret_key=settings.ARCHIVE_MINIO_SECRET_KEY,
                secure=settings.ARCHIVE_MINIO_SECURE,
            )

            if not client.bucket_exists(bucket):
                client.make_bucket(
                    bucket,
                    object_lock=True,
                )

            client.put_object(
                bucket,
                key,
                io.BytesIO(content_bytes),
                length=len(content_bytes),
            )
            chunk.minio_object_key = key
            chunk.status = CHUNK_STATUS_UPLOADED
            return key
        except ImportError:
            try:
                import boto3

                s3 = boto3.client(
                    "s3",
                    endpoint_url=f"http{'s' if settings.ARCHIVE_MINIO_SECURE else ''}://{settings.ARCHIVE_MINIO_ENDPOINT}",
                    aws_access_key_id=settings.ARCHIVE_MINIO_ACCESS_KEY,
                    aws_secret_access_key=settings.ARCHIVE_MINIO_SECRET_KEY,
                )
                try:
                    s3.head_bucket(Bucket=bucket)
                except Exception:
                    s3.create_bucket(Bucket=bucket)
                    s3.put_object_lock_configuration(
                        Bucket=bucket,
                        ObjectLockConfiguration={
                            "ObjectLockEnabled": "Enabled",
                            "Rule": {
                                "DefaultRetention": {
                                    "Mode": "GOVERNANCE",
                                    "Days": 730,
                                }
                            },
                        },
                    )

                s3.put_object(Bucket=bucket, Key=key, Body=content_bytes)
                chunk.minio_object_key = key
                chunk.status = CHUNK_STATUS_UPLOADED
                return key
            except ImportError as exc:
                raise RuntimeError(
                    "ARCHIVE_PROVIDER=minio requires minio or boto3; refusing local fallback"
                ) from exc
        except Exception as exc:
            chunk.status = CHUNK_STATUS_FAILED
            chunk.meta = {**(chunk.meta or {}), "error": f"storage failed: {exc}"}
            raise

    if not use_minio:
        import os

        base = os.path.abspath(settings.ARCHIVE_LOCAL_DIR or "./_archives")
        safe = os.path.abspath(os.path.join(base, key)).replace("\\", "/")
        base_abs = base.replace("\\", "/")
        if not safe.startswith(base_abs):
            safe = os.path.join(base_abs, os.path.basename(key))
        os.makedirs(os.path.dirname(safe), exist_ok=True)
        try:
            with open(safe, "wb") as fh:
                fh.write(content_bytes)
        except Exception as exc:
            chunk.status = CHUNK_STATUS_FAILED
            chunk.meta = {**(chunk.meta or {}), "error": f"storage failed: {exc}"}
            raise
        chunk.minio_object_key = f"local:{safe}"
        chunk.status = CHUNK_STATUS_UPLOADED
        return chunk.minio_object_key


async def verify_chunk_integrity(
    db: AsyncSession, chunk_id: uuid.UUID
) -> VerifyResult:
    chunk = await get_chunk(db, chunk_id)
    if not chunk:
        return VerifyResult(
            chunk_id=chunk_id,
            ok=False,
            chain_valid=False,
            signature_valid=None,
            message="Chunk not found",
            verified_at=datetime.now(timezone.utc),
        )

    chunk_json = (chunk.meta or {}).get("_chunk_json")
    if not chunk_json:
        return VerifyResult(
            chunk_id=chunk_id,
            ok=False,
            chain_valid=False,
            signature_valid=None,
            message="Chunk payload not available in meta",
            verified_at=datetime.now(timezone.utc),
        )

    try:
        chunk_data = json.loads(chunk_json)
    except (json.JSONDecodeError, KeyError):
        return VerifyResult(
            chunk_id=chunk_id,
            ok=False,
            chain_valid=False,
            signature_valid=None,
            message="Cannot parse chunk payload",
            verified_at=datetime.now(timezone.utc),
        )

    logs = chunk_data.get("logs", [])
    chain_info = chunk_data.get("chain", {})

    chain_valid = verify_chain(
        logs=logs,
        intermediate_hashes=chain_info.get("intermediate_hashes", []),
        final_hash=chain_info.get("curr_hash", ""),
        prev_hash=chain_info.get("prev_hash", GENESIS_HASH),
    )

    computed_content_hash = _compute_content_hash(chunk_json)
    content_hash_valid = computed_content_hash == chunk.content_hash

    overall_ok = chain_valid and content_hash_valid

    message_parts = []
    if chain_valid:
        message_parts.append("Chain valid")
    else:
        message_parts.append("Chain integrity FAILED")
    if content_hash_valid:
        message_parts.append("Content hash valid")
    else:
        message_parts.append("Content hash MISMATCH")

    if overall_ok and chunk.signature_value:
        try:
            from app.modules.logs_5651.signing_service import verify_signature

            sig_valid = verify_signature(
                content_hash=chunk.content_hash,
                signature_value=chunk.signature_value,
                certificate_pem=chunk.certificate_serial or "",
            )
            if sig_valid:
                message_parts.append("Signature valid")
            else:
                message_parts.append("Signature INVALID")
                overall_ok = False
        except Exception as exc:
            message_parts.append(f"Signature verify error: {exc}")

    if overall_ok:
        chunk.status = CHUNK_STATUS_VERIFIED
        await db.flush()
    else:
        # Verification failure is persisted; a failed chunk can never be
        # interpreted as an upload-ready legal artifact.
        chunk.status = CHUNK_STATUS_FAILED
        await db.flush()

    return VerifyResult(
        chunk_id=chunk.id,
        ok=overall_ok,
        chain_valid=chain_valid,
        signature_valid=None if not chunk.signature_value else overall_ok,
        message="; ".join(message_parts),
        verified_at=datetime.now(timezone.utc),
    )
