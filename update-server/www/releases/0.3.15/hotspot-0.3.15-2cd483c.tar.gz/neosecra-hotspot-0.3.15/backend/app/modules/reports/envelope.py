"""Canonical immutable report/evidence envelope helpers."""
from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Any


REPORT_SCHEMA_VERSION = "1.0"
EVIDENCE_SCHEMA_VERSION = "1.0"


def canonical_json(value: dict[str, Any]) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str)


def envelope_hash(envelope: dict[str, Any]) -> str:
    body = dict(envelope)
    body.pop("sha256_hash", None)
    return hashlib.sha256(canonical_json(body).encode("utf-8")).hexdigest()


def build_report_envelope(
    *,
    report_id: uuid.UUID | str,
    module: str,
    tenant_id: uuid.UUID | str | None,
    customer_id: uuid.UUID | str,
    generated_at: datetime,
    reporting_period: dict[str, Any],
    data: dict[str, Any],
    provenance: dict[str, Any] | None = None,
) -> dict[str, Any]:
    envelope: dict[str, Any] = {
        "report_id": str(report_id),
        "platform": "NeoSecra",
        "module": module,
        "schema_version": REPORT_SCHEMA_VERSION,
        "tenant_id": str(tenant_id) if tenant_id is not None else None,
        "customer_id": str(customer_id),
        "generated_at": (generated_at.astimezone(timezone.utc) if generated_at.tzinfo else generated_at.replace(tzinfo=timezone.utc)).isoformat(),
        "reporting_period": reporting_period,
        "provenance": provenance or {},
        "data": data,
    }
    envelope["sha256_hash"] = envelope_hash(envelope)
    return envelope


def verify_envelope(envelope: dict[str, Any]) -> bool:
    expected = envelope.get("sha256_hash")
    return isinstance(expected, str) and bool(expected) and expected == envelope_hash(envelope)


def build_evidence_envelope(
    *,
    export_id: uuid.UUID | str,
    evidence_type: str,
    tenant_id: uuid.UUID | str,
    customer_id: uuid.UUID | str,
    session_id: uuid.UUID | str,
    generated_at: datetime,
    package_hash: str,
    files: dict[str, str],
    provenance: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the immutable, hash-addressed envelope persisted for an export."""
    envelope: dict[str, Any] = {
        "evidence_id": str(export_id),
        "evidence_type": evidence_type,
        "module": "hotspot",
        "schema_version": EVIDENCE_SCHEMA_VERSION,
        "tenant_id": str(tenant_id),
        "customer_id": str(customer_id),
        "session_id": str(session_id),
        "generated_at": (
            generated_at.astimezone(timezone.utc)
            if generated_at.tzinfo
            else generated_at.replace(tzinfo=timezone.utc)
        ).isoformat(),
        "package_hash": package_hash,
        "files": dict(sorted(files.items())),
        "provenance": provenance or {},
    }
    envelope["sha256_hash"] = envelope_hash(envelope)
    return envelope
