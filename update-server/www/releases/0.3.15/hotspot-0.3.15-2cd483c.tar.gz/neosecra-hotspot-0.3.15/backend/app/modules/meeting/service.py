import logging
import random
import string
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.meeting.models import MeetingCode

log = logging.getLogger(__name__)


def generate_code(length: int = 8) -> str:
    return "".join(random.choices(string.ascii_uppercase + string.digits, k=length))


async def create_meeting_code(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None,
    event_name: str,
    max_uses: int,
    duration_minutes: int,
    expires_at: datetime,
    created_by: uuid.UUID,
    code: str | None = None,
) -> MeetingCode:
    if code and str(code).strip():
        code_str = str(code).strip().upper()
        existing = (
            await db.execute(
                select(MeetingCode).where(
                    MeetingCode.customer_id == customer_id,
                    func.upper(MeetingCode.code) == code_str,
                )
            )
        ).scalar_one_or_none()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"'{code_str}' koduna sahip bir toplantı kodu zaten mevcut",
            )
    else:
        code_str = generate_code()
        while True:
            existing = (
                await db.execute(select(MeetingCode).where(MeetingCode.code == code_str))
            ).scalar_one_or_none()
            if not existing:
                break
            code_str = generate_code()

    mc = MeetingCode(
        customer_id=customer_id,
        location_id=location_id,
        code=code_str,
        event_name=event_name,
        max_uses=max_uses,
        current_uses=0,
        duration_minutes=duration_minutes,
        expires_at=expires_at,
        is_active=True,
        created_by=created_by,
    )
    db.add(mc)
    await db.commit()
    await db.refresh(mc)
    return mc


async def verify_code(
    db: AsyncSession,
    *,
    code: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
) -> MeetingCode:
    clean_code = (code or "").strip().upper()
    q = select(MeetingCode).where(
        func.upper(MeetingCode.code) == clean_code,
        MeetingCode.customer_id == customer_id,
    )
    if location_id:
        q = q.where(
            or_(
                MeetingCode.location_id.is_(None),
                MeetingCode.location_id == location_id,
            )
        )

    # The lookup is constrained by the unique meeting-code key.  Use the
    # scalar API directly so async drivers and lightweight test doubles expose
    # the same contract (and we do not accidentally treat a Result wrapper as
    # a MeetingCode instance).
    mc = (await db.execute(q)).scalar_one_or_none()

    if not mc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Toplanti kodu bulunamadi",
        )
    if not mc.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Toplanti kodu aktif degil",
        )
    now = datetime.now(timezone.utc)
    if mc.expires_at:
        exp = mc.expires_at if mc.expires_at.tzinfo else mc.expires_at.replace(tzinfo=timezone.utc)
        if exp < now:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Toplanti kodunun suresi doldu",
            )
    if mc.current_uses >= mc.max_uses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Toplanti kodu maksimum kullanim sayisina ulasti",
        )

    mc.current_uses += 1
    await db.commit()
    await db.refresh(mc)
    return mc


async def list_codes(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
) -> list[MeetingCode]:
    result = await db.execute(
        select(MeetingCode)
        .where(MeetingCode.customer_id == customer_id)
        .order_by(MeetingCode.created_at.desc())
    )
    return list(result.scalars().all())
