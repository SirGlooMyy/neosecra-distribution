"""Vendor-neutral firewall adapter contract.

Adapters wrap a single vendor's management API (FortiGate FortiOS REST, Palo
Alto XML API, ...). They MUST NOT leak vendor-specific assumptions into the
core service (Mutlak Kural #7 — adapter pattern). The service talks only to
this ABC; concrete adapters are selected by the registry.

All adapter methods return plain dicts/dataclasses, never ORM objects and never
raw vendor responses — they normalize to the platform's canonical shape.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)


@dataclass
class ConnectionConfig:
    """Decrypted connection details handed to an adapter at construction time.

    Built by the service from Device + DeviceCredential. The adapter never
    touches the DB or crypto layer — it only consumes this config.

    TLS Security
    ------------
    `verify_tls` defaults to **True** (production-safe). Disabling TLS
    verification allows man-in-the-middle attacks and MUST be avoided in
    production environments. Development/lab deployments using self-signed
    certificates can explicitly set ``verify_tls = False``, but a security
    warning will be logged on every adapter instantiation.
    """

    vendor: str
    api_host: str
    api_port: int | None = None
    api_token: str | None = None          # decrypted API key
    api_username: str | None = None
    api_vdom: str | None = None
    verify_tls: bool = True               # Production-safe default (was False)
    api_tls: bool = True                  # Whether to use HTTPS (False for HTTP simulators)
    ssh_key: str | None = None            # decrypted, optional
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate TLS configuration.

        Log a security warning when TLS verification is disabled. In
        production environments this is a significant risk. The warning
        fires on every adapter construction so operators cannot miss it.
        """
        if not self.verify_tls:
            self._log_tls_warning()

    def _log_tls_warning(self) -> None:
        """Emit a structured security warning for disabled TLS."""
        try:
            from app.core.config import settings

            env = getattr(settings, "ENVIRONMENT", "development")
        except Exception:  # pragma: no cover
            env = "unknown"

        log.warning(
            "SECURITY: TLS verification is DISABLED for %s at %s. "
            "Environment: %s. "
            "This is INSECURE for production use — enable verify_tls or "
            "use a trusted CA bundle.",
            self.vendor,
            self.api_host,
            env,
        )

        # Never log secret or certificate content (Mutlak Kural #3 / Yasak).
        # api_token, ssh_key, and any extra dict values are NOT included here.


@dataclass
class FirewallCapabilities:
    """Declares what operations this vendor/adapter supports.

    The platform uses these to show/hide UI buttons, warn during onboarding,
    and reject unsupported operations before they reach the adapter.
    """
    external_captive_portal: bool = False
    radius_authentication: bool = False
    radius_accounting: bool = False
    radius_coa: bool = False
    disconnect_message: bool = False
    mac_auth_bypass: bool = False
    local_guest_users: bool = False
    vpn_radius_mfa: bool = False
    active_session_query: bool = False
    authorize_guest_api: bool = False
    revoke_guest_api: bool = False
    config_backup: bool = False
    syslog: bool = False
    api_health: bool = False


@dataclass
class AdapterResult:
    """Normalized outcome of an adapter call."""
    ok: bool
    message: str = ""
    data: dict[str, Any] = field(default_factory=dict)

    def __bool__(self) -> bool:           # so `if result:` reads naturally
        return self.ok


class FirewallAdapter(ABC):
    """Abstract firewall/gateway adapter."""

    #: vendor slug this adapter handles (matches Device.vendor)
    vendor: str = "abstract"

    def __init__(self, config: ConnectionConfig) -> None:
        self.config = config

    def _guest_policy(self, session: dict[str, Any]) -> dict[str, Any]:
        """Return a normalized guest policy dictionary if present."""
        policy = session.get("policy")
        if not isinstance(policy, dict) or not policy:
            policy = session.get("group_policy")
        if not isinstance(policy, dict) or not policy:
            hint_keys = (
                "group_id",
                "group_name",
                "vlan_id",
                "radius_avps",
                "bandwidth_up",
                "bandwidth_down",
                "session_timeout",
                "idle_timeout",
            )
            policy = {
                key: session.get(key)
                for key in hint_keys
                if session.get(key) is not None
            }
        return policy if isinstance(policy, dict) else {}

    def _guest_policy_note(self, session: dict[str, Any]) -> str:
        """Compact, human-readable policy suffix for device comments."""
        policy = self._guest_policy(session)
        parts: list[str] = []
        vlan_id = policy.get("vlan_id")
        radius_avps = policy.get("radius_avps")
        if vlan_id is None and isinstance(radius_avps, dict):
            vlan_id = radius_avps.get("Tunnel-Private-Group-ID")
        if vlan_id not in (None, ""):
            parts.append(f"vlan={vlan_id}")
        bandwidth_up = policy.get("bandwidth_up")
        bandwidth_down = policy.get("bandwidth_down")
        if bandwidth_up is not None or bandwidth_down is not None:
            up = bandwidth_up if bandwidth_up is not None else "*"
            down = bandwidth_down if bandwidth_down is not None else "*"
            parts.append(f"bw={up}:{down}")
        if policy.get("session_timeout") is not None:
            parts.append(f"session_timeout={policy['session_timeout']}")
        if policy.get("idle_timeout") is not None:
            parts.append(f"idle_timeout={policy['idle_timeout']}")
        if policy.get("group_name"):
            parts.append(f"group={policy['group_name']}")
        return f"policy {'; '.join(parts)}" if parts else ""

    def _guest_comment(self, session: dict[str, Any], *, prefix: str = "hotspot session") -> str:
        """Build the comment/description string used by guest allowlists."""
        session_id = session.get("session_id", "")
        base = f"{prefix} {session_id}".strip()
        note = self._guest_policy_note(session)
        return f"{base} | {note}" if note else base

    # ---- capability / discovery ----------------------------------------
    def get_capabilities(self) -> FirewallCapabilities:
        """Return what this adapter supports. Default all-False — each
        concrete adapter overrides the fields it can actually do."""
        return FirewallCapabilities()

    @abstractmethod
    async def test_connection(self) -> AdapterResult: ...

    @abstractmethod
    async def get_device_info(self) -> dict[str, Any]: ...

    @abstractmethod
    async def get_interfaces(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def get_captive_portal_config(self) -> dict[str, Any]: ...

    # ---- guest session lifecycle ---------------------------------------
    @abstractmethod
    async def get_active_sessions(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]: ...

    @abstractmethod
    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult: ...

    @abstractmethod
    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult: ...

    # ---- log ingestion -------------------------------------------------
    @abstractmethod
    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]: ...
