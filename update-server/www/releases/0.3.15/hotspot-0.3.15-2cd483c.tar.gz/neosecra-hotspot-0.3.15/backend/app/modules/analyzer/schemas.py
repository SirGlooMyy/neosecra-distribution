"""HTTP contracts for the tenant-scoped 5651/network Analyzer."""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class AnalyzerSearchParams(BaseModel):
    q: str | None = Field(None, max_length=255)
    source_type: str | None = Field(None, max_length=50)
    source_name: str | None = Field(None, max_length=255)
    category: str | None = Field(None, max_length=50)
    severity: str | None = Field(None, max_length=20)
    action: str | None = Field(None, max_length=80)
    source_ip: str | None = Field(None, max_length=64)
    destination_ip: str | None = Field(None, max_length=64)
    mac: str | None = Field(None, max_length=32)
    identity: str | None = Field(None, max_length=255)
    session_id: str | None = Field(None, max_length=120)
    nat_ip: str | None = Field(None, max_length=64)
    dns_query: str | None = Field(None, max_length=255)
    from_time: datetime | None = None
    to_time: datetime | None = None
    limit: int = Field(100, ge=1, le=1000)
    offset: int = Field(0, ge=0)

    @field_validator("from_time", "to_time", mode="before")
    @classmethod
    def normalize_timezone(cls, value: Any) -> Any:
        if isinstance(value, datetime) and value.tzinfo is None:
            from datetime import timezone

            return value.replace(tzinfo=timezone.utc)
        return value


class AnalyzerEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    raw_event_id: uuid.UUID
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    occurred_at: datetime | None = None
    received_at: datetime
    source_name: str
    source_type: str
    transport: str
    vendor: str
    category: str
    subtype: str | None = None
    severity: str
    action: str | None = None
    source_ip: str | None = None
    destination_ip: str | None = None
    source_mac: str | None = None
    destination_mac: str | None = None
    source_port: int | None = None
    destination_port: int | None = None
    identity: str | None = None
    session_id: str | None = None
    nat_source_ip: str | None = None
    nat_destination_ip: str | None = None
    nat_source_port: int | None = None
    nat_destination_port: int | None = None
    dns_query: str | None = None
    dns_answers: list[str] | None = None
    firewall_policy_id: int | None = None
    firewall_policy_name: str | None = None
    bytes_sent: int | None = None
    bytes_received: int | None = None
    duration_seconds: int | None = None
    fields: dict[str, Any] = Field(default_factory=dict)
    raw_sha256: str
    normalized_sha256: str
    parser_version: str
    provenance: dict[str, Any] = Field(default_factory=dict)
    retention_until: datetime
    legal_hold: bool = False


class AnalyzerSearchResponse(BaseModel):
    items: list[AnalyzerEventOut]
    total: int
    limit: int
    offset: int
    took_ms: int
    source: str = "postgres"
    provenance: dict[str, Any] = Field(default_factory=dict)


class AnalyzerTimelineBucket(BaseModel):
    timestamp: datetime
    count: int
    severities: dict[str, int] = Field(default_factory=dict)


class AnalyzerTimelineResponse(BaseModel):
    events: list[AnalyzerEventOut]
    buckets: list[AnalyzerTimelineBucket]
    total: int
    from_time: datetime | None = None
    to_time: datetime | None = None


class AnalyzerSessionReconstruction(BaseModel):
    session: dict[str, Any] | None = None
    identity: dict[str, Any] = Field(default_factory=dict)
    network: dict[str, Any] = Field(default_factory=dict)
    events: list[AnalyzerEventOut] = Field(default_factory=list)
    timeline: list[dict[str, Any]] = Field(default_factory=list)
    provenance: dict[str, Any] = Field(default_factory=dict)


class AnalyzerIdentityMap(BaseModel):
    identity: str | None = None
    phone: str | None = None
    mac_addresses: list[str] = Field(default_factory=list)
    ip_addresses: list[str] = Field(default_factory=list)
    sessions: list[dict[str, Any]] = Field(default_factory=list)
    event_count: int = 0
    provenance: dict[str, Any] = Field(default_factory=dict)


class AnalyzerSourceHealthOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    source_name: str
    source_type: str
    status: str
    last_received_at: datetime | None = None
    last_parsed_at: datetime | None = None
    last_failure_at: datetime | None = None
    last_error_code: str | None = None
    received_count: int
    parsed_count: int
    parser_failure_count: int
    lag_seconds: int | None = None
    updated_at: datetime


class AnalyzerFailureOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    raw_event_id: uuid.UUID
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    error_code: str
    error_message: str
    attempts: int
    status: str
    next_retry_at: datetime | None = None
    last_attempt_at: datetime
    replayed_at: datetime | None = None
    provenance: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime


class AnalyzerFailureReplayOut(BaseModel):
    failure_id: uuid.UUID
    normalized_event_id: uuid.UUID | None = None
    status: str
    replayed: bool = False
    error: str | None = None


class AnalyzerRawEventOut(BaseModel):
    id: uuid.UUID
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    source_name: str
    source_type: str
    transport: str
    source_ip: str | None = None
    received_at: datetime
    raw_payload: str
    raw_sha256: str
    status: str
    retention_until: datetime
    provenance: dict[str, Any] = Field(default_factory=dict)


class AnalyzerSavedViewCreate(BaseModel):
    tenant_id: uuid.UUID | None = None
    customer_id: uuid.UUID | None = None
    title: str = Field(..., min_length=1, max_length=255)
    description: str | None = Field(None, max_length=1000)
    filters: dict[str, Any] = Field(default_factory=dict)
    is_shared: bool = False


class AnalyzerSavedViewUpdate(BaseModel):
    title: str | None = Field(None, min_length=1, max_length=255)
    description: str | None = Field(None, max_length=1000)
    filters: dict[str, Any] | None = None
    is_shared: bool | None = None


class AnalyzerSavedViewOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    created_by_user_id: uuid.UUID
    title: str
    description: str | None = None
    filters: dict[str, Any]
    is_shared: bool
    created_at: datetime
    updated_at: datetime


class AnalyzerIngestRequest(BaseModel):
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    raw_payload: str = Field(..., min_length=1, max_length=2_000_000)
    source_name: str = Field(..., min_length=1, max_length=255)
    source_type: str = Field("firewall", min_length=1, max_length=50)
    transport: str = Field("syslog", min_length=1, max_length=20)
    source_ip: str | None = Field(None, max_length=64)
    received_at: datetime | None = None
    idempotency_key: str | None = Field(None, min_length=1, max_length=255)


class AnalyzerIngestOut(BaseModel):
    raw_event_id: uuid.UUID
    normalized_event_id: uuid.UUID | None = None
    status: Literal["normalized", "failed", "replayed"]
    raw_sha256: str
    normalized_sha256: str | None = None
    failure_id: uuid.UUID | None = None
    provenance: dict[str, Any] = Field(default_factory=dict)


class AnalyzerLegalHoldRequest(BaseModel):
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    raw_event_id: uuid.UUID | None = None
    normalized_event_id: uuid.UUID | None = None
    action: Literal["place", "release"] = "place"
    reason: str = Field(..., min_length=3, max_length=1000)


class AnalyzerLegalHoldOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    raw_event_id: uuid.UUID | None = None
    normalized_event_id: uuid.UUID | None = None
    action: str
    reason: str
    actor_id: uuid.UUID | None = None
    created_at: datetime


class AnalyzerEvidenceRequest(AnalyzerSearchParams):
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    include_raw: bool = False
    idempotency_key: str | None = Field(None, min_length=1, max_length=255)


class AnalyzerEvidenceOut(BaseModel):
    export_id: uuid.UUID
    status: Literal["ready"]
    package_ref: str
    content_hash: str
    sha256_hash: str
    file_size: int
    envelope: dict[str, Any]


class AnalyzerReportRequest(AnalyzerSearchParams):
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    report_type: str = Field("network_analyzer", min_length=1, max_length=80)
    idempotency_key: str | None = Field(None, min_length=1, max_length=255)


class AnalyzerReportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    tenant_id: uuid.UUID
    customer_id: uuid.UUID
    period_start: datetime | None = None
    period_end: datetime | None = None
    report_type: str
    schema_version: str
    generated_at: datetime
    sha256_hash: str
    provenance: dict[str, Any]
    snapshot: dict[str, Any]
