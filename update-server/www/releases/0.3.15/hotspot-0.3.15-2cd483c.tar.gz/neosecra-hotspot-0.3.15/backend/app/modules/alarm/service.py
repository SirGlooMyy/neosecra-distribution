"""Alarm event service — Real security incidents, correlation, stats, trend."""
import logging
import uuid
import time
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.alarm.models import AlarmEvent

log = logging.getLogger(__name__)

# In-memory storage for acknowledged real-time incidents
_acknowledged_incidents: set[str] = set()


async def create_alarm(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    severity: str = "warning",
    title: str,
    message: str = "",
    source: str = "manual",
    trigger_id: uuid.UUID | None = None,
    commit: bool = True,
) -> AlarmEvent:
    event = AlarmEvent(
        id=uuid.uuid4(),
        customer_id=customer_id,
        location_id=location_id,
        severity=severity,
        title=title,
        message=message,
        source=source,
        trigger_id=trigger_id,
        event_time=datetime.now(timezone.utc),
        acknowledged=False,
    )
    db.add(event)
    if commit:
        await db.commit()
        await db.refresh(event)
    else:
        await db.flush()
    return event


async def list_alarms(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID | None = None,
    severity: str | None = None,
    acknowledged: bool | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[AlarmEvent]:
    query = select(AlarmEvent)
    if customer_id:
        query = query.where(AlarmEvent.customer_id == customer_id)
    if severity:
        query = query.where(AlarmEvent.severity == severity)
    if acknowledged is not None:
        query = query.where(AlarmEvent.acknowledged == acknowledged)
    query = query.order_by(AlarmEvent.event_time.desc()).limit(limit).offset(offset)
    res = await db.execute(query)
    events = res.scalars().all() if hasattr(res, "scalars") else []
    return list(events) if events else []


async def list_real_alarm_events(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID | None = None,
    severity: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    """Returns real security alarm incidents correlated from live firewall logs."""
    since = datetime.now(timezone.utc) - timedelta(hours=24)

    # Query real security threats from firewall_logs
    sec_sql = text("""
        SELECT id, effective_event_time, src_ip, dst_ip, dst_port, service, proto, action, log_type, severity, "user", raw_syslog
        FROM firewall_logs
        WHERE (action IN ('deny', 'drop', 'block', 'reject', 'ip-conn') 
               OR log_type IN ('vpn', 'webfilter', 'app-ctrl', 'utm') 
               OR severity IN ('emergency', 'alert', 'critical', 'warning'))
          AND effective_event_time >= :since
        ORDER BY effective_event_time DESC
        LIMIT :limit OFFSET :offset
    """)
    res = await db.execute(sec_sql, {"since": since, "limit": limit, "offset": offset})
    rows = res.fetchall()

    alarms = []
    for r in rows:
        log_id, etime, sip, dip, dport, svc, proto, act, ltype, sev, uname, raw = r
        sev_str = str(sev or "warning").lower()
        if sev_str in ("emergency", "alert", "critical") or act in ("drop", "blocked"):
            mapped_sev = "critical"
        elif act in ("deny", "ip-conn") or sev_str == "warning":
            mapped_sev = "warning"
        else:
            mapped_sev = "info"

        if severity and severity.lower() != "all" and mapped_sev != severity.lower():
            continue

        # Formulate intuitive security title & message
        if ltype == "vpn":
            title = f"VPN Oturum Olayı ({uname or 'Kullanıcı'})"
            msg = f"Kullanıcı: {uname or 'Bilinmeyen'} · Kaynak IP: {sip} · Eylem: {act}."
        elif act in ("deny", "drop"):
            title = f"Güvenlik Duvarı Engelleme ({act.upper()})"
            msg = f"Kaynak IP: {sip} ──► Hedef: {dip}:{dport or svc or 'Port'} ({svc or 'TCP/UDP'}) kural tarafından engellendi."
        elif ltype == "webfilter":
            title = "Web Filtre Kategori Engellemesi"
            msg = f"Kaynak IP: {sip} zararlı/yasaklı web içeriğine erişmeye çalışırken durduruldu."
        else:
            title = f"Güvenlik Tehdidi ({sev_str.upper()})"
            msg = f"Kaynak: {sip} ──► Hedef: {dip}:{dport or ''} · Durum: {act}."

        is_ack = str(log_id) in _acknowledged_incidents

        alarms.append({
            "id": str(log_id),
            "customer_id": str(customer_id) if customer_id else None,
            "location_id": None,
            "trigger_id": None,
            "trigger_name": title,
            "severity": mapped_sev,
            "title": title,
            "message": msg,
            "source": "FortiGate-60F",
            "source_ip": str(sip or "-"),
            "dest_ip": f"{dip}:{dport}" if dport else str(dip or "-"),
            "user": uname or "-",
            "acknowledged": is_ack,
            "acknowledged_at": None,
            "acknowledged_by": None,
            "timestamp": etime.isoformat() if hasattr(etime, "isoformat") else str(etime),
        })

    return alarms


async def acknowledge_alarm(
    db: AsyncSession,
    event_id: uuid.UUID | str,
    user_id: uuid.UUID,
):
    """Marks a security alarm as acknowledged."""
    # Check if event exists as AlarmEvent model first
    try:
        uid = uuid.UUID(str(event_id))
        event = await db.get(AlarmEvent, uid)
        if event is not None:
            if event.acknowledged:
                raise HTTPException(status_code=400, detail="Alarm zaten onaylanmis")
            event.acknowledged = True
            event.acknowledged_at = datetime.now(timezone.utc)
            event.acknowledged_by = user_id
            await db.commit()
            return event
        elif isinstance(event_id, uuid.UUID):
            raise HTTPException(status_code=404, detail="Alarm bulunamadi")
    except ValueError:
        pass
    except HTTPException:
        raise

    str_id = str(event_id)
    _acknowledged_incidents.add(str_id)
    return {
        "id": str_id,
        "acknowledged": True,
        "acknowledged_at": datetime.now(timezone.utc).isoformat(),
        "acknowledged_by": str(user_id),
    }


async def get_alarm_stats(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID | None = None,
) -> dict:
    """Returns real security incident stats from firewall_logs for the last 24h."""
    since = datetime.now(timezone.utc) - timedelta(hours=24)

    stats_sql = text("""
        SELECT 
            COUNT(*) AS total,
            COUNT(*) FILTER (WHERE severity IN ('emergency', 'alert', 'critical') OR action IN ('drop', 'blocked')) AS critical_count,
            COUNT(*) FILTER (WHERE action IN ('deny', 'ip-conn') OR severity = 'warning') AS warning_count,
            COUNT(*) FILTER (WHERE log_type = 'vpn' OR severity IN ('notice', 'info')) AS info_count
        FROM firewall_logs
        WHERE (action IN ('deny', 'drop', 'block', 'reject', 'ip-conn') 
               OR log_type IN ('vpn', 'webfilter', 'app-ctrl', 'utm') 
               OR severity IN ('emergency', 'alert', 'critical', 'warning'))
          AND effective_event_time >= :since
    """)
    res = await db.execute(stats_sql, {"since": since})
    row = res.fetchone()

    total = int((row[0] if row else 0) or 0)
    crit = int((row[1] if row else 0) or 0)
    warn = int((row[2] if row else 0) or 0)
    inf = int((row[3] if row else 0) or 0)
    ack_count = len(_acknowledged_incidents)
    unack_count = max(0, total - ack_count)

    return {
        "total_today": total,
        "critical": crit,
        "warning": warn,
        "info": inf,
        "acknowledged": ack_count,
        "unacknowledged": unack_count,
    }


async def get_alarm_trend(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID | None = None,
    days: int = 14,
) -> list[dict]:
    """Returns daily alarm incidents trend for the specified days."""
    since = datetime.now(timezone.utc) - timedelta(days=days)

    trend_sql = text("""
        SELECT 
            DATE(effective_event_time) AS log_date,
            COUNT(*) AS total_count,
            COUNT(*) FILTER (WHERE severity IN ('emergency', 'alert', 'critical') OR action IN ('drop', 'blocked')) AS crit_cnt,
            COUNT(*) FILTER (WHERE action IN ('deny', 'ip-conn') OR severity = 'warning') AS warn_cnt,
            COUNT(*) FILTER (WHERE log_type = 'vpn' OR severity IN ('notice', 'info')) AS info_cnt
        FROM firewall_logs
        WHERE (action IN ('deny', 'drop', 'block', 'reject', 'ip-conn') 
               OR log_type IN ('vpn', 'webfilter', 'app-ctrl', 'utm') 
               OR severity IN ('emergency', 'alert', 'critical', 'warning'))
          AND effective_event_time >= :since
        GROUP BY DATE(effective_event_time)
        ORDER BY DATE(effective_event_time) ASC
    """)
    res = await db.execute(trend_sql, {"since": since})
    rows = res.fetchall()

    return [
        {
            "date": str(r[0]),
            "count": int(r[1] or 0),
            "critical": int(r[2] or 0),
            "warning": int(r[3] or 0),
            "info": int(r[4] or 0),
        }
        for r in rows
    ]
