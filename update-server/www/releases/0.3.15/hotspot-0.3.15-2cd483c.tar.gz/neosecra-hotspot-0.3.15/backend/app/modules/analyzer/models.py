"""Analyzer persistence models.

Raw payloads and normalized projections intentionally live in different tables.
Raw rows are content addressed and append-only; normalized rows are a derived
projection that can be rebuilt from the raw evidence. Operational failure and
health rows are mutable so retry/replay state is durable without changing the
evidence itself.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import TimestampMixin, UUIDPK, fk


RAW_RECEIVED = "received"
RAW_NORMALIZED = "normalized"
RAW_FAILED = "failed"
RAW_STATUSES = (RAW_RECEIVED, RAW_NORMALIZED, RAW_FAILED)

FAILURE_PENDING = "pending"
FAILURE_RETRYING = "retrying"
FAILURE_DEAD_LETTER = "dead_letter"
FAILURE_REPLAYED = "replayed"
FAILURE_STATUSES = (FAILURE_PENDING, FAILURE_RETRYING, FAILURE_DEAD_LETTER, FAILURE_REPLAYED)


class AnalyzerRawEvent(Base, UUIDPK):
    """Immutable source payload and provenance envelope."""

    __tablename__ = "analyzer_raw_events"
    __table_args__ = (
        # Idempotency is isolated at the customer boundary as well as the
        # installation tenant.  Two customers can legitimately emit the same
        # payload/key without one replaying the other's evidence row.
        UniqueConstraint("tenant_id", "customer_id", "idempotency_key", name="uq_analyzer_raw_tenant_idempotency"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    source_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    transport: Mapped[str] = mapped_column(String(20), nullable=False, default="syslog")
    source_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    received_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )
    raw_payload: Mapped[str] = mapped_column(Text, nullable=False)
    raw_sha256: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    idempotency_key: Mapped[str] = mapped_column(String(255), nullable=False)
    parser_version: Mapped[str] = mapped_column(String(40), nullable=False, default="fortigate-v1")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default=RAW_RECEIVED, index=True)
    retention_until: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    provenance: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    content_size: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )


class AnalyzerNormalizedEvent(Base, UUIDPK):
    """Immutable, searchable projection derived from one raw event."""

    __tablename__ = "analyzer_normalized_events"
    __table_args__ = (
        UniqueConstraint("raw_event_id", name="uq_analyzer_normalized_raw_event"),
    )

    raw_event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False, index=True
    )
    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    occurred_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    source_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    transport: Mapped[str] = mapped_column(String(20), nullable=False, default="syslog")
    vendor: Mapped[str] = mapped_column(String(50), nullable=False, default="fortigate", index=True)
    category: Mapped[str] = mapped_column(String(50), nullable=False, default="event", index=True)
    subtype: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="info", index=True)
    action: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    source_ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    destination_ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    source_mac: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    destination_mac: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    source_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    destination_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    identity: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    session_id: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    nat_source_ip: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    nat_destination_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    nat_source_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    nat_destination_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    dns_query: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    dns_answers: Mapped[list | None] = mapped_column(JSONB, nullable=True)
    firewall_policy_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    firewall_policy_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    bytes_sent: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    bytes_received: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    duration_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    fields: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    normalized_sha256: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    parser_version: Mapped[str] = mapped_column(String(40), nullable=False, default="fortigate-v1")
    provenance: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    retention_until: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )


class AnalyzerIngestFailure(Base, UUIDPK):
    """Durable parser/normalization failure and retry/DLQ state."""

    __tablename__ = "analyzer_ingest_failures"

    raw_event_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    error_code: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    error_message: Mapped[str] = mapped_column(String(2000), nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default=FAILURE_PENDING, index=True)
    next_retry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    last_attempt_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    replayed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    provenance: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )


class AnalyzerSourceHealth(Base, UUIDPK):
    """Operational health counters for a source/parser pair."""

    __tablename__ = "analyzer_source_health"
    __table_args__ = (
        UniqueConstraint("tenant_id", "customer_id", "source_name", name="uq_analyzer_source_health_tenant_source"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    source_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="unknown", index=True)
    last_received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_parsed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_failure_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error_code: Mapped[str | None] = mapped_column(String(80), nullable=True)
    received_count: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    parsed_count: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    parser_failure_count: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    lag_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )


class AnalyzerLegalHold(Base, UUIDPK):
    """Append-only legal-hold action stream; raw evidence is never updated."""

    __tablename__ = "analyzer_legal_holds"

    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    raw_event_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    normalized_event_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    reason: Mapped[str] = mapped_column(String(1000), nullable=False)
    actor_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )


class AnalyzerEvidenceExport(Base, UUIDPK):
    """Immutable evidence-package catalog row."""

    __tablename__ = "analyzer_evidence_exports"
    __table_args__ = (
        UniqueConstraint("tenant_id", "customer_id", "idempotency_key", name="uq_analyzer_evidence_tenant_idempotency"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    period_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    period_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    package_ref: Mapped[str] = mapped_column(String(500), nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    file_size: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="ready", index=True)
    schema_version: Mapped[str] = mapped_column(String(20), nullable=False, default="1.0")
    provenance: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    envelope: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    idempotency_key: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )


class AnalyzerReport(Base, UUIDPK):
    """Immutable JSON report snapshot; PDF/CSV renderers consume this row."""

    __tablename__ = "analyzer_reports"
    __table_args__ = (
        UniqueConstraint("tenant_id", "customer_id", "idempotency_key", name="uq_analyzer_report_tenant_idempotency"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    period_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    period_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    report_type: Mapped[str] = mapped_column(String(80), nullable=False, index=True)
    schema_version: Mapped[str] = mapped_column(String(20), nullable=False, default="1.0")
    generated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    sha256_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    provenance: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    snapshot: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    idempotency_key: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), index=True
    )


class AnalyzerSavedView(Base, UUIDPK, TimestampMixin):
    """Tenant-scoped saved filter preset for the Analyzer surface."""

    __tablename__ = "analyzer_saved_views"

    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    created_by_user_id: Mapped[uuid.UUID] = fk("users", ondelete="CASCADE")
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    filters: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    is_shared: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, index=True)
