"""Vendor-neutral firewall syslog parsers for common gateway formats."""
from __future__ import annotations

import ipaddress
import re
import shlex
from typing import Any

from app.modules.firewall_adapters.fortigate import parse_syslog_event as parse_fortigate

_ASA = re.compile(r"%ASA-(?P<severity>\d)-(?P<code>\d+):\s*(?P<message>.*)")


def _int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _base(vendor: str, raw: str) -> dict[str, Any]:
    return {
        "vendor": vendor, "raw": raw, "parsed_fields": {"raw_message": raw},
        "log_type": "event", "log_subtype": None, "severity": "info",
        "action": None, "src_ip": None, "dst_ip": None, "src_port": None,
        "dst_port": None, "proto": None, "service": None, "user": None,
        "policyid": None, "duration": None, "sentbyte": None, "rcvdbyte": None,
        "session_id": None, "device_name": None, "device_id": None,
    }


def _parse_routeros(raw: str) -> dict[str, Any]:
    result = _base("mikrotik", raw)
    line = raw.strip()
    if line.startswith("<") and ">" in line:
        line = line.split(">", 1)[1].lstrip()
    try:
        tokens = shlex.split(line, posix=True)
    except ValueError:
        tokens = line.split()
    fields: dict[str, str] = {}
    for token in tokens:
        if "=" in token:
            key, value = token.split("=", 1)
            fields[key.lower()] = value
    topic = fields.get("topic") or ""
    if not topic:
        topic_match = re.match(r"(hotspot|firewall|account|ppp|system),(?:info|warning|error|debug)", line, re.I)
        topic = topic_match.group(1).lower() if topic_match else ""
    result["parsed_fields"].update(fields)
    result["device_name"] = fields.get("hostname") or fields.get("identity") or fields.get("devname")
    result["event_type"] = topic or fields.get("type") or "event"
    result["src_ip"] = fields.get("srcip") or fields.get("src") or fields.get("src-address")
    result["dst_ip"] = fields.get("dstip") or fields.get("dst") or fields.get("dst-address")
    result["src_port"] = _int(fields.get("srcport") or fields.get("src-port"))
    result["dst_port"] = _int(fields.get("dstport") or fields.get("dst-port"))
    result["action"] = fields.get("action")
    result["user"] = fields.get("user") or fields.get("username")
    result["proto"] = fields.get("protocol") or fields.get("proto")
    result["log_type"] = "traffic" if topic == "firewall" else ("event" if topic else "unknown")
    pairs = re.findall(r"(?:\(|\s)([0-9a-fA-F:.]+)(?::(\d+))?\s*(?:\)|->)", line)
    ips: list[tuple[str, int | None]] = []
    for ip, port in pairs:
        try:
            ipaddress.ip_address(ip)
            ips.append((ip, _int(port)))
        except ValueError:
            continue
    if ips:
        result["src_ip"], result["src_port"] = ips[0]
    if len(ips) > 1:
        result["dst_ip"], result["dst_port"] = ips[1]
    if not result["action"]:
        if re.search(r"\b(drop|deny|reject|blocked)\b", line, re.I):
            result["action"] = "deny"
        elif re.search(r"\b(accept|allow|forward)\b", line, re.I):
            result["action"] = "accept"
    return result


def _parse_pfsense(raw: str) -> dict[str, Any]:
    result = _base("pfsense", raw)
    line = raw.strip()
    marker = re.search(r"filterlog(?:\s+\d+)?[:,]\s*", line, re.I)
    if not marker:
        return result
    values = [v.strip() for v in line[marker.end():].split(",")]
    if values and values[0].isdigit() and int(values[0]) <= 10:
        # filterlog starts with the format version (normally 4); the
        # remaining indexes then follow the documented rule/action layout.
        result["parsed_fields"]["filterlog_version"] = values.pop(0)
    result["parsed_fields"].update({f"field_{i}": v for i, v in enumerate(values)})
    # pfSense filterlog (format 4/5) layout after the version field commonly
    # starts with empty rule/subrule/anchor fields followed by tracker,
    # interface, reason, action, direction, ipversion.
    if len(values) >= 7:
        result["policyid"] = _int(values[2]) or _int(values[0])
        result["action"] = values[5].lower() or None
    if len(values) >= 8:
        result["log_subtype"] = values[6].lower() or None
    result["log_type"] = "traffic"
    if len(values) > 15:
        result["proto"] = values[15] or None
    addresses: list[str] = []
    for value in values:
        try:
            ipaddress.ip_address(value)
            addresses.append(value)
        except ValueError:
            continue
    if addresses:
        result["src_ip"] = addresses[0]
    if len(addresses) > 1:
        result["dst_ip"] = addresses[1]
    if result["src_ip"] in values:
        idx = values.index(result["src_ip"])
        result["src_port"] = _int(values[idx + 2]) if idx + 2 < len(values) else None
        result["dst_port"] = _int(values[idx + 3]) if idx + 3 < len(values) else None
    if result["action"] in {"block", "reject", "deny"}:
        result["action"] = "deny"
    elif result["action"] in {"pass", "allow", "accept"}:
        result["action"] = "accept"
    return result


def _parse_cisco_asa(raw: str) -> dict[str, Any] | None:
    match = _ASA.search(raw)
    if not match:
        return None
    result = _base("cisco_asa", raw)
    result["severity"] = {
        0: "emergency", 1: "alert", 2: "critical", 3: "error",
        4: "warning", 5: "notice", 6: "info", 7: "debug",
    }.get(int(match.group("severity")), "info")
    code, message = match.group("code"), match.group("message")
    result["parsed_fields"] = {"asa_code": code, "message": message}
    result["log_type"] = "traffic" if code in {"302013", "302014", "302015", "302016", "302017", "302018"} else "event"
    result["log_subtype"] = "connection" if result["log_type"] == "traffic" else "system"
    result["action"] = "close" if "Teardown" in message else ("accept" if "Built" in message else None)
    proto_match = re.search(r"(?:Built|Teardown)\s+(\w+)\s+connection", message, re.I)
    result["proto"] = proto_match.group(1).lower() if proto_match else None
    endpoints = re.findall(r"[^:]+:([0-9a-fA-F:.]+)/(\d+)", message)
    if len(endpoints) >= 2:
        result["src_ip"], result["src_port"] = endpoints[0][0], _int(endpoints[0][1])
        result["dst_ip"], result["dst_port"] = endpoints[1][0], _int(endpoints[1][1])
    bytes_match = re.search(r"bytes\s+(\d+)", message, re.I)
    if bytes_match:
        result["sentbyte"] = _int(bytes_match.group(1))
    session_match = re.search(r"connection\s+(\d+)", message, re.I)
    result["session_id"] = session_match.group(1) if session_match else None
    return result


def parse_firewall_syslog(raw: str, vendor_hint: str | None = None) -> dict[str, Any]:
    """Parse FortiOS, RouterOS, pfSense and Cisco ASA into one shape."""
    hint = (vendor_hint or "").lower()
    if hint in {"cisco", "cisco_asa", "asa", "ftd"} or "%ASA-" in raw:
        parsed = _parse_cisco_asa(raw)
        if parsed is not None:
            return parsed
    if hint in {"pfsense", "opnsense"} or re.search(r"\bfilterlog(?:\s|:|,)", raw, re.I):
        return _parse_pfsense(raw)
    if hint in {"mikrotik", "routeros"} or re.search(r"\b(?:hotspot|firewall),(?:info|warning|error)", raw, re.I):
        return _parse_routeros(raw)
    return parse_fortigate(raw)
