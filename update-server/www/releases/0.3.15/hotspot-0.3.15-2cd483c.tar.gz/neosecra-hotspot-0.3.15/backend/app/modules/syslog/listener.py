"""Async TCP/UDP syslog listener (RFC 5424 receiver).

Listens on SYSLOG_LISTEN_HOST:SYSLOG_LISTEN_PORT (default 0.0.0.0:514) on both
TCP and UDP.  FortiGate's default syslog mode is UDP, while reliable mode is
TCP, so both transports share the same parser and persistence path.

Graceful shutdown via SIGTERM/SIGINT.

Usage:
    from app.modules.syslog.listener import start_syslog_server
    server = await start_syslog_server(db_session_factory)
    # ... later
    server.close()
    await server.wait_closed()
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import os
import signal
import time
from collections import OrderedDict, defaultdict
from datetime import datetime, timedelta, timezone

from sqlalchemy.ext.asyncio import async_sessionmaker

from app.core.config import settings
from app.modules.syslog.parsers import parse_firewall_syslog
from app.modules.syslog.models import FirewallLog
from app.modules.syslog.rfc5424 import parse_rfc5424
from app.modules.syslog.repository import (
    insert_firewall_log_batch,
    resolve_firewall_log_context,
)
from app.modules.syslog.service import process_firewall_log_batch

log = logging.getLogger(__name__)

# Config from environment with defaults
SYSLOG_HOST = os.getenv("SYSLOG_LISTEN_HOST", "0.0.0.0")
SYSLOG_PORT = int(os.getenv("SYSLOG_LISTEN_PORT", "514"))
BATCH_SIZE = 100
FLUSH_INTERVAL = 1.0  # seconds
UDP_QUEUE_SIZE = int(os.getenv("SYSLOG_UDP_QUEUE_SIZE", "8192"))
UDP_WORKERS = max(1, int(os.getenv("SYSLOG_UDP_WORKERS", "4")))


class _DeviceContextCache:
    """Bounded TTL cache for device -> tenant ownership resolution.

    A FortiGate commonly emits the same hostname/serial on every line. A
    cache miss is the only path allowed to open a database session; normal
    traffic therefore performs an in-memory lookup instead of one SQL JOIN per
    packet. Failed lookups are cached briefly too, preventing an unknown sender
    from exhausting the pool.
    """

    def __init__(self, ttl: float = 60.0, max_entries: int = 2048) -> None:
        self.ttl = ttl
        self.max_entries = max_entries
        self._items: OrderedDict[tuple[str, str, str], tuple[float, object]] = OrderedDict()

    async def resolve(
        self,
        db_session_factory: async_sessionmaker,
        hostname: str | None,
        device_identifier: str | None,
        source_ip: str | None,
    ):
        key = (
            (hostname or "").strip().lower(),
            (device_identifier or "").strip().lower(),
            (source_ip or "").strip().lower(),
        )
        now = time.monotonic()
        cached = self._items.get(key)
        if cached and cached[0] > now:
            self._items.move_to_end(key)
            return cached[1]
        if cached:
            self._items.pop(key, None)

        async with db_session_factory() as db:
            context = await resolve_firewall_log_context(
                db, hostname, device_identifier, source_ip=source_ip
            )
        self._items[key] = (now + self.ttl, context)
        self._items.move_to_end(key)
        while len(self._items) > self.max_entries:
            self._items.popitem(last=False)
        return context

    def invalidate(self) -> None:
        self._items.clear()


_context_cache = _DeviceContextCache()


async def start_syslog_server(
    db_session_factory: async_sessionmaker,
    host: str = SYSLOG_HOST,
    port: int = SYSLOG_PORT,
) -> asyncio.AbstractServer:
    """Start the async TCP syslog server.

    Returns the asyncio server object. Call server.close() to shut down.
    """
    if port < 1024 and os.geteuid() != 0:
        log.warning(
            "Port %d requires root; try port >1024 or run as root. "
            "Continuing anyway (will likely fail with EACCES).",
            port,
        )

    server = await asyncio.start_server(
        _make_handler(db_session_factory),
        host=host,
        port=port,
        reuse_address=True,
        reuse_port=False,
    )

    log.info("Syslog TCP server listening on %s:%d", host, port)
    return server


class _DatagramReader:
    """Small StreamReader-compatible wrapper for one UDP datagram."""

    def __init__(self, payload: bytes) -> None:
        self._lines = payload.splitlines(keepends=True) or [payload]

    async def readline(self) -> bytes:
        if not self._lines:
            return b""
        return self._lines.pop(0)


class _SyslogDatagramProtocol(asyncio.DatagramProtocol):
    def __init__(
        self,
        db_session_factory: async_sessionmaker,
        *,
        queue_size: int = UDP_QUEUE_SIZE,
        worker_count: int = UDP_WORKERS,
    ) -> None:
        self.db_session_factory = db_session_factory
        self.transport: asyncio.DatagramTransport | None = None
        self._queue: asyncio.Queue[tuple[bytes, tuple[str, int]]] = asyncio.Queue(
            maxsize=max(1, queue_size)
        )
        self._worker_count = max(1, worker_count)
        self._workers: set[asyncio.Task] = set()
        self._dropped = 0

    def connection_made(self, transport: asyncio.BaseTransport) -> None:
        self.transport = transport  # type: ignore[assignment]
        sock = transport.get_extra_info("sockname")
        log.info("Syslog UDP server listening on %s", sock)
        for _ in range(self._worker_count):
            worker = asyncio.create_task(self._worker())
            self._workers.add(worker)
            worker.add_done_callback(self._workers.discard)

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        if not data:
            return
        # Datagram callbacks must never spawn unbounded tasks. Put the packet
        # in a bounded queue; a fixed worker pool below batches records and
        # applies backpressure when PostgreSQL/ClickHouse is slow.
        try:
            self._queue.put_nowait((data, addr))
        except asyncio.QueueFull:
            self._dropped += 1
            if self._dropped == 1 or self._dropped % 1000 == 0:
                log.warning(
                    "Syslog UDP queue full; dropped=%d (increase SYSLOG_UDP_QUEUE_SIZE)",
                    self._dropped,
                )

    def error_received(self, exc: Exception) -> None:
        log.warning("Syslog UDP receive error: %s", exc)

    async def wait_tasks(self) -> None:
        # Drain accepted datagrams before stopping workers, then cancel the
        # idle consumers. Packets dropped because the queue was full are
        # explicitly counted and never reported as persisted.
        await self._queue.join()
        workers = list(self._workers)
        for worker in workers:
            worker.cancel()
        if workers:
            await asyncio.gather(*workers, return_exceptions=True)

    async def _worker(self) -> None:
        while True:
            first = await self._queue.get()
            packets = [first]
            try:
                # Drain a short burst into one parser call. Group by sender so
                # source_ip remains correct for ownership resolution.
                for _ in range(BATCH_SIZE - 1):
                    try:
                        packets.append(await asyncio.wait_for(self._queue.get(), timeout=0.01))
                    except asyncio.TimeoutError:
                        break
                grouped: defaultdict[str | None, list[bytes]] = defaultdict(list)
                for payload, peer in packets:
                    grouped[peer[0] if peer else None].append(payload)
                for source_ip, payloads in grouped.items():
                    combined = b"\n".join(payloads)
                    await _process_stream(
                        _DatagramReader(combined),
                        None,
                        self.db_session_factory,
                        source_ip=source_ip,
                    )
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("Syslog UDP worker failed for %d packets", len(packets))
            finally:
                for _ in packets:
                    self._queue.task_done()


async def start_syslog_udp_server(
    db_session_factory: async_sessionmaker,
    host: str = SYSLOG_HOST,
    port: int = SYSLOG_PORT,
) -> tuple[asyncio.DatagramTransport, _SyslogDatagramProtocol]:
    """Start the UDP listener on the same port as the TCP listener."""
    loop = asyncio.get_running_loop()
    transport, protocol = await loop.create_datagram_endpoint(
        lambda: _SyslogDatagramProtocol(db_session_factory),
        local_addr=(host, port),
    )
    return transport, protocol


def _make_handler(
    db_session_factory: async_sessionmaker,
):
    """Factory for per-connection handlers with closure over factory."""

    async def _handle_connection(
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        peername = writer.get_extra_info("peername")
        log.info("Syslog connection from %s", peername)
        try:
            peer_ip = peername[0] if isinstance(peername, tuple) and peername else None
            await _process_stream(
                reader, writer, db_session_factory, source_ip=peer_ip
            )
        except asyncio.CancelledError:
            log.debug("Syslog connection cancelled: %s", peername)
        except Exception:
            log.exception("Syslog connection error: %s", peername)
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    return _handle_connection


async def _process_stream(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    db_session_factory: async_sessionmaker,
    *,
    source_ip: str | None = None,
) -> None:
    """Read lines from the TCP stream, parse, batch insert."""
    batch: list[FirewallLog] = []
    last_flush = datetime.now(timezone.utc)

    while True:
        try:
            raw_bytes = await asyncio.wait_for(reader.readline(), timeout=300.0)
        except asyncio.TimeoutError:
            # Flush partial batch on idle timeout
            if batch:
                await _flush_batch(db_session_factory, batch)
                batch.clear()
                last_flush = datetime.now(timezone.utc)
            continue

        if not raw_bytes:
            # EOF
            break

        raw_line = raw_bytes.decode("utf-8", errors="replace").strip()
        if not raw_line:
            continue

        # Parse RFC 5424 to get hostname
        parsed = parse_rfc5424(raw_line)
        if parsed is None:
            log.debug("Unparseable syslog line, storing raw only")
            hostname = None
        else:
            hostname = parsed.get("hostname")

        # Enrich with FortiGate key=value parsing
        fortigate_data = parse_firewall_syslog(raw_line)
        hostname = hostname or fortigate_data.get("device_name")

        # Resolve ownership and the internal device UUID before constructing
        # the ORM row. FortiGate ``devid`` is a serial string, not our UUID.
        context = None
        device_identifier = fortigate_data.get("device_id")
        if hostname or device_identifier or source_ip or settings.SINGLE_TENANT_MODE:
            context = await _context_cache.resolve(
                db_session_factory,
                hostname,
                device_identifier,
                source_ip,
            )

        # Determine event_time from FortiGate date= + time= fields
        event_time = _parse_fortigate_timestamp(fortigate_data.get("parsed_fields", {}))

        # Build FirewallLog
        log_entry = FirewallLog(
            tenant_id=(context[0] if context else fortigate_data.get("tenant_id")),
            customer_id=(context[1] if context else fortigate_data.get("customer_id")),
            device_id=(context[2] if context else None),
            received_at=datetime.now(timezone.utc),
            event_time=event_time,
            vendor=fortigate_data.get("vendor", "fortigate"),
            log_type=fortigate_data.get("log_type", "unknown"),
            log_subtype=fortigate_data.get("log_subtype"),
            severity=fortigate_data.get("severity", "info"),
            action=fortigate_data.get("action"),
            src_ip=fortigate_data.get("src_ip"),
            dst_ip=fortigate_data.get("dst_ip"),
            src_port=fortigate_data.get("src_port"),
            dst_port=fortigate_data.get("dst_port"),
            proto=fortigate_data.get("proto"),
            service=fortigate_data.get("service"),
            user=fortigate_data.get("user"),
            policyid=fortigate_data.get("policyid"),
            duration=fortigate_data.get("duration"),
            sentbyte=fortigate_data.get("sentbyte"),
            rcvdbyte=fortigate_data.get("rcvdbyte"),
            session_id=fortigate_data.get("session_id"),
            raw_syslog=raw_line,
            parsed_fields=fortigate_data.get("parsed_fields", {}),
        )

        batch.append(log_entry)

        # Flush batch on size or time
        now = datetime.now(timezone.utc)
        time_since_flush = (now - last_flush).total_seconds()
        if len(batch) >= BATCH_SIZE or time_since_flush >= FLUSH_INTERVAL:
            await _flush_batch(db_session_factory, batch)
            batch.clear()
            last_flush = now

    # Flush remaining
    if batch:
        await _flush_batch(db_session_factory, batch)


async def _flush_batch(
    db_session_factory: async_sessionmaker,
    batch: list[FirewallLog],
) -> None:
    """Insert a batch into DB and call post-process service."""
    if not batch:
        return

    async with db_session_factory() as db:
        try:
            count = await insert_firewall_log_batch(db, batch)
            await db.commit()
            log.debug("Inserted %d firewall_logs", count)

            # Post-process records already persisted. Do not call the raw-line
            # ingestion function here; that would duplicate rows and pass an
            # ORM object to a string parser.
            await process_firewall_log_batch(db, batch)

            # The Analyzer is the canonical normalized projection for new
            # 5651/network analysis.  Keep the legacy FirewallLog table for
            # compatibility, but mirror each tenant-bound raw line through a
            # savepoint so one analyzer failure cannot erase the legacy batch.
            from app.modules.analyzer.service import mirror_firewall_log

            analyzer_mirrored = False
            for entry in batch:
                try:
                    savepoint = db.begin_nested()
                    if inspect.isawaitable(savepoint):
                        savepoint = await savepoint
                    async with savepoint:
                        mirrored = await mirror_firewall_log(db, entry, commit=False)
                        analyzer_mirrored = analyzer_mirrored or mirrored is not None
                except Exception:
                    log.exception("Analyzer mirror failed for firewall log %s", getattr(entry, "id", None))
            if analyzer_mirrored:
                await db.commit()

        except Exception:
            await db.rollback()
            log.exception("Batch insert failed for %d logs", len(batch))


def _parse_fortigate_timestamp(fields: dict) -> datetime | None:
    """Parse FortiGate date/time and honor its explicit local timezone.

    FortiOS emits ``tz="+0300"``.  Treating the wall clock as UTC shifts every
    event into the future, making a normal ``last 24 hours`` query hide live
    traffic.  Unknown/missing offsets retain the historical UTC behavior.
    """
    date_str = fields.get("date")
    time_str = fields.get("time")
    if date_str and time_str:
        try:
            dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M:%S")
            tz_raw = str(fields.get("tz") or fields.get("timezone") or "").strip()
            if tz_raw and len(tz_raw) == 5 and tz_raw[0] in "+-" and tz_raw[1:].isdigit():
                sign = 1 if tz_raw[0] == "+" else -1
                minutes = int(tz_raw[1:3]) * 60 + int(tz_raw[3:5])
                return dt.replace(tzinfo=timezone(sign * timedelta(minutes=minutes))).astimezone(timezone.utc)
            return dt.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    return None


async def run_forever(
    db_session_factory: async_sessionmaker,
    host: str = SYSLOG_HOST,
    port: int = SYSLOG_PORT,
) -> None:
    """Start syslog server and run until cancelled.

    Registers signal handlers for graceful shutdown.
    """
    server = await start_syslog_server(db_session_factory, host=host, port=port)
    udp_transport: asyncio.DatagramTransport | None = None
    udp_protocol: _SyslogDatagramProtocol | None = None
    try:
        udp_transport, udp_protocol = await start_syslog_udp_server(
            db_session_factory, host=host, port=port
        )
    except Exception:
        # TCP remains useful when an external process already owns UDP. Keep
        # startup non-fatal and make the transport limitation visible.
        log.exception("Failed to start syslog UDP server (TCP remains active)")

    stop_event = asyncio.Event()

    def _signal_handler():
        log.info("Signal received, shutting down syslog server...")
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _signal_handler)
        except NotImplementedError:
            pass

    await stop_event.wait()
    server.close()
    await server.wait_closed()
    if udp_transport is not None:
        udp_transport.close()
    if udp_protocol is not None:
        await udp_protocol.wait_tasks()
    log.info("Syslog server stopped.")


async def serve_forever(
    db_session_factory: async_sessionmaker,
    host: str = SYSLOG_HOST,
    port: int = SYSLOG_PORT,
) -> None:
    """Alias for run_forever — kept for compatibility."""
    await run_forever(db_session_factory, host=host, port=port)
