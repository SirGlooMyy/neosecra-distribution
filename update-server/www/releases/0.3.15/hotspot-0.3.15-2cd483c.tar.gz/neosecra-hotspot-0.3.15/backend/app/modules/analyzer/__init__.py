"""Tenant-scoped 5651/network Analyzer capability."""
