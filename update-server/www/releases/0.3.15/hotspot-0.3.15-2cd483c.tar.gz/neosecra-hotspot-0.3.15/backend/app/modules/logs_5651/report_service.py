"""5651-compliant PDF report and CSV generation — immutable archive evidence.

5651 sayili Kanun ve ilgili yonetmeliklere uygun:
  - Log kayitlari degistirilemez formatta sunulur
  - Hash zinciri dogrulama bilgisi rapora eklenir
  - Dijital imza bilgisi (varsa) rapora yansitilir
  - Mahkeme delil paketi: session + syslog + radius + hash chain

PDF generation uses weasyprint (primary) or reportlab (fallback), both
imported lazily so the app boots without them.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import logging
import os
import uuid
import zipfile
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.rls import set_syslog_context
from app.core.config import settings
from app.modules.logs_5651.models import ArchiveRecord
from app.modules.customers.models import Customer
from app.modules.sessions.models import GuestSession
from app.modules.syslog.models import SyslogRecord
from app.modules.radius.models import RadiusEvent
from app.modules.reports.envelope import envelope_hash

if TYPE_CHECKING:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        PageBreak,
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )
    import weasyprint

log = logging.getLogger(__name__)

_WEASYPRINT_AVAIL = False
_REPORTLAB_AVAIL = False

try:
    import weasyprint  # type: ignore[misc] # noqa: F401
    _WEASYPRINT_AVAIL = True
except ImportError:
    _WEASYPRINT_AVAIL = False

try:
    from reportlab.lib.pagesizes import A4, landscape  # type: ignore[misc] # noqa: F401
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle  # type: ignore[misc] # noqa: F401
    from reportlab.lib.units import cm  # type: ignore[misc] # noqa: F401
    from reportlab.platypus import (  # type: ignore[misc] # noqa: F401
        Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak,
    )
    from reportlab.lib import colors  # type: ignore[misc] # noqa: F401
    _REPORTLAB_AVAIL = True
except ImportError:
    pass


# ---- 5651 PDF generation ------------------------------------------------------


async def generate_5651_pdf(
    db: AsyncSession,
    customer_id: uuid.UUID,
    period_start: datetime,
    period_end: datetime,
    archive_records: list[ArchiveRecord],
    require_ready: bool = False,
) -> bytes:
    """Generate a 5651 yasal rapor formatinda PDF.

    Args:
        db: Database session.
        customer_id: Musteri ID.
        period_start: Baslangic tarihi.
        period_end: Bitis tarihi.
        archive_records: Imzalanacak/raporlanacak arsiv kayitlari.

    Returns:
        PDF bytes.
    """
    from app.modules.customers.models import Customer
    if require_ready and not archive_records:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="5651 archive evidence is unavailable",
        )
    if require_ready and any(
        getattr(r, "status", None) != "ready"
        or not getattr(r, "storage_verified", False)
        or not getattr(r, "signature_valid", False)
        for r in archive_records
    ):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="5651 archive is not storage- and signature-verified",
        )

    cust_res = await db.execute(select(Customer).where(Customer.id == customer_id))
    customer = cust_res.scalar_one_or_none()
    if require_ready:
        if customer is None or getattr(customer, "tenant_id", None) is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="tenant provenance unavailable",
            )
        if any(
            str(getattr(record, "customer_id", "")) != str(customer_id)
            for record in archive_records
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="archive customer scope mismatch",
            )
    # ``require_ready=False`` is an explicit rendering-only compatibility path
    # used by legacy/unit callers.  Publication/download callers must use the
    # strict path above and cannot receive a synthetic customer identity.
    customer_name = customer.name if customer else "Bilinmeyen Musteri"

    html = _build_5651_html(
        customer_info={
            "name": customer_name,
            "id": str(customer_id),
        },
        period={"start": period_start, "end": period_end},
        records=archive_records,
    )

    if _WEASYPRINT_AVAIL:
        pdf_bytes = weasyprint.HTML(string=html).write_pdf()
        if pdf_bytes is None:
            raise RuntimeError("weasyprint PDF uretemedi")
        return pdf_bytes
    if _REPORTLAB_AVAIL:
        return _render_5651_reportlab(customer_name, period_start, period_end, archive_records)
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="PDF olusturmak icin weasyprint veya reportlab kurulu olmali",
    )


def _build_5651_html(
    customer_info: dict,
    period: dict,
    records: list[ArchiveRecord],
) -> str:
    """5651 kanun metni referansli HTML template."""
    now_str = datetime.now(timezone.utc).strftime("%d.%m.%Y %H:%M:%S UTC")
    period_start_str = period["start"].strftime("%d.%m.%Y %H:%M:%S") if isinstance(period["start"], datetime) else str(period["start"])
    period_end_str = period["end"].strftime("%d.%m.%Y %H:%M:%S") if isinstance(period["end"], datetime) else str(period["end"])

    record_rows = ""
    total_items = 0
    for r in records:
        total_items += r.item_count
        sig_status = "Imzali" if r.signature_value else "Imzasiz"
        sig_info = f"{sig_status}"
        if r.signature_time:
            sig_info += f" | {r.signature_time.strftime('%d.%m.%Y %H:%M:%S')}"
        if r.certificate_serial:
            sig_info += f" | SN: {r.certificate_serial[:20]}"
        record_rows += f"""<tr>
            <td>{r.chain_seq}</td>
            <td>{r.period_start.strftime('%d.%m.%Y %H:%M:%S')}</td>
            <td>{r.period_end.strftime('%d.%m.%Y %H:%M:%S')}</td>
            <td>{r.item_count}</td>
            <td style="font-family:monospace;font-size:9px">{r.content_hash[:20]}...</td>
            <td style="font-family:monospace;font-size:9px">{r.curr_hash[:20]}...</td>
            <td>{sig_info}</td>
        </tr>"""

    chain_ok = _chain_status_html(records)

    return f"""<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<style>
    @page {{ size: A4; margin: 2cm; }}
    body {{ font-family: DejaVu Sans, sans-serif; font-size: 10pt; color: #1a1a1a; }}
    h1 {{ font-size: 16pt; color: #1f2937; border-bottom: 2px solid #1f2937; padding-bottom: 6px; }}
    h2 {{ font-size: 13pt; color: #374151; margin-top: 20px; }}
    h3 {{ font-size: 11pt; color: #4b5563; }}
    table {{ border-collapse: collapse; width: 100%; margin-bottom: 15px; font-size: 9pt; }}
    th, td {{ border: 1px solid #d1d5db; padding: 5px; text-align: left; }}
    th {{ background: #1f2937; color: white; font-weight: bold; }}
    tr:nth-child(even) {{ background: #f9fafb; }}
    .legal {{ background: #fffbeb; border: 1px solid #fde68a; padding: 10px; margin: 15px 0; font-size: 9pt; }}
    .footer {{ margin-top: 30px; font-size: 8pt; color: #6b7280; text-align: center; border-top: 1px solid #d1d5db; padding-top: 10px; }}
    .hash {{ font-family: monospace; font-size: 8pt; word-break: break-all; }}
</style>
</head>
<body>

<h1>5651 Sayili Kanun Kapsaminda Log Arsiv Raporu</h1>

<div class="legal">
    <strong>5651 sayili "Internet Ortaminda Yapilan Yayinlarin Duzenlenmesi ve Bu
    Yayinlar Yoluyla Islenen Suc ve Kabahatlerle Mucadele Edilmesi Hakkinda Kanun"</strong><br>
    ve 26.06.2015 tarihli "Temel Hizmet Saglayicilarina ve Yer Saglayicilarina
    Iliskin Usul ve Esaslar" kapsaminda hazirlanmistir. Bu rapor, ilgili mevzuat
    geregi log kayitlarinin degistirilemez, dogrulanabilir ve imzali bir
    ozetini sunar.
</div>

<h2>Musteri Bilgisi</h2>
<table>
    <tr><td style="width:200px"><strong>Musteri Adi</strong></td><td>{customer_info['name']}</td></tr>
    <tr><td><strong>Musteri ID</strong></td><td style="font-family:monospace">{customer_info['id']}</td></tr>
    <tr><td><strong>Rapor Donemi</strong></td><td>{period_start_str} — {period_end_str}</td></tr>
    <tr><td><strong>Rapor Tarihi</strong></td><td>{now_str}</td></tr>
    <tr><td><strong>Toplam Arsiv Kaydi</strong></td><td>{len(records)}</td></tr>
    <tr><td><strong>Toplam Oturum Sayisi</strong></td><td>{total_items}</td></tr>
</table>

<h2>Arsiv Kayitlari ve Hash Zinciri</h2>
<table>
    <tr>
        <th>#</th>
        <th>Baslangic</th>
        <th>Bitis</th>
        <th>Kayit Sayisi</th>
        <th>Content Hash</th>
        <th>Chain Hash</th>
        <th>Imza</th>
    </tr>
    {record_rows}
</table>

<h2>Hash Zinciri Dogrulama</h2>
{chain_ok}

<h2>Dijital Imza Bilgisi</h2>
<table>
    <tr><td>Imzalama Yontemi</td><td>SHA-256 RSA PKCS#1 v1.5</td></tr>
    <tr><td>Imzalayan</td><td>Hotspot Platform — 5651 Log Arsiv Modulu</td></tr>
    <tr><td>Sertifika Altyapisi</td><td>TUBITAK KamuSM / Yerel Kriptografik X.509 Sertifikasi</td></tr>
</table>

{_signature_detail_rows(records)}

<div class="footer">
    Bu rapor {now_str} tarihinde Hotspot Platform tarafindan otomatik olarak
    olusturulmustur. Rapor icerisindeki hash degerleri ile arsiv butunlugu
    dogrulanabilir. 5651 sayili kanun geregi log kayitlari en az 2 yil sureyle
    saklanmalidir.
</div>

</body></html>"""


def _chain_status_html(records: list[ArchiveRecord]) -> str:
    if not records:
        return "<p>Zincir bos.</p>"
    expected_prev = "0" * 64
    rows = ""
    for r in records:
        from app.modules.logs_5651.service import _chain_hash, _period_key

        pkey = _period_key(r.period_start, r.period_end)
        recomputed = _chain_hash(r.prev_hash, r.content_hash, pkey, r.record_type)
        prev_ok = r.prev_hash == expected_prev
        curr_ok = recomputed == r.curr_hash
        status_icon = "✓" if (prev_ok and curr_ok) else "✗"
        rows += f"""<tr>
            <td>{r.chain_seq}</td>
            <td>{'✓' if prev_ok else '✗'}</td>
            <td>{'✓' if curr_ok else '✗'}</td>
            <td class="hash">{r.curr_hash[:32]}...</td>
            <td>{status_icon}</td>
        </tr>"""
        expected_prev = r.curr_hash
    return f"""<table>
    <tr><th>#</th><th>Onceki Hash</th><th>Chain Hash</th><th>Deger</th><th>Durum</th></tr>
    {rows}
</table>"""


def _signature_detail_rows(records: list[ArchiveRecord]) -> str:
    signed = [r for r in records if r.signature_value]
    if not signed:
        return "<p><em>Bu donemde dijital imza bulunmamaktadir.</em></p>"
    rows = ""
    for r in signed:
        sig_value = r.signature_value or ""
        rows += f"""<tr>
            <td>{r.chain_seq}</td>
            <td style="font-family:monospace;font-size:8px">{sig_value[:40]}...</td>
            <td>{r.signature_time.strftime('%d.%m.%Y %H:%M:%S') if r.signature_time else '-'}</td>
            <td>{r.certificate_serial or '-'}</td>
            <td>{r.sign_method or '-'}</td>
        </tr>"""
    return f"""<h3>Imzali Kayitlar</h3>
<table>
    <tr><th>#</th><th>Imza Degeri</th><th>Imza Zamani</th><th>Sertifika Seri No</th><th>Yontem</th></tr>
    {rows}
</table>"""


def _render_5651_reportlab(
    customer_name: str,
    period_start: datetime,
    period_end: datetime,
    records: list[ArchiveRecord],
) -> bytes:
    """Reportlab fallback rendering."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title="5651 Log Arsiv Raporu")
    styles = getSampleStyleSheet()
    elems = []

    title_style = ParagraphStyle("Title5651", parent=styles["Title"], fontSize=14, leading=18)
    elems.append(Paragraph("5651 Sayili Kanun Kapsaminda Log Arsiv Raporu", title_style))
    elems.append(Spacer(1, 0.5 * cm))

    info_data = [
        ["Musteri", customer_name],
        ["Donem", f"{period_start.strftime('%d.%m.%Y')} - {period_end.strftime('%d.%m.%Y')}"],
        ["Kayit Sayisi", str(len(records))],
        ["Toplam Oturum", str(sum(r.item_count for r in records))],
    ]
    info_table = Table(info_data, colWidths=[4 * cm, 10 * cm])
    info_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#1f2937")),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    elems.append(info_table)
    elems.append(Spacer(1, 0.5 * cm))

    if records:
        elems.append(Paragraph("Arsiv Kayitlari", styles["Heading2"]))
        table_data = [["#", "Baslangic", "Bitis", "Kayit", "Imza"]]
        for r in records:
            sig = "Evet" if r.signature_value else "Hayir"
            table_data.append([
                str(r.chain_seq),
                r.period_start.strftime("%d.%m.%Y"),
                r.period_end.strftime("%d.%m.%Y"),
                str(r.item_count),
                sig,
            ])
        t = Table(table_data, repeatRows=1, colWidths=[1.5 * cm, 3.5 * cm, 3.5 * cm, 2 * cm, 2 * cm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        elems.append(t)

    doc.build(elems)
    return buf.getvalue()


# ---- CSV export ---------------------------------------------------------------


def export_session_logs_csv(
    sessions: list[GuestSession], period: dict
) -> bytes:
    """5651 log kayitlarini CSV olarak export eder.

    CSV format: UTF-8 BOM ile baslar (Excel uyumu), Turkish karakterler korunur.
    """
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow(["5651 Log Kaydi Export — Hotspot Platform"])
    writer.writerow([
        "Donem:",
        f"{period.get('start', '')} — {period.get('end', '')}",
    ])
    writer.writerow([])

    headers = [
        "session_id", "mac", "ip", "nas_ip", "ssid", "phone",
        "auth_method", "status", "started_at", "ended_at", "expires_at",
        "customer_id", "location_id",
    ]
    writer.writerow(headers)

    for s in sessions:
        writer.writerow([
            str(s.id),
            s.mac or "",
            s.ip or "",
            s.nas_ip or "",
            s.ssid or "",
            s.phone or "",
            s.auth_method,
            s.status,
            s.started_at.isoformat() if s.started_at else "",
            s.ended_at.isoformat() if s.ended_at else "",
            s.expires_at.isoformat() if s.expires_at else "",
            str(s.customer_id),
            str(s.location_id) if s.location_id else "",
        ])

    bom = "\ufeff"
    return (bom + output.getvalue()).encode("utf-8")


# ---- Court evidence package ---------------------------------------------------


async def generate_court_evidence_package(
    db: AsyncSession,
    session_id: uuid.UUID,
    customer_id: uuid.UUID,
) -> bytes:
    """Mahkeme delil paketi olusturur.

    Paket icerigi (ZIP):
      1. session.json           — oturum detaylari
      2. syslog_records.jsonl   — ilgili syslog kayitlari
      3. radius_events.jsonl    — RADIUS accounting kayitlari
      4. archive_chain.json     — hash zinciri bilgisi
      5. evidence_manifest.json — paket bilgisi ve hash
    """

    session = await db.get(GuestSession, session_id)
    if not session:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Oturum bulunamadi")

    if str(session.customer_id) != str(customer_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu oturum bu musteriye ait degil")

    customer_row = await db.get(Customer, customer_id)
    tenant_id = getattr(customer_row, "tenant_id", None) if customer_row else None
    if tenant_id is None:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="tenant provenance unavailable")

    file_payloads: dict[str, bytes] = {}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:

        # 1. session.json
        session_data = {
            "session_id": str(session.id),
            "customer_id": str(session.customer_id),
            "location_id": str(session.location_id) if session.location_id else None,
            "device_id": str(session.device_id) if session.device_id else None,
            "mac": session.mac,
            "ip": session.ip,
            "nas_ip": session.nas_ip,
            "ssid": session.ssid,
            "phone": session.phone,
            "auth_method": session.auth_method,
            "status": session.status,
            "started_at": session.started_at.isoformat() if session.started_at else None,
            "ended_at": session.ended_at.isoformat() if session.ended_at else None,
            "expires_at": session.expires_at.isoformat() if session.expires_at else None,
            "radius_session_id": session.radius_session_id,
            "bytes_in": session.bytes_in,
            "bytes_out": session.bytes_out,
            "authorize_ok": session.authorize_ok,
            "authorize_message": session.authorize_message,
            "group_id": str(session.group_id) if getattr(session, "group_id", None) else None,
            "group_policy": (session.meta or {}).get("group_policy") if isinstance(session.meta, dict) else None,
        }
        file_payloads["session.json"] = json.dumps(session_data, indent=2, ensure_ascii=False).encode("utf-8")
        zf.writestr("session.json", file_payloads["session.json"])

        # 2. syslog_records.jsonl (NAS IP veya session IP ile iliskili)
        syslog_filter = []
        if session.nas_ip:
            syslog_filter.append(SyslogRecord.hostname == session.nas_ip)
        if session.ip:
            syslog_filter.append(SyslogRecord.message.contains(session.ip))
        if session.mac:
            syslog_filter.append(SyslogRecord.message.contains(session.mac))

        syslog_rows = []
        if syslog_filter:
            await set_syslog_context(db, tenant_id)
            from sqlalchemy import or_
            sys_res = await db.execute(
                select(SyslogRecord)
                .where(SyslogRecord.tenant_id == tenant_id, or_(*syslog_filter))
                .order_by(SyslogRecord.created_at.desc())
                .limit(500)
            )
            for sr in sys_res.scalars().all():
                syslog_rows.append({
                    "id": str(sr.id),
                    "facility": sr.facility,
                    "severity": sr.severity,
                    "hostname": sr.hostname,
                    "app_name": sr.app_name,
                    "message": sr.message,
                    "created_at": sr.created_at.isoformat() if sr.created_at else None,
                })
        file_payloads["syslog_records.jsonl"] = "\n".join(json.dumps(r, ensure_ascii=False) for r in syslog_rows).encode("utf-8")
        zf.writestr("syslog_records.jsonl", file_payloads["syslog_records.jsonl"])

        # 3. radius_events.jsonl
        radius_rows = []
        if session.radius_session_id:
            rad_res = await db.execute(
                select(RadiusEvent)
                .where(RadiusEvent.tenant_id == tenant_id, RadiusEvent.acct_session_id == session.radius_session_id)
                .order_by(RadiusEvent.created_at.asc())
            )
            for re in rad_res.scalars().all():
                radius_rows.append({
                    "id": str(re.id),
                    "username": re.username,
                    "nas_ip": re.nas_ip,
                    "acct_status_type": re.acct_status_type,
                    "acct_session_id": re.acct_session_id,
                    "calling_station_id": re.calling_station_id,
                    "framed_ip_address": re.framed_ip_address,
                    "acct_input_octets": re.acct_input_octets,
                    "acct_output_octets": re.acct_output_octets,
                    "acct_session_time": re.acct_session_time,
                    "acct_terminate_cause": re.acct_terminate_cause,
                    "acct_interim_interval": re.acct_interim_interval,
                    "created_at": re.created_at.isoformat() if re.created_at else None,
                })
        file_payloads["radius_events.jsonl"] = "\n".join(json.dumps(r, ensure_ascii=False) for r in radius_rows).encode("utf-8")
        zf.writestr("radius_events.jsonl", file_payloads["radius_events.jsonl"])

        # 4. archive_chain.json
        chain_res = await db.execute(
            select(ArchiveRecord)
            .where(ArchiveRecord.customer_id == customer_id)
            .order_by(ArchiveRecord.chain_seq.asc())
        )
        chain_records = list(chain_res.scalars().all())
        # A court package must never silently include an archive whose object
        # or signature was not verified.  Empty chains are allowed for a new
        # installation; any present unverified record fails closed.
        if any(
            getattr(ar, "status", None) != "ready"
            or not getattr(ar, "storage_verified", False)
            or not getattr(ar, "signature_valid", False)
            for ar in chain_records
        ):
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="5651 archive chain contains unverified evidence",
            )
        chain_data = []
        for ar in chain_records:
            chain_data.append({
                "chain_seq": ar.chain_seq,
                "period_start": ar.period_start.isoformat() if ar.period_start else None,
                "period_end": ar.period_end.isoformat() if ar.period_end else None,
                "item_count": ar.item_count,
                "content_hash": ar.content_hash,
                "content_ref": ar.content_ref,
                "prev_hash": ar.prev_hash,
                "curr_hash": ar.curr_hash,
                "signature_value": ar.signature_value,
                "signature_time": ar.signature_time.isoformat() if ar.signature_time else None,
                "certificate_serial": ar.certificate_serial,
                "sign_method": ar.sign_method,
            })
        file_payloads["archive_chain.json"] = json.dumps(chain_data, indent=2, ensure_ascii=False).encode("utf-8")
        zf.writestr("archive_chain.json", file_payloads["archive_chain.json"])

        # 5. evidence_manifest.json
        manifest = {
            "package_type": "5651_court_evidence",
            "schema_version": "1.0",
            "session_id": str(session_id),
            "customer_id": str(customer_id),
            "tenant_id": str(tenant_id),
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "platform": "Hotspot Platform",
            "platform_version": settings.VERSION,
            "files": [
                "session.json",
                "syslog_records.jsonl",
                "radius_events.jsonl",
                "archive_chain.json",
            ],
            "sha256_hashes": {name: hashlib.sha256(payload).hexdigest() for name, payload in file_payloads.items()},
            "legal_basis": (
                "5651 sayili Kanun ve ilgili yonetmelikler kapsaminda "
                "mahkeme ve kolluk kuvvetlerine sunulmak uzere hazirlanmistir."
            ),
        }
        manifest["sha256_hash"] = envelope_hash(manifest)
        file_payloads["evidence_manifest.json"] = json.dumps(manifest, indent=2, ensure_ascii=False).encode("utf-8")
        zf.writestr("evidence_manifest.json", file_payloads["evidence_manifest.json"])

    return buf.getvalue()


# ---- evidence package file storage --------------------------------------------


async def save_evidence_package(
    package_bytes: bytes,
    session_id: uuid.UUID,
    customer_id: uuid.UUID,
) -> str:
    """Save evidence package to local storage and return file path.

    Returns content_ref string matching archive_service convention.
    """
    base = settings.EVIDENCE_STORAGE_PATH
    os.makedirs(base, exist_ok=True)
    pkg_hash = hashlib.sha256(package_bytes).hexdigest()
    filename = f"evidence_{session_id}_{pkg_hash[:16]}.zip"
    filepath = os.path.join(base, filename)
    try:
        with open(filepath, "xb") as fh:
            fh.write(package_bytes)
    except FileExistsError:
        # Idempotent retry: an identical content-addressed package is safe to
        # reuse; a different payload must never overwrite immutable evidence.
        with open(filepath, "rb") as fh:
            if hashlib.sha256(fh.read()).hexdigest() != pkg_hash:
                raise IOError("immutable evidence package already exists with a different hash")
    with open(filepath, "rb") as fh:
        if hashlib.sha256(fh.read()).hexdigest() != pkg_hash:
            raise IOError("evidence package storage verification failed")
    return f"local:{filepath}"


def inspect_evidence_package(package_bytes: bytes) -> tuple[dict, dict[str, str]]:
    """Validate an evidence ZIP and return its manifest and file hashes."""
    with zipfile.ZipFile(io.BytesIO(package_bytes), "r") as zf:
        manifest = json.loads(zf.read("evidence_manifest.json"))
        expected_manifest_hash = manifest.get("sha256_hash")
        if not isinstance(expected_manifest_hash, str) or envelope_hash(manifest) != expected_manifest_hash:
            raise ValueError("evidence manifest SHA-256 mismatch")
        expected_files = manifest.get("sha256_hashes") or {}
        actual_files: dict[str, str] = {}
        for name, expected in expected_files.items():
            payload = zf.read(name)
            digest = hashlib.sha256(payload).hexdigest()
            if digest != expected:
                raise ValueError(f"evidence file SHA-256 mismatch: {name}")
            actual_files[name] = digest
    return manifest, actual_files


async def generate_archive_zip_package(
    db: AsyncSession,
    archive_id: uuid.UUID,
    customer_id: uuid.UUID,
) -> tuple[bytes, str]:
    """Generates an official, court/audit ready 5651 ZIP package for an archive record."""
    from app.modules.customers.models import Customer
    from app.modules.logs_5651.archive_service import read_archive_payload

    archive_rec = await db.get(ArchiveRecord, archive_id)
    if not archive_rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Arsiv kaydi bulunamadi")
    if (
        getattr(archive_rec, "status", None) != "ready"
        or not getattr(archive_rec, "storage_verified", False)
        or not getattr(archive_rec, "signature_valid", False)
    ):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="5651 archive is not storage- and signature-verified",
        )

    if str(getattr(archive_rec, "customer_id", "")) != str(customer_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="archive customer scope mismatch")

    cust_res = await db.execute(select(Customer).where(Customer.id == customer_id))
    customer = cust_res.scalar_one_or_none()
    if customer is None or getattr(customer, "tenant_id", None) is None:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="tenant provenance unavailable")
    customer_name = customer.name

    # 1. Generate PDF
    pdf_bytes = await generate_5651_pdf(
        db,
        customer_id=customer_id,
        period_start=archive_rec.period_start,
        period_end=archive_rec.period_end,
        archive_records=[archive_rec],
        require_ready=True,
    )

    # 2. Get Raw Payload
    raw_payload = read_archive_payload(archive_rec.content_ref or "")
    if not raw_payload or hashlib.sha256(raw_payload).hexdigest() != archive_rec.content_hash:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="5651 archive payload unavailable or hash mismatch",
        )

    # 3. Cryptographic Signature & Hash Manifest
    sig_manifest = {
        "kanun": "5651 Sayili Kanun ve Ilgili Mevzuat",
        "arsiv_id": str(archive_rec.id),
        "blok_sira_no": archive_rec.chain_seq,
        "kurum_adi": customer_name,
        "log_turu": archive_rec.record_type,
        "kayit_sayisi": archive_rec.item_count,
        "donem_baslangic": archive_rec.period_start.isoformat(),
        "donem_bitis": archive_rec.period_end.isoformat(),
        "sha256_icerik_ozeti": archive_rec.content_hash,
        "blok_zincir_hash": archive_rec.curr_hash,
        "onceki_blok_hash": archive_rec.prev_hash,
        "zaman_damgasi_durumu": "Mühürlü" if archive_rec.signature_value else "Beklemede",
        "zaman_damgasi_tarihi": archive_rec.signature_time.isoformat() if archive_rec.signature_time else None,
        "zaman_damgasi_sertifika_seri_no": archive_rec.certificate_serial,
        "imza_degeri": archive_rec.signature_value,
        "imza_kaynagi": (archive_rec.meta or {}).get("signature_origin", archive_rec.sign_method or "kamusm"),
    }

    # 4. Forensic verification guide for prosecutors & police
    date_str = archive_rec.period_start.strftime("%d.%m.%Y")
    guide_text = f"""================================================================================
5651 SAYILI KANUN KAPSAMINDA ELEKTRONIK DELIL VE LOG DOGRULAMA REHBERI
================================================================================
Kurum / Musteri: {customer_name}
Arsiv Blok Sira No: #{archive_rec.chain_seq}
Donem: {date_str}
Log Turu: {archive_rec.record_type}
Kayit Sayisi: {archive_rec.item_count} adet

BU PAKETIN ICERIGI:
1. 5651_Yasal_Arsiv_Raporu.pdf : Adli mercilere sunulmak uzere hazirlanmis resmi ozet rapor.
2. 5651_Icerik_Loglari.jsonl   : Olay anina ait IP, MAC, Port, Kimlik ve Trafik kayitlari.
3. Kriptografik_Zaman_Damgasi.json : SHA-256 hash ve zaman damgasi imza detaylari.

KRIPTOGRAFIK DOGRULAMA ADIMLARI (BILIRKISI / ADLI BILISIM ICIN):
--------------------------------------------------------------------------------
1. '5651_Icerik_Loglari.jsonl' dosyasinin SHA-256 ozetini hesaplayiniz:
   Linux / Mac: sha256sum 5651_Icerik_Loglari.jsonl
   Windows: CertUtil -hashfile 5651_Icerik_Loglari.jsonl SHA256

2. Hesaplanan ozet degerinin Kriptografik_Zaman_Damgasi_ve_Hash_Imzasi.json
   dosyasindaki 'sha256_icerik_ozeti' degeri ({archive_rec.content_hash})
   ile BIREBIR ESIT oldugunu teyit ediniz.

3. Bu esitlik, log kayitlarinin olusturuldugu andan itibaren 1 karakter dahi
   degistirilmedigini veya tahrif edilmedigini kesin olarak kanitlar.
================================================================================
"""

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("5651_Yasal_Arsiv_Raporu.pdf", pdf_bytes)
        zf.writestr("5651_Icerik_Loglari.jsonl", raw_payload)
        zf.writestr("Kriptografik_Zaman_Damgasi_ve_Hash_Imzasi.json", json.dumps(sig_manifest, indent=2, ensure_ascii=False))
        zf.writestr("Bilisim_ve_Savcilik_Dogrulama_Rehberi.txt", guide_text)

    filename = f"5651_Delil_Paketi_{archive_rec.chain_seq}_{archive_rec.period_start.strftime('%Y%m%d')}.zip"
    return buf.getvalue(), filename
