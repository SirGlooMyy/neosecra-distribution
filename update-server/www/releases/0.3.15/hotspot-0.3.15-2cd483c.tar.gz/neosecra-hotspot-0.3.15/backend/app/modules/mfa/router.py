"""MFA HTTP endpoints."""
import logging
import uuid
import io
from datetime import datetime, timezone
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.modules.auth.deps import get_current_user, require_permission
from app.modules.auth.models import User
from app.modules.mfa import (
    portal_service,
    rdp_service,
    service as mfa_service,
    vpn_service,
)

router = APIRouter()
log = logging.getLogger(__name__)


async def _customer_for_mfa(db: AsyncSession, user: User) -> uuid.UUID:
    """Resolve the installation customer for global/super-admin users.

    VPN MFA is an installation capability, so a super-admin must be able to
    configure it even when the admin account itself has no customer_id.
    """
    cid = user.customer_id or await resolve_installation_customer(db)
    if not cid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Musteri baglantisi bulunamadi",
        )
    return cid


# ---- Schemas ----------------------------------------------------------------
class TotpSetupOut(BaseModel):
    secret: str
    qr_code_uri: str
    backup_codes: list[str]


class TotpVerifyIn(BaseModel):
    code: str = Field(..., min_length=4, max_length=10)


class MfaCodeSendIn(BaseModel):
    method: str = Field(..., pattern=r"^(sms|email|whatsapp)$")


class MfaCodeSendOut(BaseModel):
    session_token: str
    ttl_seconds: int


class MfaCodeVerifyIn(BaseModel):
    session_token: str
    code: str = Field(..., min_length=4, max_length=10)


class BackupCodeVerifyIn(BaseModel):
    code: str = Field(..., min_length=1)


class MfaStatusOut(BaseModel):
    mfa_required: bool
    methods: list[str]
    active_tokens: list[str]
    backup_codes_remaining: int


class RdpConfigIn(BaseModel):
    is_enabled: bool = True
    gateway_host: str | None = None
    gateway_port: int = 3391
    allowed_groups: list[str] = []
    mfa_method: str = "sms"


class VpnConfigIn(BaseModel):
    is_enabled: bool = True
    # Public address/port of the bundled Hotspot RADIUS listener.  The
    # gateway_* names are retained as a wire-compatibility alias for older
    # admin builds and are never shown as a VPN gateway setting.
    radius_listener_host: str | None = Field(default=None, max_length=255)
    radius_listener_port: int | None = Field(default=None, ge=1, le=65535)
    gateway_host: str | None = None
    # FreeRADIUS authentication listener (the FortiGate VPN gateway itself
    # stays on its own SSL-VPN/IPsec port).
    gateway_port: int = 1812
    radius_nas_ip: str | None = Field(default=None, max_length=64)
    radius_accounting_port: int = Field(default=1813, ge=1, le=65535)
    # Only accepted on writes; never returned by the API.
    radius_shared_secret: str | None = Field(default=None, min_length=4, max_length=512)
    allowed_groups: list[str] = []
    mfa_method: str = "totp"
    sms_template: str | None = Field(
        default=None,
        max_length=500,
        description="VPN SMS metni; {code} ve {username} yer tutucuları desteklenir.",
    )


class PortalConfigIn(BaseModel):
    is_enabled: bool = True
    mfa_method: str = "sms"
    require_mfa_after: str | None = None


class ConfigOut(BaseModel):
    id: str
    is_enabled: bool
    mfa_method: str
    extra: dict = {}


class VpnMfaUserCreateIn(BaseModel):
    username: str = Field(..., min_length=1, max_length=255)
    password: str | None = None
    mfa_method: str = Field(default="totp", min_length=1, max_length=100)
    secret: str | None = None
    phone: str | None = None
    email: str | None = None


class VpnMfaUserOut(BaseModel):
    id: str
    username: str
    mfa_method: str
    phone: str | None = None
    email: str | None = None
    is_active: bool
    qr_code_uri: str | None = None
    qr_code_svg: str | None = None
    # Only populated on the one-time setup response; list calls keep it null.
    totp_secret: str | None = None


def _totp_uri(username: str, secret: str) -> str:
    label = quote(f"NeoSecra VPN:{username}")
    issuer = quote("NeoSecra VPN")
    return f"otpauth://totp/{label}?secret={quote(secret)}&issuer={issuer}&algorithm=SHA1&digits=6&period=30"


def _totp_qr_svg(uri: str) -> str | None:
    """Render a self-contained QR SVG without sending the secret elsewhere."""
    try:
        import qrcode
        from qrcode.image.svg import SvgPathImage
        image = qrcode.make(uri, image_factory=SvgPathImage)
        buf = io.BytesIO()
        image.save(buf)
        return buf.getvalue().decode("utf-8")
    except Exception:
        return None


def _request_host(request: Request | None) -> str | None:
    if not request:
        return None
    forwarded = request.headers.get("x-forwarded-host") or request.headers.get("host")
    if not forwarded:
        return request.url.hostname
    # X-Forwarded-Host may contain a comma-separated proxy chain and a port.
    host = forwarded.split(",", 1)[0].strip()
    if host.startswith("[") and "]" in host:
        return host[1:host.index("]")]
    return host.rsplit(":", 1)[0] if host.count(":") == 1 else host


def _vpn_config_payload(config, request: Request | None = None) -> dict:
    """Stable, secret-safe representation used by all VPN config responses."""
    # Older admin builds used this as a placeholder. Never surface it as a
    # real destination after the UI has been upgraded.
    configured_host = config.gateway_host if config.gateway_host not in ("radius.example.local", "") else None
    listener_host = configured_host or settings.RADIUS_LISTENER_HOST or _request_host(request)
    listener_port = config.gateway_port or settings.RADIUS_LISTENER_PORT
    return {
        "id": str(config.id),
        "customer_id": str(config.customer_id),
        "is_enabled": bool(config.is_enabled),
        "gateway_host": configured_host,
        "gateway_port": config.gateway_port,
        "radius_listener_host": listener_host,
        "radius_listener_port": listener_port,
        "radius_service": {
            "mode": "embedded",
            "service_name": settings.RADIUS_INTERNAL_HOST,
            "auth_port": settings.RADIUS_INTERNAL_PORT,
            "accounting_port": settings.RADIUS_LISTENER_ACCOUNTING_PORT,
        },
        "radius_nas_ip": config.radius_nas_ip,
        "radius_accounting_port": config.radius_accounting_port,
        "radius_secret_configured": bool(config.radius_shared_secret_encrypted),
        "radius_secret_updated_at": config.radius_secret_updated_at.isoformat() if config.radius_secret_updated_at else None,
        "allowed_groups": config.allowed_groups or [],
        "mfa_method": config.mfa_method,
        "sms_template": config.sms_template or "VPN giriş doğrulama kodunuz: {code}",
    }


# ---- Endpoints --------------------------------------------------------------

@router.get("/config", summary="Get compatibility MFA settings for the admin UI")
async def get_compat_mfa_config(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Return a stable user-level config shape for older admin clients.

    Customer-scoped RDP/portal settings remain available under their
    dedicated routes below. This endpoint prevents the legacy /mfa/config
    client call from being interpreted as DELETE /mfa/{method} (405).
    """
    current = await mfa_service.get_mfa_status(db, user.id)
    methods = current.get("methods", [])
    return {
        "default_method": methods[0] if methods else "totp",
        "enforce_for_admins": bool(current.get("mfa_required")),
        "enforce_for_portal": False,
        "backup_codes": [],
        "backup_codes_remaining": current.get("backup_codes_remaining", 0),
        "rdp_mfa_enabled": False,
        "vpn_mfa_enabled": False,
        "portal_mfa_enabled": False,
    }


@router.put("/config", summary="Update compatibility MFA settings for the admin UI")
async def update_compat_mfa_config(
    body: dict,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not has_permission(user.role, "system.write"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")
    if "enforce_for_admins" in body:
        user.mfa_required = bool(body["enforce_for_admins"])
        await db.commit()
    return body


@router.post("/regenerate-backup-codes", summary="Regenerate backup codes for the current user")
async def regenerate_backup_codes(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return {"codes": await mfa_service.generate_backup_codes(db, user.id)}

@router.get("/status", response_model=MfaStatusOut, summary="Get MFA status and configured methods for the current user", description="Returns the MFA configuration status including which methods are enabled, active tokens, and remaining backup codes. Requires a valid access token.")
async def mfa_status(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await mfa_service.get_mfa_status(db, user.id)


@router.post("/setup/totp", response_model=TotpSetupOut, summary="Set up TOTP authentication for the current user", description="Initializes TOTP setup by generating a secret, QR code URI, and backup codes. The user must scan the QR code with an authenticator app and verify with a code to activate. Requires a valid access token.")
async def setup_totp(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await mfa_service.setup_totp(db, user.id, request)


@router.post("/verify/totp", summary="Verify and activate TOTP with an authenticator code", description="Completes TOTP setup by verifying a code generated from the user's authenticator app. On success, TOTP is activated for the user's account. Requires a valid access token.")
async def verify_totp(
    body: TotpVerifyIn,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    ok = await mfa_service.activate_totp(db, user.id, body.code)
    return {"verified": ok}


@router.post("/send-code", response_model=MfaCodeSendOut, summary="Send an MFA verification code via SMS, email, or WhatsApp", description="Sends a one-time verification code to the user using the specified delivery method. Returns a session token for subsequent verification. Requires a valid access token.")
async def send_code(
    body: MfaCodeSendIn,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    session_token = await mfa_service.send_mfa_code(db, user.id, body.method, request)
    return MfaCodeSendOut(
        session_token=session_token,
        ttl_seconds=settings.MFA_CODE_TTL_SECONDS,
    )


@router.post("/verify-code", summary="Verify an MFA code sent via SMS, email, or WhatsApp", description="Validates a one-time code against the provided session token. Used to complete MFA verification for a login or sensitive action. Requires a valid access token.")
async def verify_code(
    body: MfaCodeVerifyIn,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    ok = await mfa_service.verify_mfa_code(db, body.session_token, body.code, request)
    return {"verified": ok}


@router.post("/verify-backup", summary="Verify a backup code for MFA recovery", description="Validates a backup code for the user. Backup codes are generated during TOTP setup and can be used when the primary MFA method is unavailable. Each backup code can only be used once. Requires a valid access token.")
async def verify_backup(
    body: BackupCodeVerifyIn,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    ok = await mfa_service.verify_backup_code(db, user.id, body.code, request)
    return {"verified": ok}


@router.delete("/{method}", status_code=204, summary="Disable a specific MFA method for the current user", description="Disables the specified MFA method (totp, sms, email, or whatsapp) for the authenticated user. Returns 204 No Content on success. Requires a valid access token.")
async def disable_mfa(
    method: str,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if method not in ("totp", "sms", "email", "whatsapp"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Gecersiz MFA yontemi: {method}",
        )
    await mfa_service.disable_mfa(db, user.id, method, request)


# ---- RDP MFA config ---------------------------------------------------------
@router.get("/rdp/config", summary="Get RDP MFA configuration for the customer", description="Returns the RDP gateway MFA configuration for the authenticated user's customer. Includes gateway host, port, allowed groups, and MFA method. Requires the mfa.rdp.read permission.")
async def get_rdp_config(
    user: User = Depends(require_permission("mfa.rdp.read")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await rdp_service.get_config(db, cid)
    if not config:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="RDP MFA yapilandirmasi bulunamadi")
    return config


@router.put("/rdp/config", summary="Update RDP MFA configuration for the customer", description="Creates or updates the RDP gateway MFA configuration. Supports settings for gateway host, port, allowed groups, and MFA method. Requires the mfa.rdp.write permission.")
async def update_rdp_config(
    body: RdpConfigIn,
    user: User = Depends(require_permission("mfa.rdp.write")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await rdp_service.get_config(db, cid)
    if config:
        return await rdp_service.update_config(db, cid, **body.model_dump())
    return await rdp_service.create_config(db, cid, **body.model_dump())


# ---- VPN MFA config ---------------------------------------------------------
@router.get("/vpn/config", summary="Get VPN MFA configuration for the customer", description="Returns the VPN MFA configuration and the bundled Hotspot RADIUS listener details. Requires the mfa.vpn.read permission.")
async def get_vpn_config(
    request: Request,
    user: User = Depends(require_permission("mfa.vpn.read")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await vpn_service.get_config(db, cid)
    if not config:
        # An unconfigured installation is a valid initial state. Returning a
        # stable, secret-safe payload lets the UI render the setup form without
        # treating the first visit as an application error.
        return {
            "id": None,
            "customer_id": str(cid),
            "is_enabled": False,
            "gateway_host": None,
            "gateway_port": settings.RADIUS_LISTENER_PORT,
            "radius_listener_host": settings.RADIUS_LISTENER_HOST or _request_host(request),
            "radius_listener_port": settings.RADIUS_LISTENER_PORT,
            "radius_service": {
                "mode": "embedded",
                "service_name": settings.RADIUS_INTERNAL_HOST,
                "auth_port": settings.RADIUS_INTERNAL_PORT,
                "accounting_port": settings.RADIUS_LISTENER_ACCOUNTING_PORT,
            },
            "radius_nas_ip": None,
            "radius_accounting_port": settings.RADIUS_LISTENER_ACCOUNTING_PORT,
            "radius_secret_configured": False,
            "radius_secret_updated_at": None,
            "allowed_groups": [],
            "mfa_method": "totp",
            "sms_template": "VPN giriş doğrulama kodunuz: {code}",
        }
    return _vpn_config_payload(config, request)


@router.put("/vpn/config", summary="Update VPN MFA configuration for the customer", description="Creates or updates VPN MFA and the FortiGate client settings. The RADIUS server itself is bundled with Hotspot; customers do not install FreeRADIUS. Requires the mfa.vpn.write permission.")
async def update_vpn_config(
    body: VpnConfigIn,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await vpn_service.get_config(db, cid)
    updates = body.model_dump()
    # New clients use the explicit listener names; old clients can continue
    # sending gateway_host/gateway_port without a migration.
    if body.radius_listener_host is not None:
        updates["gateway_host"] = body.radius_listener_host
    if body.radius_listener_port is not None:
        updates["gateway_port"] = body.radius_listener_port
    updates.pop("radius_listener_host", None)
    updates.pop("radius_listener_port", None)
    if config:
        updated = await vpn_service.update_config(db, cid, **updates)
        # The request-scoped AsyncSession is not auto-committed. Persist the
        # FortiGate/RADIUS settings before returning so a page refresh (and the
        # captive portal flow) sees the same configuration.
        await db.commit()
        from app.modules.radius.runtime import sync_runtime_clients
        await sync_runtime_clients(db)
        return _vpn_config_payload(updated)
    created = await vpn_service.create_config(db, cid, **updates)
    await db.commit()
    from app.modules.radius.runtime import sync_runtime_clients
    await sync_runtime_clients(db)
    return _vpn_config_payload(created)


@router.post("/vpn/test-radius", summary="Test the configured FreeRADIUS listener used by FortiGate")
async def test_vpn_radius(
    request: Request,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    """Test the saved listener; no caller-supplied destination is accepted."""
    from app.core.crypto import decrypt
    from app.modules.radius.service import test_radius_connection

    cid = await _customer_for_mfa(db, user)
    config = await vpn_service.get_config(db, cid)
    if not config or not config.radius_shared_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Önce FortiGate NAS IP ve shared secret kaydedin")
    try:
        secret = decrypt(config.radius_shared_secret_encrypted)
    except Exception:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="RADIUS shared secret çözülemedi")
    # The listener is bundled with this installation. Test it over the
    # internal Docker network; the public host/port is only for FortiGate.
    internal_host = settings.RADIUS_INTERNAL_HOST
    internal_port = settings.RADIUS_INTERNAL_PORT
    ok = await test_radius_connection(internal_host, secret, port=internal_port)
    return {
        "ok": bool(ok),
        "message": "Dahili RADIUS yanıt verdi." if ok else "Dahili RADIUS yanıt vermedi; servis ve shared secret'ı kontrol edin.",
        "host": settings.RADIUS_LISTENER_HOST or _request_host(request),
        "port": config.gateway_port or settings.RADIUS_LISTENER_PORT,
        "service": internal_host,
    }


# ---- VPN MFA per-user registration ------------------------------------------

@router.get("/vpn/users", response_model=list[VpnMfaUserOut], summary="List VPN MFA registered users for the customer", description="Returns all active VPN MFA users registered for the authenticated user's customer. Includes username, MFA method, and contact information. Requires the mfa.vpn.read permission.")
async def list_vpn_mfa_users(
    user: User = Depends(require_permission("mfa.vpn.read")),
    db: AsyncSession = Depends(get_db),
):
    from app.modules.mfa.models import VpnMfaUser

    cid = await _customer_for_mfa(db, user)
    rows = (await db.execute(
        select(VpnMfaUser).where(
            VpnMfaUser.customer_id == cid,
            VpnMfaUser.is_active.is_(True),
        ).order_by(VpnMfaUser.username)
    )).scalars().all()
    return [
        VpnMfaUserOut(
            id=str(r.id),
            username=r.username,
            mfa_method=r.mfa_method,
            phone=r.phone,
            email=r.email,
            is_active=r.is_active,
        )
        for r in rows
    ]


@router.post("/vpn/users", response_model=VpnMfaUserOut, status_code=status.HTTP_201_CREATED, summary="Register a new VPN MFA user", description="Creates a new VPN MFA user registration with the specified username, MFA method, and optional contact details. The user's secret is encrypted before storage. Requires the mfa.vpn.write permission.")
async def create_vpn_mfa_user(
    body: VpnMfaUserCreateIn,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    from app.modules.mfa.models import VpnMfaUser
    from app.core.crypto import encrypt

    cid = await _customer_for_mfa(db, user)
    clean_username = body.username.strip()
    existing = (await db.execute(
        select(VpnMfaUser).where(
            VpnMfaUser.customer_id == cid,
            func.lower(VpnMfaUser.username) == clean_username.lower(),
        )
    )).scalar_one_or_none()
    if existing and existing.is_active is not False:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Bu kullanici zaten kayitli")
    setup_secret = None
    if "totp" in body.mfa_method.lower():
        if body.secret:
            setup_secret = body.secret.strip().replace(" ", "").upper()
        else:
            import pyotp
            setup_secret = pyotp.random_base32()
    try:
        encrypted_secret = encrypt(setup_secret) if setup_secret else None
    except Exception:
        log.exception("VPN MFA secret encryption failed for customer %s", cid)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="MFA gizli anahtarı güvenli biçimde saklanamadı; sunucu crypto ayarlarını kontrol edin",
        ) from None

    if existing:
        # A previous manual/local-user deletion leaves the MFA row as a
        # recoverable inactive record. Reactivate it instead of returning a
        # duplicate error, while replacing the secret and contact metadata.
        record = existing
        record.username = clean_username
        record.mfa_method = body.mfa_method
        record.secret_encrypted = encrypted_secret
        record.phone = body.phone
        record.email = body.email
        record.is_active = True
    else:
        record = VpnMfaUser(
            customer_id=cid,
            username=clean_username,
            mfa_method=body.mfa_method,
            secret_encrypted=encrypted_secret,
            phone=body.phone,
            email=body.email,
        )
        db.add(record)
    if body.password and body.password.strip():
        from app.modules.local_auth.models import LocalUser
        from app.core.security import hash_password
        local_u = (await db.execute(
            select(LocalUser).where(
                LocalUser.customer_id == cid,
                func.lower(LocalUser.username) == clean_username.lower(),
            )
        )).scalar_one_or_none()
        if local_u:
            local_u.password_hash = hash_password(body.password.strip())
            local_u.is_active = True
            local_u.username = clean_username
            if body.email:
                local_u.email = body.email
            if body.phone:
                local_u.phone = body.phone
        else:
            local_u = LocalUser(
                customer_id=cid,
                username=clean_username,
                password_hash=hash_password(body.password.strip()),
                display_name=clean_username,
                email=body.email,
                phone=body.phone,
                is_active=True,
            )
            db.add(local_u)

    await db.flush()
    await db.refresh(record)
    await db.commit()

    qr_uri = _totp_uri(record.username, setup_secret) if setup_secret else None
    if "totp" in (record.mfa_method or "").lower() and record.email and setup_secret and qr_uri:
        await _send_vpn_totp_email(record.username, record.email, setup_secret, qr_uri, cid, db)

    return VpnMfaUserOut(
        id=str(record.id),
        username=record.username,
        mfa_method=record.mfa_method,
        phone=record.phone,
        email=record.email,
        is_active=record.is_active,
        qr_code_uri=qr_uri,
        qr_code_svg=_totp_qr_svg(qr_uri) if qr_uri else None,
        totp_secret=setup_secret,
    )


async def _send_vpn_totp_email(
    username: str,
    email: str,
    secret: str,
    uri: str,
    customer_id: uuid.UUID | None,
    db: AsyncSession,
) -> bool:
    if not email or not email.strip():
        return False
    try:
        import qrcode
        import io
        from app.modules.system.email_service import send_email

        # Generate QR code PNG locally in-memory
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=8,
            border=2,
        )
        qr.add_data(uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#0f172a", back_color="#ffffff")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        qr_png_bytes = buf.getvalue()

        now_str = datetime.now(timezone.utc).strftime("%d.%m.%Y %H:%M:%S UTC")

        html_body = f"""<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>VPN İki Adımlı Doğrulama Kurulumu</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color: #f1f5f9; padding: 40px 15px;">
    <tr>
      <td align="center">
        <!-- Main White Card -->
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width: 540px; background-color: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); overflow: hidden;">
          
          <!-- Header -->
          <tr>
            <td style="padding: 24px 32px 18px 32px; background-color: #ffffff; border-bottom: 1px solid #f1f5f9;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                  <td>
                    <div style="display: inline-block; background: #2563eb; border-radius: 6px; padding: 6px 12px; vertical-align: middle;">
                      <span style="color: #ffffff; font-weight: 800; font-size: 14px; letter-spacing: 1px;">🛡️ NEOSECRA</span>
                    </div>
                    <span style="color: #64748b; font-size: 13px; font-weight: 600; margin-left: 10px; vertical-align: middle;">VPN 2FA Kurulumu</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Content -->
          <tr>
            <td style="padding: 32px 32px 24px 32px;">
              <h1 style="color: #0f172a; font-size: 20px; font-weight: 700; margin: 0 0 10px 0; line-height: 1.3;">VPN İki Adımlı Doğrulama (TOTP)</h1>
              <p style="color: #475569; font-size: 14px; line-height: 1.6; margin: 0 0 20px 0;">
                Merhaba <strong>{username}</strong>,<br>
                Kurumunuzun güvenli SSL-VPN ağına erişebilmeniz için iki faktörlü kimlik doğrulama profiliniz hazırlandı.
              </p>

              <!-- Step 1 Card: QR Code -->
              <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; text-align: center; margin-bottom: 20px;">
                <p style="color: #0f172a; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 14px 0;">
                  📱 1. Adım: QR Kodu Authenticator ile Okutun
                </p>
                <div style="display: inline-block; padding: 10px; background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);">
                  <img src="cid:vpn_totp_qr" alt="Google/Microsoft Authenticator QR Kodu" width="200" height="200" style="display: block; margin: 0 auto; border-radius: 4px;" />
                </div>
                <p style="color: #64748b; font-size: 12px; margin: 14px 0 0 0; line-height: 1.4;">
                  Google Authenticator veya Microsoft Authenticator uygulamasını açıp <strong>"+"</strong> butonuna basarak bu QR kodu okutun.
                </p>
              </div>

              <!-- Manual Secret Key -->
              <div style="background: #f1f5f9; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; margin-bottom: 20px;">
                <p style="color: #64748b; font-size: 12px; margin: 0 0 6px 0; font-weight: 600;">
                  🔑 QR Kodu okutamıyorsanız el ile girilecek Gizli Anahtar:
                </p>
                <div style="font-family: 'SF Mono', 'Courier New', Courier, monospace; font-size: 15px; font-weight: 700; background: #ffffff; color: #1e293b; padding: 8px 12px; border-radius: 6px; letter-spacing: 2px; border: 1px dashed #94a3b8; word-break: break-all; text-align: center;">
                  {secret}
                </div>
              </div>

              <!-- Step 2: How to Login -->
              <div style="background: #eff6ff; border-left: 4px solid #3b82f6; border-radius: 0 8px 8px 0; padding: 14px 16px; margin-bottom: 20px;">
                <p style="color: #1d4ed8; font-size: 13px; font-weight: 700; margin: 0 0 4px 0;">
                  🚀 2. Adım: VPN'e Nasıl Bağlanacaksınız?
                </p>
                <p style="color: #334155; font-size: 12px; margin: 0; line-height: 1.6;">
                  1. FortiClient / SSL-VPN uygulamasında kullanıcı adı ve şifrenizi girin.<br>
                  2. Açılan doğrulama penceresine telefonunuzdaki Authenticator uygulamasının ürettiği <strong>6 haneli kodu</strong> yazın.
                </p>
              </div>

              <!-- Metadata -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-top: 1px solid #f1f5f9; padding-top: 12px;">
                <tr>
                  <td style="color: #94a3b8; font-size: 11px;">
                    Hesap: <strong style="color: #64748b;">{username}</strong>
                  </td>
                  <td align="right" style="color: #94a3b8; font-size: 11px;">
                    Tarih: <strong style="color: #64748b;">{now_str}</strong>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding: 16px 32px; background-color: #f8fafc; border-top: 1px solid #f1f5f9; text-align: center;">
              <p style="color: #94a3b8; font-size: 11px; margin: 0 0 3px 0;">
                © 2026 NeoSecra. Tüm hakları saklıdır.
              </p>
              <p style="color: #cbd5e1; font-size: 10px; margin: 0;">
                Bu e-posta güvenlik gereği otomatik olarak üretilmiştir.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>"""

        return await send_email(
            to=email.strip(),
            subject="🔐 NeoSecra VPN - Google/Microsoft Authenticator Kurulum Kodu",
            html_body=html_body,
            customer_id=customer_id,
            db=db,
            inline_images={"vpn_totp_qr": qr_png_bytes},
        )
    except Exception as exc:
        log.warning("VPN TOTP email gonderilemedi: %s", exc)
        return False


@router.post("/vpn/users/{user_id}/totp-setup", response_model=VpnMfaUserOut, summary="Generate a new TOTP QR setup for a VPN user")
async def setup_vpn_totp(
    user_id: uuid.UUID,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    """Rotate a VPN user's TOTP secret and return the QR URI once."""
    from app.core.crypto import encrypt
    from app.modules.mfa.models import VpnMfaUser
    import pyotp

    cid = await _customer_for_mfa(db, user)
    record = (
        await db.execute(
            select(VpnMfaUser).where(
                VpnMfaUser.id == user_id,
                VpnMfaUser.customer_id == cid,
                VpnMfaUser.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kullanici bulunamadi")
    if "totp" not in (record.mfa_method or "").lower():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Bu kullanici TOTP kullanmiyor")
    secret = pyotp.random_base32()
    try:
        record.secret_encrypted = encrypt(secret)
    except Exception:
        log.exception("VPN TOTP secret rotation failed for user %s", record.id)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="TOTP gizli anahtarı güvenli biçimde saklanamadı; sunucu crypto ayarlarını kontrol edin",
        ) from None
    await db.commit()

    uri = _totp_uri(record.username, secret)
    if record.email:
        await _send_vpn_totp_email(record.username, record.email, secret, uri, cid, db)

    return VpnMfaUserOut(
        id=str(record.id), username=record.username, mfa_method=record.mfa_method,
        phone=record.phone, email=record.email, is_active=record.is_active,
        qr_code_uri=uri, totp_secret=secret,
        qr_code_svg=_totp_qr_svg(uri),
    )


@router.post("/vpn/users/{user_id}/send-email", summary="Send or resend TOTP QR setup email to user")
async def send_vpn_user_email(
    user_id: uuid.UUID,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    from app.core.crypto import decrypt
    from app.modules.mfa.models import VpnMfaUser
    cid = await _customer_for_mfa(db, user)
    record = (
        await db.execute(
            select(VpnMfaUser).where(
                VpnMfaUser.id == user_id,
                VpnMfaUser.customer_id == cid,
            )
        )
    ).scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kullanici bulunamadi")
    if not record.email:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Kullanicinin kayitli bir e-posta adresi bulunmuyor")

    try:
        secret = decrypt(record.secret_encrypted) if record.secret_encrypted else ""
    except Exception:
        log.exception("VPN TOTP secret decrypt failed for user %s", record.id)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="TOTP gizli anahtarı okunamadı; sunucu crypto ayarlarını kontrol edin",
        ) from None
    if not secret:
        import pyotp
        from app.core.crypto import encrypt
        secret = pyotp.random_base32()
        try:
            record.secret_encrypted = encrypt(secret)
        except Exception:
            log.exception("VPN TOTP secret creation failed for user %s", record.id)
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="TOTP gizli anahtarı güvenli biçimde saklanamadı; sunucu crypto ayarlarını kontrol edin",
            ) from None
        await db.commit()

    uri = _totp_uri(record.username, secret)
    sent = await _send_vpn_totp_email(record.username, record.email, secret, uri, cid, db)
    if not sent:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="E-posta gonderilemedi. Lutfen SMTP ayarlarini kontrol edin.")
    return {"success": True, "message": f"Kurulum e-postasi {record.email} adresine basariyla gonderildi"}


@router.delete("/vpn/users/{user_id}", status_code=204, summary="Deactivate a VPN MFA user registration", description="Deletes the specified VPN MFA user registration. Requires the mfa.vpn.write permission.")
async def delete_vpn_mfa_user(
    user_id: uuid.UUID,
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    from app.modules.mfa.models import VpnMfaUser

    cid = await _customer_for_mfa(db, user)
    record = (
        await db.execute(
            select(VpnMfaUser).where(
                VpnMfaUser.id == user_id,
                VpnMfaUser.customer_id == cid,
                VpnMfaUser.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kullanici bulunamadi")
    # Keep the registration row so a re-registration can safely reactivate it
    # and so historical challenge references remain auditable.
    record.is_active = False
    await db.commit()


@router.get("/vpn/otp-logs", summary="Get recent VPN MFA OTP challenge logs")
async def get_vpn_otp_logs(
    user: User = Depends(require_permission("mfa.vpn.read")),
    db: AsyncSession = Depends(get_db),
    limit: int = 50,
):
    from app.modules.radius.models import RadiusChallenge
    cid = await _customer_for_mfa(db, user)
    q = (
        select(RadiusChallenge)
        .where(RadiusChallenge.customer_id == cid)
        .order_by(RadiusChallenge.created_at.desc())
        .limit(limit)
    )
    records = (await db.execute(q)).scalars().all()
    now = datetime.now(timezone.utc)
    return [
        {
            "id": str(r.id),
            "username": r.username,
            "mfa_method": r.mfa_method,
            # OTP plaintext is intentionally never persisted or returned. Keep
            # the legacy field name for older admin builds, but expose only a
            # method-safe placeholder.
            "otp_code": "TOTP" if "totp" in (r.mfa_method or "").lower() else "—",
            "nas_ip": r.nas_ip,
            "verified": r.verified,
            "is_expired": r.expires_at < now,
            "expires_at": r.expires_at.isoformat() if r.expires_at else None,
            "consumed_at": r.consumed_at.isoformat() if r.consumed_at else None,
            "created_at": r.created_at.isoformat() if r.created_at else None,
            "attempt_count": r.attempt_count,
        }
        for r in records
    ]


@router.post("/vpn/generate-config", summary="Generate FreeRADIUS config snippet for VPN MFA", description="Generates a FreeRADIUS configuration snippet for VPN MFA integration based on the customer's current VPN MFA settings. The output is ready to be included in FreeRADIUS configuration files. Requires the mfa.vpn.write permission.")
async def generate_vpn_mfa_config(
    user: User = Depends(require_permission("mfa.vpn.write")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await vpn_service.get_config(db, cid)
    if not config:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="VPN MFA yapilandirmasi bulunamadi")
    try:
        snippet = vpn_service.generate_radius_config_for_vpn_mfa(config)
    except RuntimeError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc
    return {"config": snippet, "customer_id": str(cid)}


# ---- Portal MFA config ------------------------------------------------------
@router.get("/portal/config", summary="Get portal MFA configuration for the customer", description="Returns the captive portal MFA configuration for the authenticated user's customer. Includes enabled status, MFA method, and conditional MFA rules. Requires the mfa.portal.read permission.")
async def get_portal_config(
    user: User = Depends(require_permission("mfa.portal.read")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await portal_service.get_portal_config(db, cid)
    if not config:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Portal MFA yapilandirmasi bulunamadi")
    return config


@router.put("/portal/config", summary="Update portal MFA configuration for the customer", description="Creates or updates the captive portal MFA configuration. Supports settings for MFA method and conditional MFA rules. Requires the mfa.portal.write permission.")
async def update_portal_config(
    body: PortalConfigIn,
    user: User = Depends(require_permission("mfa.portal.write")),
    db: AsyncSession = Depends(get_db),
):
    cid = await _customer_for_mfa(db, user)
    config = await portal_service.get_portal_config(db, cid)
    if config:
        return await portal_service.update_portal_config(db, config.id, **body.model_dump())
    return await portal_service.create_portal_config(db, cid, **body.model_dump())
