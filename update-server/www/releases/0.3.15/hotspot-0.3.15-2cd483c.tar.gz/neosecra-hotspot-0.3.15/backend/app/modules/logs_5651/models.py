"""5651 log archive — APPEND-ONLY + hash chain (Mutlak Kural #4).

These rows are NEVER updated or deleted. Each ArchiveRecord is a sealed, hashed
snapshot of a period's guest-session/auth events:

  content_hash  = sha256 of the canonical serialized payload (the archive bytes)
  prev_hash     = curr_hash of the immediately preceding record in the chain
                  (GENESIS_HASH for the first record)
  curr_hash     = sha256(prev_hash | content_hash | period_key | record_type)
  chain_seq     = monotonic counter within (customer_id, record_type)

The chain is per (customer, record_type) so each customer/type has its own
tamper-evident ledger. verify_chain() re-walks it to detect tampering.

This is the 5651 "değiştirilemez arşiv" (immutable archive): KVKK/5651 requires
that traffic/identity records cannot be altered after the fact; the hash chain
makes any retroactive edit mathematically detectable (Kural #4 — append-only
event approach, hash never updated).

Digital signature fields (signature_value, signature_time, certificate_serial,
sign_method) are set after archive creation by the KamuSM signing pipeline.
They are NULL until signed — the archive is legally valid without a digital
signature, but signing adds TUBITAK-level non-repudiation.
"""
import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk

GENESIS_HASH = "0" * 64

RECORD_SESSION_ARCHIVE = "session_archive"
RECORD_AUTH_EVENT = "auth_event"
RECORD_RAW_TRAFFIC = "raw_traffic"
RECORD_RAW_SYSLOG = "raw_syslog"
RECORD_RAW_RADIUS = "raw_radius"
RECORD_TYPES = (
    RECORD_SESSION_ARCHIVE,
    RECORD_AUTH_EVENT,
    RECORD_RAW_TRAFFIC,
    RECORD_RAW_SYSLOG,
    RECORD_RAW_RADIUS,
)

SIGN_METHOD_KAMUSM = "kamusm"
SIGN_METHOD_LOCALFILE = "localfile"
SIGN_METHOD_PKCS11 = "pkcs11"
SIGN_METHODS = (SIGN_METHOD_KAMUSM, SIGN_METHOD_LOCALFILE, SIGN_METHOD_PKCS11)

ARCHIVE_STATUS_PENDING = "pending"
ARCHIVE_STATUS_READY = "ready"
ARCHIVE_STATUS_FAILED = "failed"
ARCHIVE_STATUSES = (ARCHIVE_STATUS_PENDING, ARCHIVE_STATUS_READY, ARCHIVE_STATUS_FAILED)

EVIDENCE_STATUS_PENDING = "pending"
EVIDENCE_STATUS_RUNNING = "running"
EVIDENCE_STATUS_READY = "ready"
EVIDENCE_STATUS_FAILED = "failed"
EVIDENCE_STATUSES = (
    EVIDENCE_STATUS_PENDING,
    EVIDENCE_STATUS_RUNNING,
    EVIDENCE_STATUS_READY,
    EVIDENCE_STATUS_FAILED,
)


class ArchiveRecord(Base, UUIDPK, TimestampMixin):
    """One sealed, hashed archive of a period's events. Append-only."""

    __tablename__ = "archive_records_5651"

    # RESTRICT: a customer cannot be deleted while archive rows exist (Kural #4).
    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    period_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    period_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    record_type: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    chain_seq: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    item_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    # sha256 hex of the archive payload bytes.
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    # Object-store key / path where the payload lives (archive_service.upload).
    content_ref: Mapped[str] = mapped_column(String(500), nullable=False)
    content_size: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    prev_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    curr_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    meta: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

    # ---- digital signature (TUBITAK KamuSM / local cert) ----------------------
    signature_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    signature_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    certificate_serial: Mapped[str | None] = mapped_column(String(100), nullable=True)
    sign_method: Mapped[str | None] = mapped_column(String(20), nullable=True)
    # A record is only legally publishable when storage and signature checks
    # both completed.  Failed records remain append-only evidence of the
    # attempted build and are never exposed as success-ready.
    status: Mapped[str] = mapped_column(
        String(20), default=ARCHIVE_STATUS_PENDING, nullable=False, index=True
    )
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    storage_verified: Mapped[bool] = mapped_column(default=False, nullable=False)
    signature_valid: Mapped[bool] = mapped_column(default=False, nullable=False)


class ArchiveIndex(Base, UUIDPK, TimestampMixin):
    """Quick-search index for archived syslog data.

    Each row represents one daily .zst archive file in MinIO.
    PostgreSQL'de sadece katalog bilgisi tutulur; veri MinIO'da.
    Silinemez/değiştirilemez (Mutlak Kural #4).
    """

    __tablename__ = "archive_index"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    period_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    period_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    record_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    file_ref: Mapped[str] = mapped_column(String(500), nullable=False)
    file_size: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    compression: Mapped[str] = mapped_column(String(10), default="zstd", nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    prev_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    signature_value: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Hızlı arama için metadata indeksi
    searchable_fields: Mapped[dict | None] = mapped_column(JSONB, nullable=True,
        comment="{'ips': [...], 'macs': [...], 'users': [...], 'domains': [...], 'devices': [...]}")


class EvidenceExport(Base, UUIDPK, TimestampMixin):
    """Durable court-evidence export job and immutable package envelope."""

    __tablename__ = "evidence_exports"

    session_id: Mapped[uuid.UUID] = fk("guest_sessions", ondelete="CASCADE")
    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    tenant_id: Mapped[uuid.UUID] = fk("tenants", ondelete="RESTRICT")
    status: Mapped[str] = mapped_column(
        String(20), default=EVIDENCE_STATUS_PENDING, nullable=False, index=True
    )
    package_ref: Mapped[str | None] = mapped_column(String(500), nullable=True)
    file_size: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), default="", nullable=False, index=True)
    schema_version: Mapped[str] = mapped_column(String(20), default="1.0", nullable=False)
    sha256_hash: Mapped[str] = mapped_column(String(64), default="", nullable=False, index=True)
    provenance: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    envelope: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)


class EvidenceExportStatusHistory(Base, UUIDPK, TimestampMixin):
    """Append-only status transitions for evidence export jobs."""

    __tablename__ = "evidence_export_status_history"

    export_id: Mapped[uuid.UUID] = fk("evidence_exports", ondelete="CASCADE")
    session_id: Mapped[uuid.UUID] = fk("guest_sessions", ondelete="CASCADE")
    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    tenant_id: Mapped[uuid.UUID] = fk("tenants", ondelete="RESTRICT")
    status: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    attempt: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    details: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
