"""VPN MFA integration: FreeRADIUS config generation for VPN MFA
enforcement."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.mfa.models import VpnMfaConfig
from app.core.crypto import encrypt, decrypt


async def create_config(
    db: AsyncSession,
    customer_id: uuid.UUID,
    *,
    is_enabled: bool = True,
    gateway_host: str | None = None,
    gateway_port: int = 1812,
    radius_nas_ip: str | None = None,
    radius_accounting_port: int = 1813,
    radius_shared_secret: str | None = None,
    allowed_groups: list | None = None,
    mfa_method: str = "totp",
    sms_template: str | None = None,
) -> VpnMfaConfig:
    existing = (
        await db.execute(
            select(VpnMfaConfig).where(VpnMfaConfig.customer_id == customer_id)
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Bu musteri icin VPN MFA yapilandirmasi zaten mevcut",
        )

    config = VpnMfaConfig(
        customer_id=customer_id,
        is_enabled=bool(is_enabled),
        gateway_host=gateway_host,
        gateway_port=gateway_port,
        radius_nas_ip=radius_nas_ip,
        radius_accounting_port=radius_accounting_port,
        radius_shared_secret_encrypted=encrypt(radius_shared_secret) if radius_shared_secret else None,
        radius_secret_updated_at=datetime.now(timezone.utc) if radius_shared_secret else None,
        allowed_groups=allowed_groups or [],
        mfa_method=mfa_method,
        sms_template=sms_template or "VPN giriş doğrulama kodunuz: {code}",
    )
    db.add(config)
    await db.flush()
    await db.refresh(config)
    return config


async def update_config(
    db: AsyncSession,
    customer_id: uuid.UUID,
    **updates: Any,
) -> VpnMfaConfig:
    config = (
        await db.execute(
            select(VpnMfaConfig).where(VpnMfaConfig.customer_id == customer_id)
        )
    ).scalar_one_or_none()
    if not config:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="VPN MFA yapilandirmasi bulunamadi",
        )

    for key in ("is_enabled", "gateway_host", "gateway_port", "radius_nas_ip", "radius_accounting_port", "allowed_groups", "mfa_method", "sms_template"):
        if key in updates:
            setattr(config, key, updates[key])
    # An omitted/empty secret means "keep existing".  This makes masked UI
    # fields safe to submit without accidentally deleting the FortiGate key.
    if updates.get("radius_shared_secret"):
        config.radius_shared_secret_encrypted = encrypt(updates["radius_shared_secret"])
        config.radius_secret_updated_at = datetime.now(timezone.utc)
    await db.flush()
    await db.refresh(config)
    return config


async def get_config(
    db: AsyncSession, customer_id: uuid.UUID
) -> VpnMfaConfig | None:
    return (
        await db.execute(
            select(VpnMfaConfig).where(VpnMfaConfig.customer_id == customer_id)
        )
    ).scalar_one_or_none()


async def delete_config(db: AsyncSession, customer_id: uuid.UUID) -> None:
    config = (
        await db.execute(
            select(VpnMfaConfig).where(VpnMfaConfig.customer_id == customer_id)
        )
    ).scalar_one_or_none()
    if config:
        await db.delete(config)
        await db.flush()


def generate_radius_config_for_vpn_mfa(config: VpnMfaConfig) -> str:
    """Generate an optional FreeRADIUS config snippet for VPN MFA.

    Requires FreeRADIUS v3.2+ with ``rest`` module enabled.
    The config uses our backend's challenge API to drive the
    Access-Challenge / Access-Accept flow.

    The bundled service is already configured by the product.  This output is
    intended only for an operator who deliberately uses an external
    FreeRADIUS deployment or needs a manual recovery/configuration artifact.

    Additionally add to /etc/freeradius/mods-enabled/rest:

        rest vpn_mfa {{
            connect_uri = "http://backend:8000/api/v1/radius/vpn/challenge"
            tls = no
        }}
    """
    groups = config.allowed_groups or []
    group_conditions = " || ".join(
        f'&LDAP-Group == "{g}"' for g in groups
    ) or "1"
    api_key = str(settings.RADIUS_API_KEY or "").strip()
    if not api_key:
        raise RuntimeError("RADIUS_API_KEY is not configured")
    if not config.radius_shared_secret_encrypted:
        raise RuntimeError("VPN MFA RADIUS shared secret is not configured")
    try:
        radius_secret = decrypt(config.radius_shared_secret_encrypted)
    except Exception as exc:
        raise RuntimeError("VPN MFA RADIUS shared secret could not be decrypted") from exc
    nas_ip = str(config.radius_nas_ip or "").strip()
    if not nas_ip:
        raise RuntimeError("VPN MFA NAS IP is not configured")

    return f"""# VPN MFA FreeRADIUS Config — Customer: {config.customer_id}
# Generated by Hotspot Platform — el ile duzenlemeyin

# FortiGate RADIUS client (shared secret is shown only when explicitly
# generating this snippet; it is encrypted in the platform database).
client fortigate_hotspot {{
    ipaddr = {nas_ip}
    secret = {radius_secret}
    shortname = fortigate-hotspot
    nas_type = other
}}

server vpn_mfa {{
    listen {{
        type = auth
        ipaddr = {config.gateway_host or "*"}
        port = {config.gateway_port}
    }}

    authorize {{
        # LDAP auth (requires ldap module configured separately)
        ldap
        if (!ok) {{
            reject
        }}

        # Only enforce MFA for allowed groups
        if ({group_conditions}) {{
            # Call backend to initiate MFA challenge
            rest vpn_mfa {{
                url = "/init"
                method = "POST"
                body = "json"
                data = '{{"customer_id":"{config.customer_id}","username":"%{{User-Name}}","nas_ip":"%{{NAS-IP-Address}}"}}'
                headers = {{{{ "X-API-Key": "{api_key}" }}}}
            }}

            if (&rest.vpn_mfa.response =~ /"challenge_required": true/) {{
                update {{
                    &control:&Auth-Type := MFA
                    &session-state:VPN-MFA-State := "%{{rest.vpn_mfa.response}}"
                    &reply:&State := "%{{rest.vpn_mfa.response[state]}}"
                    &reply:&Reply-Message := "%{{rest.vpn_mfa.response[reply_message]}}"
                }}
            }} else {{
                noop
            }}
        }}
    }}

    authenticate {{
        Auth-Type MFA {{
            # Verify MFA code via backend
            rest vpn_mfa {{
                url = "/verify"
                method = "POST"
                body = "json"
                data = '{{"state":"%{{reply:State}}","code":"%{{User-Password}}"}}'
                headers = {{{{ "X-API-Key": "{api_key}" }}}}
            }}

            if (&rest.vpn_mfa.response =~ /"verified": true/) {{
                ok
            }} else {{
                reject
            }}
        }}
    }}

    post-auth {{
        Post-Auth-Type REJECT {{
            &reply:&Reply-Message := "MFA dogrulama basarisiz"
        }}
    }}
}}

# FreeRADIUS rest module config for /etc/freeradius/mods-enabled/rest:
# rest vpn_mfa {{
#     connect_uri = "http://backend:8000/api/v1/radius/vpn/challenge"
#     tls = no
# }}
"""


async def configure_vpn_mfa(
    db: AsyncSession,
    radius_client: str,
    config: VpnMfaConfig,
) -> dict:
    """Configure VPN MFA on a RADIUS client (simulated/recorded)."""
    snippet = generate_radius_config_for_vpn_mfa(config)

    return {
        "status": "configured",
        "radius_client": radius_client,
        "mfa_method": config.mfa_method,
        "config_snippet": snippet,
        "message": "Dahili FreeRADIUS servisi ürünle birlikte çalışır. Bu metin yalnızca harici/ileri düzey kurulum içindir.",
    }
