"""Schemas for system management surfaces."""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

UpdateReleaseType = Literal["feature", "fix", "security", "hotfix", "maintenance"]
UpdateChannel = Literal["stable", "beta", "hotfix"]
UpdateStatus = Literal["draft", "published", "archived"]


class SystemUpdateUpsertIn(BaseModel):
    slug: str | None = Field(default=None, max_length=120)
    version: str = Field(..., min_length=1, max_length=50)
    title: str = Field(..., min_length=2, max_length=255)
    summary: str | None = Field(default=None, max_length=500)
    body: str = Field(..., min_length=5)
    release_type: UpdateReleaseType = "feature"
    channel: UpdateChannel = "stable"
    minimum_version: str | None = Field(default=None, max_length=50)
    is_mandatory: bool = False
    upgrade_steps: list[str] = Field(default_factory=list)
    artifact_name: str | None = Field(default=None, max_length=255)
    artifact_url: str | None = Field(default=None, max_length=500)
    checksum: str | None = Field(default=None, max_length=64)
    file_size_kb: int | None = Field(default=None, ge=0)
    sort_order: int = 100
    meta: dict = Field(default_factory=dict)


class SystemUpdateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    section: str
    slug: str
    version: str
    title: str
    category: str | None = None
    summary: str | None = None
    body: str
    asset_url: str | None = None
    checksum: str | None = None
    file_size_kb: int | None = None
    is_current: bool = True
    sort_order: int = 0
    meta: dict = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime
    release_type: UpdateReleaseType = "feature"
    channel: UpdateChannel = "stable"
    status: UpdateStatus = "draft"
    minimum_version: str | None = None
    is_mandatory: bool = False
    upgrade_steps: list[str] = Field(default_factory=list)
    artifact_name: str | None = None
    artifact_ref: str | None = None
    artifact_generated_at: datetime | None = None
    artifact_size_bytes: int | None = None
    distribution_status: str | None = None
    distribution_manifest_ref: str | None = None
    distribution_manifest_generated_at: datetime | None = None
    distribution_activation_ref: str | None = None
    distribution_activated_at: datetime | None = None
    distribution_activated_by: str | None = None
    distribution_targets: list[str] = Field(default_factory=list)
    published_by: str | None = None
    published_at: datetime | None = None
    archived_by: str | None = None
    archived_at: datetime | None = None


class SystemUpdateSnapshotOut(BaseModel):
    current_version: str
    latest_release_version: str | None = None
    latest_published_version: str | None = None
    upgrade_available: bool = False
    release_count: int
    draft_count: int
    archived_count: int = 0
    distribution_status_counts: dict[str, int] = Field(default_factory=dict)
    channel_counts: dict[str, int] = Field(default_factory=dict)
    latest_distribution_manifest_at: datetime | None = None
    latest_distribution_activation_at: datetime | None = None
    highlights: list[str] = Field(default_factory=list)
    featured_release: SystemUpdateOut | None = None
    releases: list[SystemUpdateOut] = Field(default_factory=list)
    stored_artifacts: list[SystemUpdateOut] = Field(default_factory=list)


# ---- Unified NeoSecra Settings Information Architecture Schemas ----

class GeneralSettingsIn(BaseModel):
    org_name: str | None = Field(None, max_length=255)
    site_name: str | None = Field(None, max_length=255)
    timezone: str | None = Field(None, max_length=100)
    locale: str | None = Field(None, max_length=20)
    session_timeout_minutes: int | None = Field(None, ge=5, le=1440)
    two_fa_enforced: bool | None = None
    ip_allowlist: list[str] | None = None
    version_tag: int | None = Field(None, ge=1)  # Optimistic concurrency lock


class GeneralSettingsOut(BaseModel):
    org_name: str
    site_name: str
    timezone: str
    locale: str
    session_timeout_minutes: int
    two_fa_enforced: bool
    ip_allowlist: list[str]
    version_tag: int
    updated_at: datetime | None = None
    updated_by: str | None = None


class SettingsAuditItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    action: str
    resource_type: str
    resource_id: str | None = None
    actor_id: uuid.UUID | None = None
    ip_address: str | None = None
    user_agent: str | None = None
    details: dict = Field(default_factory=dict)
    created_at: datetime
