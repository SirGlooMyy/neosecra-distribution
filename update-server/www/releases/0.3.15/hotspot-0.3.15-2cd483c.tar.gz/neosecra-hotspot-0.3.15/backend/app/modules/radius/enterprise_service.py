"""802.1X Enterprise FreeRADIUS konfigurasyonu.

EAP-PEAP / EAP-TTLS icin FreeRADIUS sites-enabled config,
LDAP auth backend, VLAN atama ve MAC Bypass (MAB) yapilandirmasi.
"""
from __future__ import annotations

import logging
from typing import Any

from app.core.crypto import decrypt

log = logging.getLogger(__name__)

EAP_TEMPLATE = """# Hotspot Enterprise — {location_name} ({location_id})
# FreeRADIUS sites-enabled config (otomatik olusturuldu)

server {server_name} {{

listen {{
    type = auth
    ipaddr = *
    port = 0
}}

listen {{
    type = acct
    ipaddr = *
    port = 0
}}

authorize {{
    preprocess
    auth_log
    suffix
    eap {{
        ok = return
    }}
    files
    ldap
    if (ok) {{
        update {{
            &reply:Tunnel-Type = VLAN
            &reply:Tunnel-Medium-Type = IEEE-802
            &reply:Tunnel-Private-Group-ID = "%{{sql:SELECT vlan_id FROM vlan_profiles WHERE user_group='%{{User-Name}}'}}"
        }}
    }}
    expiration
    logintime
}}

authenticate {{
    eap
    ldap
}}

post-auth {{
    post_auth_log
    reply_log
    if (session-state:User-Name && reply:Tunnel-Private-Group-ID) {{
        update {{
            &reply:Tunnel-Type := 13
            &reply:Tunnel-Medium-Type := 6
            &reply:Tunnel-Private-Group-ID := "%{{reply:Tunnel-Private-Group-ID}}"
        }}
    }}
}}

preacct {{
    preprocess
    acct_counters64
    acct_detail
}}

accounting {{
    detail
    acct_log
    radutmp
    &Acct-Input-Gigawords := 0
    &Acct-Output-Gigawords := 0
}}

session {{
    radutmp
}}
}}
"""

EAP_MODULE_TEMPLATE = """eap {{
    default_eap_type = peap
    timer_expire = 60
    ignore_unknown_eap_types = no
    cisco_accounting_username_bug = no

    tls-config tls-common {{
        private_key_password = /etc/freeradius/certs/server-key.pem
        private_key_file = /etc/freeradius/certs/server-key.pem
        certificate_file = /etc/freeradius/certs/server.pem
        CA_file = /etc/freeradius/certs/ca.pem
        dh_file = /etc/freeradius/certs/dh
        random_file = /dev/urandom
        fragment_size = 1024
        include_length = yes
        check_crl = no
        cipher_list = "DEFAULT"
    }}

    ttls {{
        tls = tls-common
        default_eap_type = mschapv2
        copy_request_to_tunnel = no
        use_tunneled_reply = no
        virtual_server = "inner-tunnel"
    }}

    peap {{
        tls = tls-common
        default_eap_type = mschapv2
        copy_request_to_tunnel = no
        use_tunneled_reply = no
        virtual_server = "inner-tunnel"
    }}

    mschapv2 {{
        send_error = no
    }}
}}
"""

MAB_AUTHORIZE_TEMPLATE = """# MAC Bypass (MAB) — Hotspot otomatik
# Yetkili MAC adresleri kontrolu
if ("%{{User-Name}}" =~ /^([0-9a-fA-F]{{2}}[:-]){{5}}[0-9a-fA-F]{{2}}$/) {{
    update {{
        &control:Auth-Type := Accept
    }}
    ok
}}
"""


def generate_freeradius_config(
    location_id: str,
    radius_client: Any,
    location_name: str = "Unknown",
) -> str:
    """FreeRADIUS sites-enabled config dosyasi icin icerik olustur.

    Args:
        location_id: Lokasyon UUID'si (string).
        radius_client: RadiusClient model instance.
        location_name: Lokasyon adi.

    Returns:
        FreeRADIUS config metni.
    """
    secret = ""
    if hasattr(radius_client, "shared_secret_encrypted") and radius_client.shared_secret_encrypted:
        try:
            secret = decrypt(radius_client.shared_secret_encrypted)
        except Exception as exc:
            log.error("shared_secret decrypt basarisiz: %s", exc)
            raise RuntimeError("RADIUS shared secret could not be decrypted") from exc
    else:
        raise RuntimeError("RADIUS shared secret is not configured")

    server_name = f"hotspot-{location_id[:8]}"

    config = f"""# Hotspot Enterprise RADIUS — {location_name}
# Otomatik olusturuldu — el ile duzenlemeyin.

server {server_name} {{

listen {{
    type = auth
    ipaddr = *
    port = 1812
}}

listen {{
    type = acct
    ipaddr = *
    port = 1813
}}

client {radius_client.nas_identifier} {{
    ipaddr = {radius_client.nas_ip or "0.0.0.0"}
    secret = {secret}
    shortname = {radius_client.nas_identifier}
    nastype = other
}}

authorize {{
    preprocess
    auth_log
    suffix
    eap {{
        ok = return
    }}
    files
    ldap
    if (ok) {{
        update reply {{
            Tunnel-Type = 13
            Tunnel-Medium-Type = 6
            Tunnel-Private-Group-ID = "%{{sql:SELECT vlan_id FROM vlan_profiles WHERE user_group='%{{User-Name}}'}}"
        }}
    }}
    expiration
    logintime
}}

authenticate {{
    eap
    ldap
}}

authenticate {{
    Auth-Type PAP {{
        pap
    }}
    Auth-Type CHAP {{
        chap
    }}
    Auth-Type MS-CHAP {{
        mschap
    }}
}}

post-auth {{
    post_auth_log
    reply_log
    if (reply:Tunnel-Private-Group-ID) {{
        update reply {{
            Tunnel-Type := 13
            Tunnel-Medium-Type := 6
        }}
    }}
}}

preacct {{
    preprocess
    acct_counters64
    acct_detail
}}

accounting {{
    detail
    acct_log
    radutmp
    &Acct-Input-Gigawords := 0
    &Acct-Output-Gigawords := 0
}}

session {{
    radutmp
}}
}}
"""
    return config


def enable_dynamic_vlan(radius_client: Any, vlan_id: int, user_group: str) -> dict[str, object]:
    """Dinamik VLAN atamasi icin RADIUS AVP doner.

    Args:
        radius_client: RadiusClient nesnesi (context icin).
        vlan_id: Atanacak VLAN ID.
        user_group: Kullanici grubu (ornek: employee, guest, iot).

    Returns:
        RADIUS AVP dict: Tunnel-Type, Tunnel-Medium-Type, Tunnel-Private-Group-ID.
    """
    return {
        "Tunnel-Type": 13,
        "Tunnel-Medium-Type": 6,
        "Tunnel-Private-Group-ID": str(vlan_id),
        "_meta": {
            "description": f"VLAN {vlan_id} atandi (user_group={user_group})",
            "nas_identifier": getattr(radius_client, "nas_identifier", "unknown"),
        },
    }


def configure_mac_bypass(
    nas_ip: str,
    shared_secret: str,
    mac_addresses: list[str],
) -> dict[str, object]:
    """MAC Bypass (MAB) yapilandirmasi — whitelist'teki MAC'lere izin ver.

    Args:
        nas_ip: NAS IP adresi.
        shared_secret: NAS shared secret.
        mac_addresses: Whitelist'teki MAC adresleri.

    Returns:
        MAB yapilandirma bilgisi.
    """
    mac_list = "\n".join(
        f'  if ("%{{User-Name}}" == "{m}") {{ update {{ &control:Auth-Type := Accept }} }}'
        for m in mac_addresses
    )
    config = f"""# MAC Bypass (MAB) — {nas_ip}
client mab-client {{
    ipaddr = {nas_ip}
    secret = {shared_secret}
    shortname = mab-{nas_ip.replace(".", "-")}
    nastype = cisco
}}

authorize mab {{
    if ("%{{User-Name}}" =~ /^([0-9a-fA-F]{{2}}[:-]){{5}}[0-9a-fA-F]{{2}}$/) {{
{mac_list}
        else {{
            reject
        }}
    }}
}}
"""
    return {
        "config": config,
        "nas_ip": nas_ip,
        "mac_count": len(mac_addresses),
    }


def generate_radius_client_config(
    client_ip: str,
    shared_secret: str,
    nas_type: str = "other",
) -> str:
    """FreeRADIUS clients.conf snippet olustur.

    Args:
        client_ip: NAS/IP katman cihaz IP.
        shared_secret: Paylasilan sifre.
        nas_type: NAS turu (cisco, other, vs.).

    Returns:
        clients.conf icin konfigurasyon metni.
    """
    shortname = f"client-{client_ip.replace('.', '-')}"
    return f"""client {shortname} {{
    ipaddr = {client_ip}
    secret = {shared_secret}
    shortname = {shortname}
    nastype = {nas_type}
}}
"""
