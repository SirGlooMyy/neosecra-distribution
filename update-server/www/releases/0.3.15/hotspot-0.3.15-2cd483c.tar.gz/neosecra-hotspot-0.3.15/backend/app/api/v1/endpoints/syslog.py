import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import settings
from app.core.ingest_auth import require_ingest_api_key
from app.core.rls import set_syslog_context
from app.modules.syslog.models import SyslogRecord
from app.modules.syslog.repository import resolve_firewall_log_context
from app.modules.syslog.schemas import SyslogRecordCreate, SyslogRecordOut

router = APIRouter()


async def _resolve_syslog_tenant(
    db: AsyncSession,
    body: SyslogRecordCreate,
    request: Request,
):
    """Resolve legacy syslog ownership from a registered source.

    ``tenant_id`` remains an input for backwards compatibility, but it is
    only accepted when it agrees with the device/source lookup. Unknown
    sources are rejected instead of being written into an arbitrary tenant.
    """
    client_host = request.client.host if request.client else None
    context = await resolve_firewall_log_context(
        db,
        body.hostname,
        None,
        source_ip=client_host,
    )
    if not context or context[0] is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Syslog kaynağı kayıtlı değil; tenant sahipliği doğrulanamadı",
        )

    try:
        resolved_tenant_id = uuid.UUID(str(context[0]))
    except (TypeError, ValueError, AttributeError):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Syslog tenant sahipliği geçersiz",
        )
    if body.tenant_id is not None and body.tenant_id != resolved_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Syslog tenant scope uyuşmuyor",
        )
    return resolved_tenant_id


@router.post("/records", response_model=SyslogRecordOut, summary="Ingest a syslog message record", description="Creates a new syslog record from an incoming syslog message. Accepts standard syslog fields such as facility, severity, hostname, and message body. Typically called by the syslog receiver service.")
async def create_syslog_record(
    body: SyslogRecordCreate,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    require_ingest_api_key(request, expected_key=settings.SYSLOG_API_KEY, service="Syslog")
    resolved_tenant_id = await _resolve_syslog_tenant(db, body, request)
    record = SyslogRecord(
        tenant_id=resolved_tenant_id,
        tenant_resolution_source="api_ingest",
        facility=body.facility,
        severity=body.severity,
        hostname=body.hostname,
        app_name=body.app_name,
        message=body.message
    )
    try:
        await set_syslog_context(db, resolved_tenant_id)
        db.add(record)
        await db.commit()
        # ``set_config(..., true)`` is transaction-local and commit resets it;
        # restore the same scope before the response refresh executes.
        await set_syslog_context(db, resolved_tenant_id)
        await db.refresh(record)
    except Exception:
        # Keep a failed legacy ingest from leaving a pending row in a reused
        # session; callers can retry the same source record safely.
        await db.rollback()
        raise
    return record
