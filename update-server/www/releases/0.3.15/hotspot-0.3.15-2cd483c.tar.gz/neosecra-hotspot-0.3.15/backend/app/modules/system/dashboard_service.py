"""Advanced Dashboard statistics service.

All queries are scope-filtered via the existing sessions._scoped_query_async
pattern (Mutlak Kural #2). Uses raw SQL for aggregations where SQLAlchemy ORM
would be verbose.
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import Integer, case, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.devices.models import Device
from app.modules.locations.models import Location
from app.modules.sessions.models import GuestSession

log = logging.getLogger(__name__)


def _session_filters(customer_id: uuid.UUID | None, *filters):
    """Build ORM filters without applying a customer predicate globally."""
    return [*(filters), *([GuestSession.customer_id == customer_id] if customer_id else [])]


def _customer_sql(alias: str, customer_id: uuid.UUID | None) -> tuple[str, dict]:
    """Return a safe static SQL scope predicate and its bind parameters."""
    if customer_id is None:
        return "TRUE", {}
    return f"{alias}.customer_id = :customer_id", {"customer_id": customer_id}


async def get_realtime_stats(db: AsyncSession, customer_id: uuid.UUID | None) -> dict:
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    active_count = await db.scalar(
        select(func.count(GuestSession.id)).where(
            *_session_filters(customer_id, GuestSession.status == "active")
        )
    )

    today_count = await db.scalar(
        select(func.count(GuestSession.id)).where(
            *_session_filters(customer_id, GuestSession.started_at >= today_start)
        )
    )

    scope_sql, scope_params = _customer_sql("gs", customer_id)
    peak_res = await db.execute(
        text(f"""
            SELECT COUNT(*) AS cnt, DATE_TRUNC('hour', started_at) AS hr
            FROM guest_sessions gs
            WHERE {scope_sql} AND started_at >= :since
            GROUP BY hr ORDER BY cnt DESC LIMIT 1
        """),
        {**scope_params, "since": today_start},
    )
    row = peak_res.fetchone()
    peak_today = row[0] if row else 0

    device_query = select(func.count(Device.id)).where(Device.status == "online")
    if customer_id is not None:
        device_query = device_query.join(Location, Device.location_id == Location.id).where(
            Location.customer_id == customer_id
        )
    active_devices = await db.scalar(device_query)

    return {
        "online_guests": active_count or 0,
        "today_guests": today_count or 0,
        "peak_today": peak_today,
        "active_devices": active_devices or 0,
    }


async def get_trend_data(db: AsyncSession, customer_id: uuid.UUID | None, days: int = 30) -> dict:
    since = datetime.now(timezone.utc) - timedelta(days=days)
    scope_sql, scope_params = _customer_sql("gs", customer_id)

    res = await db.execute(
        text(f"""
            SELECT
                DATE(gs.started_at) AS day,
                COUNT(*) AS total
            FROM guest_sessions gs
            WHERE {scope_sql} AND gs.started_at >= :since
            GROUP BY day ORDER BY day
        """),
        {**scope_params, "since": since},
    )
    daily = [{"date": str(r[0]), "count": r[1]} for r in res.fetchall()]

    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    yesterday_start = today_start - timedelta(days=1)
    today_count = await db.scalar(
        select(func.count(GuestSession.id)).where(
            *_session_filters(customer_id, GuestSession.started_at >= today_start)
        )
    ) or 0
    yesterday_count = await db.scalar(
        select(func.count(GuestSession.id)).where(
            *_session_filters(
                customer_id,
                GuestSession.started_at >= yesterday_start,
                GuestSession.started_at < today_start,
            )
        )
    ) or 0

    weekly_res = await db.execute(
        text(f"""
            SELECT
                DATE_TRUNC('week', gs.started_at) AS week,
                COUNT(*) AS total
            FROM guest_sessions gs
            WHERE {scope_sql} AND gs.started_at >= :since
            GROUP BY week ORDER BY week
        """),
        {**scope_params, "since": since},
    )
    weekly = [{"week": str(r[0]), "count": r[1]} for r in weekly_res.fetchall()]

    return {
        "daily": daily,
        "today": today_count,
        "yesterday": yesterday_count,
        "change_percent": round(
            ((today_count - yesterday_count) / max(yesterday_count, 1)) * 100, 1
        ),
        "weekly": weekly,
    }


async def get_os_browser_stats(db: AsyncSession, customer_id: uuid.UUID | None, period_days: int = 7) -> dict:
    since = datetime.now(timezone.utc) - timedelta(days=period_days)

    res = await db.execute(
        select(GuestSession.meta).where(
            *_session_filters(customer_id, GuestSession.started_at >= since)
        )
    )
    rows = res.scalars().all()

    os_dist: dict[str, int] = {}
    browser_dist: dict[str, int] = {}
    for meta in rows:
        if not meta:
            continue
        ua = meta.get("user_agent", meta.get("ua", ""))
        os_name = _parse_os(ua)
        browser_name = _parse_browser(ua)
        os_dist[os_name] = os_dist.get(os_name, 0) + 1
        browser_dist[browser_name] = browser_dist.get(browser_name, 0) + 1

    return {
        "os_distribution": [{"name": k, "count": v} for k, v in sorted(os_dist.items(), key=lambda x: -x[1])],
        "browser_distribution": [{"name": k, "count": v} for k, v in sorted(browser_dist.items(), key=lambda x: -x[1])],
    }


async def get_auth_method_distribution(db: AsyncSession, customer_id: uuid.UUID | None, period_days: int = 30) -> list[dict]:
    since = datetime.now(timezone.utc) - timedelta(days=period_days)
    scope_sql, scope_params = _customer_sql("gs", customer_id)

    res = await db.execute(
        text(f"""
            SELECT gs.auth_method, COUNT(*) AS cnt
            FROM guest_sessions gs
            WHERE {scope_sql} AND gs.started_at >= :since
            GROUP BY gs.auth_method ORDER BY cnt DESC
        """),
        {**scope_params, "since": since},
    )
    return [{"method": r[0], "count": r[1]} for r in res.fetchall()]


async def get_hourly_heatmap(db: AsyncSession, customer_id: uuid.UUID | None, days: int = 7) -> list[dict]:
    since = datetime.now(timezone.utc) - timedelta(days=days)
    scope_sql, scope_params = _customer_sql("gs", customer_id)

    res = await db.execute(
        text(f"""
            SELECT
                EXTRACT(DOW FROM gs.started_at)::int AS day_of_week,
                EXTRACT(HOUR FROM gs.started_at)::int AS hour_of_day,
                COUNT(*) AS cnt
            FROM guest_sessions gs
            WHERE {scope_sql} AND gs.started_at >= :since
            GROUP BY day_of_week, hour_of_day
            ORDER BY day_of_week, hour_of_day
        """),
        {**scope_params, "since": since},
    )
    return [
        {"day_of_week": r[0], "hour_of_day": r[1], "count": r[2]}
        for r in res.fetchall()
    ]


async def get_top_locations(db: AsyncSession, customer_id: uuid.UUID | None, limit: int = 10) -> list[dict]:
    scope_sql, scope_params = _customer_sql("gs", customer_id)
    res = await db.execute(
        text(f"""
            SELECT l.id, l.name, COUNT(gs.id) AS session_count
            FROM guest_sessions gs
            JOIN locations l ON l.id = gs.location_id
            WHERE {scope_sql}
            GROUP BY l.id, l.name
            ORDER BY session_count DESC
            LIMIT :lim
        """),
        {**scope_params, "lim": limit},
    )
    return [
        {
            "location_id": str(r[0]),
            "location_name": r[1],
            # Keep the canonical names used by the admin dashboard while
            # retaining the explicit fields for API consumers.
            "id": str(r[0]),
            "name": r[1],
            "session_count": r[2],
        }
        for r in res.fetchall()
    ]


async def get_top_users(db: AsyncSession, customer_id: uuid.UUID | None, limit: int = 10) -> list[dict]:
    scope_sql, scope_params = _customer_sql("gs", customer_id)
    res = await db.execute(
        text(f"""
            SELECT COALESCE(gs.phone, gs.mac, 'Misafir') AS user_identifier,
                   COUNT(*) AS session_count,
                   MAX(gs.started_at) AS last_seen,
                   COALESCE(SUM(gs.bytes_in + gs.bytes_out), 0) AS bytes_total
            FROM guest_sessions gs
            WHERE {scope_sql}
            GROUP BY COALESCE(gs.phone, gs.mac, 'Misafir')
            ORDER BY bytes_total DESC, session_count DESC
            LIMIT :lim
        """),
        {**scope_params, "lim": limit},
    )
    return [
        {
            "phone": r[0],
            "name": r[0],
            "session_count": int(r[1] or 0),
            "bytes_total": int(r[3] or 0),
            "last_seen": str(r[2]) if r[2] else None,
        }
        for r in res.fetchall()
    ]


async def get_dashboard_overview(
    db: AsyncSession,
    customer_id: uuid.UUID,
    *,
    trend_days: int = 30,
) -> dict:
    """Return the operational dashboard in one typed response.

    The admin used to fan out to nine independent requests.  Besides being
    slow, that made a missing customer scope look like a collection of 400s.
    This endpoint keeps the existing service functions (and therefore their
    query semantics) but presents a single installation/customer snapshot.
    """
    realtime = await get_realtime_stats(db, customer_id)
    trend = await get_trend_data(db, customer_id, trend_days)
    auth_methods = await get_auth_method_distribution(db, customer_id)
    heatmap = await get_hourly_heatmap(db, customer_id)
    os_browser = await get_os_browser_stats(db, customer_id)
    top_locations = await get_top_locations(db, customer_id)
    top_users = await get_top_users(db, customer_id)

    total_auth = sum(int(item.get("count", 0) or 0) for item in auth_methods)
    auth_distribution = [
        {
            **item,
            "percentage": round((int(item.get("count", 0) or 0) / total_auth) * 100, 1)
            if total_auth
            else 0,
        }
        for item in auth_methods
    ]

    from app.modules.syslog.models import FirewallLog
    since_date = datetime.now(timezone.utc) - timedelta(days=trend_days)

    fw_traffic = await db.execute(
        select(
            func.coalesce(func.sum(FirewallLog.rcvdbyte), 0),
            func.coalesce(func.sum(FirewallLog.sentbyte), 0),
        ).where(
            FirewallLog.customer_id == customer_id,
            FirewallLog.effective_event_time >= since_date,
        )
    )
    fw_bin, fw_bout = fw_traffic.one()
    bytes_in = int(fw_bin or 0)
    bytes_out = int(fw_bout or 0)

    if bytes_in == 0 and bytes_out == 0:
        sess_traffic = await db.execute(
            select(
                func.coalesce(func.sum(GuestSession.bytes_in), 0),
                func.coalesce(func.sum(GuestSession.bytes_out), 0),
            ).where(
                GuestSession.customer_id == customer_id,
                GuestSession.started_at >= since_date,
            )
        )
        sess_bin, sess_bout = sess_traffic.one()
        bytes_in = int(sess_bin or 0)
        bytes_out = int(sess_bout or 0)

    auth_counts = await db.execute(
        select(
            func.count(GuestSession.id),
            func.sum(
                case(
                    (
                        (GuestSession.authorize_ok == True)  # noqa: E712
                        | (GuestSession.status.in_(["active", "closed", "expired"]))
                        & (GuestSession.authorize_message != "Yönetici onayı reddedildi"),
                        1,
                    ),
                    else_=0,
                )
            ),
        ).where(
            GuestSession.customer_id == customer_id,
            GuestSession.started_at >= since_date,
        )
    )
    attempts, successful = auth_counts.one()
    attempts = int(attempts or 0)
    successful = int(successful or 0)

    return {
        "customer_id": str(customer_id),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "realtime": realtime,
        "trend": trend,
        "auth_methods": auth_distribution,
        "heatmap": heatmap,
        "os_browser": os_browser,
        "top_locations": top_locations,
        "top_users": top_users,
        "traffic": {
            "bytes_in": int(bytes_in or 0),
            "bytes_out": int(bytes_out or 0),
            "bytes_total": int((bytes_in or 0) + (bytes_out or 0)),
        },
        "authentication": {
            "attempts": attempts,
            "successes": successful,
            "failures": max(attempts - successful, 0),
            "success_rate": round((successful / attempts) * 100, 1) if attempts else 100.0,
        },
    }


async def get_system_health(db: AsyncSession) -> dict:
    health = {"database": "ok", "redis": "unknown", "minio": "unknown",
              "celery": "unknown", "disk_usage": {}, "memory_usage": {}}

    try:
        await db.execute(select(func.now()))
        health["database"] = "ok"
    except Exception as exc:
        health["database"] = f"error: {exc}"

    try:
        import aioredis  # type: ignore[import-not-found]
        from app.core.config import settings as cfg
        r = aioredis.from_url(cfg.REDIS_URL, socket_connect_timeout=3)
        await r.ping()
        health["redis"] = "ok"
        await r.close()
    except ImportError:
        try:
            import redis
            from app.core.config import settings as cfg
            r = redis.from_url(cfg.REDIS_URL, socket_connect_timeout=3)
            r.ping()
            health["redis"] = "ok"
            r.close()
        except Exception as exc:
            health["redis"] = f"error: {exc}"
    except Exception as exc:
        health["redis"] = f"error: {exc}"

    try:
        from minio import Minio  # type: ignore[import-not-found]
        from app.core.config import settings
        client = Minio(
            settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=settings.MINIO_SECURE,
        )
        client.list_buckets()
        health["minio"] = "ok"
    except ImportError:
        pass
    except Exception as exc:
        health["minio"] = f"error: {exc}"

    try:
        from app.modules.workers.celery_app import celery_app as capp
        inspector = capp.control.inspect()
        stats = inspector.stats()
        if stats:
            health["celery"] = f"ok ({len(stats)} worker(s))"
        else:
            health["celery"] = "no workers"
    except Exception as exc:
        health["celery"] = f"error: {exc}"

    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        health["disk_usage"] = {
            "total_gb": round(total / (1024**3), 2),
            "used_gb": round(used / (1024**3), 2),
            "free_gb": round(free / (1024**3), 2),
            "percent_used": round((used / total) * 100, 1),
        }
    except Exception as exc:
        health["disk_usage"] = {"error": str(exc)}

    # ClickHouse check
    if settings.CLICKHOUSE_ENABLED:
        try:
            from app.adapters import clickhouse as ch
            cnt = await ch.count_syslog()
            health["clickhouse"] = f"ok ({cnt:,} log)"
        except Exception as exc:
            health["clickhouse"] = f"error: {exc}"
    else:
        health["clickhouse"] = "disabled"

    try:
        import psutil
        mem = psutil.virtual_memory()
        health["memory_usage"] = {
            "total_gb": round(mem.total / (1024**3), 2),
            "available_gb": round(mem.available / (1024**3), 2),
            "percent_used": mem.percent,
        }
    except Exception:
        try:
            with open("/proc/meminfo") as f:
                lines = f.readlines()
            meminfo = {}
            for line in lines:
                parts = line.split(":")
                if len(parts) == 2:
                    meminfo[parts[0].strip()] = int(parts[1].split()[0])
            total_kb = meminfo.get("MemTotal", 0)
            avail_kb = meminfo.get("MemAvailable", meminfo.get("MemFree", 0))
            used_kb = total_kb - avail_kb
            if total_kb > 0:
                health["memory_usage"] = {
                    "total_gb": round(total_kb / (1024**2), 2),
                    "available_gb": round(avail_kb / (1024**2), 2),
                    "percent_used": round((used_kb / total_kb) * 100, 1),
                }
        except Exception as exc:
            health["memory_usage"] = {"error": str(exc)}

    return health


# ---- User-Agent parsing helpers -----------------------------------------------
_OS_MAP = [
    ("Android", "android"),
    ("iOS", "iphone|ipad|ipod"),
    ("Windows", "windows"),
    ("macOS", "macintosh|mac os x"),
    ("Linux", "linux"),
    ("Chrome OS", "cros"),
]

_BROWSER_MAP = [
    ("Chrome", "chrome"),
    ("Safari", "safari"),
    ("Firefox", "firefox"),
    ("Edge", "edg"),
    ("Opera", "opera|opr"),
    ("IE", "trident|msie"),
]


def _parse_os(ua: str) -> str:
    ua_lower = ua.lower()
    for name, pattern in _OS_MAP:
        import re
        if re.search(pattern, ua_lower):
            return name
    return "Bilinmeyen"


def _parse_browser(ua: str) -> str:
    ua_lower = ua.lower()
    for name, pattern in _BROWSER_MAP:
        import re
        if re.search(pattern, ua_lower):
            return name
    return "Bilinmeyen"
