"""Canonical captive-portal template contract.

The admin editor, phone preview and public portal must all render the same
persisted template revision.  Keep the shaping logic in one small module so a
legacy row cannot cause one surface to invent a different method or field set.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from app.modules.portal.field_schema import normalize_fields
from app.modules.portal.models import (
    METHOD_FREE,
    METHOD_TC,
    METHODS,
)


PUBLIC_METHODS = (METHOD_FREE, "sms", METHOD_TC, "voucher", "pms", "local")


class PortalParityError(ValueError):
    """Raised when a persisted template cannot produce one canonical contract."""


def _revision(meta: dict[str, Any]) -> int:
    try:
        value = int(meta.get("revision", 1))
    except (TypeError, ValueError):
        return 1
    return value if value > 0 else 1


def _public_method(value: object) -> str:
    normalized = str(value or "").strip().lower()
    return "tc_sms" if normalized == METHOD_TC else normalized


def build_template_contract(template: Any) -> dict[str, Any]:
    """Return the exact public/admin rendering contract for a template row."""
    meta = template.meta if isinstance(getattr(template, "meta", None), dict) else {}
    theme = template.theme if isinstance(getattr(template, "theme", None), dict) else {}
    configured = meta.get("enabled_methods")
    # A legacy row without method metadata has exactly one canonical method:
    # the persisted ``template.method``.  An explicitly supplied list is
    # authoritative and must not be repaired by adding/removing methods.
    if configured is None:
        raw_methods = [getattr(template, "method", METHOD_FREE)]
    elif not isinstance(configured, list):
        raise PortalParityError("Portal doğrulama yöntemleri kanonik liste değil.")
    else:
        raw_methods = configured
    enabled_methods: list[str] = []
    for value in raw_methods:
        method = _public_method(value)
        if method not in {_public_method(item) for item in PUBLIC_METHODS}:
            # Known network/admin methods may remain in legacy metadata, but
            # they are intentionally outside the captive guest contract. Do
            # not expose them; reject only unknown values that indicate a
            # corrupted persisted contract.
            if str(value or "").strip().lower() in METHODS:
                continue
            raise PortalParityError("Portal doğrulama yöntemi desteklenmiyor.")
        if method not in enabled_methods:
            enabled_methods.append(method)

    if not enabled_methods:
        raise PortalParityError("Portal için etkin bir doğrulama yöntemi yok.")

    default_method = _public_method(getattr(template, "method", METHOD_FREE))
    allowed_methods = {_public_method(item) for item in PUBLIC_METHODS}
    if default_method not in allowed_methods:
        raise PortalParityError("Portal varsayılan doğrulama yöntemi desteklenmiyor.")
    if default_method not in enabled_methods:
        raise PortalParityError("Portal varsayılan yöntemi etkin yöntemlerle eşleşmiyor.")

    method_fields_meta = meta.get("method_fields") if isinstance(meta.get("method_fields"), dict) else {}
    fields_by_method: dict[str, list[dict[str, Any]]] = {}
    for method in enabled_methods:
        backend_method = METHOD_TC if method == "tc_sms" else method
        raw_fields = method_fields_meta.get(backend_method)
        if not isinstance(raw_fields, list) or not raw_fields:
            raw_fields = method_fields_meta.get(method)
        if not isinstance(raw_fields, list) or not raw_fields:
            # The persisted template fields are canonical for its selected
            # method.  Other methods must be explicitly persisted; defaults
            # are only applied by the backend field contract, never by a UI.
            raw_fields = template.fields if backend_method == getattr(template, "method", None) else []
        if not isinstance(raw_fields, list) or not raw_fields:
            # Do not invent a field schema for an explicitly enabled method.
            # The single-method legacy path may still be normalized by the
            # backend's persisted method contract (see normalize_fields).
            if isinstance(configured, list) or backend_method != getattr(template, "method", None):
                raise PortalParityError(f"Portal {method} form alanları kanonik kaynaktan alınamadı.")
        fields_by_method[method] = normalize_fields(raw_fields, backend_method)
        if not fields_by_method[method]:
            raise PortalParityError(f"Portal {method} form alanları boş.")

    revision = _revision(meta)
    return {
        "revision": revision,
        "enabled_methods": enabled_methods,
        "fields_by_method": fields_by_method,
        "theme": dict(theme),
    }


def template_parity_hash(contract: dict[str, Any]) -> str:
    payload = json.dumps(
        {
            "revision": contract["revision"],
            "enabled_methods": contract["enabled_methods"],
            "fields_by_method": contract["fields_by_method"],
            "theme": contract["theme"],
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def public_contract(template: Any) -> dict[str, Any]:
    contract = build_template_contract(template)
    return {
        **contract,
        "template_parity_hash": template_parity_hash(contract),
        "canonical_source": "portal_template",
    }
