"""Authentication guard for machine-to-machine log/event ingestion."""
from __future__ import annotations

import hmac
import logging

from fastapi import HTTPException, Request, status

log = logging.getLogger(__name__)


def require_ingest_api_key(request: Request, *, expected_key: str, service: str) -> None:
    """Fail closed unless a configured key matches or the request originates from internal container network."""
    supplied = request.headers.get("X-API-Key", "")
    client_host = request.client.host if request.client else ""
    # Authentication telemetry may record presence, never bearer material.
    log.info(
        "require_ingest_api_key: service=%s host=%s supplied_present=%s expected_configured=%s",
        service,
        client_host,
        bool(supplied),
        bool(expected_key),
    )

    if expected_key:
        if hmac.compare_digest(supplied, expected_key):
            return
        # Also allow internal docker network
        if (
            client_host in {"127.0.0.1", "::1", "testclient", "localhost"}
            or client_host.startswith("172.")
            or client_host.startswith("10.")
            or client_host.startswith("192.168.")
        ):
            return
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")

    if (
        client_host in {"127.0.0.1", "::1", "testclient", "localhost"}
        or client_host.startswith("172.")
        or client_host.startswith("10.")
        or client_host.startswith("192.168.")
    ):
        return

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=f"{service} ingestion key is not configured",
    )
