"""Location CRUD with tenant-tree scope filtering.

- super_admin: all locations
- partner_admin: locations under customers whose partner_id == scope.partner_id (join)
- customer_admin: Location.customer_id == scope.customer_id
- location_manager: Location.id == scope.location_id (own)
- others: deny (fail-closed)
"""
import uuid

from fastapi import HTTPException, Request, status
from sqlalchemy import false, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.locations.schemas import LocationCreate, LocationUpdate


def _scoped_query(scope: ScopeContext):
    q = select(Location)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = q.join(Customer, Location.customer_id == Customer.id)
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(Location.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        return q.where(Location.id == scope.location_id), True
    return q.where(false()), False


async def list_locations(db: AsyncSession, scope: ScopeContext) -> list[Location]:
    q, _ = _scoped_query(scope)
    # The operational selector must not offer soft-deleted locations. Their
    # historical rows remain queryable through audit/archive surfaces.
    result = await db.execute(q.where(Location.is_active.is_(True)).order_by(Location.created_at.desc()))
    locations = list(result.scalars().all())
    if not locations:
        return locations

    # Enrichment is part of the location-list contract, not best-effort UI
    # decoration. Restrict both lookups to the already scoped locations so a
    # customer/partner can never influence counts or names outside its view.
    from app.modules.devices.models import Device

    location_ids = [location.id for location in locations]
    dev_res = await db.execute(
        select(Device.location_id, func.count(Device.id).label("devices_count"))
        .where(Device.location_id.in_(location_ids), Device.is_active.is_(True))
        .group_by(Device.location_id)
    )
    dev_map = {loc_id: int(count) for loc_id, count in dev_res.all() if loc_id}

    customer_ids = {location.customer_id for location in locations if location.customer_id}
    cust_map: dict[uuid.UUID, str] = {}
    if customer_ids:
        cust_res = await db.execute(
            select(Customer.id, Customer.name).where(Customer.id.in_(customer_ids))
        )
        cust_map = {customer_id: name for customer_id, name in cust_res.all()}

    for location in locations:
        location.devices_count = dev_map.get(location.id, 0)
        location.customer_name = cust_map.get(location.customer_id)

    return locations


async def get_location(db: AsyncSession, location_id: uuid.UUID, scope: ScopeContext) -> Location:
    q, allowed = _scoped_query(scope)
    result = await db.execute(q.where(Location.id == location_id))
    location = result.scalar_one_or_none()
    if not location:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Lokasyon bulunamadi")
    if not allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu lokasyona erisim yetkiniz yok")
    return location


async def _resolve_customer_for_create(
    db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext
) -> Customer:
    """Validate that the caller may attach a location to this customer."""
    cq = select(Customer)
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        cq = cq.where(Customer.id == customer_id, Customer.partner_id == scope.partner_id)
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        cq = cq.where(Customer.id == customer_id, Customer.id == scope.customer_id)
    elif scope.level == TenantLevel.GLOBAL:
        cq = cq.where(Customer.id == customer_id)
    else:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Lokasyon olusturma yetkiniz yok")
    customer = (await db.execute(cq)).scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu musteriye lokasyon ekleyemezsiniz")
    return customer


async def create_location(
    db: AsyncSession, body: LocationCreate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> Location:
    await _resolve_customer_for_create(db, body.customer_id, scope)
    location = Location(
        customer_id=body.customer_id, name=body.name, address=body.address,
        city=body.city, default_ssid=body.default_ssid, timezone=body.timezone,
    )
    db.add(location)
    await log_audit(db, "location.created", "location", str(location.id), str(actor_id), request,
                    details={"name": body.name, "customer_id": str(body.customer_id)})
    await db.commit()
    await db.refresh(location)
    return location


async def update_location(
    db: AsyncSession, location_id: uuid.UUID, body: LocationUpdate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> Location:
    location = await get_location(db, location_id, scope)
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(location, k, v)
    await log_audit(db, "location.updated", "location", str(location_id), str(actor_id), request, details=data)
    await db.commit()
    await db.refresh(location)
    return location


async def deactivate_location(
    db: AsyncSession, location_id: uuid.UUID, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> None:
    location = await get_location(db, location_id, scope)
    location.is_active = False
    await log_audit(db, "location.deactivated", "location", str(location_id), str(actor_id), request)
    await db.commit()
