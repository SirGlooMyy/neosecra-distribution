from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
import uuid
from typing import List

from app.core.database import get_db
from app.modules.devices.models import Device
from app.modules.devices import service as device_service
from app.modules.devices.schemas import DeviceOut
from app.modules.firewall_adapters import service as adapter_service
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.core.tenant import scope_for

router = APIRouter()

class TestConnectionIn(BaseModel):
    device_id: uuid.UUID


# --- Firewall Capability Endpoint ---

@router.get("/capabilities")
async def list_capabilities():
    """Return all supported vendors and their capability matrix."""
    return await adapter_service.list_vendor_capabilities()


@router.get("/{device_id}/capabilities")
async def device_capabilities(
    device_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Return a specific device's capabilities (vendor + runtime info)."""
    scope = scope_for(user)
    return await adapter_service.get_device_capabilities(db, device_id, scope)


# --- Endpoints ---

@router.get("", response_model=List[DeviceOut])
async def list_devices(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user)
):
    # Retrieve devices through the scoped device service; never silently
    # downgrade to an empty list if an adapter helper is missing.
    return await device_service.list_devices(db, scope_for(user))

@router.get("/all", response_model=List[DeviceOut])
async def list_all_devices(
    db: AsyncSession = Depends(get_db)
):
    q = select(Device).where(Device.is_active)
    res = await db.execute(q)
    return list(res.scalars().all())

@router.post("/test-connection")
async def test_connection(
    body: TestConnectionIn,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        res = await adapter_service.test_connection_service(db, body.device_id, scope_for(user))
        return {"ok": res.ok, "message": res.message, "data": res.data}
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Cihaz bağlantısı test edilemedi; cihaz ve credential ayarlarını kontrol edin",
        )
