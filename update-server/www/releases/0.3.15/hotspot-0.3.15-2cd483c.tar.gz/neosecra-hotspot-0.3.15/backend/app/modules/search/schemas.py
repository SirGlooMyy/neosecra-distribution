from datetime import datetime
import uuid

from pydantic import BaseModel, ConfigDict, Field


class SearchCorrelationSummary(BaseModel):
    correlation_id: str
    correlation_type: str
    reason: str
    hit_count: int
    source_count: int = 0
    sources: list[str] = Field(default_factory=list)
    first_timestamp: str
    last_timestamp: str
    sample_hostname: str | None = None
    sample_source_ip: str | None = None
    sample_session_id: str | None = None


class SearchQuery(BaseModel):
    customer_id: str
    q: str | None = None
    vendor: str | None = None
    log_type: str | None = None
    from_time: datetime | None = None
    to_time: datetime | None = None
    source_ip: str | None = None
    dest_ip: str | None = None
    mac: str | None = None
    username: str | None = None
    domain: str | None = None
    application: str | None = None
    action: str | None = None
    severity_min: int | None = None
    severity_max: int | None = None
    hostname: str | None = None
    device_id: str | None = None
    location_id: str | None = None
    quick_filter: str | None = None
    correlation_window_minutes: int = Field(15, ge=1, le=120)
    limit: int = Field(100, ge=1, le=5000)
    offset: int = Field(0, ge=0)


class SearchHit(BaseModel):
    timestamp: str
    customer_id: str
    location_id: str | None = None
    device_id: str | None = None
    facility: str = "unknown"
    log_type: str | None = None
    log_subtype: str | None = None
    severity: int = 5
    hostname: str = ""
    source_ip: str = "::"
    dest_ip: str = "::"
    mac: str = ""
    username: str = ""
    domain: str = ""
    application: str = ""
    action: str = ""
    message: str = ""
    raw: str | None = None
    session_id: str | None = None
    source: str = "clickhouse"  # clickhouse | archive
    correlation_id: str | None = None
    correlation_type: str | None = None
    correlation_reason: str | None = None
    correlation_group_size: int | None = None


class SearchResult(BaseModel):
    hits: list[SearchHit]
    total: int
    limit: int
    offset: int
    source: str = "clickhouse"
    correlation_summary: list[SearchCorrelationSummary] = Field(default_factory=list)


class SearchExportOut(BaseModel):
    filename: str
    content_type: str = "application/zip"
    row_count: int


class LogSearchParams(BaseModel):
    customer_id: uuid.UUID | None = None
    vendor: str | None = None
    log_type: str | None = None
    severity: str | None = None
    action: str | None = None
    src_ip: str | None = None
    dst_ip: str | None = None
    src_port: int | None = None
    dst_port: int | None = None
    user: str | None = None
    device_id: str | None = None
    location_id: str | None = None
    policyid: int | None = None
    service: str | None = None
    proto: str | None = None
    q: str | None = None
    from_time: datetime | None = None
    to_time: datetime | None = None
    time_window: str | None = None
    limit: int = Field(100, ge=1, le=1000)
    offset: int = Field(0, ge=0)


class LogSearchItem(BaseModel):
    id: str
    tenant_id: str
    event_time: str | None = None
    received_at: str | None = None
    vendor: str = "fortigate"
    hostname: str | None = None
    log_type: str
    log_subtype: str | None = None
    severity: str
    action: str | None = None
    message: str | None = None
    src_ip: str | None = None
    dst_ip: str | None = None
    src_port: int | None = None
    dst_port: int | None = None
    proto: str | None = None
    service: str | None = None
    user: str | None = None
    policyid: int | None = None
    duration: int | None = None
    sentbyte: int | None = None
    rcvdbyte: int | None = None
    session_id: str | None = None
    raw_syslog: str | None = None
    parsed_fields: dict = Field(default_factory=dict)
    rank: float | None = None


class LogSearchResponse(BaseModel):
    total: int
    items: list[LogSearchItem]
    took_ms: int


class HistogramBucket(BaseModel):
    timestamp: str
    count: int


class FacetValue(BaseModel):
    value: str
    count: int


class FacetResult(BaseModel):
    vendor: list[FacetValue] = Field(default_factory=list)
    log_type: list[FacetValue] = Field(default_factory=list)
    severity: list[FacetValue] = Field(default_factory=list)
    action: list[FacetValue] = Field(default_factory=list)
    src_ip: list[FacetValue] = Field(default_factory=list)
    dst_ip: list[FacetValue] = Field(default_factory=list)
    user: list[FacetValue] = Field(default_factory=list)
    domain: list[FacetValue] = Field(default_factory=list)
    application: list[FacetValue] = Field(default_factory=list)
    histogram: list[HistogramBucket] = Field(default_factory=list)


class CorrelateSessionInfo(BaseModel):
    id: str
    mac: str
    ip: str | None = None
    auth_method: str | None = None
    status: str | None = None
    started_at: str | None = None
    ended_at: str | None = None
    bytes_in: int = 0
    bytes_out: int = 0


class CorrelateTimelineItem(BaseModel):
    event_time: str
    source: str
    log_type: str | None = None
    severity: str | None = None
    action: str | None = None
    message: str | None = None


class CorrelateResponse(BaseModel):
    session: CorrelateSessionInfo | None = None
    traffic_logs: list[LogSearchItem] = Field(default_factory=list)
    auth_logs: list[LogSearchItem] = Field(default_factory=list)
    timeline: list[CorrelateTimelineItem] = Field(default_factory=list)


class TrafficAggregationOut(BaseModel):
    hourly: list[dict]
    summary: dict


class SearchViewCreate(BaseModel):
    surface: str = Field("firewall_logs", min_length=1, max_length=50)
    title: str = Field(..., min_length=1, max_length=255)
    description: str | None = Field(None, max_length=1000)
    filters: dict = Field(default_factory=dict)
    is_shared: bool = False


class SearchViewUpdate(BaseModel):
    surface: str | None = Field(None, min_length=1, max_length=50)
    title: str | None = Field(None, min_length=1, max_length=255)
    description: str | None = Field(None, max_length=1000)
    filters: dict | None = None
    is_shared: bool | None = None


class SearchViewOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    created_by_user_id: uuid.UUID
    surface: str
    title: str
    description: str | None = None
    filters: dict
    is_shared: bool
    created_at: datetime
    updated_at: datetime
