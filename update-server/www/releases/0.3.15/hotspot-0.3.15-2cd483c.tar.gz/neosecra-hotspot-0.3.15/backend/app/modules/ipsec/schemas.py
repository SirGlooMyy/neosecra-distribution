"""IPsec & Dial-up Tunnel Management Schemas."""
from __future__ import annotations

from typing import Any
from pydantic import BaseModel, Field


class IpsecSummaryOut(BaseModel):
    active_tunnels: int = 0
    total_dialup_clients: int = 0
    total_traffic_bytes: int = 0
    total_sent_bytes: int = 0
    total_rcvd_bytes: int = 0
    nat_t_sessions: int = 0
    ike_phase1_ok: bool = True
    ike_phase2_ok: bool = True
    active_users_list: list[str] = Field(default_factory=list)
    top_devices: list[dict[str, Any]] = Field(default_factory=list)


class IpsecTunnelSessionOut(BaseModel):
    id: str
    event_time: str
    user: str
    device_name: str
    os_name: str
    hardware_vendor: str
    src_ip: str
    src_country: str
    dst_ip: str
    dst_country: str
    tunnel_ip: str
    src_port: int
    dst_port: int
    service: str
    proto: str
    action: str
    duration_sec: int
    duration_str: str
    sent_bytes: int
    rcvd_bytes: int
    total_bytes: int
    sent_packets: int
    rcvd_packets: int
    policy_name: str
    status: str  # UP, ACTIVE, CLOSED, NEGOTIATING
    is_dialup: bool


class IpsecEventOut(BaseModel):
    id: str
    event_time: str
    event_type: str  # IKE_PHASE1, IKE_PHASE2, DPD, REKEY, DISCONNECT, TRAFFIC
    level: str
    action: str
    user: str
    src_ip: str
    dst_ip: str
    port: int
    message: str


class IpsecTrendPoint(BaseModel):
    time_label: str
    sent_bytes: int
    rcvd_bytes: int
    total_bytes: int
    session_count: int
