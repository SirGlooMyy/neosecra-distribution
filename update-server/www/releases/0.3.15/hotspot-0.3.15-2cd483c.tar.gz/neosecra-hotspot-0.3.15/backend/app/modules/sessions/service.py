"""Guest session service: creation (public captive flow), scoped admin
list/get and close.

create_session is a PUBLIC-flow helper (no admin JWT) — the caller resolves
customer_id/location_id/device_id from the device the guest is behind and
passes them in explicitly (Mutlak Kural #1/#2 — tenant isolation extends to
the guest auth path). Admin views are scope-filtered on the customer (->
partner) axis with an extra LOCATION filter on the denormalized location_id,
mirroring vouchers/identity. Fail-closed for any scoped role with no
assignment.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import inspect
import logging
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import and_, false, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.portal.approval import normalize_decision
from app.modules.sessions.models import (
    STATUS_ACTIVE,
    STATUS_PENDING,
    STATUS_CLOSED,
    STATUS_EXPIRED,
    GuestSession,
    AUTH_STATUS_AUTHORIZED,
    AUTH_STATUS_FAILED,
    AUTH_STATUS_REVOKED,
)

log = logging.getLogger(__name__)


def _approval_audit_projection(meta: dict | None) -> dict:
    """Return a secret/PII-safe projection for session-created audit rows."""
    if not isinstance(meta, dict):
        return {}
    projected = dict(meta)
    if "approval" in projected:
        approval = projected.get("approval")
        # Token digests are intentionally not copied to append-only audit
        # storage.  Correlation remains available without bearer material or
        # manager e-mail PII.
        projected = {
            key: meta[key]
            for key in ("terms_version", "privacy_version")
            if key in meta
        }
        if isinstance(approval, dict):
            projected["approval"] = {
                "required": approval.get("required"),
                "status": approval.get("status"),
                "expires_at": approval.get("token_expires_at"),
                "approval_correlation_id": approval.get("approval_correlation_id"),
            }
        else:
            # A malformed approval envelope must never be copied to an audit
            # record where an accidentally embedded secret could persist.
            projected["approval"] = {"status": "invalid"}
    return projected


def _approval_expiry(value: object) -> datetime | None:
    if not value:
        return None
    try:
        parsed = value if isinstance(value, datetime) else datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _approval_details(
    approval: dict,
    *,
    decision: str,
    outcome: str | None = None,
    source: str | None = None,
) -> dict:
    """Build audit details without token, digest or recipient PII."""
    return {
        "approval_correlation_id": approval.get("approval_correlation_id"),
        "decision": decision,
        "outcome": outcome or approval.get("status"),
        "source": source or (
            "public_link" if approval.get("source") == "public_link" else "session_action"
        ),
    }


# ---- scoped query (customer -> partner axis, mirrors vouchers/identity) --
async def _scoped_query_async(db: AsyncSession, scope: ScopeContext):
    """Scope query on GuestSession (customer axis). LOCATION level filters on
    the denormalized location_id directly (no customer join needed). Fail-closed
    for a scoped role with no assignment."""
    q = select(GuestSession)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = q.join(Customer, GuestSession.customer_id == Customer.id)
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(GuestSession.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        return q.where(GuestSession.location_id == scope.location_id), True
    return q.where(false()), False


# ---- public-flow create (no admin JWT) -----------------------------------
async def create_session(
    db: AsyncSession,
    *,
    session_id: uuid.UUID | None = None,
    customer_id: uuid.UUID,
    mac: str,
    auth_method: str,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    identity_verification_id: uuid.UUID | None = None,
    voucher_id: uuid.UUID | None = None,
    group_id: uuid.UUID | None = None,
    phone: str | None = None,
    ip: str | None = None,
    nas_ip: str | None = None,
    ssid: str | None = None,
    duration_minutes: int | None = None,
    authorize_ok: bool = True,
    authorize_message: str | None = None,
    status: str = STATUS_ACTIVE,
    meta: dict | None = None,
    request: Request | None = None,
    # KVKK / Consent (HS-MVP-SLICE-01)
    terms_accepted: bool = False,
    privacy_accepted: bool = False,
    terms_version: str | None = None,
    privacy_version: str | None = None,
    consent_ip: str | None = None,
    consent_user_agent: str | None = None,
) -> GuestSession:
    """Create an authorized guest internet session. Called by the PUBLIC
    captive flow after portal-token validation + firewall authorize. Caller
    passes the resolved site context explicitly.

    flush -> log_audit -> commit -> refresh, mirroring vouchers/identity.
    """
    now = datetime.now(timezone.utc)
    started_at = now
    expires_at = now + timedelta(minutes=duration_minutes) if duration_minutes else None

    mac = (mac or "").strip().upper()
    ip = (ip or "").strip() or None

    # A reconnect from the same client must replace the previous open
    # session. Otherwise a brief Wi-Fi roam leaves multiple rows marked
    # active and the concurrency limit rejects the legitimate reconnect.
    identity_conditions = []
    if mac:
        identity_conditions.append(GuestSession.mac == mac)
    if ip:
        identity_conditions.append(GuestSession.ip == ip)
    if identity_conditions:
        previous_result = await db.execute(
            select(GuestSession)
            .where(
                GuestSession.customer_id == customer_id,
                GuestSession.status.in_((STATUS_ACTIVE, STATUS_PENDING)),
                or_(*identity_conditions),
            )
            .with_for_update()
        )
        previous_scalars = previous_result.scalars()
        if inspect.isawaitable(previous_scalars):
            previous_scalars = await previous_scalars
        previous_rows = previous_scalars.all()
        if inspect.isawaitable(previous_rows):
            previous_rows = await previous_rows
        if isinstance(previous_rows, (list, tuple)):
            for previous in previous_rows:
                previous.status = STATUS_CLOSED
                previous.ended_at = now
                previous.authorization_status = AUTH_STATUS_REVOKED
                previous.revoked_at = now

    # Never expose a session as active before the firewall has confirmed the
    # authorization.  A failed device call remains pending so an operator can
    # retry synchronization, but it must not count as an online guest.
    effective_status = status

    session = GuestSession(
        id=session_id or uuid.uuid4(),
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        identity_verification_id=identity_verification_id,
        voucher_id=voucher_id,
        group_id=group_id,
        phone=phone,
        mac=mac,
        ip=ip,
        nas_ip=nas_ip,
        ssid=ssid,
        auth_method=auth_method,
        status=effective_status,
        started_at=started_at,
        expires_at=expires_at,
        authorize_ok=authorize_ok,
        authorize_message=authorize_message,
        meta=meta or {},
        terms_accepted=terms_accepted,
        terms_accepted_at=now if terms_accepted else None,
        privacy_accepted=privacy_accepted,
        privacy_accepted_at=now if privacy_accepted else None,
        terms_version=terms_version,
        privacy_version=privacy_version,
        consent_ip=consent_ip,
        consent_user_agent=consent_user_agent,
    )
    db.add(session)
    await db.flush()
    audit_details = {
        "customer_id": str(customer_id),
        "auth_method": auth_method,
        "status": status,
        "meta": _approval_audit_projection(meta),
    }
    if isinstance((meta or {}).get("approval"), dict):
        # A MAC is a personal identifier; approval audit rows only need a
        # stable correlation value, not the raw address.
        audit_details["mac_hash"] = hashlib.sha256(
            mac.encode("utf-8")
        ).hexdigest()[:16]
    else:
        audit_details["mac"] = mac
    await log_audit(
        db,
        "session.created",
        "guest_session",
        str(session.id),
        None,
        request,
        details=audit_details,
        tenant_id=str(customer_id),
    )
    await db.commit()
    await db.refresh(session)
    return session


async def count_active_sessions_for_identity(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    phone: str | None = None,
    mac: str | None = None,
) -> int:
    """Count active sessions for the same user identity.

    The portal flow uses this to enforce user-group concurrency caps before
    authorizing a new guest session.
    """
    now = datetime.now(timezone.utc)
    filters = [
        GuestSession.customer_id == customer_id,
        GuestSession.status == STATUS_ACTIVE,
        GuestSession.ended_at.is_(None),
        or_(GuestSession.expires_at.is_(None), GuestSession.expires_at > now),
    ]
    identity_filters = []
    if phone:
        identity_filters.append(GuestSession.phone == phone)
    if mac:
        identity_filters.append(GuestSession.mac == mac.strip().upper())
    if not identity_filters:
        return 0
    stmt = select(func.count()).select_from(GuestSession).where(*filters, or_(*identity_filters))
    result = await db.execute(stmt)
    return int(result.scalar_one() or 0)


async def get_identity_usage_today(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    mac: str | None = None,
    phone: str | None = None,
) -> int:
    """Sum total bytes transferred today (since 00:00 UTC) for this MAC / Phone."""
    from app.modules.syslog.models import FirewallLog

    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    
    filters = [
        GuestSession.customer_id == customer_id,
        GuestSession.started_at >= today_start - timedelta(hours=24),
    ]
    id_conds = []
    if mac:
        id_conds.append(GuestSession.mac == mac.strip().upper())
    if phone:
        id_conds.append(GuestSession.phone == phone)
    if not id_conds:
        return 0

    stmt = select(
        func.coalesce(func.sum(GuestSession.bytes_in + GuestSession.bytes_out), 0)
    ).where(*filters, or_(*id_conds))
    sess_bytes = int((await db.execute(stmt)).scalar_one() or 0)

    ips_stmt = select(GuestSession.ip).where(*filters, or_(*id_conds), GuestSession.ip.is_not(None)).distinct()
    ips = [r[0] for r in (await db.execute(ips_stmt)).all() if r[0]]
    
    fw_bytes = 0
    if ips:
        fw_stmt = select(
            func.coalesce(func.sum(FirewallLog.rcvdbyte + FirewallLog.sentbyte), 0)
        ).where(
            FirewallLog.src_ip.in_(ips),
            FirewallLog.effective_event_time >= today_start,
        )
        fw_bytes = int((await db.execute(fw_stmt)).scalar_one() or 0)

    return max(sess_bytes, fw_bytes)


async def get_identity_usage_month(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    mac: str | None = None,
    phone: str | None = None,
) -> int:
    """Sum total bytes transferred this month for this MAC / Phone."""
    now = datetime.now(timezone.utc)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    
    filters = [
        GuestSession.customer_id == customer_id,
        GuestSession.started_at >= month_start,
    ]
    id_conds = []
    if mac:
        id_conds.append(GuestSession.mac == mac.strip().upper())
    if phone:
        id_conds.append(GuestSession.phone == phone)
    if not id_conds:
        return 0

    stmt = select(
        func.coalesce(func.sum(GuestSession.bytes_in + GuestSession.bytes_out), 0)
    ).where(*filters, or_(*id_conds))
    return int((await db.execute(stmt)).scalar_one() or 0)


async def enforce_active_sessions_quota(db: AsyncSession) -> int:
    """Sweep active sessions, check quota limits, and revoke over-quota sessions."""
    from app.modules.syslog.models import FirewallLog
    from app.modules.firewall_adapters.service import revoke_guest_service
    
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    
    q = select(GuestSession).where(
        GuestSession.status == STATUS_ACTIVE,
        GuestSession.ended_at.is_(None),
    )
    active_sessions = list((await db.execute(q)).scalars().all())
    revoked_count = 0
    
    for s in active_sessions:
        group_policy = (s.meta or {}).get("group_policy")
        if not isinstance(group_policy, dict):
            continue
            
        daily_quota_mb = group_policy.get("daily_quota")
        if not daily_quota_mb:
            continue
            
        current_bytes = (s.bytes_in or 0) + (s.bytes_out or 0)
        if s.ip:
            fw_row = (await db.execute(
                select(
                    func.coalesce(func.sum(FirewallLog.rcvdbyte + FirewallLog.sentbyte), 0)
                ).where(
                    FirewallLog.src_ip == s.ip,
                    FirewallLog.effective_event_time >= today_start,
                )
            )).scalar_one()
            current_bytes = max(current_bytes, int(fw_row or 0))
            
        daily_limit_bytes = int(daily_quota_mb) * 1024 * 1024
        if current_bytes >= daily_limit_bytes:
            log.info("Session %s exceeded daily quota (%d >= %d bytes). Revoking.", s.id, current_bytes, daily_limit_bytes)
            s.status = STATUS_EXPIRED
            s.ended_at = now
            s.authorization_status = AUTH_STATUS_REVOKED
            s.authorize_message = f"Günlük kota aşıldı ({daily_quota_mb} MB)"
            revoked_count += 1
            if s.device_id:
                try:
                    await revoke_guest_service(
                        db, s.device_id, ScopeContext(level=TenantLevel.CUSTOMER, customer_id=s.customer_id),
                        {"session_id": str(s.id), "ip": s.ip, "mac": s.mac},
                    )
                except Exception as exc:
                    log.warning("Could not revoke session %s on firewall: %s", s.id, exc)
                    
    if revoked_count > 0:
        await db.commit()
        
    return revoked_count


# ---- scoped admin views --------------------------------------------------
async def get_session(
    db: AsyncSession, session_id: uuid.UUID, scope: ScopeContext
) -> GuestSession:
    q, allowed = await _scoped_query_async(db, scope)
    result = await db.execute(q.where(GuestSession.id == session_id))
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Oturum bulunamadi",
        )
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu oturuma erisim yetkiniz yok",
        )
    return session


async def list_pending_sessions(
    db: AsyncSession, scope: ScopeContext
) -> list[GuestSession]:
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        return []
    q = q.where(GuestSession.status == STATUS_PENDING)
    result = await db.execute(q.order_by(GuestSession.started_at.desc()))
    return list(result.scalars().all())


async def _apply_approval_locked(
    db: AsyncSession,
    session: GuestSession,
    *,
    actor_id: uuid.UUID | None,
    request: Request | None,
    source: str = "admin",
) -> bool:
    """Apply an approval to a row already locked by the caller.

    Returning ``False`` means the provider did not authorize the guest.  In
    that case the session stays pending, but a bearer decision is still
    consumed.  The authenticated admin action can retry the provider without
    reopening the public e-mail link.
    """
    now = datetime.now(timezone.utc)
    authorize_ok = True
    authorize_status = AUTH_STATUS_AUTHORIZED
    authorize_message = "Yönetici tarafından onaylandı"
    auth_err_msg = None

    if session.device_id:
        from app.modules.firewall_adapters.service import authorize_guest_service

        flow_scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=session.customer_id)
        session_payload = {
            "session_id": str(session.id),
            "mac": session.mac,
            "ip": session.ip,
            "username": session.phone or session.mac or "guest",
            "duration_minutes": max(
                1,
                int((session.expires_at - session.started_at).total_seconds() / 60),
            ) if session.expires_at and session.started_at else None,
        }
        group_policy = (session.meta or {}).get("group_policy")
        if isinstance(group_policy, dict):
            session_payload.update(group_policy)
        try:
            result = await authorize_guest_service(
                db, session.device_id, flow_scope, session_payload
            )
            if not result.ok:
                authorize_ok = False
                authorize_status = AUTH_STATUS_FAILED
                auth_err_msg = "firewall_authorization_failed"
                authorize_message = "Güvenlik duvarı yetkilendirmesi başarısız"
                log.warning("firewall authorize result not ok during approval")
        except Exception as exc:
            # Provider exceptions are not copied into logs or persisted
            # verbatim because they may contain request/credential material.
            log.warning("firewall authorize exception during approval: %s", type(exc).__name__)
            authorize_ok = False
            authorize_status = AUTH_STATUS_FAILED
            auth_err_msg = "firewall_provider_unavailable"
            authorize_message = "Güvenlik duvarına ulaşılamadı"
    else:
        # Manager approval is not an authorization primitive by itself. A
        # legacy/unbound row has no firewall target, so approving it must stay
        # pending and surface a durable binding error instead of claiming
        # network access merely because no adapter call was attempted.
        authorize_ok = False
        authorize_status = AUTH_STATUS_FAILED
        auth_err_msg = "device_binding_missing"
        authorize_message = "Portal cihazı eşleşmesi bulunamadı"

    session.status = STATUS_ACTIVE if authorize_ok else STATUS_PENDING
    session.authorize_ok = authorize_ok
    session.authorize_message = authorize_message
    session.authorization_status = authorize_status
    session.authorized_at = now if authorize_ok else None
    session.authorization_error_message = auth_err_msg
    session.authorization_attempts = (session.authorization_attempts or 0) + 1
    session.external_session_id = session.external_session_id or str(session.id)

    meta = dict(session.meta or {})
    approval = dict(meta.get("approval") or {})
    approval.setdefault("required", True)
    approval["last_attempt_at"] = now.isoformat()
    approval["last_attempt_decision"] = "approve"
    approval["last_attempt_source"] = source
    if authorize_ok:
        approval.update({
            "status": "approved",
            "decision": "approve",
            "decision_at": now.isoformat(),
            "token_used_at": now.isoformat() if approval.get("token_hash") else approval.get("token_used_at"),
            "approved_at": now.isoformat(),
            "approved_by": str(actor_id) if actor_id else None,
            "last_attempt_status": "succeeded",
            "last_attempt_error": None,
            "decision_outcome": "authorized",
        })
    else:
        # A public approval token is single-use even when the downstream
        # firewall is unavailable.  Persist the decision and usage timestamp
        # while keeping the session pending so no network access is reported
        # until a later authenticated retry succeeds.
        approval.update({
            "status": "pending",
            "last_attempt_status": "failed",
            "last_attempt_error": auth_err_msg or "firewall_authorization_failed",
        })
        if approval.get("token_hash"):
            approval.setdefault("decision", "approve")
            approval.setdefault("decision_at", now.isoformat())
            approval.setdefault("token_used_at", now.isoformat())
            approval["decision_outcome"] = "authorization_failed"
    meta["approval"] = approval
    session.meta = meta
    await db.flush()
    await log_audit(
        db,
        "session.approved" if authorize_ok else "session.approval_failed",
        "guest_session",
        str(session.id),
        str(actor_id) if actor_id else None,
        request,
        details=_approval_details(
            approval,
            decision="approve",
            outcome="approved" if authorize_ok else "failed",
            source=source,
        ),
        tenant_id=str(session.customer_id) if session.customer_id else None,
    )
    return authorize_ok


async def _apply_rejection_locked(
    db: AsyncSession,
    session: GuestSession,
    *,
    actor_id: uuid.UUID | None,
    request: Request | None,
    source: str = "admin",
) -> None:
    now = datetime.now(timezone.utc)
    session.status = STATUS_CLOSED
    session.ended_at = now
    session.authorize_ok = False
    session.authorize_message = "Yönetici onayı reddedildi"
    session.authorization_status = AUTH_STATUS_FAILED
    session.authorization_error_message = "manager_rejected"
    meta = dict(session.meta or {})
    approval = dict(meta.get("approval") or {})
    approval.setdefault("required", True)
    approval.update({
        "status": "rejected",
        "decision": "reject",
        "decision_at": now.isoformat(),
        "token_used_at": now.isoformat() if approval.get("token_hash") else approval.get("token_used_at"),
        "rejected_at": now.isoformat(),
        "rejected_by": str(actor_id) if actor_id else None,
        "last_attempt_source": source,
    })
    meta["approval"] = approval
    session.meta = meta
    await db.flush()
    await log_audit(
        db,
        "session.rejected",
        "guest_session",
        str(session.id),
        str(actor_id) if actor_id else None,
        request,
        details=_approval_details(
            approval, decision="reject", outcome="rejected", source=source
        ),
        tenant_id=str(session.customer_id) if session.customer_id else None,
    )


async def _expire_approval_locked(
    db: AsyncSession,
    session: GuestSession,
    *,
    request: Request | None,
) -> None:
    now = datetime.now(timezone.utc)
    session.status = STATUS_CLOSED
    session.ended_at = now
    session.authorize_ok = False
    session.authorize_message = "Yönetici onay bağlantısının süresi doldu"
    session.authorization_status = AUTH_STATUS_FAILED
    session.authorization_error_message = "approval_token_expired"
    meta = dict(session.meta or {})
    approval = dict(meta.get("approval") or {})
    approval.update({
        "status": "expired",
        "expired_at": now.isoformat(),
        "token_used_at": now.isoformat(),
    })
    meta["approval"] = approval
    session.meta = meta
    await db.flush()
    await log_audit(
        db,
        "session.approval_expired",
        "guest_session",
        str(session.id),
        None,
        request,
        details=_approval_details(
            approval, decision="none", outcome="expired", source="public_link"
        ),
        tenant_id=str(session.customer_id) if session.customer_id else None,
    )


async def inspect_approval_token(
    db: AsyncSession,
    session_id: uuid.UUID,
    token: str,
    *,
    decision: str = "approve",
) -> GuestSession:
    """Validate a public approval link without changing database state.

    The GET landing page uses this read-only path so mail scanners can never
    consume a decision.  Expiry is reported but only POST records the terminal
    ``expired`` state and its audit event.
    """
    try:
        canonical_decision = normalize_decision(decision)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not isinstance(token, str) or not token or token != token.strip():
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    session = await db.get(GuestSession, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Onay bağlantısı geçersiz")
    approval = (session.meta or {}).get("approval") or {}
    if not isinstance(approval, dict):
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    approval_customer_id = approval.get("customer_id")
    if approval_customer_id and str(approval_customer_id) != str(session.customer_id):
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    raw_token = token
    digest = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
    expected_digest = str(approval.get("token_hash") or "")
    if not expected_digest or not hmac.compare_digest(expected_digest, digest):
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    binding_digest = approval.get("token_binding_hash")
    if binding_digest:
        expected_binding = hashlib.sha256(
            f"{session.id}:{raw_token}".encode("utf-8")
        ).hexdigest()
        if not hmac.compare_digest(str(binding_digest), expected_binding):
            raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    recorded = approval.get("decision")
    try:
        recorded = normalize_decision(recorded) if recorded else None
    except ValueError:
        recorded = None
    if recorded and recorded != canonical_decision:
        raise HTTPException(status_code=409, detail="Onay bağlantısı başka bir kararla kullanıldı")
    if approval.get("status") == "expired":
        raise HTTPException(status_code=410, detail="Onay bağlantısının süresi doldu")
    if approval.get("token_used_at") and not recorded:
        raise HTTPException(status_code=409, detail="Onay bağlantısı daha önce kullanıldı")
    if approval.get("status") in {"approved", "rejected"} and not recorded:
        raise HTTPException(status_code=409, detail="Onay bağlantısı daha önce kullanıldı")
    expires_at = _approval_expiry(approval.get("token_expires_at"))
    if approval.get("token_expires_at") and expires_at is None:
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    if expires_at and expires_at <= datetime.now(timezone.utc):
        raise HTTPException(status_code=410, detail="Onay bağlantısının süresi doldu")
    if session.status != STATUS_PENDING and not recorded:
        raise HTTPException(status_code=409, detail="Oturum artık onay beklemiyor")
    return session


async def approve_session(
    db: AsyncSession,
    session_id: uuid.UUID,
    scope: ScopeContext,
    actor_id: uuid.UUID | None = None,
    request: Request | None = None,
) -> GuestSession:
    # Serialize approval attempts.  Without a row lock two manager clicks can
    # both observe `pending`, call the firewall and overwrite the outcome.
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu oturuma erisim yetkiniz yok",
        )
    session = (
        await db.execute(
            q.where(GuestSession.id == session_id).with_for_update()
        )
    ).scalar_one_or_none()
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Oturum bulunamadi"
        )
    if session.status != STATUS_PENDING:
        approval = (session.meta or {}).get("approval") or {}
        recorded = approval.get("decision") if isinstance(approval, dict) else None
        try:
            if recorded and normalize_decision(recorded) == "approve":
                return session
        except ValueError:
            pass
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Oturum onay bekliyor durumunda degil",
        )
    approval = (session.meta or {}).get("approval") or {}
    if isinstance(approval, dict):
        recorded = approval.get("decision")
        try:
            if recorded and normalize_decision(recorded) == "reject":
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Oturum başka bir kararla işaretlendi",
                )
        except ValueError:
            # A malformed legacy value is not treated as an authorization.
            pass
    await _apply_approval_locked(
        db, session, actor_id=actor_id, request=request, source="admin"
    )
    await db.commit()
    await db.refresh(session)
    return session


async def reject_session(
    db: AsyncSession,
    session_id: uuid.UUID,
    scope: ScopeContext,
    actor_id: uuid.UUID | None = None,
    request: Request | None = None,
) -> GuestSession:
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu oturuma erisim yetkiniz yok",
        )
    session = (
        await db.execute(
            q.where(GuestSession.id == session_id).with_for_update()
        )
    ).scalar_one_or_none()
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Oturum bulunamadi"
        )
    if session.status != STATUS_PENDING:
        approval = (session.meta or {}).get("approval") or {}
        recorded = approval.get("decision") if isinstance(approval, dict) else None
        try:
            if recorded and normalize_decision(recorded) == "reject":
                return session
        except ValueError:
            pass
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Oturum onay bekliyor durumunda degil",
        )
    approval = (session.meta or {}).get("approval") or {}
    if isinstance(approval, dict):
        recorded = approval.get("decision")
        try:
            if recorded and normalize_decision(recorded) == "approve":
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Oturum başka bir kararla işaretlendi",
                )
        except ValueError:
            # A malformed legacy value is not treated as an authorization.
            pass
    await _apply_rejection_locked(
        db, session, actor_id=actor_id, request=request, source="admin"
    )
    await db.commit()
    await db.refresh(session)
    return session


async def approve_session_by_token(
    db: AsyncSession,
    session_id: uuid.UUID,
    token: str,
    *,
    decision: str = "approve",
    request: Request | None = None,
) -> GuestSession:
    """Process a one-time manager e-mail decision without an admin JWT.

    The token is stored only as a SHA-256 digest in the session metadata.  A
    used digest is retained with a timestamp and decision so repeated clicks
    are deterministic (same decision is idempotent; the opposite decision is
    rejected) without retaining the bearer credential itself.
    """
    try:
        canonical_decision = normalize_decision(decision)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not isinstance(token, str) or not token or token != token.strip():
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")

    session = (
        await db.execute(
            select(GuestSession)
            .where(GuestSession.id == session_id)
            .with_for_update()
        )
    ).scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Onay bağlantısı geçersiz")
    approval = (session.meta or {}).get("approval") or {}
    if not isinstance(approval, dict):
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    approval_customer_id = approval.get("customer_id")
    if approval_customer_id and str(approval_customer_id) != str(session.customer_id):
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    raw_token = token
    digest = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
    expected_digest = str(approval.get("token_hash") or "")
    if not expected_digest or not hmac.compare_digest(expected_digest, digest):
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    # New links bind the digest to this exact session as well as retaining the
    # legacy SHA-256(token) value.  Old links without this field remain valid.
    binding_digest = approval.get("token_binding_hash")
    if binding_digest:
        expected_binding = hashlib.sha256(
            f"{session.id}:{raw_token}".encode("utf-8")
        ).hexdigest()
        if not hmac.compare_digest(str(binding_digest), expected_binding):
            raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")

    recorded_decision = approval.get("decision")
    try:
        recorded_decision = normalize_decision(recorded_decision) if recorded_decision else None
    except ValueError:
        recorded_decision = None
    used_at = approval.get("token_used_at")
    expires_at = _approval_expiry(approval.get("token_expires_at"))
    if approval.get("token_expires_at") and expires_at is None:
        raise HTTPException(status_code=403, detail="Onay bağlantısı geçersiz")
    if approval.get("status") == "expired":
        raise HTTPException(status_code=410, detail="Onay bağlantısının süresi doldu")
    if expires_at and expires_at <= datetime.now(timezone.utc):
        if not used_at and not recorded_decision:
            await _expire_approval_locked(db, session, request=request)
            await db.commit()
        # An expired bearer is never replayable, even when a prior decision
        # was recorded.  A previously active session remains unchanged; this
        # response only prevents another public mutation.
        raise HTTPException(status_code=410, detail="Onay bağlantısının süresi doldu")
    if used_at and not recorded_decision:
        raise HTTPException(status_code=409, detail="Onay bağlantısı daha önce kullanıldı")
    if approval.get("status") in {"approved", "rejected"} and not recorded_decision:
        raise HTTPException(status_code=409, detail="Onay bağlantısı daha önce kullanıldı")
    if used_at or recorded_decision:
        if recorded_decision == canonical_decision:
            # No firewall call or second audit mutation on a replay of the
            # same decision.  The row lock makes concurrent clicks converge.
            return session
        raise HTTPException(status_code=409, detail="Onay bağlantısı başka bir kararla kullanıldı")

    if session.status != STATUS_PENDING:
        raise HTTPException(status_code=409, detail="Oturum artık onay beklemiyor")

    if canonical_decision == "reject":
        await _apply_rejection_locked(
            db, session, actor_id=None, request=request, source="public_link"
        )
    else:
        authorize_ok = await _apply_approval_locked(
            db, session, actor_id=None, request=request, source="public_link"
        )
        if not authorize_ok:
            # The decision is consumed even though authorization failed.  The
            # session remains pending and an authenticated admin can retry the
            # firewall adapter without reopening the public bearer link.
            await db.commit()
            await db.refresh(session)
            return session
    await db.commit()
    await db.refresh(session)
    return session


async def list_online_sessions(
    db: AsyncSession, scope: ScopeContext
) -> list[GuestSession]:
    """List only truly active online guest sessions.
    
    1. Sweeps and closes expired sessions (leases past expires_at).
    2. Validates ended_at IS NULL and expires_at > now.
    3. Correlates live network traffic from FirewallLog to verify transmitting vs idle state.
    """
    now = datetime.now(timezone.utc)
    
    # 1. Sweep expired active sessions in background
    try:
        expired_stmt = (
            select(GuestSession)
            .where(
                GuestSession.status == STATUS_ACTIVE,
                or_(
                    and_(GuestSession.expires_at.is_not(None), GuestSession.expires_at <= now),
                    and_(GuestSession.expires_at.is_(None), GuestSession.started_at < now - timedelta(hours=24)),
                )
            )
        )
        expired_sessions = (await db.execute(expired_stmt)).scalars().all()
        for s in expired_sessions:
            if (s.expires_at and s.expires_at <= now) or (not s.expires_at and s.started_at and s.started_at < now - timedelta(hours=24)):
                s.status = STATUS_CLOSED
                s.ended_at = s.expires_at or now
        if expired_sessions:
            await db.commit()
    except Exception as e:
        log.warning("Session auto-sweep error: %s", e)

    # 2. Query scoped active sessions
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        return []
    q = q.where(
        GuestSession.status == STATUS_ACTIVE,
        GuestSession.ended_at.is_(None),
        or_(GuestSession.expires_at.is_(None), GuestSession.expires_at > now),
    )
    result = await db.execute(q.order_by(GuestSession.started_at.desc()))
    sessions = list(result.scalars().all())

    # 3. Live traffic, names & telemetry correlation
    try:
        from app.modules.syslog.models import FirewallLog
        from app.modules.devices.models import Device
        from app.modules.locations.models import Location

        dev_res = await db.execute(select(Device.id, Device.name, Device.location_id, Device.mgmt_ip, Device.api_host))
        devices_map = {}
        loc_device_map = {}
        ip_device_map = {}
        for d_id, d_name, d_loc_id, d_mgmt_ip, d_api_host in dev_res.all():
            devices_map[d_id] = d_name
            if d_loc_id:
                loc_device_map[d_loc_id] = d_name
            if d_mgmt_ip:
                ip_device_map[d_mgmt_ip] = d_name
            if d_api_host:
                ip_device_map[d_api_host] = d_name
        loc_res = await db.execute(select(Location.id, Location.name))
        locations_map = {row[0]: row[1] for row in loc_res.all()}

        for session in sessions:
            meta = dict(session.meta or {})
            dev_name = (
                devices_map.get(session.device_id)
                or loc_device_map.get(session.location_id)
                or (ip_device_map.get(session.nas_ip) if session.nas_ip else None)
                or meta.get("device_name")
            )
            loc_name = locations_map.get(session.location_id) or meta.get("location_name")
            if dev_name:
                meta["device_name"] = dev_name
                session.device_name = dev_name
            if loc_name:
                meta["location_name"] = loc_name
                session.location_name = loc_name

            full_name = (
                meta.get("form_data", {}).get("full_name")
                or meta.get("form_data", {}).get("fullName")
                or meta.get("full_name")
                or meta.get("user")
                or meta.get("username")
                or session.phone
            )
            if full_name:
                meta["full_name"] = full_name
                meta["user"] = full_name
                session.full_name = full_name
                session.username = full_name

            traffic_status = "transmitting"
            last_seen = session.started_at

            if session.ip:
                end_time = session.ended_at or now
                traffic_stmt = (
                    select(
                        func.coalesce(func.sum(FirewallLog.rcvdbyte), 0).label("bytes_in"),
                        func.coalesce(func.sum(FirewallLog.sentbyte), 0).label("bytes_out"),
                        func.max(FirewallLog.effective_event_time).label("last_seen"),
                        func.count().label("event_count"),
                    )
                    .where(
                        FirewallLog.src_ip == session.ip,
                        FirewallLog.effective_event_time >= session.started_at,
                        FirewallLog.effective_event_time <= end_time,
                    )
                )
                tr_row = (await db.execute(traffic_stmt)).first()
                if tr_row and tr_row[3] > 0:
                    fw_in = int(tr_row[0] or 0)
                    fw_out = int(tr_row[1] or 0)
                    session.bytes_in = max(session.bytes_in or 0, fw_in)
                    session.bytes_out = max(session.bytes_out or 0, fw_out)
                    if tr_row[2]:
                        last_seen = tr_row[2]
                        diff_min = (now - last_seen).total_seconds() / 60.0
                        if diff_min <= 15:
                            traffic_status = "transmitting"
                        elif diff_min <= 60:
                            traffic_status = "idle"
                        else:
                            traffic_status = "inactive"
                else:
                    diff_start = (now - session.started_at).total_seconds() / 60.0
                    if diff_start > 30:
                        traffic_status = "idle"

            total_bytes = int(session.bytes_in or 0) + int(session.bytes_out or 0)
            meta["live_telemetry"] = {
                "traffic_status": traffic_status,
                "last_seen": last_seen.isoformat() if last_seen else None,
                "is_active_transmitting": traffic_status == "transmitting",
                "total_bytes": total_bytes,
            }
            session.meta = meta
    except Exception as e:
        log.warning("Live telemetry correlation error: %s", e)

    return sessions


async def list_sessions(
    db: AsyncSession, scope: ScopeContext
) -> list[GuestSession]:
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        return []
    result = await db.execute(q.order_by(GuestSession.started_at.desc()))
    sessions = list(result.scalars().all())

    now = datetime.now(timezone.utc)
    try:
        from app.modules.devices.models import Device
        from app.modules.locations.models import Location
        from app.modules.syslog.models import FirewallLog

        dev_res = await db.execute(select(Device.id, Device.name, Device.location_id, Device.mgmt_ip, Device.api_host))
        devices_map = {}
        loc_device_map = {}
        ip_device_map = {}
        for d_id, d_name, d_loc_id, d_mgmt_ip, d_api_host in dev_res.all():
            devices_map[d_id] = d_name
            if d_loc_id:
                loc_device_map[d_loc_id] = d_name
            if d_mgmt_ip:
                ip_device_map[d_mgmt_ip] = d_name
            if d_api_host:
                ip_device_map[d_api_host] = d_name
        loc_res = await db.execute(select(Location.id, Location.name))
        locations_map = {row[0]: row[1] for row in loc_res.all()}

        for session in sessions:
            meta = dict(session.meta or {})
            dev_name = (
                devices_map.get(session.device_id)
                or loc_device_map.get(session.location_id)
                or (ip_device_map.get(session.nas_ip) if session.nas_ip else None)
                or meta.get("device_name")
            )
            loc_name = locations_map.get(session.location_id) or meta.get("location_name")
            if dev_name:
                meta["device_name"] = dev_name
                session.device_name = dev_name
            if loc_name:
                meta["location_name"] = loc_name
                session.location_name = loc_name

            full_name = (
                meta.get("form_data", {}).get("full_name")
                or meta.get("form_data", {}).get("fullName")
                or meta.get("full_name")
                or meta.get("user")
                or meta.get("username")
                or session.phone
            )
            if full_name:
                meta["full_name"] = full_name
                meta["user"] = full_name
                session.full_name = full_name
                session.username = full_name

            if session.ip:
                end_time = session.ended_at or now
                tr_row = (await db.execute(
                    select(
                        func.coalesce(func.sum(FirewallLog.rcvdbyte), 0),
                        func.coalesce(func.sum(FirewallLog.sentbyte), 0),
                    ).where(
                        FirewallLog.src_ip == session.ip,
                        FirewallLog.effective_event_time >= session.started_at,
                        FirewallLog.effective_event_time <= end_time,
                    )
                )).first()
                if tr_row and (tr_row[0] or tr_row[1]):
                    session.bytes_in = int(tr_row[0] or 0)
                    session.bytes_out = int(tr_row[1] or 0)
            session.meta = meta
    except Exception as e:
        log.warning("Session enrichment error: %s", e)

    return sessions


async def _revoke_on_firewall_background(
    session_id: uuid.UUID,
    device_id: uuid.UUID,
    ip: str | None,
    mac: str,
    scope: ScopeContext,
) -> None:
    """Fire-and-forget firewall revoke. Runs in a background task so the
    API response is not blocked by a slow/unreachable firewall."""
    try:
        from app.modules.firewall_adapters.service import revoke_guest_service
        from app.core.database import AsyncSessionLocal

        async with AsyncSessionLocal() as db:
            session = await db.get(GuestSession, session_id)
            group_name = "Guest"
            if session and isinstance(session.meta, dict):
                group_name = (session.meta.get("group_policy") or {}).get("group_name") or "Guest"
            await revoke_guest_service(
                db, device_id, scope,
                {"session_id": str(session_id), "ip": ip, "mac": mac, "group_name": group_name},
            )
            if session:
                session.authorization_status = AUTH_STATUS_REVOKED
                session.revoked_at = datetime.now(timezone.utc)
                session.authorize_ok = False
                session.is_active = False
                await db.commit()
    except Exception:
        log.warning("bg firewall revoke failed for session=%s", session_id, exc_info=True)


async def _disconnect_radius_background(
    session_id: uuid.UUID,
    location_id: uuid.UUID | None,
    nas_ip: str | None,
    radius_session_id: str | None,
    username: str | None,
    mac: str | None,
    user_ip: str | None,
) -> None:
    """Send RFC 5176 Disconnect-Request after a session is closed.

    The NAS secret is decrypted only inside this short-lived worker session;
    it is never returned to the API or written to logs. Missing RADIUS
    metadata is a valid deployment mode and simply skips the best-effort
    packet.
    """
    if not location_id or not nas_ip:
        return
    try:
        from app.core.crypto import decrypt
        from app.core.database import AsyncSessionLocal
        from app.modules.devices.models import RadiusClient
        from app.modules.radius.coa import send_coa_disconnect

        async with AsyncSessionLocal() as radius_db:
            client = (await radius_db.execute(
                select(RadiusClient).where(
                    RadiusClient.location_id == location_id,
                    RadiusClient.nas_ip == nas_ip,
                    RadiusClient.is_active.is_(True),
                ).limit(1)
            )).scalar_one_or_none()
            if not client:
                return
            secret = decrypt(client.shared_secret_encrypted)
        result = await send_coa_disconnect(
            nas_ip,
            secret,
            username=username,
            session_id=radius_session_id,
            user_ip=user_ip,
            mac_address=mac,
        )
        if not result.get("ok"):
            log.warning("RADIUS Disconnect-Request failed for session=%s: %s", session_id, result.get("message"))
    except Exception:
        log.warning("bg RADIUS disconnect failed for session=%s", session_id, exc_info=True)


async def close_session(
    db: AsyncSession,
    session_id: uuid.UUID,
    scope: ScopeContext,
    actor_id: uuid.UUID | None = None,
    request: Request | None = None,
    reason: str | None = None,
) -> GuestSession:
    """Close a guest session idempotently. Repeating the action for an
    already-closed session returns the existing row instead of surfacing a
    noisy 409 to the dashboard. On close:
      - duration computed from started_at -> ended_at
      - firewall revoke fired as background task
      - 5651 session summary audit event appended (append-only, not UPDATE)
    """
    session = await get_session(db, session_id, scope)
    if session.status == STATUS_CLOSED:
        return session
    now = datetime.now(timezone.utc)
    session.status = STATUS_CLOSED
    session.is_active = False
    session.authorize_ok = False
    session.authorization_status = AUTH_STATUS_REVOKED
    session.revoked_at = now
    session.ended_at = now
    if session.started_at:
        duration_sec = int((now - session.started_at).total_seconds())
    else:
        duration_sec = 0
    await db.flush()
    await log_audit(
        db,
        "session.closed",
        "guest_session",
        str(session_id),
        str(actor_id) if actor_id else None,
        request,
        details={"reason": reason, "duration_sec": duration_sec},
    )
    await log_audit(
        db,
        "5651.session_summary",
        "guest_session",
        str(session_id),
        str(actor_id) if actor_id else None,
        request,
        details={
            "reason": reason,
            "duration_sec": duration_sec,
            "bytes_in": session.bytes_in,
            "bytes_out": session.bytes_out,
            "mac": session.mac,
            "ip": session.ip,
            "phone": session.phone,
            "auth_method": session.auth_method,
            "started_at": session.started_at.isoformat() if session.started_at else None,
            "ended_at": now.isoformat(),
        },
    )
    await db.commit()
    await db.refresh(session)
    if session.device_id:
        asyncio.create_task(
            _revoke_on_firewall_background(
                session.id, session.device_id, session.ip, session.mac, scope,
            )
        )
    if session.nas_ip and session.location_id:
        asyncio.create_task(
            _disconnect_radius_background(
                session.id,
                session.location_id,
                session.nas_ip,
                session.radius_session_id,
                session.phone,
                session.mac,
                session.ip,
            )
        )
    return session


# ---- M5 expiry sweep (called by the worker scheduler) ---------------------
async def expire_due(db: AsyncSession, request: Request | None = None) -> int:
    """Flip active sessions past their expires_at or exceeding idle_timeout to STATUS_EXPIRED.

    Mutlak Kural #5 — sessions are NOT deleted; they are marked expired so the
    correlation chain (5651 archive, RADIUS, syslog) stays intact. Returns the
    count flipped. Called by the Celery beat worker (M6)."""
    from app.modules.syslog.models import FirewallLog
    from app.modules.firewall_adapters.service import revoke_guest_service
    from app.core.tenant import ScopeContext, TenantLevel

    now = datetime.now(timezone.utc)
    res = await db.execute(
        select(GuestSession).where(
            GuestSession.status == STATUS_ACTIVE,
            GuestSession.ended_at.is_(None),
        )
    )
    active_sessions = list(res.scalars().all())
    expired_count = 0

    for s in active_sessions:
        is_expired = False
        reason = ""

        # 1. Hard expiry by duration / expires_at (3 Gün / 4320 dk)
        if s.expires_at and s.expires_at < now:
            is_expired = True
            reason = "Oturum süresi doldu"

        # 2. Idle timeout (Boşta Kapatma: 30 dk)
        if not is_expired:
            group_policy = (s.meta or {}).get("group_policy")
            if isinstance(group_policy, dict):
                idle_minutes = group_policy.get("idle_timeout")
                if idle_minutes and int(idle_minutes) > 0:
                    last_active = s.started_at
                    if s.ip:
                        max_fw = (await db.execute(
                            select(func.max(FirewallLog.effective_event_time)).where(
                                FirewallLog.src_ip == s.ip,
                                FirewallLog.effective_event_time >= s.started_at,
                            )
                        )).scalar_one_or_none()
                        if max_fw:
                            last_active = max_fw

                    idle_delta = (now - last_active).total_seconds() / 60.0
                    if idle_delta >= int(idle_minutes):
                        is_expired = True
                        reason = f"Boşta kalma süresi ({idle_minutes} dk) aşıldı"

        if is_expired:
            s.status = STATUS_EXPIRED
            s.ended_at = now
            s.authorization_status = AUTH_STATUS_REVOKED
            s.authorize_message = reason
            expired_count += 1
            if s.device_id:
                try:
                    await revoke_guest_service(
                        db, s.device_id, ScopeContext(level=TenantLevel.CUSTOMER, customer_id=s.customer_id),
                        {"session_id": str(s.id), "ip": s.ip, "mac": s.mac},
                    )
                except Exception as exc:
                    log.warning("Could not revoke session %s on firewall: %s", s.id, exc)

    if expired_count > 0:
        await log_audit(
            db,
            "session.expired_batch",
            "guest_session",
            None,
            None,
            request,
            details={"count": expired_count},
        )
        await db.commit()
    return expired_count
