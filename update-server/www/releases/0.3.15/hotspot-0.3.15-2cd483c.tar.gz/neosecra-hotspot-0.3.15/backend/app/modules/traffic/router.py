
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.traffic import service

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


@router.get("/trend", summary="Get network traffic trend data over a period", description="Returns traffic volume trend data including upload and download metrics over the specified number of days. Useful for capacity planning and usage analysis. Requires the report.read permission.")
@router.get("/traffic/trend", include_in_schema=False)
async def traffic_trend(
    days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    if scope.customer_id is None and scope.level.value == "global":
        scope.customer_id = getattr(user, "customer_id", None) or await resolve_installation_customer(db)
    return await service.get_traffic_trend(db, scope, days)


@router.get("/dashboard", summary="Get traffic dashboard summary data", description="Returns a real-time traffic dashboard summary including current bandwidth usage, top talkers, and traffic distribution across locations. Requires the report.read permission.")
@router.get("/traffic/dashboard", include_in_schema=False)
async def traffic_dashboard(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    if scope.customer_id is None and scope.level.value == "global":
        scope.customer_id = getattr(user, "customer_id", None) or await resolve_installation_customer(db)
    return await service.get_traffic_dashboard(db, scope)


@router.get("/live-stream", summary="Get real-time Grafana/SOC traffic telemetry stream")
@router.get("/traffic/live-stream", include_in_schema=False)
async def live_traffic_stream(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    if scope.customer_id is None and scope.level.value == "global":
        scope.customer_id = getattr(user, "customer_id", None) or await resolve_installation_customer(db)
    return await service.get_live_traffic_stream(db, scope)
