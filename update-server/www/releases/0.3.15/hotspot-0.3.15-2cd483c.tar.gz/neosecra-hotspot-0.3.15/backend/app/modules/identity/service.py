"""Identity verification issuers + portal token exchange.

This is the orchestration record the PUBLIC captive flow produces after
SMS/TC/Voucher succeeds. The portal token is later exchanged (start-session)
for a guest session. Append-only in spirit: once issued it is only consumed,
never edited (Mutluk Kural #4 — append-only event approach for identity proofs).

Public-flow callers pass customer_id (required) + location_id/device_id (from
device resolution) explicitly — no admin JWT here, scope is derived from the
device the guest is behind (Mutlak Kural #1/#2 — tenant isolation extends to
the guest auth path).

Security:
  * TC Kimlik No is NEVER stored plaintext and NEVER returned in any schema —
    only a salted sha256 (sms `_hash_code` style).
  * portal_token is returned ONLY in PortalTokenOut at issue time; not in
    IdentityOut (admin/support view) (Mutlak Kural #3 — secrets not exposed).
"""
from __future__ import annotations

import hashlib
import logging
import re
import secrets
import uuid
import json
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import false, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.crypto import encrypt
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.identity.models import (
    METHOD_FREE,
    METHOD_SMS,
    METHOD_TC,
    METHOD_VOUCHER,
    METHOD_PMS,
    METHOD_WHATSAPP,
    METHOD_MEETING,
    METHOD_FOREIGNER,
    METHOD_LOCAL,
    METHOD_LDAP,
    METHOD_RADIUS,
    IdentityVerification,
)
from app.modules.identity.tc_validation import is_valid_turkish_identity_number
from app.modules.locations.models import Location
from app.modules.sms.models import SmsOtp
from app.modules.vouchers.models import Voucher
from app.modules.whatsapp.models import WhatsAppVerification

log = logging.getLogger(__name__)

_TC_DIGITS_RE = re.compile(r"\D")


# ---- helpers ---------------------------------------------------------------
def _hash_phone(phone: str) -> str:
    """Unsalted sha256 for anonymized phone lookup (phone is already low-risk
    normalized E.164; needed so sessions/audit can correlate by phone)."""
    return hashlib.sha256(phone.encode()).hexdigest()


def _hash_tc(tc: str) -> str:
    """Salted sha256 — TC is sensitive PII, NEVER stored plaintext. Mirrors
    sms.service._hash_code (salt$sha256hex)."""
    salt = secrets.token_hex(8)
    digest = hashlib.sha256(f"{salt}:{tc}".encode()).hexdigest()
    return f"{salt}${digest}"


def _mask_phone(phone: str | None) -> str | None:
    # +905xx***xx** — enough for support triage, not for re-identification.
    if not phone:
        return None
    return phone[:6] + "***" + phone[-2:] if len(phone) >= 8 else "***"


def _client_ip(request: Request | None) -> str | None:
    return request.client.host if request and request.client else None


def _new_token() -> str:
    return secrets.token_urlsafe(32)


# ---- core issuer -----------------------------------------------------------
async def _issue(
    db: AsyncSession,
    *,
    method: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    phone: str | None = None,
    tc_number: str | None = None,
    otp_id: uuid.UUID | None = None,
    voucher_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
    legal_evidence: dict | None = None,
) -> IdentityVerification:
    """Build + persist an IdentityVerification row (portal token issuance).

    flush -> log_audit -> commit -> refresh, mirroring sms/vouchers flow so the
    audit row lives within the caller's transaction.
    """
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=settings.PORTAL_TOKEN_TTL_SECONDS)
    iv = IdentityVerification(
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        method=method,
        phone=phone,
        phone_hash=_hash_phone(phone) if phone else None,
        tc_number_hash=_hash_tc(tc_number) if tc_number else None,
        otp_id=otp_id,
        voucher_id=voucher_id,
        verified=True,
        portal_token=_new_token(),
        portal_token_expires_at=expires_at,
        request_ip=_client_ip(request),
        form_data=form_data or {},
        identity_evidence_encrypted=(
            encrypt(json.dumps(legal_evidence, ensure_ascii=False, sort_keys=True))
            if legal_evidence else None
        ),
    )
    db.add(iv)
    await db.flush()
    await log_audit(
        db, "identity.issued", "identity_verification", str(iv.id), None, request,
        details={
            "method": method,
            "customer_id": str(customer_id),
            "phone": _mask_phone(phone) if phone else None,
        },
    )
    await db.commit()
    await db.refresh(iv)
    return iv


# ---- public-flow issuers (called by the portal flow) ----------------------
async def issue_for_sms(
    db: AsyncSession,
    *,
    otp: SmsOtp,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    """Issue after SMS OTP verify succeeds. Requires otp.verified True."""
    if not otp.verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="SMS dogrulamasi tamamlanmamis.",
        )
    return await _issue(
        db,
        method=METHOD_SMS,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        phone=otp.phone,
        otp_id=otp.id,
        request=request,
        form_data=form_data,
    )


async def issue_for_voucher(
    db: AsyncSession,
    *,
    voucher: Voucher,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    """Issue after voucher redeem succeeds."""
    return await _issue(
        db,
        method=METHOD_VOUCHER,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        voucher_id=voucher.id,
        request=request,
        form_data=form_data,
    )


async def issue_for_tc(
    db: AsyncSession,
    *,
    tc_number: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    """Issue after TC Kimlik No validation. Normalize digits first; fail 400 if
    invalid. TC stored only as salted hash (never plaintext)."""
    digits = _TC_DIGITS_RE.sub("", tc_number or "")
    if not is_valid_turkish_identity_number(digits):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Gecersiz TC Kimlik No",
        )
    return await _issue(
        db,
        method=METHOD_TC,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        tc_number=digits,
        request=request,
        form_data=form_data,
        legal_evidence={"document_type": "tc_kimlik", "national_id": digits},
    )


async def issue_for_whatsapp(
    db: AsyncSession,
    *,
    wa: WhatsAppVerification,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    """Issue after WhatsApp code verify succeeds. Requires wa.verified True."""
    if not wa.verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="WhatsApp dogrulamasi tamamlanmamis.",
        )
    return await _issue(
        db,
        method=METHOD_WHATSAPP,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        phone=wa.phone,
        otp_id=wa.id,
        request=request,
        form_data=form_data,
    )


async def issue_for_pms(
    db: AsyncSession,
    *,
    room_number: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    """Issue after Hotel PMS stay verification succeeds.
    Room number is stored for admin session listing."""
    return await _issue(
        db,
        method=METHOD_PMS,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        phone=f"Oda {room_number}",
        request=request,
        form_data=form_data,
    )


async def issue_free(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    """Issue for free/no-identity portal flows (open guest access)."""
    return await _issue(
        db,
        method=METHOD_FREE,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        request=request,
        form_data=form_data,
    )


async def issue_for_ldap(
    db: AsyncSession,
    *,
    username: str,
    display_name: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    """Issue after LDAP/AD authentication succeeds.
    Username is stored as phone with "LDAP: " prefix for session tracking."""
    return await _issue(
        db,
        method=METHOD_LDAP,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        phone=f"LDAP: {username} ({display_name})",
        request=request,
        form_data=form_data,
    )


async def issue_for_radius(
    db: AsyncSession,
    *,
    username: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    """Issue a portal identity after a successful RADIUS Access-Accept."""
    return await _issue(
        db,
        method=METHOD_RADIUS,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        phone=f"RADIUS: {username}",
        request=request,
        form_data=form_data,
    )


async def issue_for_meeting(
    db: AsyncSession,
    *,
    meeting_code: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    return await _issue(
        db,
        method=METHOD_MEETING,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        phone=f"Toplanti {meeting_code}",
        request=request,
        form_data=form_data,
    )


async def issue_for_foreigner(
    db: AsyncSession,
    *,
    passport_number: str,
    full_name: str,
    country: str,
    email: str | None = None,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    return await _issue(
        db,
        method=METHOD_FOREIGNER,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        # ``phone`` is the legacy identity display/correlation field used by
        # the session and admin contracts for non-SMS methods as well. Keep
        # the passport value here for backwards compatibility; the optional
        # email belongs in the bounded form/legal evidence payload, not in a
        # field that is used to identify the guest on the network.
        phone=passport_number,
        request=request,
        form_data=form_data,
        legal_evidence={
            "document_type": "passport",
            "passport_no": passport_number,
            "full_name": full_name,
            "country": country,
        },
    )


async def issue_for_local(
    db: AsyncSession,
    *,
    username: str,
    display_name: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
    request: Request | None = None,
    form_data: dict | None = None,
) -> IdentityVerification:
    return await _issue(
        db,
        method=METHOD_LOCAL,
        customer_id=customer_id,
        location_id=location_id,
        device_id=device_id,
        phone=username,
        request=request,
        form_data=form_data,
    )


# ---- token exchange (start-session) ---------------------------------------
async def validate_portal_token(
    db: AsyncSession,
    *,
    token: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    device_id: uuid.UUID | None = None,
) -> IdentityVerification:
    """Validate the portal token bound to a customer before exchanging it for a
    guest session. Fail-closed: no match -> 401, expired -> 410."""
    filters = [
        IdentityVerification.portal_token == token,
        IdentityVerification.customer_id == customer_id,
        IdentityVerification.consumed_at.is_(None),
    ]
    if location_id is not None:
        filters.append(IdentityVerification.location_id == location_id)
    if device_id is not None:
        # Canonical captive tokens are device-bound. Legacy rows without a
        # device are intentionally not exchangeable through this flow.
        filters.append(IdentityVerification.device_id == device_id)
    iv = (
        await db.execute(
            select(IdentityVerification).where(*filters)
            # The caller consumes this row after the full captive flow. Hold a
            # transaction lock across that flow to prevent token replay.
            .with_for_update()
        )
    ).scalar_one_or_none()
    if not iv:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Gecersiz veya suresi dolmus portal token",
        )
    if iv.portal_token_expires_at < datetime.now(timezone.utc):
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="Portal token suresi doldu",
        )
    return iv


async def consume(db: AsyncSession, *, iv_id: uuid.UUID) -> None:
    """Mark an IdentityVerification consumed once it has been exchanged for a
    guest session. Idempotent (append-only spirit: consumed once only)."""
    iv = await db.get(IdentityVerification, iv_id)
    if iv and not iv.consumed_at:
        iv.consumed_at = datetime.now(timezone.utc)
        await db.commit()


# ---- scoped query (admin/support views, customer axis — mirrors vouchers) -
async def _scoped_query_async(db: AsyncSession, scope: ScopeContext):
    """Scope query that may need a DB lookup (location -> customer). Fail-closed
    for a scoped role with no assignment."""
    q = select(IdentityVerification)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = q.join(Customer, IdentityVerification.customer_id == Customer.id)
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(IdentityVerification.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        loc = (
            await db.execute(select(Location).where(Location.id == scope.location_id))
        ).scalar_one_or_none()
        if not loc:
            return q.where(false()), False
        return q.where(IdentityVerification.customer_id == loc.customer_id), True
    return q.where(false()), False


async def list_for_admin(db: AsyncSession, scope: ScopeContext) -> list[IdentityVerification]:
    q, allowed = await _scoped_query_async(db, scope)
    if not allowed:
        return []
    result = await db.execute(q.order_by(IdentityVerification.created_at.desc()))
    return list(result.scalars().all())


async def get_for_admin(
    db: AsyncSession, iv_id: uuid.UUID, scope: ScopeContext
) -> IdentityVerification:
    q, allowed = await _scoped_query_async(db, scope)
    result = await db.execute(q.where(IdentityVerification.id == iv_id))
    iv = result.scalar_one_or_none()
    if not iv:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kimlik dogrulama kaydi bulunamadi",
        )
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu kayda erisim yetkiniz yok",
        )
    return iv
