"""Customer licensing / quota (Mutlak Kural #12 — licensing domain).

One row per customer (1:1). Quota fields gate the captive flow:
  * active_guests_quota   — max CONCURRENT active sessions (UNLIMITED = -1)
  * max_sessions_per_day  — daily new-session cap (None = unlimited)
  * session_minutes_default — overrides settings.GUEST_SESSION_DEFAULT_MINUTES
  * expires_at            — license expiry; an expired license blocks new sessions

The portal flow calls licensing.service.enforce_quota BEFORE creating a session.
A missing license row is tolerated only by development/test compatibility
fixtures; production captive sessions require the signed platform license.
The legacy row remains for administrative migration and reporting.
"""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import TimestampMixin, UUIDPK

# Sentinel for "no limit". Stored as -1 so the column stays NOT NULL and a
# simple `quota >= 0` check gates enforcement.
UNLIMITED = -1


class CustomerLicense(Base, UUIDPK, TimestampMixin):
    """1:1 license/quota row per customer. RESTRICT on customer so a license
    is never silently lost; SoftDelete-free — quotas are operational config,
    deactivation is via is_active."""

    __tablename__ = "customer_licenses"

    customer_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("customers.id", ondelete="RESTRICT"),
        nullable=False,
        unique=True,
        index=True,
    )
    active_guests_quota: Mapped[int] = mapped_column(Integer, default=UNLIMITED, nullable=False)
    max_sessions_per_day: Mapped[int | None] = mapped_column(Integer, nullable=True)
    session_minutes_default: Mapped[int | None] = mapped_column(Integer, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    is_trial: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_radius_enterprise: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    plan: Mapped[str] = mapped_column(String(40), default="default", nullable=False)
    meta: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
