import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import ScopeContext, TenantLevel, customer_in_scope, scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.ban import service
from app.modules.ban.schemas import (
    BanRuleCreate,
    BanRuleOut,
    BanRuleUpdate,
    WhitelistEntryCreate,
    WhitelistEntryOut,
)

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


async def _scope_with_customer(db: AsyncSession, user: User) -> ScopeContext:
    """Resolve the installation customer for global admin sessions."""
    scope = scope_for(user)
    if scope.level == TenantLevel.GLOBAL and scope.customer_id is None:
        scope.customer_id = await resolve_installation_customer(db)
    return scope


async def _resolve_customer_id(
    db: AsyncSession, scope: ScopeContext, requested: uuid.UUID | None
) -> uuid.UUID:
    """Resolve an optional form customer while preserving tenant boundaries."""
    if scope.level == TenantLevel.GLOBAL:
        # Global operators still act on this installation's customer only.
        # Resolve that anchor first; passing a form UUID into the resolver
        # would otherwise make an unconfigured single-installation deployment
        # accept an arbitrary customer id.
        installation_customer = await resolve_installation_customer(db)
        if requested is not None and requested != installation_customer:
            raise HTTPException(status_code=403, detail="Bu kurulumun müşterisi dışında işlem yapılamaz")
        return installation_customer
    if requested is None:
        if scope.customer_id is not None:
            return scope.customer_id
        raise HTTPException(status_code=400, detail="Müşteri scope'u gerekli")
    if not await customer_in_scope(db, scope, requested):
        raise HTTPException(status_code=403, detail="Bu musteriye erisim yetkiniz yok")
    return requested


# ---- Ban Rules ----


@router.get("/bans", response_model=list[BanRuleOut], summary="List all ban rules for the current tenant", description="Returns all configured ban rules that block or restrict guest access. Includes match criteria, duration, and active status. Requires a valid access token.")
async def list_bans(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.list_bans(db, await _scope_with_customer(db, user))


@router.post("/bans", response_model=BanRuleOut, status_code=status.HTTP_201_CREATED, summary="Create a new ban rule", description="Creates a new ban rule that blocks specified MAC addresses, IP addresses, or other criteria from accessing the network. Requires the customer.write permission.")
async def create_ban(
    body: BanRuleCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    scope = await _scope_with_customer(db, user)
    customer_id = await _resolve_customer_id(db, scope, body.customer_id)
    return await service.create_ban(db, body.model_copy(update={"customer_id": customer_id}), scope, user)


@router.get("/bans/{ban_id}", response_model=BanRuleOut, summary="Retrieve a single ban rule by ID", description="Fetches details of a specific ban rule including match criteria, duration, and creation information. Access is scoped to the user's tenant.")
async def get_ban(
    ban_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_ban(db, ban_id, await _scope_with_customer(db, user))


@router.put("/bans/{ban_id}", response_model=BanRuleOut, summary="Update an existing ban rule", description="Modifies the specified ban rule's settings such as match pattern, duration, or active status. Requires the customer.write permission.")
async def update_ban(
    ban_id: uuid.UUID,
    body: BanRuleUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    return await service.update_ban(db, ban_id, body, await _scope_with_customer(db, user))


@router.delete("/bans/{ban_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete a ban rule", description="Permanently removes the specified ban rule. Previously blocked clients will not be automatically unblocked. Requires the customer.write permission.")
async def delete_ban(
    ban_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    await service.delete_ban(db, ban_id, await _scope_with_customer(db, user))


# ---- Whitelist ----


@router.get("/whitelist", response_model=list[WhitelistEntryOut], summary="List all whitelist entries for the current tenant", description="Returns all whitelist entries that are exempt from ban rules. Whitelisted MACs or IPs bypass access restrictions. Requires a valid access token.")
async def list_whitelist(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.list_whitelist(db, await _scope_with_customer(db, user))


@router.post("/whitelist", response_model=WhitelistEntryOut, status_code=status.HTTP_201_CREATED, summary="Create a new whitelist entry", description="Adds a MAC address or IP to the whitelist, exempting it from ban rules and access restrictions. Requires the customer.write permission.")
async def create_whitelist_entry(
    body: WhitelistEntryCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    scope = await _scope_with_customer(db, user)
    customer_id = await _resolve_customer_id(db, scope, body.customer_id)
    return await service.create_whitelist_entry(
        db, body.model_copy(update={"customer_id": customer_id}), scope
    )


@router.delete("/whitelist/{entry_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Remove a whitelist entry", description="Deletes the specified whitelist entry, removing the exemption for that MAC address or IP. Requires the customer.write permission.")
async def delete_whitelist_entry(
    entry_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    await service.delete_whitelist_entry(db, entry_id, await _scope_with_customer(db, user))
