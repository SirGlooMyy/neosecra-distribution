"""TUBITAK KamuSM digital signing service for 5651 archives.

Supports three signing methods:
  * kamusm    — remote API via TUBITAK KamuSM (https://kamusm.tubitak.gov.tr)
  * localfile — local certificate file (.p12/.pfx) via cryptography
  * pkcs11    — hardware token (PKCS#11) — stub, requires future integration

Per Mutlak Kural #3, signing passwords are encrypted at rest using
app.core.crypto (Fernet). The signing config lives in CustomerLicense.meta
under the "kamusm_config" key so each customer has independent signing
credentials. In explicit demo mode when no KamuSM is configured, a mock
signature is returned.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import demo_mode_enabled, settings
from app.core.crypto import decrypt, encrypt
from app.modules.audit.service import log_audit
from app.modules.licensing.models import CustomerLicense
from app.modules.logs_5651.models import (
    SIGN_METHOD_KAMUSM,
    SIGN_METHOD_LOCALFILE,
    SIGN_METHOD_PKCS11,
    ArchiveRecord,
)
from app.modules.logs_5651.schemas import KamuSmConfigOut, SignResult

log = logging.getLogger(__name__)

_CONFIG_KEY = "kamusm_config"
_SIGNATURE_ORIGIN_KAMUSM = "kamusm"
_SIGNATURE_ORIGIN_LOCALFILE = "localfile"
_SIGNATURE_ORIGIN_DEMO = "demo"


# ---- config helpers -----------------------------------------------------------


def _default_config() -> dict:
    return {
        "is_configured": False,
        "sign_method": SIGN_METHOD_KAMUSM,
        "kamusm_username": "",
        "kamusm_password_encrypted": "",
        "certificate_path": "",
        "certificate_password_encrypted": "",
        "certificate_serial": "",
        "certificate_issuer": "",
        "certificate_subject": "",
        "last_signed_at": None,
        "last_signed_archive_id": None,
        "last_signature_origin": None,
    }


async def _get_config(db: AsyncSession, customer_id: uuid.UUID) -> dict:
    res = await db.execute(
        select(CustomerLicense).where(CustomerLicense.customer_id == customer_id)
    )
    lic = res.scalar_one_or_none()
    if not lic:
        return _default_config()
    cfg = lic.meta.get(_CONFIG_KEY) or {}
    return {**_default_config(), **cfg}


async def _save_config(
    db: AsyncSession, customer_id: uuid.UUID, cfg: dict
) -> CustomerLicense:
    res = await db.execute(
        select(CustomerLicense).where(CustomerLicense.customer_id == customer_id)
    )
    lic = res.scalar_one_or_none()
    if lic is None:
        from app.modules.licensing.models import CustomerLicense as CL

        lic = CL(customer_id=customer_id, plan="default", meta={})
        db.add(lic)
        await db.flush()
    meta = dict(lic.meta or {})
    meta[_CONFIG_KEY] = cfg
    lic.meta = meta
    await db.flush()
    return lic


# ---- password encryption wrappers ---------------------------------------------


def _encrypt_signing_password(password: str) -> str:
    if not password:
        return ""
    return encrypt(password)


def _decrypt_signing_password(encrypted: str) -> str:
    if not encrypted:
        return ""
    return decrypt(encrypted)


# ---- real appliance RSA-2048 keypair & local certificate signing -------------

_APPLIANCE_KEY_CACHE: dict[str, tuple[any, str]] = {}


def _get_or_create_appliance_keypair(customer_id: uuid.UUID | str) -> tuple[any, str]:
    """Generates or loads a real, persistent RSA-2048 cryptographic keypair for local 5651 digital signing."""
    cid_str = str(customer_id)
    if cid_str in _APPLIANCE_KEY_CACHE:
        return _APPLIANCE_KEY_CACHE[cid_str]

    import os
    import datetime as dt
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization, hashes
    from cryptography import x509
    from cryptography.x509.oid import NameOID

    keys_dir = os.path.join(settings.ARCHIVE_LOCAL_DIR, "keys")
    os.makedirs(keys_dir, exist_ok=True)
    key_path = os.path.join(keys_dir, f"appliance_{cid_str}_rsa.key")
    cert_path = os.path.join(keys_dir, f"appliance_{cid_str}_cert.pem")

    key_pass = hashlib.sha256(f"neosecra:5651:rsa:{settings.SECRET_KEY}:{cid_str}".encode()).digest()

    if os.path.exists(key_path) and os.path.exists(cert_path):
        try:
            # Tighten file permissions to 0600
            try:
                os.chmod(key_path, 0o600)
            except OSError:
                log.warning("Appliance key permissions could not be tightened: %s", key_path)
            with open(key_path, "rb") as f:
                key_bytes = f.read()
            try:
                private_key = serialization.load_pem_private_key(key_bytes, password=key_pass)
            except (ValueError, TypeError):
                # Fallback to unencrypted key for legacy backward compatibility, then migrate to encrypted format
                private_key = serialization.load_pem_private_key(key_bytes, password=None)
                with open(key_path, "wb") as f:
                    f.write(
                        private_key.private_bytes(
                            encoding=serialization.Encoding.PEM,
                            format=serialization.PrivateFormat.PKCS8,
                            encryption_algorithm=serialization.BestAvailableEncryption(key_pass),
                        )
                    )
                try:
                    os.chmod(key_path, 0o600)
                except OSError:
                    pass
            with open(cert_path, "rb") as f:
                cert = x509.load_pem_x509_certificate(f.read())
            serial_hex = format(cert.serial_number, "X")
            _APPLIANCE_KEY_CACHE[cid_str] = (private_key, serial_hex)
            return private_key, serial_hex
        except Exception as exc:
            log.warning("Existing appliance key could not be loaded, re-generating: %s", exc)

    # Generate genuine 2048-bit RSA Private Key
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )

    # Generate genuine self-signed X.509 Certificate for 5651 Legal Digital Signing
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "TR"),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "Turkiye"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "NeoSecra 5651 Kriptografik Muhur Sistemi"),
        x509.NameAttribute(NameOID.COMMON_NAME, f"NeoSecra 5651 Local CA ({cid_str[:8]})"),
    ])

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=1))
        .not_valid_after(dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=365 * 10))
        .sign(private_key, hashes.SHA256())
    )

    with open(key_path, "wb") as f:
        f.write(
            private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.BestAvailableEncryption(key_pass),
            )
        )
    try:
        os.chmod(key_path, 0o600)
    except OSError:
        log.warning("Appliance key permissions could not be tightened: %s", key_path)
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    serial_hex = format(cert.serial_number, "X")
    _APPLIANCE_KEY_CACHE[cid_str] = (private_key, serial_hex)
    return private_key, serial_hex


def _sign_with_appliance_key(content_hash: str, customer_id: uuid.UUID) -> dict:
    """Sign content hash using the appliance's genuine local RSA-2048 private key."""
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding

    private_key, cert_serial = _get_or_create_appliance_keypair(customer_id)
    signature = private_key.sign(
        content_hash.encode("utf-8"),
        padding.PKCS1v15(),
        hashes.SHA256(),
    )
    return {
        "signature_value": base64.b64encode(signature).decode(),
        "signing_time": datetime.now(timezone.utc),
        "certificate_serial": f"NEOSECRA-RSA2048-{cert_serial[:12]}",
        "signature_origin": _SIGNATURE_ORIGIN_LOCALFILE,
    }


# ---- real KamuSM API call -----------------------------------------------------


async def _sign_kamusm_api(content_hash: str, username: str, password: str) -> dict:
    """POST to TUBITAK KamuSM signing API."""
    import httpx

    url = settings.TUBITAK_KAMUSM_API_URL
    payload = {
        "content_hash": content_hash,
        "username": username,
        "password": password,
        "algorithm": "SHA-256",
        "signature_format": "PKCS7",
    }
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()
        return {
            "signature_value": data["signature_value"],
            "signing_time": datetime.fromisoformat(data["signing_time"]),
            "certificate_serial": data["certificate_serial"],
            "signature_origin": _SIGNATURE_ORIGIN_KAMUSM,
        }


# ---- local certificate signing ------------------------------------------------


def _sign_with_local_cert(
    content_hash: str,
    cert_path: str,
    key_password: str,
    customer_id: uuid.UUID | None = None,
) -> dict:
    """Sign content hash using a local PKCS#12 (.p12/.pfx) certificate file or fallback to appliance key."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, rsa
        from cryptography.hazmat.primitives.serialization import pkcs12

        with open(cert_path, "rb") as fh:
            p12_data = fh.read()

        private_key, certificate, _ = pkcs12.load_key_and_certificates(
            p12_data, key_password.encode() if key_password else None
        )
        if private_key is not None and isinstance(private_key, rsa.RSAPrivateKey) and certificate is not None:
            signature = private_key.sign(
                content_hash.encode("utf-8"),
                padding.PKCS1v15(),
                hashes.SHA256(),
            )
            cert_serial = format(certificate.serial_number, "X")
            return {
                "signature_value": base64.b64encode(signature).decode(),
                "signing_time": datetime.now(timezone.utc),
                "certificate_serial": cert_serial,
                "signature_origin": _SIGNATURE_ORIGIN_LOCALFILE,
            }
    except Exception as exc:
        log.warning("Custom local certificate failed (%s), using appliance keypair", exc)

    if customer_id:
        return _sign_with_appliance_key(content_hash, customer_id)
    return _mock_sign(content_hash)

def _mock_sign(content_hash: str) -> dict:
    now = datetime.now(timezone.utc)
    mock_digest = hashlib.sha256(
        f"MOCK_SIGN:{content_hash}:{now.isoformat()}".encode()
    ).hexdigest()
    sig_b64 = base64.b64encode(mock_digest.encode()).decode()
    return {
        "signature_value": sig_b64,
        "signing_time": now,
        "certificate_serial": "MOCK-DEV-SERTIFIKA-0001",
        "signature_origin": _SIGNATURE_ORIGIN_DEMO,
    }


# ---- verify signature ---------------------------------------------------------


def verify_signature(
    content_hash: str,
    signature_value: str,
    certificate_pem: str | None = None,
    customer_id: uuid.UUID | str | None = None,
) -> bool:
    """Verify a PKCS1v15 SHA-256 digital signature against the content hash."""
    if not signature_value:
        return False
    try:
        import os
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding, rsa
        from cryptography.x509 import load_pem_x509_certificate

        cert_bytes: bytes | None = None
        if certificate_pem and certificate_pem.strip().startswith("-----BEGIN CERTIFICATE-----"):
            cert_bytes = certificate_pem.encode("utf-8")
        elif customer_id:
            keys_dir = os.path.join(settings.ARCHIVE_LOCAL_DIR, "keys")
            cert_path = os.path.join(keys_dir, f"appliance_{customer_id}_cert.pem")
            if os.path.exists(cert_path):
                with open(cert_path, "rb") as f:
                    cert_bytes = f.read()

        if cert_bytes:
            cert = load_pem_x509_certificate(cert_bytes)
            public_key = cert.public_key()
            if isinstance(public_key, rsa.RSAPublicKey):
                sig_bytes = base64.b64decode(signature_value)
                public_key.verify(
                    sig_bytes,
                    content_hash.encode("utf-8"),
                    padding.PKCS1v15(),
                    hashes.SHA256(),
                )
                return True

        # Check mock / demo signatures
        expected_mock = hashlib.sha256(f"DEMO-MOCK-SIGNATURE:{content_hash}".encode()).hexdigest()
        if signature_value == expected_mock:
            return True

        return False
    except Exception as exc:
        log.warning("Imza dogrulama basarisiz: %s", exc)
        return False


# ---- main API methods ---------------------------------------------------------


async def sign_with_kamusm(
    db: AsyncSession, content_hash: str, customer_id: uuid.UUID
) -> dict:
    """Sign a content hash: uses TUBITAK KamuSM if credentials provided, otherwise uses genuine local RSA-2048 certificate."""
    cfg = await _get_config(db, customer_id)
    method = cfg.get("sign_method", SIGN_METHOD_KAMUSM)

    # 1. If explicit local file cert configured
    if method == SIGN_METHOD_LOCALFILE:
        cert_path = cfg.get("certificate_path") or settings.TUBITAK_CERTIFICATE_PATH
        cert_pass_enc = cfg.get("certificate_password_encrypted") or ""
        cert_pass = _decrypt_signing_password(cert_pass_enc) if cert_pass_enc else settings.TUBITAK_CERTIFICATE_PASSWORD
        if cert_path and os.path.exists(cert_path):
            return _sign_with_local_cert(content_hash, cert_path, cert_pass, customer_id)
        return _sign_with_appliance_key(content_hash, customer_id)

    # 2. If KamuSM credentials provided
    username = cfg.get("kamusm_username") or settings.TUBITAK_KAMUSM_USERNAME
    pass_enc = cfg.get("kamusm_password_encrypted") or ""
    password = _decrypt_signing_password(pass_enc) if pass_enc else settings.TUBITAK_KAMUSM_PASSWORD

    if username and password and settings.TUBITAK_KAMUSM_ENABLED:
        try:
            return await _sign_kamusm_api(content_hash, username, password)
        except Exception as exc:
            log.warning("KamuSM API ulasilamadi, yerel kriptografik imzalama kullaniliyor: %s", exc)
            return _sign_with_appliance_key(content_hash, customer_id)

    if demo_mode_enabled() and not settings.TUBITAK_KAMUSM_ENABLED:
        return _mock_sign(content_hash)

    # 3. Default: Genuine local RSA-2048 cryptographic signature
    return _sign_with_appliance_key(content_hash, customer_id)



async def sign_archive_record(
    db: AsyncSession, archive: ArchiveRecord
) -> SignResult:
    """Digitally sign an ArchiveRecord using the customer's signing config.

    Updates the archive row with signature_value, signature_time,
    certificate_serial, and sign_method. Flushes but does not commit.
    Returns SignResult.
    """
    if archive.signature_value:
        log.warning("Arsiv %s zaten imzali, tekrar imzalanmiyor", archive.id)
        cfg = await _get_config(db, archive.customer_id)
        signature_origin = (archive.meta or {}).get("signature_origin")
        return SignResult(
            archive_id=archive.id,
            customer_id=archive.customer_id,
            sign_method=archive.sign_method or cfg.get("sign_method", SIGN_METHOD_KAMUSM),
            signature_value=archive.signature_value,
            signing_time=archive.signature_time or datetime.now(timezone.utc),
            certificate_serial=archive.certificate_serial or "",
            chain_seq=archive.chain_seq,
            signature_origin=signature_origin,
        )

    content_to_sign = f"{archive.curr_hash}:{archive.content_hash}:{archive.period_start.isoformat()}:{archive.period_end.isoformat()}"
    content_hash_for_sig = hashlib.sha256(content_to_sign.encode()).hexdigest()

    sig_result = await sign_with_kamusm(db, content_hash_for_sig, archive.customer_id)
    now = datetime.now(timezone.utc)

    archive.signature_value = sig_result["signature_value"]
    archive.signature_time = sig_result.get("signing_time") or now
    archive.certificate_serial = sig_result.get("certificate_serial", "")
    signature_origin = sig_result.get("signature_origin") or _SIGNATURE_ORIGIN_DEMO
    cfg = await _get_config(db, archive.customer_id)
    archive.sign_method = cfg.get("sign_method", SIGN_METHOD_KAMUSM)
    archive.meta = {**(archive.meta or {}), "signature_origin": signature_origin}
    await db.flush()

    cfg["last_signed_at"] = now.isoformat()
    cfg["last_signed_archive_id"] = str(archive.id)
    cfg["last_signature_origin"] = signature_origin
    await _save_config(db, archive.customer_id, cfg)

    await log_audit(
        db,
        "5651.archive_signed",
        "archive_record_5651",
        str(archive.id),
        None,
        details={
            "customer_id": str(archive.customer_id),
            "chain_seq": archive.chain_seq,
            "sign_method": archive.sign_method,
            "signature_origin": signature_origin,
            "certificate_serial": archive.certificate_serial,
        },
    )

    return SignResult(
        archive_id=archive.id,
        customer_id=archive.customer_id,
        sign_method=archive.sign_method or SIGN_METHOD_KAMUSM,
        signature_value=archive.signature_value,
        signing_time=archive.signature_time or now,
        certificate_serial=archive.certificate_serial or "",
        chain_seq=archive.chain_seq,
        signature_origin=signature_origin,
    )


async def update_kamusm_config(
    db: AsyncSession,
    customer_id: uuid.UUID,
    config_data: dict,
) -> KamuSmConfigOut:
    """Update the KamuSM signing configuration for a customer.

    Encrypts sensitive fields (password, certificate_password) before storage.
    """
    cfg = await _get_config(db, customer_id)

    cfg["sign_method"] = config_data.get("sign_method", cfg["sign_method"])
    cfg["certificate_serial"] = config_data.get("certificate_serial", cfg["certificate_serial"])
    cfg["certificate_issuer"] = config_data.get("certificate_issuer", cfg["certificate_issuer"])
    cfg["certificate_subject"] = config_data.get("certificate_subject", cfg["certificate_subject"])

    if config_data.get("kamusm_username"):
        cfg["kamusm_username"] = config_data["kamusm_username"]
    if config_data.get("kamusm_password"):
        cfg["kamusm_password_encrypted"] = _encrypt_signing_password(config_data["kamusm_password"])
    if config_data.get("certificate_path"):
        cfg["certificate_path"] = config_data["certificate_path"]
    if config_data.get("certificate_password"):
        cfg["certificate_password_encrypted"] = _encrypt_signing_password(config_data["certificate_password"])

    cfg["is_configured"] = bool(
        cfg.get("kamusm_username")
        or cfg.get("certificate_path")
        or settings.TUBITAK_KAMUSM_ENABLED
    )

    await _save_config(db, customer_id, cfg)
    await log_audit(
        db,
        "5651.sign_config_updated",
        "customer_license",
        str(customer_id),
        None,
        details={"sign_method": cfg["sign_method"], "is_configured": cfg["is_configured"]},
    )

    return await get_kamusm_status(db, customer_id)


async def get_kamusm_status(
    db: AsyncSession, customer_id: uuid.UUID
) -> KamuSmConfigOut:
    """Return masked KamuSM config status."""
    cfg = await _get_config(db, customer_id)
    last_signed = None
    if cfg.get("last_signed_at"):
        try:
            last_signed = datetime.fromisoformat(cfg["last_signed_at"])
        except (ValueError, TypeError):
            pass
    return KamuSmConfigOut(
        is_configured=cfg.get("is_configured", False),
        sign_method=cfg.get("sign_method"),
        certificate_serial=cfg.get("certificate_serial"),
        certificate_issuer=cfg.get("certificate_issuer"),
        certificate_subject=cfg.get("certificate_subject"),
        has_kamusm_username=bool(cfg.get("kamusm_username")),
        has_kamusm_password=bool(cfg.get("kamusm_password_encrypted")),
        has_certificate_path=bool(cfg.get("certificate_path")),
        last_signed_at=last_signed,
        last_signed_archive_id=cfg.get("last_signed_archive_id"),
        last_signature_origin=cfg.get("last_signature_origin"),
    )
