"""Auth HTTP endpoints."""
from datetime import datetime
import uuid

from fastapi import APIRouter, Depends, Request, Response
from jose import JWTError
from pydantic import BaseModel, Field
from sqlalchemy import false, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import decode_token, hash_password, verify_password
from app.core.tenant import TenantLevel, scope_for
from app.modules.auth.deps import get_current_user, oauth2_scheme
from app.modules.auth.models import User
from app.modules.auth.schemas import (
    LoginRequest,
    LoginResponse,
    LogoutRequest,
    MfaVerifyIn,
    RefreshRequest,
    TokenResponse,
    UserMeUpdate,
    UserOut,
)
from app.modules.auth.service import authenticate, logout, refresh_tokens, update_current_user_profile, verify_mfa_and_login

router = APIRouter()


def _set_auth_cookies(response: Response, access_token: str | None, refresh_token: str | None) -> None:
    if access_token:
        response.set_cookie(
            key="access_token",
            value=access_token,
            httponly=True,
            samesite="lax",
            max_age=86400 * 7,
            path="/",
        )
    if refresh_token:
        response.set_cookie(
            key="refresh_token",
            value=refresh_token,
            httponly=True,
            samesite="lax",
            max_age=86400 * 30,
            path="/",
        )


@router.post("/login", response_model=LoginResponse, summary="Authenticate user credentials and return access tokens", description="Validates the provided username and password against stored credentials. Returns access and refresh tokens upon successful authentication. Supports optional MFA challenge if enabled for the user.")
async def login(body: LoginRequest, request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    result = await authenticate(db, body, request)
    if not getattr(result, "mfa_required", False) and getattr(result, "access_token", None):
        _set_auth_cookies(response, result.access_token, result.refresh_token)
    return result


@router.post("/mfa/complete", response_model=TokenResponse, summary="Complete MFA verification and finalize login", description="Verifies the MFA code provided by the user during the login flow. Returns the final access and refresh tokens once MFA validation succeeds. Should be called after the initial login endpoint returns an MFA challenge.")
async def mfa_complete(
    body: MfaVerifyIn,
    request: Request,
    response: Response,
    db: AsyncSession = Depends(get_db),
):
    result = await verify_mfa_and_login(db, body, request)
    if getattr(result, "access_token", None):
        _set_auth_cookies(response, result.access_token, result.refresh_token)
    return result


@router.get("/me", response_model=UserOut, summary="Retrieve the currently authenticated user profile", description="Returns the profile information of the authenticated user making the request. Requires a valid access token in the Authorization header. Useful for frontend applications to verify session state and display user details.")
async def me(user: User = Depends(get_current_user)):
    return user


@router.patch("/me", response_model=UserOut, summary="Update the current user profile fields", description="Partially updates the authenticated user's profile such as email or full name. Only the provided fields are modified; omitted fields remain unchanged. Requires a valid access token.")
async def update_me(
    body: UserMeUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await update_current_user_profile(
        db,
        user,
        email=body.email,
        full_name=body.full_name,
        request=request,
    )


@router.post("/refresh", response_model=TokenResponse, summary="Refresh expired access token using refresh token", description="Accepts a valid refresh token and returns a new access and refresh token pair. Enables long-lived sessions without requiring the user to re-authenticate. The refresh token must not be expired or revoked.")
async def refresh(body: RefreshRequest, response: Response, db: AsyncSession = Depends(get_db)):
    result = await refresh_tokens(db, body.refresh_token)
    if getattr(result, "access_token", None):
        _set_auth_cookies(response, result.access_token, result.refresh_token)
    return result


@router.post("/logout", status_code=204, summary="Invalidate access and refresh tokens to end session", description="Blacklists the current access token and optionally a provided refresh token. Once invalidated, these tokens cannot be used for subsequent requests. Returns 204 No Content on success.")
async def logout_endpoint(
    request: Request,
    response: Response,
    token: str | None = Depends(oauth2_scheme),
    body: LogoutRequest | None = None,
):
    actual_token = token or request.cookies.get("access_token")
    if actual_token:
        try:
            payload = decode_token(actual_token)
            if payload.get("type") == "access":
                jti = payload.get("jti")
                exp = payload.get("exp")
                if jti is not None and exp is not None:
                    await logout(jti, exp)
        except JWTError:
            pass

    ref_token = (body.refresh_token if body else None) or request.cookies.get("refresh_token")
    if ref_token:
        try:
            rp = decode_token(ref_token)
            if rp and rp.get("type") == "refresh":
                rjti = rp.get("jti")
                rexp = rp.get("exp")
                if rjti is not None and rexp is not None:
                    await logout(rjti, rexp)
        except JWTError:
            pass

    response.delete_cookie(key="access_token", path="/")
    response.delete_cookie(key="refresh_token", path="/")


@router.get("/permissions", response_model=list[str], summary="List all permissions assigned to the current user role", description="Returns the complete set of permission strings associated with the authenticated user's role. Useful for frontend applications to conditionally render UI elements based on user capabilities. Requires a valid access token.")
async def get_permissions(user: User = Depends(get_current_user)):
    from app.core.rbac import ROLE_PERMISSIONS
    perms = ROLE_PERMISSIONS.get(user.role, set())
    return list(perms)


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(min_length=1)
    new_password: str = Field(min_length=6)


@router.post("/change-password", summary="Change current user password", description="Validates the current password and updates it to the new password.")
async def change_password(
    body: ChangePasswordRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    from fastapi import HTTPException

    if not verify_password(body.current_password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Mevcut şifreniz hatalı.")
    user.hashed_password = hash_password(body.new_password)
    await db.commit()
    return {"ok": True, "message": "Şifreniz başarıyla değiştirildi."}


# ---- Platform User Management (Admin & Operator Users) -----------------------

class AdminUserCreate(BaseModel):
    email: str = Field(min_length=3, max_length=255)
    full_name: str | None = Field(default=None, max_length=255)
    password: str = Field(min_length=6, max_length=128)
    role: str = Field(default="super_admin")
    is_active: bool = True


class AdminUserUpdate(BaseModel):
    email: str | None = None
    full_name: str | None = None
    role: str | None = None
    is_active: bool | None = None
    new_password: str | None = None


class AdminUserResetPassword(BaseModel):
    new_password: str = Field(min_length=6, max_length=128)


class AdminUserOut(BaseModel):
    id: uuid.UUID
    email: str
    full_name: str | None = None
    role: str
    is_active: bool = True
    is_2fa_enabled: bool = False
    last_login_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    class Config:
        from_attributes = True


@router.get("/admin-users", response_model=list[AdminUserOut], summary="List all platform administrator/operator users")
async def list_admin_users(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    from fastapi import HTTPException
    if current_user.role not in {"super_admin", "partner_admin", "customer_admin"}:
        raise HTTPException(status_code=403, detail="Bu işlem için yetkiniz bulunmamaktadır.")

    # Administrator records carry the same tenant tree as operational data.
    # Do not let partner/customer roles enumerate the global users table.
    scope = scope_for(current_user)
    query = select(User)
    if scope.level == TenantLevel.GLOBAL:
        pass
    elif not scope.allowed:
        return []
    elif scope.level == TenantLevel.PARTNER and scope.partner_id:
        query = query.where(User.partner_id == scope.partner_id)
        if scope.tenant_id:
            query = query.where(User.tenant_id == scope.tenant_id)
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        query = query.where(User.customer_id == scope.customer_id)
        if scope.tenant_id:
            query = query.where(User.tenant_id == scope.tenant_id)
    elif scope.level == TenantLevel.TENANT and scope.tenant_id:
        query = query.where(User.tenant_id == scope.tenant_id)
    else:
        # Keep unknown or incomplete scope assignments fail-closed even if a
        # future role is added to the route's allow-list.
        query = query.where(false())

    result = await db.execute(query.order_by(User.created_at.desc()))
    users = result.scalars().all()
    return users


@router.post("/admin-users", response_model=AdminUserOut, status_code=201, summary="Create a new platform user")
async def create_admin_user(
    body: AdminUserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    from fastapi import HTTPException
    if current_user.role != "super_admin":
        raise HTTPException(status_code=403, detail="Yalnızca Süper Yöneticiler yeni kullanıcı ekleyebilir.")

    clean_email = body.email.strip().lower()
    existing = (await db.execute(select(User).where(func.lower(User.email) == clean_email))).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=400, detail="Bu e-posta adresi ile kayıtlı bir kullanıcı zaten mevcut.")

    new_user = User(
        email=clean_email,
        full_name=body.full_name.strip() if body.full_name else None,
        hashed_password=hash_password(body.password),
        role=body.role,
        is_active=body.is_active,
    )
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)
    return new_user


@router.put("/admin-users/{user_id}", response_model=AdminUserOut, summary="Update an existing platform user")
async def update_admin_user(
    user_id: uuid.UUID,
    body: AdminUserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    from fastapi import HTTPException
    if current_user.role != "super_admin":
        raise HTTPException(status_code=403, detail="Yalnızca Süper Yöneticiler kullanıcı düzenleyebilir.")

    user = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı.")

    if body.email is not None and body.email.strip().lower() != user.email.lower():
        clean_email = body.email.strip().lower()
        existing = (await db.execute(select(User).where(func.lower(User.email) == clean_email))).scalar_one_or_none()
        if existing and existing.id != user.id:
            raise HTTPException(status_code=400, detail="Bu e-posta adresi başka bir kullanıcı tarafından kullanılıyor.")
        user.email = clean_email

    if body.full_name is not None:
        user.full_name = body.full_name.strip() if body.full_name else None

    if body.role is not None:
        if user.id == current_user.id and body.role != "super_admin":
            raise HTTPException(status_code=400, detail="Kendi Süper Admin rolünüzü değiştiremezsiniz.")
        user.role = body.role

    if body.is_active is not None:
        if user.id == current_user.id and not body.is_active:
            raise HTTPException(status_code=400, detail="Kendi hesabınızı pasife alamazsınız.")
        user.is_active = body.is_active

    if body.new_password:
        if len(body.new_password) < 6:
            raise HTTPException(status_code=400, detail="Şifre en az 6 karakter olmalıdır.")
        user.hashed_password = hash_password(body.new_password)

    await db.commit()
    await db.refresh(user)
    return user


@router.post("/admin-users/{user_id}/reset-password", summary="Reset password for an existing platform user")
async def reset_admin_user_password(
    user_id: uuid.UUID,
    body: AdminUserResetPassword,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    from fastapi import HTTPException
    if current_user.role != "super_admin":
        raise HTTPException(status_code=403, detail="Yalnızca Süper Yöneticiler şifre sıfırlayabilir.")

    user = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı.")

    user.hashed_password = hash_password(body.new_password)
    await db.commit()
    return {"ok": True, "message": f"{user.email} kullanıcısının şifresi başarıyla güncellendi."}


@router.delete("/admin-users/{user_id}", summary="Delete an existing platform user")
async def delete_admin_user(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    from fastapi import HTTPException
    if current_user.role != "super_admin":
        raise HTTPException(status_code=403, detail="Yalnızca Süper Yöneticiler kullanıcı silebilir.")

    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Kendi hesabınızı silemezsiniz.")

    user = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı.")

    if user.role == "super_admin":
        super_admins = (await db.execute(select(func.count(User.id)).where(User.role == "super_admin", User.is_active.is_(True)))).scalar() or 0
        if super_admins <= 1:
            raise HTTPException(status_code=400, detail="Sistemde en az 1 aktif Süper Yönetici bulunmalıdır.")

    await db.delete(user)
    await db.commit()
    return {"ok": True, "message": f"{user.email} kullanıcısı sistemden silindi."}
