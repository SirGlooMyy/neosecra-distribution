"""Syslog record models + trigger/alert models + FirewallLog.
"""
import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Computed, DateTime, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, TSVECTOR, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


class SyslogRecord(Base, UUIDPK, TimestampMixin):
    """Record schema for incoming Syslog streams from firewalls and routers.

    Historical rows that cannot be attributed deterministically remain in this
    table as explicit quarantine records.  They retain the original payload,
    candidate tenant set, and resolution reason but are invisible to scoped
    callers under PostgreSQL RLS until an operator can prove ownership.
    """
    __tablename__ = "syslog_records"

    tenant_id: Mapped[uuid.UUID | None] = fk("tenants", ondelete="RESTRICT", nullable=True)
    # A non-null value is the only usable tenant ownership.  ``claimed`` keeps
    # an invalid historical value for audit/backward-compatible downgrade.
    claimed_tenant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    tenant_resolution_status: Mapped[str] = mapped_column(
        String(32), default="resolved", nullable=False, index=True
    )
    tenant_resolution_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    tenant_resolution_candidates: Mapped[list] = mapped_column(
        JSONB, default=list, nullable=False
    )
    # ``legacy_existing`` identifies rows present before the hardening
    # migration; new writes use an explicit source such as ``api_ingest``.
    tenant_resolution_source: Mapped[str] = mapped_column(
        String(32), default="api_ingest", nullable=False, index=True
    )
    facility: Mapped[int | None] = mapped_column(nullable=True)
    severity: Mapped[int | None] = mapped_column(nullable=True)
    hostname: Mapped[str | None] = mapped_column(String(255), nullable=True)
    app_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
    message: Mapped[str] = mapped_column(Text, nullable=False)


class SyslogTrigger(Base, UUIDPK, TimestampMixin):
    """Trigger/alert rule applied against incoming syslog records."""
    __tablename__ = "syslog_triggers"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    match_type: Mapped[str] = mapped_column(String(20), nullable=False)
    match_pattern: Mapped[str] = mapped_column(String(500), nullable=False)
    severity_threshold: Mapped[int | None] = mapped_column(Integer, nullable=True)
    channel: Mapped[str] = mapped_column(String(20), nullable=False)
    channel_config: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    cooldown_minutes: Mapped[int] = mapped_column(Integer, default=5, nullable=False)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)
    last_triggered_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class TriggerEvent(Base, UUIDPK, TimestampMixin):
    """One occurrence of a trigger firing for a legacy or firewall log."""
    __tablename__ = "syslog_trigger_events"

    trigger_id: Mapped[uuid.UUID] = fk("syslog_triggers", ondelete="CASCADE")
    syslog_record_id: Mapped[uuid.UUID] = fk("syslog_records", ondelete="CASCADE")
    matched_value: Mapped[str | None] = mapped_column(String(500), nullable=True)
    triggered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    delivery_channel: Mapped[str | None] = mapped_column(String(20), nullable=True)
    delivery_status: Mapped[str | None] = mapped_column(String(20), nullable=True)
    delivery_target: Mapped[str | None] = mapped_column(String(255), nullable=True)
    delivery_detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    delivered_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    acknowledged_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    acknowledged_by: Mapped[uuid.UUID | None] = fk("users", ondelete="SET NULL", nullable=True)


class FirewallLog(Base, UUIDPK, TimestampMixin):
    """Parsed firewall log (FortiGate syslog) — 5651-append-only."""
    __tablename__ = "firewall_logs"

    tenant_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    device_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False, index=True)
    event_time: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    vendor: Mapped[str] = mapped_column(String(50), default="fortigate", nullable=False, index=True)
    log_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    log_subtype: Mapped[str | None] = mapped_column(String(50), nullable=True)
    severity: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    action: Mapped[str | None] = mapped_column(String(50), nullable=True, index=True)
    src_ip: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    dst_ip: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    src_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    dst_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    proto: Mapped[str | None] = mapped_column(String(20), nullable=True)
    service: Mapped[str | None] = mapped_column(String(100), nullable=True)
    user: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    policyid: Mapped[int | None] = mapped_column(Integer, nullable=True)
    duration: Mapped[int | None] = mapped_column(Integer, nullable=True)
    sentbyte: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    rcvdbyte: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    session_id: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    raw_syslog: Mapped[str] = mapped_column(Text, nullable=False)
    parsed_fields: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    # PostgreSQL generated search column created by migration
    # f7a8b9c0d1e2. Mapping it is required for the analyzer full-text path.
    search_vector: Mapped[object | None] = mapped_column(
        TSVECTOR,
        Computed(
            "to_tsvector('english', coalesce(raw_syslog, '') || ' ' || "
            "coalesce(src_ip, '') || ' ' || coalesce(dst_ip, '') || ' ' || "
            "coalesce(\"user\", ''))",
            persisted=True,
        ),
        nullable=True,
    )
    # Historical FortiGate rows can carry a local wall-clock timestamp with a
    # +0300 marker. Migration 2c3d4e5f6a7b persists this normalized value and
    # maintains it with a database trigger so date filters use a btree index.
    effective_event_time: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        index=True,
    )
