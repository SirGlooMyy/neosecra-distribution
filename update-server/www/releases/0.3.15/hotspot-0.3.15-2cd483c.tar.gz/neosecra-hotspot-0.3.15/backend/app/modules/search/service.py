"""Search service: ClickHouse hot data plus archive index and archive payloads."""

from __future__ import annotations

import csv
from collections import defaultdict
import io
import hashlib
import ipaddress
import json
import logging
import re
import time
import uuid
from datetime import datetime, timedelta, timezone
import zipfile

from fastapi import HTTPException, status
from sqlalchemy import Text, and_, case, cast, false, func, or_, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters import cache
from app.adapters import clickhouse as ch
from app.core.config import settings
from app.core.tenant import ScopeContext, TenantLevel, customer_in_scope, scope_for
from app.modules.logs_5651 import archive_service
from app.modules.customers.models import Customer
from app.modules.devices.models import Device
from app.modules.search.models import SearchView
from app.modules.search.schemas import (
    CorrelateResponse,
    CorrelateSessionInfo,
    CorrelateTimelineItem,
    FacetResult,
    FacetValue,
    LogSearchItem,
    LogSearchParams,
    LogSearchResponse,
    SearchCorrelationSummary,
    SearchHit,
    SearchQuery,
    SearchResult,
    SearchViewCreate,
    SearchViewOut,
    SearchViewUpdate,
)
from app.modules.sessions import service as sessions_service
from app.modules.syslog.models import FirewallLog

log = logging.getLogger(__name__)


def _view_out(view: SearchView) -> SearchViewOut:
    return SearchViewOut.model_validate(view)


_DEFAULT_CORRELATION_WINDOW_MINUTES = 15
_CANONICAL_SEVERITIES = (
    "emergency", "alert", "critical", "error",
    "warning", "notice", "info", "debug",
)

_CANONICAL_LOG_TYPES = (
    "traffic", "event", "utm", "iap", "anomaly", "vpn",
    "webfilter", "app-ctrl", "dns",
)


def _format_bytes(b: int | float | str | None) -> str:
    if not b:
        return ""
    try:
        val = float(b)
    except (ValueError, TypeError):
        return ""
    if val <= 0:
        return ""
    if val < 1024:
        return f"{int(val)} B"
    if val < 1024 * 1024:
        return f"{val / 1024:.1f} KB"
    if val < 1024 * 1024 * 1024:
        return f"{val / (1024 * 1024):.1f} MB"
    return f"{val / (1024 * 1024 * 1024):.2f} GB"


def _format_duration(secs: int | float | str | None) -> str:
    if not secs:
        return ""
    try:
        val = int(float(secs))
    except (ValueError, TypeError):
        return ""
    if val <= 0:
        return ""
    if val < 60:
        return f"{val} sn"
    mins = val // 60
    rem_secs = val % 60
    if mins < 60:
        return f"{mins} dk {rem_secs} sn" if rem_secs else f"{mins} dk"
    hours = mins // 60
    rem_mins = mins % 60
    return f"{hours} sa {rem_mins} dk"


def effective_firewall_log_type_column():
    """Return the analyzer category using indexed columns for high performance."""
    subtype = func.lower(func.coalesce(FirewallLog.log_subtype, ""))

    utm_webfilter = and_(
        FirewallLog.log_type == "utm",
        subtype == "webfilter",
    )
    utm_appctrl = and_(
        FirewallLog.log_type == "utm",
        subtype.in_(("app-ctrl", "application")),
    )
    utm_dns = and_(
        FirewallLog.log_type == "utm",
        subtype == "dns",
    )
    return case(
        (FirewallLog.log_type == "vpn", "vpn"),
        (utm_webfilter, "webfilter"),
        (utm_appctrl, "app-ctrl"),
        (utm_dns, "dns"),
        else_=FirewallLog.log_type,
    )


def effective_firewall_severity_column():
    """Return the canonical FortiGate severity using indexed severity column."""
    return FirewallLog.severity



def _effective_firewall_severity(row) -> str:
    """Canonicalize a stored row for API responses without mutating it."""
    raw = str(getattr(row, "severity", "") or "").lower()
    if raw in _CANONICAL_SEVERITIES:
        return raw
    parsed = getattr(row, "parsed_fields", None) or {}
    level = str(parsed.get("level") or "").lower()
    if level == "information":
        return "info"
    if level in _CANONICAL_SEVERITIES:
        return level
    return raw or "info"


def _effective_firewall_log_type(row) -> str:
    """Canonicalize a FirewallLog row for API responses."""
    raw = str(getattr(row, "log_type", "") or "").lower()
    if raw == "vpn":
        return "vpn"
    parsed = getattr(row, "parsed_fields", None) or {}
    subtype = str(getattr(row, "log_subtype", None) or parsed.get("subtype") or "").lower()
    if raw == "utm" and subtype == "webfilter":
        return "webfilter"
    if raw == "utm" and subtype in {"app-ctrl", "application"}:
        return "app-ctrl"
    if raw == "utm" and subtype == "dns":
        return "dns"
    if raw == "utm":
        return "utm"

    user = getattr(row, "user", None) or parsed.get("user")
    parsed_type = str(parsed.get("type") or "").lower()
    event_type = str(parsed.get("eventtype") or parsed.get("event_type") or "").lower()
    logdesc = str(parsed.get("logdesc") or parsed.get("message") or parsed.get("msg") or "").lower()
    action = str(getattr(row, "action", None) or parsed.get("action") or "").lower()
    srcintf = str(parsed.get("srcintf") or "").lower()
    dstintf = str(parsed.get("dstintf") or "").lower()
    policyname = str(parsed.get("policyname") or "").lower()

    if (
        parsed_type == "vpn"
        or subtype in {"vpn", "ssl-vpn", "sslvpn", "ipsec", "ipsec-vpn"}
        or any(token in event_type for token in ("vpn", "tunnel", "ipsec", "ssl-vpn"))
        or any(token in logdesc for token in ("tunnel-up", "tunnel-down", "ssl vpn connection"))
        or any(token in action for token in ("tunnel-up", "tunnel-down", "ssl-login", "ssl-logout"))
        or "ssl.root" in srcintf or "vpntunnel" in srcintf
        or "ssl.root" in dstintf
        or "sslvpn" in policyname
    ):
        return "vpn"
    return raw or "event"


def _firewall_log_message(row, log_type: str | None = None) -> str | None:
    """Choose a human-readable FortiGate message with session duration and traffic volume."""
    parsed = getattr(row, "parsed_fields", None) or {}
    user = getattr(row, "user", None) or parsed.get("user")
    policyname = parsed.get("policyname")
    srcintf = parsed.get("srcintf")
    msg = parsed.get("logdesc") or parsed.get("msg") or parsed.get("message") or parsed.get("desc")

    dur = getattr(row, "duration", None) or parsed.get("duration")
    sent = getattr(row, "sentbyte", None) or parsed.get("sentbyte")
    rcvd = getattr(row, "rcvdbyte", None) or parsed.get("rcvdbyte")
    dur_str = _format_duration(dur)
    sent_str = _format_bytes(sent)
    rcvd_str = _format_bytes(rcvd)

    metrics = []
    if dur_str:
        metrics.append(f"⏱️ {dur_str}")
    if sent_str or rcvd_str:
        metrics.append(f"↑{sent_str or '0 B'} ↓{rcvd_str or '0 B'}")
    metric_tail = f" · {', '.join(metrics)}" if metrics else ""

    if user and policyname:
        return f"{user} · {policyname} ({srcintf or 'ssl.root'}){metric_tail}"
    if user and msg:
        return f"{user}: {msg}{metric_tail}"
    if msg:
        return f"{msg}{metric_tail}"
    action = getattr(row, "action", None)
    if action:
        category = log_type or _effective_firewall_log_type(row)
        source = getattr(row, "src_ip", None) or "-"
        target = getattr(row, "dst_ip", None) or "-"
        return f"{category} {action} {source} -> {target}{metric_tail}"
    return None

_VENDOR_DISPLAY_NAMES = {
    "fortinet": "Fortinet",
    "paloalto": "PaloAlto",
    "sophos": "Sophos",
    "sonicwall": "SonicWall",
    "watchguard": "WatchGuard",
    "zyxel": "Zyxel",
    "mikrotik": "MikroTik",
    "draytek": "DrayTek",
    "pfsense": "pfSense",
    "tplink": "TP-Link",
    "aruba": "Aruba",
    "ruijie": "Ruijie",
}

_VENDOR_PATTERNS = {
    "fortinet": ("fortinet", "fortigate", "forti", "fgt"),
    "paloalto": ("paloalto", "panos", "panw", "pan-os"),
    "sophos": ("sophos",),
    "sonicwall": ("sonicwall",),
    "watchguard": ("watchguard",),
    "zyxel": ("zyxel",),
    "mikrotik": ("mikrotik", "routeros"),
    "draytek": ("draytek", "vigor"),
    "pfsense": ("pfsense", "pfsense"),
    "tplink": ("tplink", "tp-link", "omada"),
    "aruba": ("aruba", "clearpass"),
    "ruijie": ("ruijie", "reyee"),
}


def _parse_hit_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _correlation_bucket(ts: datetime | None, window_minutes: int) -> datetime | None:
    if ts is None:
        return None
    window = max(1, min(120, int(window_minutes or _DEFAULT_CORRELATION_WINDOW_MINUTES)))
    minute = (ts.minute // window) * window
    return ts.replace(minute=minute, second=0, microsecond=0)


def _normalize_vendor_key(value: str | None) -> str | None:
    if not value:
        return None
    normalized = re.sub(r"[^a-z0-9]+", "", value.lower())
    return normalized or None


def _vendor_search_haystack(hit: SearchHit) -> str:
    return " ".join(
        str(value)
        for value in (
            hit.hostname,
            hit.application,
            hit.message,
            hit.action,
            hit.domain,
        )
        if value
    ).lower()


def _pattern_in_haystack(haystack: str, pattern: str) -> bool:
    normalized_pattern = _normalize_vendor_key(pattern)
    return bool(normalized_pattern and normalized_pattern in haystack)


def infer_vendor_slug(hit: SearchHit) -> str | None:
    haystack = _normalize_vendor_key(_vendor_search_haystack(hit))
    if not haystack:
        return None
    for slug, aliases in _VENDOR_PATTERNS.items():
        if any(_pattern_in_haystack(haystack, alias) for alias in aliases):
            return slug
    return None


def infer_vendor_display_name(hit: SearchHit, fallback: str | None = None) -> str:
    vendor_slug = infer_vendor_slug(hit)
    if vendor_slug:
        return _VENDOR_DISPLAY_NAMES.get(vendor_slug, vendor_slug.title())
    normalized_fallback = _normalize_vendor_key(fallback)
    if normalized_fallback:
        return _VENDOR_DISPLAY_NAMES.get(normalized_fallback, fallback or "Bilinmiyor")
    return "Bilinmiyor"


def hit_matches_vendor(hit: SearchHit, vendor: str | None) -> bool:
    normalized_vendor = _normalize_vendor_key(vendor)
    if not normalized_vendor:
        return True

    haystack = _normalize_vendor_key(_vendor_search_haystack(hit))
    if not haystack:
        return False

    aliases = _VENDOR_PATTERNS.get(normalized_vendor, (normalized_vendor,))
    if any(_pattern_in_haystack(haystack, alias) for alias in aliases):
        return True
    return infer_vendor_slug(hit) == normalized_vendor


def _build_correlation_metadata(
    hit: SearchHit,
    *,
    correlation_window_minutes: int = _DEFAULT_CORRELATION_WINDOW_MINUTES,
) -> dict[str, str | int | None]:
    ts = _parse_hit_timestamp(hit.timestamp)
    bucket = _correlation_bucket(ts, correlation_window_minutes)
    bucket_key = bucket.isoformat() if bucket else "no-ts"

    if hit.session_id:
        reason = "aynı session_id"
        correlation_id = f"session:{hit.customer_id}:{hit.session_id}"
        correlation_type = "session"
    else:
        key_parts: list[str] = [f"customer:{hit.customer_id}"]
        reason_parts: list[str] = []

        if hit.location_id:
            key_parts.append(f"location:{hit.location_id}")
        if hit.device_id:
            key_parts.append(f"device:{hit.device_id}")
        if hit.username:
            key_parts.append(f"user:{hit.username.lower()}")
            reason_parts.append("username")
        if hit.mac:
            key_parts.append(f"mac:{hit.mac.upper()}")
            reason_parts.append("MAC")
        if hit.source_ip and hit.source_ip != "::":
            key_parts.append(f"ip:{hit.source_ip}")
            reason_parts.append("source IP")
        if hit.hostname:
            key_parts.append(f"host:{hit.hostname.lower()}")
            reason_parts.append("hostname")
        if hit.application:
            key_parts.append(f"app:{hit.application.lower()}")
        if not reason_parts:
            digest = hashlib.sha1(hit.message.encode("utf-8")).hexdigest()[:12]
            key_parts.append(f"message:{digest}")
            reason_parts.append("mesaj içeriği")

        correlation_type = (
            "principal"
            if hit.username
            else "device"
            if hit.mac or hit.device_id
            else "host"
            if hit.hostname
            else "ip"
            if hit.source_ip and hit.source_ip != "::"
            else "message"
        )
        reason = f"{', '.join(reason_parts)} eşleşmesi"
        if bucket:
            reason = f"{reason} ({correlation_window_minutes} dakikalık pencere)"
        correlation_id = f"{correlation_type}:{'|'.join(key_parts)}:{bucket_key}"

    return {
        "correlation_id": correlation_id,
        "correlation_type": correlation_type,
        "correlation_reason": reason,
    }


def enrich_search_hits_with_correlations(
    hits: list[SearchHit],
    *,
    correlation_window_minutes: int = _DEFAULT_CORRELATION_WINDOW_MINUTES,
) -> tuple[list[SearchHit], list[SearchCorrelationSummary]]:
    """Attach correlation metadata to hits and summarize related groups."""
    grouped: dict[str, list[SearchHit]] = defaultdict(list)
    grouped_sources: dict[str, set[str]] = defaultdict(set)
    enriched_hits: list[SearchHit] = []

    for hit in hits:
        metadata = _build_correlation_metadata(hit, correlation_window_minutes=correlation_window_minutes)
        enriched_hit = hit.model_copy(update=metadata)
        grouped[str(metadata["correlation_id"])].append(enriched_hit)
        grouped_sources[str(metadata["correlation_id"])].add(str(hit.source or "unknown"))
        enriched_hits.append(enriched_hit)

    summaries: list[SearchCorrelationSummary] = []
    group_sizes: dict[str, int] = {}
    for correlation_id, members in grouped.items():
        ordered = sorted(members, key=_hit_sort_key, reverse=True)
        first_ts = ordered[-1].timestamp if ordered else ""
        last_ts = ordered[0].timestamp if ordered else ""
        exemplar = ordered[0] if ordered else members[0]
        group_size = len(members)
        sources = sorted(grouped_sources.get(correlation_id, set()))
        group_sizes[correlation_id] = group_size
        summaries.append(
            SearchCorrelationSummary(
                correlation_id=correlation_id,
                correlation_type=exemplar.correlation_type or "unknown",
                reason=exemplar.correlation_reason or "Correlated log activity",
                hit_count=group_size,
                source_count=len(sources),
                sources=sources,
                first_timestamp=first_ts,
                last_timestamp=last_ts,
                sample_hostname=exemplar.hostname or None,
                sample_source_ip=exemplar.source_ip or None,
                sample_session_id=exemplar.session_id,
            )
        )

    summaries.sort(
        key=lambda item: (
            -item.hit_count,
            -(
                _parse_hit_timestamp(item.last_timestamp) or datetime.min.replace(tzinfo=timezone.utc)
            ).timestamp(),
            ),
        )
    sized_hits = [
        hit.model_copy(update={"correlation_group_size": group_sizes.get(hit.correlation_id or "", 1)})
        for hit in enriched_hits
    ]
    return sized_hits, summaries


async def unified_search(
    db: AsyncSession,
    scope: ScopeContext,
    query: SearchQuery,
) -> SearchResult:
    """Unified search service across ClickHouse hot data, archive index/payloads, and Postgres fallback.
    Enforces multi-tenant isolation through ScopeContext.
    """
    if not scope.allowed:
        return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")
    return await search_syslog(db, scope, query)


async def search_syslog(
    db: AsyncSession,
    scope: ScopeContext,
    query: SearchQuery,
) -> SearchResult:
    """Full-text search across ClickHouse hot data and archived cold data."""
    if not scope.allowed:
        return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")

    customer_uuid = _parse_uuid(query.customer_id)
    # Service callers may bypass the HTTP router, so enforce the same tenant
    # boundary here as a defense-in-depth check.  Customer scope is pinned to
    # its own id; partner/location scopes must prove the requested customer is
    # assigned to them.  A few legacy unit callers pass a light-weight mock
    # instead of ScopeContext; retain their explicit customer_id behavior.
    if isinstance(scope, ScopeContext):
        if scope.level == TenantLevel.CUSTOMER and scope.customer_id != customer_uuid:
            return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")
        if scope.level != TenantLevel.GLOBAL and not await customer_in_scope(db, scope, customer_uuid):
            return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")
        if scope.level == TenantLevel.LOCATION:
            if query.location_id and str(query.location_id) != str(scope.location_id):
                return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")
            if not query.location_id:
                query = query.model_copy(update={"location_id": str(scope.location_id)})
    customer_id = str(customer_uuid)

    # v2 invalidates pre-fix entries that were generated from the legacy
    ch_hits = await _search_clickhouse(customer_id, query)
    archive_hits: list[SearchHit] = []
    pg_hits: list[SearchHit] = []
    pg_total = 0
    if not ch_hits:
        archive_hits = await _search_archive(db, customer_uuid, query)
        pg_result = await _search_postgres(db, customer_uuid, query)
        # Keep compatibility with lightweight test doubles that return only
        # the hit list while the real implementation also returns a count.
        if isinstance(pg_result, tuple):
            pg_hits, pg_total = pg_result
        else:
            pg_hits = pg_result
            pg_total = len(pg_hits)

    all_hits = sorted(ch_hits + archive_hits + pg_hits, key=_sort_timestamp, reverse=True)
    all_hits = [hit for hit in all_hits if hit_matches_vendor(hit, query.vendor)]
    all_hits, correlation_summary = enrich_search_hits_with_correlations(
        all_hits,
        correlation_window_minutes=query.correlation_window_minutes,
    )
    if ch_hits:
        ch_filtered = [h for h in ch_hits if hit_matches_vendor(h, query.vendor)]
        hot_total = query.offset + len(ch_filtered) + (1 if len(ch_filtered) == query.limit else 0)
    else:
        hot_total = pg_total
    total = hot_total + len(archive_hits)
    paged = all_hits[:query.limit]

    if ch_hits and (archive_hits or pg_hits):
        source = "mixed"
    elif archive_hits:
        source = "archive"
    elif pg_hits:
        source = "postgres"
    else:
        # An empty fallback result is still a PostgreSQL answer when
        # ClickHouse is disabled; reporting ``clickhouse`` here made the UI
        # claim it had searched a store that was intentionally offline.
        from app.core.config import settings
        source = "postgres" if not settings.CLICKHOUSE_ENABLED else "clickhouse"

    result = SearchResult(
        hits=paged,
        total=total,
        limit=query.limit,
        offset=query.offset,
        source=source,
        correlation_summary=correlation_summary,
    )

    return result


def _build_where_clauses(filters: LogSearchParams, scope_or_user) -> list:
    """Build WHERE clause fragments for firewall_logs search scoped by ScopeContext."""
    scope = scope_or_user if isinstance(scope_or_user, ScopeContext) else scope_for(scope_or_user)

    clauses = []
    if not scope.allowed:
        clauses.append(false())
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        clauses.append(FirewallLog.customer_id == scope.customer_id)
    elif scope.level == TenantLevel.PARTNER and scope.partner_id:
        clauses.append(
            FirewallLog.customer_id.in_(
                select(Customer.id).where(Customer.partner_id == scope.partner_id)
            )
        )
    elif scope.level == TenantLevel.TENANT and scope.tenant_id:
        clauses.append(
            FirewallLog.customer_id.in_(
                select(Customer.id).where(Customer.tenant_id == scope.tenant_id)
            )
        )
    elif scope.level == TenantLevel.LOCATION and scope.location_id:
        # FirewallLog has no denormalized location_id; resolve it through the
        # device relation that produced the log.
        clauses.append(
            FirewallLog.device_id.in_(
                select(Device.id).where(Device.location_id == scope.location_id)
            )
        )
    elif scope.level != TenantLevel.GLOBAL:
        clauses.append(false())

    if getattr(filters, "customer_id", None):
        clauses.append(FirewallLog.customer_id == filters.customer_id)

    if filters.vendor:
        vendors = [v.strip() for v in filters.vendor.split(",") if v.strip()]
        if vendors:
            clauses.append(FirewallLog.vendor.in_(vendors))

    if filters.log_type:
        log_types = [lt.strip() for lt in filters.log_type.split(",") if lt.strip()]
        if log_types:
            # Filter on the canonical category so FortiOS ``event/vpn``
            # records are included when the user selects VPN.
            clauses.append(effective_firewall_log_type_column().in_(log_types))

    if filters.severity:
        severities = [s.strip() for s in filters.severity.split(",") if s.strip()]
        if severities:
            clauses.append(effective_firewall_severity_column().in_(severities))

    if filters.action:
        actions = [a.strip() for a in filters.action.split(",") if a.strip()]
        if actions:
            clauses.append(FirewallLog.action.in_(actions))

    if filters.src_ip:
        if filters.src_ip.endswith("%") or filters.src_ip.endswith("."):
            clauses.append(FirewallLog.src_ip.like(filters.src_ip))
        else:
            clauses.append(FirewallLog.src_ip == filters.src_ip)

    if filters.dst_ip:
        if filters.dst_ip.endswith("%") or filters.dst_ip.endswith("."):
            clauses.append(FirewallLog.dst_ip.like(filters.dst_ip))
        else:
            clauses.append(FirewallLog.dst_ip == filters.dst_ip)

    if filters.src_port is not None:
        clauses.append(FirewallLog.src_port == filters.src_port)

    if filters.dst_port is not None:
        clauses.append(FirewallLog.dst_port == filters.dst_port)

    if filters.user:
        clauses.append(FirewallLog.user.ilike(f"%{filters.user}%"))

    if filters.device_id:
        clauses.append(FirewallLog.device_id == filters.device_id)

    if filters.location_id:
        clauses.append(
            FirewallLog.device_id.in_(
                select(Device.id).where(Device.location_id == filters.location_id)
            )
        )

    if filters.policyid is not None:
        clauses.append(FirewallLog.policyid == filters.policyid)

    if filters.service:
        clauses.append(FirewallLog.service.ilike(f"%{filters.service}%"))

    if filters.proto:
        clauses.append(FirewallLog.proto == filters.proto)

    event_time = effective_firewall_event_time_column()
    from_time, to_time = _resolve_time_window(filters)
    if from_time:
        clauses.append(event_time >= from_time)
    if to_time:
        clauses.append(event_time <= to_time)

    return clauses


def _row_to_log_item(row) -> LogSearchItem:
    event_time = _effective_firewall_event_time(row)
    return LogSearchItem(
        id=str(row.id),
        tenant_id=str(row.tenant_id),
        event_time=event_time.isoformat() if event_time else None,
        received_at=row.received_at.isoformat() if row.received_at else None,
        vendor=row.vendor,
        hostname=str((row.parsed_fields or {}).get("devname") or (row.parsed_fields or {}).get("hostname") or "") or None,
        log_type=_effective_firewall_log_type(row),
        log_subtype=row.log_subtype,
        severity=_effective_firewall_severity(row),
        action=row.action,
        message=_firewall_log_message(row),
        src_ip=row.src_ip,
        dst_ip=row.dst_ip,
        src_port=row.src_port,
        dst_port=row.dst_port,
        proto=row.proto,
        service=row.service,
        user=row.user,
        policyid=row.policyid,
        duration=row.duration,
        sentbyte=row.sentbyte,
        rcvdbyte=row.rcvdbyte,
        session_id=row.session_id,
        raw_syslog=row.raw_syslog,
        parsed_fields=row.parsed_fields if hasattr(row, "parsed_fields") else {},
        rank=getattr(row, "rank", None),
    )


def _effective_firewall_event_time(row) -> datetime | None:
    """Return a display/search timestamp without rewriting immutable raw data.

    Older FortiGate rows were ingested before timezone offsets were honored,
    so their parsed UTC timestamp can be exactly the local wall clock (+0300)
    while ``received_at`` is correct.  Normalize only that unmistakable legacy
    shape at read time; new rows and the raw syslog payload remain untouched.
    """
    # New rows expose the persisted/generated indexed value directly. Keep the
    # compatibility calculation below for fixtures and pre-migration objects.
    persisted = getattr(row, "effective_event_time", None)
    if isinstance(persisted, datetime):
        return persisted
    event_time = getattr(row, "event_time", None)
    received_at = getattr(row, "received_at", None)
    parsed = getattr(row, "parsed_fields", None) or {}
    tz_raw = str(parsed.get("tz") or parsed.get("timezone") or "").strip()
    if event_time and received_at and tz_raw and len(tz_raw) == 5 and tz_raw[0] in "+-" and tz_raw[1:].isdigit():
        if event_time > received_at + timedelta(minutes=5):
            sign = 1 if tz_raw[0] == "+" else -1
            minutes = int(tz_raw[1:3]) * 60 + int(tz_raw[3:5])
            return event_time - sign * timedelta(minutes=minutes)
    return event_time


def effective_firewall_event_time_column():
    """Return the persisted, indexed analyzer timestamp.

    PostgreSQL generates this value from the immutable FortiGate fields.
    Keeping the compatibility normalization in a stored column prevents the
    JSONB/CASE expression from forcing a sequential scan for every request.
    """
    return FirewallLog.effective_event_time


def _search_text_clauses(value: str) -> list:
    """Build an analyzer-friendly search predicate for IP/MAC/port/text.

    PostgreSQL full-text search is useful for prose but treats punctuation as
    token boundaries, which makes an address such as ``10.0.0.1`` unreliable.
    Exact indexed fields are preferred for addresses and ports; the fallback
    text predicates keep FortiGate message, user, service and parsed vendor
    fields searchable for natural-language investigations.
    """
    query = str(value or "").strip()
    if not query:
        return []

    clauses: list = []
    try:
        ipaddress.ip_address(query)
    except ValueError:
        pass
    else:
        clauses.extend((FirewallLog.src_ip == query, FirewallLog.dst_ip == query))

    mac = re.fullmatch(r"[0-9a-fA-F]{2}(?::|-)[0-9a-fA-F]{2}(?::|-)[0-9a-fA-F]{2}(?::|-)[0-9a-fA-F]{2}(?::|-)[0-9a-fA-F]{2}(?::|-)[0-9a-fA-F]{2}", query)
    if mac:
        normalized = query.replace("-", ":").lower()
        for key in ("srcmac", "dstmac", "src_mac", "dst_mac", "mac", "calling_station_id"):
            clauses.append(func.lower(FirewallLog.parsed_fields[key].astext) == normalized)

    if query.isdigit() and 0 < int(query) <= 65535:
        port = int(query)
        clauses.extend((FirewallLog.src_port == port, FirewallLog.dst_port == port))

    # Escape LIKE metacharacters so a user searching for a literal '%' or '_'
    # cannot accidentally turn the query into an unbounded wildcard.
    escaped = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    pattern = f"%{escaped}%"
    clauses.extend(
        (
            FirewallLog.user.ilike(pattern, escape="\\"),
            FirewallLog.service.ilike(pattern, escape="\\"),
            FirewallLog.action.ilike(pattern, escape="\\"),
            FirewallLog.src_ip.ilike(pattern, escape="\\"),
            FirewallLog.dst_ip.ilike(pattern, escape="\\"),
            FirewallLog.raw_syslog.ilike(pattern, escape="\\"),
        )
    )
    # Keep the GIN path for prose searches. It is an OR branch, so punctuation
    # based searches still succeed through the exact/ILIKE predicates above.
    if re.search(r"[A-Za-zÀ-ÿ]", query):
        clauses.append(FirewallLog.search_vector.op("@@")(func.plainto_tsquery("english", query)))
    return clauses


async def search_firewall_logs(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
) -> LogSearchResponse:
    """Search firewall_logs with filters + optional fulltext (q) + tsvector ranking."""
    start = time.monotonic()
    scope = user if isinstance(user, ScopeContext) else scope_for(user)
    if not scope.allowed:
        return LogSearchResponse(total=0, items=[], took_ms=0)

    clauses = _build_where_clauses(filters, scope)

    if filters.q:
        clauses.append(or_(*_search_text_clauses(filters.q)))

    base = select(FirewallLog)
    if clauses:
        base = base.where(*clauses)

    count_q = select(func.count(FirewallLog.id))
    if clauses:
        count_q = count_q.where(*clauses)
    total_result = await db.execute(count_q)
    total = total_result.scalar() or 0

    if filters.q:
        # Keep punctuation-aware predicates (IP/MAC/port) in the result set,
        # while ranking prose matches when PostgreSQL can tokenize them.
        tsquery = func.plainto_tsquery("english", filters.q)
        rank = func.ts_rank(FirewallLog.search_vector, tsquery).label("rank")
        q = base.add_columns(rank).order_by(rank.desc(), effective_firewall_event_time_column().desc())
    else:
        q = base.order_by(effective_firewall_event_time_column().desc())

    q = q.offset(filters.offset).limit(filters.limit)

    result = await db.execute(q)
    rows = result.scalars().all()

    items = [_row_to_log_item(r) for r in rows]

    took_ms = int((time.monotonic() - start) * 1000)
    return LogSearchResponse(total=total, items=items, took_ms=took_ms)


async def get_facets(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
) -> FacetResult:
    """Compute rich facets (histogram + top-N for vendor, log_type, severity, action, src_ip, dst_ip, user, domain, application)."""
    import asyncio
    from app.modules.search.schemas import HistogramBucket
    start = time.monotonic()
    scope = user if isinstance(user, ScopeContext) else scope_for(user)
    if not scope.allowed:
        return FacetResult()

    clauses = _build_where_clauses(filters, scope)
    if filters.q:
        # Facets must describe the same hybrid result set as the table. The
        # old full-text-only predicate dropped dotted IPs and MAC searches.
        clauses.append(or_(*_search_text_clauses(filters.q)))

    async def _facet(column) -> list[FacetValue]:
        q = select(column, func.count(FirewallLog.id).label("cnt"))
        if clauses:
            q = q.where(*clauses)
        q = q.where(column.isnot(None)).group_by(column).order_by(text("cnt DESC")).limit(10)
        res = await db.execute(q)
        return [FacetValue(value=str(row[0]), count=row[1]) for row in res if row[0] is not None]

    async def _histogram() -> list[HistogramBucket]:
        bucket_col = func.date_trunc('hour', effective_firewall_event_time_column()).label("bucket")
        q = select(bucket_col, func.count(FirewallLog.id).label("cnt"))
        if clauses:
            q = q.where(*clauses)
        q = q.where(effective_firewall_event_time_column().isnot(None)).group_by(bucket_col).order_by(bucket_col.asc()).limit(100)
        res = await db.execute(q)
        buckets = []
        for row in res:
            if row[0]:
                ts_str = row[0].isoformat() if hasattr(row[0], "isoformat") else str(row[0])
                buckets.append(HistogramBucket(timestamp=ts_str, count=row[1]))
        return buckets

    vendor, log_type, severity, action, src_ip, dst_ip, user_f, domain_f, app_f, histogram = await asyncio.gather(
        _facet(FirewallLog.vendor),
        _facet(effective_firewall_log_type_column()),
        _facet(effective_firewall_severity_column()),
        _facet(FirewallLog.action),
        _facet(FirewallLog.src_ip),
        _facet(FirewallLog.dst_ip),
        _facet(FirewallLog.user),
        _facet(FirewallLog.service),
        _facet(FirewallLog.proto),
        _histogram(),
    )

    log.debug("Facets computed in %d ms", int((time.monotonic() - start) * 1000))
    return FacetResult(
        vendor=vendor,
        log_type=log_type,
        severity=severity,
        action=action,
        src_ip=src_ip,
        dst_ip=dst_ip,
        user=user_f,
        domain=domain_f,
        application=app_f,
        histogram=histogram,
    )


def build_firewall_logs_export_bundle(
    result: SearchResult,
    query: SearchQuery,
    *,
    context: dict[str, str | int | None] | None = None,
    generated_at: datetime | None = None,
) -> tuple[bytes, str]:
    """Build a portable evidence bundle for firewall log searches."""
    generated_at = generated_at or datetime.now(timezone.utc)
    enriched_hits, correlation_summary = enrich_search_hits_with_correlations(
        result.hits,
        correlation_window_minutes=query.correlation_window_minutes,
    )

    columns = [
        "timestamp",
        "customer_id",
        "location_id",
        "device_id",
        "facility",
        "severity",
        "hostname",
        "source_ip",
        "dest_ip",
        "mac",
        "username",
        "domain",
        "application",
        "action",
        "message",
        "session_id",
        "source",
    ]

    csv_buffer = io.StringIO()
    writer = csv.DictWriter(csv_buffer, fieldnames=columns)
    writer.writeheader()
    for hit in enriched_hits:
        row = hit.model_dump(mode="json")
        writer.writerow({column: row.get(column, "") for column in columns})

    manifest = {
        "title": "Firewall Logs Evidence Bundle",
        "generated_at": generated_at.isoformat(),
        "row_count": len(enriched_hits),
        "total_hits": result.total,
        "source": result.source,
        "query": query.model_dump(mode="json"),
        "context": context or {},
        "correlation_rule": {
            "window_minutes": query.correlation_window_minutes,
            "description": (
                f"MAC, IP, kullanıcı ve hostname için "
                f"{query.correlation_window_minutes} dakikalık korelasyon penceresi"
            ),
        },
        "correlation_summary": [item.model_dump(mode="json") for item in correlation_summary],
    }

    readme_lines = [
        "Firewall Logs Evidence Bundle",
        "============================",
        "",
        f"Generated at: {generated_at.isoformat()}",
        f"Rows exported: {len(enriched_hits)}",
        f"Total hits: {result.total}",
        f"Source: {result.source}",
        f"Correlation window: {query.correlation_window_minutes} minutes",
        f"Correlation groups: {len(correlation_summary)}",
    ]
    if context:
        readme_lines.extend(["", "Context:"])
        readme_lines.extend(f"- {key}: {value}" for key, value in context.items())
    if correlation_summary:
        readme_lines.extend(["", "Top correlated groups:"])
        for group in correlation_summary[:5]:
            readme_lines.append(
                f"- {group.correlation_type} · {group.hit_count} kayıt · "
                f"{', '.join(group.sources) if group.sources else 'tek kaynak'} · {group.reason}"
            )
    readme_lines.extend(
        [
            "",
            "Contents:",
            "- manifest.json",
            "- results.csv",
            "- README.txt",
        ]
    )
    readme = "\n".join(readme_lines) + "\n"

    bundle = io.BytesIO()
    with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True))
        archive.writestr("results.csv", csv_buffer.getvalue().encode("utf-8-sig"))
        archive.writestr("README.txt", readme)

    filename = f"firewall-logs-export-{generated_at.strftime('%Y%m%d-%H%M%S')}.zip"
    return bundle.getvalue(), filename


async def list_search_views(
    db: AsyncSession,
    *,
    user_id: uuid.UUID,
    surface: str = "firewall_logs",
) -> list[SearchViewOut]:
    q = select(SearchView).where(SearchView.surface == surface).where(
        (SearchView.created_by_user_id == user_id) | (SearchView.is_shared.is_(True))
    ).order_by(SearchView.updated_at.desc())
    res = await db.execute(q)
    return [_view_out(view) for view in res.scalars().all()]


async def get_search_view(db: AsyncSession, *, view_id: uuid.UUID) -> SearchView:
    view = await db.get(SearchView, view_id)
    if not view:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Saved view bulunamadi")
    return view


async def create_search_view(
    db: AsyncSession,
    *,
    body: SearchViewCreate,
    user_id: uuid.UUID,
) -> SearchViewOut:
    now = datetime.now(timezone.utc)
    view = SearchView(
        id=uuid.uuid4(),
        created_by_user_id=user_id,
        surface=body.surface,
        title=body.title,
        description=body.description,
        filters=body.filters or {},
        is_shared=body.is_shared,
        created_at=now,
        updated_at=now,
    )
    db.add(view)
    await db.commit()
    await db.refresh(view)
    return _view_out(view)


async def update_search_view(
    db: AsyncSession,
    *,
    view_id: uuid.UUID,
    body: SearchViewUpdate,
    user_id: uuid.UUID,
) -> SearchViewOut:
    view = await get_search_view(db, view_id=view_id)
    if str(view.created_by_user_id) != str(user_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu saved view size ait degil")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(view, field, value)
    view.updated_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(view)
    return _view_out(view)


async def delete_search_view(
    db: AsyncSession,
    *,
    view_id: uuid.UUID,
    user_id: uuid.UUID,
) -> None:
    view = await get_search_view(db, view_id=view_id)
    if str(view.created_by_user_id) != str(user_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu saved view size ait degil")
    await db.delete(view)
    await db.commit()


async def _search_clickhouse(customer_id: str, query: SearchQuery) -> list[SearchHit]:
    if not settings.CLICKHOUSE_ENABLED:
        return []
    try:
        rows = await ch.query_syslog(
            customer_id,
            from_time=query.from_time,
            to_time=query.to_time,
            log_type=query.log_type,
            source_ip=query.source_ip,
            dest_ip=query.dest_ip,
            mac=query.mac,
            username=query.username,
            domain=query.domain,
            application=query.application,
            action=query.action,
            severity_min=query.severity_min,
            severity_max=query.severity_max,
            hostname=query.hostname,
            location_id=query.location_id,
            device_id=query.device_id,
            quick_filter=query.quick_filter,
            q=query.q,
            limit=query.limit,
            offset=query.offset,
        )
    except Exception as exc:
        log.warning("ClickHouse search failed (CH may be offline): %s", exc)
        return []

    hits: list[SearchHit] = []
    for row in rows:
        if not _row_matches_query(row, query):
            continue
        hits.append(_row_to_hit(row, customer_id, "clickhouse"))
    return hits


async def _search_archive(
    db: AsyncSession,
    customer_id: uuid.UUID,
    query: SearchQuery,
) -> list[SearchHit]:
    """Search archived syslog payloads via PostgreSQL catalog and local files."""
    if not query.from_time and not getattr(query, "include_archives", False):
        return []

    from app.modules.logs_5651.models import ArchiveIndex

    conditions = [ArchiveIndex.customer_id == customer_id]
    if query.from_time:
        conditions.append(ArchiveIndex.period_end >= query.from_time)
    if query.to_time:
        conditions.append(ArchiveIndex.period_start <= query.to_time)
    if query.location_id:
        conditions.append(ArchiveIndex.location_id == query.location_id)

    stmt = select(ArchiveIndex).where(and_(*conditions)).order_by(ArchiveIndex.period_start.desc()).limit(10)
    result = await db.execute(stmt)
    indices = result.scalars().all()

    hits: list[SearchHit] = []
    for idx in indices:
        if not _archive_index_matches_query(idx, query):
            continue

        rows = await _load_archive_rows(idx)
        if rows is None:
            continue

        for row in rows:
            if not _row_matches_query(row, query):
                continue
            hits.append(_row_to_hit(row, customer_id, "archive", idx))  # type: ignore[arg-type]
            if len(hits) >= query.limit:
                break
        if len(hits) >= query.limit:
            break

    return hits


async def _search_postgres(
    db: AsyncSession,
    customer_id: uuid.UUID,
    query: SearchQuery,
) -> tuple[list[SearchHit], int]:
    """Fallback search against the parsed, append-only ``firewall_logs`` table.

    The old implementation queried the legacy ``syslog_records`` table, which
    is not populated by the FortiGate listener.  That made the unified search
    silently return no live firewall events whenever ClickHouse was disabled.
    """
    customer_uuid = _parse_uuid(customer_id)
    if customer_uuid is None:
        return [], 0

    conditions = [FirewallLog.customer_id == customer_uuid]
    if query.log_type:
        log_types = [value.strip() for value in query.log_type.split(",") if value.strip()]
        if log_types:
            conditions.append(effective_firewall_log_type_column().in_(log_types))
    # Use the same corrected event-time expression as the normal firewall
    # search. Older rows may contain a FortiGate +0300 wall-clock timestamp;
    # filtering the raw column would put those records in the wrong window.
    timestamp = effective_firewall_event_time_column()
    if query.from_time:
        conditions.append(timestamp >= query.from_time)
    if query.to_time:
        conditions.append(timestamp <= query.to_time)
    if query.source_ip:
        conditions.append(FirewallLog.src_ip == query.source_ip)
    if query.dest_ip:
        conditions.append(FirewallLog.dst_ip == query.dest_ip)
    if query.username:
        conditions.append(FirewallLog.user == query.username)
    if query.application:
        conditions.append(FirewallLog.service == query.application)
    if query.action:
        conditions.append(FirewallLog.action == query.action)
    if query.device_id:
        try:
            conditions.append(FirewallLog.device_id == _parse_uuid(query.device_id))
        except ValueError:
            return [], 0
    if query.location_id:
        try:
            location_uuid = _parse_uuid(query.location_id)
        except ValueError:
            return [], 0
        conditions.append(
            FirewallLog.device_id.in_(
                select(Device.id).where(Device.location_id == location_uuid)
            )
        )
    if query.hostname:
        conditions.append(
            or_(
                FirewallLog.parsed_fields["devname"].astext == query.hostname,
                FirewallLog.parsed_fields["hostname"].astext == query.hostname,
            )
        )
    if query.mac:
        conditions.append(FirewallLog.raw_syslog.ilike(f"%{query.mac}%"))
    if query.q:
        needle = f"%{query.q}%"
        conditions.append(
            or_(
                FirewallLog.raw_syslog.ilike(needle),
                FirewallLog.src_ip.ilike(needle),
                FirewallLog.dst_ip.ilike(needle),
                FirewallLog.user.ilike(needle),
                FirewallLog.service.ilike(needle),
                FirewallLog.action.ilike(needle),
            )
        )

    if query.quick_filter:
        qf = query.quick_filter.lower().strip()
        if qf == "denied":
            conditions.append(FirewallLog.action.in_(["deny", "blocked", "drop", "client-rst", "server-rst", "timeout"]))
        elif qf == "vpn":
            conditions.append(FirewallLog.log_type == "vpn")
        elif qf == "webfilter":
            conditions.append(FirewallLog.log_type.in_(["webfilter", "utm"]))
        elif qf in ("appctrl", "app-ctrl"):
            conditions.append(FirewallLog.log_type.in_(["app-ctrl", "appctrl", "application"]))
        elif qf in ("threats", "critical"):
            conditions.append(FirewallLog.severity.in_(["emergency", "alert", "critical", "error", "warning"]))
    else:
        effective_severity = effective_firewall_severity_column()
        severity_rank = case(
            (effective_severity == "emergency", 0),
            (effective_severity == "alert", 1),
            (effective_severity == "critical", 2),
            (effective_severity == "error", 3),
            (effective_severity == "warning", 4),
            (effective_severity == "notice", 5),
            (effective_severity == "info", 6),
            else_=7,
        )
        if query.severity_min is not None:
            conditions.append(severity_rank >= query.severity_min)
        if query.severity_max is not None:
            conditions.append(severity_rank <= query.severity_max)

    stmt = (
        select(FirewallLog)
        .where(and_(*conditions))
        .order_by(timestamp.desc())
        .limit(query.limit)
        .offset(query.offset)
    )
    result = await db.execute(stmt)
    rows = list(result.scalars().all())
    total = query.offset + len(rows) + (1 if len(rows) == query.limit else 0)

    hits: list[SearchHit] = []
    for row in rows:
        parsed = row.parsed_fields or {}
        hostname = str(parsed.get("devname") or parsed.get("hostname") or "fortigate-fw")
        normalized_severity = _effective_firewall_severity(row)
        rank = {
            "emergency": 0, "alert": 1, "critical": 2, "error": 3,
            "warning": 4, "notice": 5, "info": 6, "debug": 7,
        }.get(normalized_severity, 6)
        log_type = _effective_firewall_log_type(row)
        raw_ts = _effective_firewall_event_time(row) or row.received_at
        ts_iso = (raw_ts.astimezone(timezone.utc) if raw_ts.tzinfo else raw_ts.replace(tzinfo=timezone.utc)).isoformat()
        hits.append(
            SearchHit(
                timestamp=ts_iso,
                customer_id=str(row.customer_id),
                location_id=None,
                device_id=str(row.device_id) if row.device_id else None,
                facility="firewall",
                log_type=log_type,
                log_subtype=str(row.log_subtype or parsed.get("subtype") or "") or None,
                severity=rank,
                hostname=hostname,
                source_ip=str(row.src_ip or "::"),
                dest_ip=str(row.dst_ip or "::"),
                username=str(row.user or ""),
                application=str(row.service or ""),
                action=str(row.action or ""),
                message=_firewall_log_message(row, log_type) or str(row.raw_syslog or ""),
                raw=str(row.raw_syslog or (row.parsed_fields or {}).get("msg") or _firewall_log_message(row, log_type) or ""),
                session_id=str(row.session_id) if row.session_id else None,
                source="postgres",
            )
        )
    return hits, total


def _archive_index_matches_query(idx, query: SearchQuery) -> bool:
    searchable = idx.searchable_fields or {}

    if query.source_ip and query.source_ip not in searchable.get("ips", []):
        return False
    if query.dest_ip and query.dest_ip not in searchable.get("ips", []):
        return False
    if query.mac and query.mac.upper() not in searchable.get("macs", []):
        return False
    if query.username and query.username not in searchable.get("users", []):
        return False
    if query.domain and query.domain not in searchable.get("domains", []):
        return False
    if query.device_id and query.device_id not in searchable.get("devices", []):
        return False
    if query.location_id and str(getattr(idx, "location_id", "") or "") != str(query.location_id):
        return False

    return True


def _normalize_severity_int(val: Any) -> int:
    if isinstance(val, int):
        return val
    if isinstance(val, str):
        val = val.strip().lower()
        if val.isdigit():
            return int(val)
        return {
            "emergency": 0, "emerg": 0,
            "alert": 1,
            "critical": 2, "crit": 2,
            "error": 3, "err": 3,
            "warning": 4, "warn": 4,
            "notice": 5,
            "info": 6, "information": 6,
            "debug": 7,
        }.get(val, 5)
    return 5


def _row_matches_query(row: dict, query: SearchQuery) -> bool:
    if query.log_type:
        requested_types = {value.strip().lower() for value in query.log_type.split(",") if value.strip()}
        if requested_types and (_effective_hit_log_type(row) or "").lower() not in requested_types and str(row.get("app_name", "")).lower() not in requested_types:
            return False
    if query.source_ip and query.source_ip not in str(row.get("source_ip", "")):
        return False
    if query.dest_ip and query.dest_ip not in str(row.get("dest_ip", "")):
        return False
    if query.mac and str(row.get("mac", "")).upper() != query.mac.upper():
        return False
    if query.username and query.username.lower() not in str(row.get("username", "")).lower():
        return False
    if query.domain and query.domain.lower() not in str(row.get("domain", "")).lower():
        return False
    if query.application and query.application.lower() not in str(row.get("application", "")).lower():
        return False
    if query.action and str(row.get("action", "")).lower() != query.action.lower():
        return False
    if query.device_id and str(row.get("device_id", "")) != str(query.device_id):
        return False
    if query.location_id and str(row.get("location_id", "")) != str(query.location_id):
        return False
    if query.hostname and query.hostname.lower() not in str(row.get("hostname", "")).lower():
        return False
    row_sev = _normalize_severity_int(row.get("severity", 5))
    if query.severity_min is not None and row_sev < query.severity_min:
        return False
    if query.severity_max is not None and row_sev > query.severity_max:
        return False
    if query.q:
        needle = query.q.lower().strip()
        haystack = " ".join(
            str(row.get(field, "") or "")
            for field in (
                "message",
                "raw",
                "hostname",
                "app_name",
                "username",
                "domain",
                "source_ip",
                "dest_ip",
                "mac",
                "application",
                "action",
                "facility",
            )
        ).lower()
        if needle not in haystack:
            return False
    return True


def _postgres_row_matches_query(row, query: SearchQuery) -> bool:
    if query.hostname and str(row.hostname or "") != query.hostname:
        return False
    if query.application and str(row.app_name or "") != query.application:
        return False
    if query.severity_min is not None and _normalize_severity_int(row.severity) < query.severity_min:
        return False
    if query.severity_max is not None and _normalize_severity_int(row.severity) > query.severity_max:
        return False
    if query.q:
        haystack = " ".join(
            str(value or "")
            for value in (row.message, row.hostname, row.app_name)
        ).lower()
        if query.q.lower() not in haystack:
            return False
    return True


async def _load_archive_rows(idx) -> list[dict] | None:
    try:
        payload = archive_service.read_archive_payload(str(getattr(idx, "file_ref", "") or ""))
        if payload is None:
            return None
        if isinstance(payload, bytes):
            if payload.startswith(b"\x1f\x8b"):
                import gzip
                try:
                    payload = gzip.decompress(payload)
                except Exception:
                    pass
            try:
                raw_text = payload.decode("utf-8", errors="replace")
            except Exception:
                raw_text = payload.decode("latin-1", errors="replace")
        else:
            raw_text = str(payload)

        rows: list[dict] = []
        for line in raw_text.splitlines():
            line_clean = line.strip()
            if not line_clean:
                continue
            try:
                item = json.loads(line_clean)
                if isinstance(item, dict):
                    rows.append(item)
            except Exception:
                continue
        return rows
    except Exception:
        return None


def _row_to_hit(
    row: dict,
    fallback_customer_id: str,
    source: str,
    idx=None,
) -> SearchHit:
    log_type = _effective_hit_log_type(row)
    return SearchHit(
        timestamp=_row_timestamp(row, idx),
        customer_id=str(row.get("customer_id", fallback_customer_id)),
        location_id=str(row.get("location_id", "")) or None,
        device_id=str(row.get("device_id", "")) or None,
        facility=str(row.get("facility", "unknown")),
        log_type=log_type,
        log_subtype=str(row.get("log_subtype") or "") or None,
        severity=_normalize_severity_int(row.get("severity", 5)),
        hostname=str(row.get("hostname", "")),
        source_ip=str(row.get("source_ip", "::")),
        dest_ip=str(row.get("dest_ip", "::")),
        mac=str(row.get("mac", "")),
        username=str(row.get("username", "")),
        domain=str(row.get("domain", "")),
        application=str(row.get("application") or row.get("app_name") or ""),
        action=str(row.get("action", "")),
        message=str(row.get("message", "")),
        raw=str(row.get("raw") or row.get("message") or ""),
        session_id=str(row.get("session_id", "")) or None,
        source=source,
    )


def _effective_hit_log_type(row: dict) -> str | None:
    """Normalize ClickHouse/archive rows using the same VPN rules as SQL."""
    raw = str(row.get("log_type") or row.get("app_name") or "").lower()
    if raw == "vpn":
        return "vpn"
    haystack = " ".join(
        str(row.get(key) or "")
        for key in ("message", "raw", "action", "log_subtype", "eventtype")
    ).lower()
    if any(token in haystack for token in ("subtype=vpn", "ssl vpn", "sslvpn", "ipsec", "tunnel-up", "tunnel-down")):
        return "vpn"
    if raw == "utm" and "webfilter" in haystack:
        return "webfilter"
    if raw == "utm" and ("app-ctrl" in haystack or "application control" in haystack):
        return "app-ctrl"
    if raw == "utm" and "subtype=dns" in haystack:
        return "dns"
    return raw or None


def _row_timestamp(row: dict, idx=None) -> str:
    ts = row.get("timestamp")
    if hasattr(ts, "isoformat"):
        if ts.tzinfo is None:
            return ts.replace(tzinfo=timezone.utc).isoformat()
        return ts.astimezone(timezone.utc).isoformat()
    if ts:
        s = str(ts).strip().replace(" ", "T")
        if not s.endswith("Z") and "+" not in s:
            return f"{s}Z"
        return s
    if idx is not None:
        return idx.period_end.isoformat()
    return datetime.now(timezone.utc).isoformat()


def _parse_uuid(value: str) -> uuid.UUID:
    try:
        return uuid.UUID(str(value))
    except (TypeError, ValueError):
        raise ValueError("Gecersiz customer_id")


def _sort_timestamp(hit: SearchHit) -> str:
    return hit.timestamp


def _hit_sort_key(hit: SearchHit) -> datetime:
    return _parse_hit_timestamp(hit.timestamp) or datetime.min.replace(tzinfo=timezone.utc)


async def get_traffic_data(
    scope: ScopeContext,
    days: int = 30,
) -> dict:
    """Get traffic aggregation from ClickHouse with PostgreSQL fallback."""
    customer_id = str(scope.customer_id)
    location_id = str(scope.location_id) if scope.location_id else None

    try:
        return await ch.get_traffic_aggregation(customer_id, days=days, location_id=location_id)
    except Exception as exc:
        log.warning("ClickHouse traffic query failed, falling back: %s", exc)
        from app.modules.traffic.service import get_traffic_trend

        return await get_traffic_trend(None, scope, days)  # type: ignore[arg-type]


# ──────────────────────────────────────────────
# Sprint 07b — Detaylı Hızlı Log Arama
# ──────────────────────────────────────────────


def _resolve_time_window(filters: LogSearchParams) -> tuple[datetime | None, datetime | None]:
    """Resolve from_time/to_time from explicit range or time_window preset."""
    if filters.from_time and filters.to_time:
        return filters.from_time, filters.to_time
    if filters.from_time:
        return filters.from_time, None
    if filters.to_time:
        return None, filters.to_time
    if filters.time_window:
        now = datetime.now(timezone.utc)
        mapping = {
            "15m": timedelta(minutes=15),
            "1h": timedelta(hours=1),
            "24h": timedelta(hours=24),
            "7d": timedelta(days=7),
        }
        delta = mapping.get(filters.time_window)
        if delta:
            return now - delta, now
    return None, None


def _legacy_build_where_clauses(filters: LogSearchParams, tenant_id: uuid.UUID) -> list:
    """Build WHERE clause fragments for firewall_logs search."""
    clauses = [FirewallLog.tenant_id == tenant_id]

    if filters.vendor:
        vendors = [v.strip() for v in filters.vendor.split(",") if v.strip()]
        if vendors:
            clauses.append(FirewallLog.vendor.in_(vendors))

    if filters.log_type:
        log_types = [lt.strip() for lt in filters.log_type.split(",") if lt.strip()]
        if log_types:
            clauses.append(effective_firewall_log_type_column().in_(log_types))

    if filters.severity:
        severities = [s.strip() for s in filters.severity.split(",") if s.strip()]
        if severities:
            clauses.append(FirewallLog.severity.in_(severities))

    if filters.action:
        actions = [a.strip() for a in filters.action.split(",") if a.strip()]
        if actions:
            clauses.append(FirewallLog.action.in_(actions))

    if filters.src_ip:
        if filters.src_ip.endswith("%") or filters.src_ip.endswith("."):
            clauses.append(FirewallLog.src_ip.like(filters.src_ip))
        else:
            clauses.append(FirewallLog.src_ip == filters.src_ip)

    if filters.dst_ip:
        if filters.dst_ip.endswith("%") or filters.dst_ip.endswith("."):
            clauses.append(FirewallLog.dst_ip.like(filters.dst_ip))
        else:
            clauses.append(FirewallLog.dst_ip == filters.dst_ip)

    if filters.src_port is not None:
        clauses.append(FirewallLog.src_port == filters.src_port)

    if filters.dst_port is not None:
        clauses.append(FirewallLog.dst_port == filters.dst_port)

    if filters.user:
        clauses.append(FirewallLog.user.ilike(f"%{filters.user}%"))

    if filters.device_id:
        clauses.append(FirewallLog.device_id == filters.device_id)

    if filters.location_id:
        clauses.append(
            FirewallLog.device_id.in_(
                select(Device.id).where(Device.location_id == filters.location_id)
            )
        )

    if filters.policyid is not None:
        clauses.append(FirewallLog.policyid == filters.policyid)

    if filters.service:
        clauses.append(FirewallLog.service.ilike(f"%{filters.service}%"))

    if filters.proto:
        clauses.append(FirewallLog.proto == filters.proto)

    from_time, to_time = _resolve_time_window(filters)
    if from_time:
        clauses.append(FirewallLog.event_time >= from_time)
    if to_time:
        clauses.append(FirewallLog.event_time <= to_time)

    return clauses


async def _legacy_search_firewall_logs(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
) -> LogSearchResponse:
    """Search firewall_logs with filters + optional fulltext (q) + tsvector ranking."""
    start = time.monotonic()
    tenant_id = user.tenant_id
    clauses = _legacy_build_where_clauses(filters, tenant_id)

    if filters.q:
        tsquery = func.plainto_tsquery("english", filters.q)
        clauses.append(
            FirewallLog.search_vector.op("@@")(tsquery)
        )

    base = select(FirewallLog).where(*clauses)

    count_q = select(func.count(FirewallLog.id)).where(*clauses)
    total_result = await db.execute(count_q)
    total = total_result.scalar() or 0

    if filters.q:
        rank = func.ts_rank(FirewallLog.search_vector, tsquery).label("rank")
        q = base.add_columns(rank).order_by(rank.desc(), FirewallLog.event_time.desc())
    else:
        q = base.order_by(FirewallLog.event_time.desc())

    q = q.offset(filters.offset).limit(filters.limit)

    log.debug("EXPLAIN ANALYZE equivalent: SELECT ... FROM firewall_logs WHERE ...")

    result = await db.execute(q)
    rows = result.scalars().all()

    items = [_row_to_log_item(r) for r in rows]

    took_ms = int((time.monotonic() - start) * 1000)
    return LogSearchResponse(total=total, items=items, took_ms=took_ms)


async def _legacy_get_facets(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
) -> FacetResult:
    """Compute 4 facets (vendor, log_type, severity, action) with active filters applied."""
    start = time.monotonic()
    tenant_id = user.tenant_id
    clauses = _legacy_build_where_clauses(filters, tenant_id)

    async def _facet(column) -> list[FacetValue]:
        q = (
            select(column, func.count(FirewallLog.id).label("cnt"))
            .where(*clauses)
            .group_by(column)
            .order_by(text("cnt DESC"))
            .limit(10)
        )
        res = await db.execute(q)
        return [FacetValue(value=str(row[0]), count=row[1]) for row in res]

    import asyncio

    vendor, log_type, severity, action = await asyncio.gather(
        _facet(FirewallLog.vendor),
        _facet(effective_firewall_log_type_column()),
        _facet(FirewallLog.severity),
        _facet(FirewallLog.action),
    )

    log.debug("Facets computed in %d ms", int((time.monotonic() - start) * 1000))
    return FacetResult(vendor=vendor, log_type=log_type, severity=severity, action=action)


async def correlate_session(
    db: AsyncSession,
    user,
    session_id: str,
) -> CorrelateResponse:
    """Correlate a session_id across GuestSession + FirewallLog traffic + FirewallLog auth events."""
    scope = user if isinstance(user, ScopeContext) else scope_for(user)
    if not scope.allowed:
        return CorrelateResponse()

    session_row = None
    try:
        sid_uuid = uuid.UUID(session_id)
        try:
            session_row = await sessions_service.get_session(db, sid_uuid, scope)
        except HTTPException:
            # Do not reveal whether a session exists outside the caller's
            # tenant/location scope.
            session_row = None
    except (ValueError, AttributeError):
        pass

    # Correlation is only meaningful for a session visible in the caller's
    # scope. Do not fall back to a raw session_id search: that would allow a
    # caller to probe logs belonging to another tenant when the session row is
    # hidden.
    if session_row is None:
        return CorrelateResponse()

    session_info = None
    if session_row:
        session_info = CorrelateSessionInfo(
            id=str(session_row.id),
            mac=session_row.mac,
            ip=session_row.ip,
            auth_method=session_row.auth_method,
            status=session_row.status,
            started_at=session_row.started_at.isoformat() if session_row.started_at else None,
            ended_at=session_row.ended_at.isoformat() if session_row.ended_at else None,
            bytes_in=session_row.bytes_in or 0,
            bytes_out=session_row.bytes_out or 0,
        )

    customer_id = getattr(session_row, "customer_id", None)
    if not customer_id:
        return CorrelateResponse(session=session_info)
    traffic_clauses = [
        FirewallLog.session_id == session_id,
        FirewallLog.log_type == "traffic",
        FirewallLog.customer_id == customer_id,
    ]
    auth_clauses = [
        FirewallLog.session_id == session_id,
        effective_firewall_log_type_column().in_(["event", "utm", "vpn", "webfilter", "app-ctrl", "dns"]),
        FirewallLog.customer_id == customer_id,
    ]

    traffic_q = (
        select(FirewallLog)
        .where(*traffic_clauses)
        .order_by(FirewallLog.event_time.desc())
        .limit(500)
    )
    traffic_result = await db.execute(traffic_q)
    traffic_logs = [_row_to_log_item(r) for r in traffic_result.scalars().all()]

    auth_q = (
        select(FirewallLog)
        .where(*auth_clauses)
        .order_by(FirewallLog.event_time.desc())
        .limit(500)
    )
    auth_result = await db.execute(auth_q)
    auth_logs = [_row_to_log_item(r) for r in auth_result.scalars().all()]

    timeline_raw: list[tuple] = []
    for item in traffic_logs:
        ts = item.event_time or ""
        timeline_raw.append((ts, "traffic", item.log_type, item.severity, item.action, item.raw_syslog))
    for item in auth_logs:
        ts = item.event_time or ""
        timeline_raw.append((ts, "auth", item.log_type, item.severity, item.action, item.raw_syslog))
    if session_info:
        timeline_raw.append((session_info.started_at or "", "session", None, None, None, None))
        if session_info.ended_at:
            timeline_raw.append((session_info.ended_at, "session", None, None, None, None))

    timeline_raw.sort(key=lambda x: x[0] or "")
    timeline = [
        CorrelateTimelineItem(
            event_time=t[0],
            source=t[1],
            log_type=t[2],
            severity=t[3],
            action=t[4],
            message=t[5][:200] if t[5] else None,
        )
        for t in timeline_raw
    ]

    return CorrelateResponse(
        session=session_info,
        traffic_logs=traffic_logs,
        auth_logs=auth_logs,
        timeline=timeline,
    )


_CSV_BTK_COLUMNS = [
    "event_time", "received_at", "vendor", "log_type", "severity",
    "action", "src_ip", "dst_ip", "src_port", "dst_port",
    "proto", "service", "user", "policyid", "duration",
    "sentbyte", "rcvdbyte", "session_id",
]


async def export_firewall_logs(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
    fmt: str = "csv",
    max_rows: int = 100_000,
):
    """Streaming export of firewall_logs matching filters."""
    scope = user if isinstance(user, ScopeContext) else scope_for(user)
    clauses = _build_where_clauses(filters, scope)

    q = select(FirewallLog)
    if clauses:
        q = q.where(*clauses)
    q = q.order_by(FirewallLog.event_time.desc()).limit(max_rows)
    result = await db.execute(q)
    rows = result.scalars().all()

    if fmt == "csv":
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=_CSV_BTK_COLUMNS)
        writer.writeheader()
        for r in rows:
            writer.writerow({
                "event_time": (_effective_firewall_event_time(r).isoformat() if _effective_firewall_event_time(r) else ""),
                "received_at": r.received_at.isoformat() if r.received_at else "",
                "vendor": r.vendor,
                "log_type": _effective_firewall_log_type(r),
                "severity": _effective_firewall_severity(r),
                "action": r.action or "",
                "src_ip": r.src_ip or "",
                "dst_ip": r.dst_ip or "",
                "src_port": r.src_port or "",
                "dst_port": r.dst_port or "",
                "proto": r.proto or "",
                "service": r.service or "",
                "user": r.user or "",
                "policyid": r.policyid or "",
                "duration": r.duration or "",
                "sentbyte": r.sentbyte or "",
                "rcvdbyte": r.rcvdbyte or "",
                "session_id": r.session_id or "",
            })
        csv_content = buf.getvalue()

        async def _stream():
            yield csv_content.encode("utf-8")

        return _stream(), f"firewall-logs-export-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}.csv"

    buf = io.StringIO()
    for r in rows:
        item = _row_to_log_item(r)
        buf.write(item.model_dump_json(exclude_none=True) + "\n")
    jsonl_content = buf.getvalue()

    async def _stream():
        yield jsonl_content.encode("utf-8")

    return _stream(), f"firewall-logs-export-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}.jsonl"


async def get_vpn_sessions(
    db: AsyncSession,
    scope: ScopeContext,
    *,
    customer_id: str | None = None,
) -> dict:
    """Analyze VPN traffic and event logs to extract currently active (online) vs historical VPN sessions."""
    where_clauses = [
        FirewallLog.log_type == "vpn",
    ]
    if customer_id:
        try:
            cid = uuid.UUID(customer_id)
            where_clauses.append(FirewallLog.customer_id == cid)
        except ValueError:
            pass

    user_expr = func.coalesce(
        func.nullif(FirewallLog.user, ""),
        func.nullif(FirewallLog.parsed_fields.op("->>")("user"), ""),
        func.nullif(FirewallLog.parsed_fields.op("->>")("dstuser"), ""),
        "Unknown",
    )
    ip_expr = func.coalesce(FirewallLog.src_ip, FirewallLog.parsed_fields.op("->>")("srcip"), "0.0.0.0")
    policy_expr = func.coalesce(FirewallLog.parsed_fields.op("->>")("policyname"), "SSL-VPN")
    device_expr = func.coalesce(FirewallLog.parsed_fields.op("->>")("devname"), FirewallLog.vendor)
    ts_expr = func.coalesce(FirewallLog.event_time, FirewallLog.received_at)
    date_expr = func.date_trunc("day", ts_expr)

    stmt = (
        select(
            user_expr.label("vpn_user"),
            ip_expr.label("virtual_ip"),
            policy_expr.label("policy"),
            device_expr.label("device"),
            date_expr.label("session_day"),
            func.min(ts_expr).label("connected_at"),
            func.max(ts_expr).label("last_activity"),
            func.count().label("total_events"),
            func.coalesce(func.sum(FirewallLog.rcvdbyte), 0).label("bytes_in"),
            func.coalesce(func.sum(FirewallLog.sentbyte), 0).label("bytes_out"),
        )
        .where(and_(*where_clauses, user_expr != "Unknown", user_expr != ""))
        .group_by(user_expr, ip_expr, policy_expr, device_expr, date_expr)
        .order_by(func.max(ts_expr).desc())
    )

    rows = (await db.execute(stmt)).all()
    now = datetime.now(timezone.utc)
    active_users = []
    history = []
    seen_active_keys = set()

    for r in rows:
        connected_at = r.connected_at.astimezone(timezone.utc) if r.connected_at else now
        last_act = r.last_activity.astimezone(timezone.utc) if r.last_activity else now
        diff_mins = (now - last_act).total_seconds() / 60.0
        duration_secs = max(0, int((last_act - connected_at).total_seconds()))

        # Active if event seen within last 15 minutes
        is_online = diff_mins <= 15.0
        user_key = f"{r.vpn_user}:{r.virtual_ip}"

        item = {
            "user": r.vpn_user,
            "virtual_ip": r.virtual_ip,
            "policy": r.policy,
            "device": r.device,
            "connected_at": connected_at.isoformat(),
            "last_activity": last_act.isoformat(),
            "duration_seconds": duration_secs,
            "duration_formatted": _format_duration(duration_secs) or "1 dk",
            "total_events": int(r.total_events or 0),
            "bytes_in": int(r.bytes_in or 0),
            "bytes_out": int(r.bytes_out or 0),
            "bytes_in_formatted": _format_bytes(r.bytes_in) or "0 B",
            "bytes_out_formatted": _format_bytes(r.bytes_out) or "0 B",
            "status": "online" if (is_online and user_key not in seen_active_keys) else "offline",
        }
        if is_online and user_key not in seen_active_keys:
            active_users.append(item)
            seen_active_keys.add(user_key)
        else:
            history.append(item)

    # Refine connected_at, duration and bandwidth for active sessions to the current continuous burst
    for item in active_users:
        u_name = item["user"]
        u_ip = item["virtual_ip"]
        burst_stmt = (
            select(
                ts_expr.label("event_time"),
                func.coalesce(FirewallLog.rcvdbyte, 0).label("rcvdbyte"),
                func.coalesce(FirewallLog.sentbyte, 0).label("sentbyte"),
            )
            .where(
                and_(
                    *where_clauses,
                    user_expr == u_name,
                    ip_expr == u_ip,
                    ts_expr >= (now - timedelta(hours=24)),
                )
            )
            .order_by(ts_expr.desc())
            .limit(500)
        )
        burst_rows = (await db.execute(burst_stmt)).all()
        if burst_rows:
            burst_start = burst_rows[0].event_time.astimezone(timezone.utc)
            burst_rcvd = 0
            burst_sent = 0
            burst_events = 0
            prev_ts = burst_start
            for br in burst_rows:
                br_ts = br.event_time.astimezone(timezone.utc)
                if (prev_ts - br_ts).total_seconds() > 900:  # 15 min inactivity gap defines session boundary
                    break
                burst_start = br_ts
                prev_ts = br_ts
                burst_rcvd += int(br.rcvdbyte or 0)
                burst_sent += int(br.sentbyte or 0)
                burst_events += 1

            last_act = datetime.fromisoformat(item["last_activity"])
            duration_secs = max(0, int((last_act - burst_start).total_seconds()))
            item["connected_at"] = burst_start.isoformat()
            item["duration_seconds"] = duration_secs
            item["duration_formatted"] = _format_duration(duration_secs) or "1 dk"
            item["total_events"] = burst_events
            if burst_rcvd > 0:
                item["bytes_in"] = burst_rcvd
                item["bytes_in_formatted"] = _format_bytes(burst_rcvd) or "0 B"
            if burst_sent > 0:
                item["bytes_out"] = burst_sent
                item["bytes_out_formatted"] = _format_bytes(burst_sent) or "0 B"

    total_bytes = sum(u["bytes_in"] + u["bytes_out"] for u in active_users)
    return {
        "active_users": active_users,
        "history": history[:50],
        "stats": {
            "online_count": len(active_users),
            "offline_count": len(history),
            "total_bandwidth_mb": round(total_bytes / (1024 * 1024), 2),
        },
    }


_analytics_cache: dict[str, tuple[float, dict]] = {}


async def get_firewall_analytics(
    db: AsyncSession,
    scope: ScopeContext,
    *,
    customer_id: str | None = None,
    time_range: str = "24h",
    from_time: str | None = None,
    to_time: str | None = None,
) -> dict:
    """Compute KPIs, top denied IPs, top attacked ports, and log distributions for specified time range."""
    from app.core.config import settings

    cache_key = f"analytics:{customer_id or 'all'}:{time_range}:{from_time or ''}:{to_time or ''}"
    now_ts = time.time()
    if cache_key in _analytics_cache:
        cached_time, cached_val = _analytics_cache[cache_key]
        if now_ts - cached_time < 15.0:
            return cached_val

    now = datetime.now(timezone.utc)

    if time_range == "7d":
        since_dt = now - timedelta(days=7)
        until_dt = now
    elif time_range == "30d":
        since_dt = now - timedelta(days=30)
        until_dt = now
    elif time_range == "custom" and from_time:
        from zoneinfo import ZoneInfo
        try:
            clean_from = from_time.strip().replace("Z", "+00:00")
            f_dt = datetime.fromisoformat(clean_from)
            if f_dt.tzinfo is None:
                f_dt = f_dt.replace(tzinfo=ZoneInfo("Europe/Istanbul"))
            since_dt = f_dt.astimezone(timezone.utc)
        except Exception:
            since_dt = now - timedelta(hours=24)
        if to_time:
            try:
                clean_to = to_time.strip().replace("Z", "+00:00")
                t_dt = datetime.fromisoformat(clean_to)
                if t_dt.tzinfo is None:
                    t_dt = t_dt.replace(tzinfo=ZoneInfo("Europe/Istanbul"))
                until_dt = t_dt.astimezone(timezone.utc)
            except Exception:
                until_dt = now
        else:
            until_dt = now
    else:
        since_dt = now - timedelta(hours=24)
        until_dt = now

    ch_where = f"timestamp >= '{since_dt.strftime('%Y-%m-%d %H:%M:%S')}' AND timestamp <= '{until_dt.strftime('%Y-%m-%d %H:%M:%S')}'"

    if settings.CLICKHOUSE_ENABLED:
        try:
            import clickhouse_connect
            from concurrent.futures import ThreadPoolExecutor

            def _run_ch(q_str: str):
                c = clickhouse_connect.get_client(
                    host=settings.CLICKHOUSE_HOST,
                    port=settings.CLICKHOUSE_PORT,
                    username=settings.CLICKHOUSE_USER,
                    password=settings.CLICKHOUSE_PASSWORD,
                    database=settings.CLICKHOUSE_DB,
                    connect_timeout=2,
                    send_receive_timeout=4,
                )
                return c.query(q_str).result_rows

            ch_queries = [
                # 0: Summary counts & deduplicated session bytes
                f"""
                    SELECT 
                        (SELECT count(*) FROM syslog_logs WHERE {ch_where}), 
                        (SELECT countIf(action IN ('deny', 'drop', 'reject', 'block', 'blocked')) FROM syslog_logs WHERE {ch_where}),
                        sum(max_rcvd),
                        sum(max_sent)
                    FROM (
                        SELECT 
                            if(extract(raw, 'sessionid=([0-9]+)') != '', extract(raw, 'sessionid=([0-9]+)'), toString(id)) AS sid,
                            max(toUInt64OrZero(extract(raw, 'rcvdbyte=([0-9]+)'))) AS max_rcvd,
                            max(toUInt64OrZero(extract(raw, 'sentbyte=([0-9]+)'))) AS max_sent
                        FROM syslog_logs 
                        WHERE {ch_where}
                        GROUP BY sid
                    )
                """,
                # 1: Top Denied IPs
                f"""
                    SELECT 
                        IPv6NumToString(source_ip) AS src, 
                        extract(raw, 'srccountry="?([^" ]+)"?') AS country, 
                        count(*) AS cnt 
                    FROM syslog_logs 
                    WHERE {ch_where} AND action IN ('deny', 'drop', 'reject', 'block', 'blocked') 
                    GROUP BY src, country ORDER BY cnt DESC LIMIT 10
                """,
                # 2: Top Attacked Destination Ports
                f"""
                    SELECT 
                        toUInt16OrZero(extract(raw, 'dstport=([0-9]+)')) AS port, 
                        extract(raw, 'service="?([^" ]+)"?') AS srv, 
                        count(*) AS cnt 
                    FROM syslog_logs 
                    WHERE {ch_where} AND port > 0 
                    GROUP BY port, srv ORDER BY cnt DESC LIMIT 10
                """,
                # 3: Log Types
                f"""
                    SELECT app_name, count(*) FROM syslog_logs 
                    WHERE {ch_where} GROUP BY app_name ORDER BY count(*) DESC
                """,
                # 4: Severities
                f"""
                    SELECT severity, count(*) FROM syslog_logs 
                    WHERE {ch_where} GROUP BY severity ORDER BY count(*) DESC
                """,
                # 5: Top Apps
                f"""
                    SELECT 
                        if(extract(raw, 'app="?([^" ]+)"?') != '', extract(raw, 'app="?([^" ]+)"?'), if(application != '', application, 'Unknown')) AS app, 
                        count(*) AS cnt, 
                        sum(toUInt64OrZero(extract(raw, 'sentbyte=([0-9]+)')) + toUInt64OrZero(extract(raw, 'rcvdbyte=([0-9]+)'))) AS total_b
                    FROM syslog_logs 
                    WHERE {ch_where} 
                    GROUP BY app ORDER BY cnt DESC LIMIT 8
                """,
                # 6: Top Countries
                f"""
                    SELECT 
                        extract(raw, 'dstcountry="?([^" ]+)"?') AS country, 
                        count(*) AS cnt, 
                        sum(toUInt64OrZero(extract(raw, 'sentbyte=([0-9]+)')) + toUInt64OrZero(extract(raw, 'rcvdbyte=([0-9]+)'))) AS total_b
                    FROM syslog_logs 
                    WHERE {ch_where} AND country NOT IN ('', 'Reserved') 
                    GROUP BY country ORDER BY cnt DESC LIMIT 8
                """,
                # 7: Top Sources
                f"""
                    SELECT 
                        IPv6NumToString(source_ip) AS src, 
                        if(extract(raw, 'osname="?([^" ]+)"?') != '', extract(raw, 'osname="?([^" ]+)"?'), 'Host') AS os, 
                        count(*) AS cnt, 
                        sum(toUInt64OrZero(extract(raw, 'sentbyte=([0-9]+)')) + toUInt64OrZero(extract(raw, 'rcvdbyte=([0-9]+)'))) AS total_b
                    FROM syslog_logs 
                    WHERE {ch_where} 
                    GROUP BY src, os ORDER BY total_b DESC LIMIT 8
                """,
                # 8: Top Policies
                f"""
                    SELECT 
                        extract(raw, 'policyname="?([^" ]+)"?') AS pol, 
                        count(*) AS cnt, 
                        sum(toUInt64OrZero(extract(raw, 'sentbyte=([0-9]+)')) + toUInt64OrZero(extract(raw, 'rcvdbyte=([0-9]+)'))) AS total_b
                    FROM syslog_logs 
                    WHERE {ch_where} AND extract(raw, 'policyname="?([^" ]+)"?') != '' 
                    GROUP BY pol ORDER BY cnt DESC LIMIT 8
                """,
                # 9: Top Interfaces
                f"""
                    SELECT 
                        extract(raw, 'srcintf="?([^" ]+)"?') AS intf, 
                        count(*) AS cnt 
                    FROM syslog_logs 
                    WHERE {ch_where} AND extract(raw, 'srcintf="?([^" ]+)"?') NOT IN ('', '_default', 'root') 
                    GROUP BY intf ORDER BY cnt DESC LIMIT 6
                """,
            ]

            with ThreadPoolExecutor(max_workers=10) as executor:
                ch_results = list(executor.map(_run_ch, ch_queries))

            c_row = ch_results[0][0]
            total_count = int(c_row[0])
            denied_count = int(c_row[1])
            bytes_in_total = int(c_row[2])
            bytes_out_total = int(c_row[3])

            top_denied = [
                {"ip": r[0], "country": r[1] or "Reserved", "count": int(r[2])}
                for r in ch_results[1]
            ]
            top_ports = [
                {"port": int(r[0]), "service": r[1] or "TCP/UDP", "count": int(r[2])}
                for r in ch_results[2]
            ]
            log_types = [{"type": r[0] or "other", "count": int(r[1])} for r in ch_results[3]]
            sev_names = {0: "emergency", 1: "alert", 2: "critical", 3: "error", 4: "warning", 5: "notice", 6: "info", 7: "debug"}
            severities = [{"severity": sev_names.get(int(r[0]), "info"), "count": int(r[1])} for r in ch_results[4]]
            top_apps = [
                {
                    "app": r[0],
                    "hits": int(r[1]),
                    "bytes": int(r[2]),
                    "bytes_formatted": _format_bytes(int(r[2])) or "0 B",
                }
                for r in ch_results[5]
            ]
            top_countries = [
                {
                    "country": r[0],
                    "hits": int(r[1]),
                    "bytes": int(r[2]),
                    "bytes_formatted": _format_bytes(int(r[2])) or "0 B",
                }
                for r in ch_results[6]
            ]
            top_sources = [
                {
                    "src_ip": r[0],
                    "os": r[1],
                    "hits": int(r[2]),
                    "bytes": int(r[3]),
                    "bytes_formatted": _format_bytes(int(r[3])) or "0 B",
                }
                for r in ch_results[7]
            ]
            top_policies = [
                {
                    "policy": r[0],
                    "hits": int(r[1]),
                    "bytes": int(r[2]),
                    "bytes_formatted": _format_bytes(int(r[2])) or "0 B",
                }
                for r in ch_results[8]
            ]
            top_interfaces = [{"name": r[0], "count": int(r[1])} for r in ch_results[9]]

            if total_count > 0:
                block_ratio = denied_count / max(1, total_count)
                security_score = max(72, min(99, int(100 - (block_ratio * 30))))

                res_dict = {
                    "total_logs_24h": total_count,
                    "denied_events_24h": denied_count,
                    "bytes_in": bytes_in_total,
                    "bytes_out": bytes_out_total,
                    "bytes_in_formatted": _format_bytes(bytes_in_total) or "0 B",
                    "bytes_out_formatted": _format_bytes(bytes_out_total) or "0 B",
                    "security_score": security_score,
                    "top_denied_ips": top_denied,
                    "top_ports": top_ports,
                    "top_apps": top_apps,
                    "top_countries": top_countries,
                    "top_sources": top_sources,
                    "top_policies": top_policies,
                    "top_interfaces": top_interfaces,
                    "log_types": log_types,
                    "severities": severities,
                }
                _analytics_cache[cache_key] = (now_ts, res_dict)
                return res_dict
        except Exception as exc:
            log.warning("ClickHouse analytics query fallback: %s", exc)

    ts_expr = FirewallLog.received_at

    where_base = [ts_expr >= since_dt, ts_expr <= until_dt]
    if customer_id:
        try:
            cid = uuid.UUID(customer_id)
            where_base.append(or_(FirewallLog.customer_id == cid, FirewallLog.tenant_id == cid))
        except ValueError:
            pass

    denied_actions = ["deny", "drop", "reject", "block", "blocked"]

    # 1. Total counts & Denied counts (fast indexed count)
    counts_stmt = select(
        func.count().label("total_24h"),
        func.count().filter(FirewallLog.action.in_(denied_actions)).label("denied_24h"),
    ).where(and_(*where_base))
    counts_res = (await db.execute(counts_stmt)).one()

    # Session deduplicated bytes
    bytes_sub = (
        select(
            func.max(FirewallLog.rcvdbyte).label("max_rcvd"),
            func.max(FirewallLog.sentbyte).label("max_sent"),
        )
        .where(and_(*where_base))
        .group_by(FirewallLog.session_id)
        .subquery("bsub")
    )
    bytes_stmt = select(
        func.coalesce(func.sum(bytes_sub.c.max_rcvd), 0).label("bytes_in"),
        func.coalesce(func.sum(bytes_sub.c.max_sent), 0).label("bytes_out"),
    )
    bytes_res = (await db.execute(bytes_stmt)).one()

    # 2. Recent sample for sub-second distribution metrics (scans latest 25,000 rows in <100ms)
    recent_sub = (
        select(
            FirewallLog.src_ip,
            FirewallLog.dst_port,
            FirewallLog.action,
            FirewallLog.service,
            FirewallLog.proto,
            FirewallLog.log_type,
            FirewallLog.severity,
            FirewallLog.rcvdbyte,
            FirewallLog.sentbyte,
            FirewallLog.parsed_fields,
        )
        .where(and_(*where_base))
        .order_by(FirewallLog.received_at.desc())
        .limit(10000)
        .subquery("recent")
    )

    # 3. Top Denied Source IPs
    top_denied_stmt = (
        select(
            recent_sub.c.src_ip,
            func.min(func.coalesce(recent_sub.c.parsed_fields.op("->>")("srccountry"), "Reserved")).label("country"),
            func.count().label("cnt"),
        )
        .where(recent_sub.c.action.in_(denied_actions), recent_sub.c.src_ip.is_not(None))
        .group_by(recent_sub.c.src_ip)
        .order_by(func.count().desc())
        .limit(10)
    )
    top_denied = [
        {"ip": r[0], "country": r[1] or "Reserved", "count": int(r[2])}
        for r in (await db.execute(top_denied_stmt)).all()
    ]

    # 4. Top Attacked / Target Ports
    top_ports_stmt = (
        select(
            recent_sub.c.dst_port,
            func.min(func.coalesce(recent_sub.c.service, recent_sub.c.proto, "TCP/UDP")).label("service"),
            func.count().label("cnt"),
        )
        .where(recent_sub.c.dst_port.is_not(None))
        .group_by(recent_sub.c.dst_port)
        .order_by(func.count().desc())
        .limit(10)
    )
    top_ports = [
        {"port": int(r[0]), "service": r[1] or "TCP/UDP", "count": int(r[2])}
        for r in (await db.execute(top_ports_stmt)).all()
    ]

    # 5. Log Type Distribution
    log_types_stmt = (
        select(recent_sub.c.log_type, func.count().label("cnt"))
        .group_by(recent_sub.c.log_type)
        .order_by(func.count().desc())
    )
    log_types = [
        {"type": r[0] or "traffic", "count": int(r[1])}
        for r in (await db.execute(log_types_stmt)).all()
    ]

    # 6. Severity Distribution
    severity_stmt = (
        select(recent_sub.c.severity, func.count().label("cnt"))
        .group_by(recent_sub.c.severity)
        .order_by(func.count().desc())
    )
    severities = [
        {"severity": r[0] or "info", "count": int(r[1])}
        for r in (await db.execute(severity_stmt)).all()
    ]

    # 7. Top Applications
    app_expr = func.coalesce(recent_sub.c.parsed_fields.op("->>")("app"), recent_sub.c.service, recent_sub.c.proto, "Unknown")
    top_apps_stmt = (
        select(
            app_expr.label("app"),
            func.count().label("hits"),
            func.coalesce(func.sum(func.coalesce(recent_sub.c.rcvdbyte, 0) + func.coalesce(recent_sub.c.sentbyte, 0)), 0).label("bytes"),
        )
        .group_by(app_expr)
        .order_by(func.count().desc())
        .limit(8)
    )
    top_apps = [
        {
            "app": r[0] or "Unknown",
            "hits": int(r[1]),
            "bytes": int(r[2]),
            "bytes_formatted": _format_bytes(r[2]) or "0 B",
        }
        for r in (await db.execute(top_apps_stmt)).all()
    ]

    # 8. Top Destination Countries
    dstcountry_expr = recent_sub.c.parsed_fields.op("->>")("dstcountry")
    top_countries_stmt = (
        select(
            dstcountry_expr.label("country"),
            func.count().label("hits"),
            func.coalesce(func.sum(func.coalesce(recent_sub.c.rcvdbyte, 0) + func.coalesce(recent_sub.c.sentbyte, 0)), 0).label("bytes"),
        )
        .where(dstcountry_expr.is_not(None), dstcountry_expr != "", dstcountry_expr != "Reserved")
        .group_by(dstcountry_expr)
        .order_by(func.count().desc())
        .limit(8)
    )
    top_countries = [
        {
            "country": r[0] or "Unknown",
            "hits": int(r[1]),
            "bytes": int(r[2]),
            "bytes_formatted": _format_bytes(r[2]) or "0 B",
        }
        for r in (await db.execute(top_countries_stmt)).all()
    ]

    # 9. Top Sources & Devices
    top_sources_stmt = (
        select(
            recent_sub.c.src_ip,
            func.min(func.coalesce(recent_sub.c.parsed_fields.op("->>")("osname"), recent_sub.c.parsed_fields.op("->>")("devtype"), "Host")).label("os"),
            func.count().label("hits"),
            func.coalesce(func.sum(func.coalesce(recent_sub.c.rcvdbyte, 0) + func.coalesce(recent_sub.c.sentbyte, 0)), 0).label("bytes"),
        )
        .where(recent_sub.c.src_ip.is_not(None))
        .group_by(recent_sub.c.src_ip)
        .order_by(func.sum(func.coalesce(recent_sub.c.rcvdbyte, 0) + func.coalesce(recent_sub.c.sentbyte, 0)).desc())
        .limit(8)
    )
    top_sources = [
        {
            "src_ip": r[0],
            "os": r[1] or "Host",
            "hits": int(r[2]),
            "bytes": int(r[3]),
            "bytes_formatted": _format_bytes(r[3]) or "0 B",
        }
        for r in (await db.execute(top_sources_stmt)).all()
    ]

    # 10. Top Firewall Policies
    policyname_expr = recent_sub.c.parsed_fields.op("->>")("policyname")
    top_policies_stmt = (
        select(
            policyname_expr.label("policy"),
            func.count().label("hits"),
            func.coalesce(func.sum(func.coalesce(recent_sub.c.rcvdbyte, 0) + func.coalesce(recent_sub.c.sentbyte, 0)), 0).label("bytes"),
        )
        .where(policyname_expr.is_not(None), policyname_expr != "")
        .group_by(policyname_expr)
        .order_by(func.count().desc())
        .limit(8)
    )
    top_policies = [
        {
            "policy": r[0] or "Default",
            "hits": int(r[1]),
            "bytes": int(r[2]),
            "bytes_formatted": _format_bytes(r[2]) or "0 B",
        }
        for r in (await db.execute(top_policies_stmt)).all()
    ]

    # 11. Top Interfaces
    intf_expr = recent_sub.c.parsed_fields.op("->>")("srcintf")
    top_interfaces_stmt = (
        select(intf_expr.label("intf"), func.count().label("cnt"))
        .where(intf_expr.is_not(None), intf_expr != "", intf_expr != "root")
        .group_by(intf_expr)
        .order_by(func.count().desc())
        .limit(6)
    )
    top_interfaces = [
        {"name": r[0], "count": int(r[1])}
        for r in (await db.execute(top_interfaces_stmt)).all()
    ]

    total_count = int(counts_res.total_24h or 0)
    denied_count = int(counts_res.denied_24h or 0)
    if total_count > 0:
        block_ratio = denied_count / total_count
        security_score = max(72, min(99, int(100 - (block_ratio * 30))))
    else:
        security_score = 98

    res = {
        "total_logs_24h": total_count,
        "denied_events_24h": denied_count,
        "bytes_in": int(bytes_res.bytes_in or 0),
        "bytes_out": int(bytes_res.bytes_out or 0),
        "bytes_in_formatted": _format_bytes(bytes_res.bytes_in) or "0 B",
        "bytes_out_formatted": _format_bytes(bytes_res.bytes_out) or "0 B",
        "security_score": security_score,
        "top_denied_ips": top_denied,
        "top_ports": top_ports,
        "top_apps": top_apps,
        "top_countries": top_countries,
        "top_sources": top_sources,
        "top_policies": top_policies,
        "top_interfaces": top_interfaces,
        "log_types": log_types,
        "severities": severities,
    }
    _analytics_cache[cache_key] = (now_ts, res)
    return res
