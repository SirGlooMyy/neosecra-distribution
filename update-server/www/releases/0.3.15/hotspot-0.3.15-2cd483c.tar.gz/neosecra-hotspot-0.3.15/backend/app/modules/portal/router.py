"""Portal template HTTP endpoints. Read = portal.read; write = portal.write.

The captive *flow* endpoints (render, send-code, verify, start-session) are
added in M4 — this module currently exposes template config only.
"""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from fastapi.responses import HTMLResponse

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.portal import service
from app.modules.portal.schemas import (
    PortalTemplateCreate,
    PortalTemplateHistoryOut,
    PortalTemplateOut,
    PortalTemplateUpdate,
)
from app.modules.portal.template_service import (
    get_available_templates,
    get_template_by_id,
    render_preview_html,
    apply_template_to_portal,
)

router = APIRouter()


def _require(role: str, perm: str) -> None:
    if not has_permission(role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


@router.get("", response_model=list[PortalTemplateOut], summary="List portal templates")
async def list_templates(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_templates(db, scope_for(user))


@router.get("/templates/predefined", summary="List all 15 predefined portal templates.")
async def list_predefined_templates():
    """List all 15 predefined portal templates."""
    return {
        "templates": get_available_templates(),
        "categories": ["hotel", "residence", "school", "cafe", "public", "mall", "business"],
    }


@router.get("/templates/preview/{template_id}", summary="Get HTML preview of a predefined template.")
async def preview_predefined_template(
    template_id: str,
    method: str = "sms",
    lang: str = "tr",
):
    """Get HTML preview of a predefined template."""
    html = render_preview_html(template_id, method, lang)
    return HTMLResponse(content=html)


@router.get("/{template_id}", response_model=PortalTemplateOut, summary="Get portal template")
async def get_template(
    template_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    return await service.get_template(db, template_id, scope_for(user))


@router.post("", response_model=PortalTemplateOut, status_code=status.HTTP_201_CREATED, summary="Create portal template")
async def create_template(
    body: PortalTemplateCreate, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "portal.write")
    return await service.create_template(db, body, scope_for(user), user.id, request)


@router.put("/{template_id}", response_model=PortalTemplateOut, summary="Update portal template")
async def update_template(
    template_id: uuid.UUID, body: PortalTemplateUpdate, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "portal.write")
    return await service.update_template(db, template_id, body, scope_for(user), user.id, request)


@router.get("/{template_id}/history", response_model=PortalTemplateHistoryOut, summary="Template History")
async def get_template_history(
    template_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.list_template_history(db, template_id, scope_for(user))


@router.post("/{template_id}/history/{revision}/restore", response_model=PortalTemplateOut, summary="Restore Template Revision")
async def restore_template_revision(
    template_id: uuid.UUID,
    revision: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user.role, "portal.write")
    return await service.restore_template_revision(db, template_id, revision, scope_for(user), user.id, request)


@router.delete("/{template_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Deactivate portal template")
async def delete_template(
    template_id: uuid.UUID, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "portal.write")
    await service.deactivate_template(db, template_id, scope_for(user), user.id, request)


@router.post("/{template_id}/apply-template/{predefined_id}", summary="Apply a predefined template's theme to an existing portal template.")
async def apply_predefined_template(
    template_id: uuid.UUID,
    predefined_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Apply a predefined template's theme to an existing portal template."""
    _require(user.role, "portal.write")
    tmpl_def = get_template_by_id(predefined_id)
    if not tmpl_def:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Predefined template '{predefined_id}' not found",
        )
    result = await apply_template_to_portal(
        db, template_id, predefined_id, scope_for(user), user.id, request
    )
    return PortalTemplateOut.model_validate(result)
