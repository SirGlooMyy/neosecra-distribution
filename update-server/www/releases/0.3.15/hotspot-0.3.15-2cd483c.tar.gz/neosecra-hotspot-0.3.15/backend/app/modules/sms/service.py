"""SMS OTP send/verify for the captive portal guest auth path.

Two operations:
  * send_otp  — generate a short code, hash it, persist, deliver via the
                configured provider, rate-limited per phone.
  * verify_otp — constant-time check against the latest unconsumed code bound
                 to the guest's (customer, location) site context.

This module is invoked by the PUBLIC captive flow (no admin JWT), so the scope
(customer_id/location_id) is resolved from the device the guest is behind and
passed in explicitly — OTPs are bound to a physical site to prevent cross-site
replay (Mutlak Kural #1/#2).
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import HTTPException, Request, status
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import demo_mode_enabled, settings
from app.core.crypto import decrypt
from app.core.security import rate_limit
from app.modules.audit.service import log_audit
from app.modules.sms.models import PURPOSE_PORTAL, SmsConfig, SmsOtp
from app.modules.sms.schemas import OtpResultOut

log = logging.getLogger(__name__)

_GSM_RE = re.compile(r"\D")
_MASK = "********"


def _env_runtime_config() -> dict[str, Any]:
    """Build a provider-neutral config from legacy environment settings."""
    provider = (settings.SMS_PROVIDER or "console").strip().lower()
    if provider == "netgsm":
        username = settings.NETGSM_USERCODE or settings.NETGSM_USER
        password = settings.NETGSM_PASSWORD or settings.NETGSM_PASS
        api_key = ""
        http_url = ""
    elif provider == "twilio":
        username = settings.TWILIO_ACCOUNT_SID
        password = settings.TWILIO_AUTH_TOKEN
        api_key = ""
        http_url = ""
    elif provider == "vatansms":
        username = getattr(settings, "VATANSMS_API_ID", "")
        password = ""
        api_key = settings.VATANSMS_API_KEY
        api_secret = ""
        http_url = ""
    elif provider == "iletimerkezi":
        username = password = ""
        api_key = getattr(settings, "ILETIMERKEZI_API_KEY", "")
        api_secret = getattr(settings, "ILETIMERKEZI_API_HASH", "")
        http_url = getattr(settings, "ILETIMERKEZI_API_URL", "")
    elif provider == "muttl":
        username = password = ""
        api_key = settings.MUTTL_API_KEY
        api_secret = ""
        http_url = settings.MUTTL_API_URL
    elif provider == "relateddigital":
        username = password = ""
        api_key = settings.RELATEDDIGITAL_API_KEY
        api_secret = ""
        http_url = settings.RELATEDDIGITAL_API_URL
    else:
        username = password = api_key = api_secret = ""
        http_url = settings.SMS_HTTP_URL
    if provider == "netgsm":
        api_secret = ""
    elif provider == "twilio":
        api_secret = ""
    return {
        "provider": provider,
        "username": username,
        "password": password,
        "api_key": api_key,
        "api_secret": api_secret,
        "sender": settings.NETGSM_MSGHEADER if provider == "netgsm" and settings.NETGSM_MSGHEADER else settings.TWILIO_FROM_NUMBER if provider == "twilio" and settings.TWILIO_FROM_NUMBER else settings.SMS_SENDER,
        "http_url": http_url,
        "http_token": settings.SMS_HTTP_TOKEN,
        "http_template": "",
        "provider_options": {},
    }


async def get_runtime_config(
    db: AsyncSession | None = None,
    customer_id: uuid.UUID | None = None,
) -> tuple[dict[str, Any], bool]:
    """Return effective SMS config and whether it came from the database.

    A customer-specific row wins over the legacy global (NULL customer_id)
    row.  Missing fields intentionally fall back to environment variables so
    existing installations keep working while operators migrate to the UI.
    """
    config = _env_runtime_config()
    if db is None:
        return config, False

    q = select(SmsConfig).order_by(SmsConfig.updated_at.desc())
    if customer_id is not None:
        q = q.where(or_(SmsConfig.customer_id == customer_id, SmsConfig.customer_id.is_(None)))
    else:
        q = q.where(SmsConfig.customer_id.is_(None))
    rows = list((await db.execute(q)).scalars().all())
    # Prefer an exact customer row over a global fallback, then newest row.
    rows.sort(key=lambda row: (row.customer_id != customer_id, -(row.updated_at.timestamp() if row.updated_at else 0)))
    row = rows[0] if rows else None
    if not row:
        return config, False

    config["provider"] = (row.provider or config["provider"] or "console").strip().lower()
    for field in ("username", "sender", "http_url", "http_template"):
        value = getattr(row, field, None)
        if value:
            config[field] = value
    for field, attr in (("password", "password_encrypted"), ("api_key", "api_key_encrypted"), ("api_secret", "api_secret_encrypted"), ("http_token", "http_token_encrypted")):
        value = getattr(row, attr, None)
        if value:
            try:
                config[field] = decrypt(value)
            except Exception:
                log.warning("SMS %s secret could not be decrypted", field)
    options = getattr(row, "provider_options", None)
    if isinstance(options, dict):
        # A row's explicit options override env defaults while retaining an
        # immutable copy for provider adapters.
        config["provider_options"] = dict(options)
    return config, True


# ---- phone normalization (Turkey) --------------------------------------
def normalize_tr_phone(raw: str) -> str:
    """Normalize to E.164 (+905xxxxxxxxx). Accepts 5XXXXXXXXX, 05.., +90, 90.."""
    digits = _GSM_RE.sub("", raw or "")
    if digits.startswith("90"):
        digits = digits[2:]
    elif digits.startswith("0"):
        digits = digits[1:]
    if len(digits) != 10 or digits[0] != "5":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Gecerli bir GSM numarasi girin (orn. 5XX XXX XX XX)",
        )
    return "+90" + digits


def _mask_phone(phone: str) -> str:
    # +905xx***xx** — enough for support triage, not for re-identification.
    return phone[:6] + "***" + phone[-2:] if len(phone) >= 8 else "***"


def _client_ip(request: Request | None) -> str | None:
    return request.client.host if request and request.client else None


# ---- code hashing (salted sha256, constant-time verify) ----------------
def _hash_code(code: str) -> str:
    salt = secrets.token_hex(8)
    digest = hashlib.sha256(f"{salt}:{code}".encode()).hexdigest()
    return f"{salt}${digest}"


def _verify_code(code: str, stored: str) -> bool:
    try:
        salt, digest = stored.split("$", 1)
    except ValueError:
        return False
    candidate = hashlib.sha256(f"{salt}:{code}".encode()).hexdigest()
    return hmac.compare_digest(candidate, digest)


def _gen_code() -> str:
    n = settings.SMS_OTP_LENGTH
    return f"{secrets.randbelow(10 ** n):0{n}d}"


def _build_sms_message(runtime: dict[str, Any], code: str, phone: str) -> str:
    options = runtime.get("provider_options") or {}
    company = options.get("company_name") or runtime.get("sender") or settings.SMS_SENDER or "Wi-Fi"
    ttl_seconds = int(options.get("otp_ttl_seconds") or settings.SMS_OTP_TTL_SECONDS)
    ttl_min = max(1, round(ttl_seconds / 60))
    template = options.get("message_template") or getattr(settings, "SMS_MESSAGE_TEMPLATE", None)
    if not template or "{code}" not in template:
        return f"{company} Wi-Fi doğrulama kodunuz: {code}. Bu kod {ttl_min} dakika geçerlidir."
    try:
        return template.format(code=code, company=company, ttl=ttl_min, phone=phone)
    except Exception:
        return f"{company} Wi-Fi doğrulama kodunuz: {code}"


# ---- delivery ----------------------------------------------------------
async def _deliver(
    phone: str,
    code: str,
    *,
    db: AsyncSession | None = None,
    customer_id: uuid.UUID | None = None,
) -> tuple[bool, str | None]:
    """Deliver via the configured provider. Returns (ok, error)."""
    runtime, _ = await get_runtime_config(db, customer_id)
    provider = runtime["provider"]
    message = _build_sms_message(runtime, code, phone)
    if provider in ("", "console", "log"):
        if str(getattr(settings, "ENVIRONMENT", "") or "").strip().lower() == "production" and not demo_mode_enabled():
            log.error("SMS provider is not configured for production environment (customer_id=%s)", customer_id)
            return False, "SMS servisi yapılandırılmamış"
        masked_phone = _mask_phone(phone)
        log.info("SMS OTP dispatched -> %s (provider=%s)", masked_phone, provider or "console")
        return True, None

    # Dispatch to primary provider adapter
    from app.modules.sms.providers import PROVIDER_MAP
    provider_cls = PROVIDER_MAP.get(provider)
    if provider_cls:
        try:
            instance = provider_cls(runtime)
            ok, err = await instance.send(phone, message)
            if ok:
                return True, None
            log.warning("SMS primary provider %s failed: %s, attempting smart failover", provider, err)
        except Exception as exc:
            log.error("SMS primary provider %s exception: %s, attempting smart failover", provider, exc)

    # Smart SMS Failover (Yedekli SMS Dağıtım Motoru)
    fallback_provider = (
        runtime.get("provider_options", {}).get("fallback_provider")
        or getattr(settings, "SMS_FALLBACK_PROVIDER", None)
    )
    if fallback_provider and fallback_provider.strip().lower() != provider:
        fallback_cls = PROVIDER_MAP.get(fallback_provider.strip().lower())
        if fallback_cls:
            try:
                log.info("SMS Smart Failover aktif: %s uzerinden gonderiliyor", fallback_provider)
                fallback_instance = fallback_cls(runtime)
                return await fallback_instance.send(phone, message)
            except Exception as fexc:
                log.error("SMS fallback provider %s failed: %s", fallback_provider, fexc)

    # Legacy fallback
    if provider == "http" and runtime.get("http_url"):
        return await _deliver_http(phone, code, runtime)
    return False, "no-sms-provider-configured"


async def _deliver_http(phone: str, code: str, runtime: dict[str, str] | None = None) -> tuple[bool, str | None]:
    """Minimal HTTP gateway POST. Provider-specific payload lives here; kept
    intentionally generic in MVP (adapter-style: swap per vendor later)."""
    try:
        import httpx  # lazy import — only needed when provider=http
    except ImportError:
        return False, "httpx-not-installed"
    runtime = runtime or _env_runtime_config()
    payload = {"sender": runtime.get("sender") or settings.SMS_SENDER, "to": phone, "message": f"Dogrulama kodunuz: {code}"}
    token = runtime.get("http_token") or ""
    headers = {"Authorization": f"Bearer {token}" } if token else {}
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(runtime.get("http_url") or settings.SMS_HTTP_URL, json=payload, headers=headers)
        if 200 <= resp.status_code < 300:
            return True, None
        return False, f"http-{resp.status_code}"
    except Exception as exc:  # noqa: BLE001 — delivery must not crash the flow
        return False, f"deliver-error:{type(exc).__name__}"


# ---- public operations -------------------------------------------------
async def send_otp(
    db: AsyncSession,
    *,
    phone: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    purpose: str = PURPOSE_PORTAL,
    request: Request | None = None,
) -> OtpResultOut:
    phone = normalize_tr_phone(phone)

    # Per-phone send flood guard (Redis). Key is phone-only so a guest cannot
    # bypass the limit by rotating location/device context.
    blocked, _ = await rate_limit(
        f"sms_send:{phone}",
        settings.SMS_SEND_MAX_PER_WINDOW,
        settings.SMS_SEND_WINDOW_MINUTES * 60,
    )
    if blocked:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Cok fazla kod istendi. Lutfen bir sure sonra tekrar deneyin.",
        )

    code = _gen_code()
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=settings.SMS_OTP_TTL_SECONDS)
    otp = SmsOtp(
        customer_id=customer_id,
        location_id=location_id,
        phone=phone,
        code_hash=_hash_code(code),
        purpose=purpose,
        expires_at=expires_at,
        max_attempts=settings.SMS_OTP_MAX_ATTEMPTS,
        request_ip=_client_ip(request),
    )
    delivered, err = await _deliver(phone, code, db=db, customer_id=customer_id)
    otp.delivered = delivered
    # Provider adapters return a job/message id as the second tuple value on
    # success. It is useful in the test response but must never be persisted
    # as a delivery error.
    otp.deliver_error = err if not delivered else None

    db.add(otp)
    await db.flush()
    await log_audit(
        db, "sms.otp_sent", "sms_otp", str(otp.id), None, request,
        details={"phone": _mask_phone(phone), "delivered": delivered, "purpose": purpose},
    )
    await db.commit()

    return OtpResultOut(
        state="sent",
        ttl_seconds=settings.SMS_OTP_TTL_SECONDS,
        attempts_left=settings.SMS_OTP_MAX_ATTEMPTS,
    )


async def verify_otp(
    db: AsyncSession,
    *,
    phone: str,
    code: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
) -> SmsOtp:
    """Bind to the guest's site context. Fail-closed: no matching code -> 404."""
    phone = normalize_tr_phone(phone)
    now = datetime.now(timezone.utc)

    q = (
        select(SmsOtp)
        .where(
            SmsOtp.phone == phone,
            SmsOtp.customer_id == customer_id,
            SmsOtp.verified.is_(False),
            SmsOtp.consumed_at.is_(None),
        )
        .order_by(SmsOtp.created_at.desc())
        # OTP verification is a one-shot state transition.  Keep the row lock
        # until the commit below so concurrent requests cannot both observe an
        # unverified code and mint two sessions.
        .with_for_update()
    )
    if location_id is not None:
        q = q.where(SmsOtp.location_id == location_id)

    otp = (await db.execute(q.limit(1))).scalar_one_or_none()
    if not otp:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kod bulunamadi. Once kod isteyin.",
        )
    if otp.expires_at < now:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="Kodun suresi doldu. Yeni kod isteyin.",
        )

    otp.attempts += 1
    if otp.attempts > otp.max_attempts:
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Cok fazla hatali deneme. Yeni kod isteyin.",
        )
    if not _verify_code(code, otp.code_hash):
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Hatali kod.",
        )

    otp.verified = True
    await db.commit()
    await db.refresh(otp)
    return otp


async def consume_otp(db: AsyncSession, otp_id: uuid.UUID) -> None:
    """Mark a verified OTP consumed once it has been exchanged for a session."""
    otp = await db.get(SmsOtp, otp_id)
    if otp and not otp.consumed_at:
        otp.consumed_at = datetime.now(timezone.utc)
        await db.commit()


async def send_custom_sms(
    phone: str,
    message: str,
    *,
    db: AsyncSession | None = None,
    customer_id: uuid.UUID | None = None,
) -> tuple[bool, str | None]:
    """Deliver a custom SMS message via the configured provider."""
    try:
        phone = normalize_tr_phone(phone)
    except HTTPException:
        # Invalid phone format — let caller handle with meaningful error
        return False, "invalid-phone-format"
    runtime, _ = await get_runtime_config(db, customer_id)
    provider = runtime["provider"]
    if provider in ("", "console", "log"):
        if demo_mode_enabled():
            log.warning("SMS custom delivery simulated in demo mode")
            return True, None
        return False, "sms-provider-not-configured"

    from app.modules.sms.providers import PROVIDER_MAP
    provider_cls = PROVIDER_MAP.get(provider)
    if provider_cls:
        try:
            instance = provider_cls(runtime)
            return await instance.send(phone, message)
        except Exception as exc:
            log.error("SMS provider %s failed: %s", provider, exc)
            return False, f"provider-error:{type(exc).__name__}"

    if provider == "http" and runtime.get("http_url"):
        try:
            import httpx
            payload = {"sender": runtime.get("sender") or settings.SMS_SENDER, "to": phone, "message": message}
            token = runtime.get("http_token") or ""
            headers = {"Authorization": f"Bearer {token}"} if token else {}
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(runtime.get("http_url") or settings.SMS_HTTP_URL, json=payload, headers=headers)
            if 200 <= resp.status_code < 300:
                return True, None
            return False, f"http-{resp.status_code}"
        except Exception as exc:
            return False, f"deliver-error:{type(exc).__name__}"
    return False, "no-sms-provider-configured"
