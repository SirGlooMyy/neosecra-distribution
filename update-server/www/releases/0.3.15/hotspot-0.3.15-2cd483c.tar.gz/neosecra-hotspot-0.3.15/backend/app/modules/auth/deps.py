"""Auth dependencies: JWT extraction, current-user resolution, permission
guard, MFA requirement, and tenant-scope resolution for repositories."""
import uuid
from datetime import datetime, timezone

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.security import decode_token, is_token_blacklisted
from app.core.tenant import ScopeContext, scope_for
from app.modules.auth.models import User
from app.modules.mfa.models import MfaSession

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


async def get_current_user(
    request: Request,
    token: str | None = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    credentials_exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Kimlik dogrulama gerekiyor",
        headers={"WWW-Authenticate": "Bearer"},
    )
    if not token:
        token = request.cookies.get("access_token")
    if not token:
        raise credentials_exc

    try:
        payload = decode_token(token)
    except JWTError:
        raise credentials_exc

    if payload.get("type") != "access":
        raise credentials_exc

    jti = payload.get("jti")
    if jti and await is_token_blacklisted(jti):
        raise credentials_exc

    try:
        user_id = uuid.UUID(str(payload.get("sub", "")))
    except (ValueError, AttributeError):
        raise credentials_exc

    user = await db.get(User, user_id)
    if not user or not user.is_active:
        raise credentials_exc
    return user


def require_permission(permission: str):
    """Dependency factory: returns the current user if they hold `permission`."""
    async def _dep(user: User = Depends(get_current_user)) -> User:
        if not has_permission(user.role, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Bu islem icin '{permission}' yetkisi gerekiyor",
            )
        return user
    return _dep


async def require_mfa_completed(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Ensure the user has completed MFA for this session. Checks for a
    valid verified MFA session in the current request context."""
    session_token = request.headers.get("X-MFA-Session")
    if not session_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="MFA tamamlanmamis. X-MFA-Session header gerekli.",
        )

    session = (
        await db.execute(
            select(MfaSession).where(
                MfaSession.session_token == session_token,
                MfaSession.user_id == user.id,
                MfaSession.verified.is_(True),
                MfaSession.consumed_at.is_(None),
                MfaSession.expires_at > datetime.now(timezone.utc),
            )
        )
    ).scalar_one_or_none()

    if not session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="MFA oturumu gecersiz veya sureci dolmus",
        )

    return user


async def get_scope(user: User = Depends(get_current_user)) -> ScopeContext:
    """Convenience dependency: resolved tenant scope for the current user."""
    return scope_for(user)
