"""Tenant-scoped HTTP surface for the 5651/network Analyzer."""
from __future__ import annotations

import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, Response, status
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.analyzer import service
from app.modules.analyzer.models import AnalyzerEvidenceExport, AnalyzerRawEvent, AnalyzerReport
from app.modules.audit.service import log_audit
from app.modules.analyzer.schemas import (
    AnalyzerEvidenceOut,
    AnalyzerEvidenceRequest,
    AnalyzerEventOut,
    AnalyzerFailureOut,
    AnalyzerFailureReplayOut,
    AnalyzerIdentityMap,
    AnalyzerIngestOut,
    AnalyzerIngestRequest,
    AnalyzerLegalHoldOut,
    AnalyzerLegalHoldRequest,
    AnalyzerRawEventOut,
    AnalyzerReportOut,
    AnalyzerReportRequest,
    AnalyzerSavedViewCreate,
    AnalyzerSavedViewOut,
    AnalyzerSavedViewUpdate,
    AnalyzerSearchParams,
    AnalyzerSearchResponse,
    AnalyzerSessionReconstruction,
    AnalyzerSourceHealthOut,
    AnalyzerTimelineResponse,
)
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.shared.licensing.license_service import require_licensed_module

router = APIRouter()


def _require(user: User, permission: str) -> None:
    if not has_permission(user.role, permission):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


async def _licensed(db: AsyncSession, user: User) -> None:
    # Analyzer evidence is part of the licensed 5651 capability.  A missing
    # or expired entitlement is surfaced as LICENSE_REQUIRED, never as empty
    # or simulated data.
    await require_licensed_module(db, user, "logs_5651")


async def _target_scope(db: AsyncSession, user: User, tenant_id: uuid.UUID, customer_id: uuid.UUID) -> None:
    await service.assert_customer_scope(db, scope_for(user), customer_id, tenant_id)


def _ingest_out(result: dict) -> AnalyzerIngestOut:
    normalized = result.get("normalized_event")
    failure = result.get("failure")
    replayed = bool(result.get("replayed"))
    return AnalyzerIngestOut(
        raw_event_id=result["raw_event"].id,
        normalized_event_id=normalized.id if normalized is not None else None,
        status="replayed" if replayed else ("normalized" if normalized is not None else "failed"),
        raw_sha256=result["raw_sha256"],
        normalized_sha256=normalized.normalized_sha256 if normalized is not None else None,
        failure_id=failure.id if failure is not None else None,
        provenance={
            "raw_event_id": str(result["raw_event"].id),
            "raw_payload": "stored_separately",
            "replayed": replayed,
        },
    )


@router.get("/events", response_model=AnalyzerSearchResponse, summary="5651 Analyzer olaylarını ara")
@router.get("/search", response_model=AnalyzerSearchResponse, include_in_schema=False)
async def search_events(
    params: AnalyzerSearchParams = Depends(),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    return await service.search_events(db, scope_for(user), params)


@router.get("/timeline", response_model=AnalyzerTimelineResponse, summary="Saatlik olay zaman çizelgesini getir")
async def analyzer_timeline(
    params: AnalyzerSearchParams = Depends(),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    return await service.timeline(db, scope_for(user), params)


@router.get("/sessions/{session_id}", response_model=AnalyzerSessionReconstruction, summary="Oturum ve ağ olaylarını yeniden oluştur")
async def analyzer_session(
    session_id: str,
    ip: str | None = Query(None, max_length=64),
    mac: str | None = Query(None, max_length=32),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    return await service.reconstruct_session(db, scope_for(user), session_id, ip=ip, mac=mac)


@router.get("/identity-map", response_model=AnalyzerIdentityMap, summary="Kimlik-IP-MAC ilişkisini getir")
async def analyzer_identity_map(
    identity: str | None = Query(None, max_length=255),
    ip: str | None = Query(None, max_length=64),
    mac: str | None = Query(None, max_length=32),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    if not any((identity, ip, mac)):
        raise HTTPException(status_code=400, detail="identity, ip veya mac gerekli")
    return await service.identity_map(db, scope_for(user), identity=identity, ip=ip, mac=mac)


@router.get("/sources/health", response_model=list[AnalyzerSourceHealthOut], summary="Kaynak sağlık ve lag durumunu getir")
async def analyzer_source_health(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    return await service.list_source_health(db, scope_for(user))


@router.get("/failures", response_model=list[AnalyzerFailureOut], summary="Parser failure ve DLQ kayıtlarını getir")
async def analyzer_failures(
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    return await service.list_failures(db, scope_for(user), limit=limit)


@router.post("/failures/{failure_id}/replay", response_model=AnalyzerFailureReplayOut, summary="Parser failure kaydını yeniden oynat")
async def replay_analyzer_failure(
    failure_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.write")
    await _licensed(db, user)
    return await service.replay_failure(db, scope_for(user), failure_id, actor_id=user.id, request=request)


@router.post("/ingest", response_model=AnalyzerIngestOut, status_code=status.HTTP_201_CREATED, summary="Tenant kapsamında Analyzer olayını al")
async def ingest_analyzer_event(
    body: AnalyzerIngestRequest,
    request: Request,
    idempotency_header: str | None = Header(None, alias="Idempotency-Key"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.write")
    await _licensed(db, user)
    await _target_scope(db, user, body.tenant_id, body.customer_id)
    result = await service.ingest_event(
        db,
        tenant_id=body.tenant_id,
        customer_id=body.customer_id,
        raw_payload=body.raw_payload,
        source_name=body.source_name,
        source_type=body.source_type,
        transport=body.transport,
        source_ip=body.source_ip,
        received_at=body.received_at,
        idempotency_key=idempotency_header or body.idempotency_key,
        actor_id=user.id,
        request=request,
        scope=scope_for(user),
    )
    return _ingest_out(result)


@router.get("/raw/{raw_id}", response_model=AnalyzerRawEventOut, summary="Yetkili ham kanıt kaydını getir")
async def get_analyzer_raw(
    raw_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.raw.read")
    await _licensed(db, user)
    scope = scope_for(user)
    await service.set_rls_context(db, scope)
    predicate = service.scope_clause(AnalyzerRawEvent, scope)
    query = select(AnalyzerRawEvent).where(AnalyzerRawEvent.id == raw_id)
    if predicate is not None:
        query = query.where(predicate)
    raw = (await db.execute(query)).scalar_one_or_none()
    if raw is None:
        raise HTTPException(status_code=404, detail="Raw event bulunamadi")
    await service.log_raw_access(db, raw, actor_id=user.id, request=request)
    return AnalyzerRawEventOut(
        id=raw.id,
        tenant_id=raw.tenant_id,
        customer_id=raw.customer_id,
        source_name=raw.source_name,
        source_type=raw.source_type,
        transport=raw.transport,
        source_ip=raw.source_ip,
        received_at=raw.received_at,
        raw_payload=raw.raw_payload,
        raw_sha256=raw.raw_sha256,
        status=raw.status,
        retention_until=raw.retention_until,
        provenance=raw.provenance or {},
    )


@router.post("/legal-holds", response_model=AnalyzerLegalHoldOut, status_code=status.HTTP_201_CREATED, summary="Kanıt için legal hold aksiyonu kaydet")
async def create_analyzer_legal_hold(
    body: AnalyzerLegalHoldRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.hold")
    await _licensed(db, user)
    return await service.create_legal_hold(db, scope_for(user), body, actor_id=user.id, request=request)


@router.get("/legal-holds", response_model=list[AnalyzerLegalHoldOut], summary="Legal hold geçmişini getir")
async def list_analyzer_legal_holds(
    limit: int = Query(200, ge=1, le=1000),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    return await service.list_legal_holds(db, scope_for(user), limit=limit)


@router.get("/views", response_model=list[AnalyzerSavedViewOut], summary="Kayıtlı Analyzer görünümlerini getir")
async def list_analyzer_views(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    return await service.list_views(db, scope_for(user), user.id)


@router.post("/views", response_model=AnalyzerSavedViewOut, status_code=status.HTTP_201_CREATED, summary="Analyzer görünümünü kaydet")
async def create_analyzer_view(
    body: AnalyzerSavedViewCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.write")
    await _licensed(db, user)
    return await service.create_view(db, scope_for(user), user.id, body, request=request)


@router.put("/views/{view_id}", response_model=AnalyzerSavedViewOut, summary="Analyzer görünümünü güncelle")
async def update_analyzer_view(
    view_id: uuid.UUID,
    body: AnalyzerSavedViewUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.write")
    await _licensed(db, user)
    return await service.update_view(db, scope_for(user), user.id, view_id, body, request=request)


@router.delete("/views/{view_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Analyzer görünümünü sil")
async def delete_analyzer_view(
    view_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.write")
    await _licensed(db, user)
    await service.delete_view(db, scope_for(user), user.id, view_id, request=request)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/evidence/export", response_model=AnalyzerEvidenceOut, status_code=status.HTTP_201_CREATED, summary="Hash manifestli evidence paketi üret")
@router.post("/export", response_model=AnalyzerEvidenceOut, status_code=status.HTTP_201_CREATED, include_in_schema=False)
async def export_analyzer_evidence(
    body: AnalyzerEvidenceRequest,
    request: Request,
    idempotency_header: str | None = Header(None, alias="Idempotency-Key"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.export")
    await _licensed(db, user)
    if body.include_raw:
        _require(user, "analyzer.raw.read")
    if idempotency_header:
        body = body.model_copy(update={"idempotency_key": idempotency_header})
    export = await service.create_evidence_export(db, scope_for(user), body, actor_id=user.id, request=request)
    return AnalyzerEvidenceOut(
        export_id=export.id,
        status="ready",
        package_ref=export.package_ref,
        content_hash=export.content_hash,
        sha256_hash=export.envelope.get("sha256_hash", export.content_hash),
        file_size=export.file_size,
        envelope=export.envelope or {},
    )


@router.get("/evidence/{export_id}/download", summary="Evidence paketini bütünlük doğrulayarak indir")
async def download_analyzer_evidence(
    export_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.export")
    await _licensed(db, user)
    scope = scope_for(user)
    await service.set_rls_context(db, scope)
    predicate = service.scope_clause(AnalyzerEvidenceExport, scope)
    query = select(AnalyzerEvidenceExport).where(AnalyzerEvidenceExport.id == export_id)
    if predicate is not None:
        query = query.where(predicate)
    export = (await db.execute(query)).scalar_one_or_none()
    if export is None:
        raise HTTPException(status_code=404, detail="Evidence export bulunamadi")
    path = Path(export.package_ref.removeprefix("local:")).resolve()
    base = Path(settings.EVIDENCE_STORAGE_PATH).resolve()
    if base not in path.parents or not path.is_file():
        raise HTTPException(status_code=503, detail="Evidence storage kullanilamiyor")
    if service.file_sha256(path) != export.content_hash:
        raise HTTPException(status_code=503, detail="Evidence hash dogrulamasi basarisiz")
    await log_audit(
        db,
        "analyzer.evidence.download",
        "analyzer_evidence_export",
        str(export.id),
        str(user.id),
        request,
        details={"content_hash": export.content_hash},
        tenant_id=str(export.tenant_id),
    )
    await db.commit()
    return FileResponse(path, media_type="application/zip", filename=f"analyzer-evidence-{export.id}.zip")


@router.post("/reports", response_model=AnalyzerReportOut, status_code=status.HTTP_201_CREATED, summary="Değiştirilemez Analyzer rapor snapshotı üret")
@router.post("/report", response_model=AnalyzerReportOut, status_code=status.HTTP_201_CREATED, include_in_schema=False)
async def create_analyzer_report(
    body: AnalyzerReportRequest,
    request: Request,
    idempotency_header: str | None = Header(None, alias="Idempotency-Key"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.report")
    await _licensed(db, user)
    if idempotency_header:
        body = body.model_copy(update={"idempotency_key": idempotency_header})
    return await service.create_report(db, scope_for(user), body, actor_id=user.id, request=request)


@router.get("/reports/{report_id}", response_model=AnalyzerReportOut, summary="Analyzer rapor snapshotını getir")
async def get_analyzer_report(
    report_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.report")
    await _licensed(db, user)
    scope = scope_for(user)
    await service.set_rls_context(db, scope)
    predicate = service.scope_clause(AnalyzerReport, scope)
    query = select(AnalyzerReport).where(AnalyzerReport.id == report_id)
    if predicate is not None:
        query = query.where(predicate)
    report = (await db.execute(query)).scalar_one_or_none()
    if report is None:
        raise HTTPException(status_code=404, detail="Analyzer raporu bulunamadi")
    return report


@router.get("/reports/{report_id}/csv", summary="Analyzer raporunu CSV olarak indir")
async def download_analyzer_report_csv(
    report_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.report")
    await _licensed(db, user)
    scope = scope_for(user)
    await service.set_rls_context(db, scope)
    predicate = service.scope_clause(AnalyzerReport, scope)
    query = select(AnalyzerReport).where(AnalyzerReport.id == report_id)
    if predicate is not None:
        query = query.where(predicate)
    report = (await db.execute(query)).scalar_one_or_none()
    if report is None:
        raise HTTPException(status_code=404, detail="Analyzer raporu bulunamadi")
    return Response(
        content=service.report_csv(report),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="analyzer-report-{report.id}.csv"'},
    )


@router.get("/archive/verify", summary="5651 archive hash chain doğrulamasını çalıştır")
async def verify_analyzer_archive(
    customer_id: uuid.UUID | None = Query(None),
    record_type: str = Query("session_archive", max_length=40),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "analyzer.read")
    await _licensed(db, user)
    scope = scope_for(user)
    target = customer_id or scope.customer_id
    if target is None and scope.level.value == "global":
        target = await resolve_installation_customer(db)
    if target is None:
        raise HTTPException(status_code=400, detail="customer_id gerekli")
    await service.assert_customer_scope(db, scope, target)
    return await service.verify_archive_chain(db, scope, target, record_type=record_type)
