import logging
import uuid
from typing import Optional

from fastapi import HTTPException, status
from passlib.context import CryptContext
from sqlalchemy import func, select, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.local_auth.models import LocalUser

log = logging.getLogger(__name__)

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")


def _tr_lower(s: str) -> str:
    if not s:
        return ""
    return s.strip().replace("İ", "i").replace("I", "ı").lower()


async def create_user(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None,
    username: str,
    password: str,
    display_name: str,
    email: str | None = None,
    phone: str | None = None,
) -> LocalUser:
    clean_username = (username or "").strip()
    if not clean_username:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Kullanıcı adı boş olamaz",
        )

    tr_clean = _tr_lower(clean_username)
    existing = (
        await db.execute(
            select(LocalUser).where(
                LocalUser.customer_id == customer_id,
                or_(
                    func.lower(LocalUser.username) == clean_username.lower(),
                    func.lower(LocalUser.username) == tr_clean,
                    func.lower(func.replace(func.replace(LocalUser.username, "İ", "i"), "I", "ı")) == tr_clean,
                ),
            )
        )
    ).scalar_one_or_none()
    if existing:
        # SQLAlchemy applies a Python-side Boolean default only at flush time.
        # Treat an unsaved/partially-loaded row with ``None`` as active here;
        # only an explicit False may be reactivated. This fail-closed rule
        # prevents duplicate usernames when a stale identity is presented.
        if existing.is_active is False:
            existing.username = clean_username
            existing.password_hash = pwd_ctx.hash(password)
            existing.display_name = display_name or clean_username
            existing.email = email
            existing.phone = phone
            existing.location_id = location_id
            existing.is_active = True
            await db.commit()
            await db.refresh(existing)
            return existing

        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Bu kullanici adi zaten mevcut",
        )

    user = LocalUser(
        customer_id=customer_id,
        location_id=location_id,
        username=clean_username,
        password_hash=pwd_ctx.hash(password),
        display_name=display_name or clean_username,
        email=email,
        phone=phone,
        is_active=True,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


async def update_user(
    db: AsyncSession,
    *,
    user_id: uuid.UUID,
    customer_id: uuid.UUID,
    display_name: str | None = None,
    email: str | None = None,
    phone: str | None = None,
    password: str | None = None,
) -> LocalUser:
    user = (
        await db.execute(
            select(LocalUser).where(
                LocalUser.id == user_id,
                LocalUser.customer_id == customer_id,
            )
        )
    ).scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kullanici bulunamadi",
        )

    if display_name is not None:
        user.display_name = display_name
    if email is not None:
        user.email = email
    if phone is not None:
        user.phone = phone
    if password is not None:
        user.password_hash = pwd_ctx.hash(password)

    await db.commit()
    await db.refresh(user)
    return user


async def delete_user(
    db: AsyncSession,
    *,
    user_id: uuid.UUID,
    customer_id: uuid.UUID,
) -> None:
    user = (
        await db.execute(
            select(LocalUser).where(
                LocalUser.id == user_id,
                LocalUser.customer_id == customer_id,
            )
        )
    ).scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kullanici bulunamadi",
        )
    await db.delete(user)
    await db.commit()


async def deactivate_user(
    db: AsyncSession,
    *,
    user_id: uuid.UUID,
    customer_id: uuid.UUID,
) -> None:
    user = (
        await db.execute(
            select(LocalUser).where(
                LocalUser.id == user_id,
                LocalUser.customer_id == customer_id,
            )
        )
    ).scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kullanici bulunamadi",
        )
    user.is_active = False
    await db.commit()


async def authenticate(
    db: AsyncSession,
    *,
    username: str,
    password: str,
    customer_id: uuid.UUID,
) -> Optional[LocalUser]:
    clean_username = (username or "").strip()
    if not clean_username:
        return None
    tr_clean = _tr_lower(clean_username)
    user = (
        await db.execute(
            select(LocalUser).where(
                LocalUser.customer_id == customer_id,
                or_(
                    func.lower(LocalUser.username) == clean_username.lower(),
                    func.lower(LocalUser.username) == tr_clean,
                    func.lower(func.replace(func.replace(LocalUser.username, "İ", "i"), "I", "ı")) == tr_clean,
                ),
                LocalUser.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    if not user:
        return None
    if not pwd_ctx.verify(password, user.password_hash):
        return None
    return user


async def list_users(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
) -> list[LocalUser]:
    result = await db.execute(
        select(LocalUser)
        .where(LocalUser.customer_id == customer_id)
        .order_by(LocalUser.created_at.desc())
    )
    return list(result.scalars().all())
