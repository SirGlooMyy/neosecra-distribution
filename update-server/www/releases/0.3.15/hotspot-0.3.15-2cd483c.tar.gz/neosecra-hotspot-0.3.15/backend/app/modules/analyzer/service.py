"""Application services for the 5651/network Analyzer.

The Analyzer is deliberately built around a one-way ingest pipeline:

``raw payload -> parser -> immutable normalized projection``

Raw payloads are never rewritten or returned by default search responses. A
parser failure keeps the raw row and creates a durable DLQ row, so an operator
can replay it later without losing provenance.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import logging
import os
import re
import uuid
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from fastapi import HTTPException, status
from sqlalchemy import Text, and_, false, func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.rls import set_rls_context as apply_rls_context
from app.core.tenant import ScopeContext, TenantLevel, customer_in_scope
from app.modules.analyzer.models import (
    FAILURE_DEAD_LETTER,
    FAILURE_PENDING,
    FAILURE_REPLAYED,
    FAILURE_RETRYING,
    RAW_FAILED,
    RAW_NORMALIZED,
    AnalyzerEvidenceExport,
    AnalyzerIngestFailure,
    AnalyzerLegalHold,
    AnalyzerNormalizedEvent,
    AnalyzerRawEvent,
    AnalyzerReport,
    AnalyzerSourceHealth,
)
from app.modules.analyzer.schemas import (
    AnalyzerEventOut,
    AnalyzerFailureOut,
    AnalyzerIdentityMap,
    AnalyzerSavedViewOut,
    AnalyzerSearchParams,
    AnalyzerSearchResponse,
    AnalyzerSessionReconstruction,
    AnalyzerSourceHealthOut,
    AnalyzerTimelineBucket,
    AnalyzerTimelineResponse,
)
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.sessions.models import GuestSession
from app.modules.syslog.parsers import parse_firewall_syslog
from app.modules.syslog.rfc5424 import parse_rfc5424

log = logging.getLogger(__name__)

PARSER_VERSION = "fortigate-v1"
MAX_REPLAY_ATTEMPTS = 5
_SEVERITIES = ("emergency", "alert", "critical", "error", "warning", "notice", "info", "debug")


def _utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _json_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()


def _request_hash(payload: Any) -> str:
    """Fingerprint an idempotent request without including its key."""
    if hasattr(payload, "model_dump"):
        value = payload.model_dump(mode="json", exclude={"idempotency_key"})
    elif isinstance(payload, dict):
        value = {key: item for key, item in payload.items() if key != "idempotency_key"}
    else:
        value = str(payload)
    return _json_hash(value)


_SENSITIVE_FIELD_RE = re.compile(
    r"(?i)(?:password|passwd|token|secret|authorization|api[_-]?key|private[_-]?key|credential)"
)
_SENSITIVE_VALUE_RE = re.compile(
    r"(?i)\b(password|passwd|token|secret|authorization|api[_-]?key|private[_-]?key|credential)\b\s*([=:])\s*(?:\"[^\"]*\"|'[^']*'|[^\s,;]+)"
)
_RAW_FIELD_NAMES = {"raw", "raw_message", "raw_payload"}
_MAX_NORMALIZED_FIELD_TEXT = 4096


def _sanitize_fields(value: Any, *, _depth: int = 0) -> Any:
    """Keep derived fields searchable without copying raw/secrets into them."""
    if _depth > 6:
        return "[truncated]"
    if isinstance(value, dict):
        clean: dict[str, Any] = {}
        for key, item in value.items():
            key_text = str(key)
            key_lower = key_text.lower()
            if key_lower in _RAW_FIELD_NAMES:
                continue
            if _SENSITIVE_FIELD_RE.search(key_text):
                clean[key_text] = "[redacted]"
                continue
            clean[key_text] = _sanitize_fields(item, _depth=_depth + 1)
        return clean
    if isinstance(value, list):
        return [_sanitize_fields(item, _depth=_depth + 1) for item in value[:1000]]
    if isinstance(value, tuple):
        return [_sanitize_fields(item, _depth=_depth + 1) for item in value[:1000]]
    if isinstance(value, str):
        value = _SENSITIVE_VALUE_RE.sub(r"\1\2[redacted]", value)
        if len(value) > _MAX_NORMALIZED_FIELD_TEXT:
            return value[:_MAX_NORMALIZED_FIELD_TEXT] + "...[truncated]"
    return value


def _ingest_request_hash(
    *,
    tenant_id: uuid.UUID,
    customer_id: uuid.UUID,
    raw_sha256: str,
    source_name: str,
    source_type: str,
    transport: str,
    source_ip: str | None,
    received_at: datetime,
    include_received_at: bool,
) -> str:
    """Fingerprint ingest metadata while keeping content-addressed retries stable."""
    value: dict[str, Any] = {
        "tenant_id": str(tenant_id),
        "customer_id": str(customer_id),
        "raw_sha256": raw_sha256,
        "source_name": source_name,
        "source_type": source_type,
        "transport": transport,
        "source_ip": source_ip,
    }
    # Auto-generated content keys intentionally ignore receive time; explicit
    # keys represent a caller request and therefore bind the timestamp too.
    if include_received_at:
        value["received_at"] = received_at.isoformat()
    return _json_hash(value)


def file_sha256(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    """Hash an evidence file incrementally so downloads cannot force a huge read."""
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def _assert_idempotent_payload(existing: Any, request_hash: str) -> None:
    """Reject reuse of an idempotency key with a different request body."""
    stored_hash = (getattr(existing, "provenance", None) or {}).get("request_hash")
    if stored_hash and stored_hash != request_hash:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Idempotency-Key payload uyusmazligi",
        )


def _safe_error(exc: Exception) -> str:
    """Keep parser errors useful without leaking payloads or credentials."""
    message = re.sub(r"(?i)(password|token|secret|authorization)\s*[=:]\s*[^\s,;]+", r"\1=[redacted]", str(exc))
    return message[:1000] or "parser failure"


async def _set_rls_context(db: AsyncSession, scope: ScopeContext) -> None:
    """Set request-local PostgreSQL RLS context when a real session is used."""
    await apply_rls_context(
        db,
        tenant_id=scope.tenant_id,
        customer_id=scope.customer_id if scope.level == TenantLevel.CUSTOMER else None,
        partner_id=scope.partner_id,
        location_id=scope.location_id,
        is_super_admin=scope.level == TenantLevel.GLOBAL,
    )


async def set_rls_context(db: AsyncSession, scope: ScopeContext) -> None:
    """Apply request scope for router-level direct reads."""
    await _set_rls_context(db, scope)


def scope_clause(model: Any, scope: ScopeContext):
    """Build a fail-closed predicate for every Analyzer tenant table."""
    if not scope.allowed:
        return false()
    if scope.level == TenantLevel.GLOBAL:
        return None
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        predicate = model.customer_id == scope.customer_id
        if scope.tenant_id:
            predicate = and_(predicate, model.tenant_id == scope.tenant_id)
        return predicate
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        customer_scope = select(Customer.id).where(Customer.partner_id == scope.partner_id)
        if scope.tenant_id:
            customer_scope = customer_scope.where(Customer.tenant_id == scope.tenant_id)
            return and_(model.tenant_id == scope.tenant_id, model.customer_id.in_(customer_scope))
        return model.customer_id.in_(customer_scope)
    if scope.level == TenantLevel.TENANT and scope.tenant_id:
        return model.tenant_id == scope.tenant_id
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        location_scope = select(Location.customer_id).where(Location.id == scope.location_id)
        if scope.tenant_id:
            location_scope = location_scope.join(Customer, Location.customer_id == Customer.id).where(
                Customer.tenant_id == scope.tenant_id
            )
            return and_(model.tenant_id == scope.tenant_id, model.customer_id.in_(location_scope))
        return model.customer_id.in_(location_scope)
    return false()


async def assert_customer_scope(
    db: AsyncSession,
    scope: ScopeContext,
    customer_id: uuid.UUID,
    tenant_id: uuid.UUID | None = None,
) -> None:
    """Validate both the caller scope and the customer/tenant binding."""
    if not await customer_in_scope(db, scope, customer_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Musteri scope disinda")
    if tenant_id is not None:
        customer = await db.get(Customer, customer_id)
        if customer is None or customer.tenant_id != tenant_id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Musteri tenant scope disinda")


def _parse_event(raw_payload: str, source_type: str) -> dict[str, Any]:
    """Parse a payload into the stable normalized event shape."""
    rfc = parse_rfc5424(raw_payload)
    parsed = parse_firewall_syslog(raw_payload, vendor_hint=source_type)
    fields = dict(parsed.get("parsed_fields") or {})
    if rfc:
        fields.setdefault("facility", rfc.get("facility"))
        fields.setdefault("rfc_severity", rfc.get("severity"))
        fields.setdefault("hostname", rfc.get("hostname"))
        fields.setdefault("app_name", rfc.get("app_name"))
        fields.setdefault("rfc_timestamp", rfc.get("ts"))
        fields.setdefault("message", rfc.get("msg"))

    # A line that has neither an RFC header nor a recognizable key/value
    # payload is retained as raw evidence but must not become a fake event.
    known_tokens = {
        "date", "time", "tz", "devname", "devid", "type", "subtype", "logid", "action",
        "srcip", "dstip", "srcport", "dstport", "srcmac", "dstmac", "user", "username",
        "policyid", "policyname", "sentbyte", "rcvdbyte", "duration", "sessionid", "qname",
        "dns_query", "domain", "message", "msg",
    }
    recognizable = bool(
        rfc
        or any(token.split("=", 1)[0].lower() in known_tokens for token in raw_payload.split() if "=" in token)
        or re.search(r"%ASA-|\bfilterlog(?:\s|:|,)|\b(?:hotspot|firewall),(?:info|warning|error|debug)", raw_payload, re.I)
    )
    if not recognizable:
        raise ValueError("PARSER_UNRECOGNIZED_PAYLOAD")

    def first(*keys: str) -> Any:
        for key in keys:
            value = fields.get(key)
            if value not in (None, "", "-", "N/A"):
                return value
        return None

    def as_int(value: Any) -> int | None:
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    category = str(parsed.get("log_type") or parsed.get("event_type") or "event").lower()
    if category == "unknown":
        category = "event"
    severity = str(parsed.get("severity") or "info").lower()
    if severity not in _SEVERITIES:
        severity = "info"
    occurred = None
    timestamp = first("event_time", "timestamp", "time")
    if fields.get("date") and fields.get("time"):
        timestamp = f"{fields['date']}T{fields['time']}"
        tz_raw = str(fields.get("tz") or fields.get("timezone") or "")
        if re.fullmatch(r"[+-]\d{4}", tz_raw):
            timestamp += tz_raw[:3] + ":" + tz_raw[3:]
    if timestamp:
        try:
            occurred = _utc(datetime.fromisoformat(str(timestamp).replace("Z", "+00:00")))
        except ValueError:
            occurred = None
    if occurred is None and rfc and rfc.get("ts"):
        try:
            occurred = _utc(datetime.fromisoformat(str(rfc["ts"]).replace("Z", "+00:00")))
        except ValueError:
            occurred = None

    dns_answers = first("dns_answers", "answers", "resolved_ips")
    if isinstance(dns_answers, str):
        dns_answers = [item for item in re.split(r"[,\s]+", dns_answers) if item]
    elif not isinstance(dns_answers, list):
        dns_answers = None

    return {
        "occurred_at": occurred,
        "source_name": str(parsed.get("device_name") or fields.get("devname") or fields.get("hostname") or "unknown-source"),
        "vendor": str(parsed.get("vendor") or source_type or "firewall").lower(),
        "category": category,
        "subtype": parsed.get("log_subtype") or first("subtype", "eventtype"),
        "severity": severity,
        "action": parsed.get("action") or first("action", "status"),
        "source_ip_address": parsed.get("src_ip") or first("srcip", "src_ip", "remip", "remoteip", "peerip", "src"),
        "destination_ip_address": parsed.get("dst_ip") or first("dstip", "dst_ip", "tunnelip", "assignip", "virtualip", "dst"),
        "source_mac": first("srcmac", "src_mac", "mac", "calling_station_id"),
        "destination_mac": first("dstmac", "dst_mac"),
        "source_port": parsed.get("src_port") or as_int(first("srcport", "src_port")),
        "destination_port": parsed.get("dst_port") or as_int(first("dstport", "dst_port")),
        "identity": parsed.get("user") or first("user", "username", "unauthuser", "phone", "identity"),
        "session_id": parsed.get("session_id") or first("sessionid", "session_id", "logid", "tunnelid"),
        "nat_source_ip": first("transip", "trans_src_ip", "nat_src_ip", "translated_src_ip", "srcip_nat"),
        "nat_destination_ip": first("transdst", "trans_dst_ip", "nat_dst_ip", "translated_dst_ip", "dstip_nat"),
        "nat_source_port": as_int(first("transport", "trans_src_port", "nat_src_port", "translated_src_port")),
        "nat_destination_port": as_int(first("transdport", "trans_dst_port", "nat_dst_port", "translated_dst_port")),
        "dns_query": first("qname", "dns_query", "domain", "query"),
        "dns_answers": dns_answers,
        "firewall_policy_id": parsed.get("policyid") or as_int(first("policyid", "policy_id")),
        "firewall_policy_name": first("policyname", "policy_name"),
        "bytes_sent": parsed.get("sentbyte") or as_int(first("sentbyte", "bytes_sent")),
        "bytes_received": parsed.get("rcvdbyte") or as_int(first("rcvdbyte", "bytes_received")),
        "duration_seconds": parsed.get("duration") or as_int(first("duration")),
        # Vendor parsers may retain raw_message/raw keys or credential-like
        # fields.  Never copy those into the searchable normalized projection.
        "fields": _sanitize_fields(fields),
    }


def _raw_out(raw: AnalyzerRawEvent) -> dict[str, Any]:
    return {
        "id": raw.id,
        "tenant_id": raw.tenant_id,
        "customer_id": raw.customer_id,
        "source_name": raw.source_name,
        "source_type": raw.source_type,
        "transport": raw.transport,
        "source_ip": raw.source_ip,
        "received_at": raw.received_at,
        "raw_sha256": raw.raw_sha256,
        "status": raw.status,
        "retention_until": raw.retention_until,
        "provenance": raw.provenance or {},
    }


async def log_raw_access(
    db: AsyncSession,
    raw: AnalyzerRawEvent,
    *,
    actor_id: uuid.UUID,
    request: Any = None,
) -> None:
    """Record explicit raw-payload access without exposing it in searches."""
    await log_audit(
        db,
        "analyzer.raw.read",
        "analyzer_raw_event",
        str(raw.id),
        str(actor_id),
        request,
        details={"raw_sha256": raw.raw_sha256, "content_size": raw.content_size},
        tenant_id=str(raw.tenant_id),
    )
    await db.commit()


async def _latest_holds(db: AsyncSession, raw_ids: list[uuid.UUID]) -> set[uuid.UUID]:
    if not raw_ids:
        return set()
    result = await db.execute(
        select(AnalyzerLegalHold.raw_event_id, AnalyzerLegalHold.action, AnalyzerLegalHold.created_at)
        .where(AnalyzerLegalHold.raw_event_id.in_(raw_ids))
        .order_by(AnalyzerLegalHold.created_at.asc())
    )
    state: dict[uuid.UUID, bool] = {}
    for raw_id, action, _ in result.all():
        if raw_id:
            state[raw_id] = action == "place"
    return {raw_id for raw_id, active in state.items() if active}


async def _event_outs(db: AsyncSession, rows: list[AnalyzerNormalizedEvent]) -> list[AnalyzerEventOut]:
    holds = await _latest_holds(db, [row.raw_event_id for row in rows])
    raw_hashes: dict[uuid.UUID, tuple[str, uuid.UUID, uuid.UUID]] = {}
    if rows:
        # Keep the raw hash linked to the same tenant/customer as the
        # normalized row.  The FK protects identity, while this check
        # protects against malformed legacy rows that cross-link scopes.
        raw_rows = list((await db.execute(
            select(
                AnalyzerRawEvent.id,
                AnalyzerRawEvent.raw_sha256,
                AnalyzerRawEvent.tenant_id,
                AnalyzerRawEvent.customer_id,
            ).where(AnalyzerRawEvent.id.in_([row.raw_event_id for row in rows]))
        )).all())
        raw_hashes = {
            raw_id: (raw_sha256, raw_tenant_id, raw_customer_id)
            for raw_id, raw_sha256, raw_tenant_id, raw_customer_id in raw_rows
        }
    output = []
    for row in rows:
        output.append(
            AnalyzerEventOut(
                id=row.id,
                raw_event_id=row.raw_event_id,
                tenant_id=row.tenant_id,
                customer_id=row.customer_id,
                occurred_at=row.occurred_at,
                received_at=row.received_at,
                source_name=row.source_name,
                source_type=row.source_type,
                transport=row.transport,
                vendor=row.vendor,
                category=row.category,
                subtype=row.subtype,
                severity=row.severity,
                action=row.action,
                source_ip=row.source_ip_address,
                destination_ip=row.destination_ip_address,
                source_mac=row.source_mac,
                destination_mac=row.destination_mac,
                source_port=row.source_port,
                destination_port=row.destination_port,
                identity=row.identity,
                session_id=row.session_id,
                nat_source_ip=row.nat_source_ip,
                nat_destination_ip=row.nat_destination_ip,
                nat_source_port=row.nat_source_port,
                nat_destination_port=row.nat_destination_port,
                dns_query=row.dns_query,
                dns_answers=row.dns_answers,
                firewall_policy_id=row.firewall_policy_id,
                firewall_policy_name=row.firewall_policy_name,
                bytes_sent=row.bytes_sent,
                bytes_received=row.bytes_received,
                duration_seconds=row.duration_seconds,
                fields=_sanitize_fields(row.fields or {}),
                raw_sha256=(
                    raw_hashes[row.raw_event_id][0]
                    if row.raw_event_id in raw_hashes
                    and raw_hashes[row.raw_event_id][1] == row.tenant_id
                    and raw_hashes[row.raw_event_id][2] == row.customer_id
                    else ""
                ),
                normalized_sha256=row.normalized_sha256,
                parser_version=row.parser_version,
                provenance=row.provenance or {},
                retention_until=row.retention_until,
                legal_hold=row.raw_event_id in holds,
            )
        )
    return output


async def _update_source_health(
    db: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    customer_id: uuid.UUID,
    source_name: str,
    source_type: str,
    received_at: datetime,
    parsed: bool,
    error_code: str | None = None,
) -> AnalyzerSourceHealth:
    result = await db.execute(
        select(AnalyzerSourceHealth).where(
            AnalyzerSourceHealth.tenant_id == tenant_id,
            AnalyzerSourceHealth.customer_id == customer_id,
            AnalyzerSourceHealth.source_name == source_name,
        )
    )
    health = result.scalar_one_or_none()
    now = _now()
    if health is None:
        candidate = AnalyzerSourceHealth(
            tenant_id=tenant_id,
            customer_id=customer_id,
            source_name=source_name,
            source_type=source_type,
            status="healthy" if parsed else "degraded",
            received_count=0,
            parsed_count=0,
            parser_failure_count=0,
        )
        try:
            # A concurrent first event for the same customer/source may win
            # the unique constraint.  Keep that race local to a savepoint and
            # continue updating the winner instead of aborting the ingest.
            async with db.begin_nested():
                db.add(candidate)
                await db.flush()
            health = candidate
        except IntegrityError:
            health = (
                await db.execute(
                    select(AnalyzerSourceHealth).where(
                        AnalyzerSourceHealth.tenant_id == tenant_id,
                        AnalyzerSourceHealth.customer_id == customer_id,
                        AnalyzerSourceHealth.source_name == source_name,
                    )
                )
            ).scalar_one_or_none()
            if health is None:
                raise
    health.received_count = int(health.received_count or 0) + 1
    health.last_received_at = received_at
    health.lag_seconds = max(0, int((now - received_at).total_seconds()))
    if parsed:
        health.parsed_count = int(health.parsed_count or 0) + 1
        health.last_parsed_at = now
        health.status = "healthy"
    else:
        health.parser_failure_count = int(health.parser_failure_count or 0) + 1
        health.last_failure_at = now
        health.last_error_code = error_code
        health.status = "degraded"
    return health


async def ingest_event(
    db: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    customer_id: uuid.UUID,
    raw_payload: str,
    source_name: str,
    source_type: str = "firewall",
    transport: str = "syslog",
    source_ip: str | None = None,
    received_at: datetime | None = None,
    idempotency_key: str | None = None,
    actor_id: uuid.UUID | None = None,
    request: Any = None,
    scope: ScopeContext | None = None,
    commit: bool = True,
) -> dict[str, Any]:
    """Persist raw evidence and, when possible, its normalized projection."""
    if scope is not None:
        await _set_rls_context(db, scope)
        await assert_customer_scope(db, scope, customer_id, tenant_id)
    received_was_provided = received_at is not None
    received = _utc(received_at) or _now()
    raw_sha = hashlib.sha256(raw_payload.encode("utf-8")).hexdigest()
    explicit_idempotency = bool((idempotency_key or "").strip())
    idem = (idempotency_key or "").strip() or f"sha256:{raw_sha}"
    request_hash = _ingest_request_hash(
        tenant_id=tenant_id,
        customer_id=customer_id,
        raw_sha256=raw_sha,
        source_name=source_name,
        source_type=source_type,
        transport=transport,
        source_ip=source_ip,
        received_at=received,
        include_received_at=explicit_idempotency and received_was_provided,
    )
    retention_until = received + timedelta(days=max(1, int(settings.ARCHIVE_RETENTION_DAYS or 730)))

    existing_result = await db.execute(
        select(AnalyzerRawEvent).where(
            AnalyzerRawEvent.tenant_id == tenant_id,
            AnalyzerRawEvent.customer_id == customer_id,
            AnalyzerRawEvent.idempotency_key == idem,
        )
    )
    existing = existing_result.scalar_one_or_none()
    if existing is not None:
        if existing.customer_id != customer_id or existing.raw_sha256 != raw_sha:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Idempotency-Key payload uyusmazligi")
        stored_request_hash = (existing.provenance or {}).get("request_hash")
        if stored_request_hash:
            _assert_idempotent_payload(existing, request_hash)
        elif (
            existing.source_name != source_name
            or existing.source_type != source_type
            or existing.transport != transport
            or existing.source_ip != source_ip
        ):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Idempotency-Key payload uyusmazligi")
        normalized = (
            await db.execute(select(AnalyzerNormalizedEvent).where(AnalyzerNormalizedEvent.raw_event_id == existing.id))
        ).scalar_one_or_none()
        failure = (
            await db.execute(select(AnalyzerIngestFailure).where(AnalyzerIngestFailure.raw_event_id == existing.id).order_by(AnalyzerIngestFailure.created_at.desc()).limit(1))
        ).scalar_one_or_none()
        return {
            "raw_event": existing,
            "normalized_event": normalized,
            "failure": failure,
            "status": RAW_NORMALIZED if normalized else RAW_FAILED,
            "replayed": True,
            "raw_sha256": raw_sha,
        }

    # Parse and build the derived object before inserting either row.  This
    # lets the raw evidence row be written once with its final ingest status;
    # no later status UPDATE is needed (database append-only guard).
    parsed: dict[str, Any] | None = None
    parse_error: Exception | None = None
    try:
        parsed = _parse_event(raw_payload, source_type)
    except Exception as exc:
        parse_error = exc

    raw_id = uuid.uuid4()
    raw = AnalyzerRawEvent(
        id=raw_id,
        tenant_id=tenant_id,
        customer_id=customer_id,
        source_name=source_name,
        source_type=source_type,
        transport=transport,
        source_ip=source_ip,
        received_at=received,
        raw_payload=raw_payload,
        raw_sha256=raw_sha,
        idempotency_key=idem,
        parser_version=PARSER_VERSION,
        status=RAW_NORMALIZED if parsed is not None else RAW_FAILED,
        retention_until=retention_until,
        content_size=len(raw_payload.encode("utf-8")),
        provenance={
            "source": source_name,
            "source_type": source_type,
            "transport": transport,
            "received_at": received.isoformat(),
            "parser_version": PARSER_VERSION,
            "request_hash": request_hash,
        },
    )
    normalized = None
    failure = None
    if parsed is not None:
        normalized_payload = {
            key: value.isoformat() if isinstance(value, datetime) else value
            for key, value in parsed.items()
        }
        normalized_hash = _json_hash(normalized_payload)
        normalized = AnalyzerNormalizedEvent(
            id=uuid.uuid4(),
            raw_event_id=raw.id,
            tenant_id=tenant_id,
            customer_id=customer_id,
            occurred_at=parsed["occurred_at"],
            received_at=received,
            source_name=source_name,
            source_type=source_type,
            transport=transport,
            vendor=parsed["vendor"],
            category=parsed["category"],
            subtype=parsed["subtype"],
            severity=parsed["severity"],
            action=parsed["action"],
            source_ip_address=parsed["source_ip_address"],
            destination_ip_address=parsed["destination_ip_address"],
            source_mac=parsed["source_mac"],
            destination_mac=parsed["destination_mac"],
            source_port=parsed["source_port"],
            destination_port=parsed["destination_port"],
            identity=parsed["identity"],
            session_id=parsed["session_id"],
            nat_source_ip=parsed["nat_source_ip"],
            nat_destination_ip=parsed["nat_destination_ip"],
            nat_source_port=parsed["nat_source_port"],
            nat_destination_port=parsed["nat_destination_port"],
            dns_query=parsed["dns_query"],
            dns_answers=parsed["dns_answers"],
            firewall_policy_id=parsed["firewall_policy_id"],
            firewall_policy_name=parsed["firewall_policy_name"],
            bytes_sent=parsed["bytes_sent"],
            bytes_received=parsed["bytes_received"],
            duration_seconds=parsed["duration_seconds"],
            fields=parsed["fields"],
            normalized_sha256=normalized_hash,
            parser_version=PARSER_VERSION,
            provenance={
                "raw_event_id": str(raw.id),
                "raw_sha256": raw_sha,
                "parser": PARSER_VERSION,
                "normalized_at": _now().isoformat(),
            },
            retention_until=retention_until,
        )
    else:
        error = parse_error or ValueError("PARSER_FAILED")
        error_code = str(error)[:80] if str(error).startswith("PARSER_") else "PARSER_FAILED"
        failure = AnalyzerIngestFailure(
            id=uuid.uuid4(),
            raw_event_id=raw.id,
            tenant_id=tenant_id,
            customer_id=customer_id,
            error_code=error_code,
            error_message=_safe_error(error),
            attempts=1,
            status=FAILURE_PENDING,
            provenance={"raw_sha256": raw_sha, "parser_version": PARSER_VERSION},
        )

    try:
        # A savepoint keeps an idempotency race from rolling back unrelated
        # work in a listener batch.
        async with db.begin_nested():
            # ``raw_event_id`` is backed by a database FK, but the ORM model
            # intentionally keeps the projection detached from a relationship
            # so raw and normalized evidence remain independently append-only.
            # Flush the raw envelope first; otherwise SQLAlchemy may emit the
            # normalized INSERT before its parent and PostgreSQL rejects a
            # valid live syslog event with a FK violation.
            db.add(raw)
            await db.flush([raw])
            if normalized is not None:
                db.add(normalized)
            if failure is not None:
                db.add(failure)
            await db.flush()
    except IntegrityError:
        replay = await db.execute(
            select(AnalyzerRawEvent).where(
                AnalyzerRawEvent.tenant_id == tenant_id,
                AnalyzerRawEvent.customer_id == customer_id,
                AnalyzerRawEvent.idempotency_key == idem,
            )
        )
        existing = replay.scalar_one_or_none()
        if existing and existing.customer_id == customer_id and existing.raw_sha256 == raw_sha:
            stored_request_hash = (existing.provenance or {}).get("request_hash")
            if stored_request_hash:
                _assert_idempotent_payload(existing, request_hash)
            elif (
                existing.source_name != source_name
                or existing.source_type != source_type
                or existing.transport != transport
                or existing.source_ip != source_ip
            ):
                raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Idempotency-Key payload uyusmazligi")
            normalized = (
                await db.execute(select(AnalyzerNormalizedEvent).where(AnalyzerNormalizedEvent.raw_event_id == existing.id))
            ).scalar_one_or_none()
            return {"raw_event": existing, "normalized_event": normalized, "failure": None, "status": RAW_NORMALIZED if normalized else RAW_FAILED, "replayed": True, "raw_sha256": raw_sha}
        raise

    await db.flush()
    await _update_source_health(
        db,
        tenant_id=tenant_id,
        customer_id=customer_id,
        source_name=source_name,
        source_type=source_type,
        received_at=received,
        parsed=normalized is not None,
        error_code=failure.error_code if failure is not None else None,
    )

    if actor_id:
        await log_audit(
            db,
            "analyzer.ingest",
            "analyzer_raw_event",
            str(raw.id),
            str(actor_id),
            request,
            details={"status": raw.status, "raw_sha256": raw_sha, "source_type": source_type},
            tenant_id=str(tenant_id),
        )
    if commit:
        await db.commit()
        await db.refresh(raw)
        if normalized is not None:
            await db.refresh(normalized)
    return {
        "raw_event": raw,
        "normalized_event": normalized,
        "failure": failure,
        "status": RAW_NORMALIZED if normalized else RAW_FAILED,
        "replayed": False,
        "raw_sha256": raw_sha,
    }


async def mirror_firewall_log(
    db: AsyncSession,
    entry: Any,
    *,
    commit: bool = True,
) -> dict[str, Any] | None:
    """Mirror a legacy FirewallLog into the canonical Analyzer pipeline."""
    if not getattr(entry, "tenant_id", None) or not getattr(entry, "customer_id", None):
        return None
    raw = str(getattr(entry, "raw_syslog", "") or "")
    if not raw:
        return None
    return await ingest_event(
        db,
        tenant_id=entry.tenant_id,
        customer_id=entry.customer_id,
        raw_payload=raw,
        source_name=str((getattr(entry, "parsed_fields", None) or {}).get("devname") or "firewall-syslog"),
        source_type="firewall",
        transport="syslog",
        received_at=getattr(entry, "received_at", None),
        idempotency_key=f"legacy-firewall:{entry.customer_id}:{hashlib.sha256(raw.encode('utf-8')).hexdigest()}",
        scope=ScopeContext(level=TenantLevel.TENANT, tenant_id=entry.tenant_id),
        commit=commit,
    )


def _search_clauses(
    params: AnalyzerSearchParams,
    scope: ScopeContext,
    *,
    customer_id: uuid.UUID | None = None,
) -> list[Any]:
    clauses: list[Any] = []
    scope_predicate = scope_clause(AnalyzerNormalizedEvent, scope)
    if scope_predicate is not None:
        clauses.append(scope_predicate)
    if customer_id is not None:
        # Reports and exports may be requested by a broader partner/global
        # operator, but their snapshot must remain for the explicitly named
        # customer rather than the whole caller scope.
        clauses.append(AnalyzerNormalizedEvent.customer_id == customer_id)
    if params.source_type:
        clauses.append(AnalyzerNormalizedEvent.source_type == params.source_type)
    if params.source_name:
        clauses.append(AnalyzerNormalizedEvent.source_name.ilike(f"%{params.source_name}%"))
    if params.category:
        clauses.append(AnalyzerNormalizedEvent.category == params.category)
    if params.severity:
        clauses.append(AnalyzerNormalizedEvent.severity == params.severity)
    if params.action:
        clauses.append(AnalyzerNormalizedEvent.action == params.action)
    if params.source_ip:
        clauses.append(AnalyzerNormalizedEvent.source_ip_address == params.source_ip)
    if params.destination_ip:
        clauses.append(AnalyzerNormalizedEvent.destination_ip_address == params.destination_ip)
    if params.mac:
        mac = params.mac.strip().upper()
        clauses.append(or_(func.upper(AnalyzerNormalizedEvent.source_mac) == mac, func.upper(AnalyzerNormalizedEvent.destination_mac) == mac))
    if params.identity:
        clauses.append(AnalyzerNormalizedEvent.identity.ilike(f"%{params.identity}%"))
    if params.session_id:
        clauses.append(AnalyzerNormalizedEvent.session_id == params.session_id)
    if params.nat_ip:
        clauses.append(or_(AnalyzerNormalizedEvent.nat_source_ip == params.nat_ip, AnalyzerNormalizedEvent.nat_destination_ip == params.nat_ip))
    if params.dns_query:
        clauses.append(AnalyzerNormalizedEvent.dns_query.ilike(f"%{params.dns_query}%"))
    if params.from_time:
        clauses.append(func.coalesce(AnalyzerNormalizedEvent.occurred_at, AnalyzerNormalizedEvent.received_at) >= _utc(params.from_time))
    if params.to_time:
        clauses.append(func.coalesce(AnalyzerNormalizedEvent.occurred_at, AnalyzerNormalizedEvent.received_at) <= _utc(params.to_time))
    if params.q:
        needle = f"%{params.q.replace('%', '%%')}%"
        clauses.append(or_(
            AnalyzerNormalizedEvent.identity.ilike(needle),
            AnalyzerNormalizedEvent.source_ip_address.ilike(needle),
            AnalyzerNormalizedEvent.destination_ip_address.ilike(needle),
            AnalyzerNormalizedEvent.dns_query.ilike(needle),
            AnalyzerNormalizedEvent.firewall_policy_name.ilike(needle),
            AnalyzerNormalizedEvent.fields.cast(Text).ilike(needle),
        ))
    return clauses


async def search_events(
    db: AsyncSession,
    scope: ScopeContext,
    params: AnalyzerSearchParams,
    *,
    customer_id: uuid.UUID | None = None,
) -> AnalyzerSearchResponse:
    started = _now()
    await _set_rls_context(db, scope)
    clauses = _search_clauses(params, scope, customer_id=customer_id)
    count_q = select(func.count(AnalyzerNormalizedEvent.id))
    query = select(AnalyzerNormalizedEvent)
    if clauses:
        count_q = count_q.where(*clauses)
        query = query.where(*clauses)
    total = int((await db.execute(count_q)).scalar_one() or 0)
    query = query.order_by(func.coalesce(AnalyzerNormalizedEvent.occurred_at, AnalyzerNormalizedEvent.received_at).desc(), AnalyzerNormalizedEvent.id.desc()).offset(params.offset).limit(params.limit)
    rows = list((await db.execute(query)).scalars().all())
    return AnalyzerSearchResponse(
        items=await _event_outs(db, rows),
        total=total,
        limit=params.limit,
        offset=params.offset,
        took_ms=max(0, int((_now() - started).total_seconds() * 1000)),
        provenance={"projection": "analyzer_normalized_events", "raw_payloads": "excluded"},
    )


async def timeline(db: AsyncSession, scope: ScopeContext, params: AnalyzerSearchParams) -> AnalyzerTimelineResponse:
    response = await search_events(db, scope, params.model_copy(update={"limit": min(params.limit, 1000), "offset": 0}))
    buckets: dict[datetime, dict[str, Any]] = {}
    for event in response.items:
        timestamp = event.occurred_at or event.received_at
        bucket_time = timestamp.replace(minute=0, second=0, microsecond=0)
        bucket = buckets.setdefault(bucket_time, {"count": 0, "severities": {}})
        bucket["count"] += 1
        bucket["severities"][event.severity] = bucket["severities"].get(event.severity, 0) + 1
    return AnalyzerTimelineResponse(
        events=response.items,
        buckets=[AnalyzerTimelineBucket(timestamp=key, count=value["count"], severities=value["severities"]) for key, value in sorted(buckets.items())],
        total=response.total,
        from_time=_utc(params.from_time),
        to_time=_utc(params.to_time),
    )


async def reconstruct_session(
    db: AsyncSession,
    scope: ScopeContext,
    session_id: str,
    *,
    ip: str | None = None,
    mac: str | None = None,
) -> AnalyzerSessionReconstruction:
    await _set_rls_context(db, scope)
    session = None
    try:
        parsed_session_id = uuid.UUID(str(session_id))
    except (TypeError, ValueError, AttributeError):
        parsed_session_id = None
    if parsed_session_id is not None:
        session_query = select(GuestSession).where(GuestSession.id == parsed_session_id)
        session_scope = scope_clause(GuestSession, scope)
        if session_scope is not None:
            session_query = session_query.where(session_scope)
        session = (await db.execute(session_query)).scalar_one_or_none()

    clauses: list[Any] = []
    if session is not None:
        clauses.append(AnalyzerNormalizedEvent.customer_id == session.customer_id)
    event_keys = [AnalyzerNormalizedEvent.session_id == str(session_id)]
    if ip:
        event_keys.extend(
            [AnalyzerNormalizedEvent.source_ip_address == ip, AnalyzerNormalizedEvent.destination_ip_address == ip]
        )
    if mac:
        normalized_mac = mac.strip().upper()
        event_keys.extend(
            [func.upper(AnalyzerNormalizedEvent.source_mac) == normalized_mac, func.upper(AnalyzerNormalizedEvent.destination_mac) == normalized_mac]
        )
    if session is not None:
        if session.ip:
            event_keys.append(AnalyzerNormalizedEvent.source_ip_address == session.ip)
        if session.mac:
            event_keys.append(func.upper(AnalyzerNormalizedEvent.source_mac) == session.mac.upper())
        event_keys.append(AnalyzerNormalizedEvent.session_id == str(session.id))
        if session.started_at:
            clauses.append(func.coalesce(AnalyzerNormalizedEvent.occurred_at, AnalyzerNormalizedEvent.received_at) >= session.started_at - timedelta(minutes=15))
        if session.ended_at:
            clauses.append(func.coalesce(AnalyzerNormalizedEvent.occurred_at, AnalyzerNormalizedEvent.received_at) <= session.ended_at + timedelta(minutes=15))
    scope_predicate = scope_clause(AnalyzerNormalizedEvent, scope)
    if scope_predicate is not None:
        clauses.append(scope_predicate)
    clauses.append(or_(*event_keys))
    events = list((await db.execute(select(AnalyzerNormalizedEvent).where(*clauses).order_by(func.coalesce(AnalyzerNormalizedEvent.occurred_at, AnalyzerNormalizedEvent.received_at).asc()).limit(1000))).scalars().all())
    if session is None and not events:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Oturum veya Analyzer olayi bulunamadi")
    event_outs = await _event_outs(db, events)
    return AnalyzerSessionReconstruction(
        session={
            "id": str(session.id),
            "customer_id": str(session.customer_id),
            "location_id": str(session.location_id) if session.location_id else None,
            "device_id": str(session.device_id) if session.device_id else None,
            "status": session.status,
            "started_at": session.started_at,
            "ended_at": session.ended_at,
            "auth_method": session.auth_method,
            "bytes_in": int(session.bytes_in or 0),
            "bytes_out": int(session.bytes_out or 0),
        } if session is not None else None,
        identity={"phone": session.phone, "mac": session.mac, "ip": session.ip} if session is not None else {
            "mac": mac,
            "ip": ip,
            "identities": sorted({event.identity for event in event_outs if event.identity}),
        },
        network={"nas_ip": session.nas_ip, "ssid": session.ssid, "radius_session_id": session.radius_session_id} if session is not None else {
            "sources": sorted({event.source_name for event in event_outs}),
            "nat_ips": sorted({value for event in event_outs for value in (event.nat_source_ip, event.nat_destination_ip) if value}),
        },
        events=event_outs,
        timeline=[{"timestamp": event.occurred_at or event.received_at, "category": event.category, "action": event.action, "source": event.source_name} for event in event_outs],
        provenance={"join": "session_id|ip|mac", "window_minutes": 15, "raw_payloads": "excluded", "matched_event_count": len(event_outs)},
    )


async def identity_map(db: AsyncSession, scope: ScopeContext, *, identity: str | None = None, ip: str | None = None, mac: str | None = None) -> AnalyzerIdentityMap:
    await _set_rls_context(db, scope)
    clauses: list[Any] = []
    predicate = scope_clause(AnalyzerNormalizedEvent, scope)
    if predicate is not None:
        clauses.append(predicate)
    if identity:
        clauses.append(AnalyzerNormalizedEvent.identity.ilike(f"%{identity}%"))
    if ip:
        clauses.append(
            or_(
                AnalyzerNormalizedEvent.source_ip_address == ip,
                AnalyzerNormalizedEvent.destination_ip_address == ip,
                AnalyzerNormalizedEvent.nat_source_ip == ip,
                AnalyzerNormalizedEvent.nat_destination_ip == ip,
            )
        )
    if mac:
        normalized_mac = mac.strip().upper()
        clauses.append(
            or_(
                func.upper(AnalyzerNormalizedEvent.source_mac) == normalized_mac,
                func.upper(AnalyzerNormalizedEvent.destination_mac) == normalized_mac,
            )
        )
    rows = list((await db.execute(select(AnalyzerNormalizedEvent).where(*clauses).order_by(AnalyzerNormalizedEvent.received_at.desc()).limit(1000))).scalars().all())
    events = await _event_outs(db, rows)
    macs = sorted({item for row in events for item in (row.source_mac, row.destination_mac) if item})
    ips = sorted({item for row in events for item in (row.source_ip, row.destination_ip, row.nat_source_ip, row.nat_destination_ip) if item})
    session_keys: list[Any] = []
    if ip:
        session_keys.append(GuestSession.ip == ip)
    if mac:
        session_keys.append(func.upper(GuestSession.mac) == mac.strip().upper())
    if identity:
        session_keys.append(GuestSession.phone.ilike(f"%{identity}%"))
    session_query = select(GuestSession).order_by(GuestSession.started_at.desc()).limit(100)
    session_predicate = scope_clause(GuestSession, scope)
    if session_predicate is not None:
        session_query = session_query.where(session_predicate)
    if session_keys:
        session_query = session_query.where(or_(*session_keys))
    else:
        # With no direct session key, returning an unbounded tenant session
        # list would expose unrelated identities; keep the map projection-only.
        session_query = session_query.where(false())
    session_rows = list((await db.execute(session_query)).scalars().all())
    phones = sorted({session.phone for session in session_rows if session.phone})
    sessions = [
        {
            "id": str(session.id),
            "customer_id": str(session.customer_id),
            "location_id": str(session.location_id) if session.location_id else None,
            "mac": session.mac,
            "ip": session.ip,
            "phone": session.phone,
            "status": session.status,
            "started_at": session.started_at,
            "ended_at": session.ended_at,
        }
        for session in session_rows
    ]
    return AnalyzerIdentityMap(identity=identity, phone=phones[0] if len(phones) == 1 else None, mac_addresses=macs, ip_addresses=ips, sessions=sessions, event_count=len(events), provenance={"projection": "analyzer_normalized_events", "session_projection": "guest_sessions", "raw_payloads": "excluded"})


async def list_source_health(db: AsyncSession, scope: ScopeContext) -> list[AnalyzerSourceHealthOut]:
    await _set_rls_context(db, scope)
    predicate = scope_clause(AnalyzerSourceHealth, scope)
    query = select(AnalyzerSourceHealth).order_by(AnalyzerSourceHealth.source_name.asc())
    if predicate is not None:
        query = query.where(predicate)
    rows = list((await db.execute(query)).scalars().all())
    now = _now()
    output: list[AnalyzerSourceHealthOut] = []
    for row in rows:
        item = AnalyzerSourceHealthOut.model_validate(row)
        if row.last_received_at:
            lag_seconds = max(0, int((now - row.last_received_at).total_seconds()))
            item = item.model_copy(
                update={
                    "lag_seconds": lag_seconds,
                    "status": "stale" if item.status == "healthy" and lag_seconds > 900 else item.status,
                }
            )
        output.append(item)
    return output


async def list_failures(db: AsyncSession, scope: ScopeContext, *, limit: int = 100) -> list[AnalyzerFailureOut]:
    await _set_rls_context(db, scope)
    predicate = scope_clause(AnalyzerIngestFailure, scope)
    query = select(AnalyzerIngestFailure).order_by(AnalyzerIngestFailure.created_at.desc()).limit(limit)
    if predicate is not None:
        query = query.where(predicate)
    rows = list((await db.execute(query)).scalars().all())
    return [AnalyzerFailureOut.model_validate(row) for row in rows]


async def replay_failure(db: AsyncSession, scope: ScopeContext, failure_id: uuid.UUID, *, actor_id: uuid.UUID | None = None, request: Any = None) -> dict[str, Any]:
    await _set_rls_context(db, scope)
    failure = await db.get(AnalyzerIngestFailure, failure_id)
    if failure is None:
        raise HTTPException(status_code=404, detail="Parser failure bulunamadi")
    predicate = scope_clause(AnalyzerIngestFailure, scope)
    if predicate is not None:
        check = await db.execute(select(AnalyzerIngestFailure.id).where(AnalyzerIngestFailure.id == failure_id, predicate))
        if check.scalar_one_or_none() is None:
            raise HTTPException(status_code=403, detail="Failure scope disinda")
    if failure.status == FAILURE_REPLAYED:
        return {"failure_id": failure.id, "status": FAILURE_REPLAYED, "replayed": True}
    raw = await db.get(AnalyzerRawEvent, failure.raw_event_id)
    if raw is None:
        failure.status = FAILURE_DEAD_LETTER
        failure.error_message = "raw evidence unavailable"
        await db.commit()
        raise HTTPException(status_code=503, detail="Raw evidence kullanilamiyor")
    failure.status = FAILURE_RETRYING
    failure.attempts = int(failure.attempts or 0) + 1
    failure.last_attempt_at = _now()
    await db.flush()
    try:
        parsed = _parse_event(raw.raw_payload, raw.source_type)
        normalized_hash = _json_hash({key: value.isoformat() if isinstance(value, datetime) else value for key, value in parsed.items()})
        existing = (await db.execute(select(AnalyzerNormalizedEvent).where(AnalyzerNormalizedEvent.raw_event_id == raw.id))).scalar_one_or_none()
        if existing is None:
            existing = AnalyzerNormalizedEvent(
                raw_event_id=raw.id, tenant_id=raw.tenant_id, customer_id=raw.customer_id,
                occurred_at=parsed["occurred_at"], received_at=raw.received_at, source_name=raw.source_name,
                source_type=raw.source_type, transport=raw.transport, vendor=parsed["vendor"], category=parsed["category"],
                subtype=parsed["subtype"], severity=parsed["severity"], action=parsed["action"],
                source_ip_address=parsed["source_ip_address"], destination_ip_address=parsed["destination_ip_address"],
                source_mac=parsed["source_mac"], destination_mac=parsed["destination_mac"], source_port=parsed["source_port"],
                destination_port=parsed["destination_port"], identity=parsed["identity"], session_id=parsed["session_id"],
                nat_source_ip=parsed["nat_source_ip"], nat_destination_ip=parsed["nat_destination_ip"], nat_source_port=parsed["nat_source_port"],
                nat_destination_port=parsed["nat_destination_port"], dns_query=parsed["dns_query"], dns_answers=parsed["dns_answers"],
                firewall_policy_id=parsed["firewall_policy_id"], firewall_policy_name=parsed["firewall_policy_name"],
                bytes_sent=parsed["bytes_sent"], bytes_received=parsed["bytes_received"], duration_seconds=parsed["duration_seconds"],
                fields=parsed["fields"], normalized_sha256=normalized_hash, parser_version=PARSER_VERSION,
                provenance={"raw_event_id": str(raw.id), "raw_sha256": raw.raw_sha256, "parser": PARSER_VERSION, "replayed_at": _now().isoformat()},
                retention_until=raw.retention_until,
            )
            db.add(existing)
        raw.status = RAW_NORMALIZED
        failure.status = FAILURE_REPLAYED
        failure.replayed_at = _now()
        failure.next_retry_at = None
        failure.error_message = ""
        await _update_source_health(db, tenant_id=raw.tenant_id, customer_id=raw.customer_id, source_name=raw.source_name, source_type=raw.source_type, received_at=raw.received_at, parsed=True)
        if actor_id:
            await log_audit(db, "analyzer.failure.replay", "analyzer_ingest_failure", str(failure.id), str(actor_id), request, details={"status": FAILURE_REPLAYED, "raw_sha256": raw.raw_sha256}, tenant_id=str(raw.tenant_id))
        await db.commit()
        await db.refresh(existing)
        return {"failure_id": failure.id, "normalized_event_id": existing.id, "status": FAILURE_REPLAYED, "replayed": False}
    except Exception as exc:
        failure.status = FAILURE_DEAD_LETTER if failure.attempts >= MAX_REPLAY_ATTEMPTS else FAILURE_PENDING
        failure.error_message = _safe_error(exc)
        failure.next_retry_at = _now() + timedelta(minutes=min(60, 2 ** min(failure.attempts, 6)))
        await db.commit()
        return {"failure_id": failure.id, "status": failure.status, "replayed": False, "error": failure.error_message}


async def create_legal_hold(db: AsyncSession, scope: ScopeContext, payload: Any, *, actor_id: uuid.UUID, request: Any = None) -> AnalyzerLegalHold:
    await _set_rls_context(db, scope)
    await assert_customer_scope(db, scope, payload.customer_id, payload.tenant_id)
    if not payload.raw_event_id and not payload.normalized_event_id:
        raise HTTPException(status_code=400, detail="raw_event_id veya normalized_event_id gerekli")
    if payload.raw_event_id:
        raw = (await db.execute(select(AnalyzerRawEvent).where(AnalyzerRawEvent.id == payload.raw_event_id, AnalyzerRawEvent.customer_id == payload.customer_id, AnalyzerRawEvent.tenant_id == payload.tenant_id))).scalar_one_or_none()
        if raw is None:
            raise HTTPException(status_code=404, detail="Raw event bulunamadi")
    if payload.normalized_event_id:
        normalized = (await db.execute(select(AnalyzerNormalizedEvent).where(AnalyzerNormalizedEvent.id == payload.normalized_event_id, AnalyzerNormalizedEvent.customer_id == payload.customer_id, AnalyzerNormalizedEvent.tenant_id == payload.tenant_id))).scalar_one_or_none()
        if normalized is None:
            raise HTTPException(status_code=404, detail="Normalized event bulunamadi")
    hold = AnalyzerLegalHold(
        tenant_id=payload.tenant_id,
        customer_id=payload.customer_id,
        raw_event_id=payload.raw_event_id,
        normalized_event_id=payload.normalized_event_id,
        action=payload.action,
        reason=payload.reason,
        actor_id=actor_id,
    )
    db.add(hold)
    await log_audit(db, "analyzer.legal_hold." + payload.action, "analyzer_legal_hold", str(hold.id), str(actor_id), request, details={"action": payload.action, "reason": payload.reason[:200]}, tenant_id=str(payload.tenant_id))
    await db.commit()
    await db.refresh(hold)
    return hold


async def list_legal_holds(db: AsyncSession, scope: ScopeContext, *, limit: int = 200) -> list[AnalyzerLegalHold]:
    await _set_rls_context(db, scope)
    predicate = scope_clause(AnalyzerLegalHold, scope)
    query = select(AnalyzerLegalHold).order_by(AnalyzerLegalHold.created_at.desc()).limit(limit)
    if predicate is not None:
        query = query.where(predicate)
    return list((await db.execute(query)).scalars().all())


def _view_out(view: Any) -> AnalyzerSavedViewOut:
    return AnalyzerSavedViewOut.model_validate(view)


async def list_views(db: AsyncSession, scope: ScopeContext, user_id: uuid.UUID) -> list[AnalyzerSavedViewOut]:
    from app.modules.analyzer.models import AnalyzerSavedView

    await _set_rls_context(db, scope)
    predicate = scope_clause(AnalyzerSavedView, scope)
    query = select(AnalyzerSavedView).where(or_(AnalyzerSavedView.created_by_user_id == user_id, AnalyzerSavedView.is_shared.is_(True))).order_by(AnalyzerSavedView.updated_at.desc())
    if predicate is not None:
        query = query.where(predicate)
    return [_view_out(view) for view in (await db.execute(query)).scalars().all()]


async def create_view(db: AsyncSession, scope: ScopeContext, user_id: uuid.UUID, body: Any, *, request: Any = None) -> AnalyzerSavedViewOut:
    from app.modules.analyzer.models import AnalyzerSavedView

    await _set_rls_context(db, scope)
    requested_customer = body.customer_id or scope.customer_id
    if scope.level == TenantLevel.GLOBAL and requested_customer is None:
        raise HTTPException(status_code=400, detail="Global scope icin customer_id gerekli")
    if not scope.allowed or not requested_customer:
        raise HTTPException(status_code=400, detail="Saved view icin müşteri scope gerekli")
    customer = await db.get(Customer, requested_customer)
    if customer is None:
        raise HTTPException(status_code=404, detail="Musteri bulunamadi")
    await assert_customer_scope(db, scope, requested_customer, body.tenant_id or customer.tenant_id)
    view = AnalyzerSavedView(tenant_id=body.tenant_id or customer.tenant_id, customer_id=requested_customer, created_by_user_id=user_id, title=body.title, description=body.description, filters=body.filters or {}, is_shared=body.is_shared)
    db.add(view)
    await db.flush()
    await log_audit(db, "analyzer.view.create", "analyzer_saved_view", str(view.id), str(user_id), request, details={"title": body.title[:120]}, tenant_id=str(view.tenant_id))
    await db.commit()
    await db.refresh(view)
    return _view_out(view)


async def update_view(
    db: AsyncSession,
    scope: ScopeContext,
    user_id: uuid.UUID,
    view_id: uuid.UUID,
    body: Any,
    *,
    request: Any = None,
) -> AnalyzerSavedViewOut:
    from app.modules.analyzer.models import AnalyzerSavedView

    await _set_rls_context(db, scope)
    view = await db.get(AnalyzerSavedView, view_id)
    if view is None:
        raise HTTPException(status_code=404, detail="Saved view bulunamadi")
    if view.created_by_user_id != user_id:
        raise HTTPException(status_code=403, detail="Saved view size ait degil")
    predicate = scope_clause(AnalyzerSavedView, scope)
    if predicate is not None and (await db.execute(select(AnalyzerSavedView.id).where(AnalyzerSavedView.id == view_id, predicate))).scalar_one_or_none() is None:
        raise HTTPException(status_code=403, detail="Saved view scope disinda")
    updates = body.model_dump(exclude_unset=True)
    for key, value in updates.items():
        # Optional update fields use null to mean "leave unchanged".  This
        # avoids violating NOT NULL constraints on title/filters/is_shared.
        if value is None and key in {"title", "filters", "is_shared"}:
            continue
        setattr(view, key, value)
    await log_audit(db, "analyzer.view.update", "analyzer_saved_view", str(view.id), str(user_id), request, details={"fields": list(updates)}, tenant_id=str(view.tenant_id))
    await db.commit()
    await db.refresh(view)
    return _view_out(view)


async def delete_view(
    db: AsyncSession,
    scope: ScopeContext,
    user_id: uuid.UUID,
    view_id: uuid.UUID,
    *,
    request: Any = None,
) -> None:
    from app.modules.analyzer.models import AnalyzerSavedView

    await _set_rls_context(db, scope)
    view = await db.get(AnalyzerSavedView, view_id)
    if view is None:
        raise HTTPException(status_code=404, detail="Saved view bulunamadi")
    if view.created_by_user_id != user_id:
        raise HTTPException(status_code=403, detail="Saved view size ait degil")
    predicate = scope_clause(AnalyzerSavedView, scope)
    if predicate is not None and (await db.execute(select(AnalyzerSavedView.id).where(AnalyzerSavedView.id == view_id, predicate))).scalar_one_or_none() is None:
        raise HTTPException(status_code=403, detail="Saved view scope disinda")
    await log_audit(
        db,
        "analyzer.view.delete",
        "analyzer_saved_view",
        str(view.id),
        str(user_id),
        request,
        details={"title": view.title[:120]},
        tenant_id=str(view.tenant_id),
    )
    await db.delete(view)
    await db.commit()


def _range_from_params(params: AnalyzerSearchParams) -> tuple[datetime | None, datetime | None]:
    return _utc(params.from_time), _utc(params.to_time)


async def _load_report_events(db: AsyncSession, scope: ScopeContext, params: AnalyzerSearchParams) -> list[AnalyzerEventOut]:
    response = await search_events(
        db,
        scope,
        params.model_copy(update={"limit": 1000, "offset": 0}),
        customer_id=getattr(params, "customer_id", None),
    )
    return response.items


def _report_snapshot(events: list[AnalyzerEventOut], *, report_type: str, from_time: datetime | None, to_time: datetime | None) -> dict[str, Any]:
    severity_counts: dict[str, int] = {}
    category_counts: dict[str, int] = {}
    source_counts: dict[str, int] = {}
    for event in events:
        severity_counts[event.severity] = severity_counts.get(event.severity, 0) + 1
        category_counts[event.category] = category_counts.get(event.category, 0) + 1
        source_counts[event.source_name] = source_counts.get(event.source_name, 0) + 1
    return {
        "report_type": report_type,
        "summary": {"event_count": len(events), "severity": severity_counts, "categories": category_counts, "sources": source_counts},
        "events": [event.model_dump(mode="json") for event in events],
        "limitations": ["Raw payloadlar varsayılan olarak rapor snapshotına dahil edilmez.", "KamuSM veya yasal uygunluk doğrulaması bu rapor tarafından iddia edilmez."] if not events else ["KamuSM veya yasal uygunluk doğrulaması bu rapor tarafından iddia edilmez."],
        "evidence_status": "verified_projection" if events else "insufficient_evidence",
        "period": {"start": from_time.isoformat() if from_time else None, "end": to_time.isoformat() if to_time else None},
    }


async def create_report(db: AsyncSession, scope: ScopeContext, payload: Any, *, actor_id: uuid.UUID, request: Any = None) -> AnalyzerReport:
    await _set_rls_context(db, scope)
    await assert_customer_scope(db, scope, payload.customer_id, payload.tenant_id)
    from_time, to_time = _range_from_params(payload)
    request_hash = _request_hash(payload)
    idem = (payload.idempotency_key or "").strip() or f"report:{request_hash}"
    predicate = scope_clause(AnalyzerReport, scope)
    query = select(AnalyzerReport).where(
        AnalyzerReport.tenant_id == payload.tenant_id,
        AnalyzerReport.customer_id == payload.customer_id,
        AnalyzerReport.idempotency_key == idem,
    )
    if predicate is not None:
        query = query.where(predicate)
    existing = (await db.execute(query)).scalar_one_or_none()
    if existing:
        _assert_idempotent_payload(existing, request_hash)
        return existing
    events = await _load_report_events(db, scope, payload)
    report_id = uuid.uuid4()
    generated_at = _now()
    snapshot = _report_snapshot(events, report_type=payload.report_type, from_time=from_time, to_time=to_time)
    provenance = {"projection": "analyzer_normalized_events", "event_count": len(events), "generated_by": str(actor_id), "request_hash": request_hash}
    body = {"report_id": str(report_id), "schema_version": "1.0", "tenant_id": str(payload.tenant_id), "customer_id": str(payload.customer_id), "generated_at": generated_at.isoformat(), "provenance": provenance, "snapshot": snapshot}
    digest = _json_hash(body)
    report = AnalyzerReport(id=report_id, tenant_id=payload.tenant_id, customer_id=payload.customer_id, period_start=from_time, period_end=to_time, report_type=payload.report_type, schema_version="1.0", generated_at=generated_at, sha256_hash=digest, provenance=provenance, snapshot={**body, "sha256_hash": digest}, idempotency_key=idem)
    try:
        async with db.begin_nested():
            db.add(report)
            await db.flush()
    except IntegrityError:
        existing = (await db.execute(query)).scalar_one_or_none()
        if existing is not None:
            _assert_idempotent_payload(existing, request_hash)
            return existing
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Idempotency-Key already used")
    await log_audit(db, "analyzer.report.create", "analyzer_report", str(report.id), str(actor_id), request, details={"sha256_hash": digest, "event_count": len(events)}, tenant_id=str(payload.tenant_id))
    await db.commit()
    await db.refresh(report)
    return report


def _evidence_envelope(export_id: uuid.UUID, tenant_id: uuid.UUID, customer_id: uuid.UUID, generated_at: datetime, files: dict[str, str], package_hash: str, provenance: dict[str, Any]) -> dict[str, Any]:
    envelope = {"evidence_id": str(export_id), "module": "hotspot", "evidence_type": "5651_network_analyzer", "schema_version": "1.0", "tenant_id": str(tenant_id), "customer_id": str(customer_id), "generated_at": generated_at.isoformat(), "package_hash": package_hash, "files": dict(sorted(files.items())), "provenance": provenance}
    envelope["sha256_hash"] = _json_hash(envelope)
    return envelope


async def create_evidence_export(db: AsyncSession, scope: ScopeContext, payload: Any, *, actor_id: uuid.UUID, request: Any = None) -> AnalyzerEvidenceExport:
    await _set_rls_context(db, scope)
    await assert_customer_scope(db, scope, payload.customer_id, payload.tenant_id)
    from_time, to_time = _range_from_params(payload)
    request_hash = _request_hash(payload)
    idem = (payload.idempotency_key or "").strip() or f"evidence:{request_hash}"
    predicate = scope_clause(AnalyzerEvidenceExport, scope)
    query = select(AnalyzerEvidenceExport).where(
        AnalyzerEvidenceExport.tenant_id == payload.tenant_id,
        AnalyzerEvidenceExport.customer_id == payload.customer_id,
        AnalyzerEvidenceExport.idempotency_key == idem,
    )
    if predicate is not None:
        query = query.where(predicate)
    existing = (await db.execute(query)).scalar_one_or_none()
    if existing:
        _assert_idempotent_payload(existing, request_hash)
        return existing
    response = await search_events(
        db,
        scope,
        payload.model_copy(update={"limit": 1000, "offset": 0}),
        customer_id=payload.customer_id,
    )
    generated = _now()
    normalized_lines = "\n".join(json.dumps(event.model_dump(mode="json"), sort_keys=True, ensure_ascii=False) for event in response.items) + ("\n" if response.items else "")
    files_payload: dict[str, bytes] = {"normalized_events.jsonl": normalized_lines.encode("utf-8")}
    if payload.include_raw:
        raw_ids = [event.raw_event_id for event in response.items]
        raw_query = select(AnalyzerRawEvent).where(
            AnalyzerRawEvent.id.in_(raw_ids),
            AnalyzerRawEvent.tenant_id == payload.tenant_id,
            AnalyzerRawEvent.customer_id == payload.customer_id,
        ) if raw_ids else None
        raw_predicate = scope_clause(AnalyzerRawEvent, scope)
        if raw_query is not None and raw_predicate is not None:
            raw_query = raw_query.where(raw_predicate)
        raw_rows = list((await db.execute(raw_query)).scalars().all()) if raw_query is not None else []
        if len(raw_rows) != len(set(raw_ids)):
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Raw evidence kullanilamiyor")
        raw_lines = "\n".join(json.dumps({**_raw_out(row), "raw_payload": row.raw_payload}, sort_keys=True, ensure_ascii=False, default=str) for row in raw_rows) + ("\n" if raw_rows else "")
        files_payload["raw_events.jsonl"] = raw_lines.encode("utf-8")
    file_hashes = {name: hashlib.sha256(data).hexdigest() for name, data in files_payload.items()}
    provenance = {"projection": "analyzer_normalized_events", "raw_included": bool(payload.include_raw), "event_count": len(response.items), "matched_total": response.total, "truncated": response.total > len(response.items), "request_hash": request_hash, "limitations": ["Paket bütünlüğü doğrulanır; yasal uygunluk iddiası içermez."]}
    export_id = uuid.uuid4()
    manifest = {"package_type": "5651_network_analyzer", "schema_version": "1.0", "tenant_id": str(payload.tenant_id), "customer_id": str(payload.customer_id), "generated_at": generated.isoformat(), "period": {"start": from_time.isoformat() if from_time else None, "end": to_time.isoformat() if to_time else None}, "sha256_hashes": file_hashes, "provenance": provenance}
    manifest["sha256_hash"] = _json_hash(manifest)
    files_payload["evidence_manifest.json"] = json.dumps(manifest, sort_keys=True, ensure_ascii=False, indent=2).encode("utf-8")
    package = io.BytesIO()
    with zipfile.ZipFile(package, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(files_payload):
            archive.writestr(name, files_payload[name])
    package_bytes = package.getvalue()
    package_hash = hashlib.sha256(package_bytes).hexdigest()
    envelope = _evidence_envelope(export_id, payload.tenant_id, payload.customer_id, generated, {name: hashlib.sha256(data).hexdigest() for name, data in files_payload.items()}, package_hash, provenance)
    base = Path(settings.EVIDENCE_STORAGE_PATH).resolve()
    base.mkdir(parents=True, exist_ok=True)
    path = base / f"analyzer_{export_id}_{package_hash[:16]}.zip"
    temporary_path = base / f".{path.name}.{uuid.uuid4().hex}.tmp"
    created_file = False
    if path.exists():
        if file_sha256(path) != package_hash:
            raise HTTPException(status_code=500, detail="Evidence immutable storage hash mismatch")
    else:
        try:
            # Write and atomically publish the immutable object.  A temporary
            # name prevents readers from observing a partial ZIP on a crash.
            temporary_path.write_bytes(package_bytes)
            os.replace(temporary_path, path)
            created_file = True
        finally:
            temporary_path.unlink(missing_ok=True)
    export = AnalyzerEvidenceExport(id=export_id, tenant_id=payload.tenant_id, customer_id=payload.customer_id, period_start=from_time, period_end=to_time, package_ref=f"local:{path}", content_hash=package_hash, file_size=len(package_bytes), status="ready", schema_version="1.0", provenance=provenance, envelope=envelope, idempotency_key=idem)
    try:
        async with db.begin_nested():
            db.add(export)
            await db.flush()
    except IntegrityError:
        existing = (await db.execute(query)).scalar_one_or_none()
        if existing is not None:
            _assert_idempotent_payload(existing, request_hash)
            if created_file:
                path.unlink(missing_ok=True)
            return existing
        if created_file:
            path.unlink(missing_ok=True)
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Idempotency-Key already used")
    try:
        await log_audit(db, "analyzer.evidence.export", "analyzer_evidence_export", str(export.id), str(actor_id), request, details={"content_hash": package_hash, "event_count": len(response.items), "raw_included": bool(payload.include_raw)}, tenant_id=str(payload.tenant_id))
        await db.commit()
    except Exception:
        if created_file:
            path.unlink(missing_ok=True)
        raise
    await db.refresh(export)
    return export


async def verify_archive_chain(db: AsyncSession, scope: ScopeContext, customer_id: uuid.UUID, record_type: str = "session_archive") -> Any:
    await _set_rls_context(db, scope)
    await assert_customer_scope(db, scope, customer_id)
    from app.modules.logs_5651.service import verify_chain

    return await verify_chain(db, customer_id=customer_id, record_type=record_type)


def report_csv(report: AnalyzerReport) -> str:
    snapshot = report.snapshot or {}
    rows = snapshot.get("snapshot", {}).get("events", []) if isinstance(snapshot.get("snapshot"), dict) else []
    fields = ["id", "occurred_at", "source_name", "category", "severity", "action", "source_ip", "destination_ip", "source_mac", "identity", "session_id", "raw_sha256", "normalized_sha256"]
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        writer.writerow({field: row.get(field, "") for field in fields})
    return buf.getvalue()
