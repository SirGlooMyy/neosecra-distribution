import httpx
import base64
import json
from app.core.config import settings
from .base import SmsProvider

NETGSM_HTTP_GET_URL = "https://api.netgsm.com.tr/sms/send/get"
NETGSM_HTTP_POST_URL = "https://api.netgsm.com.tr/sms/send/post"
NETGSM_REST_URL = "https://api.netgsm.com.tr/sms/rest/v2/send"

NETGSM_ERROR_CODES = {
    "20": "Mesaj metni hatası veya karakter sınırı aşıldı",
    "30": "Geçersiz kullanıcı kodu, şifre veya yetkisiz IP adresi",
    "40": "Mesaj başlığı (gönderici adı) NetGSM sisteminde onaylı değil",
    "50": "Abone hesabı aktif değil veya bakiye/kredi yetersiz",
    "51": "Abonelik süresi dolmuş",
    "60": "Arama servisi aktif değil",
    "70": "Hatalı parametre veya geçersiz telefon numarası formatı",
    "80": "Gönderim sınır aşımı",
    "85": "Mükerrer gönderim engellendi",
    "100": "NetGSM sistem hatası",
    "101": "NetGSM sistem hatası",
}


class NetGSMProvider(SmsProvider):
    async def send(self, phone: str, message: str) -> tuple[bool, str | None]:
        usercode = self.value("username", settings.NETGSM_USERCODE or settings.NETGSM_USER)
        password = self.value("password", settings.NETGSM_PASSWORD or settings.NETGSM_PASS)
        msgheader = self.value("sender", settings.NETGSM_MSGHEADER or settings.SMS_SENDER)
        options = self.config.get("provider_options") or {}

        if not usercode or not password:
            return False, "NetGSM kullanıcı kodu veya şifresi eksik."

        # NetGSM phone formatting: 905xxxxxxxxx or 5xxxxxxxxx
        clean_phone = phone.lstrip("+").strip()
        if clean_phone.startswith("0"):
            clean_phone = clean_phone[1:]
        if not clean_phone.startswith("90") and len(clean_phone) == 10:
            clean_phone = f"90{clean_phone}"

        api_type = str(options.get("api_type") or "http_get").lower()

        # Mode 1: NetGSM REST v2 (JSON / Basic Auth)
        if api_type == "rest":
            payload = {
                "msgheader": msgheader,
                "messages": [{"msg": message, "no": clean_phone}],
                "encoding": str(options.get("encoding") or "TR").upper(),
                "iysfilter": str(options.get("iysfilter") or "0"),
            }
            if options.get("appname"):
                payload["appname"] = str(options["appname"])
            url = str(options.get("endpoint") or NETGSM_REST_URL)
            token = base64.b64encode(f"{usercode}:{password}".encode()).decode()
            headers = {"Authorization": f"Basic {token}", "Content-Type": "application/json"}
            try:
                async with httpx.AsyncClient(timeout=12.0) as client:
                    resp = await client.post(url, json=payload, headers=headers)
                if 200 <= resp.status_code < 300:
                    try:
                        data = resp.json()
                    except (ValueError, json.JSONDecodeError):
                        data = {}
                    code = str(data.get("code") or "").strip()
                    if code in ("00", "01", "02"):
                        return True, str(data.get("jobid") or data.get("jobId") or "") or None
                    desc = str(data.get("description") or data.get("message") or NETGSM_ERROR_CODES.get(code, "Bilinmeyen hata"))
                    return False, f"NetGSM Hatası ({code}): {desc}"
                return False, f"NetGSM HTTP Hatası: {resp.status_code}"
            except httpx.TimeoutException:
                return False, "NetGSM sunucusuna ulaşılamadı (Zaman aşımı / Timeout)"
            except Exception as exc:
                return False, f"NetGSM bağlantı hatası: {type(exc).__name__}"

        # Mode 2 (Default / Recommended): Official NetGSM HTTP GET/POST API
        params = {
            "usercode": usercode,
            "password": password,
            "gsmno": clean_phone,
            "message": message,
            "msgheader": msgheader,
            "dil": str(options.get("encoding") or "TR").upper(),
        }
        if options.get("startdate"):
            params["startdate"] = str(options["startdate"])
        if options.get("stopdate"):
            params["stopdate"] = str(options["stopdate"])

        url = str(options.get("endpoint") or NETGSM_HTTP_GET_URL)
        try:
            async with httpx.AsyncClient(timeout=12.0) as client:
                if api_type == "http_post":
                    resp = await client.post(str(options.get("endpoint") or NETGSM_HTTP_POST_URL), data=params)
                else:
                    resp = await client.get(url, params=params)

            resp_text = resp.text.strip()
            # NetGSM responses: "00 123456789" (Success) or "20", "30", "40", "70", etc.
            if resp_text.startswith("00") or resp_text.startswith("01") or resp_text.startswith("02"):
                parts = resp_text.split()
                job_id = parts[1] if len(parts) > 1 else resp_text
                return True, job_id

            code = resp_text.split()[0] if resp_text else "unknown"
            err_msg = NETGSM_ERROR_CODES.get(code, f"Hata Kodu: {resp_text}")
            return False, f"NetGSM ({code}): {err_msg}"

        except httpx.TimeoutException:
            return False, "NetGSM sunucusuna ulaşılamadı (Zaman aşımı / Timeout)"
        except Exception as exc:
            return False, f"NetGSM bağlantı hatası: {type(exc).__name__}"
