"""Apple/Android/Windows captive portal detection endpoints.

The probe is considered online only when its bearer token maps to a consumed
identity and an active, firewall-authorized guest session, or when the probe's
client identity matches such a session. Merely providing an arbitrary
cookie/header is never sufficient.
"""
from __future__ import annotations

import re
import uuid
from datetime import datetime, timezone
from urllib.parse import urlencode, urlsplit, urlunsplit

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse, Response
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.modules.identity.models import IdentityVerification
from app.modules.sessions.models import GuestSession, STATUS_ACTIVE

router = APIRouter(tags=["captive-portal"])

SUCCESS_HTML = """<HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML>"""
NCSI_TEXT = "Microsoft NCSI"
_UUID_RE = re.compile(
    r"(?i)([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})"
)


def _parse_uuid(value: str | None) -> uuid.UUID | None:
    match = _UUID_RE.search(str(value or ""))
    if not match:
        return None
    try:
        return uuid.UUID(match.group(1))
    except ValueError:
        return None


def _query_value(request: Request, *names: str) -> str | None:
    for name in names:
        value = request.query_params.get(name)
        if value:
            return value
    return None


def _client_mac(request: Request) -> str | None:
    raw = _query_value(request, "mac", "client_mac", "client-mac", "usermac", "cmac")
    if not raw:
        return None
    compact = re.sub(r"[^0-9a-fA-F]", "", raw)
    if len(compact) == 12:
        return ":".join(compact[index:index + 2] for index in range(0, 12, 2)).upper()
    return raw.strip().upper()


def _client_ip(request: Request) -> str | None:
    return _query_value(request, "ip", "client_ip", "client-ip", "userip", "uip")


async def _has_authorized_session(request: Request, db: AsyncSession) -> bool:
    """Return true only for a live session bound to this probe."""
    now = datetime.now(timezone.utc)
    token = request.cookies.get("portal_token") or request.headers.get("X-Portal-Token")
    device_id = _parse_uuid(_query_value(request, "device_id", "device", "nas_device_id"))
    try:
        if token:
            iv = (
                await db.execute(
                    select(IdentityVerification).where(IdentityVerification.portal_token == token)
                )
            ).scalar_one_or_none()
            # A pre-session identity token is not an authorization. It must
            # have been consumed by start-session and still be in its TTL.
            if iv and iv.consumed_at and iv.portal_token_expires_at > now:
                query = select(GuestSession).where(
                    GuestSession.identity_verification_id == iv.id,
                    GuestSession.customer_id == iv.customer_id,
                    GuestSession.status == STATUS_ACTIVE,
                    GuestSession.authorize_ok.is_(True),
                    GuestSession.ended_at.is_(None),
                    or_(GuestSession.expires_at.is_(None), GuestSession.expires_at > now),
                )
                # Identity tokens are device-bound.  If a probe supplied a
                # device id it must match both the token and session; when it
                # did not, retain the token's own binding instead of accepting
                # a session from another gateway.
                if iv.device_id is not None:
                    query = query.where(GuestSession.device_id == iv.device_id)
                    if device_id is not None and device_id != iv.device_id:
                        return False
                elif device_id is not None:
                    query = query.where(GuestSession.device_id == device_id)
                if iv.location_id is not None:
                    query = query.where(GuestSession.location_id == iv.location_id)
                if (await db.execute(query)).scalar_one_or_none():
                    return True

        # Browsers normally do not retain the one-shot identity token. Match
        # the redirect's client identity against a current authorized session.
        mac = _client_mac(request)
        ip = _client_ip(request)
        if not device_id or (not mac and not ip):
            return False
        conditions = []
        if mac:
            conditions.append(GuestSession.mac == mac)
        if ip:
            conditions.append(GuestSession.ip == ip)
        query = select(GuestSession).where(
            GuestSession.status == STATUS_ACTIVE,
            GuestSession.authorize_ok.is_(True),
            GuestSession.ended_at.is_(None),
            or_(GuestSession.expires_at.is_(None), GuestSession.expires_at > now),
            or_(*conditions),
        )
        if device_id is not None:
            query = query.where(GuestSession.device_id == device_id)
        return (await db.execute(query)).scalar_one_or_none() is not None
    except Exception:
        # Detection must fail closed if the database is unavailable.
        return False


def _portal_redirect_url(request: Request) -> str:
    """Build a safe browser-facing portal URL retaining probe parameters."""
    params = list(request.query_params.multi_items())
    configured = str(getattr(settings, "PORTAL_APP_BASE_URL", "") or "").strip()
    if configured:
        try:
            parsed = urlsplit(configured)
            if (
                parsed.scheme in {"http", "https"}
                and parsed.netloc
                and not parsed.username
                and not parsed.password
                and not parsed.query
                and not parsed.fragment
            ):
                path = parsed.path.rstrip("/") or ""
                return urlunsplit((parsed.scheme, parsed.netloc, f"{path}/", urlencode(params, doseq=True), ""))
        except ValueError:
            pass
    # Same-origin is the normal reverse-proxy deployment. A relative URL
    # cannot be turned into an open redirect by a hostile Host header.
    query = urlencode(params, doseq=True)
    return f"/" + (f"?{query}" if query else "")


@router.get(
    "/hotspot-detect.html",
    response_class=HTMLResponse,
    summary="Apple captive portal detection endpoint",
)
async def hotspot_detect(request: Request, db: AsyncSession = Depends(get_db)):
    if not await _has_authorized_session(request, db):
        return RedirectResponse(url=_portal_redirect_url(request))
    return HTMLResponse(content=SUCCESS_HTML)


@router.get(
    "/generate_204",
    status_code=204,
    summary="Android captive portal detection endpoint",
)
async def generate_204(request: Request, db: AsyncSession = Depends(get_db)):
    if not await _has_authorized_session(request, db):
        return RedirectResponse(url=_portal_redirect_url(request))
    return Response(status_code=204)


@router.get(
    "/ncsi.txt",
    response_class=PlainTextResponse,
    summary="Windows NCSI captive portal detection endpoint",
)
async def ncsi_txt(request: Request, db: AsyncSession = Depends(get_db)):
    if not await _has_authorized_session(request, db):
        return RedirectResponse(url=_portal_redirect_url(request))
    return PlainTextResponse(content=NCSI_TEXT)
