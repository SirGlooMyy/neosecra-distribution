import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class BanRuleCreate(BaseModel):
    # Single-installation admin clients may omit this and let the API resolve
    # the active customer from the authenticated scope.
    customer_id: uuid.UUID | None = None
    location_id: uuid.UUID | None = None
    mac_address: str | None = Field(None, max_length=32)
    phone: str | None = Field(None, max_length=20)
    ip_address: str | None = Field(None, max_length=64)
    reason: str | None = None
    expires_at: datetime | None = None


class BanRuleUpdate(BaseModel):
    location_id: uuid.UUID | None = None
    reason: str | None = None
    expires_at: datetime | None = None


class BanRuleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    mac_address: str | None = None
    phone: str | None = None
    ip_address: str | None = None
    reason: str | None = None
    is_active: bool
    expires_at: datetime | None = None
    created_at: datetime


class WhitelistEntryCreate(BaseModel):
    # Keep compatibility with scope-aware clients that do not carry a
    # customer selector in the form payload.
    customer_id: uuid.UUID | None = None
    location_id: uuid.UUID | None = None
    mac_address: str | None = Field(None, max_length=32)
    phone: str | None = Field(None, max_length=20)
    description: str | None = None


class WhitelistEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    mac_address: str | None = None
    phone: str | None = None
    description: str | None = None
    is_active: bool
    created_at: datetime
