"""SMTP / Email configuration service.

SMTP passwords are encrypted at rest via app.core.crypto (Mutlak Kural #3).
Email sending uses aiosmtplib (async) with smtplib fallback; prints in dev.
"""
from __future__ import annotations

import logging
import uuid

from sqlalchemy import Boolean, Integer, String, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from app.core.config import demo_mode_enabled, settings
from app.core.crypto import decrypt, encrypt
from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk

log = logging.getLogger(__name__)


class EmailConfig(Base, UUIDPK, TimestampMixin):
    __tablename__ = "email_configs"

    customer_id: Mapped[uuid.UUID | None] = fk("customers", ondelete="CASCADE", nullable=True)
    smtp_host: Mapped[str] = mapped_column(String(255), nullable=False)
    smtp_port: Mapped[int] = mapped_column(Integer, default=587, nullable=False)
    smtp_username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    smtp_password_encrypted: Mapped[str | None] = mapped_column(String(500), nullable=True)
    smtp_use_tls: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    smtp_use_ssl: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    from_address: Mapped[str] = mapped_column(String(255), nullable=False)
    from_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


async def get_config(db: AsyncSession, customer_id: uuid.UUID | None = None) -> EmailConfig | None:
    if customer_id:
        res = await db.execute(
            select(EmailConfig).where(EmailConfig.customer_id == customer_id)
        )
        cfg = res.scalar_one_or_none()
        if cfg:
            return cfg
    res = await db.execute(
        select(EmailConfig).order_by(EmailConfig.created_at.desc())
    )
    return res.scalars().first()


async def upsert_config(
    db: AsyncSession,
    customer_id: uuid.UUID | None,
    data: dict,
) -> EmailConfig:
    res = await db.execute(
        select(EmailConfig).where(EmailConfig.customer_id == customer_id)
    )
    cfg = res.scalar_one_or_none()

    if not cfg:
        cfg = EmailConfig(customer_id=customer_id)

    for key in ("smtp_host", "smtp_port", "smtp_username", "smtp_use_tls",
                 "smtp_use_ssl", "from_address", "from_name", "is_verified"):
        if key in data:
            setattr(cfg, key, data[key])

    if "smtp_password" in data and data["smtp_password"]:
        cfg.smtp_password_encrypted = _encrypt_smtp_password(data["smtp_password"])

    db.add(cfg)
    await db.commit()
    await db.refresh(cfg)
    return cfg


async def test_connection(db: AsyncSession, config_id: uuid.UUID) -> dict:
    cfg = await db.get(EmailConfig, config_id)
    if not cfg:
        raise ValueError("E-posta yapilandirmasi bulunamadi")

    password = _decrypt_smtp_password(cfg.smtp_password_encrypted) if cfg.smtp_password_encrypted else ""

    try:
        import smtplib
        import ssl

        context = ssl.create_default_context()
        if cfg.smtp_use_ssl:
            client = smtplib.SMTP_SSL(cfg.smtp_host, cfg.smtp_port, context=context, timeout=10)
        else:
            client = smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=10)

        client.ehlo()
        if cfg.smtp_use_tls:
            client.starttls(context=context)
            client.ehlo()

        if cfg.smtp_username and password:
            client.login(cfg.smtp_username, password)
        client.quit()

        cfg.is_verified = True
        await db.commit()

        return {
            "success": True,
            "message": "SMTP baglantisi basarili",
            "host": cfg.smtp_host,
            "port": cfg.smtp_port,
        }
    except Exception as exc:
        raise ValueError(f"SMTP baglantisi basarisiz: {exc}")


def _encrypt_smtp_password(password: str) -> str:
    return encrypt(password)


def _decrypt_smtp_password(encrypted: str | None) -> str:
    if not encrypted:
        return ""
    return decrypt(encrypted)


async def send_email(
    to: str,
    subject: str,
    html_body: str,
    from_addr: str | None = None,
    customer_id: uuid.UUID | None = None,
    db: AsyncSession | None = None,
    inline_images: dict[str, bytes] | None = None,
    text_body: str | None = None,
) -> bool:
    # ``To``, ``Subject`` and ``From`` become MIME headers below.  Reject
    # control characters before the standard library constructs them so a
    # malformed tenant configuration cannot inject additional headers.
    header_values = (to, subject, from_addr or "")
    if any(
        not isinstance(value, str)
        or any(ord(char) < 0x20 or ord(char) == 0x7F for char in value)
        for value in header_values
    ):
        log.error("E-posta başlıkları geçersiz")
        return False
    if not db:
        if demo_mode_enabled():
            # Never log message bodies: approval links and other bearer
            # credentials may be embedded in HTML attributes.
            log.info("[DEV EMAIL] dispatch requested")
            return True
        log.error("E-posta verisi yok ve demo modu kapali")
        return False

    cfg = await get_config(db, customer_id)
    if not cfg:
        if demo_mode_enabled():
            log.info("[DEV EMAIL - no config] dispatch requested")
            return True
        log.error("E-posta yapilandirmasi bulunamadi ve demo modu kapali")
        return False

    password = _decrypt_smtp_password(cfg.smtp_password_encrypted) if cfg.smtp_password_encrypted else ""
    sender = from_addr or cfg.from_address
    name = cfg.from_name or ""
    if any(
        not isinstance(value, str)
        or any(ord(char) < 0x20 or ord(char) == 0x7F for char in value)
        for value in (sender, name)
    ):
        log.error("E-posta gönderen bilgisi geçersiz")
        return False

    try:
        import smtplib
        import ssl
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        from email.mime.image import MIMEImage
        from email.utils import formatdate, make_msgid
        import re

        clean_text = text_body
        if clean_text is None:
            clean_text = re.sub(r"<[^>]+>", " ", html_body)
            clean_text = re.sub(r"\s+", " ", clean_text).strip()

        if inline_images:
            msg = MIMEMultipart("related")
            msg["Subject"] = subject
            msg["From"] = f"{name} <{sender}>" if name else sender
            msg["To"] = to
            msg["Date"] = formatdate(localtime=True)
            msg["Message-ID"] = make_msgid(domain=sender.split("@")[-1] if "@" in sender else "neosecra.com")

            alt_part = MIMEMultipart("alternative")
            alt_part.attach(MIMEText(clean_text, "plain", "utf-8"))
            alt_part.attach(MIMEText(html_body, "html", "utf-8"))
            msg.attach(alt_part)

            for cid, img_data in inline_images.items():
                img_part = MIMEImage(img_data, _subtype="png")
                img_part.add_header("Content-ID", f"<{cid}>")
                img_part.add_header("Content-Disposition", "inline", filename=f"{cid}.png")
                msg.attach(img_part)
        else:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = f"{name} <{sender}>" if name else sender
            msg["To"] = to
            msg["Date"] = formatdate(localtime=True)
            msg["Message-ID"] = make_msgid(domain=sender.split("@")[-1] if "@" in sender else "neosecra.com")
            msg.attach(MIMEText(clean_text, "plain", "utf-8"))
            msg.attach(MIMEText(html_body, "html", "utf-8"))

        context = ssl.create_default_context()
        if cfg.smtp_use_ssl:
            client = smtplib.SMTP_SSL(cfg.smtp_host, cfg.smtp_port, context=context, timeout=10)
        else:
            client = smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=10)

        client.ehlo()
        if cfg.smtp_use_tls:
            client.starttls(context=context)
            client.ehlo()

        if cfg.smtp_username and password:
            client.login(cfg.smtp_username, password)
        client.send_message(msg)
        client.quit()
        log.info("E-posta gonderildi")
        return True

    except Exception as exc:
        # SMTP exceptions can contain provider-specific envelope data.  Keep
        # the log bounded and free of message bodies/recipient PII.
        log.error("E-posta gonderilemedi: %s", type(exc).__name__)
        return False


async def send_template_email(
    to: str,
    template_name: str,
    template_data: dict,
    customer_id: uuid.UUID | None = None,
    db: AsyncSession | None = None,
) -> bool:
    try:
        from jinja2 import Environment, FileSystemLoader
        import os
        templates_dir = os.path.join(os.path.dirname(__file__), "templates")
        if not os.path.isdir(templates_dir):
            log.warning("E-posta template dizini bulunamadi: %s", templates_dir)
            html_body = f"<html><body><h1>{template_name}</h1><pre>{template_data}</pre></body></html>"
        else:
            env = Environment(loader=FileSystemLoader(templates_dir))
            tmpl = env.get_template(f"{template_name}.html")
            html_body = tmpl.render(**template_data)
    except ImportError:
        html_body = f"<html><body><h1>{template_name}</h1><pre>{template_data}</pre></body></html>"

    subject = template_data.get("subject", template_name.replace("_", " ").title())
    return await send_email(to, subject, html_body, customer_id=customer_id, db=db)
