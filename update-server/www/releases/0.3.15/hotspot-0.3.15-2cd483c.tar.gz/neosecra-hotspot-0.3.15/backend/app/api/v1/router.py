from fastapi import APIRouter

from app.modules.auth.router import router as auth_router
from app.modules.locations.router import router as locations_router
from app.modules.devices.router import router as devices_router
from app.api.v1.endpoints.portal import router as portal_router
from app.modules.portal.router import router as portal_templates_router
from app.modules.sessions.router import router as guest_sessions_router
from app.modules.vouchers.router import router as vouchers_router
from app.api.v1.endpoints.radius import router as radius_events_router
from app.api.v1.endpoints.syslog import router as syslog_router
from app.modules.logs_5651.router import router as logs_5651_router
from app.modules.syslog.router import router as syslog_triggers_router
from app.modules.reports.router import router as reports_router
from app.modules.system.router import router as system_router
from app.modules.user_groups.router import router as user_groups_router
from app.modules.ban.router import router as ban_router
from app.modules.traffic.router import router as traffic_router
from app.modules.search.router import router as search_router
from app.modules.meeting.router import router as meeting_router
from app.modules.auth_methods.router import router as auth_methods_router
from app.modules.alarm.router import router as alarm_router
from app.modules.archive.router import router as archive_router
from app.modules.pms.api_router import router as pms_router
from app.modules.mfa.router import router as mfa_router
from app.modules.licensing.router import router as licensing_router
from app.modules.public_content.router import router as public_content_router
from app.modules.ipsec.router import router as ipsec_router
from app.api.v1.endpoints.platform_upgrade import router as legacy_platform_upgrade_router
from app.api.v1.endpoints.platform_licensing import router as canonical_platform_licensing_router
from app.modules.analyzer.router import router as analyzer_router

api_router = APIRouter()

api_router.include_router(auth_router, prefix="/auth", tags=["auth"])
api_router.include_router(locations_router, prefix="/locations", tags=["locations"])
api_router.include_router(devices_router, prefix="/devices", tags=["devices"])
api_router.include_router(portal_router, prefix="/portal", tags=["portal"])
api_router.include_router(portal_templates_router, prefix="/portal", tags=["portal-templates"])
api_router.include_router(guest_sessions_router, prefix="/sessions", tags=["sessions"])
api_router.include_router(vouchers_router, prefix="/vouchers", tags=["vouchers"])
api_router.include_router(radius_events_router, prefix="/radius", tags=["radius"])
api_router.include_router(syslog_router, prefix="/syslog", tags=["syslog"])
api_router.include_router(logs_5651_router, prefix="/logs-5651", tags=["logs-5651"])
api_router.include_router(syslog_triggers_router, prefix="/syslog", tags=["syslog-triggers"])
api_router.include_router(reports_router, prefix="/reports", tags=["reports"])
api_router.include_router(system_router, prefix="/system", tags=["system"])
api_router.include_router(user_groups_router, prefix="/user-groups", tags=["user-groups"])
api_router.include_router(ban_router, prefix="/ban", tags=["ban"])
api_router.include_router(traffic_router, prefix="/traffic", tags=["traffic"])
api_router.include_router(ipsec_router, prefix="/ipsec", tags=["ipsec"])
api_router.include_router(search_router, prefix="", tags=["search"])
api_router.include_router(meeting_router, prefix="/auth-methods/meeting-codes", tags=["auth-methods"])
api_router.include_router(auth_methods_router, prefix="/auth-methods", tags=["auth-methods"])
api_router.include_router(alarm_router, prefix="/alarm", tags=["alarm"])
api_router.include_router(archive_router, prefix="/archive", tags=["archive"])
api_router.include_router(pms_router, prefix="/pms", tags=["pms"])
api_router.include_router(mfa_router, prefix="/mfa", tags=["mfa"])
api_router.include_router(licensing_router, prefix="/licenses", tags=["licensing"])
api_router.include_router(public_content_router, prefix="/public-content", tags=["public-content"])
api_router.include_router(legacy_platform_upgrade_router)
api_router.include_router(canonical_platform_licensing_router)
api_router.include_router(analyzer_router, prefix="/analyzer", tags=["analyzer"])
