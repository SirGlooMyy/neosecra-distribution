"""Canonical Hotspot license/update contract.

The wire envelope remains schema version 1.  Canonical payload validation is
kept here so the product consumer and the licensing API share the same rules
without importing code from the license authority repository.
"""
from datetime import datetime, timezone, timedelta
from typing import Any, Mapping

PRODUCT_CODE = "hotspot"
CHANNEL = "hotspot-stable"
EDITIONS = frozenset({"standard", "enterprise"})
CANONICAL_PAYLOAD_SCHEMA_VERSION = 1
PRODUCT_CODES = ("assessment", "soc", "hotspot", "pish")
ENTITLEMENTS_BY_PRODUCT: dict[str, tuple[str, ...]] = {
    "assessment": (
        "assessment.core", "assessment.attack_surface", "assessment.active_directory",
        "assessment.microsoft_365", "assessment.fortigate", "assessment.web_security",
        "assessment.vulnerability", "assessment.compliance", "assessment.reporting",
    ),
    "soc": (
        "soc.core", "soc.log_management", "soc.wazuh_xdr", "soc.network_detection",
        "soc.case_management", "soc.collaboration", "soc.soar", "soc.threat_intelligence",
        "soc.reporting", "soc.ai_analyst_l1", "soc.ai_analyst_l2", "soc.ai_analyst_l3",
        "soc.managed_service",
    ),
    "hotspot": ("hotspot.core",),
    "pish": ("phishing.core",),
}
ENTITLEMENT_CATALOG = ENTITLEMENTS_BY_PRODUCT
PRODUCT_ENTITLEMENTS = ENTITLEMENTS_BY_PRODUCT
ALLOWED_DURATION_MONTHS = frozenset({12, 24, 36})
CUSTOM_DURATION_MIN_MONTHS = 1
CUSTOM_DURATION_MAX_MONTHS = 120
HOTSPOT_SESSION_PRESETS = frozenset({5, 10, 50})
HOTSPOT_SESSION_MIN = 1
HOTSPOT_SESSION_MAX = 100_000
PHISH_FORBIDDEN_LIMITS = frozenset({"max_campaigns", "max_recipients", "campaign_quota", "recipient_quota"})
LICENSE_STATUSES = ("NOT_INSTALLED", "ACTIVE", "EXPIRING_SOON", "GRACE_PERIOD", "EXPIRED", "REVOKED", "INVALID_PRODUCT", "INVALID_SIGNATURE", "INSTALLATION_MISMATCH", "NOT_YET_VALID", "LEGACY_WARNING", "CANONICAL_INVALID", "TENANT_MISMATCH")
_NON_TIME_STATUSES = frozenset({"REVOKED", "INVALID_PRODUCT", "INVALID_SIGNATURE", "INSTALLATION_MISMATCH", "LEGACY_WARNING", "CANONICAL_INVALID"})


class CanonicalLicenseError(ValueError):
    """A stable fail-closed validation error exposed to tests and logs."""

    def __init__(self, code: str, detail: str):
        self.code = code
        self.detail = detail
        super().__init__(f"{code}: {detail}")


def _parse_datetime(value: object) -> datetime:
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("timezone required")
    return parsed.astimezone(timezone.utc)


def is_canonical_payload(payload: Mapping[str, Any]) -> bool:
    return any(key in payload for key in ("payload_schema_version", "entitlements", "duration_months"))


def validate_duration_months(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise CanonicalLicenseError("INVALID_DURATION", "duration_months must be an integer")
    if not CUSTOM_DURATION_MIN_MONTHS <= value <= CUSTOM_DURATION_MAX_MONTHS:
        raise CanonicalLicenseError("INVALID_DURATION", "duration_months is outside the controlled range")
    return value


def validate_entitlements(product_code: Any, entitlements: Any) -> list[str]:
    if product_code not in ENTITLEMENTS_BY_PRODUCT:
        raise CanonicalLicenseError("INVALID_PRODUCT", "unsupported product_code")
    if not isinstance(entitlements, list) or not entitlements or any(not isinstance(item, str) for item in entitlements):
        raise CanonicalLicenseError("INVALID_ENTITLEMENTS", "entitlements must be a non-empty string array")
    normalized = sorted(set(entitlements))
    unknown = sorted(set(normalized) - set(ENTITLEMENTS_BY_PRODUCT[product_code]))
    if unknown:
        raise CanonicalLicenseError("INVALID_ENTITLEMENTS", f"unknown entitlements: {unknown}")
    return normalized


def validate_limits(product_code: str, limits: Any) -> dict[str, int]:
    if not isinstance(limits, dict):
        raise CanonicalLicenseError("INVALID_LIMITS", "limits must be an object")
    normalized: dict[str, int] = {}
    for name, value in limits.items():
        if not isinstance(name, str) or isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise CanonicalLicenseError("INVALID_LIMITS", f"limit {name!r} must be a non-negative integer")
        normalized[name] = value
    if product_code == "hotspot":
        if set(normalized) != {"max_concurrent_sessions"}:
            raise CanonicalLicenseError("MISSING_LIMIT" if "max_concurrent_sessions" not in normalized else "INVALID_LIMITS", "Hotspot only supports max_concurrent_sessions")
        value = normalized["max_concurrent_sessions"]
        if not HOTSPOT_SESSION_MIN <= value <= HOTSPOT_SESSION_MAX:
            raise CanonicalLicenseError("INVALID_LIMIT", "max_concurrent_sessions is outside the controlled range")
    if product_code == "pish" and PHISH_FORBIDDEN_LIMITS.intersection(normalized):
        raise CanonicalLicenseError("PHISH_QUOTA_FORBIDDEN", "Phish has no campaign or recipient hard quota")
    return normalized


def validate_canonical_payload(
    payload: Mapping[str, Any], *, now: datetime | None = None,
    expected_product: str | None = None, expected_tenant: str | None = None,
    expected_installation: str | None = None,
) -> dict[str, Any]:
    """Validate and normalize a canonical payload; raises on every violation."""
    if not isinstance(payload, Mapping):
        raise CanonicalLicenseError("INVALID_PAYLOAD", "payload must be an object")
    required = ("payload_schema_version", "license_id", "issuer", "product_code", "tenant_id", "valid_from", "expires_at", "duration_months", "entitlements", "limits")
    missing = [key for key in required if key not in payload]
    if missing:
        raise CanonicalLicenseError("MISSING_FIELD", f"missing fields: {missing}")
    if payload["payload_schema_version"] != CANONICAL_PAYLOAD_SCHEMA_VERSION:
        raise CanonicalLicenseError("SCHEMA_UNSUPPORTED", "unsupported payload schema version")
    if payload["issuer"] not in ("NeoSecra", "VData"):
        raise CanonicalLicenseError("INVALID_ISSUER", "issuer must be NeoSecra or VData")
    product = str(payload["product_code"]).strip().lower()
    if product not in PRODUCT_CODES:
        raise CanonicalLicenseError("INVALID_PRODUCT", "unsupported product_code")
    if expected_product and product != expected_product:
        raise CanonicalLicenseError("PRODUCT_MISMATCH", f"expected {expected_product}, got {product}")
    tenant = payload["tenant_id"]
    if not isinstance(tenant, str) or not tenant.strip():
        raise CanonicalLicenseError("TENANT_REQUIRED", "tenant_id must be non-empty")
    if expected_tenant is not None and tenant != expected_tenant:
        raise CanonicalLicenseError("TENANT_MISMATCH", "license tenant does not match customer tenant")
    installation = payload.get("installation_id")
    if expected_installation is not None and installation != expected_installation:
        raise CanonicalLicenseError("INSTALLATION_MISMATCH", "license installation does not match")
    valid_from = _parse_datetime(payload["valid_from"])
    expires_at = _parse_datetime(payload["expires_at"])
    if expires_at <= valid_from:
        raise CanonicalLicenseError("INVALID_VALIDITY", "expires_at must be after valid_from")
    duration = validate_duration_months(payload["duration_months"])
    entitlements = validate_entitlements(product, payload["entitlements"])
    limits = validate_limits(product, payload["limits"])
    grace_days = payload.get("grace_period_days", 0)
    if isinstance(grace_days, bool) or not isinstance(grace_days, int) or not 0 <= grace_days <= 365:
        raise CanonicalLicenseError("INVALID_GRACE_PERIOD", "grace_period_days must be between 0 and 365")
    normalized = dict(payload)
    normalized.update({
        "payload_schema_version": CANONICAL_PAYLOAD_SCHEMA_VERSION,
        "product_code": product,
        "tenant_id": tenant,
        "valid_from": valid_from.isoformat().replace("+00:00", "Z"),
        "expires_at": expires_at.isoformat().replace("+00:00", "Z"),
        "duration_months": duration,
        "entitlements": entitlements,
        "limits": limits,
        "grace_period_days": grace_days,
    })
    current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    if current < valid_from:
        normalized["status"] = "NOT_YET_VALID"
    elif current > expires_at:
        normalized["status"] = "GRACE_PERIOD" if current <= expires_at + timedelta(days=grace_days) and grace_days else "EXPIRED"
    else:
        normalized["status"] = "ACTIVE"
    return normalized


def validate_payload(
    payload: Mapping[str, Any], *, now: datetime | None = None,
    expected_product: str | None = None, expected_tenant: str | None = None,
    expected_installation: str | None = None, allow_legacy: bool = False,
) -> dict[str, Any]:
    """Compatibility-named validator used by offline consumer SDKs."""
    if not is_canonical_payload(payload) and allow_legacy:
        return dict(payload)
    return validate_canonical_payload(
        payload, now=now, expected_product=expected_product,
        expected_tenant=expected_tenant, expected_installation=expected_installation,
    )


def license_status(payload: dict | None, now: datetime | None = None) -> str:
    if not payload:
        return "NOT_INSTALLED"
    raw_status = str(payload.get("status") or "").upper()
    if raw_status in _NON_TIME_STATUSES:
        return raw_status
    try:
        current = now or datetime.now(timezone.utc)
        start = _parse_datetime(payload["valid_from"])
        end = _parse_datetime(payload["expires_at"])
        grace_days = int(payload.get("grace_period_days", 0))
        if grace_days < 0:
            raise ValueError("negative grace period")
    except (KeyError, TypeError, ValueError, OverflowError):
        return "INVALID_SIGNATURE"
    if current < start:
        return "NOT_YET_VALID"
    if current >= end:
        grace_end = end + timedelta(days=grace_days)
        return "GRACE_PERIOD" if grace_days > 0 and current < grace_end else "EXPIRED"
    return "EXPIRING_SOON" if (end-current).days <= 30 else "ACTIVE"


def update_entitlement_expired(payload: dict | None, now: datetime | None = None) -> bool:
    value = (payload or {}).get("update_entitlement_until")
    if not value:
        return False
    try:
        return (now or datetime.now(timezone.utc)) >= _parse_datetime(value)
    except (TypeError, ValueError, OverflowError):
        return True
