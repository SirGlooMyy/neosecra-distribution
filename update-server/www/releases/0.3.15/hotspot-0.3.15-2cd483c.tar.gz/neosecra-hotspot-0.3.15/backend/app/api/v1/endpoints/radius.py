import uuid
from urllib.parse import parse_qs

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import settings
from app.core.ingest_auth import require_ingest_api_key
from app.modules.radius.models import RadiusEvent
from app.modules.customers.models import Customer
from app.modules.devices.models import RadiusClient
from app.modules.locations.models import Location
from app.core.installation import resolve_installation_customer
from app.modules.radius.schemas import RadiusEventCreate, RadiusEventOut
from app.modules.radius import challenge_service

router = APIRouter()


async def _resolve_event_tenant(
    db: AsyncSession, *, nas_ip: str | None, requested_tenant: uuid.UUID | None
) -> uuid.UUID:
    """Resolve accounting ownership from the registered NAS.

    RADIUS is machine-to-machine, so accepting an arbitrary tenant_id from the
    request would let a caller with the shared ingest key write into another
    tenant.  The NAS IP is the trust anchor; single-installation deployments
    retain the legacy fallback to their configured ownership customer.
    """
    tenant_id = None
    if nas_ip:
        row = (
            await db.execute(
                select(Customer.tenant_id)
                .join(Location, Location.customer_id == Customer.id)
                .join(RadiusClient, RadiusClient.location_id == Location.id)
                .where(
                    RadiusClient.nas_ip == nas_ip,
                    RadiusClient.is_active.is_(True),
                    Customer.is_active.is_(True),
                )
                .order_by(RadiusClient.created_at.asc())
                .limit(1)
            )
        ).scalar_one_or_none()
        tenant_id = row

    if tenant_id is None and settings.SINGLE_TENANT_MODE:
        customer_id = await resolve_installation_customer(db)
        tenant_id = (
            await db.execute(select(Customer.tenant_id).where(Customer.id == customer_id))
        ).scalar_one_or_none()

    if tenant_id is None:
        raise HTTPException(
            status_code=403,
            detail="RADIUS NAS kayitli degil; event sahipligi dogrulanamadi",
        )
    if requested_tenant is not None and requested_tenant != tenant_id:
        raise HTTPException(status_code=403, detail="RADIUS tenant scope uyusmuyor")
    return tenant_id


class VpnChallengeInitIn(BaseModel):
    """FreeRADIUS REST payload for the first Access-Request."""

    username: str = Field(..., min_length=1, max_length=255)
    customer_id: uuid.UUID | None = None
    nas_ip: str | None = None


class VpnChallengeVerifyIn(BaseModel):
    """FreeRADIUS REST payload for the Access-Challenge response."""

    state: str = Field(..., min_length=8, max_length=255)
    code: str = Field(..., min_length=4, max_length=32)


@router.post("/events", response_model=RadiusEventOut, summary="Ingest a RADIUS accounting event", description="Creates a new RADIUS accounting event record from a NAS device. Typically called by the RADIUS server or a syslog forwarder. Accepts standard RADIUS attributes such as username, NAS IP, and session identifiers.")
async def create_radius_event(
    body: RadiusEventCreate,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS")
    resolved_tenant_id = await _resolve_event_tenant(
        db, nas_ip=body.nas_ip, requested_tenant=body.tenant_id
    )
    event = RadiusEvent(
        tenant_id=resolved_tenant_id,
        username=body.username,
        nas_ip=body.nas_ip,
        nas_port=body.nas_port,
        acct_status_type=body.acct_status_type,
        acct_session_id=body.acct_session_id,
        calling_station_id=body.calling_station_id,
        framed_ip_address=body.framed_ip_address,
        acct_input_octets=body.acct_input_octets,
        acct_output_octets=body.acct_output_octets,
        acct_session_time=body.acct_session_time,
        acct_terminate_cause=body.acct_terminate_cause,
        acct_interim_interval=body.acct_interim_interval,
    )
    db.add(event)
    await db.commit()
    await db.refresh(event)
    return event


@router.post(
    "/vpn/challenge/init",
    summary="Start a VPN MFA RADIUS Access-Challenge",
    description="Called by the FreeRADIUS REST module for a FortiGate VPN login. The response contains the State and Reply-Message used for the second Access-Request.",
)
async def init_vpn_challenge(
    body: VpnChallengeInitIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    result = await challenge_service.init_challenge(
        db,
        customer_id=body.customer_id,
        username=body.username,
        nas_ip=body.nas_ip,
    )
    if result.get("challenge_required"):
        return {
            "control:Auth-Type": "Challenge",
            "reply:State": result.get("state"),
            "reply:Reply-Message": result.get("reply_message") or "OTP kodunu girin",
        }
    return {}


@router.post(
    "/vpn/challenge/init/form",
    include_in_schema=False,
)
async def init_vpn_challenge_form(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    try:
        form = await request.form()
        values = {str(key): str(value) for key, value in form.items()}
    except Exception:
        raw = (await request.body()).decode("utf-8", errors="replace")
        values = {key: items[-1] for key, items in parse_qs(raw, keep_blank_values=True).items() if items}
    def _value(*keys: str) -> str | None:
        for key in keys:
            value = values.get(key)
            if value not in (None, ""):
                return value
        return None
    username = _value("username", "User-Name", "User_Name")
    if not username:
        raise HTTPException(status_code=422, detail="User-Name gerekli")
    customer_raw = _value("customer_id", "Customer-Id", "Customer-ID")
    customer_id = None
    if customer_raw:
        try:
            customer_id = uuid.UUID(customer_raw)
        except ValueError:
            raise HTTPException(status_code=422, detail="customer_id gecersiz")
    result = await challenge_service.init_challenge(
        db,
        customer_id=customer_id,
        username=username,
        nas_ip=_value("nas_ip", "NAS-IP-Address", "NAS_IP_Address"),
    )
    if result.get("challenge_required"):
        return {
            "control:Auth-Type": "Challenge",
            "reply:State": result.get("state"),
            "reply:Reply-Message": result.get("reply_message") or "OTP kodunu girin",
        }
    return {}


@router.post(
    "/vpn/challenge/verify",
    summary="Verify a VPN MFA RADIUS Access-Challenge",
    description="Called by FreeRADIUS when FortiGate returns the one-time SMS, email or authenticator code.",
)
async def verify_vpn_challenge(
    body: VpnChallengeVerifyIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    result = await challenge_service.verify_challenge(db, state=body.state, code=body.code)
    if not result.get("verified"):
        raise HTTPException(status_code=401, detail="OTP dogrulama basarisiz")
    return {
        "control:Cleartext-Password": body.code,
        "reply:Reply-Message": "Giris basarili",
    }


@router.post(
    "/vpn/challenge/verify/form",
    include_in_schema=False,
)
async def verify_vpn_challenge_form(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """FreeRADIUS ``rest`` compatibility endpoint for the OTP response.

    ``rlm_rest`` sends RADIUS attributes as URL-encoded form fields when the
    operation uses ``body = post``.  Keep this adapter at the HTTP boundary so
    the challenge service remains independent of FreeRADIUS attribute names.
    Invalid codes deliberately return 401: rlm_rest maps that status to
    ``reject`` and cannot accidentally turn a failed OTP into Access-Accept.
    """
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    try:
        form = await request.form()
        values = {str(key): str(value) for key, value in form.items()}
    except Exception:
        raw = (await request.body()).decode("utf-8", errors="replace")
        values = {key: items[-1] for key, items in parse_qs(raw, keep_blank_values=True).items() if items}

    def _value(*keys: str) -> str | None:
        for key in keys:
            value = values.get(key)
            if value not in (None, ""):
                return value
        return None

    state = _value("state", "State", "State_", "reply:State")
    code = _value("code", "User-Password", "User_Password", "user_password")
    if not state or not code:
        raise HTTPException(status_code=422, detail="State ve OTP kodu gerekli")
    result = await challenge_service.verify_challenge(db, state=state, code=code)
    if not result.get("verified"):
        raise HTTPException(status_code=401, detail=result.get("reply_message") or "Gecersiz OTP")
    result.update({
        "control:Auth-Type": "Accept",
    })
    return result
