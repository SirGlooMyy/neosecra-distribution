"""IdentityVerification = guest identity verification record + short-lived
portal token produced by the PUBLIC captive flow once SMS/TC/Voucher succeeds.

Append-only in spirit: once issued it is only consumed, never edited. TC never
stored plaintext (salted hash). Phone stored normalized for session binding +
sha256 for anonymized search.
"""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import TimestampMixin, UUIDPK, fk

METHOD_SMS = "sms"
METHOD_TC = "tc"
METHOD_VOUCHER = "voucher"
METHOD_FREE = "free"
METHOD_PMS = "pms"
METHOD_WHATSAPP = "whatsapp"
METHOD_MEETING = "meeting"
METHOD_FOREIGNER = "foreigner"
METHOD_LOCAL = "local"
METHOD_LDAP = "ldap"
METHOD_RADIUS = "radius"
METHODS = (METHOD_SMS, METHOD_TC, METHOD_VOUCHER, METHOD_FREE, METHOD_PMS, METHOD_WHATSAPP, METHOD_MEETING, METHOD_FOREIGNER, METHOD_LOCAL, METHOD_LDAP, METHOD_RADIUS)


class IdentityVerification(Base, UUIDPK, TimestampMixin):
    """Guest identity verification record + short-lived portal token. TC never
    stored plaintext (salted hash). Phone stored normalized for session binding
    + sha256 for anonymized search."""

    __tablename__ = "identity_verifications"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    device_id: Mapped[uuid.UUID | None] = fk("devices", ondelete="SET NULL", nullable=True)
    method: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True, index=True)
    phone_hash: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    tc_number_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # Encrypted legal-evidence envelope. Plaintext document numbers never
    # live in PostgreSQL, but the 5651 archive builder can decrypt the sealed
    # value when producing a restricted legal export.
    identity_evidence_encrypted: Mapped[str | None] = mapped_column(String(4000), nullable=True)
    otp_id: Mapped[uuid.UUID | None] = fk("sms_otps", ondelete="SET NULL", nullable=True)
    voucher_id: Mapped[uuid.UUID | None] = fk("vouchers", ondelete="SET NULL", nullable=True)
    verified: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    portal_token: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)
    portal_token_expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    request_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    # Bounded, non-secret values from the configurable portal form. The flow
    # strips OTP/password/T.C. plaintext before assigning this JSON payload.
    form_data: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

    @property
    def phone_masked(self) -> str | None:
        """Masked phone for admin/support display (IdentityOut). Plaintext
        phone is never returned in any schema (Mutlak Kural #3)."""
        if not self.phone:
            return None
        p = self.phone
        return p[:6] + "***" + p[-2:] if len(p) >= 8 else "***"
