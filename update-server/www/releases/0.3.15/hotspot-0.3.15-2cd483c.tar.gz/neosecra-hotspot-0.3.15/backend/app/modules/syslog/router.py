"""Syslog trigger/alert endpoints.
"""
import json
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import TenantLevel, customer_in_scope, scope_for
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.syslog import trigger_service
from app.modules.syslog.models import TriggerEvent, SyslogTrigger

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=403, detail="Yetkisiz islem")


def _serialize_trigger(trigger: SyslogTrigger) -> dict:
    return {
        "id": str(trigger.id),
        "customer_id": str(trigger.customer_id),
        "name": trigger.name,
        "description": trigger.description,
        "match_type": trigger.match_type,
        "pattern": trigger.match_pattern,
        "severity_threshold": trigger.severity_threshold,
        "channel": trigger.channel,
        "channel_config": trigger.channel_config,
        "cooldown_minutes": trigger.cooldown_minutes,
        "is_active": trigger.is_active,
        "last_triggered_at": trigger.last_triggered_at.isoformat() if trigger.last_triggered_at else None,
        "last_triggered": trigger.last_triggered_at.isoformat() if trigger.last_triggered_at else None,
        "created_at": trigger.created_at.isoformat() if trigger.created_at else None,
        "updated_at": trigger.updated_at.isoformat() if trigger.updated_at else None,
    }


def _serialize_trigger_event(event: TriggerEvent, trigger_name: str | None = None) -> dict:
    return {
        "id": str(event.id),
        "trigger_id": str(event.trigger_id),
        "trigger_name": trigger_name,
        "syslog_record_id": str(event.syslog_record_id),
        "matched_value": event.matched_value,
        "timestamp": event.triggered_at.isoformat(),
        "triggered_at": event.triggered_at.isoformat(),
        "delivery_channel": event.delivery_channel,
        "delivery_status": event.delivery_status,
        "delivery_target": event.delivery_target,
        "delivery_detail": event.delivery_detail,
        "delivered_at": event.delivered_at.isoformat() if event.delivered_at else None,
        "acknowledged": event.acknowledged_at is not None,
        "acknowledged_at": event.acknowledged_at.isoformat() if event.acknowledged_at else None,
        "acknowledged_by": str(event.acknowledged_by) if event.acknowledged_by else None,
    }


def _scope_customer_clause(scope):
    """SQL predicate for trigger rows visible to the caller."""
    if not scope.allowed:
        return False
    if scope.level == TenantLevel.GLOBAL:
        return None
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return SyslogTrigger.customer_id == scope.customer_id
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        return SyslogTrigger.customer_id.in_(
            select(Customer.id).where(Customer.partner_id == scope.partner_id)
        )
    if scope.level == TenantLevel.TENANT and scope.tenant_id:
        return SyslogTrigger.customer_id.in_(
            select(Customer.id).where(Customer.tenant_id == scope.tenant_id)
        )
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        return SyslogTrigger.customer_id.in_(
            select(Location.customer_id).where(Location.id == scope.location_id)
        )
    return False


async def _validate_customer(db: AsyncSession, scope, customer_id):
    """Resolve installation default and reject cross-scope customer ids."""
    if customer_id is None and scope.level == TenantLevel.GLOBAL:
        customer_id = await resolve_installation_customer(db)
    if customer_id is None:
        raise HTTPException(status_code=400, detail="customer_id gerekli")
    try:
        customer_id = uuid.UUID(str(customer_id))
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="Gecersiz customer_id")
    if not await customer_in_scope(db, scope, customer_id):
        raise HTTPException(status_code=403, detail="Musteri scope disinda")
    return customer_id


async def _assert_trigger_scope(db: AsyncSession, scope, trigger: SyslogTrigger) -> None:
    if not await customer_in_scope(db, scope, trigger.customer_id):
        raise HTTPException(status_code=403, detail="Bu tetikleyici kapsaminiz disinda")


# --- Triggers CRUD ---

@router.get("/triggers", summary="List all syslog alert triggers", description="Returns all configured syslog triggers filtered by optional customer_id. Each trigger defines matching patterns and notification channels. Requires the syslog.read permission.")
async def list_triggers(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    customer_id = await _validate_customer(db, scope, customer_id)
    triggers = await trigger_service.list_triggers(db, customer_id)
    return [_serialize_trigger(trigger) for trigger in triggers]


def _normalize_trigger_payload(body: dict) -> dict:
    payload = dict(body)
    if "pattern" in payload and "match_pattern" not in payload:
        payload["match_pattern"] = payload.pop("pattern")
    if "match_pattern" not in payload:
        payload["match_pattern"] = ""
    st = payload.get("severity_threshold")
    if st in (None, "", "null"):
        payload["severity_threshold"] = None
    elif isinstance(st, str):
        try:
            payload["severity_threshold"] = int(st)
        except ValueError:
            payload["severity_threshold"] = None
    cc = payload.get("channel_config")
    if isinstance(cc, str):
        try:
            payload["channel_config"] = json.loads(cc) if cc.strip() else {}
        except Exception:
            payload["channel_config"] = {"raw": cc}
    elif not isinstance(cc, dict):
        payload["channel_config"] = {}
    return payload


@router.post("/triggers", status_code=201, summary="Create a new syslog alert trigger", description="Creates a new trigger rule that watches for specific patterns in incoming syslog messages. Supports match type, severity threshold, and notification channel configuration. Requires the syslog.write permission.")
async def create_trigger(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.write")
    scope = scope_for(user)
    customer_id = await _validate_customer(db, scope, body.get("customer_id") or scope.customer_id)
    payload = _normalize_trigger_payload(body)
    payload["customer_id"] = customer_id
    trigger = await trigger_service.create_trigger(db, payload)
    return _serialize_trigger(trigger)


@router.put("/triggers/{trigger_id}", summary="Update an existing syslog alert trigger", description="Updates the configuration of the specified syslog trigger including pattern, severity threshold, channel settings, and active status. Requires the syslog.write permission.")
async def update_trigger(
    trigger_id: uuid.UUID,
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.write")
    scope = scope_for(user)
    existing = await db.get(SyslogTrigger, trigger_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Tetikleyici bulunamadi")
    await _assert_trigger_scope(db, scope, existing)
    payload = _normalize_trigger_payload(body)
    trigger = await trigger_service.update_trigger(db, trigger_id, payload)
    return _serialize_trigger(trigger)


@router.delete("/triggers/{trigger_id}", status_code=204, summary="Delete a syslog alert trigger", description="Permanently removes the specified trigger and its configuration. Triggered events associated with this trigger are preserved for auditing. Requires the syslog.write permission.")
async def delete_trigger(
    trigger_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.write")
    scope = scope_for(user)
    existing = await db.get(SyslogTrigger, trigger_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Tetikleyici bulunamadi")
    await _assert_trigger_scope(db, scope, existing)
    await trigger_service.delete_trigger(db, trigger_id)


# --- Events ---

@router.get("/triggers/events", summary="List syslog trigger events with optional filter", description="Returns recent trigger events with their delivery status. Optionally filtered by a specific trigger ID. Includes acknowledgment and delivery detail information. Requires the syslog.read permission.")
async def list_trigger_events(
    trigger_id: uuid.UUID | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    q = (
        select(TriggerEvent, SyslogTrigger.name)
        .join(SyslogTrigger, TriggerEvent.trigger_id == SyslogTrigger.id)
        .order_by(TriggerEvent.triggered_at.desc())
        .limit(limit)
    )
    if trigger_id:
        q = q.where(TriggerEvent.trigger_id == trigger_id)
    scope_clause = _scope_customer_clause(scope)
    if scope_clause is False:
        return []
    if scope_clause is not None:
        q = q.where(scope_clause)
    res = await db.execute(q)
    return [_serialize_trigger_event(event, trigger_name=trigger_name) for event, trigger_name in res.all()]


@router.post("/triggers/events/{event_id}/acknowledge", summary="Acknowledge a syslog trigger event", description="Marks the specified trigger event as acknowledged by the current user. Acknowledged events are considered reviewed and will not trigger additional notifications. Requires the syslog.write permission.")
async def acknowledge_event(
    event_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.write")
    scope = scope_for(user)
    existing = await db.get(TriggerEvent, event_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Tetikleyici olayi bulunamadi")
    trigger = await db.get(SyslogTrigger, existing.trigger_id)
    if not trigger:
        raise HTTPException(status_code=404, detail="Tetikleyici bulunamadi")
    await _assert_trigger_scope(db, scope, trigger)
    event = await trigger_service.acknowledge_trigger(db, event_id, user.id)
    trigger = await db.get(SyslogTrigger, event.trigger_id) if event.trigger_id else None
    trigger_name = trigger.name if trigger else None
    return _serialize_trigger_event(event, trigger_name=trigger_name)


# --- Stats ---

@router.get("/triggers/stats", summary="Get syslog trigger statistics", description="Returns aggregated statistics for syslog triggers including total triggers, event counts, and delivery success rates for a given customer. Requires the syslog.read permission.")
async def get_trigger_stats(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    customer_id = await _validate_customer(db, scope, customer_id)
    return await trigger_service.get_trigger_stats(db, customer_id)


def _resolve_customer(user: User) -> uuid.UUID | None:
    scope = scope_for(user)
    return scope.customer_id
