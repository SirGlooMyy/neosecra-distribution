"""Auth business logic: login (with rate limiting), token refresh, logout
(token blacklist), registration by admins."""
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.rbac import has_permission
from app.core.security import (
    blacklist_token,
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    is_token_blacklisted,
    rate_limit_check,
    rate_limit_reset,
    verify_password,
)
from app.modules.audit.service import log_audit
from app.modules.auth.models import User
from app.modules.auth.schemas import LoginRequest, LoginResponse, MfaVerifyIn, TokenResponse, UserOut
from app.modules.mfa.models import MfaSession


def _client_ip(request: Request | None) -> str:
    return request.client.host if request and request.client else "unknown"


async def authenticate(
    db: AsyncSession,
    body: LoginRequest,
    request: Request | None = None,
) -> TokenResponse | LoginResponse:
    ip = _client_ip(request)
    rl_key = f"login:{body.email}:{ip}"
    blocked, attempts = await rate_limit_check(rl_key)
    if blocked:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Cok fazla basarisiz deneme. Daha sonra tekrar deneyin.",
        )

    result = await db.execute(select(User).where(User.email == body.email))
    user = result.scalar_one_or_none()

    # Constant-ish failure path: never leak whether the email exists.
    if not user or not user.is_active or not verify_password(body.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Gecersiz e-posta veya sifre",
        )

    # Successful auth -> reset the rate-limit window.
    await rate_limit_reset(rl_key)

    # MFA required: return challenge instead of tokens
    if user.mfa_required:
        # Prefer an enrolled TOTP token.  For SMS/e-mail challenges delegate to
        # the single MFA service so the generated code hash is persisted on the
        # challenge itself and cannot be bypassed by the login endpoint.
        methods = [str(m) for m in (user.mfa_methods or [])]
        method = methods[0] if methods else "totp"
        if method == "totp":
            session_token = secrets.token_urlsafe(32)
            mfa_session = MfaSession(
                user_id=user.id,
                session_token=session_token,
                mfa_type="totp",
                verified=False,
                expires_at=datetime.now(timezone.utc) + timedelta(seconds=settings.MFA_CODE_TTL_SECONDS),
            )
            db.add(mfa_session)
            await db.flush()
        else:
            from app.modules.mfa.service import send_mfa_code

            session_token = await send_mfa_code(db, user.id, method=method, request=request)

        # get_db intentionally does not auto-commit. Persist the challenge
        # before returning it; otherwise the next request cannot find it.
        await db.commit()

        return LoginResponse(
            mfa_required=True,
            mfa_session_token=session_token,
            user=UserOut.model_validate(user),
        )

    token_data = {
        "role": user.role,
        "tid": str(user.tenant_id) if user.tenant_id else None,
    }
    access = create_access_token(str(user.id), extra=token_data)
    refresh = create_refresh_token(str(user.id))

    user.last_login_at = datetime.now(timezone.utc)
    await db.commit()

    await log_audit(
        db, "auth.login", "user", str(user.id), str(user.id), request,
        details={"ip": ip}, tenant_id=str(user.tenant_id) if user.tenant_id else None,
    )
    await db.commit()

    return TokenResponse(
        access_token=access,
        refresh_token=refresh,
        user=UserOut.model_validate(user),
    )


async def verify_mfa_and_login(
    db: AsyncSession,
    body: MfaVerifyIn,
    request: Request | None = None,
) -> TokenResponse:
    session = (
        await db.execute(
            select(MfaSession).where(
                MfaSession.session_token == body.session_token,
                MfaSession.verified.is_(False),
                MfaSession.consumed_at.is_(None),
                MfaSession.expires_at > datetime.now(timezone.utc),
            )
        )
    ).scalar_one_or_none()

    if not session:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="MFA oturumu gecersiz veya sureci dolmus",
        )

    user = await db.get(User, session.user_id)
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Kullanici bulunamadi",
        )

    if session.mfa_type == "totp":
        from app.modules.mfa.service import verify_totp

        try:
            valid = await verify_totp(db, user.id, body.code)
        except HTTPException:
            valid = False
        if not valid:
            session.attempt_count = (session.attempt_count or 0) + 1
            if session.attempt_count >= 5:
                session.consumed_at = datetime.now(timezone.utc)
            await db.flush()
            await db.commit()
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Gecersiz MFA kodu",
            )
        session.verified = True
        session.consumed_at = datetime.now(timezone.utc)
        await db.flush()
    else:
        from app.modules.mfa.service import verify_mfa_code

        if not await verify_mfa_code(db, body.session_token, body.code, request):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Gecersiz MFA kodu",
            )

    token_data = {
        "role": user.role,
        "tid": str(user.tenant_id) if user.tenant_id else None,
    }
    access = create_access_token(str(user.id), extra=token_data)
    refresh = create_refresh_token(str(user.id))

    user.last_login_at = datetime.now(timezone.utc)
    await db.commit()

    await log_audit(
        db, "auth.login", "user", str(user.id), str(user.id), request,
        details={"ip": _client_ip(request), "mfa": True},
        tenant_id=str(user.tenant_id) if user.tenant_id else None,
    )
    await db.commit()

    return TokenResponse(
        access_token=access,
        refresh_token=refresh,
        user=UserOut.model_validate(user),
    )


async def refresh_tokens(db: AsyncSession, refresh_token: str) -> TokenResponse:
    try:
        payload = decode_token(refresh_token)
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Gecersiz refresh token")

    if payload.get("type") != "refresh":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Gecersiz refresh token")

    # Revoked refresh tokens must not mint new tokens.
    if await is_token_blacklisted(payload.get("jti", "")):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Gecersiz refresh token")

    user = await db.get(User, uuid.UUID(str(payload.get("sub", ""))))
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Kullanici bulunamadi")

    # Rotate refresh tokens as one-time credentials.  Revoking the token that
    # was just presented prevents replay after a successful refresh while
    # preserving the existing response contract.
    current_jti = payload.get("jti")
    current_exp = payload.get("exp")
    if current_jti and current_exp:
        await blacklist_token(str(current_jti), int(current_exp))

    token_data = {"role": user.role, "tid": str(user.tenant_id) if user.tenant_id else None}
    access = create_access_token(str(user.id), extra=token_data)
    new_refresh = create_refresh_token(str(user.id))
    return TokenResponse(
        access_token=access,
        refresh_token=new_refresh,
        user=UserOut.model_validate(user),
    )


async def update_current_user_profile(
    db: AsyncSession,
    user: User,
    *,
    email: str | None = None,
    full_name: str | None = None,
    request: Request | None = None,
) -> User:
    changes: dict[str, str | None] = {}

    if email is not None:
        normalized_email = email.strip().lower()
        if normalized_email != user.email:
            existing = (
                await db.execute(
                    select(User).where(User.email == normalized_email, User.id != user.id)
                )
            ).scalar_one_or_none()
            if existing:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Bu e-posta adresi zaten kullaniliyor",
                )
            user.email = normalized_email
            changes["email"] = normalized_email

    if full_name is not None:
        normalized_name = full_name.strip() or None
        if normalized_name != user.full_name:
            user.full_name = normalized_name
            changes["full_name"] = normalized_name

    if not changes:
        return user

    await log_audit(
        db,
        "auth.profile_updated",
        "user",
        str(user.id),
        str(user.id),
        request,
        details=changes,
        tenant_id=str(user.tenant_id) if user.tenant_id else None,
    )
    await db.commit()
    await db.refresh(user)
    return user


async def logout(jti: str, exp: int) -> None:
    await blacklist_token(jti, exp)


async def create_user(
    db: AsyncSession,
    *,
    email: str,
    password: str,
    role: str,
    full_name: str | None,
    tenant_id: uuid.UUID | None,
    partner_id: uuid.UUID | None,
    customer_id: uuid.UUID | None,
    location_id: uuid.UUID | None,
    actor: User,
    request: Request | None = None,
) -> User:
    if not has_permission(actor.role, "user.write") and actor.role != "super_admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Kullanici olusturma yetkisi yok")

    user = User(
        email=email,
        full_name=full_name,
        hashed_password=hash_password(password),
        role=role,
        tenant_id=tenant_id,
        partner_id=partner_id,
        customer_id=customer_id,
        location_id=location_id,
    )
    db.add(user)
    await db.flush()
    await log_audit(
        db, "user.created", "user", str(user.id), str(actor.id), request,
        details={"role": role, "email": email},
        tenant_id=str(actor.tenant_id) if actor.tenant_id else None,
    )
    await db.commit()
    await db.refresh(user)
    return user
