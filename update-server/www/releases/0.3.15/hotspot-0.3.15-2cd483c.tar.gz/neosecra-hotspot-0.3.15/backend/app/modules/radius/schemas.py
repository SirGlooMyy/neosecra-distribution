from pydantic import BaseModel
from datetime import datetime
from typing import Optional
import uuid


class RadiusEventBase(BaseModel):
    username: str
    nas_ip: Optional[str] = None
    nas_port: Optional[int] = None
    acct_status_type: Optional[str] = None
    acct_session_id: Optional[str] = None
    calling_station_id: Optional[str] = None
    framed_ip_address: Optional[str] = None
    acct_input_octets: Optional[int] = None
    acct_output_octets: Optional[int] = None
    acct_session_time: Optional[int] = None
    acct_terminate_cause: Optional[str] = None
    acct_interim_interval: Optional[int] = None


class RadiusEventCreate(RadiusEventBase):
    tenant_id: Optional[uuid.UUID] = None


class RadiusEventOut(RadiusEventBase):
    id: uuid.UUID
    tenant_id: Optional[uuid.UUID] = None
    created_at: datetime

    model_config = {"from_attributes": True}
