"""IPsec and Dial-up VPN Monitoring Endpoints."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.ipsec import service
from app.modules.ipsec.schemas import (
    IpsecEventOut,
    IpsecSummaryOut,
    IpsecTrendPoint,
    IpsecTunnelSessionOut,
)

router = APIRouter()


@router.get("/summary", response_model=IpsecSummaryOut, summary="Get IPsec & Dial-up KPI summary metrics")
async def get_ipsec_summary(
    days: int = Query(7, ge=1, le=90),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_ipsec_summary(db, scope_for(user), days=days)


@router.get("/tunnels", response_model=list[IpsecTunnelSessionOut], summary="List IPsec and Dial-up tunnel sessions")
async def get_ipsec_tunnels(
    days: int = Query(7, ge=1, le=90),
    filter_mode: str = Query("all", description="all|dialup|sitetosite|natt|error"),
    search: str | None = Query(None),
    limit: int = Query(150, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_ipsec_tunnels(
        db,
        scope_for(user),
        days=days,
        filter_mode=filter_mode,
        search=search,
        limit=limit,
    )


@router.get("/events", response_model=list[IpsecEventOut], summary="Live IKE negotiation and IPsec event stream")
async def get_ipsec_events(
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_ipsec_events(db, scope_for(user), limit=limit)


@router.get("/traffic-trend", response_model=list[IpsecTrendPoint], summary="Get IPsec traffic trend over time")
async def get_ipsec_traffic_trend(
    days: int = Query(7, ge=1, le=90),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_ipsec_traffic_trend(db, scope_for(user), days=days)
