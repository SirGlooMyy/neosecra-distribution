"""5651 archive service — append-only build + hash-chain seal + verification.

This is the legally sensitive core (Mutlak Kural #4 — 5651 records are
immutable; append-only event approach; the archive hash is never updated).

Flow:
  build_session_archive gathers the GuestSessions for a (customer, period),
  serializes them deterministically (sorted, fixed key order, JSONL), gzips the
  payload (deterministic mtime=0 so the same input -> the same artifact -> the
  same content_hash), uploads it (archive_service) and seals an ArchiveRecord:

      content_hash = sha256(payload_bytes)
      prev_hash    = last.curr_hash in the chain (GENESIS_HASH for the first)
      curr_hash    = sha256(prev_hash | content_hash | period_key | record_type)

The chain is per (customer, record_type). verify_chain re-walks it: it recomputes
each curr_hash from the STORED (prev_hash, content_hash, period_key, record_type)
and checks the prev_hash linkage. A mismatch proves a row was retroactively
edited/deleted/reordered — tamper-evidence without trusting the object store.

Rows are never UPDATEd or DELETEd here (and the table has no soft-delete mixin).
"""
from __future__ import annotations

import gzip
import hashlib
import json
import logging
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import false, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.core.config import settings
from app.core.crypto import decrypt
from app.core.installation import resolve_installation_customer
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.logs_5651 import archive_service
from app.modules.logs_5651.models import (
    ARCHIVE_STATUS_FAILED,
    ARCHIVE_STATUS_PENDING,
    ARCHIVE_STATUS_READY,
    GENESIS_HASH,
    RECORD_SESSION_ARCHIVE,
    ArchiveRecord,
)
from app.modules.logs_5651.schemas import ArchiveVerifyResult
from app.modules.sessions.models import GuestSession

log = logging.getLogger(__name__)


def _signature_digest(record: ArchiveRecord) -> str:
    """Return the exact digest signed by ``sign_archive_record``."""
    content = (
        f"{record.curr_hash}:{record.content_hash}:"
        f"{record.period_start.isoformat()}:{record.period_end.isoformat()}"
    )
    return hashlib.sha256(content.encode()).hexdigest()


def _uploaded_payload_matches(content_ref: str, payload: bytes, expected_hash: str) -> bool:
    """Verify the object-store round trip before an archive can be ready."""
    if not content_ref or archive_service.is_compatibility_reference(content_ref):
        return False
    stored = archive_service.read_archive_payload(content_ref)
    return stored is not None and archive_service.content_hash(stored) == expected_hash


async def _mark_archive_failed(db: AsyncSession, record: ArchiveRecord, reason: str) -> ArchiveRecord:
    record.status = ARCHIVE_STATUS_FAILED
    record.storage_verified = False
    record.signature_valid = False
    record.error_message = reason[:2000]
    await db.flush()
    await db.commit()
    await db.refresh(record)
    return record


# ---- hash chain primitives --------------------------------------------------
def _chain_hash(
    prev_hash: str, content_hash: str, period_key: str, record_type: str
) -> str:
    h = hashlib.sha256()
    for part in (prev_hash, content_hash, period_key, record_type):
        h.update(part.encode("utf-8"))
        h.update(b"|")
    return h.hexdigest()


def _period_key(period_start: datetime, period_end: datetime) -> str:
    ps = period_start.astimezone().isoformat() if period_start.tzinfo else period_start.isoformat()
    pe = period_end.astimezone().isoformat() if period_end.tzinfo else period_end.isoformat()
    return f"{ps}/{pe}"


async def _last_in_chain(
    db: AsyncSession, customer_id: uuid.UUID, record_type: str
) -> ArchiveRecord | None:
    res = await db.execute(
        select(ArchiveRecord)
        .where(
            ArchiveRecord.customer_id == customer_id,
            ArchiveRecord.record_type == record_type,
        )
        .order_by(ArchiveRecord.chain_seq.desc())
        .limit(1)
    )
    return res.scalar_one_or_none()


# ---- canonical serialization of a period's sessions ------------------------
def _serialize_sessions(
    sessions: list[GuestSession],
    identities: dict[uuid.UUID, object] | None = None,
) -> bytes:
    """Deterministic JSONL of the 5651-relevant session fields, gzipped.

    Identity (phone) + IP/MAC are exactly what 5651/YYİH retention needs for
    IP<->kimlik correlation. Sorted by (started_at, id) and emitted with
    sort_keys so the same input always yields the same artifact/content_hash."""
    rows = []
    identities = identities or {}
    for s in sorted(
        sessions,
        key=lambda x: (
            x.started_at or datetime.min.replace(tzinfo=timezone.utc),
            str(x.id),
        ),
    ):
        identity = identities.get(s.identity_verification_id) if s.identity_verification_id else None
        identity_form = dict(getattr(identity, "form_data", None) or {}) if identity else {}
        identity_method = getattr(identity, "method", None) if identity else None
        legal_evidence: dict = {}
        encrypted_evidence = getattr(identity, "identity_evidence_encrypted", None) if identity else None
        if encrypted_evidence:
            try:
                decoded = json.loads(decrypt(encrypted_evidence))
                if isinstance(decoded, dict):
                    legal_evidence = decoded
            except Exception:
                log.warning("5651 identity evidence could not be decrypted for session=%s", s.id)
        # Keep the legal correlation evidence in the archive without putting
        # plaintext T.C./passport numbers in the operational database. The
        # identity service stores a salted T.C. hash; foreigner/passport flows
        # use the same protected document hash. Names and consent fields are
        # safe, bounded form values captured at verification time.
        identity_payload = None
        if identity:
            identity_payload = {
                "method": identity_method,
                "phone": getattr(identity, "phone", None) or s.phone,
                "full_name": identity_form.get("full_name"),
                "first_name": identity_form.get("first_name"),
                "last_name": identity_form.get("last_name"),
                "country": identity_form.get("country"),
                "document_type": "passport" if identity_method == "foreigner" else "tc_kimlik",
                # Restricted 5651 exports must be readable without resolving
                # an internal UUID. These values come only from the encrypted
                # evidence envelope and are never exposed by operational APIs.
                "national_id": legal_evidence.get("national_id"),
                "passport_no": legal_evidence.get("passport_no"),
                "country_code": legal_evidence.get("country_code") or legal_evidence.get("country"),
                "document_hash": getattr(identity, "tc_number_hash", None),
                "legal_evidence": legal_evidence,
                "verified": bool(getattr(identity, "verified", False)),
                "verified_at": getattr(identity, "created_at", None).isoformat()
                if getattr(identity, "created_at", None) else None,
            }
        rows.append(
            {
                "session_id": str(s.id),
                "customer_id": str(s.customer_id),
                "location_id": str(s.location_id) if s.location_id else None,
                "device_id": str(s.device_id) if s.device_id else None,
                "mac": s.mac,
                "ip": s.ip,
                "nas_ip": s.nas_ip,
                "ssid": s.ssid,
                "phone": s.phone,
                "auth_method": s.auth_method,
                "identity_verification_id": str(s.identity_verification_id)
                if s.identity_verification_id
                else None,
                "identity": identity_payload,
                "voucher_id": str(s.voucher_id) if s.voucher_id else None,
                "status": s.status,
                "started_at": s.started_at.isoformat() if s.started_at else None,
                "ended_at": s.ended_at.isoformat() if s.ended_at else None,
                "expires_at": s.expires_at.isoformat() if s.expires_at else None,
            }
        )
    payload = ("\n".join(json.dumps(r, sort_keys=True) for r in rows)).encode("utf-8")
    if not rows:
        payload = b""  # empty-period archive still seals a (content_hash) record
    return gzip.compress(payload, mtime=0)


# ---- append-only build ------------------------------------------------------
async def build_session_archive(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    period_start: datetime,
    period_end: datetime,
    request: Request | None = None,
) -> ArchiveRecord:
    """Build + seal one archive record for a customer/period. APPEND-ONLY.

    Gathers sessions whose started_at falls in [period_start, period_end).
    Idempotent at the data level (deterministic payload) but ALWAYS appends a
    new chain record — re-running for the same period produces a new sealed
    record (chain_seq + 1) rather than mutating an existing one (Kural #4)."""
    if period_end <= period_start:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="period_end period_start'tan sonra olmali",
        )

    res = await db.execute(
        select(GuestSession).where(
            GuestSession.customer_id == customer_id,
            GuestSession.started_at >= period_start,
            GuestSession.started_at < period_end,
        )
    )
    sessions = list(res.scalars().all())

    identity_map: dict[uuid.UUID, object] = {}
    identity_ids = {
        s.identity_verification_id
        for s in sessions
        if s.identity_verification_id is not None
    }
    if identity_ids:
        from app.modules.identity.models import IdentityVerification

        identity_res = await db.execute(
            select(IdentityVerification).where(IdentityVerification.id.in_(identity_ids))
        )
        identity_map = {item.id: item for item in identity_res.scalars().all()}

    payload = _serialize_sessions(sessions, identity_map)
    content_hash = archive_service.content_hash(payload)
    content_ref = ""
    storage_error: str | None = None
    try:
        content_ref = archive_service.upload(
            payload, customer_id=customer_id, period_start=period_start
        )
        if not _uploaded_payload_matches(content_ref, payload, content_hash):
            storage_error = "5651 archive payload storage could not be verified"
    except Exception as exc:  # noqa: BLE001 - persisted as failed evidence state
        storage_error = f"5651 archive payload storage failed: {exc}"

    last = await _last_in_chain(db, customer_id, RECORD_SESSION_ARCHIVE)
    prev_hash = last.curr_hash if last else GENESIS_HASH
    chain_seq = (last.chain_seq + 1) if last else 1
    pkey = _period_key(period_start, period_end)
    curr_hash = _chain_hash(prev_hash, content_hash, pkey, RECORD_SESSION_ARCHIVE)

    record = ArchiveRecord(
        customer_id=customer_id,
        period_start=period_start,
        period_end=period_end,
        record_type=RECORD_SESSION_ARCHIVE,
        chain_seq=chain_seq,
        item_count=len(sessions),
        content_hash=content_hash,
        content_ref=content_ref,
        content_size=len(payload),
        prev_hash=prev_hash,
        curr_hash=curr_hash,
        meta={"gzip": True, "format": "jsonl"},
        status=ARCHIVE_STATUS_FAILED if storage_error else ARCHIVE_STATUS_PENDING,
        error_message=storage_error,
        storage_verified=not bool(storage_error),
        signature_valid=False,
    )
    db.add(record)
    await db.flush()
    await log_audit(
        db,
        "5651.archive_created",
        "archive_record_5651",
        str(record.id),
        None,
        request,
        details={
            "customer_id": str(customer_id),
            "record_type": RECORD_SESSION_ARCHIVE,
            "chain_seq": chain_seq,
            "item_count": len(sessions),
            "curr_hash": curr_hash,
        },
    )
    await db.commit()
    await db.refresh(record)

    if storage_error:
        return await _mark_archive_failed(db, record, storage_error)

    # Automatically digitally sign and seal the archive
    try:
        from app.modules.logs_5651.signing_service import sign_archive_record

        await sign_archive_record(db, record)
        from app.modules.logs_5651.signing_service import verify_signature
        if not verify_signature(
            _signature_digest(record),
            record.signature_value or "",
            customer_id=record.customer_id,
        ):
            raise RuntimeError("5651 archive signature verification failed")
        record.signature_valid = True
        record.status = ARCHIVE_STATUS_READY
        record.error_message = None
        await db.commit()
        await db.refresh(record)
        log.info("5651 oturum arsivi seq=%d basariyla imzalandi (customer=%s)", chain_seq, customer_id)
    except Exception as exc:
        log.warning("5651 oturum arsivi seq=%d imzalanamadi: %s", chain_seq, exc)
        await _mark_archive_failed(db, record, f"5651 archive signature failed: {exc}")

    return record


async def build_raw_log_archive(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    record_type: str,
    period_start: datetime,
    period_end: datetime,
    records: list[dict] | None = None,
    request: Request | None = None,
) -> ArchiveRecord:
    """Build + seal an archive record for raw traffic/syslog/radius logs into the hash chain. APPEND-ONLY."""
    if period_end <= period_start:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="period_end period_start'tan sonra olmali",
        )

    log_records = records or []
    if not log_records:
        # 1. Query ClickHouse first (primary high-volume real FortiGate syslog store)
        if settings.CLICKHOUSE_ENABLED:
            try:
                from app.adapters import clickhouse as ch
                ch_rows = await ch.query_syslog(
                    customer_id=str(customer_id),
                    from_time=period_start,
                    to_time=period_end,
                    limit=10000000,
                )
                if ch_rows:
                    log_records = [
                        {
                            "id": str(r.get("id") or uuid.uuid4()),
                            "timestamp": r["timestamp"].isoformat() if isinstance(r.get("timestamp"), datetime) else str(r.get("timestamp", "")),
                            "src_ip": str(r.get("source_ip", "")),
                            "src_port": int(r.get("source_port") or 0),
                            "nat_ip": str(r.get("transip") or "") or None,
                            "nat_port": int(r.get("transport") or 0) or None,
                            "dst_ip": str(r.get("dest_ip", "")),
                            "dst_port": int(r.get("dest_port") or 0),
                            "proto": str(r.get("protocol") or "TCP"),
                            "action": str(r.get("action", "ACCEPT")).upper(),
                            "user": str(r.get("username", "")),
                            "mac": str(r.get("mac", "")),
                        }
                        for r in ch_rows
                    ]
            except Exception as exc:
                log.warning("ClickHouse 5651 raw log query fallback: %s", exc)

        # 2. Fallback to PostgreSQL if ClickHouse had no records for the period
        if not log_records:
            from app.modules.syslog.models import FirewallLog
            query = (
                select(
                    FirewallLog.id,
                    FirewallLog.customer_id,
                    FirewallLog.tenant_id,
                    FirewallLog.event_time,
                    FirewallLog.action,
                    FirewallLog.src_ip,
                    FirewallLog.dst_ip,
                    FirewallLog.src_port,
                    FirewallLog.dst_port,
                    FirewallLog.proto,
                    FirewallLog.user,
                    FirewallLog.parsed_fields,
                )
                .where(
                    or_(FirewallLog.customer_id == customer_id, FirewallLog.tenant_id == customer_id),
                    FirewallLog.event_time >= period_start,
                    FirewallLog.event_time < period_end,
                    or_(
                        FirewallLog.log_subtype.ilike("%forward%"),
                        FirewallLog.action.in_(["accept", "close", "client-rst", "server-rst"]),
                        FirewallLog.log_type == "traffic",
                    ),
                )
                .order_by(FirewallLog.event_time.asc())
                .limit(10000000)
            )
            res = await db.execute(query)
            fw_rows = res.all()
            log_records = []
            for r in fw_rows:
                fid, cid, tid, etime, act, sip, dip, sport, dport, proto, uname, pf = r
                pf = pf or {}
                # Canonical 5651 NAT record format (IP - Port - NAT IP - NAT Port - Dst IP - Dst Port)
                log_records.append({
                    "id": str(fid),
                    "timestamp": etime.isoformat() if etime else None,
                    "src_ip": str(sip or ""),
                    "src_port": sport or int(pf.get("srcport") or 0),
                    "nat_ip": str(pf.get("transip") or pf.get("assigned_ip") or "") or None,
                    "nat_port": int(pf.get("transport") or 0) or None,
                    "dst_ip": str(dip or ""),
                    "dst_port": dport or int(pf.get("dstport") or 0),
                    "proto": str(proto or pf.get("proto") or "TCP"),
                    "action": str(act or "ACCEPT").upper(),
                    "user": str(uname or pf.get("user") or pf.get("srcname") or ""),
                    "mac": str(pf.get("srcmac") or ""),
                })

    payload = archive_service.serialize_raw_logs(log_records)
    content_hash = archive_service.content_hash(payload)
    content_ref = ""
    storage_error: str | None = None
    try:
        content_ref = archive_service.upload(
            payload, customer_id=customer_id, period_start=period_start
        )
        if not _uploaded_payload_matches(content_ref, payload, content_hash):
            storage_error = "5651 raw log payload storage could not be verified"
    except Exception as exc:  # noqa: BLE001 - persisted as failed evidence state
        storage_error = f"5651 raw log payload storage failed: {exc}"

    searchable = archive_service.extract_searchable_fields(log_records)

    last = await _last_in_chain(db, customer_id, record_type)
    prev_hash = last.curr_hash if last else GENESIS_HASH
    chain_seq = (last.chain_seq + 1) if last else 1
    pkey = _period_key(period_start, period_end)
    curr_hash = _chain_hash(prev_hash, content_hash, pkey, record_type)

    record = ArchiveRecord(
        customer_id=customer_id,
        period_start=period_start,
        period_end=period_end,
        record_type=record_type,
        chain_seq=chain_seq,
        item_count=len(log_records),
        content_hash=content_hash,
        content_ref=content_ref,
        content_size=len(payload),
        prev_hash=prev_hash,
        curr_hash=curr_hash,
        meta={"zstd": True, "format": "jsonl", "record_type": record_type},
        status=ARCHIVE_STATUS_FAILED if storage_error else ARCHIVE_STATUS_PENDING,
        error_message=storage_error,
        storage_verified=not bool(storage_error),
        signature_valid=False,
    )
    db.add(record)

    from app.modules.logs_5651.models import ArchiveIndex
    archive_index = ArchiveIndex(
        customer_id=customer_id,
        period_start=period_start,
        period_end=period_end,
        record_count=len(log_records),
        file_ref=content_ref,
        file_size=len(payload),
        compression="zstd",
        content_hash=content_hash,
        prev_hash=prev_hash,
        searchable_fields=searchable,
    )
    db.add(archive_index)

    await db.flush()
    await log_audit(
        db,
        "5651.archive_created",
        "archive_record_5651",
        str(record.id),
        None,
        request,
        details={
            "customer_id": str(customer_id),
            "record_type": record_type,
            "chain_seq": chain_seq,
            "item_count": len(log_records),
            "curr_hash": curr_hash,
        },
    )
    await db.commit()
    await db.refresh(record)

    if storage_error:
        return await _mark_archive_failed(db, record, storage_error)

    # Automatically digitally sign and seal the archive
    try:
        from app.modules.logs_5651.signing_service import sign_archive_record

        await sign_archive_record(db, record)
        from app.modules.logs_5651.signing_service import verify_signature
        if not verify_signature(
            _signature_digest(record),
            record.signature_value or "",
            customer_id=record.customer_id,
        ):
            raise RuntimeError("5651 raw log signature verification failed")
        record.signature_valid = True
        record.status = ARCHIVE_STATUS_READY
        record.error_message = None
        await db.commit()
        await db.refresh(record)
        log.info("5651 trafik arsivi seq=%d basariyla imzalandi (customer=%s, type=%s)", chain_seq, customer_id, record_type)
    except Exception as exc:
        log.warning("5651 trafik arsivi seq=%d imzalanamadi: %s", chain_seq, exc)
        await _mark_archive_failed(db, record, f"5651 archive signature failed: {exc}")

    return record


async def sign_all_unsigned_archives(db: AsyncSession, scope: ScopeContext) -> dict:
    """Signs all currently unsigned archive records for the scoped customer(s)."""
    from app.modules.logs_5651.signing_service import sign_archive_record

    query, _ = await _scoped_query(db, scope)
    res = await db.execute(
        query.where(ArchiveRecord.signature_value.is_(None)).order_by(ArchiveRecord.chain_seq.asc())
    )
    records = list(res.scalars().all())

    signed_count = 0
    failed_count = 0
    for rec in records:
        try:
            await sign_archive_record(db, rec)
            signed_count += 1
        except Exception as exc:
            failed_count += 1
            log.warning("Toplu imzalama arsiv=%s basarisiz: %s", rec.id, exc)

    await db.commit()
    return {
        "total_unsigned": len(records),
        "signed_count": signed_count,
        "failed_count": failed_count,
    }


async def seal_live_logs_today(
    db: AsyncSession,
    scope: ScopeContext,
    customer_id: uuid.UUID | None = None,
) -> list[dict]:
    """Instantly builds and cryptographically signs both Session Archive and Firewall Traffic Archive for today."""
    cid = customer_id or scope.customer_id
    if cid is None and scope.level == TenantLevel.GLOBAL:
        cid = await resolve_installation_customer(db)
    if not cid:
        raise HTTPException(status_code=400, detail="Müşteri ID bulunamadı.")

    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    today_end = datetime.now(timezone.utc)

    results = []
    # 1. Build & sign Session Archive
    try:
        sess_rec = await build_session_archive(
            db, customer_id=cid, period_start=today_start, period_end=today_end
        )
        results.append({
            "type": "session_archive",
            "id": str(sess_rec.id),
            "seq": sess_rec.chain_seq,
            "count": sess_rec.item_count,
            "signed": bool(sess_rec.signature_value),
        })
    except Exception as exc:
        log.warning("seal_live_logs_today session_archive error: %s", exc)

    # 2. Build & sign Firewall Traffic Archive
    try:
        fw_rec = await build_raw_log_archive(
            db, customer_id=cid, record_type="raw_traffic", period_start=today_start, period_end=today_end
        )
        results.append({
            "type": "raw_traffic",
            "id": str(fw_rec.id),
            "seq": fw_rec.chain_seq,
            "count": fw_rec.item_count,
            "signed": bool(fw_rec.signature_value),
        })
    except Exception as exc:
        log.warning("seal_live_logs_today raw_traffic error: %s", exc)

    return results


# ---- scoped admin views -----------------------------------------------------
async def _scoped_query(db: AsyncSession, scope: ScopeContext):
    q = select(ArchiveRecord)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = q.join(Customer, ArchiveRecord.customer_id == Customer.id)
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(ArchiveRecord.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        loc = (
            await db.execute(select(Location).where(Location.id == scope.location_id))
        ).scalar_one_or_none()
        if not loc:
            return q.where(false()), False
        return q.where(ArchiveRecord.customer_id == loc.customer_id), True
    return q.where(false()), False


async def list_archives(
    db: AsyncSession, scope: ScopeContext, record_type: str | None = None
) -> list[dict]:
    q, allowed = await _scoped_query(db, scope)
    if not allowed:
        return []
    if record_type:
        q = q.where(ArchiveRecord.record_type == record_type)
    
    q = q.add_columns(Customer.name.label("customer_name"))
    if scope.level != TenantLevel.PARTNER:
        q = q.join(Customer, ArchiveRecord.customer_id == Customer.id)

    res = await db.execute(q.order_by(ArchiveRecord.created_at.desc()))
    out = []
    for row in res.all():
        rec = row[0]
        name = row[1]
        out.append({
            "id": rec.id,
            "customer_id": rec.customer_id,
            "customer_name": name,
            "location_id": rec.location_id,
            "period_start": rec.period_start,
            "period_end": rec.period_end,
            "record_type": rec.record_type,
            "chain_seq": rec.chain_seq,
            "item_count": rec.item_count,
            "content_hash": rec.content_hash,
            "content_ref": rec.content_ref,
            "content_size": rec.content_size,
            "prev_hash": rec.prev_hash,
            "curr_hash": rec.curr_hash,
            "created_at": rec.created_at,
            "signature_value": rec.signature_value,
            "signature_time": rec.signature_time,
            "certificate_serial": rec.certificate_serial,
            "sign_method": rec.sign_method,
            "signature_origin": (rec.meta or {}).get("signature_origin"),
            "status": rec.status,
            "error_message": rec.error_message,
            "storage_verified": rec.storage_verified,
            "signature_valid": rec.signature_valid,
        })
    return out


async def get_archive(
    db: AsyncSession, record_id: uuid.UUID, scope: ScopeContext
) -> dict:
    q, allowed = await _scoped_query(db, scope)
    q = q.where(ArchiveRecord.id == record_id).add_columns(Customer.name.label("customer_name"))
    if scope.level != TenantLevel.PARTNER:
        q = q.join(Customer, ArchiveRecord.customer_id == Customer.id)
    res = await db.execute(q)
    row = res.one_or_none()
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Arsiv kaydi bulunamadi"
        )
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu arsive erisim yetkiniz yok",
        )
    rec = row[0]
    name = row[1]
    return {
        "id": rec.id,
        "customer_id": rec.customer_id,
        "customer_name": name,
        "location_id": rec.location_id,
        "period_start": rec.period_start,
        "period_end": rec.period_end,
        "record_type": rec.record_type,
        "chain_seq": rec.chain_seq,
        "item_count": rec.item_count,
        "content_hash": rec.content_hash,
        "content_ref": rec.content_ref,
        "content_size": rec.content_size,
        "prev_hash": rec.prev_hash,
        "curr_hash": rec.curr_hash,
        "created_at": rec.created_at,
        "signature_value": rec.signature_value,
        "signature_time": rec.signature_time,
        "certificate_serial": rec.certificate_serial,
        "sign_method": rec.sign_method,
        "signature_origin": (rec.meta or {}).get("signature_origin"),
        "status": rec.status,
        "error_message": rec.error_message,
        "storage_verified": rec.storage_verified,
        "signature_valid": rec.signature_valid,
    }


# ---- chain verification (tamper-evidence) -----------------------------------
async def verify_chain(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    record_type: str = RECORD_SESSION_ARCHIVE,
) -> ArchiveVerifyResult:
    """Re-walk the chain for (customer, record_type). Detects any row whose
    stored curr_hash does not match the recomputed value, or whose prev_hash
    linkage is broken. No object-store fetch — this validates the ledger."""
    res = await db.execute(
        select(ArchiveRecord)
        .where(
            ArchiveRecord.customer_id == customer_id,
            ArchiveRecord.record_type == record_type,
        )
        .order_by(ArchiveRecord.chain_seq.asc())
    )
    records = list(res.scalars().all())
    if not records:
        return ArchiveVerifyResult(
            customer_id=customer_id,
            record_type=record_type,
            ok=True,
            checked=0,
            message="Zincir bos (kayit yok).",
        )

    expected_prev = GENESIS_HASH
    for rec in records:
        if rec.prev_hash != expected_prev:
            return ArchiveVerifyResult(
                customer_id=customer_id,
                record_type=record_type,
                ok=False,
                checked=rec.chain_seq,
                broken_seq=rec.chain_seq,
                broken_id=rec.id,
                message=f"prev_hash kopuklugu seq={rec.chain_seq} (ekleme/silme sansi)",
            )
        recomputed = _chain_hash(
            rec.prev_hash, rec.content_hash, _period_key(rec.period_start, rec.period_end), rec.record_type
        )
        if recomputed != rec.curr_hash:
            return ArchiveVerifyResult(
                customer_id=customer_id,
                record_type=record_type,
                ok=False,
                checked=rec.chain_seq,
                broken_seq=rec.chain_seq,
                broken_id=rec.id,
                message=f"curr_hash uyusmazligi seq={rec.chain_seq} (degistirilmis satir)",
            )
        expected_prev = rec.curr_hash

    return ArchiveVerifyResult(
        customer_id=customer_id,
        record_type=record_type,
        ok=True,
        checked=len(records),
        message=f"Zincir saglam ({len(records)} kayit dogrulandi).",
    )
