"""Transaction-local PostgreSQL row-level security context helpers.

The application still applies explicit scope predicates for portability and
query clarity.  These helpers set the same ``app.*`` settings used by the
database policies.  ``set_config(..., true)`` makes the values local to the
current transaction, so pooled connections cannot retain a previous tenant
after commit or rollback.
"""
from __future__ import annotations

import uuid

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


def _uuid_text(value: uuid.UUID | str | None, *, field: str) -> str:
    if value is None or value == "":
        return ""
    try:
        return str(uuid.UUID(str(value)))
    except (TypeError, ValueError, AttributeError) as exc:
        raise ValueError(f"invalid {field} for RLS context") from exc


async def set_rls_context(
    db: AsyncSession,
    *,
    tenant_id: uuid.UUID | str | None = None,
    customer_id: uuid.UUID | str | None = None,
    partner_id: uuid.UUID | str | None = None,
    location_id: uuid.UUID | str | None = None,
    is_super_admin: bool = False,
    require_tenant: bool = False,
) -> None:
    """Set a transaction-local scope for PostgreSQL RLS policies.

    ``require_tenant`` is used by tenant-bound legacy ingest/worker paths.  A
    missing or malformed tenant is rejected before any write/query can occur.
    Non-PostgreSQL sessions and lightweight test doubles are intentionally
    untouched; their application-level scope predicates remain authoritative.
    """
    tenant_value = _uuid_text(tenant_id, field="tenant_id")
    if require_tenant and not tenant_value:
        raise ValueError("tenant context is required")
    customer_value = _uuid_text(customer_id, field="customer_id")
    partner_value = _uuid_text(partner_id, field="partner_id")
    location_value = _uuid_text(location_id, field="location_id")

    if not isinstance(db, AsyncSession):
        return
    try:
        bind = db.get_bind()
        if getattr(getattr(bind, "dialect", None), "name", None) != "postgresql":
            return
    except Exception as exc:
        # A strict tenant-bound path must never continue after failing to
        # inspect its real session.  Lightweight doubles are filtered above.
        if require_tenant:
            raise RuntimeError("unable to establish PostgreSQL RLS context") from exc
        return

    values = {
        "is_super_admin": "true" if is_super_admin else "false",
        "tenant_id": tenant_value,
        "customer_id": customer_value,
        "partner_id": partner_value,
        "location_id": location_value,
    }
    for setting in ("is_super_admin", "tenant_id", "customer_id", "partner_id", "location_id"):
        await db.execute(
            text(f"select set_config('app.{setting}', :value, true)"),
            {"value": values[setting]},
        )


async def set_syslog_context(
    db: AsyncSession,
    tenant_id: uuid.UUID | str | None,
    *,
    is_super_admin: bool = False,
) -> None:
    """Set the strict tenant context required for legacy ``syslog_records``."""
    await set_rls_context(
        db,
        tenant_id=tenant_id,
        is_super_admin=is_super_admin,
        require_tenant=True,
    )
