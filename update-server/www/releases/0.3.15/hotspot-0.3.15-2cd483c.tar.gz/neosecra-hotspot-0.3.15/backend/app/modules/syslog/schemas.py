from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional
import uuid


class SyslogRecordBase(BaseModel):
    facility: Optional[int] = None
    severity: Optional[int] = None
    hostname: Optional[str] = None
    app_name: Optional[str] = None
    message: str


class SyslogRecordCreate(SyslogRecordBase):
    tenant_id: Optional[uuid.UUID] = None


class SyslogRecordOut(SyslogRecordBase):
    id: uuid.UUID
    tenant_id: Optional[uuid.UUID] = None
    tenant_resolution_status: str = "resolved"
    tenant_resolution_reason: Optional[str] = None
    tenant_resolution_candidates: list[str] = Field(default_factory=list)
    tenant_resolution_source: str = "api_ingest"
    created_at: datetime

    model_config = {"from_attributes": True}
