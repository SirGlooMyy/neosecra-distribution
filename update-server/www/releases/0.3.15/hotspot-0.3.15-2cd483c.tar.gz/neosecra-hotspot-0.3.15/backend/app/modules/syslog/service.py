"""Syslog service — dual-write to PostgreSQL (katalog) + ClickHouse (sıcak veri).

ClickHouse bağlantısı yoksa sessizce PostgreSQL'e yazmaya devam eder
(arka uyumlu). ClickHouse varsa tüm syslog kayıtları otomatik olarak
oraya da yazılır — dashboard sorguları ve arama API'si ClickHouse'u öncelikli kullanır.
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters import clickhouse as ch
from app.core.config import settings
from app.core.rls import set_syslog_context
from app.modules.syslog.parsers import parse_firewall_syslog
from app.modules.syslog.models import FirewallLog, SyslogRecord
from app.modules.syslog.rfc5424 import parse_rfc5424
from app.modules.syslog.repository import (
    insert_firewall_log,
    resolve_firewall_log_context,
)
from app.modules.syslog.trigger_service import fire_triggers

log = logging.getLogger(__name__)


def _session_uuid(value: str | None) -> str:
    """Return a stable UUID for ClickHouse's UUID session column."""
    if not value:
        return "00000000-0000-0000-0000-000000000000"
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, AttributeError, TypeError):
        return str(uuid.uuid5(uuid.NAMESPACE_URL, f"hotspot:session:{value}"))


def _record_tenant_id(record: SyslogRecord) -> uuid.UUID:
    """Return a resolved tenant or fail closed for quarantined legacy rows."""
    tenant_id = getattr(record, "tenant_id", None)
    status = getattr(record, "tenant_resolution_status", None) or "resolved"
    if tenant_id is None or status != "resolved":
        raise ValueError("legacy syslog record has no resolved tenant")
    try:
        return uuid.UUID(str(tenant_id))
    except (TypeError, ValueError, AttributeError) as exc:
        raise ValueError("legacy syslog record has an invalid tenant") from exc


async def process_syslog_record(db: AsyncSession, record: SyslogRecord) -> None:
    """After saving a syslog record:
    1. Evaluate triggers (fire-and-forget)
    2. Write to ClickHouse (sıcak veri, best-effort)
    """
    tenant_id = _record_tenant_id(record)
    await set_syslog_context(db, tenant_id)
    try:
        events = await fire_triggers(db, record)
        if events:
            log.info("Syslog record %s tetikledi %d trigger", record.id, len(events))
    except Exception as exc:
        # A failed flush/commit leaves the session unusable until its
        # transaction is rolled back.  Clear it before the caller can reuse
        # the pooled session for another tenant-bound operation.
        await db.rollback()
        log.exception("Trigger degerlendirme basarisiz record=%s: %s", record.id, exc)

    # ClickHouse dual-write (best-effort, asenkron)
    try:
        if not settings.CLICKHOUSE_ENABLED:
            return
        await ch.insert_syslog_batch([_to_ch_record(record)])
    except Exception as exc:
        log.debug("ClickHouse write skipped (CH may be offline): %s", exc)


async def process_syslog_batch(db: AsyncSession, records: list[SyslogRecord]) -> None:
    """Batch process syslog records: triggers + ClickHouse dual-write."""
    if not records:
        return
    tenant_ids = {_record_tenant_id(record) for record in records}
    if len(tenant_ids) != 1:
        raise ValueError("legacy syslog batch must contain one tenant")
    tenant_id = next(iter(tenant_ids))
    for record in records:
        try:
            # ``fire_triggers`` commits each record, so its transaction-local
            # GUCs are reset after every iteration. Re-apply the tenant before
            # each query rather than allowing the second record to run with a
            # pooled connection's empty context.
            await set_syslog_context(db, tenant_id)
            await fire_triggers(db, record)
        except Exception as exc:
            # ``fire_triggers`` may fail after opening an aborted transaction;
            # rollback before the next iteration so its context can be set
            # again on the pooled connection.
            await db.rollback()
            log.exception("Trigger error record=%s: %s", record.id, exc)

    try:
        if not settings.CLICKHOUSE_ENABLED:
            return
        ch_records = [_to_ch_record(r) for r in records]
        await ch.insert_syslog_batch(ch_records)
    except Exception as exc:
        log.debug("ClickHouse batch write skipped: %s", exc)


async def process_firewall_log_batch(
    db: AsyncSession, records: list[FirewallLog]
) -> None:
    """Post-process records already persisted by the TCP listener.

    The listener performs the batch insert itself; calling
    ``process_firewall_log`` here would parse an ORM object as a raw string and
    insert every event a second time.  Keep this hook side-effect-safe and only
    perform the best-effort ClickHouse dual-write.
    """
    if not records:
        return
    try:
        if not settings.CLICKHOUSE_ENABLED:
            return
        await ch.insert_syslog_batch([_to_ch_firewall_log(r) for r in records])
    except Exception as exc:
        log.debug("ClickHouse firewall batch write skipped: %s", exc)


def _to_ch_record(record: SyslogRecord) -> dict:
    """Convert a SyslogRecord to ClickHouse-compatible dict."""
    tenant_id = _record_tenant_id(record)
    return {
        "timestamp": record.created_at or datetime.now(timezone.utc),
        "customer_id": str(tenant_id),
        "location_id": "",
        "device_id": "",
        "facility": record.facility or "unknown",
        "severity": _severity_int(str(record.severity or "")),
        "hostname": record.hostname or "",
        "app_name": record.app_name or "",
        "source_ip": "::",
        "dest_ip": "::",
        "mac": "",
        "username": "",
        "domain": "",
        "application": "",
        "action": "",
        "message": record.message or "",
        "raw": "",
        "session_id": "00000000-0000-0000-0000-000000000000",
    }


def _severity_int(severity: str | None) -> int:
    mapping = {
        "emergency": 0, "alert": 1, "critical": 2, "error": 3,
        "warning": 4, "notice": 5, "info": 6, "debug": 7,
    }
    return mapping.get(severity.lower() if severity else "", 5)


async def process_firewall_log(
    db: AsyncSession,
    raw: str,
    hostname: str | None = None,
    *,
    resolve_tenant: bool = True,
) -> FirewallLog | None:
    """Process a raw syslog line into a FirewallLog.

    Steps:
    1. Parse RFC 5424 (for hostname)
    2. Parse FortiGate key=value fields
    3. Resolve tenant/customer from hostname
    4. Build and insert FirewallLog
    5. ClickHouse dual-write (best-effort)

    Returns the inserted FirewallLog, or None on failure.
    """
    try:
        # Parse RFC 5424 for hostname if not provided
        if not hostname:
            rfc = parse_rfc5424(raw)
            hostname = rfc.get("hostname") if rfc else None

        # Parse FortiGate key=value
        fg = parse_firewall_syslog(raw)

        # Resolve tenant/customer from hostname
        tenant_id = None
        customer_id = None
        device_id = None
        if resolve_tenant and (
            hostname or fg.get("device_id") or settings.SINGLE_TENANT_MODE
        ):
            resolved_context = await resolve_firewall_log_context(
                db,
                hostname,
                fg.get("device_id"),
            )
            if resolved_context:
                tenant_id, customer_id, device_id = resolved_context

        # Build event_time from date= + time=
        event_time = None
        pf = fg.get("parsed_fields", {})
        date_str = pf.get("date")
        time_str = pf.get("time")
        if date_str and time_str:
            try:
                naive = datetime.strptime(
                    f"{date_str} {time_str}", "%Y-%m-%d %H:%M:%S"
                )
                tz_raw = str(pf.get("tz") or pf.get("timezone") or "").strip()
                if tz_raw and len(tz_raw) == 5 and tz_raw[0] in "+-" and tz_raw[1:].isdigit():
                    sign = 1 if tz_raw[0] == "+" else -1
                    minutes = int(tz_raw[1:3]) * 60 + int(tz_raw[3:5])
                    event_time = naive.replace(
                        tzinfo=timezone(sign * timedelta(minutes=minutes))
                    ).astimezone(timezone.utc)
                else:
                    event_time = naive.replace(tzinfo=timezone.utc)
            except ValueError:
                pass

        log_entry = FirewallLog(
            tenant_id=tenant_id or fg.get("tenant_id"),
            customer_id=customer_id or fg.get("customer_id"),
            device_id=device_id,
            received_at=datetime.now(timezone.utc),
            event_time=event_time,
            vendor=fg.get("vendor", "fortigate"),
            log_type=fg.get("log_type", "unknown"),
            log_subtype=fg.get("log_subtype"),
            severity=fg.get("severity", "info"),
            action=fg.get("action"),
            src_ip=fg.get("src_ip"),
            dst_ip=fg.get("dst_ip"),
            src_port=fg.get("src_port"),
            dst_port=fg.get("dst_port"),
            proto=fg.get("proto"),
            service=fg.get("service"),
            user=fg.get("user"),
            policyid=fg.get("policyid"),
            duration=fg.get("duration"),
            sentbyte=fg.get("sentbyte"),
            rcvdbyte=fg.get("rcvdbyte"),
            session_id=fg.get("session_id"),
            raw_syslog=raw,
            parsed_fields=pf,
        )

        await insert_firewall_log(db, log_entry)
        await db.commit()

        # ClickHouse dual-write (best-effort)
        try:
            if not settings.CLICKHOUSE_ENABLED:
                return log_entry
            await ch.insert_syslog_batch([_to_ch_firewall_log(log_entry)])
        except Exception as exc:
            log.debug("ClickHouse firewall log write skipped: %s", exc)

        return log_entry

    except Exception:
        log.exception("Failed to process firewall log")
        return None


def _to_ch_firewall_log(log_entry: FirewallLog) -> dict:
    """Convert a FirewallLog to ClickHouse-compatible dict."""
    zero_uuid = "00000000-0000-0000-0000-000000000000"
    parsed = log_entry.parsed_fields or {}
    raw_str = log_entry.raw_syslog or ""
    return {
        "timestamp": log_entry.event_time or log_entry.received_at or datetime.now(timezone.utc),
        "customer_id": str(log_entry.customer_id or zero_uuid),
        # ClickHouse columns are UUIDs; empty strings make every dual-write
        # fail for records without an optional location/device relation.
        "location_id": zero_uuid,
        "device_id": str(log_entry.device_id or zero_uuid),
        "facility": log_entry.vendor or "unknown",
        "severity": _severity_int(log_entry.severity),
        "hostname": str(parsed.get("devname") or "fortigate-fw"),
        "app_name": log_entry.log_type or "traffic",
        "source_ip": log_entry.src_ip or "::",
        "dest_ip": log_entry.dst_ip or "::",
        "mac": str(parsed.get("mac") or parsed.get("srcmac") or ""),
        "username": log_entry.user or str(parsed.get("user") or ""),
        "domain": str(parsed.get("domain") or ""),
        "application": log_entry.service or str(parsed.get("app") or parsed.get("service") or ""),
        "action": log_entry.action or "",
        "message": raw_str,
        "raw": raw_str,
        "session_id": _session_uuid(log_entry.session_id) if hasattr(log_entry, "session_id") else zero_uuid,
    }
