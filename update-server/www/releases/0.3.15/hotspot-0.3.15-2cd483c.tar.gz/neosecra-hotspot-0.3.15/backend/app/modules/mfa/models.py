import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


class MfaToken(Base, UUIDPK, TimestampMixin):
    __tablename__ = "mfa_tokens"

    user_id: Mapped[uuid.UUID] = fk("users", ondelete="CASCADE")
    mfa_type: Mapped[str] = mapped_column(String(20), nullable=False)
    secret_encrypted: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    backup_codes_encrypted: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class MfaSession(Base, UUIDPK, TimestampMixin):
    __tablename__ = "mfa_sessions"

    user_id: Mapped[uuid.UUID] = fk("users", ondelete="CASCADE")
    session_token: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    mfa_type: Mapped[str] = mapped_column(String(20), nullable=False)
    # OTP challenges must carry the verifier-side hash.  Keeping this on the
    # challenge (rather than in an audit log) makes verification one-time and
    # independent from log retention/cleanup jobs.
    code_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class MfaLog(Base, UUIDPK, TimestampMixin):
    __tablename__ = "mfa_logs"

    user_id: Mapped[uuid.UUID] = fk("users", ondelete="CASCADE")
    action: Mapped[str] = mapped_column(String(30), nullable=False)
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)
    details: Mapped[dict | None] = mapped_column(JSONB, nullable=True, default={})


MFA_ACTION_ENABLED = "enabled"
MFA_ACTION_DISABLED = "disabled"
MFA_ACTION_VERIFIED = "verified"
MFA_ACTION_FAILED = "failed"
MFA_ACTION_BACKUP_USED = "backup_used"


# --- RDP MFA ---
class RdpMfaConfig(Base, UUIDPK, TimestampMixin):
    __tablename__ = "rdp_mfa_config"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    gateway_host: Mapped[str | None] = mapped_column(String(255), nullable=True)
    gateway_port: Mapped[int] = mapped_column(Integer, default=1812, nullable=False)
    allowed_groups: Mapped[dict | None] = mapped_column(JSONB, nullable=True, default=[])
    mfa_method: Mapped[str] = mapped_column(String(20), default="sms", nullable=False)


# --- VPN MFA ---
class VpnMfaConfig(Base, UUIDPK, TimestampMixin):
    __tablename__ = "vpn_mfa_config"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    gateway_host: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # FreeRADIUS authentication listener; the FortiGate VPN gateway keeps its
    # own SSL-VPN/IPsec port and is not configured here.
    gateway_port: Mapped[int] = mapped_column(Integer, default=1812, nullable=False)
    # FortiGate -> FreeRADIUS client settings.  The shared secret is encrypted
    # at rest and is never included in the normal GET response.
    radius_nas_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    radius_accounting_port: Mapped[int] = mapped_column(Integer, default=1813, nullable=False)
    radius_shared_secret_encrypted: Mapped[str | None] = mapped_column(String(2000), nullable=True)
    radius_secret_updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    allowed_groups: Mapped[dict | None] = mapped_column(JSONB, nullable=True, default=[])
    mfa_method: Mapped[str] = mapped_column(String(20), default="totp", nullable=False)
    sms_template: Mapped[str | None] = mapped_column(
        String(500), nullable=True, default="VPN giriş doğrulama kodunuz: {code}"
    )


# --- VPN MFA per-user registration ---
class VpnMfaUser(Base, UUIDPK, TimestampMixin):
    """VPN kullanicisi MFA kaydi — TOTP secret, SMS telefon, Email."""
    __tablename__ = "vpn_mfa_users"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    username: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    mfa_method: Mapped[str] = mapped_column(String(100), nullable=False)
    secret_encrypted: Mapped[str | None] = mapped_column(String(512), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(64), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


# --- Portal MFA ---
class PortalMfaConfig(Base, UUIDPK, TimestampMixin):
    __tablename__ = "portal_mfa_config"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="CASCADE", nullable=True)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    mfa_method: Mapped[str] = mapped_column(String(20), default="sms", nullable=False)
    require_mfa_after: Mapped[str | None] = mapped_column(String(30), nullable=True)
