"""Report Scheduler — job CRUD, generation, email delivery.
"""
from __future__ import annotations

import hashlib
import io
import logging
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.reports.models import ReportArchive, ReportJob, ReportJobStatusHistory
from app.modules.reports.envelope import build_report_envelope
from app.modules.reports.pdf_service import render_report_to_pdf
from app.modules.reports import service as reports_service
from app.modules.sessions.models import GuestSession
from app.modules.syslog.models import SyslogRecord
from app.modules.customers.models import Customer
from app.core.rls import set_syslog_context
from app.core.tenant import ScopeContext, TenantLevel

log = logging.getLogger(__name__)

REPORT_TYPES = ("daily", "weekly", "monthly", "custom")
FORMATS = ("pdf", "csv", "xlsx")
REPORT_STATUS_HISTORY = ("queued", "running", "retry", "succeeded", "failed")


async def record_job_status(
    db: AsyncSession,
    job: ReportJob,
    status: str,
    *,
    attempt: int = 1,
    idempotency_key: str | None = None,
    error_message: str | None = None,
    details: dict | None = None,
) -> ReportJobStatusHistory:
    """Append a durable status transition; rows are never updated/deleted."""
    if status not in REPORT_STATUS_HISTORY:
        raise ValueError(f"unsupported report status: {status}")
    history = ReportJobStatusHistory(
        job_id=job.id,
        customer_id=job.customer_id,
        status=status,
        attempt=attempt,
        idempotency_key=idempotency_key,
        error_message=error_message,
        details=details or {},
    )
    db.add(history)
    await db.flush()
    return history


async def create_job(db: AsyncSession, data: dict) -> ReportJob:
    if data.get("report_type") not in REPORT_TYPES:
        raise HTTPException(status_code=400, detail=f"report_type {data['report_type']} gecersiz. Secenekler: {', '.join(REPORT_TYPES)}")
    if data.get("format") not in FORMATS:
        raise HTTPException(status_code=400, detail=f"format {data['format']} gecersiz. Secenekler: {', '.join(FORMATS)}")
    template_id = data.get("template_id")
    if template_id in ("", None):
        data["template_id"] = None
    elif template_id not in {**reports_service.QUICK_REPORTS, **reports_service.DIFFERENTIATOR_REPORTS}:
        raise HTTPException(status_code=400, detail="Desteklenmeyen rapor şablonu")
    if data.get("trigger"):
        data["next_run_at"] = _calculate_next_run(data["trigger"])
    job = ReportJob(**data)
    db.add(job)
    await db.commit()
    await db.refresh(job)
    return job


async def update_job(db: AsyncSession, job_id: uuid.UUID, data: dict) -> ReportJob:
    job = await db.get(ReportJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Rapor jobi bulunamadi")
    if "trigger" in data and data["trigger"]:
        data["next_run_at"] = _calculate_next_run(data["trigger"])
    if "template_id" in data:
        if data["template_id"] in ("", None):
            data["template_id"] = None
        elif data["template_id"] not in {**reports_service.QUICK_REPORTS, **reports_service.DIFFERENTIATOR_REPORTS}:
            raise HTTPException(status_code=400, detail="Desteklenmeyen rapor şablonu")
    for k, v in data.items():
        setattr(job, k, v)
    await db.commit()
    await db.refresh(job)
    return job


async def delete_job(db: AsyncSession, job_id: uuid.UUID) -> None:
    job = await db.get(ReportJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Rapor jobi bulunamadi")
    await db.delete(job)
    await db.commit()


async def list_jobs(
    db: AsyncSession, customer_id: uuid.UUID | None = None
) -> list[ReportJob]:
    q = select(ReportJob)
    if customer_id:
        q = q.where(ReportJob.customer_id == customer_id)
    q = q.order_by(ReportJob.created_at.desc())
    res = await db.execute(q)
    return list(res.scalars().all())


async def get_job(db: AsyncSession, job_id: uuid.UUID) -> ReportJob:
    job = await db.get(ReportJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Rapor jobi bulunamadi")
    return job


def _calculate_next_run(cron_expression: str) -> datetime:
    """Parse a simple cron expression and return next run time.
    Supports: 'daily', 'weekly', 'monthly', '*/N * * * *' style."""
    now = datetime.now(timezone.utc)
    expr = cron_expression.strip().lower()

    if expr == "daily":
        return (now + timedelta(days=1)).replace(hour=2, minute=0, second=0, microsecond=0)
    if expr == "weekly":
        return (now + timedelta(weeks=1)).replace(hour=2, minute=0, second=0, microsecond=0)
    if expr == "monthly":
        next_month = now.month % 12 + 1
        year = now.year + (1 if next_month == 1 else 0)
        return datetime(year, next_month, 1, 2, 0, 0, tzinfo=timezone.utc)
    if expr == "hourly":
        return (now + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)

    parts = expr.split()
    if len(parts) == 5:
        minute_part, hour_part, _, _, _ = parts
        try:
            next_run = now.replace(second=0, microsecond=0) + timedelta(hours=1)
            if minute_part != "*":
                minutes = [int(m) for m in minute_part.split(",")]
                if minutes:
                    if now.minute >= max(minutes):
                        next_run = next_run.replace(minute=minutes[0])
                    else:
                        next_run = next_run.replace(minute=min(m for m in minutes if m > now.minute))
            if hour_part != "*":
                hours = [int(h) for h in hour_part.split(",")]
                if hours:
                    if next_run.hour > max(hours):
                        next_run += timedelta(days=1)
                        next_run = next_run.replace(hour=hours[0], minute=0)
                    elif next_run.hour < min(hours):
                        next_run = next_run.replace(hour=hours[0], minute=0)
            return next_run
        except (ValueError, IndexError):
            pass

    return now + timedelta(hours=1)


async def generate_report(
    db: AsyncSession,
    job_id: uuid.UUID,
    *,
    idempotency_key: str | None = None,
    attempt: int = 1,
) -> ReportArchive:
    job = await get_job(db, job_id)
    now = datetime.now(timezone.utc)

    if job.report_type == "daily":
        period_start = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        period_end = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif job.report_type == "weekly":
        period_start = (now - timedelta(weeks=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        period_end = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif job.report_type == "monthly":
        period_start = (now - timedelta(days=30)).replace(hour=0, minute=0, second=0, microsecond=0)
        period_end = now.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        period_start = job.last_run_at or (now - timedelta(days=1))
        period_end = now
        if hasattr(job, "custom_period_start"):
            period_start = getattr(job, "custom_period_start")  # type: ignore[attr-defined]
        if hasattr(job, "custom_period_end"):
            period_end = getattr(job, "custom_period_end")  # type: ignore[attr-defined]
        period_start = period_start.replace(tzinfo=timezone.utc) if period_start.tzinfo is None else period_start
        period_end = period_end.replace(tzinfo=timezone.utc) if period_end.tzinfo is None else period_end

    # # A retry with the same key must not create a second success artifact.
    if idempotency_key:
        existing_res = await db.execute(
            select(ReportArchive)
            .where(
                ReportArchive.job_id == job.id,
                ReportArchive.idempotency_key == idempotency_key,
                ReportArchive.status == "ready",
            )
            .order_by(ReportArchive.created_at.desc())
            .limit(1)
        )
        existing = existing_res.scalar_one_or_none()
        if existing is not None:
            return existing

    if attempt > 1:
        await record_job_status(db, job, "retry", attempt=attempt, idempotency_key=idempotency_key)
    await record_job_status(db, job, "queued", attempt=attempt, idempotency_key=idempotency_key)
    await record_job_status(db, job, "running", attempt=attempt, idempotency_key=idempotency_key)
    # Commit lifecycle markers before doing rendering/storage work so a worker
    # crash cannot erase the fact that the attempt started.
    await db.commit()

    tenant_id = None
    try:
        customer = await db.get(Customer, job.customer_id)
        tenant_id = getattr(customer, "tenant_id", None) if customer else None
    except Exception:
        tenant_id = None

    provenance = {
        "sources": ["guest_sessions", "syslog_records"],
        "status": "verified" if tenant_id is not None else "partial",
        "tenant_resolution": "customer.tenant_id" if tenant_id is not None else "unavailable",
    }

    async def _failed(error: Exception | str) -> ReportArchive:
        message = str(error)
        archive = ReportArchive(
            job_id=job.id,
            customer_id=job.customer_id,
            tenant_id=tenant_id,
            period_start=period_start,
            period_end=period_end,
            generated_at=now,
            format=job.format,
            file_size=0,
            file_ref="",
            content_hash="",
            status="failed",
            error_message=message,
            schema_version="1.0",
            provenance={**provenance, "error": message},
            envelope={},
            sha256_hash="",
            idempotency_key=idempotency_key,
        )
        db.add(archive)
        await record_job_status(db, job, "failed", attempt=attempt, idempotency_key=idempotency_key, error_message=message)
        await db.commit()
        await db.refresh(archive)
        return archive

    if tenant_id is None:
        return await _failed("tenant provenance unavailable")

    # A template_id points at a concrete Analyzer preset.  Legacy jobs have no
    # template_id and retain the original session/syslog summary behaviour.
    try:
        if job.template_id in reports_service.QUICK_REPORTS:
            # The built-in presets are explicitly 30-day Analyzer views. Their
            # cadence controls delivery time, not the analytical window.
            period_start = period_end - timedelta(days=30)
            report_data = await reports_service.build_quick_report(
                db,
                ScopeContext(level=TenantLevel.CUSTOMER, customer_id=job.customer_id),
                job.template_id,
                date_from=period_start,
                date_to=period_end,
            )
        elif job.template_id in reports_service.DIFFERENTIATOR_REPORTS:
            report_data = {
                "title": reports_service.DIFFERENTIATOR_REPORTS[job.template_id],
                "period_start": period_start,
                "period_end": period_end,
                "generated_at": now,
            }
        else:
            report_data = await _build_report_data(db, job.customer_id, period_start, period_end)
    except Exception as exc:
        return await _failed(exc)

    envelope_data = {
        "report_type": job.template_id or job.report_type,
        "format": job.format,
        "summary": report_data,
    }

    if job.format == "pdf":
        try:
            if job.template_id in reports_service.QUICK_REPORTS:
                pdf_bytes = reports_service.build_quick_pdf(report_data)
            elif job.template_id in reports_service.DIFFERENTIATOR_REPORTS:
                pdf_bytes = await reports_service.build_differentiator_pdf(
                    db,
                    ScopeContext(level=TenantLevel.CUSTOMER, customer_id=job.customer_id),
                    job.template_id,
                    date_from=period_start,
                    date_to=period_end,
                )
            else:
                pdf_bytes = render_report_to_pdf(report_data, "session_report")
        except Exception as exc:
            return await _failed(exc)

        content_hash = hashlib.sha256(pdf_bytes).hexdigest()
        try:
            file_ref = await _store_report(pdf_bytes, job, content_hash)
        except Exception as exc:
            return await _failed(exc)

        report_id = uuid.uuid4()
        envelope = build_report_envelope(
            report_id=report_id,
            module="hotspot",
            tenant_id=tenant_id,
            customer_id=job.customer_id,
            generated_at=now,
            reporting_period={"start": period_start.isoformat(), "end": period_end.isoformat()},
            data=envelope_data,
            provenance=provenance,
        )

        archive = ReportArchive(
            id=report_id,
            job_id=job.id,
            customer_id=job.customer_id,
            tenant_id=tenant_id,
            period_start=period_start,
            period_end=period_end,
            generated_at=now,
            format=job.format,
            file_size=len(pdf_bytes),
            file_ref=file_ref,
            content_hash=content_hash,
            status="ready",
            schema_version="1.0",
            provenance=provenance,
            envelope=envelope,
            sha256_hash=envelope["sha256_hash"],
            idempotency_key=idempotency_key,
        )
    elif job.format == "csv":
        if job.template_id in reports_service.QUICK_REPORTS:
            csv_text = reports_service.build_quick_csv(report_data)
        elif job.template_id in reports_service.DIFFERENTIATOR_REPORTS:
            csv_text = await reports_service.build_differentiator_csv(
                db,
                ScopeContext(level=TenantLevel.CUSTOMER, customer_id=job.customer_id),
                job.template_id,
                date_from=period_start,
                date_to=period_end,
            )
        else:
            csv_text = _build_csv(report_data)
        csv_bytes = csv_text.encode("utf-8-sig")
        content_hash = hashlib.sha256(csv_bytes).hexdigest()
        try:
            file_ref = await _store_report(csv_bytes, job, content_hash)
        except Exception as exc:
            return await _failed(exc)
        report_id = uuid.uuid4()
        envelope = build_report_envelope(
            report_id=report_id,
            module="hotspot",
            tenant_id=tenant_id,
            customer_id=job.customer_id,
            generated_at=now,
            reporting_period={"start": period_start.isoformat(), "end": period_end.isoformat()},
            data=envelope_data,
            provenance=provenance,
        )
        archive = ReportArchive(
            id=report_id,
            job_id=job.id,
            customer_id=job.customer_id,
            tenant_id=tenant_id,
            period_start=period_start,
            period_end=period_end,
            generated_at=now,
            format=job.format,
            file_size=len(csv_bytes),
            file_ref=file_ref,
            content_hash=content_hash,
            status="ready",
            schema_version="1.0",
            provenance=provenance,
            envelope=envelope,
            sha256_hash=envelope["sha256_hash"],
            idempotency_key=idempotency_key,
        )
    else:
        raise HTTPException(status_code=400, detail=f"Desteklenmeyen format: {job.format}")

    db.add(archive)
    job.last_run_at = now
    job.next_run_at = _calculate_next_run(job.trigger)
    db.add(job)
    await record_job_status(
        db, job, "succeeded", attempt=attempt, idempotency_key=idempotency_key,
        details={"archive_id": str(archive.id), "sha256_hash": archive.sha256_hash},
    )
    await db.commit()
    await db.refresh(archive)
    return archive


async def _build_report_data(
    db: AsyncSession, customer_id: uuid.UUID, period_start: datetime, period_end: datetime
) -> dict:
    res = await db.execute(
        select(GuestSession).where(
            GuestSession.customer_id == customer_id,
            GuestSession.started_at >= period_start,
            GuestSession.started_at < period_end,
        )
    )
    sessions = list(res.scalars().all())

    customer = await db.get(Customer, customer_id)
    tenant_id = getattr(customer, "tenant_id", None) if customer else None
    # SyslogRecord is tenant-bound (not customer-bound).  A missing customer
    # mapping is insufficient evidence and therefore yields no syslog rows.
    if tenant_id is not None:
        await set_syslog_context(db, tenant_id)
    syslog_filters = [
        SyslogRecord.created_at >= period_start,
        SyslogRecord.created_at < period_end,
        SyslogRecord.tenant_id == tenant_id if tenant_id is not None else False,
    ]
    syslog_res = await db.execute(select(SyslogRecord).where(*syslog_filters))
    syslog_records = list(syslog_res.scalars().all())

    by_status: dict[str, int] = {}
    by_method: dict[str, int] = {}
    bytes_total = 0
    durations = []
    for s in sessions:
        by_status[s.status] = by_status.get(s.status, 0) + 1
        by_method[s.auth_method] = by_method.get(s.auth_method, 0) + 1
        bytes_total += int(s.bytes_in or 0) + int(s.bytes_out or 0)
        if s.started_at and s.ended_at:
            durations.append((s.ended_at - s.started_at).total_seconds())

    by_severity: dict[str, int] = {}
    for r in syslog_records:
        key = f"sev_{r.severity}" if r.severity is not None else "unknown"
        by_severity[key] = by_severity.get(key, 0) + 1

    return {
        "customer_id": str(customer_id),
        "period_start": period_start.isoformat(),
        "period_end": period_end.isoformat(),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "sessions": {
            "total": len(sessions),
            "by_status": by_status,
            "by_method": by_method,
            "bytes_total": bytes_total,
            "avg_duration_seconds": sum(durations) / len(durations) if durations else 0,
            "max_duration_seconds": max(durations) if durations else 0,
        },
        "syslog": {
            "total": len(syslog_records),
            "by_severity": by_severity,
        },
        "sessions_detail": [
            {
                "id": str(s.id),
                "mac": s.mac,
                "ip": s.ip or "",
                "phone": s.phone or "",
                "auth_method": s.auth_method,
                "status": s.status,
                "started_at": s.started_at.isoformat() if s.started_at else None,
                "ended_at": s.ended_at.isoformat() if s.ended_at else None,
                "bytes_in": s.bytes_in or 0,
                "bytes_out": s.bytes_out or 0,
            }
            for s in sessions
        ],
    }


def _build_csv(report_data: dict) -> str:
    import csv as csv_mod
    buf = io.StringIO()
    fieldnames = ["id", "mac", "ip", "phone", "auth_method", "status", "started_at", "ended_at", "bytes_in", "bytes_out"]
    writer = csv_mod.DictWriter(buf, fieldnames=fieldnames)
    writer.writeheader()
    for s in report_data.get("sessions_detail", []):
        writer.writerow({k: s.get(k, "") for k in fieldnames})
    return buf.getvalue()


async def _store_report(content: bytes, job: ReportJob, content_hash: str) -> str:
    provider = (settings.ARCHIVE_PROVIDER or "local").lower()
    key = f"reports/{job.customer_id}/{job.id}/{content_hash}.{job.format}"

    if provider == "local":
        import os
        base = settings.ARCHIVE_LOCAL_DIR or "./_archives"
        safe = os.path.normpath(os.path.join(base, "reports", str(job.customer_id), str(job.id))).replace("\\", "/")
        os.makedirs(safe, exist_ok=True)
        filepath = os.path.join(safe, f"{content_hash}.{job.format}")
        with open(filepath, "wb") as f:
            f.write(content)
        with open(filepath, "rb") as f:
            if hashlib.sha256(f.read()).hexdigest() != content_hash:
                raise RuntimeError("report local storage verification failed")
        return f"local:{filepath}"

    if provider == "minio":
        try:
            from minio import Minio  # type: ignore[import-not-found]
            bucket = settings.MINIO_BUCKET_REPORTS or "hotspot-reports"
            client = Minio(
                settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
                access_key=settings.MINIO_ACCESS_KEY,
                secret_key=settings.MINIO_SECRET_KEY,
                secure=settings.MINIO_SECURE,
            )
            if not client.bucket_exists(bucket):
                client.make_bucket(bucket)
            client.put_object(bucket, key, io.BytesIO(content), length=len(content))
            if client.stat_object(bucket, key).size != len(content):
                raise RuntimeError("report object storage size verification failed")
            return f"minio:{bucket}/{key}"
        except Exception as exc:
            log.error("MinIO report upload failed: %s", exc)
            raise RuntimeError(f"report object storage failed: {exc}") from exc

    raise RuntimeError("report object storage provider is not configured")


async def send_report_email(archive: ReportArchive) -> bool:
    try:
        import smtplib
        from email.mime.text import MIMEText

        job = await _get_archive_job(archive)
        if not job or not job.recipients:
            log.warning("Rapor emaili icin alici bulunamadi archive=%s", archive.id)
            return False

        subject = f"[Hotspot Report] {job.name} - {archive.period_start.date()} / {archive.period_end.date()}"
        body = f"""Rapor hazir.

Donem: {archive.period_start.date()} - {archive.period_end.date()}
Format: {archive.format}
Boyut: {_fmt_size(archive.file_size)}
Dosya: {archive.file_ref}

Hotspot Platform Rapor Sistemi"""

        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = getattr(settings, "SMTP_FROM", "reports@hotspot.local")
        msg["To"] = ", ".join(job.recipients)

        host = getattr(settings, "SMTP_HOST", "localhost")
        port = getattr(settings, "SMTP_PORT", 25)

        with smtplib.SMTP(host, port, timeout=10) as server:
            server.sendmail(msg["From"], job.recipients, msg.as_string())
        return True
    except Exception as exc:
        log.error("Rapor emaili gonderilemedi archive=%s: %s", archive.id, exc)
        return False


async def _get_archive_job(archive: ReportArchive) -> ReportJob | None:
    if archive.job_id:
        from app.core.database import AsyncSessionLocal
        async with AsyncSessionLocal() as db:
            return await db.get(ReportJob, archive.job_id)
    return None


def _fmt_size(size: int) -> str:
    if size < 1024:
        return f"{size} B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size / (1024 * 1024):.1f} MB"
