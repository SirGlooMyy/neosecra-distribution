import logging

log = logging.getLogger(__name__)

# ISO 3166-1 alpha-2 country codes (common set)
VALID_COUNTRIES = {
    "US", "GB", "DE", "FR", "IT", "ES", "PT", "NL", "BE", "CH", "AT",
    "GR", "TR", "RU", "UA", "PL", "CZ", "SK", "HU", "RO", "BG", "RS",
    "HR", "BA", "SI", "AL", "MK", "ME", "XK",
    "SE", "NO", "DK", "FI", "IS",
    "CA", "MX", "BR", "AR", "CL", "CO", "PE",
    "AU", "NZ",
    "JP", "KR", "CN", "IN", "SG", "MY", "TH", "VN", "ID", "PH",
    "SA", "AE", "QA", "KW", "OM", "BH", "JO", "LB", "IL",
    "EG", "ZA", "NG", "KE", "MA", "TN", "DZ", "GH", "ET", "TZ",
    "IR", "IQ", "AF", "PK", "BD", "LK", "NP",
    "OTHER",
}


async def validate_passport(
    passport_number: str,
    country: str,
    full_name: str,
) -> bool:
    country_upper = country.strip().upper()
    if country_upper not in VALID_COUNTRIES:
        log.warning("Passport syntax validation failed: unknown country %s", country_upper)
        return False
    passport_clean = passport_number.strip()
    if len(passport_clean) < 5:
        log.warning("Passport syntax validation failed: number too short")
        return False
    if not full_name.strip():
        log.warning("Passport syntax validation failed: empty full name")
        return False
    masked_passport = (passport_clean[:2] + "****" + passport_clean[-2:]) if len(passport_clean) >= 6 else "****"
    log.info("Passport syntax validation SUCCESS: country=%s passport=%s", country_upper, masked_passport)
    return True


async def send_email_verification(
    email: str,
    code: str,
    *,
    customer_id=None,
    db=None,
) -> bool:
    from app.core.config import demo_mode_enabled
    from app.modules.system.email_service import send_email

    masked_email = (email[:2] + "***@" + email.split("@")[-1]) if "@" in email else "***"
    if demo_mode_enabled():
        log.info("Email verification delivery requested for %s (demo mode)", masked_email)
        return True

    html = (
        "<h2>Hotspot Giriş Doğrulama Kodu</h2>"
        f"<p>İnternet erişimi için tek kullanımlık doğrulama kodunuz: <strong>{code}</strong></p>"
        "<p>Bu kod 5 dakika geçerlidir.</p>"
    )
    try:
        delivered = await send_email(
            to=email,
            subject="Hotspot İnternet Doğrulama Kodu",
            html_body=html,
            customer_id=customer_id,
            db=db,
        )
        if delivered:
            log.info("Email verification sent to %s", masked_email)
            return True
        log.warning("Email verification delivery failed for %s", masked_email)
        return False
    except Exception as exc:
        log.error("Email verification service error: %s", exc)
        return False


def verify_email_code(code: str, stored: str) -> bool:
    return code.strip() == stored.strip()
