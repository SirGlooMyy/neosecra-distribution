"""Backward-compatible platform upgrade routes.

The canonical API lives under ``/system/updates``. These aliases keep older
admin bundles working while installations are upgraded in place.
"""
from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.shared.upgrade.upgrade_service import (
    UpgradeConflict, UpgradeError, UpgradeNotEnabled, check_available_updates,
    get_current_system_info, get_upgrade_history, orchestrator,
    run_preflight_checks,
)

router = APIRouter(prefix="/platform-upgrade", tags=["platform-upgrade"])


def _require(user: User, write: bool = False) -> None:
    if not has_permission(user.role, "system.write" if write else "system.read"):
        raise HTTPException(status_code=403, detail="Yetkisiz islem")


@router.get("/info", summary="Get platform upgrade information")
async def info(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user)
    return await get_current_system_info(db)


@router.get("/status")
async def status_endpoint(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user)
    return {"status": (await get_current_system_info(db)).get("upgrade_status", "IDLE")}


@router.get("/check", summary="Check available platform updates")
async def check(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user)
    return await check_available_updates(db)


@router.get("/history", summary="List platform upgrade history")
async def history(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user)
    return {"history": await get_upgrade_history(db)}


@router.post("/preflight", summary="Run platform upgrade preflight checks")
async def preflight(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user)
    return {"checks": await run_preflight_checks(db)}


@router.post("/start", summary="Start a platform upgrade session")
async def start(body: dict, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user), idempotency_key: str | None = Header(None, alias="Idempotency-Key")):
    _require(user, True)
    if not idempotency_key or not idempotency_key.strip():
        raise HTTPException(status_code=400, detail="IDEMPOTENCY_KEY_REQUIRED")
    replay = await orchestrator.get_idempotent_result(db, idempotency_key)
    if replay is not None:
        return {"session": replay, "replayed": True}
    try:
        session = await orchestrator.start_upgrade(db, str(body.get("target_version") or ""), str(user.id))
    except UpgradeNotEnabled as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    except UpgradeConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except UpgradeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    session["idempotency_key"] = idempotency_key
    await orchestrator.record_idempotent_result(db, idempotency_key, session)
    return {"session": session}
