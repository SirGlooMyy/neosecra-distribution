"""Tenant scope primitives.

Tenant-aware query filtering helpers that consume a user object. The user
model (app.modules.auth.models.User) carries tenant_id/partner_id/
customer_id/location_id. Filter logic is applied by repository layers and
the auth dependency so every query is scoped (Mutlak Kural #1 & #2).
"""
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any

from sqlalchemy import select


class TenantLevel(str, Enum):
    """How broadly a user can see data."""
    GLOBAL = "global"      # super_admin - sees everything
    TENANT = "tenant"      # partner scope
    PARTNER = "partner"
    CUSTOMER = "customer"
    LOCATION = "location"


# Maps role -> scope level. Roles below the super admin are always scoped.
ROLE_SCOPE_LEVEL: dict[str, TenantLevel] = {
    "super_admin": TenantLevel.GLOBAL,
    "partner_admin": TenantLevel.PARTNER,
    "customer_admin": TenantLevel.CUSTOMER,
    "location_manager": TenantLevel.LOCATION,
    "support": TenantLevel.CUSTOMER,  # read-only, scoped to assigned tenant
}


def scope_level_for(role: str) -> TenantLevel:
    return ROLE_SCOPE_LEVEL.get(role, TenantLevel.CUSTOMER)


def is_global_scope(user: Any) -> bool:
    return getattr(user, "role", None) == "super_admin"


@dataclass
class ScopeContext:
    """Resolved tenant scope for a user. Repositories apply whichever ids
    are relevant to the table they query. GLOBAL level = no filtering.

    `allowed` is False for a scoped role with no assignment -> the
    repository must return an empty result set (fail-closed IDOR guard).
    """
    level: TenantLevel
    tenant_id: uuid.UUID | None = None
    partner_id: uuid.UUID | None = None
    customer_id: uuid.UUID | None = None
    location_id: uuid.UUID | None = None
    allowed: bool = True


def scope_for(user: Any) -> ScopeContext:
    """Build a ScopeContext from a User row. Fails closed when a scoped
    user lacks its mandatory assignment."""
    role = getattr(user, "role", None) or ""
    level = scope_level_for(role)

    if level == TenantLevel.GLOBAL:
        return ScopeContext(level=TenantLevel.GLOBAL)

    ctx = ScopeContext(
        level=level,
        tenant_id=getattr(user, "tenant_id", None),
        partner_id=getattr(user, "partner_id", None),
        customer_id=getattr(user, "customer_id", None),
        location_id=getattr(user, "location_id", None),
    )

    if level == TenantLevel.PARTNER:
        ctx.allowed = bool(ctx.partner_id)
    elif level == TenantLevel.CUSTOMER:
        ctx.allowed = bool(ctx.customer_id)
    elif level == TenantLevel.LOCATION:
        ctx.allowed = bool(ctx.location_id)
    return ctx


async def customer_in_scope(db: Any, scope: ScopeContext, customer_id: uuid.UUID) -> bool:
    """Validate a customer id against the caller's tenant/partner scope."""
    if not scope.allowed:
        return False
    if scope.level == TenantLevel.GLOBAL:
        return True
    from app.modules.customers.models import Customer

    if scope.level == TenantLevel.CUSTOMER:
        return scope.customer_id == customer_id
    if scope.level == TenantLevel.PARTNER:
        query = select(Customer.id).where(Customer.id == customer_id, Customer.partner_id == scope.partner_id)
        if scope.tenant_id:
            query = query.where(Customer.tenant_id == scope.tenant_id)
        result = await db.execute(query)
        return result.scalar_one_or_none() is not None
    if scope.level == TenantLevel.TENANT:
        result = await db.execute(
            select(Customer.id).where(Customer.id == customer_id, Customer.tenant_id == scope.tenant_id)
        )
        return result.scalar_one_or_none() is not None
    if scope.level == TenantLevel.LOCATION:
        from app.modules.locations.models import Location

        query = select(Location.customer_id).where(
            Location.id == scope.location_id,
            Location.customer_id == customer_id,
        )
        if scope.tenant_id:
            query = query.join(Customer, Location.customer_id == Customer.id).where(
                Customer.tenant_id == scope.tenant_id
            )
        result = await db.execute(query)
        return result.scalar_one_or_none() is not None
    return False
