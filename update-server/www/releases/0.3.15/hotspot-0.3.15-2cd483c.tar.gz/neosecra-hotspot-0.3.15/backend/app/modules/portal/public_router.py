"""PUBLIC captive-portal flow endpoints.

NO admin JWT here: the guest is not a platform user. The device_id embedded in
the firewall redirect is the trust anchor, and every step re-resolves the site
context (flow.resolve_context) before doing work (Mutlak Kural #6). Each
endpoint is IP-rate-limited to blunt brute force on OTPs / voucher codes.

Registered under /portal/public so it is visibly separate from the authed
admin/template endpoints (api/v1/router.py).
"""
import html
import re
import uuid

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request, status
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.security import rate_limit
from app.modules.portal import flow
from app.modules.portal.parity import PortalParityError
from app.modules.portal.approval import (
    ApprovalLinkConfigurationError,
    build_approval_action_path,
    normalize_decision,
    session_status_projection,
)
from app.modules.portal.i18n_data import SUPPORTED_LANGUAGES, LANGUAGE_NAMES
from app.modules.portal.i18n_service import get_translations
from app.modules.portal.schemas import (
    PortalContextOut,
    PortalVerifyIn,
    SendCodeIn,
    StartSessionIn,
    StartSessionOut,
    PortalTokenOut,
    normalize_client_ip,
    normalize_client_mac,
)
from app.modules.portal.template_service import (
    get_available_templates,
    render_preview_html,
)
from app.modules.sms.schemas import OtpResultOut

router = APIRouter(tags=["captive-portal"])

# Blunt per-IP shield across the whole public flow. Per-credential limits
# (OTP max attempts, voucher single-use, per-phone send window) are enforced
# inside the respective services; this only caps request volume.
_PORTAL_RL_MAX = 60
_PORTAL_RL_WINDOW = 60
_UUID_IN_VALUE = re.compile(
    r"(?i)([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})"
)


def _parse_redirect_uuid(value: str | uuid.UUID | None, field: str) -> uuid.UUID | None:
    """Accept a UUID with FortiOS' optional trailing magic token.

    Depending on FortiOS release, an external portal URL can be returned as
    ``device_id=<uuid>?<magic>`` or with a bare token appended to the query.
    FastAPI's UUID validator rejects that value before the route executes;
    normalize it here so the public portal remains compatible with both forms.
    """
    if value is None or isinstance(value, uuid.UUID):
        return value
    match = _UUID_IN_VALUE.search(str(value))
    if not match:
        raise HTTPException(status_code=422, detail=f"{field} geçerli bir UUID içermiyor")
    try:
        return uuid.UUID(match.group(1))
    except ValueError as exc:  # pragma: no cover - regex already constrains shape
        raise HTTPException(status_code=422, detail=f"{field} geçersiz") from exc


def _client_ip(request: Request) -> str:
    return request.client.host if request and request.client else "unknown"


def _normalize_client_mac(value: str | None) -> str | None:
    """Normalize captive redirect MAC variants to the DB representation."""
    if not value:
        return None
    try:
        return normalize_client_mac(str(value))
    except ValueError:
        # A malformed optional redirect hint must never be used for automatic
        # session lookup. The canonical start-session body validates it again.
        return None


async def _rl(request: Request, bucket: str) -> None:
    if settings.DISABLE_RATE_LIMIT:
        return
    blocked, _ = await rate_limit(
        f"portal:{bucket}:{_client_ip(request)}",
        _PORTAL_RL_MAX,
        _PORTAL_RL_WINDOW,
    )
    if blocked:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Cok fazla istek. Lutfen daha sonra tekrar deneyin.",
        )


@router.get("/context", response_model=PortalContextOut, summary="Get public portal context for a device's site", description="Returns the landing-page configuration for the captive portal associated with the specified device. Includes branding, supported auth methods, and template settings. No authentication required. Rate-limited per IP.")
async def portal_context(
    request: Request,
    # Keep these as strings at the HTTP boundary. FortiOS may append its bare
    # magic token to the configured UUID query value.
    device_id: str | None = Query(None),
    template_id: str | None = Query(None),
    location_id: str | None = Query(None),
    mac: str | None = Query(None),
    client_mac: str | None = Query(None),
    usermac: str | None = Query(None),
    ip: str | None = Query(None),
    client_ip: str | None = Query(None),
    userip: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
):
    await _rl(request, "ctx")
    parsed_device_id = _parse_redirect_uuid(device_id, "device_id")
    parsed_location_id = _parse_redirect_uuid(location_id, "location_id")
    parsed_template_id = _parse_redirect_uuid(template_id, "template_id")
    if parsed_device_id is not None:
        device, location, customer, template = await flow.resolve_context(
            db, device_id=parsed_device_id, template_id=parsed_template_id
        )
    else:
        device, location, customer, template = await flow.resolve_default_context(
            db, location_id=parsed_location_id, template_id=parsed_template_id
        )

    # Detect client MAC and client IP for automatic re-login (MAC bypass)
    effective_mac = _normalize_client_mac(
        mac or client_mac or usermac or request.query_params.get("client-mac") or request.query_params.get("cmac")
    )
    raw_ip = ip or client_ip or userip
    try:
        effective_ip = normalize_client_ip(raw_ip) if raw_ip else flow._client_ip(request)
    except ValueError:
        effective_ip = flow._client_ip(request)

    theme = template.theme if isinstance(getattr(template, "theme", None), dict) else {}
    remember_enabled = bool(theme.get("remember_mac_enabled", True))
    active_session = None
    auto_authorized = False

    if remember_enabled and (effective_mac or effective_ip):
        active_session = await flow.check_active_mac_session(
            db,
            customer_id=customer.id,
            mac=effective_mac,
            ip=effective_ip,
            device=device,
        )
        if active_session:
            auto_authorized = True

    is_demo_mode, demo_fallback_reason = await flow.resolve_demo_state(db, customer)
    try:
        return flow.build_context_out(
            template,
            customer,
            location=location,
            device_id=device.id,
            is_demo_mode=is_demo_mode,
            demo_fallback_reason=demo_fallback_reason,
            active_session=active_session,
            auto_authorized=auto_authorized,
        )
    except PortalParityError as exc:
        # A malformed persisted template must stop the guest flow explicitly;
        # never render a guessed/default form on one surface only.
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Portal şablonu kanonik sözleşmesi geçersiz; yönetici düzeltmesi gerekli",
        ) from exc


@router.post("/send-code", response_model=OtpResultOut, summary="Send an SMS OTP code for portal verification", description="Sends a one-time SMS code to the guest's phone bound to the specified device's site context. Used for SMS-based authentication in the captive portal flow. Rate-limited per IP.")
async def portal_send_code(
    body: SendCodeIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    await _rl(request, "send")
    return await flow.send_code(
        db,
        device_id=body.device_id,
        phone=body.phone,
        tc_number=body.tc_number,
        method=body.method,
        request=request,
    )


@router.post("/verify", response_model=PortalTokenOut, summary="Verify guest credential and issue a portal token", description="Verifies the guest's authentication credential (SMS code, voucher, PMS, etc.) according to the site's configured method. Issues a one-shot portal token that can be exchanged for network access. Rate-limited per IP.")
async def portal_verify(
    body: PortalVerifyIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    await _rl(request, "verify")
    return await flow.verify(
        db,
        device_id=body.device_id,
        requested_method=body.method,
        phone=body.phone,
        code=body.code,
        tc_number=body.tc_number,
        voucher_code=body.voucher_code,
        room_number=body.room_number,
        surname_or_birth=body.surname_or_birth,
        username=body.username,
        password=body.password,
        passport_number=body.passport_number,
        full_name=body.full_name,
        country=body.country,
        form_data=body.form_data,
        request=request,
    )


# ── i18n ─────────────────────────────────────────────────────────────────────


@router.get("/i18n", summary="Get translations for the captive portal UI", description="Returns all translated strings for the requested language along with the list of available languages. Falls back to Turkish if the requested language is not supported. Publicly accessible.")
async def portal_i18n(
    lang: str = Query("tr", description="Language code"),
):
    return {
        "lang": lang if lang in SUPPORTED_LANGUAGES else "tr",
        "available_languages": {
            code: LANGUAGE_NAMES[code]
            for code in SUPPORTED_LANGUAGES
        },
        "translations": get_translations(lang),
    }


# ── Predefined templates ─────────────────────────────────────────────────────


@router.get("/templates", summary="List available predefined portal templates", description="Returns all available captive portal template presets grouped by category (hotel, cafe, mall, etc.). These templates provide pre-built branding and layout configurations. Publicly accessible.")
async def portal_templates():
    return {
        "templates": get_available_templates(),
        "categories": ["hotel", "residence", "school", "cafe", "public", "mall", "business"],
    }


@router.get("/templates/preview/{template_id}", summary="Get HTML preview of a portal template", description="Renders an HTML preview of the specified portal template with the selected authentication method and language. Useful for visual template selection during setup. Publicly accessible.")
async def portal_template_preview(
    template_id: str,
    method: str = Query("sms", description="Auth method for form fields"),
    lang: str = Query("tr", description="Language for text"),
):
    html = render_preview_html(template_id, method, lang)
    return HTMLResponse(content=html)


# ── Flow endpoints ───────────────────────────────────────────────────────────


@router.post("/start-session", response_model=StartSessionOut, summary="Exchange portal token for an authorized guest session", description="Exchanges a verified portal token for a full guest session with firewall authorization. Creates a GuestSession record and adds the guest's MAC/IP to the firewall allowlist. Rate-limited per IP.")
async def portal_start_session(
    body: StartSessionIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    await _rl(request, "start")
    return await flow.start_session(
        db,
        device_id=body.device_id,
        portal_token=body.portal_token,
        mac=body.mac,
        ip=body.ip,
        ssid=body.ssid,
        request=request,
        terms_accepted=body.terms_accepted,
        privacy_accepted=body.privacy_accepted,
        terms_version=body.terms_version,
        privacy_version=body.privacy_version,
    )


def _approval_html(
    *,
    title: str,
    message: str,
    session_id: uuid.UUID,
    token: str | None = None,
    decision: str | None = None,
    submit_label: str | None = None,
    action_path: str | None = None,
    status_code: int = 200,
) -> HTMLResponse:
    """Render a no-store, side-effect-free approval landing page."""
    safe_title = html.escape(title, quote=True)
    safe_message = html.escape(message, quote=True)
    controls = ""
    if token is not None and decision is not None and submit_label:
        # The caller supplies the current path (without query parameters), so
        # any reverse-proxy prefix is preserved while the bearer token stays
        # out of the POST request URL and access logs.
        safe_action = html.escape(action_path or "?", quote=True)
        controls = (
            f"<form method=\"post\" action=\"{safe_action}\" autocomplete=\"off\">"
            f"<input type=\"hidden\" name=\"token\" value=\"{html.escape(token, quote=True)}\">"
            f"<input type=\"hidden\" name=\"decision\" value=\"{html.escape(decision, quote=True)}\">"
            f"<button type=\"submit\" aria-label=\"{html.escape(submit_label, quote=True)}\" "
            "style=\"background:#4f46e5;color:#fff;border:0;border-radius:6px;padding:12px 18px;font-weight:700;cursor:pointer;\">"
            f"{html.escape(submit_label, quote=True)}</button></form>"
        )
    response = HTMLResponse(
        content=(
            "<!doctype html><html lang=\"tr\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
            f"<title>{safe_title}</title></head><body style=\"margin:0;background:#f8fafc;"
            "font-family:Arial,Helvetica,sans-serif;color:#0f172a;\">"
            "<main style=\"max-width:560px;margin:48px auto;padding:24px;background:#fff;"
            "border:1px solid #e2e8f0;border-radius:8px;\">"
            "<p style=\"margin:0 0 8px;color:#4f46e5;font-weight:700;letter-spacing:.04em;\">NeoSecra Hotspot</p>"
            f"<h1 style=\"font-size:24px;margin:0 0 14px;\">{safe_title}</h1>"
            f"<p style=\"line-height:1.6;color:#475569;\">{safe_message}</p>{controls}"
            "</main></body></html>"
        ),
        status_code=status_code,
        media_type="text/html",
    )
    response.headers.update(
        {
            "Cache-Control": "no-store, max-age=0",
            "Pragma": "no-cache",
            "Referrer-Policy": "no-referrer",
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'",
        }
    )
    return response


@router.get("/approval/{session_id}", response_class=HTMLResponse, summary="Show manager approval confirmation")
async def manager_approval_link(
    session_id: uuid.UUID,
    request: Request,
    token: str = Query(..., min_length=20, max_length=200),
    decision: str = Query("approve"),
    db: AsyncSession = Depends(get_db),
):
    """Validate and render a confirmation form; GET never authorizes."""
    await _rl(request, "approval")
    try:
        safe_decision = normalize_decision(decision)
    except ValueError:
        return _approval_html(
            title="Onay bağlantısı geçersiz",
            message="Karar değeri tanınmadı. E-postadaki bağlantıyı yeniden açın.",
            session_id=session_id,
            status_code=400,
        )
    from app.modules.sessions import service as sessions_service

    try:
        session = await sessions_service.inspect_approval_token(
            db, session_id, token, decision=safe_decision
        )
    except HTTPException as exc:
        status_code = exc.status_code if exc.status_code in {400, 403, 404, 409, 410} else 403
        title = "Onay bağlantısının süresi doldu" if status_code == 410 else "Onay bağlantısı geçersiz"
        return _approval_html(
            title=title,
            message="Bu bağlantı artık kullanılamıyor. Yeni bir onay isteği oluşturulması için sistem yöneticinizle iletişime geçin.",
            session_id=session_id,
            status_code=status_code,
        )
    approval = (session.meta or {}).get("approval") or {}
    if isinstance(approval, dict) and approval.get("decision"):
        if (
            approval.get("status") == "pending"
            and approval.get("last_attempt_status") == "failed"
        ):
            return _approval_html(
                title="Karar alındı; ağ erişimi açılamadı",
                message="Yönetici kararı kaydedildi ancak ağ geçidi erişimi doğrulamadı. Yeni bir deneme için kimliği doğrulanmış yönetici panelini kullanın.",
                session_id=session_id,
            )
        label = "onaylandı" if safe_decision == "approve" else "reddedildi"
        return _approval_html(
            title="Onay bağlantısı daha önce kullanıldı",
            message=f"Bu istek zaten {label}. Yeni bir karar verilemez.",
            session_id=session_id,
        )
    action = "Erişimi reddet" if safe_decision == "reject" else "Erişimi onayla"
    title = "Hotspot erişim talebini reddet" if safe_decision == "reject" else "Hotspot erişim talebini onayla"
    try:
        action_path = build_approval_action_path(session_id, request=request)
    except ApprovalLinkConfigurationError:
        return _approval_html(
            title="Onay bağlantısı kullanılamıyor",
            message="Onay bağlantısı yapılandırması geçersiz. Yeni bir bağlantı oluşturulması için sistem yöneticinizle iletişime geçin.",
            session_id=session_id,
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        )
    return _approval_html(
        title=title,
        message="Devam etmek için aşağıdaki düğmeye basın. Bu sayfanın açılması tek başına karar vermez.",
        session_id=session_id,
        token=token,
        decision=safe_decision,
        submit_label=action,
        # Keep the bearer token out of the POST request URL and access logs;
        # derive the path from the trusted external prefix so mounted/proxied
        # deployments post back to the same public route.
        action_path=action_path,
    )


@router.post("/approval/{session_id}", response_class=HTMLResponse, include_in_schema=False)
async def process_manager_approval(
    session_id: uuid.UUID,
    request: Request,
    token: str = Form(..., min_length=20, max_length=200),
    decision: str = Form("approve"),
    db: AsyncSession = Depends(get_db),
):
    """Consume the one-time manager decision after an explicit click."""
    await _rl(request, "approval")
    try:
        canonical_decision = normalize_decision(decision)
    except ValueError:
        return _approval_html(
            title="Onay kararı geçersiz",
            message="Karar değeri tanınmadı; hiçbir işlem yapılmadı.",
            session_id=session_id,
            status_code=400,
        )
    from app.modules.sessions import service as sessions_service
    try:
        session = await sessions_service.approve_session_by_token(
            db, session_id, token, decision=canonical_decision, request=request
        )
    except HTTPException as exc:
        return _approval_html(
            title="Hotspot onayı işlenemedi",
            message=(
                "Onay bağlantısının süresi doldu."
                if exc.status_code == 410
                else "Bağlantı geçersiz, kullanılmış veya bu istek için yetkili değil."
            ),
            session_id=session_id,
            status_code=exc.status_code if exc.status_code in {400, 403, 404, 409, 410} else 403,
        )
    if canonical_decision == "approve" and session.status == "pending" and not session.authorize_ok:
        return _approval_html(
            title="Ağ erişimi henüz açılamadı",
            message="Yönetici kararı kaydedildi ancak ağ geçidi erişimi doğrulamadı. Bağlantı, sistem yöneticisi yeniden deneyene kadar kullanılabilir.",
            session_id=session_id,
        )
    label = "onaylandı" if canonical_decision == "approve" else "reddedildi"
    return _approval_html(
        title=f"Erişim talebi {label}",
        message="Karar kaydedildi. Bu pencereyi kapatabilirsiniz.",
        session_id=session_id,
    )


@router.get(
    "/session/{session_id}/status",
    summary="Get guest session status for live approval polling",
    description="Allows the captive portal frontend to poll for manager approval completion."
)
async def portal_session_status(
    session_id: uuid.UUID,
    request: Request,
    token: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
):
    from app.modules.sessions.models import GuestSession
    await _rl(request, "status")
    session = await db.get(GuestSession, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Oturum bulunamadı")
    try:
        return session_status_projection(session, token)
    except ValueError as exc:
        raise HTTPException(status_code=403, detail="Oturum durumu için geçerli token gerekli") from exc
