"""Report job + archive models for scheduled reporting.
"""
import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


class ReportJob(Base, UUIDPK, TimestampMixin):
    """Scheduled report generation job."""
    __tablename__ = "report_jobs"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    # Optional concrete report preset.  Keeping report_type as the cadence
    # (daily/weekly/monthly/custom) lets existing jobs continue to work while
    # scheduled jobs can now target the same Analyzer presets exposed by the
    # Reports page.
    template_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    report_type: Mapped[str] = mapped_column(String(20), nullable=False)
    format: Mapped[str] = mapped_column(String(10), nullable=False)
    trigger: Mapped[str] = mapped_column(String(100), nullable=False)
    recipients: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    last_run_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    next_run_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)
    created_by: Mapped[uuid.UUID] = fk("users", ondelete="SET NULL", nullable=True)


class ReportArchive(Base, UUIDPK, TimestampMixin):
    """Generated report output stored in MinIO/object-store."""
    __tablename__ = "report_archives"

    job_id: Mapped[uuid.UUID | None] = fk("report_jobs", ondelete="SET NULL", nullable=True)
    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    period_start: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    period_end: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    generated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    format: Mapped[str] = mapped_column(String(10), nullable=False)
    file_size: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    file_ref: Mapped[str] = mapped_column(String(500), nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="generating", nullable=False)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    # Immutable, machine-readable report envelope.  ``sha256_hash`` covers
    # the canonical JSON envelope (excluding the hash field itself).
    schema_version: Mapped[str] = mapped_column(String(20), default="1.0", nullable=False)
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True, index=True)
    sha256_hash: Mapped[str] = mapped_column(String(64), default="", nullable=False, index=True)
    provenance: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    envelope: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)


class ReportJobStatusHistory(Base, UUIDPK, TimestampMixin):
    """Append-only status transitions for asynchronous report jobs."""

    __tablename__ = "report_job_status_history"

    job_id: Mapped[uuid.UUID] = fk("report_jobs", ondelete="CASCADE")
    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    status: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    attempt: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    details: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
