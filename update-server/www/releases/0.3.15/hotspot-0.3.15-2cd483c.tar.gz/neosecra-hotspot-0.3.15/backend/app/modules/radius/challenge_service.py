"""RADIUS Access-Challenge state machine for VPN MFA.

FreeRADIUS calls this service via its `rest` module during the
authorize/authenticate phases.  The flow:

  1. FreeRADIUS calls init_challenge → we return a State + Reply-Message.
  2. FreeRADIUS sends Access-Challenge to the NAS.
  3. User provides the MFA code.
  4. FreeRADIUS calls verify_challenge → we validate the code.
  5. FreeRADIUS sends Access-Accept / Access-Reject.
"""
from __future__ import annotations

import logging
import hashlib
import hmac
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import demo_mode_enabled, settings
from app.modules.mfa.models import VpnMfaConfig, VpnMfaUser
from app.modules.radius.models import RadiusChallenge

log = logging.getLogger(__name__)

CHALLENGE_TTL_SECONDS = 300
MAX_ATTEMPTS = 3


def _render_otp_email(username: str, code: str, title: str = "VPN Giriş Doğrulama Kodu", gateway: str = "SSL-VPN Ağ Geçidi") -> str:
    now_str = datetime.now(timezone.utc).strftime("%d.%m.%Y %H:%M:%S UTC")
    return f"""<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color: #f1f5f9; padding: 40px 15px;">
    <tr>
      <td align="center">
        <!-- Main White Card -->
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width: 520px; background-color: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); overflow: hidden;">
          
          <!-- Header -->
          <tr>
            <td style="padding: 24px 32px 18px 32px; background-color: #ffffff; border-bottom: 1px solid #f1f5f9;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                  <td>
                    <div style="display: inline-block; background: #2563eb; border-radius: 6px; padding: 6px 12px; vertical-align: middle;">
                      <span style="color: #ffffff; font-weight: 800; font-size: 14px; letter-spacing: 1px;">🛡️ NEOSECRA</span>
                    </div>
                    <span style="color: #64748b; font-size: 13px; font-weight: 600; margin-left: 10px; vertical-align: middle;">VPN Güvenlik Servisi</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Content Body -->
          <tr>
            <td style="padding: 32px 32px 24px 32px;">
              <h1 style="color: #0f172a; font-size: 20px; font-weight: 700; margin: 0 0 12px 0; line-height: 1.3;">{title}</h1>
              <p style="color: #475569; font-size: 14px; line-height: 1.6; margin: 0 0 20px 0;">
                Merhaba <strong>{username}</strong>,<br>
                Giris dogrulama kodunuz: Kurumsal VPN oturumunuz için 2. faktör doğrulama kodunuz oluşturulmuştur:
              </p>

              <!-- High-Impact Clean White/Blue OTP Box -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="margin: 20px 0;">
                <tr>
                  <td align="center" style="background: #f8fafc; border: 2px dashed #2563eb; border-radius: 10px; padding: 20px 16px;">
                    <div style="color: #64748b; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 6px;">Tek Kullanımlık Giriş Kodu</div>
                    <div style="font-family: 'SF Mono', 'Courier New', Courier, monospace; font-size: 36px; font-weight: 800; letter-spacing: 10px; color: #1d4ed8; padding-left: 10px;">
                      {code}
                    </div>
                  </td>
                </tr>
              </table>

              <!-- Notice Box -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background: #fefce8; border: 1px solid #fef08a; border-radius: 8px; margin-bottom: 16px;">
                <tr>
                  <td style="padding: 12px 16px;">
                    <p style="color: #854d0e; font-size: 12px; font-weight: 600; margin: 0;">
                      ⏱️ <strong>Geçerlilik: 5 Dakika</strong> • Kod tek kullanımlıktır ve süresi dolduğunda otomatik olarak iptal olur.
                    </p>
                  </td>
                </tr>
              </table>

              <!-- Security Warning -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; margin-bottom: 20px;">
                <tr>
                  <td style="padding: 12px 16px;">
                    <p style="color: #991b1b; font-size: 12px; line-height: 1.5; margin: 0;">
                      <strong>⚠️ Güvenlik Uyarısı:</strong> Bu giriş talebini siz yapmadıysanız, şifrenizi derhal değiştirin ve sistem yöneticinizle irtibata geçin.
                    </p>
                  </td>
                </tr>
              </table>

              <!-- Metadata Table -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-top: 1px solid #f1f5f9; padding-top: 12px;">
                <tr>
                  <td style="color: #94a3b8; font-size: 11px;">
                    Ağ Geçidi: <strong style="color: #64748b;">{gateway}</strong>
                  </td>
                  <td align="right" style="color: #94a3b8; font-size: 11px;">
                    Tarih: <strong style="color: #64748b;">{now_str}</strong>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Clean Light Footer -->
          <tr>
            <td style="padding: 18px 32px; background-color: #f8fafc; border-top: 1px solid #f1f5f9; text-align: center;">
              <p style="color: #94a3b8; font-size: 11px; margin: 0 0 3px 0;">
                © 2026 NeoSecra. Tüm hakları saklıdır.
              </p>
              <p style="color: #cbd5e1; font-size: 10px; margin: 0;">
                Bu e-posta otomatik güvenlik bildirimidir, lütfen yanıtlamayınız.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>"""


async def _vpn_sms_message(
    db: AsyncSession, customer_id: uuid.UUID, username: str, code: str
) -> str:
    config = (
        await db.execute(
            select(VpnMfaConfig).where(VpnMfaConfig.customer_id == customer_id)
        )
    ).scalar_one_or_none()
    template = (getattr(config, "sms_template", None) if config else None) or "VPN giriş doğrulama kodunuz: {code}"
    try:
        message = template.format(code=code, username=username)
    except (KeyError, IndexError, ValueError):
        message = f"VPN giriş doğrulama kodunuz: {code}"
    return message[:500]


async def _lookup_vpn_user(
    db: AsyncSession,
    customer_id: uuid.UUID | None,
    username: str,
) -> VpnMfaUser | None:
    q = select(VpnMfaUser).where(
        VpnMfaUser.username == username,
        VpnMfaUser.is_active.is_(True),
    )
    if customer_id is not None:
        q = q.where(VpnMfaUser.customer_id == customer_id)
    return (await db.execute(q)).scalar_one_or_none()


async def init_challenge(
    db: AsyncSession,
    customer_id: uuid.UUID | None,
    username: str,
    nas_ip: str | None = None,
) -> dict:
    """Initiate a RADIUS Access-Challenge for VPN MFA.

    Looks up the user's MFA registration, creates a challenge session,
    and returns the State attribute value for FreeRADIUS.
    If customer_id is None, derives it from the VpnMfaUser record.

    Returns:
        dict with keys: challenge_required (bool), state (str | None),
                        reply_message (str), mfa_method (str | None)
    """
    vpn_user = await _lookup_vpn_user(db, customer_id, username)
    if not vpn_user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No MFA config")

    cid = customer_id or vpn_user.customer_id
    state = secrets.token_urlsafe(32)
    raw_method = vpn_user.mfa_method or "totp"
    methods = [m.strip().lower() for m in raw_method.split(",") if m.strip()]
    if not methods:
        methods = ["totp"]

    code_hash: str | None = None
    # The delivery code exists only for the outbound provider call.  Persist
    # its verifier-side hash, never the plaintext code.
    delivery_code: str | None = None
    if any(m in ("sms", "email", "whatsapp") for m in methods):
        import secrets as sec
        delivery_code = f"{sec.randbelow(900000) + 100000}"
        code_hash = hashlib.sha256(delivery_code.encode()).hexdigest()

    sent_channels = []
    if "sms" in methods:
        if vpn_user and vpn_user.phone:
            from app.modules.sms.service import send_custom_sms
            delivered, err = await send_custom_sms(
                phone=vpn_user.phone,
                message=await _vpn_sms_message(db, cid, username, delivery_code),
                db=db,
                customer_id=cid,
            )
            if delivered or demo_mode_enabled():
                sent_channels.append("SMS")
                log.info("VPN MFA SMS delivered -> %s", vpn_user.phone)
            else:
                log.warning("VPN MFA SMS delivery failed: %s", err)
        elif demo_mode_enabled():
            sent_channels.append("SMS")
            log.info("VPN MFA SMS (demo) delivery enabled")

    if "email" in methods:
        if vpn_user and vpn_user.email:
            from app.modules.system.email_service import send_email
            email_html = _render_otp_email(
                username=vpn_user.username,
                code=delivery_code,
                title="VPN Giriş Doğrulama Kodu",
                gateway=nas_ip or "Kurumsal VPN Ağ Geçidi",
            )
            delivered = await send_email(
                to=vpn_user.email,
                subject="🔐 VPN Doğrulama Kodu",
                html_body=email_html,
                customer_id=cid,
                db=db,
            )
            if delivered:
                sent_channels.append("EMAIL")
                log.info("VPN MFA email delivered -> %s", vpn_user.email)
            elif demo_mode_enabled():
                sent_channels.append("EMAIL")
                log.info("VPN MFA email (demo) delivery enabled")
            else:
                log.warning("VPN MFA email delivery failed")
                raise HTTPException(status_code=503, detail="E-posta ile dogrulama kodu gonderilemedi")
        elif demo_mode_enabled():
            sent_channels.append("EMAIL")
            log.info("VPN MFA email (demo) delivery enabled")

    if "whatsapp" in methods:
        if vpn_user and vpn_user.phone:
            from app.modules.whatsapp.service import send_whatsapp_otp
            delivered, err = await send_whatsapp_otp(
                phone=vpn_user.phone,
                code=delivery_code,
                customer_id=cid,
                db=db,
            )
            if delivered or demo_mode_enabled():
                sent_channels.append("WHATSAPP")
                log.info("VPN MFA WhatsApp delivered -> %s", vpn_user.phone)
            else:
                log.warning("VPN MFA WhatsApp delivery failed: %s", err)
        elif demo_mode_enabled():
            sent_channels.append("WHATSAPP")
            log.info("VPN MFA WhatsApp (demo) delivery enabled")

    if "totp" in methods and sent_channels:
        reply_msg = f"Authenticator (TOTP) veya {'/'.join(sent_channels)} kodunu girin"
    elif "totp" in methods:
        reply_msg = "Google Authenticator (TOTP) kodunu girin"
    elif sent_channels:
        reply_msg = f"Dogrulama kodu {'/'.join(sent_channels)} ile gonderildi"
    else:
        reply_msg = "Dogrulama kodunu girin"

    challenge = RadiusChallenge(
        customer_id=cid,
        username=username,
        nas_ip=nas_ip,
        state=state,
        mfa_method=raw_method,
        code_hash=code_hash,
        session_token=None,
        verified=False,
        expires_at=datetime.now(timezone.utc) + timedelta(seconds=CHALLENGE_TTL_SECONDS),
    )

    db.add(challenge)
    await db.flush()
    await db.commit()
    log.info("VPN MFA challenge init: user=%s methods=%s state=%s", username, raw_method, state[:12])

    return {
        "challenge_required": True,
        "state": state,
        "reply_message": reply_msg,
        "mfa_method": raw_method,
    }


def _normalize_state(raw_state: str) -> list[str]:
    candidates = [raw_state.strip()]
    cleaned = raw_state.strip()
    if cleaned.startswith("0x") or cleaned.startswith("0X"):
        try:
            decoded = bytes.fromhex(cleaned[2:]).decode("utf-8", errors="ignore")
            if decoded and decoded not in candidates:
                candidates.append(decoded)
        except Exception:
            pass
    else:
        try:
            hex_str = "0x" + cleaned.encode("utf-8").hex()
            if hex_str not in candidates:
                candidates.append(hex_str)
        except Exception:
            pass
    return candidates


def _normalize_code(raw_code: str) -> list[str]:
    cleaned = raw_code.strip().strip('"').strip("'")
    candidates = [cleaned]
    if cleaned.startswith("0x") or cleaned.startswith("0X"):
        try:
            decoded = bytes.fromhex(cleaned[2:]).decode("utf-8", errors="ignore")
            if decoded and decoded not in candidates:
                candidates.append(decoded)
        except Exception:
            pass
    return candidates


async def verify_challenge(
    db: AsyncSession,
    state: str,
    code: str,
) -> dict:
    """Verify a MFA code against an active challenge session.

    FreeRADIUS calls this when the user responds to an Access-Challenge.

    Returns:
        dict with keys: verified (bool), reply_message (str)
    """
    state_candidates = _normalize_state(state)
    res = await db.execute(
        select(RadiusChallenge).where(
            RadiusChallenge.state.in_(state_candidates),
            RadiusChallenge.verified.is_(False),
            RadiusChallenge.consumed_at.is_(None),
            RadiusChallenge.expires_at > datetime.now(timezone.utc),
        ).with_for_update()
    )
    challenge = None
    if hasattr(res, "scalar_one_or_none") and callable(res.scalar_one_or_none):
        challenge = res.scalar_one_or_none()
    elif hasattr(res, "scalars") and callable(res.scalars):
        sc = res.scalars()
        if hasattr(sc, "first") and callable(sc.first):
            challenge = sc.first()
        elif hasattr(sc, "all") and callable(sc.all):
            items = sc.all()
            challenge = items[0] if items else None
    elif hasattr(res, "first") and callable(res.first):
        challenge = res.first()

    if not challenge:
        log.warning("VPN MFA challenge not found or expired: state=%s candidates=%s", state[:16], state_candidates)
        return {"verified": False, "reply_message": "Gecersiz veya suresi dolmus dogrulama oturumu"}

    challenge.attempt_count += 1
    if challenge.attempt_count > MAX_ATTEMPTS:
        challenge.consumed_at = datetime.now(timezone.utc)
        await db.flush()
        await db.commit()
        log.warning("VPN MFA max attempts exceeded: user=%s", challenge.username)
        return {"verified": False, "reply_message": "Maksimum deneme sayisi asildi"}

    valid = False
    methods = [m.strip().lower() for m in challenge.mfa_method.split(",") if m.strip()]
    code_candidates = _normalize_code(code)

    if "totp" in methods:
        vpn_user = await _lookup_vpn_user(db, challenge.customer_id, challenge.username)
        if vpn_user and vpn_user.secret_encrypted:
            from app.core.crypto import decrypt
            secret = decrypt(vpn_user.secret_encrypted)
            try:
                import pyotp
                totp = pyotp.TOTP(secret)
                for c in code_candidates:
                    if totp.verify(c, valid_window=2):
                        valid = True
                        break
            except ImportError:
                valid = False
        else:
            log.warning("VPN user TOTP secret not found: user=%s", challenge.username)

    if not valid and challenge.code_hash:
        for c in code_candidates:
            if hmac.compare_digest(hashlib.sha256(c.encode()).hexdigest(), challenge.code_hash):
                valid = True
                break

    if valid:
        challenge.verified = True
        challenge.consumed_at = datetime.now(timezone.utc)
        await db.flush()
        await db.commit()
        log.info("VPN MFA challenge verified: user=%s methods=%s", challenge.username, challenge.mfa_method)
        return {"verified": True, "reply_message": "Dogrulama basarili"}

    await db.flush()
    await db.commit()
    log.warning("VPN MFA challenge failed: user=%s attempt=%d", challenge.username, challenge.attempt_count)
    return {"verified": False, "reply_message": "Gecersiz dogrulama kodu"}


async def approve_challenge(
    db: AsyncSession,
    state: str,
) -> dict:
    """Admin approve a pending challenge — marks as verified and consumed."""
    challenge = (
        await db.execute(
            select(RadiusChallenge).where(
                RadiusChallenge.state == state,
                RadiusChallenge.verified.is_(False),
                RadiusChallenge.consumed_at.is_(None),
            )
        )
    ).scalar_one_or_none()

    if not challenge:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Challenge bulunamadi")

    challenge.verified = True
    challenge.consumed_at = datetime.now(timezone.utc)
    await db.flush()
    await db.commit()
    log.info("VPN MFA challenge approved by admin: user=%s state=%s", challenge.username, state[:12])
    return {"verified": True, "reply_message": "Challenge admin tarafindan onaylandi"}


async def reject_challenge(
    db: AsyncSession,
    state: str,
) -> dict:
    """Admin reject a pending challenge — marks as consumed without verified."""
    challenge = (
        await db.execute(
            select(RadiusChallenge).where(
                RadiusChallenge.state == state,
                RadiusChallenge.verified.is_(False),
                RadiusChallenge.consumed_at.is_(None),
            )
        )
    ).scalar_one_or_none()

    if not challenge:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Challenge bulunamadi")

    challenge.consumed_at = datetime.now(timezone.utc)
    await db.flush()
    await db.commit()
    log.warning("VPN MFA challenge rejected by admin: user=%s state=%s", challenge.username, state[:12])
    return {"verified": False, "reply_message": "Challenge admin tarafindan reddedildi"}


async def challenge_status(
    db: AsyncSession,
    state: str,
) -> dict:
    """Check the current status of a challenge (admin/debug)."""
    challenge = (
        await db.execute(
            select(RadiusChallenge).where(RadiusChallenge.state == state)
        )
    ).scalar_one_or_none()
    if not challenge:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Challenge bulunamadi")
    return {
        "id": str(challenge.id),
        "state": challenge.state,
        "username": challenge.username,
        "mfa_method": challenge.mfa_method,
        "verified": challenge.verified,
        "attempt_count": challenge.attempt_count,
        "expires_at": challenge.expires_at.isoformat() if challenge.expires_at else None,
        "consumed_at": challenge.consumed_at.isoformat() if challenge.consumed_at else None,
        "created_at": challenge.created_at.isoformat() if challenge.created_at else None,
    }
