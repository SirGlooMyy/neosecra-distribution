"""RADIUS business service layer — event management, FreeRADIUS config,
EAP sertifika yonetimi, baglanti testi ve istatistikler.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
import ipaddress
from datetime import datetime, timedelta, timezone
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.devices.models import RadiusClient
from app.modules.radius.eap_service import generate_eap_certs, get_cert_status

log = logging.getLogger(__name__)

_HAS_PYRAD = False
try:
    import pyrad.client
    import pyrad.packet
    import pyrad.dictionary

    _HAS_PYRAD = True
except ImportError:
    pass

EVENT_TYPES = ("Start", "Stop", "Interim-Update")


def _build_radius_scope_filter(scope: ScopeContext | None):
    """Build SQLAlchemy filter condition for RadiusEvent based on user scope."""
    if not scope or scope.level == TenantLevel.GLOBAL:
        return None
    if not scope.allowed:
        from sqlalchemy import false
        return false()

    from app.modules.customers.models import Customer
    from app.modules.locations.models import Location
    from app.modules.devices.models import RadiusClient
    from app.modules.radius.models import RadiusEvent
    from sqlalchemy import or_

    if scope.level == TenantLevel.LOCATION and scope.location_id:
        nas_ips = select(RadiusClient.nas_ip).where(
            RadiusClient.location_id == scope.location_id,
            RadiusClient.is_active.is_(True),
        )
        return RadiusEvent.nas_ip.in_(nas_ips)
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        nas_ips = (
            select(RadiusClient.nas_ip)
            .join(Location, Location.id == RadiusClient.location_id)
            .where(
                Location.customer_id == scope.customer_id,
                RadiusClient.is_active.is_(True),
            )
        )
        if scope.tenant_id:
            return or_(RadiusEvent.tenant_id == scope.tenant_id, RadiusEvent.nas_ip.in_(nas_ips))
        return RadiusEvent.nas_ip.in_(nas_ips)
    elif scope.level == TenantLevel.TENANT and scope.tenant_id:
        return RadiusEvent.tenant_id == scope.tenant_id
    elif scope.level == TenantLevel.PARTNER and scope.partner_id:
        cust_nas_ips = (
            select(RadiusClient.nas_ip)
            .join(Location, Location.id == RadiusClient.location_id)
            .join(Customer, Customer.id == Location.customer_id)
            .where(
                Customer.partner_id == scope.partner_id,
                RadiusClient.is_active.is_(True),
            )
        )
        return RadiusEvent.nas_ip.in_(cust_nas_ips)
    return None


async def get_radius_events(
    db: AsyncSession,
    scope: ScopeContext,
    *,
    limit: int = 100,
    offset: int = 0,
    username: str | None = None,
    acct_status: str | None = None,
) -> list:
    """RADIUS eventlerini scope'a gore listele."""
    from app.modules.radius.models import RadiusEvent

    q = select(RadiusEvent)
    cond = _build_radius_scope_filter(scope)
    if cond is not None:
        q = q.where(cond)
    if username:
        q = q.where(RadiusEvent.username == username)
    if acct_status and acct_status in EVENT_TYPES:
        q = q.where(RadiusEvent.acct_status_type == acct_status)
    q = q.order_by(RadiusEvent.created_at.desc()).offset(offset).limit(limit)
    res = await db.execute(q)
    return list(res.scalars().all())


async def get_radius_stats(db: AsyncSession, scope: ScopeContext | None = None) -> dict:
    """RADIUS dashboard istatistikleri — Master Prompt §8.6.

    Donus:
        total_events, unique_users, active_sessions, nas_list,
        hourly_trend (son 24s), last_event_at
    """
    from app.modules.radius.models import RadiusEvent

    scope_cond = _build_radius_scope_filter(scope)

    q_total = select(func.count()).select_from(RadiusEvent)
    q_users = select(func.count(RadiusEvent.username.distinct()))
    if scope_cond is not None:
        q_total = q_total.where(scope_cond)
        q_users = q_users.where(scope_cond)

    total = (await db.execute(q_total)).scalar_one()
    unique_users = (await db.execute(q_users)).scalar_one()

    # Son 24 saat event sayisi
    since = datetime.now(timezone.utc) - timedelta(hours=24)
    q_last_24h = select(func.count()).select_from(RadiusEvent).where(RadiusEvent.created_at >= since)
    if scope_cond is not None:
        q_last_24h = q_last_24h.where(scope_cond)
    last_24h = (await db.execute(q_last_24h)).scalar_one()

    # Event type dagilimi
    status_counts: dict[str, int] = {}
    for st in EVENT_TYPES:
        q_st = select(func.count()).select_from(RadiusEvent).where(RadiusEvent.acct_status_type == st)
        if scope_cond is not None:
            q_st = q_st.where(scope_cond)
        c = (await db.execute(q_st)).scalar_one()
        status_counts[st] = c

    # Aktif oturumlar: only the latest accounting event for each session is
    # authoritative. Counting every Start in a time window made completed
    # guests appear permanently online. Do not restrict this subquery to the
    # 24-hour window; a session started earlier can still be active now. Null
    # session IDs are excluded because they cannot be correlated safely with a
    # Stop packet.
    latest_stmt = (
        select(
            RadiusEvent.acct_session_id.label("session_id"),
            RadiusEvent.acct_status_type.label("status"),
            RadiusEvent.created_at.label("last_event_at"),
            func.row_number().over(
                partition_by=RadiusEvent.acct_session_id,
                order_by=(RadiusEvent.created_at.desc(), RadiusEvent.id.desc()),
            ).label("row_num"),
        )
        .where(
            RadiusEvent.acct_session_id.is_not(None),
            RadiusEvent.acct_session_id != "",
            RadiusEvent.acct_status_type.in_(EVENT_TYPES),
        )
    )
    if scope_cond is not None:
        latest_stmt = latest_stmt.where(scope_cond)
    latest = latest_stmt.subquery()

    fresh_interim_since = datetime.now(timezone.utc) - timedelta(
        seconds=max(60, settings.RADIUS_INTERIM_INTERVAL_SECONDS * 2)
    )
    active_sessions = (await db.execute(
        select(func.count()).select_from(latest).where(
            latest.c.row_num == 1,
            (
                ((latest.c.status == "Start") & (latest.c.last_event_at >= since))
                | (
                    (latest.c.status == "Interim-Update")
                    & (latest.c.last_event_at >= fresh_interim_since)
                )
            ),
        )
    )).scalar_one()

    # NAS listesi (benzersiz NAS IP'ler)
    nas_stmt = (
        select(RadiusEvent.nas_ip, func.count().label("evt_count"))
        .where(RadiusEvent.nas_ip.isnot(None), RadiusEvent.nas_ip != "")
    )
    if scope_cond is not None:
        nas_stmt = nas_stmt.where(scope_cond)
    nas_rows = (await db.execute(
        nas_stmt.group_by(RadiusEvent.nas_ip)
        .order_by(func.count().desc())
        .limit(20)
    )).all()

    nas_list = [
        {
            "nas_ip": row.nas_ip,
            "event_count": row.evt_count,
            "status": "online",
            "last_seen": None,
        }
        for row in nas_rows
    ]

    # Saatlik trend (son 24 saat)
    hourly_trend: list[dict] = []
    for h in range(24):
        t = since + timedelta(hours=h)
        t_next = t + timedelta(hours=1)
        h_stmt = select(func.count()).select_from(RadiusEvent).where(
            RadiusEvent.created_at >= t,
            RadiusEvent.created_at < t_next,
        )
        if scope_cond is not None:
            h_stmt = h_stmt.where(scope_cond)
        cnt = (await db.execute(h_stmt)).scalar_one()
        hourly_trend.append({
            "hour": t.strftime("%H:00"),
            "count": cnt,
        })

    recent_stmt = select(RadiusEvent)
    if scope_cond is not None:
        recent_stmt = recent_stmt.where(scope_cond)
    recent = (await db.execute(
        recent_stmt.order_by(RadiusEvent.created_at.desc()).limit(1)
    )).scalar_one_or_none()

    return {
        "total_events": total,
        "unique_usernames": unique_users,
        "last_24h_events": last_24h,
        "active_sessions": active_sessions,
        "by_status": status_counts,
        "nas_list": nas_list,
        "hourly_trend": hourly_trend,
        "last_event_at": recent.created_at.isoformat() if recent else None,
    }


async def get_freeradius_config(location_id: uuid.UUID, db: AsyncSession) -> str:
    """Belirtilen lokasyon icin FreeRADIUS config olustur.

    Args:
        location_id: Lokasyon UUID.
        db: Veritabani oturumu.

    Returns:
        FreeRADIUS config metni.
    """
    from app.modules.locations.models import Location

    loc = await db.get(Location, location_id)
    loc_name = loc.name if loc else "Unknown"

    q = select(RadiusClient).where(
        RadiusClient.location_id == location_id,
        RadiusClient.is_active,
    ).limit(1)
    rc = (await db.execute(q)).scalar_one_or_none()
    if not rc:
        return f"# {loc_name}: aktif RADIUS client bulunamadi"

    from app.modules.radius.enterprise_service import generate_freeradius_config as _gen
    return _gen(str(location_id), rc, location_name=loc_name)


async def generate_eap_certificates(location_id: uuid.UUID | None = None) -> dict:
    """EAP sertifika zinciri olustur. location_id opsiyonel (log icin).

    Args:
        location_id: Lokasyon UUID (opsiyonel).

    Returns:
        Sertifika dosya yollari.
    """
    san_dns = ["eap.hotspot.local"]
    if location_id:
        san_dns.append(f"eap-{str(location_id)[:8]}.hotspot.local")
    return generate_eap_certs(san_dns=san_dns)


async def get_certificate_status() -> dict:
    """Mevcut EAP sertifikalarinin durumunu don.

    Returns:
        Sertifika durum dict.
    """
    return get_cert_status()


async def test_radius_connection(nas_ip: str, shared_secret: str, *, port: int = 1812) -> bool:
    """RADIUS baglantisini gercek bir Access-Request paketi ile dene.

    pyrad kutuphanesi kullanarak RADIUS server'a (nas_ip:1812) bir
    Access-Request paketi gonderir ve yanit alirsa basarili sayar.

    Args:
        nas_ip: RADIUS server IP adresi.
        shared_secret: Shared secret.

    Returns:
        Baglanti basarili mi (yanit alindi mi).
    """
    if not nas_ip or not shared_secret:
        return False
    if len(shared_secret) < 4:
        return False
    if not _HAS_PYRAD:
        log.error("pyrad kurulu degil; RADIUS baglanti testi kullanilamaz")
        return False

    def _send_radius_packet() -> bool:
        try:
            secret_bytes: bytes = shared_secret.encode()
            srv = pyrad.client.Client(
                server=nas_ip,
                secret=secret_bytes,
                dict=pyrad.dictionary.Dictionary(str(Path(__file__).with_name("dictionary"))),
                authport=port,
                timeout=5,
            )
            req = srv.CreateAuthPacket(code=pyrad.packet.AccessRequest)
            req["User-Name"] = b"__hotspot_test__"
            try:
                ipaddress.ip_address(nas_ip)
                req["NAS-IP-Address"] = nas_ip
            except ValueError:
                pass
            reply = srv.SendPacket(req)
            # Any response (Access-Accept, Access-Reject, Access-Challenge) = alive
            log.info("RADIUS test paketi yaniti alindi: code=%s, nas_ip=%s", reply.code, nas_ip)
            return True
        except pyrad.client.Timeout:
            log.warning("RADIUS test paketi timeout: nas_ip=%s", nas_ip)
            return False
        except Exception:
            log.exception("RADIUS test paketi hatasi: nas_ip=%s", nas_ip)
            return False

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _send_radius_packet)
