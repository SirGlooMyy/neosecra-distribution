"""Firewall adapter orchestration service.

Bridges the persistence layer (Device + DeviceCredential) to the vendor-neutral
adapter ABC. Responsibilities:
  * load a device within the caller's scope (Mutlak Kural #1/#2)
  * decrypt credentials only here, hand them to the adapter as ConnectionConfig
    (Mutlak Kural #3 — secrets never leave this layer decrypted)
  * normalize adapter results and mirror runtime state back onto the Device row
  * retry with backoff for transient adapter failures

This module never imports a concrete vendor adapter directly — it goes through
the registry (Mutlak Kural #7).
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.crypto import decrypt
from app.core.tenant import ScopeContext
from app.modules.devices.models import Device, DeviceCredential
from app.modules.devices.service import get_device  # scoped device loader
from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
)
from app.modules.firewall_adapters.registry import (
    build_adapter,
    get_adapter_class,
    supported_vendors,
)

log = logging.getLogger(__name__)

ADAPTER_RETRY_COUNT = 3
ADAPTER_RETRY_BASE_DELAY = 1.0  # seconds


async def _call_with_retry(
    fn, *args, retries: int = ADAPTER_RETRY_COUNT, **kwargs,
) -> AdapterResult:
    """Call an adapter method with exponential backoff retry.

    Only retries on transient errors (HTTP 429, 503, connection errors).
    Permanent errors (4xx except 429) are returned immediately.
    """
    last_exc: Exception | None = None
    for attempt in range(1, retries + 1):
        try:
            result = await fn(*args, **kwargs)
            if result.ok or attempt == retries:
                return result
        except HTTPException:
            raise
        except Exception as exc:
            last_exc = exc
            if attempt < retries:
                delay = ADAPTER_RETRY_BASE_DELAY * (2 ** (attempt - 1))
                log.warning("adapter call attempt %d/%d failed: %s — retry in %.1fs", attempt, retries, exc, delay)
                await asyncio.sleep(delay)
    return AdapterResult(ok=False, message=str(last_exc or "unknown error"))


async def _load_credential(db: AsyncSession, device_id: uuid.UUID) -> DeviceCredential:
    cred = (
        await db.execute(
            select(DeviceCredential).where(DeviceCredential.device_id == device_id)
        )
    ).scalar_one_or_none()
    if not cred:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cihaz icin kimlik biligi (credential) tanimli degil",
        )
    return cred


async def build_connection_config(
    db: AsyncSession, device: Device, cred: DeviceCredential
) -> ConnectionConfig:
    """Decrypt secrets and assemble a ConnectionConfig for the adapter."""
    try:
        api_token = decrypt(cred.api_token_encrypted) if cred.api_token_encrypted else None
        ssh_key = decrypt(cred.ssh_key_encrypted) if cred.ssh_key_encrypted else None
    except Exception as exc:
        # Crypto errors must never become an opaque 500 or expose ciphertext,
        # key material, or a traceback to the admin browser.
        log.warning(
            "Firewall credential decrypt failed for device %s (%s)",
            device.id,
            type(exc).__name__,
        )
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Cihaz kimlik bilgileri çözülemedi; credential ve CRYPTO_KEY ayarlarını kontrol edin",
        ) from None
    return ConnectionConfig(
        vendor=device.vendor,
        api_host=device.api_host or "",
        api_port=device.api_port,
        api_token=api_token,
        api_username=cred.api_username,
        api_vdom=cred.api_vdom,
        verify_tls=cred.verify_tls,
        api_tls=(device.meta or {}).get("api_tls", True),
        ssh_key=ssh_key,
        extra=device.meta or {},
    )


async def get_adapter_for_device(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext
) -> tuple[Device, FirewallAdapter]:
    """Scoped device -> ready adapter. Caller must already be authorized to
    touch this device; get_device() enforces the scope filter."""
    device = await get_device(db, device_id, scope)
    cred = await _load_credential(db, device.id)
    config = await build_connection_config(db, device, cred)
    adapter = build_adapter(config)
    return device, adapter


async def test_connection_service(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext
) -> AdapterResult:
    """Live connection check; persists the result as a health signal."""
    device, adapter = await get_adapter_for_device(db, device_id, scope)
    try:
        result = await adapter.test_connection()
    except Exception as exc:
        # Keep unexpected vendor/library failures a controlled result.  The
        # caller can render the failed health signal without a 500 traceback.
        log.warning(
            "Firewall connection check failed for device %s (%s)",
            device.id,
            type(exc).__name__,
        )
        result = AdapterResult(ok=False, message="Cihaz bağlantı testi tamamlanamadı")

    cred = await _load_credential(db, device.id)
    cred.last_check_ok = result.ok
    cred.last_check_at = datetime.now(timezone.utc)
    device.last_seen_at = cred.last_check_at if result.ok else device.last_seen_at
    device.status = "online" if result.ok else "offline"
    await db.commit()
    return result


async def discover_device(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext
) -> dict:
    """Pull authoritative device info and mirror it onto the Device row."""
    device, adapter = await get_adapter_for_device(db, device_id, scope)
    info = await adapter.get_device_info()
    if info.get("serial_number"):
        device.serial_number = info["serial_number"]
    if info.get("firmware_version"):
        device.firmware_version = info["firmware_version"]
    if info.get("model"):
        device.model = info["model"]
    await db.commit()
    return info


async def authorize_guest_service(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext, session: dict
) -> AdapterResult:
    _, adapter = await get_adapter_for_device(db, device_id, scope)
    return await _call_with_retry(adapter.authorize_guest, session)


async def get_active_sessions_service(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext
) -> list[dict]:
    """Query the firewall device for active sessions."""
    _, adapter = await get_adapter_for_device(db, device_id, scope)
    return await adapter.get_active_sessions()


async def sync_session_with_device_service(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext, session: dict
) -> AdapterResult:
    """Sync a session with the device (authorize or revoke based on status)."""
    _, adapter = await get_adapter_for_device(db, device_id, scope)
    if session.get("status") in ("active", "pending"):
        return await _call_with_retry(adapter.authorize_guest, session)
    else:
        return await _call_with_retry(adapter.revoke_guest, session)
async def revoke_guest_service(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext, session: dict
) -> AdapterResult:
    _, adapter = await get_adapter_for_device(db, device_id, scope)
    return await _call_with_retry(adapter.revoke_guest, session)


async def get_device_capabilities(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext
) -> dict:
    """Return the FirewallCapabilities + device info for a given device."""
    device, adapter = await get_adapter_for_device(db, device_id, scope)
    caps = adapter.get_capabilities()
    return {
        "device_id": str(device.id),
        "device_name": device.name,
        "vendor": device.vendor,
        "model": device.model,
        "firmware_version": device.firmware_version,
        "status": device.status,
        "capabilities": caps.__dict__,
    }


async def list_vendor_capabilities() -> list[dict]:
    """List all supported vendors and their theoretical capabilities
    (no device context needed)."""
    results: list[dict] = []
    for vendor_slug in supported_vendors():
        cls = get_adapter_class(vendor_slug)
        dummy = cls(ConnectionConfig(vendor=vendor_slug, api_host=""))
        caps = dummy.get_capabilities()
        results.append({
            "vendor": vendor_slug,
            "display_name": vendor_slug.title(),
            "capabilities": caps.__dict__,
        })
    return results


async def parse_syslog(vendor: str, raw_event: str) -> dict:
    """Stateless syslog parse by vendor (no DB/device lookup needed). Used by
    the syslog ingest worker to normalize raw lines before correlation.

    parse_syslog_event does no I/O but is declared async to satisfy the ABC,
    so we await it like any other adapter call."""
    cls = get_adapter_class(vendor)
    adapter = cls(ConnectionConfig(vendor=vendor, api_host=""))
    return await adapter.parse_syslog_event(raw_event)
