"""FortiGate (FortiOS REST API) adapter.

Talks to the real FortiOS REST API at /api/v2/. Auth is a per-admin API token
carried as `Authorization: Bearer <token>` (FortiOS 7.0+ API token admin).
Secrets arrive already decrypted via ConnectionConfig — this adapter never
touches the DB or crypto layer (Mutlak Kural #7).

Guest authorization strategy implemented here: IP allowlist — the guest IP is
published as a FortiGate firewall address with a TTL, referenced by the
captive-portal-exempt policy. The RADIUS/COA strategy is layered on top in the
sessions module; this is the simplest real, testable mechanism and is
production-correct for external captive portal deployments.
"""
from __future__ import annotations

import shlex
import logging
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)

# FortiOS log_level → severity string mapping
_FORTISEVERITY_MAP: dict[str, str] = {
    # Keep FortiOS' canonical severity names.  The UI filters, reports and
    # 5651 exports use these values directly; collapsing them to high/medium/
    # low made warning/notice filters silently miss real firewall events.
    "emergency": "emergency",
    "alert": "alert",
    "critical": "critical",
    "error": "error",
    "warning": "warning",
    "notice": "notice",
    "information": "info",
    "info": "info",
    "debug": "info",
}

# FortiOS type → log_type mapping
_FORTITYPE_MAP: dict[str, str] = {
    "traffic": "traffic",
    "event": "event",
    "utm": "utm",
    "virus": "utm",
    "webfilter": "utm",
    "ips": "utm",
    "emailfilter": "utm",
    "application": "utm",
    "dlp": "utm",
    "anomaly": "anomaly",
    "wanopt": "event",
    "endpoint": "event",
    "voip": "event",
    "wifi": "event",
    "dhcp": "event",
    "system": "event",
    "router": "event",
    "vpn": "vpn",
    "auth": "event",
    "user": "event",
    "connector": "event",
    "cifs": "event",
    "nac": "event",
    "fabric": "event",
    "gtp": "event",
    "dns": "event",
    "ssh": "event",
    "ssl": "event",
    "scan": "utm",
    "forticast": "utm",
    "iap": "iap",
    "ztna": "event",
}

# FortiOS does not use one single type for VPN records.  In the default
# syslog format a tunnel event is normally ``type=event subtype=vpn`` while
# some FortiOS versions emit ``type=vpn`` or put the VPN name in eventtype.
# Keep this list deliberately small and explicit so ordinary traffic logs
# containing a VPN-related service are not reclassified by accident.
_VPN_SUBTYPES = {"vpn", "ssl-vpn", "sslvpn", "ipsec", "ipsec-vpn"}


def _is_vpn_event(fields: dict[str, Any], fgt_type: str, subtype: str | None) -> bool:
    """Return whether a FortiGate key/value record represents a VPN event."""
    if fgt_type == "vpn" or (subtype and subtype in _VPN_SUBTYPES):
        return True
    event_type = str(fields.get("eventtype") or fields.get("event_type") or "").lower()
    action = str(fields.get("action") or "").lower()
    logdesc = str(fields.get("logdesc") or "").lower()
    srcintf = str(fields.get("srcintf") or "").lower()
    dstintf = str(fields.get("dstintf") or "").lower()
    policyname = str(fields.get("policyname") or "").lower()

    if "ssl.root" in srcintf or "ssl.root" in dstintf or "vpntunnel" in srcintf:
        return True
    if "sslvpn" in policyname:
        return True
    # Tunnel lifecycle actions are emitted by both SSL-VPN and IPsec.
    if any(token in action for token in ("tunnel", "ipsec", "ssl-vpn", "tunnel-up", "tunnel-down", "ssl-login")):
        return True
    if any(token in event_type for token in ("vpn", "tunnel", "ipsec", "ssl-vpn")):
        return True
    return any(token in logdesc for token in (" vpn", "ssl vpn", "ipsec"))


def _canonical_log_type(fgt_type: str, subtype: str | None, fields: dict[str, Any]) -> str:
    """Map FortiOS type/subtype pairs to the analyzer's stable categories."""
    if _is_vpn_event(fields, fgt_type, subtype):
        return "vpn"
    # UTM records carry the useful analyzer category in ``subtype``.
    if fgt_type in {"utm", "webfilter"} and subtype == "webfilter":
        return "webfilter"
    if fgt_type in {"utm", "application", "app-ctrl"} and subtype in {"app-ctrl", "application"}:
        return "app-ctrl"
    if (fgt_type == "utm" and subtype == "dns") or fgt_type == "dns":
        return "dns"
    return _FORTITYPE_MAP.get(fgt_type, "unknown")

class AdapterError(RuntimeError):
    """Raised when the device API returns an unrecoverable error."""

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


log = logging.getLogger(__name__)


def _result_items(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Normalize FortiOS ``results`` envelopes.

    FortiOS returns a list for collection endpoints, but monitor endpoints
    commonly return a single object.  Treat both forms uniformly so a valid
    device response never becomes ``KeyError: 0`` or an iteration over dict
    keys.
    """
    results = data.get("results") if isinstance(data, dict) else None
    if isinstance(results, dict):
        # Some monitor responses wrap the actual payload one level deeper.
        nested = results.get("results")
        if isinstance(nested, list):
            return [item for item in nested if isinstance(item, dict)]
        return [results]
    if isinstance(results, list):
        return [item for item in results if isinstance(item, dict)]
    return []


class FortiGateAdapter(FirewallAdapter):
    vendor = "fortigate"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        #
        # NOTE: The simulator (fake_fortigate_server.py) runs as plain HTTP.
        #       When testing against the simulator via Docker Compose, tests
        #       override self._base_url to use http://. The production default
        #       of HTTPS is intentionally preserved here — do NOT change it.
        #
        self._base_url = f"{'https' if (getattr(config, 'api_tls', True)) else 'http'}://{config.api_host}:{port}/api/v2"
        self._headers = {"Authorization": f"Bearer {config.api_token}"} if config.api_token else {}

    # ---- low-level transport -------------------------------------------
    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 15.0,
    ) -> dict[str, Any]:
        params = dict(params or {})
        if self.config.api_vdom:
            params.setdefault("vdom", self.config.api_vdom)
        url = f"{self._base_url}/{path.lstrip('/')}"
        # NOTE: TLS verification uses self.config.verify_tls (default True).
        #       See ConnectionConfig.__post_init__ for security warnings.
        #       NEVER log API tokens or certificate content (Mutlak Kural #3).
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"FortiGate {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}",
                status_code=resp.status_code,
            )
        data = resp.json()
        # FortiOS envelopes responses with {"http_status":..., "results":[...], ...}
        # and an error body when the call logically fails (e.g. HTTP 200 + error).
        if isinstance(data, dict) and data.get("error") not in (None, 0, "0"):
            msg = (data.get("errmessage") or data.get("error_message") or "fortios logical error")
            raise AdapterError(f"FortiGate {path}: {msg}", status_code=data.get("http_status"))
        return data

    # ---- capability / discovery ----------------------------------------
    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=True,
            radius_authentication=True,
            radius_accounting=True,
            radius_coa=True,
            disconnect_message=True,
            mac_auth_bypass=True,
            local_guest_users=True,
            active_session_query=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    # ---- connection / discovery ----------------------------------------
    async def test_connection(self) -> AdapterResult:
        try:
            data = await self._request("GET", "monitor/system/status")
            items = _result_items(data)
            r = items[0] if items else {}
            hostname = r.get("hostname") or r.get("Hostname") or "FortiGate"
            model = r.get("model") or r.get("model_number") or r.get("model_name")
            version = r.get("version") or r.get("firmware") or r.get("os_version")
            identity = " ".join(str(value) for value in (hostname, model, version) if value)
            return AdapterResult(
                ok=True,
                message=f"connected: {identity or 'FortiGate'}",
                data=r,
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))
        except Exception as exc:
            log.exception("FortiGate connection check failed")
            return AdapterResult(ok=False, message=f"FortiGate yaniti islenemedi: {exc}")

    async def get_device_info(self) -> dict[str, Any]:
        data = await self._request("GET", "monitor/system/status")
        items = _result_items(data)
        r = items[0] if items else {}
        # FortiOS monitor responses may expose identity fields at the top
        # level (or use capitalized keys) instead of inside ``results``.
        def _first(*keys: str) -> Any:
            for key in keys:
                value = r.get(key)
                if value in (None, "") and isinstance(data, dict):
                    value = data.get(key)
                if value not in (None, ""):
                    return value
            return None

        return {
            "hostname": _first("hostname", "Hostname"),
            "model": _first("model", "model_name", "model_number", "Platform", "platform"),
            "serial_number": _first(
                "serial", "Serial", "serial_number", "serial-number", "Serial Number", "sn"
            ),
            "firmware_version": _first(
                "version", "Version", "firmware_version", "firmware", "os_version", "os-version"
            ),
            "bios_version": _first("bios_version", "bios", "bios-version"),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "cmdb/system/interface")
        results = _result_items(data)
        return [
            {
                "name": i.get("name"),
                "type": i.get("type"),
                "ip": i.get("ip"),
                "vdom": i.get("vdom"),
                "status": "up" if i.get("status") else "down",
            }
            for i in results
        ]

    async def get_captive_portal_config(self) -> dict[str, Any]:
        """Read user groups used by the captive-portal policy (informational)."""
        data = await self._request("GET", "cmdb/user/group")
        groups = [
            {"name": g.get("name"), "members": len(g.get("member") or [])}
            for g in _result_items(data)
        ]
        return {"user_groups": groups}

    # ---- guest session lifecycle ---------------------------------------
    async def get_active_sessions(self) -> list[dict[str, Any]]:
        try:
            data = await self._request("GET", "monitor/user/fsso/list")
        except AdapterError as exc:
            # Authentication/authorization failures are actionable and must
            # reach the caller (otherwise the UI shows a misleading empty
            # session list while the device credentials are broken). Optional
            # monitor feeds may still be absent on a healthy FortiGate.
            if exc.status_code in {401, 403}:
                raise
            log.warning("FortiGate active-session feed unavailable: %s", exc)
            return []
        except httpx.HTTPError as exc:
            # FSSO is optional on FortiGate and is often disabled for a fresh
            # appliance.  Treat an unavailable monitor feed as an empty
            # snapshot instead of turning a harmless UI refresh into HTTP 500.
            log.warning("FortiGate active-session feed unavailable: %s", exc)
            return []
        return [
            {
                "ip": u.get("ip"),
                "user": u.get("name"),
                "mac": u.get("mac"),
                "group": u.get("groups"),
            }
            for u in _result_items(data)
        ]

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        try:
            data = await self._request("GET", "monitor/firewall/ipv4-list")
        except (AdapterError, httpx.HTTPError) as exc:
            log.warning("FortiGate IP/MAC feed unavailable: %s", exc)
            return []
        return [
            {"ip": r.get("ip"), "mac": r.get("mac"), "interface": r.get("interface")}
            for r in _result_items(data)
        ]

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        """Allowlist the guest IP for the session duration.

        Creates a firewall address named `hsess-<session_id>` with a comment
        carrying the session id; the captive-portal-exempt policy matches it.
        Re-creating is idempotent because we PUT by name.
        """
        ip = session.get("ip")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        payload = {
            "name": name,
            "type": "ipmask",
            "subnet": f"{ip} 255.255.255.255",
            "comment": self._guest_comment(session),
        }
        try:
            try:
                await self._request("POST", "cmdb/firewall/address", json=payload)
            except AdapterError as exc:
                # Existing names are reported as 400/409 (or 405/500 by
                # compatible appliances); these are safe idempotent updates.
                if exc.status_code not in {400, 405, 409, 500}:
                    raise
                await self._request("PUT", f"cmdb/firewall/address/{name}", json=payload)

            group_name = (
                session.get("group_name")
                or (session.get("group_policy") or {}).get("group_name")
                or self.config.extra.get("fortigate_address_group")
                or self.config.extra.get("fortigate_guest_address_group")
                or "Guest"
            )
            if group_name:
                try:
                    await self._ensure_address_group(str(group_name), name)
                    if str(group_name) != "hotspot-allowed":
                        await self._ensure_address_group("hotspot-allowed", name)
                    await self._ensure_exempt_list(name)
                    await self._ensure_bandwidth_shaper(
                        str(group_name),
                        policy.get("bandwidth_down"),
                        policy.get("bandwidth_up"),
                        policy.get("max_sessions"),
                    )
                except Exception as exc:
                    log.warning("Could not add %s to address group %s: %s", name, group_name, exc)
            return AdapterResult(
                ok=True,
                message=f"allowed {ip}",
                data={"address": name, "policy": policy, "address_group": group_name},
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def _ensure_bandwidth_shaper(
        self,
        group_name: str,
        bandwidth_down_kbps: int | None,
        bandwidth_up_kbps: int | None,
        max_sessions: int | None = None,
    ) -> None:
        """Create or update FortiOS per-ip-shaper and shaping-policy for the group."""
        down_kbps = bandwidth_down_kbps or 10240
        shaper_name = f"{group_name}-{int(down_kbps // 1024)}M"

        shaper_payload = {
            "name": shaper_name,
            "max-bandwidth": down_kbps,
            "max-concurrent-session": 0,
            "max-concurrent-tcp-session": 0,
            "max-concurrent-udp-session": 0,
        }
        try:
            try:
                await self._request("POST", "cmdb/firewall.shaper/per-ip-shaper", json=shaper_payload)
            except AdapterError as exc:
                if exc.status_code in {400, 405, 409, 500}:
                    await self._request("PUT", f"cmdb/firewall.shaper/per-ip-shaper/{shaper_name}", json=shaper_payload)
        except Exception as exc:
            log.debug("Per-IP Shaper check/create failed: %s", exc)

        policy_name = f"{group_name}-Limit"
        shaping_policy_payload = {
            "name": policy_name,
            "srcaddr": [{"name": group_name}],
            "dstaddr": [{"name": "all"}],
            "service": [{"name": "ALL"}],
            "per-ip-shaper": shaper_name,
            "status": "enable",
        }
        try:
            res = await self._request("GET", "cmdb/firewall/shaping-policy")
            policies = res.get("results") or []
            existing_id = None
            for p in policies:
                if p.get("name") == policy_name or any(sa.get("name") == group_name for sa in (p.get("srcaddr") or [])):
                    existing_id = p.get("id") or p.get("q_origin_key")
                    break

            if existing_id is not None:
                await self._request("PUT", f"cmdb/firewall/shaping-policy/{existing_id}", json=shaping_policy_payload)
            else:
                await self._request("POST", "cmdb/firewall/shaping-policy", json=shaping_policy_payload)
        except Exception as exc:
            log.debug("Shaping policy check/create failed: %s", exc)

    async def _ensure_exempt_list(self, address_name: str | None = None) -> None:
        """Ensure security-exempt-list has rules for authorized guests."""
        try:
            r = await self._request("GET", "cmdb/user/security-exempt-list/Guest1-exempt-list")
            rules = (r.get("results") or [{}])[0].get("rule") or []
            target_srcs = ["Guest", "hotspot-allowed"]
            if address_name:
                target_srcs.append(address_name)

            rule_3 = None
            for rule in rules:
                src_names = [sa.get("name") for sa in (rule.get("srcaddr") or [])]
                if "Guest" in src_names or "hotspot-allowed" in src_names or (address_name and address_name in src_names):
                    rule_3 = rule
                    break

            if rule_3 is not None:
                current_srcs = [sa.get("name") for sa in (rule_3.get("srcaddr") or []) if sa.get("name")]
                updated = list(dict.fromkeys(current_srcs + target_srcs))
                rule_id = rule_3.get("id") or rule_3.get("q_origin_key")
                await self._request(
                    "PUT",
                    f"cmdb/user/security-exempt-list/Guest1-exempt-list/rule/{rule_id}",
                    json={
                        "id": rule_id,
                        "srcaddr": [{"name": n} for n in updated],
                        "dstaddr": [{"name": "all"}],
                        "service": [{"name": "ALL"}],
                    },
                )
            else:
                next_id = max([int(rule.get("id", 0)) for rule in rules] + [0]) + 1
                await self._request(
                    "POST",
                    "cmdb/user/security-exempt-list/Guest1-exempt-list/rule",
                    json={
                        "id": next_id,
                        "srcaddr": [{"name": n} for n in target_srcs],
                        "dstaddr": [{"name": "all"}],
                        "service": [{"name": "ALL"}],
                    },
                )
        except Exception as exc:
            log.debug("Exempt list check skipped or failed: %s", exc)

    async def _ensure_address_group(self, group_name: str, address_name: str) -> None:
        """Add an address to a FortiGate address group, creating it if not present."""
        try:
            data = await self._request("GET", f"cmdb/firewall/addrgrp/{group_name}")
            items = _result_items(data)
            group = items[0] if items else {}
            members = group.get("member") or []
        except AdapterError as exc:
            if exc.status_code == 404:
                # Group does not exist on FortiGate yet; create it!
                await self._request("POST", "cmdb/firewall/addrgrp", json={"name": group_name, "member": [{"name": address_name}], "comment": f"NeoSecra Hotspot Group: {group_name}"})
                return
            raise

        normalized: list[dict[str, str]] = []
        seen: set[str] = set()
        for member in members if isinstance(members, list) else []:
            member_name = member if isinstance(member, str) else (member or {}).get("name")
            if member_name and str(member_name) not in seen:
                normalized.append({"name": str(member_name)})
                seen.add(str(member_name))
        if address_name not in seen:
            normalized.append({"name": address_name})
        await self._request(
            "PUT",
            f"cmdb/firewall/addrgrp/{group_name}",
            json={"name": group_name, "member": normalized},
        )

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        session_name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            addr_names: set[str] = {session_name}
            if ip:
                try:
                    data = await self._request("GET", "cmdb/firewall/address")
                    for item in _result_items(data):
                        item_subnet = str(item.get("subnet") or "")
                        item_name = str(item.get("name") or "")
                        if item_subnet.startswith(f"{ip} ") or item_subnet == f"{ip}/32" or item_subnet == ip:
                            addr_names.add(item_name)
                except AdapterError as exc:
                    # A missing collection endpoint is harmless for an
                    # already-cleaned session; an auth/device failure is not.
                    if exc.status_code in {401, 403} or exc.status_code not in {404, 405}:
                        return AdapterResult(ok=False, message=str(exc))
                except httpx.HTTPError as exc:
                    return AdapterResult(ok=False, message=str(exc))
                except Exception as exc:
                    return AdapterResult(ok=False, message=str(exc))

            group_name = (
                session.get("group_name")
                or self.config.extra.get("fortigate_address_group")
                or self.config.extra.get("fortigate_guest_address_group")
                or "Guest"
            )
            groups_to_clean = {str(group_name), "Guest", "hotspot-allowed"}

            for grp in groups_to_clean:
                for a_name in addr_names:
                    try:
                        await self._remove_from_address_group(grp, a_name)
                    except AdapterError as exc:
                        # Groups are optional and may not exist; all other
                        # errors (especially 401/403) must be reported.
                        if exc.status_code not in {404, 405}:
                            return AdapterResult(ok=False, message=str(exc))
                    except httpx.HTTPError as exc:
                        return AdapterResult(ok=False, message=str(exc))
                    except Exception as exc:
                        return AdapterResult(ok=False, message=str(exc))

            for a_name in addr_names:
                try:
                    await self._request("DELETE", f"cmdb/firewall/address/{a_name}")
                except AdapterError as exc:
                    # DELETE is idempotent: an already missing object is a
                    # successful revoke, but device/auth errors are not.
                    if exc.status_code not in {404}:
                        return AdapterResult(ok=False, message=str(exc))
                except httpx.HTTPError as exc:
                    return AdapterResult(ok=False, message=str(exc))
                except Exception as exc:
                    return AdapterResult(ok=False, message=str(exc))

            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def _remove_from_address_group(self, group_name: str, address_name: str) -> None:
        """Remove an address from its policy group before deleting it."""
        data = await self._request("GET", f"cmdb/firewall/addrgrp/{group_name}")
        items = _result_items(data)
        group = items[0] if items else {}
        members = group.get("member") or []
        remaining: list[dict[str, str]] = []
        for member in members if isinstance(members, list) else []:
            member_name = member if isinstance(member, str) else (member or {}).get("name")
            if member_name and str(member_name) != address_name:
                remaining.append({"name": str(member_name)})
        await self._request(
            "PUT",
            f"cmdb/firewall/addrgrp/{group_name}",
            json={"name": group_name, "member": remaining},
        )

    # ---- log ingestion -------------------------------------------------
    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        """Delegate to module-level parse_syslog_event."""
        return parse_syslog_event(raw_event)


def parse_syslog_event(raw_event: str) -> dict[str, Any]:
    """FortiGate syslog key=value parser. Safe to call without a device.

    Returns enriched dict with:
      vendor, raw, device_name, device_id, event_type, event_subtype,
      log_type, log_subtype, severity, src_ip, dst_ip, src_port, dst_port,
      action, duration, sentbyte, rcvdbyte, session_id, user, policyid,
      proto, service, parsed_fields (all key=value pairs).
    """
    line = raw_event.strip()
    # Strip leading <PRI> token if present.
    if line.startswith("<"):
        gt = line.find(">")
        if gt != -1:
            line = line[gt + 1:]
    parsed: dict[str, Any] = {"vendor": "fortigate"}
    try:
        for tok in shlex.split(line, posix=True):
            if "=" in tok:
                k, _, v = tok.partition("=")
                parsed[k.lower()] = v
    except ValueError:
        for tok in line.split():
            if "=" in tok:
                k, _, v = tok.partition("=")
                parsed[k.lower()] = v

    # Determine log_type from FortiGate type field
    fgt_type = parsed.get("type", "").lower() if parsed.get("type") else "unknown"
    log_subtype = parsed.get("subtype", "").lower() if parsed.get("subtype") else None
    is_vpn = _is_vpn_event(parsed, fgt_type, log_subtype)
    log_type = _canonical_log_type(fgt_type, log_subtype, parsed)

    # Severity mapping
    sev_raw = parsed.get("level", "").lower() if parsed.get("level") else "info"
    severity = _FORTISEVERITY_MAP.get(sev_raw, "info")

    # Numeric conversions
    def _int(v: Any) -> int | None:
        try:
            return int(v)
        except (ValueError, TypeError):
            return None

    duration = _int(parsed.get("duration"))
    sentbyte = _int(parsed.get("sentbyte")) or _int(parsed.get("sentpkt"))
    rcvdbyte = _int(parsed.get("rcvdbyte")) or _int(parsed.get("rcvdpkt"))
    policyid = _int(parsed.get("policyid"))

    # Session ID — try sessionid, then logid, then use a derived key
    session_id = (
        parsed.get("sessionid")
        or parsed.get("logid")
        or (parsed.get("tunnelid") if is_vpn else None)
    )
    src_port = _int(parsed.get("srcport") or parsed.get("src_port"))
    dst_port = _int(parsed.get("dstport") or parsed.get("dst_port"))

    def _first(*keys: str) -> Any:
        for key in keys:
            value = parsed.get(key)
            if value not in (None, "", "-", "N/A"):
                return value
        return None

    result: dict[str, Any] = {
        "vendor": "fortigate",
        "device_name": parsed.get("devname"),
        "device_id": parsed.get("devid"),
        "event_type": fgt_type,
        "event_subtype": log_subtype,
        # Normalize all FortiOS VPN variants to the analyzer's VPN category;
        # the original type/subtype remain available in parsed_fields.
        "log_type": log_type,
        "log_subtype": log_subtype,
        "severity": severity,
        "action": _first("action", "eventtype", "status"),
        # VPN records use remip/tunnelip (or assignip) instead of srcip/dstip.
        "src_ip": _first("srcip", "src_ip", "remip", "remoteip", "peerip", "peer_ip", "src"),
        "dst_ip": _first("dstip", "dst_ip", "tunnelip", "assignip", "virtualip", "dst"),
        "src_port": src_port,
        "dst_port": dst_port,
        "proto": _first("proto", "protocol"),
        "service": _first("service", "app", "application", "tunneltype"),
        "user": _first("user", "username", "unauthuser", "user_name"),
        "policyid": policyid,
        "duration": duration,
        "sentbyte": sentbyte,
        "rcvdbyte": rcvdbyte,
        "session_id": session_id,
        "raw": raw_event,
        "parsed_fields": parsed,
    }
    return result
