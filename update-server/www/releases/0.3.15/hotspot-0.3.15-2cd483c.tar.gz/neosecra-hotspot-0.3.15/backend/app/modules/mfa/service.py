"""MFA business logic: TOTP setup/verify, SMS/email/WhatsApp code,
backup codes, status queries."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import demo_mode_enabled, settings
from app.core.crypto import decrypt, encrypt
from app.modules.mfa.models import (
    MFA_ACTION_BACKUP_USED,
    MFA_ACTION_DISABLED,
    MFA_ACTION_ENABLED,
    MFA_ACTION_FAILED,
    MFA_ACTION_VERIFIED,
    MfaLog,
    MfaSession,
    MfaToken,
)

log = logging.getLogger(__name__)

try:
    import pyotp  # type: ignore[import-not-found]
    HAS_PYOTP = True
except ImportError:
    HAS_PYOTP = False
    log.warning("pyotp not installed; TOTP operations will use mock fallback")


# ---- helpers ----------------------------------------------------------------
def _generate_code(length: int = 6) -> str:
    return str(secrets.randbelow(10**length)).zfill(length)


def _constant_time_eq(a: str, b: str) -> bool:
    return hmac.compare_digest(a, b)


def _hash_code(code: str) -> str:
    return hashlib.sha256(code.encode()).hexdigest()


def _backup_code() -> str:
    return secrets.token_hex(6)


def _require_demo_or_raise(reason: str) -> None:
    if demo_mode_enabled():
        log.warning("%s; demo fallback active", reason)
        return
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=reason,
    )


# ---- TOTP -------------------------------------------------------------------
async def setup_totp(
    db: AsyncSession,
    user_id: uuid.UUID,
    request: Request | None = None,
) -> dict:
    existing = (
        await db.execute(
            select(MfaToken).where(
                MfaToken.user_id == user_id,
                MfaToken.mfa_type == "totp",
                MfaToken.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="TOTP zaten aktif. Devre disi birakip tekrar deneyin.",
        )

    if HAS_PYOTP:
        secret = pyotp.random_base32()  # type: ignore[union-attr]
        totp = pyotp.TOTP(secret)  # type: ignore[union-attr]
        qr_uri = totp.provisioning_uri(
            name=str(user_id),
            issuer_name=settings.MFA_TOTP_ISSUER,
        )
    else:
        _require_demo_or_raise("pyotp not installed")
        secret = secrets.token_hex(16)
        qr_uri = f"otpauth://totp/{settings.MFA_TOTP_ISSUER}:{user_id}?secret={secret}&issuer={settings.MFA_TOTP_ISSUER}"

    backup_codes = [_backup_code() for _ in range(8)]
    backup_hashed = [_hash_code(c) for c in backup_codes]

    token = MfaToken(
        user_id=user_id,
        mfa_type="totp",
        secret_encrypted=encrypt(secret),
        is_active=False,
        backup_codes_encrypted=encrypt(json.dumps(backup_hashed)),
    )
    db.add(token)
    await db.flush()

    await log_mfa_action(db, user_id, MFA_ACTION_ENABLED, {"method": "totp", "step": "setup"}, request)

    return {
        "secret": secret,
        "qr_code_uri": qr_uri,
        "backup_codes": backup_codes,
    }


async def verify_totp(db: AsyncSession, user_id: uuid.UUID, code: str) -> bool:
    token = (
        await db.execute(
            select(MfaToken).where(
                MfaToken.user_id == user_id,
                MfaToken.mfa_type == "totp",
                MfaToken.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    if not token:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="TOTP aktif degil. Once kurulum yapin.",
        )

    secret = decrypt(token.secret_encrypted)

    if HAS_PYOTP:
        totp = pyotp.TOTP(secret)  # type: ignore[union-attr]
        valid = totp.verify(code, valid_window=1)
    else:
        _require_demo_or_raise("pyotp not installed")
        valid = _constant_time_eq(code, _generate_code(6))

    if valid:
        token.last_used_at = datetime.now(timezone.utc)
        await db.flush()
        await log_mfa_action(db, user_id, MFA_ACTION_VERIFIED, {"method": "totp"}, None)

    return valid


async def activate_totp(db: AsyncSession, user_id: uuid.UUID, code: str) -> bool:
    token = (
        await db.execute(
            select(MfaToken).where(
                MfaToken.user_id == user_id,
                MfaToken.mfa_type == "totp",
                MfaToken.is_active.is_(False),
            )
        )
    ).scalar_one_or_none()
    if not token:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Once TOTP kurulumu baslatin.",
        )

    secret = decrypt(token.secret_encrypted)

    if HAS_PYOTP:
        totp = pyotp.TOTP(secret)  # type: ignore[union-attr]
        valid = totp.verify(code, valid_window=1)
    else:
        _require_demo_or_raise("pyotp not installed")
        valid = _constant_time_eq(code, _generate_code(6))

    if not valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Gecersiz dogrulama kodu",
        )

    token.is_active = True
    token.last_used_at = datetime.now(timezone.utc)
    await db.flush()

    from app.modules.auth.models import User
    user = await db.get(User, user_id)
    if user:
        user.mfa_required = True
        if "totp" not in (user.mfa_methods or []):
            methods = list(user.mfa_methods or [])
            methods.append("totp")
            user.mfa_methods = methods
        await db.flush()

    await log_mfa_action(db, user_id, MFA_ACTION_ENABLED, {"method": "totp", "step": "activated"}, None)

    return True


# ---- MFA code send/verify (SMS, Email, WhatsApp) ----------------------------
async def send_mfa_code(
    db: AsyncSession,
    user_id: uuid.UUID,
    method: str,
    request: Request | None = None,
) -> str:
    if method not in ("sms", "email", "whatsapp"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Desteklenmeyen MFA yontemi: {method}",
        )

    from app.modules.auth.models import User

    user = await db.get(User, user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kullanici bulunamadi",
        )

    code = _generate_code(settings.MFA_CODE_LENGTH)
    code_hash = _hash_code(code)
    session_token = secrets.token_urlsafe(32)

    delivered = False
    delivery_note = ""
    if method == "sms":
        if demo_mode_enabled():
            log.warning("SMS MFA demo fallback for user %s", user_id)
            delivered = True
            delivery_note = "demo"
        else:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="SMS MFA icin dogrudan teslimat altyapisi yok",
            )
    elif method == "email":
        if not user.email and not demo_mode_enabled():
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Kullanici e-posta adresi bulunamadi",
            )
        if user.email:
            from app.modules.system.email_service import send_email
            from app.modules.radius.challenge_service import _render_otp_email

            email_html = _render_otp_email(
                username=user.username,
                code=code,
                title="MFA Giriş Doğrulama Kodu",
                gateway="Hotspot & Portal Erişimi",
            )
            delivered = await send_email(
                to=user.email,
                subject=f"🔐 Giriş Doğrulama Kodu: {code}",
                html_body=email_html,
                customer_id=user.customer_id,
                db=db,
            )
            delivery_note = user.email
            if not delivered:
                if demo_mode_enabled():
                    log.warning("Email MFA demo fallback for user %s", user_id)
                    delivered = True
                else:
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                        detail="E-posta MFA teslimati basarisiz",
                    )
        else:
            if demo_mode_enabled():
                log.warning("Email MFA demo fallback for user %s (no email address)", user_id)
                delivered = True
                delivery_note = "demo"
            else:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Kullanici e-posta adresi bulunamadi",
                )
    elif method == "whatsapp":
        if demo_mode_enabled():
            log.warning("WhatsApp MFA demo fallback for user %s", user_id)
            delivered = True
            delivery_note = "demo"
        else:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="WhatsApp MFA icin dogrudan teslimat altyapisi yok",
            )

    if not delivered:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="MFA kodu teslim edilemedi",
        )

    session = MfaSession(
        user_id=user_id,
        session_token=session_token,
        mfa_type=method,
        code_hash=code_hash,
        attempt_count=0,
        verified=False,
        expires_at=datetime.now(timezone.utc) + timedelta(seconds=settings.MFA_CODE_TTL_SECONDS),
    )
    db.add(session)

    # Never put even a one-way OTP hash in the audit payload: six-digit codes
    # are low entropy and hashes can be brute-forced from retained logs.
    details = {"method": method}
    if delivery_note:
        details["delivery_note"] = delivery_note
    await log_mfa_action(db, user_id, f"code_sent_{method}", details, request)
    await db.flush()
    # Persist the challenge and audit event before returning the token. The
    # request-scoped DB dependency does not commit automatically.
    await db.commit()

    # Never log OTP values. Six-digit codes are brute-forceable from retained
    # logs even when a one-way hash is used.
    log.info("MFA code queued for user %s via %s", user_id, method)

    return session_token


async def verify_mfa_code(
    db: AsyncSession,
    session_token: str,
    code: str,
    request: Request | None = None,
) -> bool:
    session = (
        await db.execute(
            select(MfaSession).where(
                MfaSession.session_token == session_token,
                MfaSession.verified.is_(False),
                MfaSession.consumed_at.is_(None),
                MfaSession.expires_at > datetime.now(timezone.utc),
            ).with_for_update()
        )
    ).scalar_one_or_none()

    if not session:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="MFA oturumu gecersiz veya sureci dolmus",
        )

    # A challenge without a verifier-side hash is a legacy/incomplete record;
    # fail closed instead of accepting any submitted code.
    session.attempt_count = (session.attempt_count or 0) + 1
    if session.attempt_count > 5 or not session.code_hash:
        session.consumed_at = datetime.now(timezone.utc)
        await db.flush()
        await log_mfa_action(db, session.user_id, MFA_ACTION_FAILED, {"method": session.mfa_type}, request)
        await db.commit()
        return False

    expected_hash = session.code_hash
    if not _constant_time_eq(_hash_code(code), expected_hash):
        if session.attempt_count >= 5:
            session.consumed_at = datetime.now(timezone.utc)
        await db.flush()
        await log_mfa_action(db, session.user_id, MFA_ACTION_FAILED, {"method": session.mfa_type}, request)
        await db.commit()
        return False

    session.verified = True
    session.consumed_at = datetime.now(timezone.utc)
    await db.flush()

    await log_mfa_action(db, session.user_id, MFA_ACTION_VERIFIED, {"method": session.mfa_type}, request)
    await db.commit()

    return True


# ---- Backup codes -----------------------------------------------------------
async def generate_backup_codes(db: AsyncSession, user_id: uuid.UUID) -> list[str]:
    codes = [_backup_code() for _ in range(8)]
    hashed = [_hash_code(c) for c in codes]

    token = (
        await db.execute(
            select(MfaToken).where(
                MfaToken.user_id == user_id,
                MfaToken.is_active.is_(True),
            ).with_for_update()
        )
    ).scalars().first()
    if token:
        token.backup_codes_encrypted = encrypt(json.dumps(hashed))
        await db.flush()

    return codes


async def verify_backup_code(
    db: AsyncSession,
    user_id: uuid.UUID,
    code: str,
    request: Request | None = None,
) -> bool:
    token = (
        await db.execute(
            select(MfaToken).where(
                MfaToken.user_id == user_id,
                MfaToken.is_active.is_(True),
            )
        )
    ).scalars().first()
    if not token or not token.backup_codes_encrypted:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Yedek kod bulunamadi",
        )

    hashed_codes: list[str] = json.loads(decrypt(token.backup_codes_encrypted))
    code_hash = _hash_code(code)

    for i, hc in enumerate(hashed_codes):
        if _constant_time_eq(code_hash, hc):
            hashed_codes.pop(i)
            token.backup_codes_encrypted = encrypt(json.dumps(hashed_codes))
            await db.flush()

            await log_mfa_action(db, user_id, MFA_ACTION_BACKUP_USED, {}, request)
            await db.commit()
            return True

    await log_mfa_action(db, user_id, MFA_ACTION_FAILED, {"method": "backup_code"}, request)
    await db.commit()
    return False


# ---- Status & disable -------------------------------------------------------
async def get_mfa_status(db: AsyncSession, user_id: uuid.UUID) -> dict:
    from app.modules.auth.models import User

    user = await db.get(User, user_id)
    tokens = (
        await db.execute(
            select(MfaToken).where(
                MfaToken.user_id == user_id,
                MfaToken.is_active.is_(True),
            )
        )
    ).scalars().all()

    methods = [t.mfa_type for t in tokens]
    backup_remaining = 0
    for t in tokens:
        if t.backup_codes_encrypted:
            backup_remaining = len(json.loads(decrypt(t.backup_codes_encrypted)))

    return {
        "mfa_required": user.mfa_required if user else False,
        "methods": user.mfa_methods if user else [],
        "active_tokens": methods,
        "backup_codes_remaining": backup_remaining,
    }


async def disable_mfa(
    db: AsyncSession,
    user_id: uuid.UUID,
    method: str,
    request: Request | None = None,
) -> None:
    tokens = (
        await db.execute(
            select(MfaToken).where(
                MfaToken.user_id == user_id,
                MfaToken.mfa_type == method,
                MfaToken.is_active.is_(True),
            )
        )
    ).scalars().all()

    for t in tokens:
        t.is_active = False
    await db.flush()

    from app.modules.auth.models import User
    user = await db.get(User, user_id)
    if user and user.mfa_methods:
        methods = list(user.mfa_methods)
        if method in methods:
            methods.remove(method)
        user.mfa_methods = methods
        if not methods:
            user.mfa_required = False
        await db.flush()

    await log_mfa_action(db, user_id, MFA_ACTION_DISABLED, {"method": method}, request)


# ---- Audit log --------------------------------------------------------------
async def log_mfa_action(
    db: AsyncSession,
    user_id: uuid.UUID,
    action: str,
    details: dict[str, Any] | None = None,
    request: Request | None = None,
) -> None:
    entry = MfaLog(
        user_id=user_id,
        action=action,
        ip_address=request.client.host if request and request.client else None,
        user_agent=request.headers.get("user-agent") if request else None,
        details=details or {},
    )
    db.add(entry)
    await db.flush()
