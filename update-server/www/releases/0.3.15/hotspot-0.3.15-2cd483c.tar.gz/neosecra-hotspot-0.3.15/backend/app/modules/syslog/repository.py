"""FirewallLog repository — CRUD for parsed firewall logs."""
from __future__ import annotations

import logging
import uuid
import inspect

from sqlalchemy import insert, or_, select
from sqlalchemy.exc import MultipleResultsFound
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.customers.models import Customer
from app.modules.devices.models import Device
from app.modules.locations.models import Location
from app.modules.syslog.models import FirewallLog

log = logging.getLogger(__name__)


async def insert_firewall_log(db: AsyncSession, log_entry: FirewallLog) -> FirewallLog:
    """Insert a single FirewallLog and flush."""
    result = db.add(log_entry)
    # AsyncMock-based repository doubles expose ``add`` as a coroutine while
    # SQLAlchemy's AsyncSession.add is intentionally synchronous.
    if inspect.isawaitable(result):
        await result
    await db.flush()
    return log_entry


async def insert_firewall_log_batch(db: AsyncSession, logs: list[FirewallLog]) -> int:
    """Insert a batch of FirewallLog records and flush.

    Returns the count of records inserted.
    """
    if not logs:
        return 0
    # SQLAlchemy executemany emits one INSERT statement for the whole batch
    # instead of one ORM unit-of-work operation per log.
    columns = (
        "id", "tenant_id", "customer_id", "device_id", "received_at",
        "event_time", "vendor", "log_type", "log_subtype", "severity",
        "action", "src_ip", "dst_ip", "src_port", "dst_port", "proto",
        "service", "user", "policyid", "duration", "sentbyte", "rcvdbyte",
        "session_id", "raw_syslog", "parsed_fields",
    )
    # Core executemany bypasses SQLAlchemy's ORM default machinery. Generate
    # UUIDs explicitly, otherwise the `id` column is sent as NULL and a real
    # PostgreSQL batch fails even though ORM single-row inserts work.
    for entry in logs:
        if getattr(entry, "id", None) is None:
            entry.id = uuid.uuid4()
    # Use a nullable fallback for optional fields.  Besides making the bulk
    # writer robust to parser variants that do not populate every field, this
    # keeps lightweight repository doubles usable in unit/integration tests.
    rows = [{column: getattr(entry, column, None) for column in columns} for entry in logs]
    if isinstance(db, AsyncSession):
        await db.execute(insert(FirewallLog), rows)
    else:
        # Lightweight test doubles and alternate repository implementations
        # may not expose SQLAlchemy's execute contract. Keep that path
        # observable without weakening the production bulk-insert path.
        for entry in logs:
            result = db.add(entry)
            # AsyncMock-based sessions expose ``add`` as a coroutine while
            # SQLAlchemy's AsyncSession.add is intentionally synchronous.
            # Supporting both avoids leaked coroutine warnings in adapters
            # and keeps this compatibility branch side-effect free.
            if inspect.isawaitable(result):
                await result
    await db.flush()
    return len(logs)


async def resolve_tenant_for_hostname(
    db: AsyncSession, hostname: str
) -> tuple[uuid.UUID, uuid.UUID] | None:
    """Resolve hostname to (tenant_id, customer_id).

    Looks up Device by name → Location → Customer → Tenant.

    Returns None if no matching device is found.
    """
    stmt = (
        select(
            Customer.tenant_id,
            Customer.id,
        )
        .select_from(Device)
        .join(Location, Device.location_id == Location.id)
        .join(Customer, Location.customer_id == Customer.id)
        .where(Device.name == hostname)
        .where(Device.is_active.is_(True))
        .where(Location.is_active.is_(True))
        .where(Customer.is_active.is_(True))
    )
    result = await db.execute(stmt)
    try:
        row = result.one_or_none()
    except MultipleResultsFound:
        # A hostname shared by devices in different customers is not enough
        # evidence to assign a tenant.  Never select an arbitrary row.
        log.warning("Ambiguous syslog hostname ownership: %s", hostname)
        return None
    if row is None:
        # Fallback: try SyslogSource identifier
        from app.modules.devices.models import SyslogSource
        stmt2 = (
            select(
                Customer.tenant_id,
                Customer.id,
            )
            .select_from(SyslogSource)
            .join(Device, SyslogSource.device_id == Device.id)
            .join(Location, Device.location_id == Location.id)
            .join(Customer, Location.customer_id == Customer.id)
            .where(SyslogSource.identifier == hostname)
            .where(Device.is_active.is_(True))
            .where(Location.is_active.is_(True))
            .where(Customer.is_active.is_(True))
        )
        result2 = await db.execute(stmt2)
        try:
            row2 = result2.one_or_none()
        except MultipleResultsFound:
            log.warning("Ambiguous syslog source ownership: %s", hostname)
            return None
        if row2 is None:
            return None
        return row2[0], row2[1]
    return row[0], row[1]


async def resolve_firewall_log_context(
    db: AsyncSession,
    hostname: str | None,
    device_identifier: str | None,
    source_ip: str | None = None,
) -> tuple[uuid.UUID, uuid.UUID, uuid.UUID | None] | None:
    """Resolve FortiGate identity to ``(tenant, customer, device UUID)``.

    FortiGate's ``devid`` is a serial number, while ``firewall_logs.device_id``
    intentionally stores our internal UUID.  Match the serial first (or the
    configured device name/syslog source), and only use the single-installation
    customer fallback when no registered device is found.
    """
    identifiers = [value.strip() for value in (hostname, device_identifier) if value and value.strip()]
    if identifiers or (source_ip and source_ip.strip()):
        identity_conditions = [
            Device.name.in_(identifiers),
            Device.serial_number.in_(identifiers),
        ]
        if source_ip and source_ip.strip():
            identity_conditions.extend(
                [Device.mgmt_ip == source_ip.strip(), Device.api_host == source_ip.strip()]
            )
        stmt = (
            select(Device.id, Customer.tenant_id, Customer.id)
            .select_from(Device)
            .join(Location, Device.location_id == Location.id)
            .join(Customer, Location.customer_id == Customer.id)
            .where(Device.is_active.is_(True))
            .where(Location.is_active.is_(True))
            .where(Customer.is_active.is_(True))
            .where(or_(*identity_conditions))
        )
        try:
            row = (await db.execute(stmt)).one_or_none()
        except MultipleResultsFound:
            log.warning(
                "Ambiguous firewall syslog ownership hostname=%s device=%s source_ip=%s",
                hostname,
                device_identifier,
                source_ip,
            )
            return None
        if row is not None:
            return row[1], row[2], row[0]

        # A manually configured syslog source may use an address/alias that is
        # not the device display name or serial number.
        from app.modules.devices.models import SyslogSource
        source_stmt = (
            select(Device.id, Customer.tenant_id, Customer.id)
            .select_from(SyslogSource)
            .join(Device, SyslogSource.device_id == Device.id)
            .join(Location, Device.location_id == Location.id)
            .join(Customer, Location.customer_id == Customer.id)
            .where(Device.is_active.is_(True))
            .where(Location.is_active.is_(True))
            .where(Customer.is_active.is_(True))
            .where(SyslogSource.identifier.in_(identifiers))
        )
        try:
            source_row = (await db.execute(source_stmt)).one_or_none()
        except MultipleResultsFound:
            log.warning("Ambiguous configured syslog source ownership: %s", identifiers)
            return None
        if source_row is not None:
            return source_row[1], source_row[2], source_row[0]

    resolved = await resolve_tenant_for_hostname(db, hostname or device_identifier or "")
    if resolved:
        return resolved[0], resolved[1], None

    # Syslog can legitimately arrive before the firewall's display name or
    # serial has been discovered.  In a single-installation deployment, use
    # an explicitly configured customer (or the sole active customer) as the
    # ownership anchor.  Multiple active customers remain unresolved.
    if settings.SINGLE_TENANT_MODE:
        # Prefer the explicitly configured installation customer.  Without a
        # configured id, accept the fallback only when exactly one active
        # customer exists; choosing the oldest row would invent ownership.
        fallback_stmt = select(Customer.tenant_id, Customer.id).where(
            Customer.is_active.is_(True)
        )
        configured_customer = str(settings.SINGLE_TENANT_CUSTOMER_ID or "").strip()
        if configured_customer:
            try:
                fallback_stmt = fallback_stmt.where(
                    Customer.id == uuid.UUID(configured_customer)
                )
            except ValueError:
                log.warning(
                    "Ignoring invalid SINGLE_TENANT_CUSTOMER_ID=%s",
                    configured_customer,
                )
        fallback = await db.execute(fallback_stmt)
        try:
            fallback_rows = fallback.all()
        except AttributeError:
            # Lightweight repository doubles may only implement one_or_none.
            fallback_row = fallback.one_or_none()
            fallback_rows = [fallback_row] if fallback_row is not None else []
        if len(fallback_rows) == 1:
            return fallback_rows[0][0], fallback_rows[0][1], None
        if len(fallback_rows) > 1:
            log.warning("Ambiguous single-tenant fallback: %d active customers", len(fallback_rows))
    return None
