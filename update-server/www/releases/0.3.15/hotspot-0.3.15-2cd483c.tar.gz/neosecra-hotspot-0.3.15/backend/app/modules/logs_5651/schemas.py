"""Pydantic schemas for the 5651 archive. Outbound only — archive records are
append-only, there is no create-via-API: archives are built by the worker/
service from session data. Hashes are exposed (they are the tamper-evidence
proof), but the archive payload itself is fetched via content_ref, not inlined.
"""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ArchiveRecordOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    customer_name: str | None = None
    location_id: uuid.UUID | None = None
    period_start: datetime
    period_end: datetime
    record_type: str
    chain_seq: int
    item_count: int
    content_hash: str
    content_ref: str
    content_size: int
    prev_hash: str
    curr_hash: str
    created_at: datetime
    signature_value: str | None = None
    signature_time: datetime | None = None
    certificate_serial: str | None = None
    sign_method: str | None = None
    signature_origin: str | None = None
    status: str = "pending"
    error_message: str | None = None
    storage_verified: bool = False
    signature_valid: bool = False


class ArchiveBuildIn(BaseModel):
    """Worker/admin trigger to build an archive for a customer + period."""
    # Kept optional for the single-installation API.  The server resolves the
    # historical ownership anchor when the admin omits it.
    customer_id: uuid.UUID | None = None
    record_type: str = "session_archive"
    period_start: datetime
    period_end: datetime


class ArchiveVerifyResult(BaseModel):
    """Chain verification report. ok=False means tampering detected at broken_seq."""
    customer_id: uuid.UUID
    record_type: str
    ok: bool
    checked: int
    broken_seq: int | None = None
    broken_id: uuid.UUID | None = None
    message: str


# ---- signing schemas ---------------------------------------------------------


class KamuSmConfigUpdate(BaseModel):
    """Update TUBITAK KamuSM signing configuration for a customer."""
    sign_method: str = Field(default="kamusm", description="kamusm|localfile|pkcs11")
    kamusm_username: str | None = Field(default=None, description="KamuSM API kullanici adi")
    kamusm_password: str | None = Field(default=None, description="KamuSM API sifresi (plaintext, encrypted before storage)")
    certificate_path: str | None = Field(default=None, description="Yerel sertifika dosya yolu (localfile modu)")
    certificate_password: str | None = Field(default=None, description="Sertifika sifresi (plaintext, encrypted before storage)")
    certificate_serial: str | None = Field(default=None, description="Sertifika seri numarasi")
    certificate_issuer: str | None = Field(default=None, description="Sertifika veren kurum")
    certificate_subject: str | None = Field(default=None, description="Sertifika konusu")


class KamuSmConfigOut(BaseModel):
    """KamuSM config response (secrets masked)."""
    is_configured: bool = False
    sign_method: str | None = None
    certificate_serial: str | None = None
    certificate_issuer: str | None = None
    certificate_subject: str | None = None
    has_kamusm_username: bool = False
    has_kamusm_password: bool = False
    has_certificate_path: bool = False
    last_signed_at: datetime | None = None
    last_signed_archive_id: str | None = None
    last_signature_origin: str | None = None


class SignResult(BaseModel):
    """Result of a digital sign operation on an archive."""
    archive_id: uuid.UUID
    customer_id: uuid.UUID
    sign_method: str
    signature_value: str
    signing_time: datetime
    certificate_serial: str
    chain_seq: int
    signature_origin: str | None = None


# ---- verification schemas ----------------------------------------------------


class SingleVerifyResult(BaseModel):
    """Verification result for a single archive record."""
    archive_id: uuid.UUID
    chain_seq: int
    content_hash_valid: bool
    # `unavailable` is distinct from a verified hash.  Consumers that only
    # understand the historical boolean still fail closed (`False`).
    content_hash_status: str = "verified"
    prev_hash_link_valid: bool | None = None
    signature_valid: bool | None = None
    overall_ok: bool
    message: str
    verified_at: datetime


class ChainVerifyResult(BaseModel):
    """Full chain verification result (extends ArchiveVerifyResult)."""
    customer_id: uuid.UUID
    record_type: str
    ok: bool
    total_records: int
    broken_at: int | None = None
    broken_id: uuid.UUID | None = None
    verified_at: datetime
    message: str


class EvidenceStatus(BaseModel):
    """Court evidence export status."""
    export_id: uuid.UUID
    session_id: uuid.UUID
    status: str
    package_ref: str | None = None
    created_at: datetime
    tenant_id: uuid.UUID | None = None
    customer_id: uuid.UUID | None = None
    content_hash: str | None = None
    sha256_hash: str | None = None
    envelope: dict | None = None
    attempt: int | None = None
    error_message: str | None = None
