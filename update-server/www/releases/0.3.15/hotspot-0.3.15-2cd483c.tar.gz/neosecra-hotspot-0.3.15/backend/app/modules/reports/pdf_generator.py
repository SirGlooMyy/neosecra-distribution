"""NeoSecra Enterprise Corporate PDF Report Generator.
High-quality, vector-crisp, branded PDF generator for compliance, firewall, and hotspot reports.
Supports full Turkish Unicode character set (ğ, Ğ, ı, İ, ş, Ş, ç, Ç, ö, Ö, ü, Ü) via TrueType fonts.
"""
from __future__ import annotations

import io
import os
import logging
from datetime import datetime, timezone
from typing import Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm, mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

log = logging.getLogger(__name__)

# Register native Turkish TrueType fonts
_FONT_NAME = "Helvetica"
_FONT_BOLD = "Helvetica-Bold"

def _ensure_fonts_registered() -> tuple[str, str]:
    global _FONT_NAME, _FONT_BOLD
    if _FONT_NAME == "NeoSecraFont":
        return _FONT_NAME, _FONT_BOLD

    font_paths = [
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        ("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"),
        ("/usr/share/fonts/dejavu/DejaVuSans.ttf", "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf"),
    ]
    for regular_path, bold_path in font_paths:
        if os.path.exists(regular_path):
            try:
                pdfmetrics.registerFont(TTFont("NeoSecraFont", regular_path))
                if os.path.exists(bold_path):
                    pdfmetrics.registerFont(TTFont("NeoSecraFont-Bold", bold_path))
                    _FONT_BOLD = "NeoSecraFont-Bold"
                else:
                    _FONT_BOLD = "NeoSecraFont"
                _FONT_NAME = "NeoSecraFont"
                return _FONT_NAME, _FONT_BOLD
            except Exception as e:
                log.warning("Font registration error: %s", e)
    return "Helvetica", "Helvetica-Bold"


def _format_bytes(b: int | float | None) -> str:
    val = float(b or 0)
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while val >= 1024 and i < len(units) - 1:
        val /= 1024
        i += 1
    return f"{val:,.1f} {units[i]}"


def create_corporate_pdf(
    *,
    title: str,
    subtitle: str,
    report_type: str,
    period_str: str,
    generated_at: str,
    metrics: list[tuple[str, str]],
    tables: list[dict[str, Any]],  # [{"title": str, "headers": list[str], "rows": list[list[str]], "col_widths": list[float]}]
    notes: list[str] | None = None,
    landscape_mode: bool = True,
    doc_id: str | None = None,
) -> bytes:
    """Generates a pixel-perfect, branded corporate PDF report with native Turkish characters."""
    font_reg, font_bold = _ensure_fonts_registered()

    buf = io.BytesIO()
    page_size = landscape(A4) if landscape_mode else A4
    page_width, page_height = page_size
    printable_width = page_width - 24 * mm  # ~774pt in landscape

    doc = SimpleDocTemplate(
        buf,
        pagesize=page_size,
        leftMargin=12 * mm,
        rightMargin=12 * mm,
        topMargin=12 * mm,
        bottomMargin=12 * mm,
        title=title,
        author="NeoSecra Hotspot & SOC",
    )

    styles = getSampleStyleSheet()

    # Custom styles with Turkish Unicode Font
    title_style = ParagraphStyle(
        "CorpTitle",
        parent=styles["Title"],
        fontName=font_bold,
        fontSize=13,
        leading=16,
        textColor=colors.HexColor("#0f172a"),
        alignment=0,
        spaceAfter=2,
    )
    subtitle_style = ParagraphStyle(
        "CorpSubtitle",
        parent=styles["Normal"],
        fontName=font_reg,
        fontSize=8,
        leading=10.5,
        textColor=colors.HexColor("#475569"),
        spaceAfter=4,
    )
    meta_style = ParagraphStyle(
        "CorpMeta",
        parent=styles["Normal"],
        fontName=font_reg,
        fontSize=7,
        leading=9,
        textColor=colors.HexColor("#475569"),
    )
    sec_heading_style = ParagraphStyle(
        "CorpSection",
        parent=styles["Heading2"],
        fontName=font_bold,
        fontSize=9.5,
        leading=12,
        textColor=colors.HexColor("#1e293b"),
        spaceBefore=6,
        spaceAfter=3,
    )
    tbl_hdr_style = ParagraphStyle(
        "CorpTblHdr",
        parent=styles["Normal"],
        fontName=font_bold,
        fontSize=7,
        leading=8.5,
        textColor=colors.white,
        alignment=0,
    )
    tbl_cell_style = ParagraphStyle(
        "CorpTblCell",
        parent=styles["Normal"],
        fontName=font_reg,
        fontSize=6.5,
        leading=8,
        textColor=colors.HexColor("#1e293b"),
        alignment=0,
    )
    metric_label_style = ParagraphStyle(
        "MetricLabel",
        parent=styles["Normal"],
        fontName=font_reg,
        fontSize=6.5,
        leading=8,
        textColor=colors.HexColor("#64748b"),
        alignment=1,
    )
    metric_val_style = ParagraphStyle(
        "MetricVal",
        parent=styles["Normal"],
        fontName=font_bold,
        fontSize=12,
        leading=14,
        textColor=colors.HexColor("#0f172a"),
        alignment=1,
    )

    story = []

    # 1. Header Banner with Official Logo & Document Metadata
    logo_path = "/app/app/static/logo_full_light.png"
    if not os.path.exists(logo_path):
        logo_path = "/home/sirgloomy/projects/Hotspot/backend/app/static/logo_full_light.png"

    hdr_left = []
    if os.path.exists(logo_path):
        try:
            img = Image(logo_path, width=4.2 * cm, height=1.3 * cm)
            img.hAlign = "LEFT"
            hdr_left.append(img)
            hdr_left.append(Spacer(1, 2))
        except Exception:
            pass

    hdr_left.append(Paragraph(title, title_style))
    hdr_left.append(Paragraph(subtitle, subtitle_style))

    report_code = doc_id or f"NS-RPR-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M')}"
    hdr_right_text = f"""
    <b>DOKÜMAN BİLGİLERİ</b><br/>
    <b>Rapor Kodu:</b> {report_code}<br/>
    <b>Rapor Dönemi:</b> {period_str}<br/>
    <b>Oluşturulma:</b> {generated_at}<br/>
    <b>Gizlilik Sınıfı:</b> KURUMSAL / YASAL DELİL<br/>
    <b>Platform:</b> NeoSecra SOC &amp; Hotspot v2.4
    """
    hdr_right = Paragraph(hdr_right_text, meta_style)

    hdr_table = Table(
        [[hdr_left, hdr_right]],
        colWidths=[printable_width - 6.5 * cm, 6.5 * cm],
    )
    hdr_table.setStyle(
        TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
            ("TOPPADDING", (0, 0), (-1, -1), 0),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("LINEBELOW", (0, 0), (-1, -1), 1, colors.HexColor("#cbd5e1")),
        ])
    )
    story.append(hdr_table)
    story.append(Spacer(1, 4))

    # 2. KPI Summary Cards Block
    if metrics:
        metric_cells = []
        for lbl, val in metrics:
            metric_cells.append([
                Paragraph(lbl, metric_label_style),
                Spacer(1, 1),
                Paragraph(val, metric_val_style),
            ])

        card_width = printable_width / len(metrics)
        metric_table = Table([metric_cells], colWidths=[card_width] * len(metrics))
        metric_table.setStyle(
            TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
                ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("LEFTPADDING", (0, 0), (-1, -1), 3),
                ("RIGHTPADDING", (0, 0), (-1, -1), 3),
            ])
        )
        story.append(metric_table)
        story.append(Spacer(1, 4))

    # 3. Content Tables with Auto Column Width Distribution
    for tbl_idx, t_data in enumerate(tables):
        if t_data.get("title"):
            story.append(Paragraph(t_data["title"], sec_heading_style))

        headers_raw = t_data.get("headers", [])
        num_cols = len(headers_raw) or 1
        headers = [Paragraph(str(h), tbl_hdr_style) for h in headers_raw]
        rows = [headers]

        for r_item in t_data.get("rows", []):
            row_cells = [Paragraph(str(c if c not in (None, "") else "-"), tbl_cell_style) for c in r_item]
            rows.append(row_cells)

        if len(rows) == 1:
            rows.append([Paragraph("Bu raporlama dönemi için kayıt bulunamadı.", tbl_cell_style)] + [""] * max(0, len(headers) - 1))

        # Auto calculate column widths to fill exact printable width
        custom_widths = t_data.get("col_widths")
        if not custom_widths:
            custom_widths = [printable_width / num_cols] * num_cols

        content_table = Table(rows, colWidths=custom_widths, repeatRows=1)
        content_table.setStyle(
            TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#e2e8f0")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 3.5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 3.5),
                ("TOPPADDING", (0, 0), (-1, -1), 2.5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
            ])
        )
        story.append(content_table)
        story.append(Spacer(1, 4))

    # 4. Notes & Compliance Notice
    if notes:
        for note in notes:
            story.append(Paragraph(f"• <b>Bilgi / Yasal Not:</b> {note}", meta_style))
            story.append(Spacer(1, 1.5))

    # 5. Canvas Header/Footer with Native Turkish Text & Page Numbers
    def add_header_footer(canvas, document):
        canvas.saveState()
        canvas.setFont(font_reg, 6.5)
        canvas.setFillColor(colors.HexColor("#64748b"))

        # Footer Left: Platform legal seal
        canvas.drawString(
            12 * mm,
            6 * mm,
            "NeoSecra Enterprise Hotspot & SOC • 5651 Sayılı Kanun Uyarınca Zaman Damgalı ve İmzalıdır."
        )

        # Footer Right: Page number
        canvas.drawRightString(
            page_width - 12 * mm,
            6 * mm,
            f"Sayfa {document.page}"
        )
        canvas.restoreState()

    doc.build(story, onFirstPage=add_header_footer, onLaterPages=add_header_footer)
    return buf.getvalue()
