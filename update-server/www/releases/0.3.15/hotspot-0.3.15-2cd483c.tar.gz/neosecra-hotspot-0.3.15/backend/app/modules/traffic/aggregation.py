"""Materialize traffic analytics from guest sessions.

The dashboard models are intentionally a read-optimized projection.  Session
accounting updates arrive asynchronously, so this job recomputes the recent
window and upserts the affected hour/day buckets.  Running it repeatedly is
safe and makes the charts converge when a late RADIUS Stop/Interim-Update is
received.
"""
from __future__ import annotations

import uuid
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.devices.models import Device
from app.modules.radius.models import RadiusEvent
from app.modules.sessions.models import GuestSession
from app.modules.syslog.models import FirewallLog
from app.modules.traffic.models import TrafficDaily, TrafficHourly, TopTalker


def _hour_start(value: datetime) -> datetime:
    value = _as_utc(value) or datetime.now(timezone.utc)
    return value.replace(minute=0, second=0, microsecond=0)


def _day_start(value: datetime) -> datetime:
    value = _as_utc(value) or datetime.now(timezone.utc)
    return value.replace(hour=0, minute=0, second=0, microsecond=0)


def _as_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


async def _upsert_hour(
    db: AsyncSession,
    customer_id: uuid.UUID,
    location_id: uuid.UUID,
    hour: datetime,
    values: dict[str, int],
) -> None:
    row = (await db.execute(
        select(TrafficHourly).where(
            TrafficHourly.customer_id == customer_id,
            TrafficHourly.location_id == location_id,
            TrafficHourly.hour == hour,
        ).limit(1)
    )).scalar_one_or_none()
    if row is None:
        db.add(TrafficHourly(customer_id=customer_id, location_id=location_id, hour=hour, **values))
    else:
        for key, value in values.items():
            setattr(row, key, value)


async def _upsert_day(
    db: AsyncSession,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None,
    day: datetime,
    values: dict,
) -> None:
    stmt = select(TrafficDaily).where(
        TrafficDaily.customer_id == customer_id,
        TrafficDaily.date == day,
    )
    if location_id is None:
        stmt = stmt.where(TrafficDaily.location_id.is_(None))
    else:
        stmt = stmt.where(TrafficDaily.location_id == location_id)
    row = (await db.execute(stmt.limit(1))).scalar_one_or_none()
    if row is None:
        db.add(TrafficDaily(customer_id=customer_id, location_id=location_id, date=day, **values))
    else:
        for key, value in values.items():
            setattr(row, key, value)


async def _upsert_talker(
    db: AsyncSession,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None,
    period_start: datetime,
    period_end: datetime,
    mac: str,
    values: dict,
) -> None:
    stmt = select(TopTalker).where(
        TopTalker.customer_id == customer_id,
        TopTalker.period_start == period_start,
        TopTalker.period_end == period_end,
        TopTalker.mac == mac,
    )
    if location_id is None:
        stmt = stmt.where(TopTalker.location_id.is_(None))
    else:
        stmt = stmt.where(TopTalker.location_id == location_id)
    row = (await db.execute(stmt.limit(1))).scalar_one_or_none()
    if row is None:
        db.add(TopTalker(
            customer_id=customer_id,
            location_id=location_id,
            period_start=period_start,
            period_end=period_end,
            mac=mac,
            **values,
        ))
    else:
        for key, value in values.items():
            setattr(row, key, value)


async def aggregate_traffic(
    db: AsyncSession,
    *,
    now: datetime | None = None,
    lookback_hours: int = 48,
) -> dict[str, int]:
    """Recompute recent TrafficHourly/TrafficDaily/TopTalker projections.

    Bytes are attributed to the bucket in which a session started (the
    session's cumulative accounting totals are not double-counted in every
    hour). Active users are evaluated against each hour's interval. Sessions
    without a location still contribute to the customer-level daily row.
    """
    now = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    since = now - timedelta(hours=max(1, lookback_hours))
    result = await db.execute(
        select(GuestSession).where(GuestSession.started_at >= since)
    )
    sessions = list(result.scalars().all())

    # RADIUS Interim/Stop counters are cumulative octets.  Keep only the
    # latest event per accounting session and use it as the authoritative
    # value for a matching GuestSession; this avoids counting Start + Interim
    # packets repeatedly while still recovering traffic for sessions whose
    # browser-side counters were never updated.
    radius_result = await db.execute(
        select(RadiusEvent).where(RadiusEvent.created_at >= since)
    )
    radius_latest: dict[str, RadiusEvent] = {}
    for event in radius_result.scalars().all():
        sid = (event.acct_session_id or "").strip()
        if not sid:
            continue
        previous = radius_latest.get(sid)
        if previous is None or (event.created_at or datetime.min.replace(tzinfo=timezone.utc)) > (previous.created_at or datetime.min.replace(tzinfo=timezone.utc)):
            radius_latest[sid] = event

    radius_by_session: dict[uuid.UUID, tuple[int, int]] = {}
    for session in sessions:
        event = radius_latest.get((session.radius_session_id or "").strip())
        if event is None:
            continue
        radius_by_session[session.id] = (
            max(0, int(event.acct_input_octets or 0)),
            max(0, int(event.acct_output_octets or 0)),
        )

    def session_bytes(session: GuestSession) -> tuple[int, int]:
        # Prefer cumulative RADIUS counters when present; otherwise use the
        # counters maintained by the captive/session flow.
        measured = radius_by_session.get(session.id)
        if measured and (measured[0] or measured[1]):
            return measured
        return max(0, int(session.bytes_in or 0)), max(0, int(session.bytes_out or 0))

    from sqlalchemy import func

    # Index sessions for IP/MAC correlation.  FortiGate traffic logs generally
    # carry source IP (not the Wi-Fi MAC); the active/archived session supplies
    # the legal identity and stable top-talker key when available.
    session_by_ip: dict[tuple[uuid.UUID, str, uuid.UUID | None], GuestSession] = {}
    session_by_ip_any_location: dict[tuple[uuid.UUID, str], GuestSession] = {}
    for session in sessions:
        if not session.ip:
            continue
        key = (session.customer_id, str(session.ip), session.location_id)
        session_by_ip.setdefault(key, session)
        session_by_ip_any_location.setdefault((session.customer_id, str(session.ip)), session)

    hour_groups: dict[tuple[uuid.UUID, uuid.UUID, datetime], list[GuestSession]] = defaultdict(list)
    day_groups: dict[tuple[uuid.UUID, uuid.UUID | None, datetime], list[GuestSession]] = defaultdict(list)
    for session in sessions:
        if not session.started_at:
            continue
        started_at = _as_utc(session.started_at)
        if started_at is None:
            continue
        hour = _hour_start(started_at)
        day = _day_start(started_at)
        if session.location_id is not None:
            hour_groups[(session.customer_id, session.location_id, hour)].append(session)
        day_groups[(session.customer_id, session.location_id, day)].append(session)

    # Firewall traffic logs: aggregate in SQL directly to avoid loading hundreds
    # of thousands of raw ORM instances into Python heap memory.
    firewall_hours: dict[tuple[uuid.UUID, uuid.UUID, datetime], dict[str, int]] = defaultdict(lambda: {"bytes_in": 0, "bytes_out": 0, "events": 0})
    firewall_days: dict[tuple[uuid.UUID, uuid.UUID | None, datetime], dict[str, int]] = defaultdict(lambda: {"bytes_in": 0, "bytes_out": 0, "events": 0})
    firewall_talkers: dict[tuple[uuid.UUID, uuid.UUID | None, datetime, str, str | None], dict[str, int]] = defaultdict(lambda: {"bytes_in": 0, "bytes_out": 0, "events": 0})

    ts_col = func.coalesce(FirewallLog.event_time, FirewallLog.received_at)
    # Reuse the exact SQL expression objects in SELECT and GROUP BY. Creating
    # separate date_trunc expressions can produce distinct bind parameters and
    # PostgreSQL then rejects the aggregation as not grouped.
    hour_bucket = func.date_trunc("hour", ts_col)
    day_bucket = func.date_trunc("day", ts_col)
    denied_actions = ["deny", "drop", "reject", "block", "blocked"]

    # 1. Hourly SQL aggregation
    hour_stmt = (
        select(
            FirewallLog.customer_id,
            Device.location_id,
            hour_bucket.label("hr"),
            func.coalesce(func.sum(FirewallLog.rcvdbyte), 0).label("bytes_in"),
            func.coalesce(func.sum(FirewallLog.sentbyte), 0).label("bytes_out"),
            func.count().label("events"),
        )
        .outerjoin(Device, Device.id == FirewallLog.device_id)
        .where(
            ts_col >= since,
            FirewallLog.customer_id.is_not(None),
            FirewallLog.action.notin_(denied_actions),
        )
        .group_by(FirewallLog.customer_id, Device.location_id, hour_bucket)
    )
    hour_rows = (await db.execute(hour_stmt)).all()
    for cid, loc_id, hr, bin_val, bout_val, ev_cnt in hour_rows:
        if loc_id is not None and hr is not None:
            firewall_hours[(cid, loc_id, _as_utc(hr))] = {
                "bytes_in": int(bin_val or 0),
                "bytes_out": int(bout_val or 0),
                "events": int(ev_cnt or 0),
            }

    # 2. Daily SQL aggregation
    day_stmt = (
        select(
            FirewallLog.customer_id,
            Device.location_id,
            day_bucket.label("dy"),
            func.coalesce(func.sum(FirewallLog.rcvdbyte), 0).label("bytes_in"),
            func.coalesce(func.sum(FirewallLog.sentbyte), 0).label("bytes_out"),
            func.count().label("events"),
        )
        .outerjoin(Device, Device.id == FirewallLog.device_id)
        .where(
            ts_col >= since,
            FirewallLog.customer_id.is_not(None),
            FirewallLog.action.notin_(denied_actions),
        )
        .group_by(FirewallLog.customer_id, Device.location_id, day_bucket)
    )
    day_rows = (await db.execute(day_stmt)).all()
    for cid, loc_id, dy, bin_val, bout_val, ev_cnt in day_rows:
        if dy is not None:
            firewall_days[(cid, loc_id, _as_utc(dy))] = {
                "bytes_in": int(bin_val or 0),
                "bytes_out": int(bout_val or 0),
                "events": int(ev_cnt or 0),
            }

    # 3. Top Talkers SQL aggregation (bounded to top 200 per aggregation run)
    talkers_stmt = (
        select(
            FirewallLog.customer_id,
            Device.location_id,
            day_bucket.label("dy"),
            FirewallLog.src_ip,
            FirewallLog.user,
            func.coalesce(func.sum(FirewallLog.rcvdbyte), 0).label("bytes_in"),
            func.coalesce(func.sum(FirewallLog.sentbyte), 0).label("bytes_out"),
            func.count().label("events"),
        )
        .outerjoin(Device, Device.id == FirewallLog.device_id)
        .where(
            ts_col >= since,
            FirewallLog.customer_id.is_not(None),
            FirewallLog.src_ip.is_not(None),
            FirewallLog.action.notin_(denied_actions),
        )
        .group_by(
            FirewallLog.customer_id,
            Device.location_id,
            day_bucket,
            FirewallLog.src_ip,
            FirewallLog.user,
        )
        .order_by((func.coalesce(func.sum(FirewallLog.rcvdbyte), 0) + func.coalesce(func.sum(FirewallLog.sentbyte), 0)).desc())
        .limit(200)
    )
    talkers_rows = (await db.execute(talkers_stmt)).all()
    for cid, loc_id, dy, src_ip, user, bin_val, bout_val, ev_cnt in talkers_rows:
        if dy is None or not src_ip:
            continue
        matched = session_by_ip.get((cid, str(src_ip), loc_id)) or session_by_ip_any_location.get((cid, str(src_ip)))
        talker_key = (matched.mac.upper() if matched and matched.mac else f"IP:{src_ip}")[:32]
        phone = matched.phone if matched else user
        firewall_talkers[(cid, loc_id, _as_utc(dy), talker_key, phone)] = {
            "bytes_in": int(bin_val or 0),
            "bytes_out": int(bout_val or 0),
            "events": int(ev_cnt or 0),
        }

    def overlaps(session: GuestSession, start: datetime, end: datetime) -> bool:
        """Whether an authorized session occupied any part of an interval.

        A historical bucket must include sessions that are now closed or
        expired. Looking only at ``status == active`` made every past peak
        disappear as soon as the visitor disconnected.
        """
        if not session.started_at or session.started_at >= end:
            return False
        if session.authorize_ok is False:
            return False
        return session.ended_at is None or session.ended_at > start

    all_hour_keys = set(hour_groups) | set(firewall_hours)
    for (customer_id, location_id, hour) in all_hour_keys:
        rows = hour_groups.get((customer_id, location_id, hour), [])
        interval_end = hour + timedelta(hours=1)
        active_macs = {
            (s.mac or "").upper()
            for s in sessions
            if s.customer_id == customer_id
            and s.location_id == location_id
            and overlaps(s, hour, interval_end)
            and s.mac
        }
        fw = firewall_hours.get((customer_id, location_id, hour), {})
        session_in = sum(session_bytes(s)[0] for s in rows)
        session_out = sum(session_bytes(s)[1] for s in rows)
        await _upsert_hour(
            db,
            customer_id,
            location_id,
            hour,
            {
                # Firewall event count is not a session count.  Keep this
                # metric semantically stable and use firewall counters as the
                # authoritative byte source when available (otherwise a
                # session's cumulative RADIUS counters are the fallback).
                "session_count": len(rows),
                "bytes_in": int(fw.get("bytes_in", 0)) if fw.get("events", 0) else session_in,
                "bytes_out": int(fw.get("bytes_out", 0)) if fw.get("events", 0) else session_out,
                "active_users": len(active_macs),
                "new_users": len({(s.mac or "").upper() for s in rows if s.mac}),
            },
        )

    all_day_keys = set(day_groups) | set(firewall_days)
    for (customer_id, location_id, day) in all_day_keys:
        rows = day_groups.get((customer_id, location_id, day), [])
        day_end = day + timedelta(days=1)
        active_counts = []
        for offset in range(24):
            slot = day + timedelta(hours=offset)
            active_counts.append(sum(
                1 for s in sessions
                if s.customer_id == customer_id
                and s.location_id == location_id
                and overlaps(s, slot, slot + timedelta(hours=1))
            ))
        durations = [
            (s.ended_at - s.started_at).total_seconds() / 60
            for s in rows if s.ended_at and s.started_at and s.ended_at >= s.started_at
        ]
        methods: dict[str, int] = defaultdict(int)
        for session in rows:
            methods[session.auth_method or "unknown"] += 1
        await _upsert_day(
            db,
            customer_id,
            location_id,
            day,
            {
                "session_count": len(rows),
                "bytes_in": int(firewall_days.get((customer_id, location_id, day), {}).get("bytes_in", 0)) if firewall_days.get((customer_id, location_id, day), {}).get("events", 0) else sum(session_bytes(s)[0] for s in rows),
                "bytes_out": int(firewall_days.get((customer_id, location_id, day), {}).get("bytes_out", 0)) if firewall_days.get((customer_id, location_id, day), {}).get("events", 0) else sum(session_bytes(s)[1] for s in rows),
                "peak_concurrent": max(active_counts, default=0),
                "avg_session_duration_min": sum(durations) / len(durations) if durations else None,
                "unique_macs": len({(s.mac or "").upper() for s in rows if s.mac}) or len({key[3] for key in firewall_talkers if key[0] == customer_id and key[1] == location_id and key[2] == day}),
                "auth_methods": dict(methods),
            },
        )

        # Merge session, RADIUS and firewall counters into one ranking.  A
        # firewall record that maps to a known session enriches that same row;
        # an unknown source IP is still retained as an ``IP:<address>`` key.
        talker_metrics: dict[tuple[str, str | None], dict[str, int]] = defaultdict(lambda: {"bytes_in": 0, "bytes_out": 0, "session_count": 0})
        firewall_talker_keys = {
            (key[3], key[4])
            for key in firewall_talkers
            if key[0] == customer_id and key[1] == location_id and key[2] == day
        }
        for session in rows:
            if session.mac:
                key = (session.mac.upper(), session.phone)
                # If firewall counters exist for this source, they supersede
                # the same cumulative session counters to prevent double
                # counting one connection in the ranking.
                if key not in firewall_talker_keys:
                    byte_in, byte_out = session_bytes(session)
                    talker_metrics[key]["bytes_in"] += byte_in
                    talker_metrics[key]["bytes_out"] += byte_out
                talker_metrics[key]["session_count"] += 1
        for (talker_customer, talker_location, _period, mac, phone), values in firewall_talkers.items():
            if talker_customer == customer_id and talker_location == location_id and _period == day:
                key = (mac, phone)
                talker_metrics[key]["bytes_in"] += values["bytes_in"]
                talker_metrics[key]["bytes_out"] += values["bytes_out"]
                talker_metrics[key]["session_count"] += values["events"]
        ranked = sorted(
            talker_metrics.items(),
            key=lambda item: item[1]["bytes_in"] + item[1]["bytes_out"],
            reverse=True,
        )
        for rank, ((mac, phone), values) in enumerate(ranked[:100], start=1):
            await _upsert_talker(
                db,
                customer_id,
                location_id,
                day,
                day_end,
                mac,
                {
                    "phone": phone,
                    "bytes_in": values["bytes_in"],
                    "bytes_out": values["bytes_out"],
                    "session_count": values["session_count"],
                    "rank": rank,
                },
            )


    await db.commit()
    return {
        "sessions": len(sessions),
        "hourly_buckets": len(all_hour_keys),
        "daily_buckets": len(all_day_keys),
    }
