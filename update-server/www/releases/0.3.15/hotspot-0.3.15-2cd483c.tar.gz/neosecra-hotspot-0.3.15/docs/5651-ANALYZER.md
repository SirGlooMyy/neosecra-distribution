# 5651 Network Analyzer

The Analyzer is the Hotspot-owned, tenant-scoped projection for firewall and
5651 network evidence. It keeps source payloads and searchable projections in
separate tables:

- `analyzer_raw_events` stores the original payload, SHA-256, source metadata,
  parser version, received time, retention deadline, and provenance.
- `analyzer_normalized_events` stores the immutable parsed projection used by
  search, timeline, session reconstruction, identity/IP/MAC correlation,
  firewall/NAT/DNS filters, and reports.
- `analyzer_ingest_failures` is the mutable retry/DLQ state. Replay reads the
  immutable raw row and creates the projection without rewriting evidence.
- `analyzer_source_health` records receive/parse counters and ingestion lag.
- `analyzer_legal_holds` is an append-only place/release action stream.
- `analyzer_evidence_exports` and `analyzer_reports` catalog immutable,
  hash-addressed exports and report snapshots. Raw payloads are excluded by
  default.
- `analyzer_saved_views` stores tenant-scoped filter presets.

## API surface

All routes are under `/api/v1/analyzer` and require an authenticated user, the
`logs_5651` entitlement, and the route-specific `analyzer.*` permission:

- `GET /events`, `GET /timeline`, `GET /sessions/{session_id}`
- `GET /identity-map`, `GET /sources/health`, `GET /failures`
- `POST /failures/{failure_id}/replay`, `POST /ingest`
- `GET /raw/{raw_id}` (requires `analyzer.raw.read` and writes an audit event)
- `GET/POST/PUT/DELETE /views`, `POST /legal-holds`, `GET /legal-holds`
- `POST /evidence/export`, `GET /evidence/{export_id}/download`
- `POST /reports`, `GET /reports/{report_id}`, `GET /reports/{report_id}/csv`
- `GET /archive/verify`

Every tenant-bound query applies the application scope predicate and sets the
PostgreSQL `app.*` RLS settings. The migration enables and forces RLS on all
Analyzer tables. Evidence/report writes use tenant-scoped unique idempotency
keys, request fingerprints, and savepoints so retries cannot create duplicate
rows or silently reuse a key for a different request.

## Legacy syslog boundary

Migration `f9a0b1c2d3e4` applies the same forced-RLS boundary to the legacy
`syslog_records` table. Existing rows are backfilled only when active
device/source -> location -> customer relationships yield exactly one tenant;
invalid, ambiguous, and unresolved rows remain as quarantined evidence with
candidate/reason provenance. API ingest and worker replay require an explicit
transaction-local tenant context, and archive/report readers establish context
only after customer ownership is proven. The downgrade reverses the schema
changes and restores the legacy representation without deleting rows.

## Integrity and retention

Raw and normalized evidence fields are protected by PostgreSQL append-only
triggers. Raw status may move from failed to normalized during replay; payload,
hash, provenance, source, and retention fields cannot be changed. Exports are
written below the configured evidence storage root and verified by SHA-256 on
download. Retention is calculated from `ARCHIVE_RETENTION_DAYS`; legal holds
are represented by append-only actions and surfaced on normalized responses.

Reports and evidence packages state their schema version, generation time,
tenant/customer identifiers, source projection, hashes, and limitations. An
empty report is `insufficient_evidence`; this implementation does not claim
KamuSM, statutory, or court compliance.

## Validation scope

Repository checks cover parser behavior, tenant predicates, RBAC boundaries,
OpenAPI registration, migration SQL generation, retry/idempotency helpers, the
full backend suite, and the Admin frontend test/build. Live services,
Distribution tooling, database apply, and production/legal certification are
intentionally not run for the repository-only task.
