# Modül Haritası — "X hangi dosyada?"

Her modül `backend/app/modules/<domain>/` altında. Aynı iskelet:
`models.py / schemas.py / service.py / repository.py / router.py` (hepsi olmayabilir).

> **STUB** = models.py var ama sadece yorum (tablo yok); veya modül boş iskelet.

## Tenant hiyerarşisi (Kural #1/#2 eksenleri)

| Modül | Tablo(lar) | Kilit dosya/sembol | Scope ekseni |
|-------|-----------|--------------------|--------------|
| `tenants` | tenants | `service.py` (list/get/create/update), `router.py` | GLOBAL/partner |
| `partners` | partners | `service.py` | GLOBAL/partner |
| `customers` | customers | `service.py`; `Customer.partner_id` | partner→customer |
| `locations` | locations | `service.py`; `Location.customer_id` | customer→location |

## Cihaz & adapter (Kural #7)

| Modül | Tablo(lar) | Kilit dosya/sembol | Not |
|-------|-----------|--------------------|-----|
| `devices` | devices, device_credentials | `router.py` (CRUD + credential + test-connection + discover + authorize/revoke-guest) | DeviceCredential Fernet ile şifreli (Kural #3) |
| `firewall_adapters` | **STUB models** | `base.py` FirewallAdapter ABC; `fortigate.py`/`paloalto.py`; `registry.py` get_adapter_class; `service.py` authorize_guest_service / revoke_guest_service / discover_device / test_connection_service / parse_syslog | vendor mantığı BURADA, core service'te DEĞİL |

## Captive portal (Kural #6 — context olmadan başlamaz)

| Dosya | Sorumluluk |
|-------|-----------|
| `portal/models.py` | PortalTemplate (method, theme, fields, terms_url, is_default, is_active) |
| `portal/service.py` | template CRUD (admin) |
| `portal/router.py` | admin template CRUD — `/portal` (JWT) |
| `portal/public_router.py` | **PUBLIC** `/portal/public/*` (JWT YOK; IP rate-limit) |
| `portal/flow.py` | `resolve_context` / `send_code` / `verify` / `start_session` — captive akışın beyni |
| `portal/schemas.py` | PortalContextOut, SendCodeIn, PortalVerifyIn, PortalTokenOut, StartSessionIn/Out |

## Guest auth yöntemleri

| Modül | Tablo(lar) | Kilit sembol | Not |
|-------|-----------|--------------|-----|
| `sms` | otp_codes | `service.send_otp` / `verify_otp`; salted sha256 code_hash + rate-limit | provider: console/http |
| `identity` | identity_verifications | `service.issue_for_sms/tc/voucher/free`, `validate_portal_token`, `consume`; `tc_validation.py` | phone_masked @property; portal token bir kez |
| `vouchers` | voucher_batches, vouchers | `service.create_batch` / `redeem`; code_hash unsalted sha256 (lookup) | plaintext code SADECE BatchCreateResult'ta |

## Oturum & 5651

| Modül | Tablo(lar) | Kilit sembol | Not |
|-------|-----------|--------------|-----|
| `sessions` | guest_sessions | `service.create_session / list / get / close / expire_due / _scoped_query_async`; `correlation.correlate` | status: pending/active/closed/expired. expire_due SİLMEZ |
| `logs_5651` | archive_records | `service.build_session_archive / verify_chain / _scoped_query`; `archive_service.content_hash / upload` | append-only + per-(customer,type) hash chain. SoftDelete YOK |

## Yönetim modülleri

| Modül | Tablo(lar) | Kilet sembol | Not |
|-------|-----------|--------------|-----|
| `reports` | **STUB models** | `service.summary / build_sessions_csv / build_sessions_pdf`; `router.py` | CSV stdlib; PDF reportlab lazy → 501 |
| `licensing` | customer_licenses + platform_settings (`platform_license`) | `service.enforce_quota / quota_status / upsert_license / get_license / list_licenses`; `shared.licensing.get_hotspot_license` | Signed canonical `.vlicense` (`hotspot.core`, tenant binding, max_concurrent_sessions) is mandatory in production; `CustomerLicense`/UNLIMITED=-1 is dev/test compatibility only; customer yazamaz (RBAC) |
| `audit` | audit_logs | `service.log_audit` | append-only; her kritik işlem çağırır |
| `auth` | users | `service` (login/refresh/logout/token-blacklist); `deps.get_current_user` / `require_permission`; `models.User` | JWT + bcrypt; 2FA flag |

## Worker (Celery)

| Dosya | Sorumluluk |
|-------|-----------|
| `workers/celery_app.py` | `celery_app` + beat schedule (expire */5, archive 02:30) |
| `workers/runtime.py` | `worker_engine` (NullPool) + `WorkerSession` (asyncpg cross-loop) |
| `workers/tasks.py` | expire_due_sessions / archive_5651_daily / archive_5651_for_customer / session_correlation_job / firewall_sync_job / syslog_parse_job / report_generation_job(stub) |

## Stub modüller (iskelet var, tablo/implementasyon YOK)

`radius/`, `syslog/`, `archive/`, `site_bridge/`, `workers/models.py`,
`reports/models.py`, `firewall_adapters/models.py` — models.py sadece yorum.
Bunlara tablo eklersen **`alembic/env.py` model import listesine de ekle**
(yoksa autogenerate görmüyor) ve `scripts/dev_create_tables.py`'yi de güncelle.

## Core & shared (modül dışı)

| Dosya | Sorumluluk |
|-------|-----------|
| `app/core/config.py` | `Settings` (tüm env ayarları) |
| `app/core/database.py` | `Base`, `engine`, `AsyncSessionLocal`, `get_db` (FastAPI dep) |
| `app/core/tenant.py` | `TenantLevel`, `ScopeContext`, `scope_for` |
| `app/core/rbac.py` | `Role`, `ROLE_PERMISSIONS`, `has_permission`, `can_manage_role` |
| `app/core/security.py` | Fernet şifreleme + `rate_limit` primitive |
| `app/shared/types.py` | `UUIDPK`, `TimestampMixin`, `SoftDeleteMixin`, `fk()` |
| `app/api/v1/router.py` | **TEK router kayıt noktası** — yeni modülü buraya ekle |
| `app/main.py` | FastAPI app + `/health` + CORS |

## Yeni modül ekleme kontrol listesi

1. `app/modules/<x>/{models,schemas,service,repository,router}.py`
2. `models.py` tablo kullanıyorsa → `alembic/env.py` + `scripts/dev_create_tables.py` import listesine ekle
3. `router.py` → `app/api/v1/router.py`'ye `include_router(..., prefix="/<x>")` ekle
4. Yetkiler → `app/core/rbac.py` `ROLE_PERMISSIONS`'a ekle
5. Cross-module erişim service üzerinden, router'dan değil
6. Kritik işlem → `audit.service.log_audit` çağır
7. Scope → repository `_scoped_query(db, scope)` pattern'i koru
