# HOT-MVP-GAP-008 — Repository MVP Gap Audit

**Date:** 2026-09-01
**Repository:** `/home/sirgloomy/projects/Hotspot`
**Scope:** Captive portal, admin, RADIUS/accounting, approval, 5651 Analyzer,
 lifecycle, tenant/RBAC, upgrade and operations. Repository-only; no live,
 Distribution or database-apply operations.

## Method and result

The audit followed the current checkpoint at `ceb12e7`, the repository and
platform contracts, targeted source review, and focused regression tests. No
P0 was evidenced. Three bounded P1 defects were confirmed and closed in this
slice; the changes preserve the legacy API shape while making ownership and
failure behavior explicit. Existing Analyzer work remains the canonical
tenant-scoped 5651 projection.

## Closed P1 findings

| ID | Evidence before closure | Closure and proof |
|---|---|---|
| GAP-01 | `backend/app/modules/auth/router.py` listed `select(User)` for partner/customer admins without a scope predicate. | The route now applies `scope_for()` with partner+tenant or customer+tenant predicates and returns an empty result for incomplete assignments. Covered by the partner-scope and fail-closed tests in `tests/test_hot_mvp_gap_008.py`. |
| GAP-02 | `backend/app/core/ingest_auth.py` logged both `supplied` and `expected` API-key values. | Ingest telemetry records only boolean presence/configuration flags. The focused test proves neither key value appears in captured logs. |
| GAP-03 | `backend/app/api/v1/endpoints/syslog.py` copied caller-provided `tenant_id` directly into `SyslogRecord`. | The endpoint resolves ownership through the registered firewall/source resolver, rejects unknown sources and mismatches, and rolls back on commit failure. Focused tests cover resolved ownership, mismatch/unknown rejection, and rollback. |

## Remaining evidence-backed gaps

These items were not silently marked complete and were not expanded into an
unbounded migration during this focused task.

| Priority | Area | Evidence and boundary |
|---|---|---|
| P1 | Legacy syslog storage-layer isolation | `SyslogRecord.tenant_id` is nullable (`backend/app/modules/syslog/models.py:18`) and the foundation migration creates `syslog_records` without a forced RLS policy (`backend/alembic/versions/bd3a07a1583c_create_hotspot_foundation_schema.py:59-71`). Application paths scope newer Analyzer/FirewallLog data, but extending forced RLS safely requires request-local database context plus legacy-row backfill. This remains an open hardening item. |
| P2 | Scoped administrator provisioning | `AdminUserCreate` accepts a role but no tenant/partner/customer assignment. A super-admin-created scoped role therefore needs a separate assignment workflow; the new listing fails closed rather than exposing global rows. |
| P2 | Optional identity integrations | LDAP intentionally returns `501` when its optional client dependency is unavailable (`backend/app/modules/portal/flow.py:1019-1025`). This is an explicit unavailable state, not a successful fallback. |
| P2 | Host upgrade/rollback execution | The update surface reports `UPGRADE_EXECUTION_NOT_SUPPORTED` or `ROLLBACK_NOT_SUPPORTED` when the host agent is not provisioned (`backend/app/modules/system/router.py:539-580`). Distribution rollout, attestation and restore drills remain separate operational work. |
| P2 | Operational verification gates | PostgreSQL migration apply, object-store/restore, stress soak, signed attestation, live services and Distribution were not run by directive. They are `NOT_RUN`, not passed. |

## Areas with no new P0/P1 defect evidenced

- Captive portal approval/identity flow and RADIUS authentication use backend
  checks and fail closed on missing configuration or rejected credentials.
- The HOT-5651-ANALYZER-007 projection already separates raw and normalized
  data, records provenance/timestamps, enforces Analyzer-table RLS and
  immutable evidence guards, and exposes replay/DLQ and audit paths.
- No live service, customer data, legal certification, KamuSM assertion or
  production-readiness claim is made by this audit.

## Verification commands

Focused regression run:

```text
cd backend && .venv-linux/bin/python -m pytest -q -p no:cacheprovider \
  tests/test_hot_mvp_gap_008.py --tb=short
```

Expected evidence for this slice: **6 passed, 0 failed, 0 skipped** (one
pre-existing Pydantic deprecation warning). Broader checks and their exact
counts are recorded in `.ai-ops/current-checkpoint.md`; no live/Distribution
operation was attempted.
