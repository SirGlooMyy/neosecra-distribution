# HOT-LEGACY-RLS-CLOSURE-009 - Legacy `syslog_records` RLS closure

**Date:** 2026-09-01
**Repository:** `/home/sirgloomy/projects/Hotspot`
**Scope:** Repository-only legacy syslog tenant ownership, PostgreSQL forced RLS,
worker/API boundaries, migration lifecycle, and negative tests.

## Implemented closure

- Migration `f9a0b1c2d3e4` adds tenant-resolution provenance, a retained
  `claimed_tenant_id` for invalid historical claims, a tenants foreign key,
  consistency checks, and resolution indexes.
- Existing rows are classified deterministically from active device/source ->
  location -> customer -> tenant relationships. Exactly one distinct tenant is
  required; ambiguous, missing, and invalid ownership stays in-place as an
  explicit quarantine row with candidates/reason. No row is discarded and no
  tenant is invented.
- PostgreSQL `syslog_records` is `ENABLE ROW LEVEL SECURITY` plus `FORCE ROW
  LEVEL SECURITY` with explicit SELECT/INSERT/UPDATE/DELETE policies. Missing
  tenant context returns no scoped rows and cannot pass INSERT/UPDATE checks;
  quarantined rows are not usable by tenant workers.
- `app.core.rls.set_syslog_context()` validates UUIDs and uses transaction-local
  `set_config(..., true)`, preventing pooled-connection tenant leakage. API
  ingest resolves ownership from a registered active source and writes explicit
  `api_ingest` provenance; mismatches/unknown sources fail with 403 and commit
  failures roll back.
- Worker trigger replay requires an explicit tenant UUID, rejects malformed,
  quarantined, missing, or cross-tenant records, and queries only after the
  transaction-local context is set. Archive/report readers set the same context
  after proving customer→tenant provenance.
- Downgrade drops policies/constraints/indexes and restores deterministic
  backfills to NULL and invalid historical claims to their original UUID.

## Verification evidence

- Focused security/regression set (`legacy_syslog_rls`, HOT-MVP-GAP-008,
  trigger, listener, IDOR, syslog router, captive-with-syslog): **67 passed,
  3 skipped (PG_REQUIRED), 0 failed, 4 warnings**.
- Full backend suite: **1184 passed, 65 skipped, 0 failed, 49 warnings**
  (`cd backend && .venv-linux/bin/python -m pytest tests/ -q --tb=line
  -p no:cacheprovider`).
- Ruff (changed Python paths), Python compile, and `git diff --check`: passed.
- Alembic offline upgrade to `f9a0b1c2d3e4` and explicit downgrade to
  `f8a9b0c1d2e3`: passed. Rendered SQL contains 4 legacy policies, 9 forced-RLS
  operations across the chain, and all 4 reversible policy drops.
- `SYSLOG_RLS_TEST_DATABASE_URL` was not configured. PostgreSQL apply,
  non-superuser live fixture, live services, deployment, Distribution, restore,
  stress, attestation, and legal-certification probes were **NOT RUN**. No
  legal/compliance claim is made.

## Remaining gates

- P1 verification gate: run the isolated non-superuser PostgreSQL migration and
  cross-tenant fixture with `SYSLOG_RLS_TEST_DATABASE_URL`; this repository run
  cannot claim that live-database evidence.
- P2 operational gates remain separate: backup/restore drill, stress/soak,
  signed attestation, Distribution rollout, and live-service validation.

**Canonical owner:** Hotspot owns captive portal, RADIUS, firewall policy, and
5651 evidence. No downstream repository was changed.
