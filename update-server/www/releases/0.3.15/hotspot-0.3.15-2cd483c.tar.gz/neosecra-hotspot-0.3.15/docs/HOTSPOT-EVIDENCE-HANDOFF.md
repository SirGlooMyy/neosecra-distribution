# Hotspot Evidence and Reporting Handoff

## Publication gate

5651 archive payloads are publishable only when `status=ready`,
`storage_verified=true`, and `signature_valid=true`. Missing objects, MinIO
errors, hash mismatches, and signature failures are persisted as `failed` and
never become PDF, ZIP, or raw-download success responses.

The explicit `ARCHIVE_PROVIDER=none` mode remains a development/test
compatibility state and is rejected when `ENVIRONMENT=production`. Its
`none:<sha256>` reference is never considered ready.

## Tenant and provenance

Court evidence and report syslog queries require a concrete customer-to-tenant
mapping. Syslog and RADIUS queries include the resolved `tenant_id`; missing
mapping fails closed. Customer/partner/tenant scope checks run before export,
status, archive, and report reads.

## Evidence export API

- `POST /api/v1/logs-5651/evidence/export/{session_id}` accepts
  `Idempotency-Key` and persists `pending -> running -> ready|failed`.
- `GET .../status` returns the latest durable export row; there is no synthetic
  `available` response when no export exists.
- `GET .../history` returns append-only status transitions for the scoped
  export.

`evidence_exports` stores the package hash and canonical envelope. The
`evidence_export_status_history` table is append-only and tenant-bound.

## Reports

`ReportArchive` stores `schema_version`, `tenant_id`, `provenance`, canonical
`envelope`, and its SHA-256 hash. `report_job_status_history` records queued,
running, retry, succeeded, and failed transitions. A repeated idempotency key
returns the existing ready artifact instead of creating a second one.

Legacy evidence manifests without hashes remain readable in compatibility mode
and are returned as `integrity_verified=false`; new exports require manifest
and per-file SHA-256 verification.

## Migration

Apply `e6f7a8b9c0d1_add_evidence_report_integrity.py` after backing up the
PostgreSQL database. Existing archive rows are intentionally unverified and
must be rechecked before legal publication.
