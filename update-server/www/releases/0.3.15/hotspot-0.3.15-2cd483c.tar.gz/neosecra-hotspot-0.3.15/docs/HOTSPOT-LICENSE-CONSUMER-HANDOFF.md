# Hotspot Canonical License Consumer Handoff

Hotspot consumes the signed NeoSecra `.vlicense` envelope locally. The
Ed25519 private key never enters this repository; only the configured public
key (`LICENSE_PUBLIC_KEY_B64` or `LICENSE_PUBLIC_KEY_FILE`) is trusted.

## Canonical payload

The envelope remains `schema_version: 1` and signs the base64url payload. A
Hotspot session requires these payload fields:

```json
{
  "payload_schema_version": 1,
  "license_id": "...",
  "issuer": "NeoSecra",
  "product_code": "hotspot",
  "tenant_id": "...",
  "valid_from": "2026-01-01T00:00:00Z",
  "expires_at": "2027-01-01T00:00:00Z",
  "duration_months": 12,
  "entitlements": ["hotspot.core"],
  "limits": {"max_concurrent_sessions": 10}
}
```

`duration_months` accepts the standard values 12/24/36 and controlled custom
values 1..120. `max_concurrent_sessions` accepts the standard values 5/10/50
and controlled custom values 1..100000. Hotspot has one entitlement only:
`hotspot.core`; Phish campaign/recipient quotas are not relevant here.

## Fail-closed behavior

`get_hotspot_license()` verifies the Ed25519 signature, canonical payload,
product, tenant, validity window, CRL status, entitlement and concurrent
session limit. Missing, malformed, expired, revoked, tenant-mismatched,
installation-mismatched or signature-invalid licenses are not usable.

During the one-customer migration window, a legacy Ed25519 payload may be
consumed only when its `product_code` is exactly `hotspot`, `modules` contains
`hotspot_core`, and the database has exactly one active customer under one
active tenant matching the request context. The consumer derives only
`hotspot.core`, applies a finite 50-session cap, and marks the result with
`legacy_warning=true`; it never treats legacy `limits` as unlimited and never
rewrites the signed payload as canonical. Ambiguous or multi-tenant state
fails closed. `enforce_quota()` returns HTTP 402 before firewall authorization.

The old `CustomerLicense` row and trial/unlimited path remain only for local
development/test compatibility. They are never used as a production session
authorization source.

## Atomic quota

`enforce_quota()` locks the resolved `Customer` row with `SELECT ... FOR
UPDATE`, validates the signed tenant license, and counts non-expired active
sessions while the transaction remains open. `portal.start_session()` keeps
that transaction through session insertion/commit, so parallel requests for a
customer cannot exceed `max_concurrent_sessions`. A reconnect from the same
MAC/phone is excluded from the count because the existing lease is closed by
`create_session()`.

## Compatibility and tests

`get_platform_license()` keeps legacy payloads readable for status/upgrade UI,
while the strict Hotspot consumer uses only the bounded compatibility boundary
described above. Focused coverage is in
`backend/tests/test_hotspot_canonical_license.py` (negative signature,
tenant/entitlement/quota/date checks, bounded legacy compatibility and
ambiguity rejection, production missing license, and a serialized concurrent
quota race).
