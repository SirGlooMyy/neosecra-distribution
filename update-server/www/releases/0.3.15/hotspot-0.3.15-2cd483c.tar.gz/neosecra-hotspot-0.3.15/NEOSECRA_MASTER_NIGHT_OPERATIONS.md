# NeoSecra Master Gece Operasyonları & Canlıya Geçiş Kılavuzu
**Tarih:** 25 Ağustos 2026 / 26 Ağustos 2026  
**Kapsam:** NeoSecra Hotspot (`/home/sirgloomy/projects/Hotspot`) & NeoSecra SOC (`/home/sirgloomy/projects/neosecra-soc`)

---

## 📑 İÇİNDEKİLER
1. [Bugün Yapılanlar ve Çözülen Kritik Sorunlar](#1-bugün-yapılanlar-ve-çözülen-kritik-sorunlar)
2. [Mevcut Durum ve Kalan 2 Blocker](#2-mevcut-durum-ve-kalan-2-blocker)
3. [SOC Agent / Codex İçin Gece Master Görev Promptu](#3-soc-agent--codex-için-gece-master-görev-promptu)
4. [Hotspot İçin Master E2E Doğrulama Promptu](#4-hotspot-için-master-e2e-doğrulama-promptu)
5. [Sabah Canlıya Geçiş (Deploy) & Doğrulama Adımları](#5-sabah-canlıya-geçiş-deploy--doğrulama-adımları)
6. [Tek Komutla Çalıştırılabilir Canlı Test Araçları](#6-tek-komutla-çalıştırılabilir-canlı-test-araçları)

---

## 1. BUGÜN YAPILANLAR VE ÇÖZÜLEN KRİTİK SORUNLAR

### 🌐 Hotspot Modülleri:
* **Toplantı Kodları (Meeting Codes):** Özel kod korunumu sağlandı (`VDATA2026` rastgeleye dönüşmüyor), büyük/küçük harf duyarsızlığı ve lokasyon bağımsız doğrulama getirildi. Önceden onaylı kodlar yönetici onayından muaf tutularak internet anında açıldı.
* **Yerel Kullanıcılar (Local Auth):** Kullanıcı silindiğinde veya yeniden eklendiğinde oluşan `409 Conflict: Bu kullanıcı adı zaten mevcut` hatası giderildi, otomatik reaktivasyon sağlandı.
* **Oturum İptali & FortiGate Silme (Revoke Cleanup):** İptal/yasaklama yapıldığında o IP'ye ait geçmişteki tüm `hsess-*` adres nesnelerinin FortiGate `Guest` ve `hotspot-allowed` gruplarından ve CMDB'den tamamen temizlenmesi sağlandı.
* **Cihazı Hatırla (MAC Bypass):** Süresi devam eden misafirlerin portalı tekrar açtığında form doldurmadan tek tıkla devam edebileceği yapı kuruldu.
* **Dahili FreeRADIUS:** Docker ağı (`172.18.0.0/16`) UDP 1812 paket eşleşmesi düzeltildi; yönetim panelindeki test butonu yeşile döndü (`RADIUS SERVER OK: True`).
* **Şablon Editörü:** Canlı önizleme iframe'inin ilk açılışta beyaz kalması `useMemo` ve `srcDoc` ile kalıcı olarak çözüldü.

### 🛡️ SOC Modülleri:
* **Müşteri Güvenlik Sınırı (Customer Boundary):** Müşteri rollerine iç TheHive, Graylog, iç konektör URL'leri ve ham log kaynakları maskelendi ("NeoSecra Managed Telemetry").
* **Realtime SSE & Redis:** `/api/v1/soc/alerts/stream` route çakışması yerelde giderildi, Redis `XREAD` idle timeout ve heartbeat mekanizmaları kuruldu.
* **Frontend:** Komut Paleti (`Ctrl+K`), AI Triage Paneli ve 254 testin tamamı yerelde başarıyla geçti.

---

## 2. MEVCUT DURUM VE KALAN 2 BLOCKER

1. **Canlıdaki Eski Backend İmajı (SSE 422 Hatası):**
   * Canlı sunucudaki backend container'ı eski versiyonda olduğu için `/soc/alerts/stream` isteğini UUID zannedip 422 veriyor. Yerel kodda düzeltme hazır, sadece canlı imajın build/restart edilmesi gerekiyor.
2. **Canlı Sunucu SSH Erişimi:**
   * `neosecra@10.34.99.11` sunucusuna SSH preflight testi `Permission denied (publickey,password)` ile reddedildiği için, güvenlik kuralları gereği canlı sunucuya zorlama yapılmadı. Durum `CHANGES_REQUIRED` olarak yerelde bekletildi.

---

## 3. SOC AGENT / CODEX İÇİN GECE MASTER GÖREV PROMPTU

```markdown
# GÖREV: NeoSecra SOC — L1/L2 Operasyonları, Background Worker Dayanıklılığı ve Yerel Release Hazırlığı

## 📌 BAĞLAM & ZORUNLU KURALLAR
1. `AGENTS.md` ve `.ai-ops/project-memory/SOC-MASTER-CONTEXT-2026-08-23.md` dosyalarını zorunlu kaynak olarak kabul et.
2. Roadmap sırasını kesinlikle bozma:
   - Adım 1: SOC Operations Center & Realtime
   - Adım 2: Settings Center & Konektör Güçlendirme
   - Adım 3: Background Worker & Idempotency / Dead-Letter Doğrulaması
   - Adım 4: OWASP API Security & RBAC Sınır Testleri
   - Adım 5: Release Candidate Packaging & Local Attestation
3. Canlı 10.34.99.11 hostuna yetkisiz deploy/restart yapma; tüm çalışmaları yerel repo ve testler üzerinde tamamla.
4. Dirty worktree'yi koru, sahte/mock başarı raporlama; her adımı gerçek test sayılarıyla doğrula.

---

## 🎯 SABAHA KADAR TAMAMLANACAK İŞ PAKETLERİ

### 1. İŞ PAKETİ: SETTINGS CENTER & KONEKTÖR HATA YÖNETİMİ (ROADMAP ADIM 2)
- **Graylog & Wazuh Fail-Closed Testleri:** Upstream Graylog/Wazuh servisleri kapalı veya timeout olduğunda sistemin çökmediğini, dead-letter kuyruğuna güvenle attığını ve müşteriye 500 yerine anlamlı hata döndüğünü test et.
- **Konektör Sağlık Durumu (Health Check):** Operatör için konektör bazlı latency, error_rate ve last_sync metriklerini doğrulayan backend unit testlerini tamamla.
- **Content & Rule Adapter Güvenliği:** backend/app/modules/soc/content/adapters.py içindeki pasif Sigma/Wazuh kurallarının hash, lisans ve provenance kontrollerini sıkılaştır.

### 2. İŞ PAKETİ: BACKGROUND WORKER, CELERY & IDEMPOTENCY (ROADMAP ADIM 3)
- **Olay Eşitleme Idempotency:** Aynı alert/IOC event'i iki kez işlendiğinde yinelenen (duplicate) incident veya log üretilmediğini doğrulayan pytest senaryoları yaz.
- **Worker Recovery & Retry:** Background görevlerin Redis kopması veya restart sonrasında kaldığı yerden devam edebildiğini (cursor recovery) test et.

### 3. İŞ PAKETİ: OWASP API GÜVENLİĞİ & RBAC FUZZING (ROADMAP ADIM 4)
- **Müşteri Sınır Fuzzing:** customer_admin ve customer_viewer rollerinin /api/v1/soc/internal/*, /connectors, /playbooks, /raw-logs endpoint'lerine yapacağı tüm isteklerin kesin olarak 403 Forbidden döndüğünü doğrulayan otomatik test suite'i genişlet.
- **Tenant IDOR Testleri:** Bir müşterinin başka bir müşterinin alert veya incident ID'sini sorguladığında 404/403 aldığını doğrula.

### 4. İŞ PAKETİ: LOCAL IMAGE ATTESTATION & RELEASE DOĞRULAMA (ROADMAP ADIM 5)
- release/verify-image-attestation.sh ve release/tests/test-image-attestation.sh betiklerini yerel test anahtarları (ephemeral cosign/openssl keypair) ile çalışabilir ve test edilebilir hale getir.
- release/build-release.sh çalıştırıldığında imaj etiketleri ve hash'lerin images.lock ile %100 uyuştuğunu doğrula.

---

### 📊 RAPORLAMA FORMATI
Sabah raporunda şu başlıkları eksiksiz sun:
- Değiştirilen dosyalar ve yeni eklenen testler.
- Pytest ve Frontend testlerinin tam sayıları (Pass / Fail / Skip).
- Çözülen P1/P2 maddeleri.
- Kalan blocker'lar ve sabah canlı deploy için gereken net adımlar.
```

---

## 4. HOTSPOT İÇİN MASTER E2E DOĞRULAMA PROMPTU

```markdown
# GÖREV: NeoSecra Hotspot & FortiGate Entegrasyonu Uçtan Uca (E2E) Tam Modül Denetimi ve Regresyon Testi

Aşağıdaki tüm modülleri, kimlik doğrulama yöntemlerini ve güvenlik duvarı (FortiGate) entegrasyonlarını uçtan uca test et:

1. **Toplantı Kodları:** Özel kod korunumu (VDATA2026), harf duyarsızlığı, yönetici onay muafiyeti ve FortiGate cihaz yetkilendirmesi.
2. **Yerel Kullanıcılar:** Yeni kullanıcı ekleme, silme ve aynı isimle tekrar oluşturulduğunda 409 Conflict yerine otomatik reaktivasyon.
3. **Oturum Yönetimi & FortiGate Silme:** İptal/yasaklama anında IP'ye ait tüm geçmiş hsess-* adreslerinin Guest ve hotspot-allowed gruplarından ve CMDB'den tamamen temizlenmesi.
4. **Cihazı Hatırla (MAC Bypass):** Aktif süresi devam eden cihazların portalda tanınıp tek tıkla/otomatik internete devam etmesi.
5. **Dahili FreeRADIUS & VPN MFA:** Docker içi UDP 1812 istemci eşleşmesi ve yeşil test yanıtı.
6. **Şablon Editörü:** Canlı önizleme iframe'inin ilk açılışta anında render edilmesi, FortiGate yönlendirme linki üretimi ve 5651 form alanları.

---

### 📊 RAPORLAMA:
Test sonuçlarını [✅ PASS / ❌ FAIL] formatında listele.
```

---

## 5. SABAH CANLIYA GEÇİŞ (DEPLOY) & DOĞRULAMA ADIMLARI

1. **SSH Erişiminin Sağlanması:**
   `neosecra@10.34.99.11` sunucusu için doğru SSH anahtarı veya parolası temin edilir.
2. **Release İmajlarının Güncellenmesi:**
   ```bash
   cd /home/sirgloomy/projects/neosecra-soc/release
   ./build-release.sh
   ```
3. **Canlı Sunucuya Dağıtım ve Servis Yenileme:**
   Yeni backend container imajı devreye alınarak `/soc/alerts/stream` endpoint'inin canlıda HTTP 200/SSE akışı vermesi sağlanır.
4. **Kabul Testlerinin Koşturulması:**
   Hotspot ve SOC arayüzlerinden nihai doğrulamalar yapılır.

---

## 6. TEK KOMUTLA ÇALIŞTIRILABİLİR CANLI TEST ARAÇLARI

Hotspot tarafında tüm canlı mekanizmaları tek seferde doğrulamak için:
```bash
python3 /home/sirgloomy/.gemini/antigravity-cli/brain/d25f68d5-a2d0-4bd8-a47e-240dbd907bd3/scratch/live_hotspot_suite.py
```
