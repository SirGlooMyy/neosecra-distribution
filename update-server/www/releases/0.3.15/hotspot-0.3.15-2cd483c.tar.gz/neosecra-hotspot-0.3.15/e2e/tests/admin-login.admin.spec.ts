import { test, expect } from "@playwright/test";

test.describe("Admin login UI", () => {
  test("login page renders with form fields", async ({ page }) => {
    await page.goto("/login");
    await expect(page).toHaveScreenshot("login-page.png");
    await expect(page).toHaveTitle(/Hotspot/);
    const emailInput = page.locator('input[type="email"]');
    const passwordInput = page.locator('input[type="password"]');
    const submitButton = page.locator('button[type="submit"]');
    await expect(emailInput).toBeVisible({ timeout: 15_000 });
    await expect(passwordInput).toBeVisible();
    await expect(submitButton).toBeVisible();
    await expect(emailInput).toHaveAttribute("placeholder", "admin@hotspot.com");
    await expect(submitButton).toContainText(/Giriş/i);
  });

  test("login form is fillable", async ({ page }) => {
    await page.goto("/login");
    const emailInput = page.locator('input[type="email"]');
    const passwordInput = page.locator('input[type="password"]');
    await emailInput.fill("admin@hotspot.com");
    await passwordInput.fill("Admin123!");
    await expect(page).toHaveScreenshot("login-form-filled.png");
    await expect(emailInput).toHaveValue("admin@hotspot.com");
    await expect(passwordInput).toHaveValue("Admin123!");
  });

  test("home page redirects to public landing when unauthenticated", async ({ page }) => {
    await page.goto("/");
    await page.waitForLoadState("networkidle", { timeout: 15_000 });
    const bodyText = await page.locator("body").innerText();
    expect(bodyText.length).toBeGreaterThan(50);
  });
});
