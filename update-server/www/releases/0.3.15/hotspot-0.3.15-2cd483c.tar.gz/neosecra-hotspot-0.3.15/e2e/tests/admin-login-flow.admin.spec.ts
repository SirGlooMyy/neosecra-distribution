import { test, expect } from "@playwright/test";

test.describe("Admin login UI (full E2E with API)", () => {
  test("login form submits and lands on dashboard with valid creds", async ({ page }) => {
    await page.goto("/login");
    await page.locator('input[type="email"]').fill("admin@hotspot.com");
    await page.locator('input[type="password"]').fill("Admin123!");
    await page.locator('button[type="submit"]').click();
    await page.waitForURL((url) => !url.pathname.includes("/login"), { timeout: 15_000 });
    const bodyText = await page.locator("body").innerText();
    expect(bodyText.length).toBeGreaterThan(100);
  });

  test("login form shows error on invalid credentials", async ({ page }) => {
    await page.goto("/login");
    await page.locator('input[type="email"]').fill("admin@hotspot.com");
    await page.locator('input[type="password"]').fill("WRONG-PASSWORD-FOR-E2E");
    await page.locator('button[type="submit"]').click();
    const errorBox = page.locator(".bg-rose-50, .text-rose-800").first();
    await expect(errorBox).toBeVisible({ timeout: 15_000 });
  });
});
