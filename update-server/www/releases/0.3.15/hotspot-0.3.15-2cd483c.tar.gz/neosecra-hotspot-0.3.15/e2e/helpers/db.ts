import { Pool } from "pg";

const pool = new Pool({
  host: process.env.PGHOST ?? "localhost",
  port: Number(process.env.PGPORT ?? 35432),
  user: process.env.PGUSER ?? "hotspot",
  password: process.env.PGPASSWORD ?? "hotspot",
  database: process.env.PGDATABASE ?? "hotspot",
  max: 4,
  idleTimeoutMillis: 5_000,
  connectionTimeoutMillis: 3_000,
});

export interface SmsOtpRow {
  id: string;
  phone: string;
  code_hash: string;
  customer_id: string;
  location_id: string | null;
  attempts: number;
  max_attempts: number;
  expires_at: Date;
  verified: boolean;
  consumed_at: Date | null;
}

/**
 * Look up the latest un-verified SMS OTP row for a phone number.
 * NOTE: This is a TEST helper only — the OTP `code_hash` is bcrypt and not
 * recoverable; the test calls the real /auth/sms/verify endpoint with the
 * expected code (123456) ONLY when DEMO_MODE is enabled in the API.
 * For real-OTP happy path, the test triggers the request and validates
 * the response. The negative paths (400/404/410/429) need no DB access.
 */
export async function getLatestOtp(phone: string): Promise<SmsOtpRow | null> {
  const res = await pool.query<SmsOtpRow>(
    `SELECT id, phone, code_hash, customer_id, location_id, attempts, max_attempts,
            expires_at, verified, consumed_at
       FROM sms_otps
      WHERE phone = $1
        AND verified = false
        AND consumed_at IS NULL
      ORDER BY created_at DESC
      LIMIT 1`,
    [phone],
  );
  return res.rows[0] ?? null;
}

export async function expireOtp(otpId: string): Promise<void> {
  await pool.query(`UPDATE sms_otps SET expires_at = NOW() - INTERVAL '1 minute' WHERE id = $1`, [otpId]);
}

export async function bumpOtpAttempts(otpId: string, attempts: number): Promise<void> {
  await pool.query(`UPDATE sms_otps SET attempts = $2 WHERE id = $1`, [otpId, attempts]);
}

export async function closePool(): Promise<void> {
  await pool.end();
}

export interface VoucherRow {
  id: string;
  batch_id: string;
  code_prefix: string;
  status: string;
  used_at: Date | null;
  expires_at: Date | null;
}

export async function getVoucherByCode(code: string): Promise<VoucherRow | null> {
  const res = await pool.query<VoucherRow>(
    `SELECT v.id, v.batch_id, v.code_prefix, v.status, v.used_at, v.expires_at
       FROM vouchers v
       JOIN voucher_batches vb ON vb.id = v.batch_id
      WHERE v.code_prefix = $1
      ORDER BY v.created_at ASC
      LIMIT 1`,
    [code.slice(0, 6)],
  );
  return res.rows[0] ?? null;
}

export async function expireVoucher(voucherId: string): Promise<void> {
  await pool.query(
    `UPDATE vouchers SET expires_at = NOW() - INTERVAL '1 minute' WHERE id = $1`,
    [voucherId],
  );
}

export async function resetVoucher(voucherId: string): Promise<void> {
  await pool.query(
    `UPDATE vouchers SET status = 'pending', used_at = NULL, used_by_session_id = NULL, used_phone = NULL WHERE id = $1`,
    [voucherId],
  );
}
