# Hotspot / Captive Portal / 5651 Platform - Foundation Package

Bu paket, ticari bir Hotspot / Captive Portal / 5651 Loglama / RADIUS / SMS-TC doğrulama platformu için **Sprint 00 Foundation** başlangıç paketidir.

Amaç: MVP hızlı çıksın, fakat temel mimari sonradan toparlanamayacak şekilde eksik bırakılmasın.

## Seçilen Ana Kararlar

| No | Karar |
|---|---|
| 1 | Hybrid başlayacak, ileride offline appliance desteklenecek |
| 2 | FortiGate doğrudan entegrasyon + opsiyonel SaaS Site Bridge |
| 3 | Tüm captive portal modelleri desteklenecek; MVP'de firewall redirect + harici portal |
| 4 | Auth: SMS + TC yazılım doğrulama + Voucher; ileride LDAP/AD, 802.1X, sosyal login |
| 5 | 5651: Syslog + RADIUS accounting + IP/MAC/NAT/zaman + hash + rapor |
| 6 | PostgreSQL + MinIO/S3 + ileride OpenSearch/ClickHouse |
| 7 | Multi-tenant + bayi + white-label + lokasyon |
| 8 | Hybrid lisans: lokasyon + cihaz + SMS paketi + yıllık abonelik |
| 9 | Portal template engine, tema yönetimi ve ön izleme ilk temelde olacak |
| 10 | Roller: süper admin + bayi + müşteri + lokasyon yetkilisi + destek/operasyon |
| 11 | Platform worker/agent zorunlu; SaaS Site Bridge opsiyonel; on-prem'de backend direkt local erişir |
| 12 | Enterprise-ready stack: FastAPI, PostgreSQL, Redis, Celery, React, MinIO, FreeRADIUS, Syslog Collector, Firewall Adapter, OpenSearch/ClickHouse hazırlığı, Site Bridge iskeleti |

## Paket İçeriği

- `docs/`: Ürün vizyonu, mimari, deployment, 5651, RADIUS, Syslog, firewall adapter, güvenlik, roadmap.
- `backend/`: FastAPI modüler iskelet, domain modelleri, API router yapısı, worker, adapter ve servis sınırları.
- `frontend/admin/`: Admin panel modül iskeleti.
- `frontend/portal/`: Captive portal template engine iskeleti.
- `site-bridge/`: SaaS senaryosu için opsiyonel bridge iskeleti.
- `infra/`: Docker Compose, FreeRADIUS, MinIO, Redis, PostgreSQL, OpenSearch/ClickHouse hazırlığı.
- `prompts/`: Architect, coder, reviewer, curator ve Sprint 00 master promptları.
- `CLAUDE.md`: Kod ajanları için proje kuralları.
- `.cursor/rules/`: Cursor kuralları.

## Çalıştırma Yaklaşımı

Bu paket hemen production kodu değildir; doğru mimari sınırları ve starter repo yapısını verir. Kod ajanlarına bu paket verilerek Sprint 00 -> Sprint 01 şeklinde ilerlenmelidir.
