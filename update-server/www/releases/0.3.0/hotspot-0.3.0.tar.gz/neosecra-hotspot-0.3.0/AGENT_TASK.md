# AGENT_TASK.md — Subgate Referansına Göre Proje Güncellemesi

## Amaç
Subgate referans görsellerindeki feature'ların eksiklerini tamamlayarak Hotspot platformunu Subgate seviyesine çıkarmak.

## Tespit Edilen Eksikler (Gap Analysis)

| # | Feature | Subgate'deki Karşılığı | Hotspot Durumu |
|---|---------|----------------------|----------------|
| 1 | **Kullanıcı Grupları** | Bandwidth limit, session/idle timeout, günlük/saatlik kota | ❌ Tamamen eksik |
| 2 | **Online Kullanıcılar** | Online users tabı, gerçek zamanlı görüntüleme | ❌ Sadece oturum sayısı var |
| 3 | **Ban/Whitelist** | Kullanıcı banlama (MAC/telefon), kara liste | ❌ Sadece MAB whitelist var |
| 4 | **Trafik Analizi** | Throughput grafikleri, top talkers, bant genişliği | ❌ Tamamen eksik |
| 5 | **Kullanıcı Yönetimi** | 6 tab: Users \| Online \| Banned \| Whitelist \| Meeting Codes | ❌ Dedicate sayfa yok |
| 6 | **Alarm Dashboard** | Alarm timeline, severity, istatistik | ❌ Sadece syslog trigger listesi |

## Uygulama Planı

### Aşama 1: Kullanıcı Grupları Modülü (backend)
- `backend/app/modules/user_groups/` modülü oluştur
  - `models.py`: UserGroup (name, description, bandwidth_up/down, session_timeout, idle_timeout, daily_quota, hourly_quota, speed_limit)
  - `schemas.py`: Pydantic modeller
  - `service.py`: CRUD işlemleri
  - `router.py`: REST API endpointleri
  - `repository.py`: DB işlemleri
- GuestSession modeline `group_id` FK ekle
- API router'a register et

### Aşama 2: Online Kullanıcılar (backend + frontend)
- `GET /api/v1/sessions/online` endpoint'i (sadece aktif oturumlar)
- Firewall adapter'lardan canlı session çekme (FortiGate, PaloAlto)
- Frontend: OnlineUsersPage.tsx

### Aşama 3: Ban/Whitelist Sistemi (backend + frontend)
- `backend/app/modules/ban/` modülü
  - `models.py`: BanRule (mac_address, phone, ip_address, reason, expires_at)
  - `Whitelist` modeli (MAB'den bağımsız)
- Frontend: BanWhitelistPage.tsx

### Aşama 4: Trafik Analizi (backend + frontend)
- `backend/app/modules/traffic/` modülü
  - TrafficStats, TrafficHourly modelleri
  - Top talkers, throughput trend, bandwidth usage endpointleri
- Frontend: TrafficAnalysisPage.tsx (grafikler)

### Aşama 5: Kullanıcı Yönetimi Sayfası (frontend + backend)
- Frontend: UsersPage.tsx (6 tab: Users | Online | Banned | Whitelist | Meeting Codes)
- Backend: user CRUD endpoint'leri

### Aşama 6: Alarm Dashboard (frontend)
- Frontend: AlarmDashboardPage.tsx
- Trigger events için timeline, severity pie chart, trend grafiği

## Öncelik Sırası
1. Kullanıcı Grupları (en büyük eksik)
2. Kullanıcı Yönetimi (UsersPage + Online + Ban/Whitelist)
3. Trafik Analizi
4. Alarm Dashboard
