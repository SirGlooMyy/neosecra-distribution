# Ürün Karar Kaydı

## 1. Deployment
- Ana model: Hybrid-ready.
- İlk çalışan model: On-prem first veya local lab/demo.
- SaaS: Mimari baştan destekler.
- Offline appliance: On-prem paketleme modelinin offline varyantı olarak desteklenecek.

## 2. Connector / Site Bridge Ayrımı

### Platform Agent / Worker
Zorunlu bileşendir. Backend içinde veya yanında çalışır.
Görevleri:
- Firewall sync
- RADIUS event processing
- Syslog parsing
- Session correlation
- 5651 archive/hash
- Report jobs
- SMS queue
- License usage calculation

### SaaS Site Bridge / Connector
Opsiyonel bileşendir. Sadece SaaS panelin müşteri local ağına güvenli erişmesi gerektiğinde kullanılır.
On-prem modelde gerekmez; backend zaten local ağdadır ve FortiGate/Palo Alto API, Syslog, RADIUS ile direkt konuşur.

## 3. Firewall Entegrasyonu
- MVP ana hedef: FortiGate.
- Palo Alto adapter iskeleti baştan olacak.
- Diğer vendorlar adapter pattern ile eklenecek.

## 4. Captive Portal
- Tüm modeller desteklenecek.
- İlk çalışan akış: Firewall captive redirect -> external portal -> SMS/TC/Voucher -> RADIUS/API access.
- VLAN/SSID bağlamı mutlaka lokasyon ve portal ile ilişkilendirilecek.

## 5. 5651
5651 iddiası için sadece giriş/çıkış kaydı yeterli değildir. Ürün şu korelasyonu hedefler:
- Kullanıcı/kimlik
- Telefon
- TC algoritmik validasyon sonucu
- Voucher bilgisi
- IP
- MAC
- NAT IP/Port bilgisi varsa
- Başlangıç/bitiş zamanı
- Lokasyon
- Firewall/gateway cihazı
- RADIUS accounting
- Syslog event
- Hashli arşiv ve rapor

## 6. Multi-tenant / Bayi
Hiyerarşi:
Super Admin -> Partner/Reseller -> Customer -> Location -> Device/SSID/Portal/Log Profile.

## 7. Lisans
Lisans metrikleri:
- Lokasyon
- Firewall/gateway cihazı
- SMS paketi
- Log saklama kapasitesi
- White-label paket
- On-prem yıllık bakım/lisans
 
## 8. Sprint İlerleme ve Durum Kaydı
 
### Sprint 03 — Alembic Migration + PostgreSQL Schema + Seed Data (Tamamlandı)
* **Kapsam:** Tüm veri tabanı modellerinin (15 ana kategori) Alembic migration (`bd3a07a1583c`) ile otomatik üretilmesi sağlandı.
* **Seed Data:** `seed_demo.py` ile default Tenant, Partner, Customer, Location, FortiGate cihazı, Portal şablonu, Lisans kotası, Voucher batch ve özel voucher'lar (`DEMO2026`, `HOTSPOT`, `GUEST`) güvenli şekilde eklenir hale getirildi.
* **Testler:** Migration varlığı, seed importları, metadata tablo kontrolleri ve tenant-bound model doğrulama testleri yazıldı ve yeşillendi.
 
### Sprint 04 — Backend Auth + Tenant Isolation Foundation (Tamamlandı)
* **Kapsam:** JWT auth altyapısı, token blacklist (Redis), rate limit ve şifreleme pratikleri tamamlandı. `passlib` ile `bcrypt >= 4.0.0` arasındaki 72 karakter uyumluluk problemi runtime patch ile aşılmıştır.
* **Endpointler:** `POST /login`, `POST /logout`, `POST /refresh`, `GET /me` ve rol bazlı izinleri döndüren `GET /permissions` endpointleri eklendi.
* **Tenant Isolation:** Servis katmanında `ScopeContext` ve `scope_for(user)` yardımıyla "fail-closed" (atanmamış id'lere karşı otomatik erişim reddi) izolasyon mantığı doğrulandı.
* **Seed Data:** `seed_demo.py` güncellenerek 5 farklı RBAC rolü için demo kullanıcılar (`superadmin`, `partneradmin`, `customeradmin`, `support`, `manager`) eklendi.
* **Testler:** Auth ve isolation akışını test eden kapsamlı unit/integration testleri eklendi ve tümü başarıyla tamamlandı.

### Sprint 05 — Portal API Integration Layer (Tamamlandı)
* **Kapsam:** Captive Portal Frontend'inin mock API yerine backend API'lerine (`GET /portal/config`, SMS/Voucher verify, vb.) bağlantısı gerçekleştirildi.
* **API İyileştirmeleri:** `/portal/config` endpoint'inde `location_id` parametresi opsiyonelleştirildi (veritabanındaki ilk aktif lokasyon fallback) ve `locationId` alanının geri döndürülmesi sağlandı. Bu sayede query params olmadan da geliştirme/test ortamında çalışabilirlik artırıldı.
* **Frontend Entegrasyonu:** Dynamic config yüklenmesi, SMS gönderimi, SMS doğrulaması, T.C. kimlik + SMS doğrulaması ve Voucher doğrulaması tamamen gerçek API'lere bağlandı; mock gecikmeler ve statik listeler temizlendi.
* **Testler ve Build:** Backend test paketine portal config endpoint doğrulaması eklendi (toplam 21 test yeşillendi). Portal frontend uygulaması TypeScript/Vite ile sıfır hata/uyarı ile başarılı şekilde build edildi.


### Sprint 06 — Backend Test Baseline (Tamamlandı)
* **Kapsam:** Kök 5651 smoke (53 passed) ve tam backend suite (384 passed, 10 failed, 18 skipped) baseline çıkarıldı. PDF+portal_voucher pre-existing failures kayıt altına alındı.
* **Test Metriği:** 384 passed, 58.09s. 10 pre-existing failure (regresyon değil). Frontend build: NOT_MEASURED.

### Sprint 07 — FortiLogger Syslog MVP (Tamamlandı)
* **Kapsam:** TCP 514 async receiver, RFC 5424 parser (traffic/event/utm), FirewallLog model, tenant-scoped ingest. 27 yeni test, 100% yeşil.
* **Mimari Karar:** RFC 5424 structured-data alanları JSONB'de saklanır, tenant_id ingest anında log satırına gömülür.

### Sprint 07b — Detaylı Log Search Backend (Tamamlandı)
* **Kapsam:** GIN index + tsvector fulltext search, 4 endpoint (search/facets/correlate/export), 31 yeni test.
* **Mimari Karar:** GIN index sequential scan'e göre ~8x hızlı (100ms hedefi tuttu). ClickHouse adapter duruyor ama MVP için PostgreSQL yeterli.

### Sprint 08 — SubGate Captive Portal (Tamamlandı)
* **Kapsam:** Fake FortiGate server ile redirect → SMS verify → authorize_guest → session log akışı. Session correlation + RADIUS accounting entegrasyonu.
* **Mimari Karar:** FortiGate external captive portal RFC 8908 esinli redirect. Session correlation MAC+IP+session_id üçlüsü ile çalışır. RADIUS accounting CoA MVP dışı.

### Sprint 09 — SignLogger Hash Chain + Local Cert CAdES (Tamamlandı)
* **Kapsam:** SHA256 sequential hash chain H(n)=SHA256(log_n+H(n-1)), local PKCS#12 sertifika ile CAdES imza, MinIO WORM GOVERNANCE 730d bucket. 27 yeni test.
* **Mimari Karar:** Hash chain sequential (Merkle tree değil) — legal 5651 için her kaydın tek başına doğrulanabilir olması yeterli. Local cert CAdES KamuSM/E-Tuğra REST sonrası geçilecek.

### Sprint 10 — E2E Integration + BTK Export (Tamamlandı)
* **Kapsam:** 15 E2E test (MVP full flow, multi-tenant isolation, failure scenarios, BTK export format, performance smoke). Toplam 515 passed, 0 failed.
* **Mimari Karar:** BTK 5651 export formatı (column order, ISO 8601 date, UTF-8 BOM CSV) doğrulandı. Tenant isolation tüm katmanlarda test edildi.

### Genel Mimari Kararlar (Sprint 06-11)
- **Hash chain sequential** — Merkle tree yerine H(n)=SHA256(log_n+H(n-1)) seçildi. Her log kaydı tek başına doğrulanabilir, zincir kırılması tespit edilebilir. RFC 5848 syslog-sign esinli.
- **Local cert CAdES** — KamuSM/E-Tuğra REST olmadığı için local PKCS#12 ile CAdES imza. Üretimde KamuSM API'sine geçilecek.
- **GIN index** — ClickHouse disabled durumda, PostgreSQL GIN index + tsvector ile <100ms search hedefi tutturuldu.
- **RFC 5424 parser** — structured-data JSONB'de, timestamp microsecond precision, fallback RFC 3164. Üretimde 10K msg/s hedefi için async queue gerekebilir.
