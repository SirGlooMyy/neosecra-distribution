# Hotspot Platform — Frontend Planı

> Durum: **Plan** (kod yazılmadı). Bu dosya tek seferde implementasyona hazır, tam kapsamlı plandır.
> Backend API'si canlı ve testten geçti (`http://localhost:8001`, 45 route). Bu plan o API'ye birebir bağlıdır.
> Tarih: 2026-07-10 · Stack: React + TypeScript + Tailwind + shadcn/ui

---

## 1. Hedef & Kapsam

İki ayrı frontend uygulaması:

| App | Dizin | Kim kullanır | Amaç |
|-----|-------|--------------|------|
| **Admin Panel** | `frontend/admin` | Operator/bayi/müşterinin IT personeli (5 role) | Platform yönetimi: tenant/partner/customer/location/cihaz/portal/voucher/session/license/log-rapor |
| **Captive Portal** | `frontend/portal` | WiFi misafirleri (anonim) | Captive splash: telefona SMS kodu / voucher / TC ile giriş → firewall authorize |

**Kapsam = TAM** (MVP değil). 45 backend route'unun tümüne karşılık gelen UI, RBAC role-bazlı menü, filtre, form validasyon, light/dark tema, runtime branding, release/OTA mekanizmaları.

**Tasarım dili:** Modern SaaS (Linear/Vercel estetiği) — bol whitespace, ince 1px border, yumuşak gölge, Inter tipografi, nötr palet + tek accent, light/dark. Captive portal ayrı estetik: mobile-first tek ekran splash.

---

## 2. Stack & Tasarım Sistemi

### 2.1 Ortak teknoloji (her iki app)
- **Build:** Vite + React 18 + TypeScript (strict)
- **Stil:** Tailwind CSS + CSS variables (HSL token'lar) → light/dark tema
- **UI kit:** shadcn/ui (Radix primitives üzerine) — Button, Card, Input, Select, Table, Dialog, Sheet, Tabs, DropdownMenu, Command, Toast/Sonner, Form, Badge, Skeleton, Tooltip
- **Tipografi:** Inter (fontsource)
- **İkon:** lucide-react
- **Tablo:** TanStack Table v8 (sort/filter/pagination client-side)
- **Form:** react-hook-form + zod (backend Pydantic şemalarıyla birebir zod mirror)
- **Server state:** TanStack Query v5 (cache, retry, optimistic)
- **Router:** React Router v6 (admin) / basit state machine (portal — tek akış)
- **HTTP:** fetch wrapper + interceptor (401 → refresh token rotasyonu)
- **i18n:** Türkçe varsayılan (ilk faz), yapı `react-i18next` hazır (ileride EN)

### 2.2 Tasarım token'ları (her iki app `src/styles/tokens.css`)
```
--background, --foreground, --card, --border, --muted, --primary, --primary-foreground,
--accent, --ring, --radius (0.5rem), --shadow (soft)
```
Brand rengi runtime'da override edilebilir (Bölüm 6). Varsayılan: `--primary` nötr indigo (#4f46e5 tonu).

### 2.3 Kalite çıtaları ("şık" = bu kurallar)
- Her listede boş durum (empty state) illüstrasyonlu, yüklenirde skeleton, hatada retry.
- Tüm formlar zod ile anlık validasyon, hata mesajları Türkçe, submit butonu loading state.
- Tablolar: satır hover, sticky header, satır aksiyon menüsü (Düzenle/Sil), sayfalama.
- Tüm destructive aksiyonlar (delete/deactivate) onay dialog'u (AlertDialog).
- Toast bildirimleri (Sonner) — success/error tutarlı.
- Erişilebilirlik: klavye navigasyonu, focus ring, ARIA, kontrast AA.

---

## 3. Backend API Referansı (planın bağımlılığı)

Canlı base: `http://localhost:8001` (offset port — IT-Sec ile çakışmaz). Prod'da `/api/v1`.

### 3.1 Auth
- `POST /auth/login` `{email,password}` → `TokenResponse{access_token,refresh_token,token_type,user:UserOut}`
- `POST /auth/refresh` `{refresh_token}` → `TokenResponse`
- `POST /auth/logout` (opsiyonel body refresh) → 204 (idempotent)
- `GET /auth/me` → `UserOut`

### 3.2 Roller (RBAC) — menü ve sayfa görünürlüğü buna bağlı
```
super_admin     → * (her şey)
partner_admin   → customer, location, device, portal, voucher, session, identity,
                   archive, report, user.read, license(read+write)
customer_admin   → location, device, portal, voucher, session, identity, archive,
                   report, user.read, license.read   (license.write YOK — self-serve engeli)
location_manager → device.read, session.read, report.read, voucher.read, portal.read,
                   identity.read, archive.read   (sadece okur)
support         → session.read, report.read, device.read, log.read, identity.read, archive.read
```
Hiyerarşi (kullanıcı yönetimi): super > partner > customer > location_manager > support (`can_manage_role`).

### 3.3 CRUD modülleri (hepsi `GET list / POST create / GET {id} / PUT {id} / DELETE {id}`)
Tenant, Partner, Customer, Location, Device, PortalTemplate, VoucherBatch, License, Session(read+close), Identity(read), Log5651(read+build+verify), Report(read).

### 3.4 Captive Portal public akışı (`/portal/public/*`, auth yok)
1. `GET /portal/public/context?device_id=&mac=&ip=&ssid=` → `PortalContextOut{method, theme, ...}` (cihaz+lokasyon+customer'dan template seçilir)
2. method == `sms` → `POST /portal/public/send-code {device_id, phone}` → OTP gönderilir (console provider dev'de)
3. `POST /portal/public/start-session {device_id, portal_token, mac, ip, ssid}` → portal token
4. `POST /portal/public/verify {device_id, phone, code, tc_number, voucher_code}` → firewall authorize

**method enum:** `free` (direkt bağlan) | `sms` (telefon+kod) | `voucher` (kod) | `tc` (kimlik). Portal UI method'a göre dallanır.

### 3.5 ⚠️ Backend gap'leri (frontend öncesi çözülecek — Bölüm 9)
1. **`/users` endpoint'i YOK** ama RBAC'te `user.read/write` var → admin kullanıcı yönetimi için backend'e CRUD eklenmeli (Bölüm 9.1).
2. **Pagination yok** list endpoint'lerinde (düz `[]` döner) → backend'e `?offset=&limit=&q=` eklenmeli veya client-side TanStack Table pagination (Bölüm 9.2).

---

## 4. Admin Panel (`frontend/admin`)

### 4.1 Sayfa ağacı & RBAC menü eşlemesi
Menü, kullanıcının role'üne göre permission ile filtrelenir. Gösterim koşulu = permission:

| Menü | Route | Gereken permission | super | partner | customer | loc.mgr | support |
|------|-------|--------------------|:-----:|:-------:|:--------:|:-------:|:-------:|
| Dashboard | `/` | (herkes) | ✓ | ✓ | ✓ | ✓ | ✓ |
| Tenantlar | `/tenants` | tenant.* | ✓ | — | — | — | — |
| Bayiler | `/partners` | partner.* | ✓ | — | — | — | — |
| Müşteriler | `/customers` | customer.read | ✓ | ✓ | — | — | — |
| Lokasyonlar | `/locations` | location.read | ✓ | ✓ | ✓ | — | — |
| Cihazlar | `/devices` | device.read | ✓ | ✓ | ✓ | ✓ | ✓ |
| Portal Şablonları | `/portal` | portal.read | ✓ | ✓ | ✓ | ✓ | — |
| Voucher Batch | `/vouchers` | voucher.read | ✓ | ✓ | ✓ | ✓ | — |
| Oturumlar | `/sessions` | session.read | ✓ | ✓ | ✓ | ✓ | ✓ |
| Kimlik Doğr. | `/identities` | identity.read | ✓ | ✓ | ✓ | ✓ | ✓ |
| Lisanslar | `/licenses` | license.read | ✓ | ✓ | ✓ | — | — |
| 5651 Logları | `/logs-5651` | archive.read | ✓ | ✓ | ✓ | ✓ | ✓ |
| Raporlar | `/reports` | report.read | ✓ | ✓ | ✓ | ✓ | ✓ |
| Kullanıcılar | `/users` | user.read | ✓ | ✓ | ✓ | — | — |
| Ayarlar/Profil | `/settings` | (herkes) | ✓ | ✓ | ✓ | ✓ | ✓ |

`*` (super_admin) tüm menüyü görür. Yazma butonları (Yeni/Düzenle/Sil) ilgili `.write` permission'ında.

### 4.2 Sayfa detayları (alan → API eşlemesi)

Her CRUD sayfası aynı şablondan: **Liste (tablo+filtre) → Yeni (Dialog/Form) → Düzenle (Dialog) → Detay (Sheet/Drawer) → Sil (AlertDialog)**.

#### Dashboard (`/`)
- KPI kartları: aktif oturum sayısı, bugünkü guest girişleri, aktif cihaz, kalan kota (role scope'una göre).
- Son 24s oturum grafiği (küçük sparkline), son işlemler feed'i.
- API: `GET /sessions`, `GET /devices`, `GET /licenses/{customer_id}/quota`.

#### Tenantlar (`/tenants`) — super only
- Form: `name, slug, domain, is_root` (POST `TenantCreate`); update: `name, slug, domain, is_active`.
- Tablo: ad, slug, domain, root rozeti, aktif, oluşturma.

#### Bayiler (`/partners`)
- Form: `name, reseller_code, contact_email, contact_phone, tenant_id` (select); update + `is_active`.

#### Müşteriler (`/customers`)
- Form: `name, contact_name, contact_email, contact_phone, partner_id` (select).
- Satır → tıkla: bağlı lokasyon/cihaz sayısı, lisans özeti (Sheet).

#### Lokasyonlar (`/locations`)
- Form: `name, address, city, default_ssid, timezone, customer_id` (select).

#### Cihazlar (`/devices`)
- Form: `name, vendor (select: fortigate/...), model, mgmt_ip, api_host, api_port, meta (json), location_id`.
- Satır aksiyonları: **Test Connection** (`POST .../test-connection`), **Discover** (`POST .../discover`), **Credential** (PUT/GET `CredentialSet{api_token, api_username, api_vdom, ssh_key, verify_tls}`).
- authorize-guest / revoke-guest aksiyon butonları.

#### Portal Şablonları (`/portal`)
- Form: `name, method (select), theme (json/renk), fields (dynamic), success_message, terms_url, meta, customer_id, location_id, is_default`.
- **Canlı önizleme**: seçilen method+theme ile captive portal görünümü küçük preview pane.
- Bu sayfa runtime branding'in yönetim arayüzü (Bölüm 6).

#### Voucher Batch (`/vouchers`)
- Liste: batch adı, prefix, count, süre, bitiş, aktif.
- Yeni batch: `customer_id, location_id, name, prefix, count, duration_minutes, expires_at`.
- Detay → `GET .../vouchers` (batch içindeki kodlar, CSV export butonu).
- Deactivate: `POST .../deactivate`.

#### Oturumlar (`/sessions`) — read-heavy
- Tablo: guest, cihaz, lokasyon, başlangıç, süre, durum.
- Satır → Detay (Sheet): `GET .../correlation` (syslog/radius korelasyon), **Kapat** (`POST .../close {reason}`).

#### Kimlik Doğrulama (`/identities`)
- Liste: telefon(maskeli), tc durumu, method, zaman, durum.
- Detay: `GET /identities/{id}`.

#### Lisanslar (`/licenses`)
- Liste/ara: customer, plan, kota (aktif guest / max), bitiş, trial rozeti.
- Düzenle (partner+super): `LicenseUpsert{active_guests_quota, max_sessions_per_day, session_minutes_default, expires_at, is_trial, is_active, plan, meta}`.
- Kota paneli: `GET .../quota`.
- ⚠️ customer_admin sadece okur (write butonu gizli — RBAC).

#### 5651 Logları (`/logs-5651`)
- Liste: customer, dönem, record_type, hash durumu, oluşturma.
- **Arşiv oluştur**: `POST /build {customer_id, record_type, period_start, period_end}`.
- **Zincir doğrula**: `GET /verify/{customer_id}` → bütünlük sonucu (append-only, kırmızı/yeşil rozet).
- Detay + indir (record).

#### Raporlar (`/reports`)
- Filtreli liste + **Oturum Export** (`GET /reports/sessions/export` → CSV/Excel indirme).

#### Kullanıcılar (`/users`) — ⚠️ backend gap (Bölüm 9.1)
- Liste, yeni (role select + tenant/partner/customer scope), düzenle, 2FA durum toggle, deaktif.
- Hiyerarşi kuralı: actor ancak eşit/kendi altındaki role'ü yönetir.

#### Ayarlar (`/settings`)
- Profil (ad, email), şifre değiştir, 2FA (TOTP) kurulumu (QR), tema tercihi (light/dark/system), dil.

### 4.3 Admin dosya yapısı
```
frontend/admin/
  package.json, vite.config.ts, tailwind.config.ts, tsconfig.json
  index.html
  Dockerfile              # multi-stage: node build → nginx (Bölüm 7)
  .env.example            # VITE_API_BASE
  src/
    main.tsx, App.tsx
    styles/{tokens.css, globals.css}
    lib/{api.ts (fetch+interceptor), queryClient.ts, permissions.ts (RBAC→menü), utils.ts}
    components/
      ui/                 # shadcn primitives
      layout/{AppShell,Sidebar,Topbar,Breadcrumb,ThemeToggle}
      shared/{DataTable,FormField,ConfirmDialog,EmptyState,StatusBadge,KpiCard}
    features/
      auth/               # login page, useAuth, token rotation
      tenants/, partners/, customers/, locations/, devices/,
      portal/, vouchers/, sessions/, identities/, licenses/,
      logs5651/, reports/, users/, settings/
        # her feature: {api.ts, hooks.ts, schema.ts (zod), List.tsx, Form.tsx, Detail.tsx}
    routes.tsx            # protected routes + permission guard
```

---

## 5. Captive Portal (`frontend/portal`)

### 5.1 Akış (tek state machine, auth yok)
```
[splash yükle]
   │ GET /portal/public/context?device_id&mac&ip&ssid
   ▼
[PortalContextOut.method]
   ├─ free   → "İnternete Bağlan" butonu → POST /verify → success
   ├─ sms    → telefon input → POST /send-code → kod input → POST /verify → success
   ├─ voucher→ voucher kod input → POST /verify → success
   └─ tc     → TC + telefon → POST /send-code → kod → POST /verify (tc_number) → success
   ▼
[success_message + marka rengi] → (firewall authorize oldu, internet açık)
```
- Hata: yanlış kod (limit 3 deneme), kota dolu (license.enforce_quota), cihaz geçersiz → nett error ekranı + retry.
- Geri sayım: SMS kodu TTL (180s), "tekrar gönder" (rate limit 3/15dk).

### 5.2 Portal sayfaları
- `index.html` — tek sayfa, query param'dan `device_id,mac,ip,ssid` okur.
- Bileşenler: `SplashCard` (marka logolu kart), `PhoneStep`, `CodeStep`, `VoucherStep`, `TcStep`, `SuccessScreen`, `ErrorScreen`.
- `theme` context'ten: arka plan rengi, logo URL, font → runtime branding (Bölüm 6).

### 5.3 Portal dosya yapısı
```
frontend/portal/
  package.json, vite.config.ts, tailwind.config.ts, tsconfig.json
  index.html
  Dockerfile              # nginx (Bölüm 7/8)
  src/
    main.tsx, App.tsx
    styles/{tokens.css, splash.css}
    lib/{api.ts, flow.ts (state machine)}
    components/{SplashCard, PhoneStep, CodeStep, VoucherStep, TcStep, SuccessScreen, ErrorScreen}
    hooks/{usePortalContext.ts}
```

---

## 6. Runtime Branding (tema/renk/logo — yeniden build gerektirmez)

- **Kaynak:** `PortalTemplate.theme` + `meta` (DB). Admin → Portal Şablonları sayfasından edit edilir.
- **Dağıtım:** Portal app açılışta `GET /portal/public/context` ile `theme`+`logo` çeker; CSS variable'ları runtime'da set eder (`document.documentElement.style.setProperty('--primary', ...)`).
- Admin panel de kendi markasını `/settings` → tenant/customer branding ile aynı mekanizmadan okur.
- Build'den bağımsız: yeni müşteri/renk eklemek için deploy yok, DB kaydı yeterli.

---

## 7. Release & Güncelleme (deploy stratejisi)

### 7.1 Build & image
- Her app ayrı **multi-stage Dockerfile**:
  - `stage 1 (node:20-alpine)`: `npm ci && npm run build` → `dist/`
  - `stage 2 (nginx:alpine)`: `dist/` kopyala + `nginx.conf` (SPA fallback → `/api` proxy backend)
- Image tag kuralı: `hotspot-admin:<version>` ve `hotspot-portal:<version>` (version = semver veya git sha).

### 7.2 Compose entegrasyonu
- `docker-compose.yml`'ye `admin` ve `portal` servisleri eklenir (build context `./frontend/admin`, `./frontend/portal`).
- Port: admin `5174:80` (or offset `5175`), portal `8080:80` (captive için 80/http standard).
- `nginx.conf` `/api/*` → `http://api:8000` reverse proxy (aynı docker network).

### 7.3 CI/CD (repo git'e taşınınca)
- GitHub Actions: `push tag v*` → build image → push registry (GHCR) → staging otomatik, prod manuel onay.
- **Rollback:** önceki image tag'i compose'ta set + `docker compose up -d admin portal`. Tag sabit olduğu için anında geri dönüş.

### 7.4 Versiyon görünürlüğü
- Her app `/version` (build-time injected `import.meta.env.VITE_APP_VERSION`) + backend `/health` ile uyum.

---

## 8. Müşteriye Dağıtım + OTA

İki dağıtım modeli (CLAUDE.md Kural #9/#10 uyumlu):

### 8.1 SaaS model (merkezi hosted)
- Portal + admin bulutta hosted. Müşterinin FortiGate/cihazı captive portal URL'sine (`https://portal.hotspot...`) redirect eder.
- **Güncelleme anında:** merkezi image'ı bump → tüm müşteriler bir sonraki splash yüklemede yeni sürümü görür. OTA gerekmez.

### 8.2 On-prem model (cihazda lokal)
- Portal bundle'ı cihaza push edilir (nginx static). **Site-Bridge** (mevcut backend modülü) üzerinden:
  - Admin → "Portal sürümü yayınla" → bundle build → bridge cihaza push → cihaz lokal nginx'e yerleştirir.
  - **OTA:** her bundle `manifest.json` (version, checksum) taşır; bridge version farkını görüp günceller, rollback manifest ile.
- Portal = pure static SPA olduğu için OTA = dosya değişimi, runtime upgrade riski yok.

### 8.3 Plan notu
- Faz 1 (bu plan): SaaS model + docker-compose'da lokal servisler. On-prem OTA bundle mekanizması Faz 2 (site-bridge entegrasyonu), ama dosya yapısı buna hazır (static build, manifest hook).

---

## 9. Backend Gap'leri (frontend öncesi)

### 9.1 `/users` CRUD eksik (Kullanıcılar sayfası bağımlı)
- RBAC'te `user.read/write` tanımlı ama endpoint yok.
- **Çözüm:** backend'e `app/modules/auth/` altında users router ekle: `GET /users`, `POST /users`, `PUT /users/{id}`, `DELETE /users/{id}` (soft). Scope = actor'ün tenant/partner/customer hiyerarşisi. `can_manage_role` ile target role kontrolü. 2FA durum toggle.
- Bu, admin planından **ayrı bir backend task'ı** (medium risk — RBAC/tenant izolasyonu → CLAUDE.md Kimi review).

### 9.2 Pagination eksik
- Liste endpoint'leri düz `[]` döner, query param yok.
- **Çözüm (tercih sırası):** (a) backend'e `offset/limit/q` + `Paged<T>{items,total}` ekle (tutarlı, önerilen); (b) değilse client-side TanStack Table pagination (küçük veri için geçici).

---

## 10. Implementasyon Adımları (tek seferde çıkacak sıra)

> Sıralı bağımlılıklarla. Her adım kendi içinde test edilebilir.

1. **Monorepo kurulması** — `frontend/admin` ve `frontend/portal` Vite scaffold, Tailwind + shadcn/ui + tokens.css, light/dark.
2. **Ortak lib** — `api.ts` (fetch + 401→refresh rotasyonu), `queryClient.ts`, `permissions.ts` (role→menü), zod mirror'ları.
3. **Admin: Auth & AppShell** — login sayfası, token yönetimi, sidebar+topbar, route guard, RBAC menü filtresi.
4. **Admin: shared bileşenler** — DataTable, FormField, ConfirmDialog, EmptyState, StatusBadge, KpiCard.
5. **Admin: CRUD sayfaları** — Tenant→Partner→Customer→Location→Device→Portal→Voucher→Session→Identity→License→Logs5651→Reports (her biri liste+form+detay). (Sırayla; Device credential/test-connection ve Session correlation alt-akışları dahil.)
6. **Backend gap 9.1** — `/users` CRUD + sonra Admin Users sayfası. (Backend task, araya girer.)
7. **Backend gap 9.2** — pagination (backend veya client-side karar verilecek).
8. **Captive Portal** — context fetch, state machine, 4 method ekranı, success/error, runtime theme.
9. **Runtime branding** — Portal Şablonları theme edit → context dağıtımı → portal/admin tema apply.
10. **Docker & compose** — her app multi-stage Dockerfile, compose servisleri, nginx proxy, port ataması.
11. **Release/CI** — image tag kuralı, version injection, CI workflow (git'e taşınınca), rollback prosedürü dokümante.
12. **On-prem OTA hazırlığı (Faz 2 hook)** — manifest.json şeması, site-bridge push stub (gerçek entegrasyon Faz 2).
13. **Kalite geçişi** — her sayfada empty/skeleton/error, zod validasyon, klavye/erişilebilirlik, light/dark görsel kontrol.

---

## 11. Kabul Kriterleri

- [ ] Admin: 5 role'nin tümü doğru menü/izin görür (super her şey; customer license.write görmez; location_manager sadece okur).
- [ ] Admin: her CRUD modülü listele/oluştur/düzenle/sil çalışır, zod validasyon aktif, delete onaylı.
- [ ] Device: test-connection/discover/credential; Session: correlation + close; Logs5651: build + verify; Voucher: CSV export.
- [ ] Portal: free/sms/voucher/tc akışlarının dördü baştan sona çalışır, firewall authorize olur.
- [ ] Portal: yanlış kod (3 deneme), kota dolu, geçersiz cihaz senaryoları doğru error ekranı verir.
- [ ] Runtime branding: DB'den tema değişince portal/admin yeniden build olmadan renk değişir.
- [ ] light/dark her iki app'te görsel olarak temiz.
- [ ] docker compose up → admin + portal + backend tek komutta kalkar, nginx /api proxy çalışır.
- [ ] Image tag + rollback prosedürü dokümante ve uygulanabilir.
- [ ] Erişilebilirlik: klavye navigasyonu, focus ring, kontrast AA.

---

## 12. Riskler & Notlar

- **RBAC doğruluğu:** menü/gizleme frontend'de kolay atlatılabilir; gerçek güvenlik backend'de. Frontend yalnızca UX için gizler.
- **Tenant izolasyonu:** tüm liste sorguları backend scope ile filtrelenmeli (CLAUDE.md Kural #2) — frontend bunu varsayar, test IDOR (Kural: "IDOR testleri yazılacak").
- **Token storage:** access token memory'de, refresh token httpOnly cookie ideal; JWT ise memory + refresh interceptor (XSS'e karşı).
- **On-prem OTA Faz 2:** bu plan Faz 1 (SaaS + lokal compose). Cihaz push gerçek entegrasyonu site-bridge ile ayrı.
- **Kullanıcı yönetimi (9.1)** RBAC/hiyerarşi içerir → medium risk, backend task olarak Kimi analyze + review ile yapılmalı (CLAUDE.md).
