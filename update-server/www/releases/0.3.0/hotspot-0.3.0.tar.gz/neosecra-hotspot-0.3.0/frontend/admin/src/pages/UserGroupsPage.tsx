import React, { useState, useEffect } from "react";
import {
  getUserGroups,
  createUserGroup,
  updateUserGroup,
  deleteUserGroup,
  getCurrentScope,
  getLocations,
  getUserGroupPolicyPreview,
} from "../lib/api";
import { ArrowRight, Edit2, Info, Plus, Save, Trash2, Users, X, Clock } from "lucide-react";

interface UserGroup {
  id: string;
  customer_id: string;
  location_id: string | null;
  name: string;
  description: string;
  bandwidth_up: number | null;
  bandwidth_down: number | null;
  session_timeout: number | null;
  idle_timeout: number | null;
  daily_quota: number | null;
  weekly_quota: number | null;
  monthly_quota: number | null;
  hourly_quota: number | null;
  max_sessions: number;
  is_default: boolean;
  is_active: boolean;
  priority: number;
  access_start: string | null;
  access_end: string | null;
}

const buildEmptyForm = (customerId: string = "") => ({
  customer_id: customerId,
  location_id: null as string | null,
  name: '',
  description: '',
  bandwidth_up: null as number | null,
  bandwidth_down: null as number | null,
  session_timeout: null as number | null,
  idle_timeout: null as number | null,
  daily_quota: null as number | null,
  weekly_quota: null as number | null,
  monthly_quota: null as number | null,
  hourly_quota: null as number | null,
  max_sessions: 1,
  is_default: false,
  priority: 0,
  access_start: null as string | null,
  access_end: null as string | null,
});

export const UserGroupsPage: React.FC = () => {
  const [groups, setGroups] = useState<UserGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [currentCustomerId, setCurrentCustomerId] = useState('');
  const [currentLocationId, setCurrentLocationId] = useState<string | null>(null);
  const [locations, setLocations] = useState<any[]>([]);
  const [form, setForm] = useState(() => buildEmptyForm());
  const [policyPreview, setPolicyPreview] = useState<any>(null);
  const [policyPreviewLoading, setPolicyPreviewLoading] = useState(false);
  const [policyPreviewError, setPolicyPreviewError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await getUserGroups();
      setGroups(data);
      if (!currentCustomerId && data?.[0]?.customer_id) {
        setCurrentCustomerId(String(data[0].customer_id));
      }
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    (async () => {
      try {
        const data = await getLocations();
        setLocations(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error(err);
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      const scope = await getCurrentScope();
      if (scope?.customer_id) {
        setCurrentCustomerId(scope.customer_id);
      }
      if (scope?.location_id) {
        setCurrentLocationId(scope.location_id);
      }
    })();
  }, []);

  useEffect(() => {
    if (!currentCustomerId) return;
    setForm((prev) => prev.customer_id === currentCustomerId ? prev : buildEmptyForm(currentCustomerId));
  }, [currentCustomerId]);

  useEffect(() => {
    if (!currentLocationId) return;
    setForm((prev) => prev.location_id === currentLocationId ? prev : { ...prev, location_id: currentLocationId });
  }, [currentLocationId]);

  useEffect(() => {
    const customerId = currentCustomerId || form.customer_id;
    if (!customerId) return;

    let cancelled = false;
    const loadPolicyPreview = async () => {
      setPolicyPreviewLoading(true);
      setPolicyPreviewError(null);
      try {
        const preview = await getUserGroupPolicyPreview(customerId, form.location_id || null);
        if (!cancelled) setPolicyPreview(preview);
      } catch (err: any) {
        if (!cancelled) {
          console.error(err);
          setPolicyPreview(null);
          setPolicyPreviewError(err?.message || "Politika önizlemesi yüklenemedi.");
        }
      } finally {
        if (!cancelled) setPolicyPreviewLoading(false);
      }
    };

    void loadPolicyPreview();
    return () => {
      cancelled = true;
    };
  }, [currentCustomerId, form.customer_id, form.location_id, groups]);

  const resetForm = () => {
    setForm({
      ...buildEmptyForm(currentCustomerId),
      location_id: currentLocationId,
    });
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (g: UserGroup) => {
    setForm({ customer_id: g.customer_id || currentCustomerId, location_id: g.location_id || currentLocationId, name: g.name, description: g.description || '', bandwidth_up: g.bandwidth_up, bandwidth_down: g.bandwidth_down, session_timeout: g.session_timeout, idle_timeout: g.idle_timeout, daily_quota: g.daily_quota, weekly_quota: g.weekly_quota, monthly_quota: g.monthly_quota, hourly_quota: g.hourly_quota, max_sessions: g.max_sessions, is_default: g.is_default, priority: g.priority, access_start: g.access_start, access_end: g.access_end });
    setEditingId(g.id);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) return;
    try {
      const payload = form.customer_id ? form : (() => {
        const { customer_id: _customerId, ...withoutCustomer } = form;
        return withoutCustomer;
      })();
      if (editingId) await updateUserGroup(editingId, payload);
      else await createUserGroup(payload);
      resetForm();
      await load();
    } catch (err) { console.error(err); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Bu kullanıcı grubunu silmek istediğinize emin misiniz?')) return;
    try {
      await deleteUserGroup(id);
      await load();
    } catch (err) { console.error(err); }
  };

  const formatMin = (v: number | null) => v ? v >= 1440 ? `${Math.floor(v / 1440)}g ${v % 1440}d` : v >= 60 ? `${Math.floor(v / 60)}s ${v % 60}d` : `${v} dk` : 'Sınırsız';
  const locationMap = new Map(locations.map((location: any) => [location.id, location.name]));
  const selectedLocationLabel = form.location_id ? locationMap.get(form.location_id) || "Lokasyon seçili" : "Müşteri geneli";

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Erişim Profilleri</h2>
          <p className="text-sm text-slate-500">Captive portal sonrası uygulanacak oturum süresi ve erişim pencerelerini tanımlayın.</p>
        </div>
        <button onClick={() => { resetForm(); setShowForm(true); }} className="px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 text-sm font-medium flex items-center gap-2">
          <Plus className="w-4 h-4" /> Yeni Grup
        </button>
      </div>

      <div className="grid gap-3 rounded-2xl border border-indigo-100 bg-indigo-50/70 p-4 dark:border-indigo-900/40 dark:bg-indigo-950/20 md:grid-cols-[1fr_auto_1fr_auto_1fr] md:items-center">
        <div className="flex items-start gap-3"><Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-indigo-600 dark:text-indigo-300" /><div><div className="text-xs font-semibold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">Bu ekranın amacı</div><p className="mt-1 text-xs leading-5 text-indigo-900/75 dark:text-indigo-100/75">Grup, portalda doğrulanan misafire uygulanacak süre ve eşzamanlı oturum profilidir. RADIUS sunucusu veya switch/NAC burada kurulmaz.</p></div></div>
        <ArrowRight className="hidden h-4 w-4 text-indigo-300 md:block" />
        <div><div className="text-xs font-semibold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">FortiGate bağlantısı</div><p className="mt-1 text-xs leading-5 text-indigo-900/75 dark:text-indigo-100/75">Cihazlar ekranında FortiGate API tokenını tanımlayın. Portal doğrulaması sonrası oturum bu cihaz üzerinden açılır.</p></div>
        <ArrowRight className="hidden h-4 w-4 text-indigo-300 md:block" />
        <div><div className="text-xs font-semibold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">VPN MFA</div><p className="mt-1 text-xs leading-5 text-indigo-900/75 dark:text-indigo-100/75">VPN kullanıcıları ve OTP için Auth Yöntemleri → VPN MFA ekranını kullanın. Bu grup profili VPN yetkisi vermez.</p></div>
      </div>

      {showForm && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">{editingId ? 'Captive portal profilini düzenle' : 'Yeni captive portal profili'}</h3>
            <button onClick={resetForm} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-3 rounded-xl border border-indigo-100 bg-indigo-50/70 px-4 py-3 text-xs leading-5 text-indigo-900 dark:border-indigo-900/40 dark:bg-indigo-950/20 dark:text-indigo-200">
              <strong>Bu profil ne yapar?</strong> FortiGate captive portal doğrulamasından sonra oturum süresi, eşzamanlı bağlantı ve isteğe bağlı zaman penceresini belirler. FortiGate ile eşleştirme için <span className="font-semibold">Auth Yöntemleri → VPN MFA</span> ekranını kullanın.
            </div>
            <div className="md:col-span-3">
              <label className="block text-sm font-medium mb-1">Grup Adı</label>
              <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="Örn: VIP Kullanıcılar" />
            </div>
            <div className="md:col-span-3">
              <label className="block text-sm font-medium mb-1">Açıklama</label>
              <input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="Grup açıklaması" />
            </div>
            <div className="hidden">
              <label className="block text-sm font-medium mb-1">Upload (Kbps)</label>
              <input type="number" value={form.bandwidth_up || ''} onChange={e => setForm({ ...form, bandwidth_up: e.target.value ? parseInt(e.target.value) : null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="0 = limitsiz" />
            </div>
            <div className="hidden">
              <label className="block text-sm font-medium mb-1">Download (Kbps)</label>
              <input type="number" value={form.bandwidth_down || ''} onChange={e => setForm({ ...form, bandwidth_down: e.target.value ? parseInt(e.target.value) : null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="0 = limitsiz" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Oturum Süresi (dk)</label>
              <input type="number" value={form.session_timeout || ''} onChange={e => setForm({ ...form, session_timeout: e.target.value ? parseInt(e.target.value) : null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Idle Timeout (dk)</label>
              <input type="number" value={form.idle_timeout || ''} onChange={e => setForm({ ...form, idle_timeout: e.target.value ? parseInt(e.target.value) : null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div className="hidden">
              <label className="block text-sm font-medium mb-1">Günlük Kota (MB)</label>
              <input type="number" value={form.daily_quota || ''} onChange={e => setForm({ ...form, daily_quota: e.target.value ? parseInt(e.target.value) : null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div className="hidden">
              <label className="block text-sm font-medium mb-1">Saatlik Kota (MB)</label>
              <input type="number" value={form.hourly_quota || ''} onChange={e => setForm({ ...form, hourly_quota: e.target.value ? parseInt(e.target.value) : null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Eşzamanlı Oturum</label>
              <input type="number" value={form.max_sessions} onChange={e => setForm({ ...form, max_sessions: parseInt(e.target.value) || 1 })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div className="hidden">
              <label className="block text-sm font-medium mb-1">Haftalık Kota (MB)</label>
              <input type="number" value={form.weekly_quota || ''} onChange={e => setForm({ ...form, weekly_quota: e.target.value ? parseInt(e.target.value) : null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div className="hidden">
              <label className="block text-sm font-medium mb-1">Aylık Kota (MB)</label>
              <input type="number" value={form.monthly_quota || ''} onChange={e => setForm({ ...form, monthly_quota: e.target.value ? parseInt(e.target.value) : null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Lokasyon</label>
              <select
                value={form.location_id || ''}
                onChange={e => setForm({ ...form, location_id: e.target.value || null })}
                className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm"
              >
                <option value="">Müşteri geneli</option>
                {locations.map((location: any) => (
                  <option key={location.id} value={location.id}>{location.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Erişim Başlangıç</label>
              <input type="datetime-local" value={form.access_start || ''} onChange={e => setForm({ ...form, access_start: e.target.value || null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Erişim Bitiş</label>
              <input type="datetime-local" value={form.access_end || ''} onChange={e => setForm({ ...form, access_end: e.target.value || null })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Öncelik</label>
              <input type="number" value={form.priority} onChange={e => setForm({ ...form, priority: parseInt(e.target.value) || 0 })} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" />
            </div>
            <div className="flex items-center space-x-2 pt-6">
              <input type="checkbox" checked={form.is_default} onChange={e => setForm({ ...form, is_default: e.target.checked })} className="rounded" id="default-group" />
              <label htmlFor="default-group" className="text-sm">Varsayılan grup</label>
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <button onClick={resetForm} className="px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-xl text-sm">İptal</button>
            <button onClick={handleSave} className="px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 text-sm flex items-center gap-2"><Save className="w-4 h-4" /> Kaydet</button>
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-xs uppercase tracking-wider text-slate-500">Policy Preview</div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50">Etkin Grup Politikası</h3>
          </div>
          <span className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2.5 py-1 rounded-full">
            {selectedLocationLabel}
          </span>
        </div>

        {policyPreviewLoading ? (
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-indigo-500 border-t-transparent" />
            Politika önizlemesi yükleniyor...
          </div>
        ) : policyPreviewError ? (
          <div className="rounded-xl border border-rose-200 dark:border-rose-900/40 bg-rose-50 dark:bg-rose-950/20 p-3 text-sm text-rose-800 dark:text-rose-300">
            {policyPreviewError}
          </div>
        ) : policyPreview ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-2">
              <div className="text-xs uppercase tracking-wider text-slate-500">Aktif Grup</div>
              <div className="text-lg font-semibold text-slate-900 dark:text-slate-50">
                {policyPreview.selected_group?.group_name || "Fallback"}
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-300">{policyPreview.message}</div>
              <div className="text-xs text-slate-500">
                {policyPreview.eligible_group_count} aday grup · {policyPreview.selected_group?.scope_label || "Kural yok"}
              </div>
            </div>
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-2">
              <div className="text-xs uppercase tracking-wider text-slate-500">Etkin Kural Özeti</div>
              {policyPreview.selected_group ? (
                <>
                  <div className="text-sm font-medium text-slate-800 dark:text-slate-200">
                    {policyPreview.selected_group.policy_summary}
                  </div>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {policyPreview.selected_group.enforcement_notes?.slice(0, 4).map((note: string) => (
                      <span
                        key={note}
                        className="inline-flex items-center rounded-full border border-indigo-100 dark:border-indigo-900/40 bg-indigo-50 dark:bg-indigo-950/30 px-2.5 py-1 text-xs text-indigo-700 dark:text-indigo-300"
                      >
                        {note}
                      </span>
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-sm text-slate-500">
                  Bu customer/location için aktif grup bulunmuyor; default captive davranışı uygulanır.
                </div>
              )}
            </div>
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-2">
              <div className="text-xs uppercase tracking-wider text-slate-500">Aday Gruplar</div>
              <div className="flex flex-wrap gap-2">
                {policyPreview.candidate_groups.length === 0 ? (
                  <span className="text-sm text-slate-500">Aday grup yok.</span>
                ) : (
                  policyPreview.candidate_groups.map((group: any) => (
                    <span
                      key={group.group_id}
                      className="inline-flex items-center rounded-full border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-1 text-xs text-slate-600 dark:text-slate-300"
                    >
                      {group.group_name}
                    </span>
                  ))
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="text-sm text-slate-500">Politika önizlemesi için müşteri kapsamı bekleniyor.</div>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4">
        {loading ? (
          <div className="text-center py-8 text-slate-500">Yükleniyor...</div>
        ) : groups.length === 0 ? (
          <div className="text-center py-8 text-slate-500">Henüz kullanıcı grubu oluşturulmamış.</div>
        ) : groups.map(g => (
          <div key={g.id} className={`bg-white dark:bg-slate-900 border rounded-2xl p-5 shadow-sm ${g.is_default ? 'border-indigo-300 dark:border-indigo-700' : 'border-slate-200 dark:border-slate-800'}`}>
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-semibold">{g.name}</h3>
                  {g.is_default && <span className="text-xs bg-indigo-100 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full">Varsayılan</span>}
                  <span className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-full">
                    {g.location_id ? locationMap.get(g.location_id) || "Lokasyon grubu" : "Müşteri geneli"}
                  </span>
                </div>
                {g.description && <p className="text-sm text-slate-500 mt-0.5">{g.description}</p>}
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => handleEdit(g)} className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl"><Edit2 className="w-4 h-4" /></button>
                <button onClick={() => handleDelete(g.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mt-4 sm:grid-cols-4">
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 text-center">
                <Clock className="w-4 h-4 text-amber-500 mx-auto mb-1" />
                <div className="text-xs text-slate-500">Azami oturum</div>
                <div className="text-sm font-semibold">{formatMin(g.session_timeout)}</div>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 text-center">
                <Clock className="w-4 h-4 text-rose-500 mx-auto mb-1" />
                <div className="text-xs text-slate-500">Boşta kapatma</div>
                <div className="text-sm font-semibold">{formatMin(g.idle_timeout)}</div>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 text-center">
                <Users className="w-4 h-4 text-violet-500 mx-auto mb-1" />
                <div className="text-xs text-slate-500">Eşzamanlı</div>
                <div className="text-sm font-semibold">{g.max_sessions}</div>
              </div>
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3 text-center">
                <Clock className="w-4 h-4 text-indigo-500 mx-auto mb-1" />
                <div className="text-xs text-slate-500">Erişim penceresi</div>
                <div className="text-sm font-semibold">{g.access_start ? "Planlı" : "Sürekli"}</div>
              </div>
            </div>
            <div className="flex gap-3 mt-2 text-xs text-slate-400">
              {g.access_start && <span>Erişim: {new Date(g.access_start).toLocaleDateString('tr-TR')} - {g.access_end ? new Date(g.access_end).toLocaleDateString('tr-TR') : 'sınırsız'}</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
