import React from "react";
import { DashboardPage } from "./pages/DashboardPage";
import { LocationsPage } from "./pages/LocationsPage";
import { DevicesPage } from "./pages/DevicesPage";
import { CaptivePortalPage } from "./pages/CaptivePortalPage";
import { TemplateEditorPage } from "./pages/TemplateEditorPage";
import { SessionsPage } from "./pages/SessionsPage";
import { LogsPage } from "./pages/LogsPage";
import { SyslogPage } from "./pages/SyslogPage";
import { ReportsPage } from "./pages/ReportsPage";
import { SystemSettingsPage } from "./pages/SystemSettingsPage";
import { SyslogTriggersPage } from "./pages/SyslogTriggersPage";
import { ReportSchedulerPage } from "./pages/ReportSchedulerPage";
import { AuthMethodsPage } from "./pages/AuthMethodsPage";
import { PmsConfigPage } from "./pages/PmsConfigPage";
import { SigningConfigPage } from "./pages/SigningConfigPage";
import { UserGroupsPage } from "./pages/UserGroupsPage";
import { UsersPage } from "./pages/UsersPage";
import { TrafficAnalysisPage } from "./pages/TrafficAnalysisPage";
import { AlarmDashboardPage } from "./pages/AlarmDashboardPage";
import { LogsSearch } from "./pages/LogsSearch";
import { ApprovalRequestsPage } from "./pages/ApprovalRequestsPage";
import { PlatformLicensePage } from "./pages/PlatformLicensePage";
import { PlatformUpgradePage } from "./pages/PlatformUpgradePage";

export interface RouteConfig {
  path: string;
  label: string;
  element: React.ReactNode;
}

export const routeConfig: RouteConfig[] = [
  { path: "/", label: "Genel Bakış", element: <DashboardPage /> },
  { path: "/locations", label: "Lokasyonlar", element: <LocationsPage /> },
  { path: "/devices", label: "Cihazlar", element: <DevicesPage /> },
  { path: "/portal-templates", label: "Captive Portal", element: <CaptivePortalPage /> },
  { path: "/auth-methods", label: "Auth Yöntemleri", element: <AuthMethodsPage /> },
  { path: "/pms-config", label: "Otel / PMS", element: <PmsConfigPage /> },
  { path: "/user-groups", label: "Erişim Profilleri", element: <UserGroupsPage /> },
  { path: "/users", label: "Kullanıcı Yönetimi", element: <UsersPage /> },
  { path: "/online-users", label: "Online Kullanıcılar", element: <UsersPage /> },
  { path: "/sessions", label: "Oturumlar", element: <SessionsPage /> },
  { path: "/approval-requests", label: "Onay İstekleri", element: <ApprovalRequestsPage /> },
  // The unified analyzer is the canonical firewall-log surface. It searches
  // parsed traffic/event/UTM records, facets and archived evidence together.
  { path: "/firewall-logs", label: "Firewall Analyzer", element: <LogsSearch /> },
  // Keep the legacy singular URL working as a first-class alias. Older
  // bookmarks and customer runbooks commonly use /firewall-log.
  { path: "/firewall-log", label: "Firewall Analyzer", element: <LogsSearch /> },
  { path: "/syslog-triggers", label: "Syslog Triggers", element: <SyslogTriggersPage /> },
  { path: "/alarm-dashboard", label: "Alarm Panosu", element: <AlarmDashboardPage /> },
  { path: "/archives", label: "5651 Logları", element: <LogsPage /> },
  { path: "/signing-config", label: "Signing Config", element: <SigningConfigPage /> },
  { path: "/traffic-analysis", label: "Trafik Analizi", element: <TrafficAnalysisPage /> },
  { path: "/reports", label: "Raporlar", element: <ReportsPage /> },
  { path: "/report-scheduler", label: "Report Scheduler", element: <ReportSchedulerPage /> },
  { path: "/logs/search", label: "Log Arama", element: <LogsSearch /> },
  { path: "/settings", label: "Ayarlar", element: <SystemSettingsPage /> },
  { path: "/platform-license", label: "Platform Lisansı", element: <PlatformLicensePage /> },
  { path: "/platform-upgrade", label: "Güncelleme Merkezi", element: <PlatformUpgradePage /> },
];

export const labelToPath: Record<string, string> = Object.fromEntries(
  routeConfig.map((r) => [r.label, r.path])
);

export const pathToLabel: Record<string, string> = Object.fromEntries(
  routeConfig.map((r) => [r.path, r.label])
);
