import React from "react";
import { TrendingUp, TrendingDown } from "lucide-react";

interface KpiCardProps {
  title: string;
  value: number | string;
  unit?: string;
  trend?: "up" | "down";
  trendValue?: number; // percentage
}

export const KpiCard: React.FC<KpiCardProps> = ({ title, value, unit = "", trend, trendValue }) => {
  const TrendIcon = trend === "up" ? TrendingUp : TrendingDown;
  const trendColor = trend === "up" ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400";
  const trendBg = trend === "up" ? "bg-emerald-50 dark:bg-emerald-950/30" : "bg-rose-50 dark:bg-rose-950/30";

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between transition-all duration-200 hover:shadow-md">
      <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">
        {title}
      </h3>
      <div className="flex items-baseline space-x-1">
        <span className="text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          {value}
        </span>
        {unit && (
          <span className="text-sm font-semibold text-slate-500 dark:text-slate-400">
            {unit}
          </span>
        )}
      </div>
      {trend && trendValue !== undefined && (
        <div className="flex items-center mt-4">
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${trendColor} ${trendBg}`}>
            <TrendIcon className="w-3 h-3 mr-1" />
            %{trendValue}
          </span>
          <span className="text-xs text-slate-400 dark:text-slate-500 ml-2">geçen haftaya göre</span>
        </div>
      )}
    </div>
  );
};
