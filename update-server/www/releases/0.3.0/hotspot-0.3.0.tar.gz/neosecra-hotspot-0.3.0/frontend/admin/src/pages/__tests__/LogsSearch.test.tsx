import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BrowserRouter } from 'react-router-dom';

vi.mock('../../api/logs', () => ({
  searchLogs: vi.fn(),
  getFacets: vi.fn(),
  correlateSession: vi.fn(),
  exportLogs: vi.fn(),
}));

vi.mock('../../lib/api', () => ({
  getCurrentScope: vi.fn(),
  getCurrentUser: vi.fn(),
}));

import { searchLogs, getFacets } from '../../api/logs';
import { getCurrentScope } from '../../lib/api';
import { LogsSearch } from '../LogsSearch';

const mockLogs = Array.from({ length: 5 }, (_, i) => ({
  id: `log-${i}`,
  timestamp: '2026-07-27T10:00:00Z',
  vendor: 'fortigate',
  log_type: 'traffic',
  severity: 'info',
  action: 'accept',
  src_ip: `10.0.0.${i + 1}`,
  dst_ip: '192.168.1.1',
  src_port: 40000 + i,
  dst_port: 443,
  user: i === 0 ? 'user@test.com' : null,
  hostname: 'fg-01',
  message: i % 2 === 0 ? 'Session opened' : 'Session closed',
  raw: `<14>date=2026-07-27 time=10:00:0${i} ...`,
  parsed: { policy_id: i + 100 },
  correlation_id: null,
  correlation_type: null,
  correlation_reason: null,
  correlation_group_size: null,
}));

const mockFacets = {
  vendor: [{ value: 'fortigate', count: 42 }],
  severity: [
    { value: 'info', count: 30 },
    { value: 'warning', count: 10 },
    { value: 'critical', count: 2 },
  ],
  log_type: [
    { value: 'traffic', count: 35 },
    { value: 'event', count: 5 },
    { value: 'utm', count: 2 },
  ],
  action: [
    { value: 'accept', count: 25 },
    { value: 'deny', count: 15 },
    { value: 'client-rst', count: 2 },
  ],
};

function renderPage() {
  return render(
    <BrowserRouter>
      <LogsSearch />
    </BrowserRouter>,
  );
}

describe('LogsSearch', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (getCurrentScope as any).mockResolvedValue({ tenant_id: 'tenant-1', role: 'admin' });
    (searchLogs as any).mockResolvedValue({
      items: mockLogs,
      total: 42,
      page: 1,
      page_size: 50,
      has_next: true,
    });
    (getFacets as any).mockResolvedValue(mockFacets);
  });

  it('renders page title and tenant indicator', async () => {
    renderPage();
    expect(screen.getByText(/Log Arama/)).toBeInTheDocument();
    expect(await screen.findByText(/Tenant:/)).toBeInTheDocument();
  });

  it('loads and displays logs on mount', async () => {
    renderPage();
    expect((await screen.findAllByText('Session opened')).length).toBeGreaterThan(0);
    expect(screen.getAllByText('Session closed').length).toBeGreaterThan(0);
    expect(searchLogs).toHaveBeenCalledTimes(1);
    expect(getFacets).toHaveBeenCalledTimes(1);
  });

  it('shows empty state when no logs match', async () => {
    (searchLogs as any).mockResolvedValue({
      items: [], total: 0, page: 1, page_size: 50, has_next: false,
    });
    renderPage();
    expect(await screen.findByText('Son 24 saatte eşleşme yok')).toBeInTheDocument();
  });

  it('renders facet data in the right panel', async () => {
    renderPage();
    // Values also appear in table rows — assert presence, not uniqueness.
    expect((await screen.findAllByText('fortigate')).length).toBeGreaterThan(0);
    expect(screen.getAllByText('info').length).toBeGreaterThan(0);
    expect(screen.getAllByText('traffic').length).toBeGreaterThan(0);
  });

  it('calls searchLogs when Ara button is clicked', async () => {
    renderPage();
    await screen.findAllByText('Session opened');

    const searchBtn = screen.getByText('Ara');
    const user = userEvent.setup();
    await user.click(searchBtn);

    expect(searchLogs).toHaveBeenCalledTimes(2);
  });

  it('shows error alert and retry button on failure', async () => {
    (searchLogs as any).mockRejectedValue(new Error('API hatası'));
    renderPage();
    expect(await screen.findByText('API hatası')).toBeInTheDocument();
    expect(screen.getByText('Tekrar Dene')).toBeInTheDocument();
  });

  it('displays user column correctly', async () => {
    renderPage();
    expect(await screen.findByText('user@test.com')).toBeInTheDocument();
  });
});
