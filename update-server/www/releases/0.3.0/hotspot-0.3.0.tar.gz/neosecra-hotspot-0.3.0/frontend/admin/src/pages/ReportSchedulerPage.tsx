import React, { useState, useEffect } from "react";
import { getReportJobs, createReportJob, updateReportJob, deleteReportJob, runReportNow, getReportArchives, downloadArchive, getReportTemplates } from "../lib/api";
import { Plus, Edit3, Trash2, Play, Download, Calendar, Clock, FileText, RefreshCw, Search, BarChart3, Sparkles } from "lucide-react";

const BUILT_IN_REPORTS = [
  { id: "vpn_activity_30d", name: "Son 30 Gün VPN Aktivite Raporu", description: "SSL-VPN / IPsec tünel açma-kapama ve kullanıcı özeti.", category: "Hazır Analyzer Raporları" },
  { id: "top_bandwidth_users_30d", name: "Son 30 Gün En Çok Bandwidth Tüketen Kullanıcılar", description: "FortiGate trafik kayıtlarından kullanıcı/IP bazlı trafik sıralaması.", category: "Hazır Analyzer Raporları" },
  { id: "firewall_security_30d", name: "Son 30 Gün Firewall Güvenlik Özeti", description: "İzin, engelleme, UTM ve kritik olayların Analyzer özeti.", category: "Hazır Analyzer Raporları" },
  { id: "captive_portal_usage_30d", name: "Son 30 Gün Captive Portal Kullanım Raporu", description: "Oturum, doğrulama yöntemi, lokasyon ve veri tüketimi özeti.", category: "Hazır Analyzer Raporları" },
  { id: "5651_evidence", name: "5651 Mahkeme Delil Paketi", description: "İmzalı hash zincirli, denetime hazır yasal delil paketi.", category: "5651 / Operasyon Raporları" },
  { id: "ip_identity_matrix", name: "IP ↔ Kimlik Korelasyon Matrisi", description: "IP, MAC, telefon ve doğrulama kayıtlarını eşleştirir.", category: "5651 / Operasyon Raporları" },
  { id: "venue_density", name: "Lokasyon & Mekan Yoğunluk", description: "Şube bazlı oturum yoğunluğu ve veri tüketimi.", category: "5651 / Operasyon Raporları" },
  { id: "operator_audit", name: "BTK / Operatör Denetim Raporu", description: "Yönetici işlemleri ve uyum denetim izi.", category: "5651 / Operasyon Raporları" },
  { id: "quota_license_usage", name: "Kota & Lisans Kullanım Raporu", description: "Aktif oturum ve bandwidth kota kullanımı.", category: "5651 / Operasyon Raporları" },
];

export const ReportSchedulerPage: React.FC = () => {
  const [jobs, setJobs] = useState<any[]>([]);
  const [archives, setArchives] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"jobs" | "archives" | "templates">("jobs");
  const [showModal, setShowModal] = useState(false);
  const [editingJob, setEditingJob] = useState<any>(null);
  const [searchTemplate, setSearchTemplate] = useState("");
  const [form, setForm] = useState({ name: "", template_id: "firewall_security_30d", report_type: "daily", format: "pdf", trigger: "0 6 * * *", recipients: "" });

  const loadData = async () => {
    setLoading(true);
    // Render the operator presets immediately; a missing optional templates
    // endpoint must not make the scheduler appear empty.
    setTemplates(BUILT_IN_REPORTS);
    try {
      const [j, a, t] = await Promise.all([getReportJobs(), getReportArchives(), getReportTemplates()]);
      setJobs(j);
      setArchives(a);
      const serverTemplates = Array.isArray(t) ? t : [];
      const merged = [...BUILT_IN_REPORTS, ...serverTemplates.filter((x: any) => !BUILT_IN_REPORTS.some((b) => b.id === x.id))];
      setTemplates(merged.map((x: any) => ({ ...x, category: x.category || (x.source === "syslog" ? "Syslog Analiz" : "Oturum Analiz") })));
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, []);

  const openCreate = () => {
    setEditingJob(null);
    setForm({ name: "", template_id: "firewall_security_30d", report_type: "daily", format: "pdf", trigger: "0 6 * * *", recipients: "" });
    setShowModal(true);
  };

  const openEdit = (j: any) => {
    setEditingJob(j);
    setForm({ name: j.name, template_id: j.template_id || "", report_type: j.report_type || "daily", format: j.format, trigger: j.trigger || j.cron_expression || "0 6 * * *", recipients: j.recipients?.join(", ") || "" });
    setShowModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { ...form, recipients: form.recipients.split(",").map((r: string) => r.trim()).filter(Boolean) };
    try {
      if (editingJob) {
        const updated = await updateReportJob(editingJob.id, payload);
        setJobs(jobs.map(j => j.id === editingJob.id ? updated : j));
      } else {
        const created = await createReportJob(payload);
        setJobs([created, ...jobs]);
      }
      setShowModal(false);
    } catch (err) { console.error(err); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Bu rapor işini silmek istediğinize emin misiniz?")) return;
    try { await deleteReportJob(id); setJobs(jobs.filter(j => j.id !== id)); }
    catch (err) { console.error(err); }
  };

  const handleRunNow = async (id: string) => {
    try {
      await runReportNow(id);
      const [j, a] = await Promise.all([getReportJobs(), getReportArchives()]);
      setJobs(j); setArchives(a);
    } catch (err) { console.error(err); }
  };

  const filteredTemplates = templates.filter(t =>
    String(t.name || "").toLowerCase().includes(searchTemplate.toLowerCase()) ||
    String(t.category || "").toLowerCase().includes(searchTemplate.toLowerCase())
  );

  const categories = [...new Set(templates.map(t => t.category))];

  const scheduleTemplate = (template: any) => {
    setEditingJob(null);
    setForm({
      name: template.name,
      template_id: template.id,
      report_type: "daily",
      format: "pdf",
      trigger: "0 6 * * *",
      recipients: "",
    });
    setActiveTab("jobs");
    setShowModal(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Rapor Zamanlayıcı</h2>
          <p className="text-sm text-slate-500">Periyodik raporlar oluşturun, zamanlayın ve arşivlenmiş raporları indirin.</p>
        </div>
        <div className="flex items-center space-x-3">
          <button onClick={loadData} className="inline-flex items-center px-3 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
            <RefreshCw className="w-4 h-4 mr-1.5" /> Yenile
          </button>
          {activeTab === "jobs" && (
            <button onClick={openCreate} className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors">
              <Plus className="w-4 h-4 mr-2" /> Yeni Rapor İşi
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        {(["jobs", "archives", "templates"] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`inline-flex items-center px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeTab === tab ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 shadow-sm" : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"}`}>
            {tab === "jobs" ? <Calendar className="w-4 h-4 mr-2" /> : tab === "archives" ? <FileText className="w-4 h-4 mr-2" /> : <Search className="w-4 h-4 mr-2" />}
            {tab === "jobs" ? "Rapor İşleri" : tab === "archives" ? "Arşiv" : "Şablonlar"}
          </button>
        ))}
      </div>

      {activeTab === "jobs" && (
        <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
          {loading ? (
            <div className="flex justify-center items-center py-12 space-x-2">
              <RefreshCw className="w-6 h-6 text-indigo-500 animate-spin" />
              <span className="text-sm font-medium text-slate-500">Yükleniyor...</span>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">İş Adı</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Periyot</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Format</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Cron</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Alıcılar</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Sonraki Çalışma</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Durum</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {jobs.map((j) => (
                    <tr key={j.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-slate-900 dark:text-slate-100"><div>{j.name}</div><div className="text-[11px] text-slate-400 mt-0.5">{templates.find((t) => t.id === j.template_id)?.name || "Oturum özeti"}</div></td>
                      <td className="px-6 py-4 text-sm">{j.report_type === "daily" ? "Günlük" : j.report_type === "weekly" ? "Haftalık" : j.report_type === "monthly" ? "Aylık" : "Özel"}</td>
                      <td className="px-6 py-4 text-sm font-mono uppercase text-xs">{j.format}</td>
                      <td className="px-6 py-4 text-sm font-mono text-xs text-slate-500">{j.trigger || j.cron_expression}</td>
                      <td className="px-6 py-4 text-sm text-slate-500 max-w-[150px] truncate">{j.recipients?.join(", ")}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">
                        <span className="inline-flex items-center"><Clock className="w-3 h-3 mr-1" />{(j.next_run_at || j.next_run) ? new Date(j.next_run_at || j.next_run).toLocaleString("tr-TR", { dateStyle: "short", timeStyle: "short" }) : "—"}</span>
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${j.is_active ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30" : "bg-slate-100 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700"}`}>
                          {j.is_active ? "Aktif" : "Pasif"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right space-x-1">
                        <button onClick={() => handleRunNow(j.id)} className="inline-flex items-center p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 rounded-xl transition-colors" title="Şimdi Çalıştır">
                          <Play className="w-4 h-4" />
                        </button>
                        <button onClick={() => openEdit(j)} className="inline-flex items-center p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl transition-colors">
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(j.id)} className="inline-flex items-center p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {jobs.length === 0 && <tr><td colSpan={8} className="px-6 py-12 text-center text-slate-500">Henüz rapor işi tanımlanmamış.</td></tr>}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === "archives" && (
        <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Rapor</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Tarih</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Format</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Boyut</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">İndir</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {archives.map((a) => (
                  <tr key={a.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-slate-900 dark:text-slate-100">{a.job_name || jobs.find((j) => j.id === a.job_id)?.name || "Rapor çıktısı"}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{new Date(a.generated_at || a.date || a.created_at).toLocaleDateString("tr-TR")}</td>
                    <td className="px-6 py-4 text-sm font-mono uppercase text-xs">{a.format}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{a.file_size_kb ?? Math.max(1, Math.round((a.file_size || 0) / 1024))} KB</td>
                    <td className="px-6 py-4 text-right">
                      <button onClick={() => downloadArchive(a.id)} className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl transition-colors">
                        <Download className="w-3.5 h-3.5 mr-1" /> İndir
                      </button>
                    </td>
                  </tr>
                ))}
                {archives.length === 0 && <tr><td colSpan={5} className="px-6 py-12 text-center text-slate-500">Henüz arşivlenmiş rapor yok.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === "templates" && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-3 text-slate-400 w-4 h-4" />
            <input type="text" value={searchTemplate} onChange={(e) => setSearchTemplate(e.target.value)} placeholder="Şablon ara..."
              className="w-full pl-11 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm" />
          </div>
          <div className="space-y-6">
            {categories.map(cat => {
              const items = filteredTemplates.filter(t => t.category === cat);
              if (items.length === 0) return null;
              return (
                <div key={cat}>
                  <h4 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">{cat}</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {items.map(t => (
                      <div key={t.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow flex flex-col">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-2"><div className="mt-0.5 p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600"><BarChart3 className="w-4 h-4" /></div><h5 className="font-semibold text-slate-900 dark:text-slate-100 text-sm leading-5">{t.name}</h5></div>
                          {t.scheduleable && <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />}
                        </div>
                        <p className="text-xs text-slate-500 mt-2 flex-1">{t.description || "Çok boyutlu analiz şablonu."}</p>
                        <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-500">{t.category}</span>
                          {t.scheduleable && <button type="button" onClick={() => scheduleTemplate(t)} className="text-xs font-semibold text-indigo-600 hover:text-indigo-700">Zamanla →</button>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">{editingJob ? "Rapor İşi Düzenle" : "Yeni Rapor İşi"}</h3>
            <form onSubmit={handleSave} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">İş Adı</label>
                <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Rapor</label>
                <select value={form.template_id} onChange={(e) => {
                  const selected = templates.find((t) => t.id === e.target.value);
                  setForm({ ...form, template_id: e.target.value, name: form.name || selected?.name || "" });
                }} className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="">Oturum ve syslog özeti (eski)</option>
                  {BUILT_IN_REPORTS.map((report) => <option key={report.id} value={report.id}>{report.name}</option>)}
                </select>
                <p className="text-[10px] text-slate-400">Reports ekranındaki hazır Analyzer raporlarından birini seçin.</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Periyot</label>
                  <select value={form.report_type} onChange={(e) => setForm({ ...form, report_type: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="daily">Günlük</option>
                    <option value="weekly">Haftalık</option>
                    <option value="monthly">Aylık</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Format</label>
                  <select value={form.format} onChange={(e) => setForm({ ...form, format: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="pdf">PDF</option>
                    <option value="csv">CSV</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Çalışma Zamanı (Cron)</label>
                <input type="text" required value={form.trigger} onChange={(e) => setForm({ ...form, trigger: e.target.value })}
                  placeholder="0 6 * * *"
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                <p className="text-[10px] text-slate-400">dakika saat gün ay hafta_günü (örn: 0 6 * * * = her gün 06:00)</p>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Alıcı E-Postaları (virgülle ayırın)</label>
                <input type="text" required value={form.recipients} onChange={(e) => setForm({ ...form, recipients: e.target.value })}
                  placeholder="örn: rapor@hotspot.local, admin@hotspot.local"
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="flex justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800">İptal</button>
                <button type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold">{editingJob ? "Güncelle" : "Oluştur"}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
