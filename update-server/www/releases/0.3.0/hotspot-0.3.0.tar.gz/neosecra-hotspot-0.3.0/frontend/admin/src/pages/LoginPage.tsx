import React, { useState } from "react";
import { login } from "../lib/api";
import { ShieldAlert, RefreshCw, KeyRound, Mail } from "lucide-react";

interface Props {
  onLoginSuccess: (user: any) => void;
}

export const LoginPage: React.FC<Props> = ({ onLoginSuccess }) => {
  const isDemoMode = String(import.meta.env.VITE_DEMO_MODE || "").toLowerCase() === "true";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setLoading(true);
    setErrorMsg(null);

    try {
      const user = await login(email, password);
      onLoginSuccess(user);
    } catch (err: any) {
      setErrorMsg(err.message || "Giriş başarısız oldu. Lütfen bilgilerinizi kontrol edin.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 p-6 relative overflow-hidden">
      {/* Decorative background grids/blur blobs */}
      <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-indigo-500/10 dark:bg-indigo-500/5 blur-3xl" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-violet-500/10 dark:bg-violet-500/5 blur-3xl" />

      <div className="max-w-md w-full space-y-6 z-10 animate-fade-in">
        {/* Brand header */}
        <div className="text-center space-y-3">
          <div className="inline-flex bg-gradient-to-tr from-indigo-500 to-violet-600 text-white p-3 rounded-2xl shadow-lg justify-center items-center">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 dark:text-slate-50">
            Hotspot Platformu
          </h2>
          <p className="text-sm font-medium text-slate-500">
            Yönetim ve 5651 Loglama Kontrol Paneli
          </p>
        </div>

        {/* Login form Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            {errorMsg && (
              <div className="p-3.5 bg-rose-50 dark:bg-rose-950/20 text-rose-800 dark:text-rose-400 border border-rose-100 dark:border-rose-900/30 rounded-xl text-xs font-semibold flex items-start space-x-2 animate-shake">
                <ShieldAlert className="w-4.5 h-4.5 flex-shrink-0 text-rose-600 dark:text-rose-400 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 block">E-Posta Adresi</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@hotspot.com"
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 block">Şifre</label>
                <div className="relative">
                  <KeyRound className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex justify-center items-center px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors disabled:opacity-50"
            >
              {loading && <RefreshCw className="w-4 h-4 mr-2 animate-spin" />}
              {loading ? "Giriş Yapılıyor..." : "Giriş Yap"}
            </button>
          </form>
        </div>

        {/* Footer info */}
        <div className="text-center text-xs text-slate-400">
          {isDemoMode && <p>Demo modu aktif: giriş akışı demo verisiyle çalışıyor.</p>}
          <p className="mt-1 font-mono">v0.1.0 · Secured by Enterprise Cryptography</p>
        </div>
      </div>
    </div>
  );
};
