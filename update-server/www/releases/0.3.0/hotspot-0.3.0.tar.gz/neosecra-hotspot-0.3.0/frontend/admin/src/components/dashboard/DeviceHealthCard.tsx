import React from "react";
import { StatusBadge } from "../ui/StatusBadge";
import { DeviceHealth } from "../../types/dashboard";

interface Props {
  devices: DeviceHealth[];
}

export const DeviceHealthCard: React.FC<Props> = ({ devices }) => {
  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col">
      <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">
        Cihaz Sağlığı
      </h3>
      <div className="space-y-4 flex-1">
        {devices.length === 0 ? (
          <div className="flex h-full min-h-[120px] items-center justify-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-sm text-slate-400">
            Cihaz verisi yok
          </div>
        ) : devices.map((device) => (
          <div key={device.id} className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-medium text-slate-800 dark:text-slate-200 text-sm">
                {device.name}
              </span>
              <StatusBadge status={device.status} />
            </div>
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="space-y-1">
                <div className="flex justify-between text-slate-500">
                  <span>CPU</span>
                  <span>{device.cpuUsage}%</span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-indigo-600 h-1.5 rounded-full" 
                    style={{ width: `${device.cpuUsage}%` }}
                  />
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-slate-500">
                  <span>RAM</span>
                  <span>{device.memoryUsage}%</span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-violet-600 h-1.5 rounded-full" 
                    style={{ width: `${device.memoryUsage}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
