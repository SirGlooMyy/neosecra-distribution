import { Sun, Moon } from 'lucide-react'
import { useTheme } from '../../theme/ThemeProvider'

export const ThemeToggle = () => {
  const { theme, toggle } = useTheme()

  return (
    <button
      onClick={toggle}
      className="rounded-ds-sm p-2 text-secondary transition-colors hover:bg-surface-hover hover:text-primary"
      aria-label="Tema Değiştir"
    >
      {theme === 'light' ? (
        <Moon className="h-5 w-5" />
      ) : (
        <Sun className="h-5 w-5 text-yellow-400" />
      )}
    </button>
  )
}
