import React, { useState, useEffect, useRef } from "react";
import { exportFirewallLogs, getFirewallLogs, getSearchViews, createSearchView, deleteSearchView, type SearchView } from "../lib/api";
import { Search, ChevronDown, ChevronUp, RefreshCw, Filter, Download } from "lucide-react";

interface FirewallLog {
  id: string;
  timestamp: string;
  vendor: string;
  severity: string;
  hostname: string;
  message: string;
  source_ip: string;
  raw: string;
  source?: string | null;
  correlation_id?: string | null;
  correlation_type?: string | null;
  correlation_reason?: string | null;
  correlation_group_size?: number | null;
}

interface CorrelationGroup {
  correlation_id: string;
  correlation_type: string;
  reason: string;
  count: number;
  sourceCount: number;
  sources: string[];
  firstTimestamp: string;
  lastTimestamp: string;
  sampleHostname: string;
  sampleSourceIp: string;
  sampleMessage: string;
}

const VENDORS = ["", "Fortinet", "PaloAlto", "Sophos", "SonicWall", "WatchGuard", "Zyxel", "MikroTik", "DrayTek", "pfSense", "TP-Link", "Aruba", "Ruijie"];
const SEVERITIES = ["", "emergency", "alert", "critical", "error", "warning", "notice", "info", "debug"];

const severityColor: Record<string, string> = {
  emergency: "text-rose-600 bg-rose-50 dark:bg-rose-950/30 border-rose-100 dark:border-rose-900/30",
  alert: "text-rose-600 bg-rose-50 dark:bg-rose-950/30 border-rose-100 dark:border-rose-900/30",
  critical: "text-rose-600 bg-rose-50 dark:bg-rose-950/30 border-rose-100 dark:border-rose-900/30",
  error: "text-red-600 bg-red-50 dark:bg-red-950/30 border-red-100 dark:border-red-900/30",
  warning: "text-amber-600 bg-amber-50 dark:bg-amber-950/30 border-amber-100 dark:border-amber-900/30",
  notice: "text-blue-600 bg-blue-50 dark:bg-blue-950/30 border-blue-100 dark:border-blue-900/30",
  info: "text-slate-600 bg-slate-50 dark:bg-slate-950/30 border-slate-100 dark:border-slate-900/30",
  debug: "text-slate-400 bg-slate-50 dark:bg-slate-950/30 border-slate-100 dark:border-slate-900/30",
};

function buildCorrelationGroups(logs: FirewallLog[]): CorrelationGroup[] {
  const groups = new Map<string, CorrelationGroup>();
  for (const log of logs) {
    if (!log.correlation_id) continue;
    const current = groups.get(log.correlation_id);
    if (!current) {
      groups.set(log.correlation_id, {
        correlation_id: log.correlation_id,
        correlation_type: log.correlation_type || "unknown",
        reason: log.correlation_reason || "Korelasyon grubu",
        count: log.correlation_group_size || 1,
        sourceCount: 1,
        sources: [log.source || "clickhouse"],
        firstTimestamp: log.timestamp,
        lastTimestamp: log.timestamp,
        sampleHostname: log.hostname || "—",
        sampleSourceIp: log.source_ip || "—",
        sampleMessage: log.message || "—",
      });
      continue;
    }

    current.count = Math.max(current.count, log.correlation_group_size || current.count);
    const nextSource = log.source || "clickhouse";
    if (!current.sources.includes(nextSource)) {
      current.sources.push(nextSource);
      current.sourceCount = current.sources.length;
    }
    if (log.timestamp < current.firstTimestamp) current.firstTimestamp = log.timestamp;
    if (log.timestamp > current.lastTimestamp) current.lastTimestamp = log.timestamp;
    if (current.sampleHostname === "—" && log.hostname) current.sampleHostname = log.hostname;
    if (current.sampleSourceIp === "—" && log.source_ip) current.sampleSourceIp = log.source_ip;
    if (current.sampleMessage === "—" && log.message) current.sampleMessage = log.message;
  }

  return Array.from(groups.values()).sort((a, b) => b.count - a.count || b.lastTimestamp.localeCompare(a.lastTimestamp));
}

export const FirewallLogsPage: React.FC = () => {
  const [logs, setLogs] = useState<FirewallLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [vendor, setVendor] = useState("");
  const [severity, setSeverity] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [correlationWindowMinutes, setCorrelationWindowMinutes] = useState(15);
  const [page, setPage] = useState(1);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [savedViews, setSavedViews] = useState<SearchView[]>([]);
  const [viewName, setViewName] = useState("");
  const [savingView, setSavingView] = useState(false);
  const [savedViewError, setSavedViewError] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const data = await getFirewallLogs({
        vendor,
        severity,
        search,
        from: fromDate,
        to: toDate,
        correlation_window_minutes: correlationWindowMinutes,
        page,
        page_size: 15,
      });
      setLogs(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadLogsDirect = async (
    v: string,
    s: string,
    q: string,
    from = fromDate,
    to = toDate,
    windowMinutes = correlationWindowMinutes,
  ) => {
    setLoading(true);
    try {
      const data = await getFirewallLogs({
        vendor: v,
        severity: s,
        search: q,
        from,
        to,
        correlation_window_minutes: windowMinutes,
        page: 1,
        page_size: 15,
      });
      setLogs(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [page]);

  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(() => {
        loadLogs();
      }, 10000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [autoRefresh]);

  const loadSavedViews = async () => {
    try {
      const views = await getSearchViews("firewall_logs");
      setSavedViews(views || []);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadSavedViews();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    loadLogs();
  };

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const buildViewFilters = () => ({
    vendor,
    severity,
    search,
    from: fromDate,
    to: toDate,
    correlation_window_minutes: correlationWindowMinutes,
    page_size: 15,
  });

  const handleSaveView = async () => {
    if (!viewName.trim()) {
      setSavedViewError("Görünüm adı gerekli.");
      return;
    }
    setSavingView(true);
    setSavedViewError(null);
    try {
      const saved = await createSearchView({
        surface: "firewall_logs",
        title: viewName.trim(),
        description: `${vendor || "Tüm vendorlar"} / ${severity || "Tüm severity"}`,
        filters: buildViewFilters(),
        is_shared: false,
      });
      setSavedViews((prev) => [saved, ...prev.filter((view) => view.id !== saved.id)]);
      setViewName("");
    } catch (err) {
      console.error(err);
      setSavedViewError("Görünüm kaydedilemedi.");
    } finally {
      setSavingView(false);
    }
  };

  const handleExport = async () => {
    setExporting(true);
    setExportError(null);
    try {
      const { blob, filename } = await exportFirewallLogs({
        vendor,
        severity,
        search,
        from: fromDate,
        to: toDate,
        correlation_window_minutes: correlationWindowMinutes,
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
    } catch (err) {
      console.error(err);
      setExportError("Dışa aktarma başarısız.");
    } finally {
      setExporting(false);
    }
  };

  const handleApplyView = (view: SearchView) => {
    const filters = view.filters || {};
    const nextVendor = String(filters.vendor || "");
    const nextSeverity = String(filters.severity || "");
    const nextSearch = String(filters.search || "");
    const nextFrom = String(filters.from || "");
    const nextTo = String(filters.to || "");
    const nextWindowRaw = Number(filters.correlation_window_minutes || 15);
    const nextWindow = Number.isFinite(nextWindowRaw) && nextWindowRaw > 0 ? nextWindowRaw : 15;
    setVendor(nextVendor);
    setSeverity(nextSeverity);
    setSearch(nextSearch);
    setFromDate(nextFrom);
    setToDate(nextTo);
    setCorrelationWindowMinutes(nextWindow);
    setPage(1);
    loadLogsDirect(nextVendor, nextSeverity, nextSearch, nextFrom, nextTo, nextWindow);
  };

  const handleDeleteView = async (viewId: string) => {
    try {
      await deleteSearchView(viewId);
      setSavedViews((prev) => prev.filter((view) => view.id !== viewId));
    } catch (err) {
      console.error(err);
    }
  };

  const correlationGroups = buildCorrelationGroups(logs);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Firewall Logları</h2>
          <p className="text-sm text-slate-500">
            Ağ geçidi firewall cihazlarından gelen syslog kayıtlarını görüntüleyin ve filtreleyin.
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <label className="flex items-center gap-2 text-sm text-slate-500">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500"
            />
            Otomatik Yenile (10sn)
          </label>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`inline-flex items-center px-3 py-2 border rounded-xl text-sm font-semibold transition-colors ${
              showFilters ? "bg-indigo-50 dark:bg-indigo-950/30 border-indigo-200 dark:border-indigo-800 text-indigo-600" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
            }`}
          >
            <Filter className="w-4 h-4 mr-1.5" />
            Filtrele
          </button>
          <button
            onClick={loadLogs}
            className="inline-flex items-center px-3 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 mr-1.5 ${loading ? 'animate-spin' : ''}`} />
            Yenile
          </button>
          <button
            onClick={handleExport}
            disabled={exporting}
            className="inline-flex items-center px-3 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors disabled:opacity-60"
          >
            <Download className={`w-4 h-4 mr-1.5 ${exporting ? "animate-pulse" : ""}`} />
            {exporting ? "Dışa Aktarılıyor..." : "Dışa Aktar"}
          </button>
        </div>
      </div>

      {showFilters && (
        <form onSubmit={handleSearch} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Üretici (Vendor)</label>
              <select value={vendor} onChange={(e) => setVendor(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="">Tümü</option>
                {VENDORS.filter(Boolean).map(v => <option key={v} value={v}>{v}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Severity</label>
              <select value={severity} onChange={(e) => setSeverity(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="">Tümü</option>
                {SEVERITIES.filter(Boolean).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Başlangıç Tarihi</label>
              <input type="datetime-local" value={fromDate} onChange={(e) => setFromDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Bitiş Tarihi</label>
              <input type="datetime-local" value={toDate} onChange={(e) => setToDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Korelasyon Penceresi (dk)</label>
              <input
                type="number"
                min={1}
                max={120}
                value={correlationWindowMinutes}
                onChange={(e) => setCorrelationWindowMinutes(Number(e.target.value) || 15)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button type="submit" className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold">
              <Search className="w-4 h-4 mr-1.5" /> Filtre Uygula
            </button>
          </div>
        </form>
      )}

      {/* Quick Filters Row */}
      <div className="flex flex-wrap gap-2 items-center bg-slate-50 dark:bg-slate-900/30 p-3 rounded-2xl border border-slate-100 dark:border-slate-800/50">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-2">Hızlı Filtreler:</span>
        <button
          type="button"
          onClick={() => { setVendor(""); setSeverity(""); setSearch(""); setPage(1); loadLogsDirect("", "", ""); }}
          className="px-3 py-1.5 text-xs font-semibold bg-slate-200/75 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl transition-all"
        >
          Tüm Kayıtlar
        </button>
        <button
          type="button"
          onClick={() => { setVendor("Fortinet"); setSeverity("notice"); setSearch("tunnel"); setPage(1); loadLogsDirect("Fortinet", "notice", "tunnel"); }}
          className="px-3 py-1.5 text-xs font-semibold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 rounded-xl transition-all border border-indigo-100 dark:border-indigo-900/30"
        >
          🔑 VPN Oturumları
        </button>
        <button
          type="button"
          onClick={() => { setVendor("Fortinet"); setSeverity("warning"); setSearch("admin login"); setPage(1); loadLogsDirect("Fortinet", "warning", "admin login"); }}
          className="px-3 py-1.5 text-xs font-semibold bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/40 text-amber-700 dark:text-amber-300 rounded-xl transition-all border border-amber-100 dark:border-amber-900/30"
        >
          🛡️ Fortinet Admin Girişleri
        </button>
        <button
          type="button"
          onClick={() => { setVendor(""); setSeverity("warning"); setSearch("failed"); setPage(1); loadLogsDirect("", "warning", "failed"); }}
          className="px-3 py-1.5 text-xs font-semibold bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/40 text-rose-700 dark:text-rose-300 rounded-xl transition-all border border-rose-100 dark:border-rose-900/30"
          >
          ❌ Başarısız Girişler
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row md:items-end gap-3">
          <div className="flex-1 space-y-1">
            <label className="text-xs font-semibold text-slate-500">Kayıtlı Görünüm Adı</label>
            <input
              type="text"
              value={viewName}
              onChange={(e) => setViewName(e.target.value)}
              placeholder="VPN uyarıları, başarısız girişler..."
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <button
            type="button"
            onClick={handleSaveView}
            disabled={savingView}
            className="inline-flex items-center justify-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white rounded-xl text-sm font-semibold transition-colors"
          >
            {savingView ? "Kaydediliyor..." : "Görünümü Kaydet"}
          </button>
          <button
            type="button"
            onClick={loadSavedViews}
            className="inline-flex items-center justify-center px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            Yenile
          </button>
        </div>
        {savedViewError && (
          <div className="text-sm text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-xl px-3 py-2">
            {savedViewError}
          </div>
        )}
        {exportError && (
          <div className="text-sm text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-xl px-3 py-2">
            {exportError}
          </div>
        )}
        <div className="flex flex-wrap gap-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider self-center mr-1">Kaydedilenler:</span>
          {savedViews.length === 0 ? (
            <span className="text-xs text-slate-500">Henüz görünüm kaydedilmedi.</span>
          ) : savedViews.map((view) => (
            <div key={view.id} className="inline-flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 rounded-full px-3 py-1">
              <button
                type="button"
                onClick={() => handleApplyView(view)}
                className="text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-400"
              >
                {view.title}
              </button>
              <button
                type="button"
                onClick={() => handleDeleteView(view.id)}
                className="text-xs text-slate-400 hover:text-rose-500"
                title="Görünümü sil"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      </div>

      {correlationGroups.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {correlationGroups.slice(0, 3).map((group) => (
            <div key={group.correlation_id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">{group.correlation_type}</div>
                  <div className="mt-1 text-sm font-bold text-slate-900 dark:text-slate-100">{group.reason}</div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="inline-flex items-center rounded-full bg-indigo-50 dark:bg-indigo-950/30 px-2.5 py-1 text-xs font-semibold text-indigo-700 dark:text-indigo-300">
                    {group.count} olay
                  </span>
                  <span className="inline-flex items-center rounded-full bg-slate-100 dark:bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                    {group.sourceCount} kaynak
                  </span>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-1 gap-2 text-xs text-slate-500">
                <div><span className="font-semibold text-slate-400">Aralık:</span> {new Date(group.firstTimestamp).toLocaleString("tr-TR")} - {new Date(group.lastTimestamp).toLocaleString("tr-TR")}</div>
                <div><span className="font-semibold text-slate-400">Hostname:</span> {group.sampleHostname}</div>
                <div><span className="font-semibold text-slate-400">Kaynak IP:</span> {group.sampleSourceIp}</div>
                <div><span className="font-semibold text-slate-400">Kaynaklar:</span> {group.sources.join(", ")}</div>
                <div className="truncate"><span className="font-semibold text-slate-400">Örnek:</span> {group.sampleMessage}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="relative">
        <Search className="absolute left-4 top-3 text-slate-400 w-4 h-4" />
        <input
          type="text"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          onKeyDown={(e) => { if (e.key === 'Enter') loadLogs(); }}
          placeholder="Log mesajı veya kaynak IP ara..."
          className="w-full pl-11 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
        />
      </div>

      <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
        {loading ? (
          <div className="flex justify-center items-center py-12 space-x-2">
            <RefreshCw className="w-6 h-6 text-indigo-500 animate-spin" />
            <span className="text-sm font-medium text-slate-500">Loglar yükleniyor...</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                  <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Zaman</th>
                  <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Vendor</th>
                  <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Severity</th>
                  <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Korelasyon</th>
                  <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Hostname</th>
                  <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Mesaj</th>
                  <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Kaynak IP</th>
                  <th className="px-4 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">Detay</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {logs.map((l) => (
                  <React.Fragment key={l.id}>
                    <tr className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors cursor-pointer" onClick={() => toggleExpand(l.id)}>
                      <td className="px-4 py-3 text-sm text-slate-500 whitespace-nowrap">{new Date(l.timestamp).toLocaleString("tr-TR")}</td>
                      <td className="px-4 py-3 text-sm font-medium text-slate-800 dark:text-slate-200">{l.vendor}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${severityColor[l.severity] || severityColor.info}`}>
                          {l.severity}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {l.correlation_id ? (
                          <div className="space-y-1">
                            <div className="inline-flex items-center rounded-full bg-slate-100 dark:bg-slate-800 px-2.5 py-0.5 text-[10px] font-semibold text-slate-600 dark:text-slate-300">
                              {l.correlation_type || "group"} · {l.correlation_group_size || 1}
                            </div>
                            <div className="text-[10px] text-slate-400 max-w-[12rem] truncate" title={l.correlation_reason || ""}>
                              {l.correlation_reason}
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-400 text-xs">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600 dark:text-slate-400 font-mono text-xs">{l.hostname}</td>
                      <td className="px-4 py-3 text-sm text-slate-600 dark:text-slate-400 max-w-xs truncate">{l.message}</td>
                      <td className="px-4 py-3 text-sm font-mono text-xs text-slate-500">
                        <div>{l.source_ip}</div>
                        {l.source && (
                          <div className="mt-1 text-[10px] uppercase tracking-wider text-slate-400">{l.source}</div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {expandedId === l.id ? <ChevronUp className="w-4 h-4 text-slate-400 inline" /> : <ChevronDown className="w-4 h-4 text-slate-400 inline" />}
                      </td>
                    </tr>
                    {expandedId === l.id && (
                      <tr key={`${l.id}-raw`} className="bg-slate-50/80 dark:bg-slate-950/40">
                        <td colSpan={8} className="px-6 py-4">
                          <div className="space-y-2">
                            <div className="text-xs font-semibold text-slate-400 uppercase">Ham Log</div>
                            <pre className="text-xs font-mono bg-slate-100 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 overflow-x-auto text-slate-700 dark:text-slate-300 leading-relaxed">
                              {l.raw}
                            </pre>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
                {logs.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-6 py-12 text-center text-slate-500">Filtrelere uygun log kaydı bulunamadı.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between">
        <span className="text-sm text-slate-500">Sayfa {page}</span>
        <div className="flex space-x-2">
          <button disabled={page <= 1} onClick={() => setPage(p => Math.max(1, p - 1))}
            className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors">
            Önceki
          </button>
          <button onClick={() => setPage(p => p + 1)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-colors">
            Sonraki
          </button>
        </div>
      </div>
    </div>
  );
};
