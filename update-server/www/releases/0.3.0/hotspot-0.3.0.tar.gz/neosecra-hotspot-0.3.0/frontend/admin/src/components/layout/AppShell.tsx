import React from 'react'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'
import { useLocation } from 'react-router-dom'

interface Props {
  children: React.ReactNode
}

export const AppShell: React.FC<Props> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = React.useState(false)
  const location = useLocation()

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-surface">
      <Sidebar
        className="w-64 flex-shrink-0"
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <Topbar onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
        <main className="flex-1 overflow-y-auto bg-surface p-4 sm:p-6 lg:p-8">
          <div
            className={`page-enter mx-auto w-full space-y-6 ${
              location.pathname === '/' ||
              location.pathname === '/firewall-logs' ||
              location.pathname === '/firewall-log' ||
              location.pathname === '/logs/search' ||
              location.pathname === '/sessions' ||
              location.pathname === '/approval-requests' ||
              location.pathname === '/users' ||
              location.pathname === '/online-users' ||
              location.pathname === '/traffic-analysis' ||
              location.pathname === '/alarm-dashboard' ||
              location.pathname === '/syslog-triggers' ||
              location.pathname.startsWith('/portal-templates/')
                ? 'max-w-[2200px]'
                : 'max-w-7xl'
            }`}
            key={location.pathname}
          >
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}
