import React, { useState } from "react";
import { User, Shield, HelpCircle, Save, Loader2 } from "lucide-react";
import { useTheme } from "../theme/ThemeProvider";
import { updateCurrentUserProfile } from "../lib/api";

export const SettingsPage: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const [profile, setProfile] = useState({
    name: "Hasan Coşan",
    email: "hasan@hotspot.com",
    role: "Süper Admin",
  });
  
  const [security, setSecurity] = useState({
    twoFaEnabled: false,
    sessionTimeout: 60,
  });

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [saving, setSaving] = useState(false);

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveError("");
    try {
      await updateCurrentUserProfile({ name: profile.name, email: profile.email });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      setSaveError(err?.message || "Kaydetme başarısız oldu");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Ayarlar</h2>
        <p className="text-sm text-slate-500">Profil bilgilerinizi, sistem teması tercihlerini ve güvenlik ayarlarını yapılandırın.</p>
      </div>

            {savedSuccess && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/50 rounded-xl text-sm font-medium">
          Profil ve sistem ayarları kaydedildi!
        </div>
      )}
      {saveError && (
        <div className="p-3 bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 border border-rose-100 dark:border-rose-900/50 rounded-xl text-sm font-medium">
          {saveError}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profile Card */}
        <form onSubmit={handleProfileSave} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
            <User className="w-4 h-4 mr-2 text-indigo-500" />
            Profil Bilgileri
          </h3>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Adınız Soyadınız</label>
              <input
                type="text"
                value={profile.name}
                onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">E-Posta Adresi</label>
              <input
                type="email"
                value={profile.email}
                onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Sistem Rolü</label>
              <input
                type="text"
                disabled
                value={profile.role}
                className="w-full px-4 py-2 border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-slate-400 rounded-xl text-sm"
              />
            </div>
          </div>
          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300 text-white transition-all"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              {saving ? "Kaydediliyor..." : "Kaydet"}
            </button>
          </div>
        </form>

        {/* Security & System settings */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
          {/* Security */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Shield className="w-4 h-4 mr-2 text-indigo-500" />
              Güvenlik Ayarları
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-slate-800 dark:text-slate-200">İki Faktörlü Doğrulama (2FA)</div>
                  <div className="text-xs text-slate-400">TOTP (Google Authenticator) doğrulamasını zorunlu kılın.</div>
                </div>
                <button
                  type="button"
                  onClick={() => setSecurity({ ...security, twoFaEnabled: !security.twoFaEnabled })}
                  className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none ${
                    security.twoFaEnabled ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-800'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${
                    security.twoFaEnabled ? 'left-5.5' : 'left-0.5'
                  }`} />
                </button>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Maksimum Oturum Zaman Aşımı (Dakika)</label>
                <input
                  type="number"
                  value={security.sessionTimeout}
                  onChange={(e) => setSecurity({ ...security, sessionTimeout: Number(e.target.value) })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Theme */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <HelpCircle className="w-4 h-4 mr-2 text-indigo-500" />
              Sistem Arayüz Tercihi
            </h3>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-slate-800 dark:text-slate-200">Karanlık Mod (Dark Mode)</div>
                <div className="text-xs text-slate-400">Arayüz renklerini gece moduna geçirin.</div>
              </div>
              <button
                type="button"
                onClick={toggleTheme}
                className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none ${
                  theme === 'dark' ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-800'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${
                  theme === 'dark' ? 'left-5.5' : 'left-0.5'
                }`} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
