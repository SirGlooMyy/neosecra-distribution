/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: ['selector', '[data-theme="dark"]'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      colors: {
        base: 'var(--bg-base)',
        surface: {
          DEFAULT: 'var(--bg-base)',
          secondary: 'var(--bg-secondary)',
          card: 'var(--bg-card)',
          hover: 'var(--bg-hover)',
          app: 'var(--surface-app)',
          shell: 'var(--surface-shell)',
          page: 'var(--surface-page)',
          panel: 'var(--surface-panel)',
          elevated: 'var(--surface-elevated)',
          selected: 'var(--surface-selected)',
        },
        border: {
          DEFAULT: 'var(--border-color)',
          light: 'var(--border-light)',
          subtle: 'var(--border-subtle)',
          strong: 'var(--border-strong)',
        },
        risk: {
          critical: 'var(--risk-critical)',
          high: 'var(--risk-high)',
          medium: 'var(--risk-medium)',
          low: 'var(--risk-low)',
          info: 'var(--risk-info)',
          success: 'var(--risk-success)',
          warning: 'var(--risk-warning)',
          destructive: 'var(--risk-destructive)',
          muted: 'var(--risk-muted)',
        },
        accent: {
          fortigate: 'var(--accent-fortigate)',
          ad: 'var(--accent-ad)',
          m365: 'var(--accent-m365)',
          veeam: 'var(--accent-veeam)',
          openvas: 'var(--accent-openvas)',
        },
      },
      textColor: {
        primary: 'var(--text-primary)',
        secondary: 'var(--text-secondary)',
        muted: 'var(--text-muted)',
      },
      borderRadius: {
        'ds-sm': '6px',
        'ds-md': '10px',
        'ds-lg': '14px',
      },
      boxShadow: {
        elevated: '0 4px 16px rgba(0,0,0,0.24), 0 1px 4px rgba(0,0,0,0.12)',
      },
      backdropBlur: {
        xs: '2px',
      },
    },
  },
  plugins: [],
}
