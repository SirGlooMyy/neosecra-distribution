import { Menu } from 'lucide-react'
import { ThemeToggle } from './ThemeToggle'

interface Props {
  onMenuClick?: () => void
}

export const Topbar: React.FC<Props> = ({ onMenuClick }) => (
  <header className="flex items-center justify-between border-b border-border bg-surface-panel px-6 py-4">
    <button
      onClick={onMenuClick}
      className="rounded-ds-md border border-border p-2 text-secondary transition-colors hover:bg-surface-hover hover:text-primary md:hidden"
      aria-label="Menü Aç"
    >
      <Menu className="h-5 w-5" />
    </button>

    <h1 className="text-lg font-semibold text-primary">
      Hotspot Yönetim Paneli
    </h1>

    <div className="flex items-center space-x-3">
      <ThemeToggle />
    </div>
  </header>
)
