import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

vi.mock('../../lib/api', () => ({
  getSessions: vi.fn(),
  getSessionCorrelation: vi.fn(),
  closeSession: vi.fn(),
  retryAuthorization: vi.fn(),
  syncSessionWithDevice: vi.fn(),
}));

import {
  getSessions,
  closeSession,
  retryAuthorization,
} from '../../lib/api';
import { SessionsPage } from '../SessionsPage';

// RawSession API shape mock data
const mockRawSessions: any[] = [
  {
    id: 'sess-1',
    phone: '+905551234567',
    mac: 'AA:BB:CC:DD:EE:01',
    ip: '192.168.1.100',
    nas_ip: '192.168.1.1',
    ssid: 'FortiGate-1',
    started_at: '2025-01-15T10:00:00Z',
    auth_method: 'sms_otp',
    status: 'active',
    authorize_ok: true,
    meta: {
      authorization_status: 'authorized',
      fortigate_sync_status: 'healthy',
      device_name: 'FortiGate-1',
      external_session_id: 'ext-abc-123',
      authorized_at: '2025-01-15T10:01:00Z',
      group_policy: { group_name: 'VIP Müsteriler' },
    },
  },
  {
    id: 'sess-2',
    phone: '+905559876543',
    mac: 'AA:BB:CC:DD:EE:02',
    ip: '192.168.1.101',
    nas_ip: '192.168.1.1',
    started_at: '2025-01-15T10:05:00Z',
    auth_method: 'sms_otp',
    status: 'pending',
    authorize_ok: false,
    meta: {
      authorization_status: 'pending',
      fortigate_sync_status: 'not-configured',
      group_policy: { group_name: 'Standart' },
    },
  },
  {
    id: 'sess-3',
    phone: '+905551112233',
    mac: 'AA:BB:CC:DD:EE:03',
    ip: '192.168.1.102',
    nas_ip: '192.168.1.1',
    ssid: 'FortiGate-2',
    started_at: '2025-01-15T09:30:00Z',
    auth_method: 'voucher',
    status: 'active',
    authorize_ok: false,
    authorize_message: 'Firewall hatası: timeout',
    meta: {
      authorization_status: 'failed',
      authorize_error: 'Yetkilendirme başarısız: Cihaz yanıt vermedi',
      fortigate_sync_status: 'unhealthy',
      device_name: 'FortiGate-2',
    },
  },
];

describe('SessionsPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (getSessions as any).mockResolvedValue(mockRawSessions);
  });

  it('shows loading skeleton while fetching sessions', async () => {
    (getSessions as any).mockImplementation(() => new Promise(() => {}));
    render(<SessionsPage />);
    expect(screen.getByText('Oturumlar')).toBeInTheDocument();
    expect(screen.getByText(/Aktif ve geçmiş oturumları/)).toBeInTheDocument();
  });

  it('renders session rows after successful load', async () => {
    render(<SessionsPage />);
    expect(await screen.findByText('+905551234567')).toBeInTheDocument();
    expect(await screen.findByText('+905559876543')).toBeInTheDocument();
    expect(await screen.findByText('+905551112233')).toBeInTheDocument();
    expect(getSessions).toHaveBeenCalledTimes(1);
  });

  it('shows pending authorization badge for pending sessions', async () => {
    render(<SessionsPage />);
    const pending = await screen.findAllByText('Bekliyor');
    expect(pending.length).toBeGreaterThanOrEqual(1);
  });

  it('shows authorized badge for authorized sessions', async () => {
    render(<SessionsPage />);
    const authorized = await screen.findAllByText('Yetkilendirildi');
    expect(authorized.length).toBeGreaterThanOrEqual(1);
  });

  it('shows failed badge for failed sessions', async () => {
    render(<SessionsPage />);
    const failed = await screen.findAllByText('Başarısız');
    expect(failed.length).toBeGreaterThanOrEqual(1);
  });

  it('opens revoke confirmation modal when revoke button clicked', async () => {
    render(<SessionsPage />);
    await screen.findByText('Yetkilendirildi');
    const revokeButtons = screen.getAllByTitle('Oturumu Sonlandır');
    expect(revokeButtons.length).toBeGreaterThanOrEqual(1);
    const user = userEvent.setup();
    await user.click(revokeButtons[0]);
    expect(screen.getByText('Oturumu Sonlandır')).toBeInTheDocument();
  });

  it('calls closeSession when revoke is confirmed', async () => {
    (closeSession as any).mockResolvedValue(undefined);
    render(<SessionsPage />);
    await screen.findByText('Yetkilendirildi');
    const user = userEvent.setup();
    const revokeButtons = screen.getAllByTitle('Oturumu Sonlandır');
    await user.click(revokeButtons[0]);
    await user.click(screen.getByText('Evet, Sonlandır'));
    expect(closeSession).toHaveBeenCalledWith('sess-1', 'Yönetici tarafından sonlandırıldı');
  });

  it('shows retry button for failed authorization', async () => {
    render(<SessionsPage />);
    const failed = await screen.findAllByText('Başarısız');
    expect(failed.length).toBeGreaterThanOrEqual(1);
    const retryButtons = screen.getAllByTitle('Yetkilendirmeyi Tekrar Dene');
    expect(retryButtons.length).toBeGreaterThanOrEqual(1);
  });

  it('calls retryAuthorization when retry button clicked', async () => {
    (retryAuthorization as any).mockResolvedValue({ ok: true });
    render(<SessionsPage />);
    const failed = await screen.findAllByText('Başarısız');
    expect(failed.length).toBeGreaterThanOrEqual(1);
    const user = userEvent.setup();
    const retryButtons = screen.getAllByTitle('Yetkilendirmeyi Tekrar Dene');
    await user.click(retryButtons[0]);
    expect(retryAuthorization).toHaveBeenCalledWith('sess-3');
  });

  it('shows error state when fetching sessions fails', async () => {
    (getSessions as any).mockRejectedValue(new Error('Veritabanı hatası'));
    render(<SessionsPage />);
    expect(await screen.findByText('Veritabanı hatası')).toBeInTheDocument();
    expect(screen.getByText('Tekrar Dene')).toBeInTheDocument();
  });

  it('shows offline banner when network error occurs', async () => {
    (getSessions as any).mockRejectedValue(new TypeError('Failed to fetch'));
    render(<SessionsPage />);
    expect(await screen.findByText('Sunucuya Bağlanılamıyor')).toBeInTheDocument();
    expect(screen.getByText('Tekrar Dene')).toBeInTheDocument();
  });

  it('shows empty state when no sessions exist', async () => {
    (getSessions as any).mockResolvedValue([]);
    render(<SessionsPage />);
    expect(await screen.findByText('Henüz Oturum Yok')).toBeInTheDocument();
  });

  it('closes revoke modal when cancel is clicked', async () => {
    render(<SessionsPage />);
    await screen.findByText('Yetkilendirildi');
    const user = userEvent.setup();
    const revokeButtons = screen.getAllByTitle('Oturumu Sonlandır');
    await user.click(revokeButtons[0]);
    expect(screen.getByText('Oturumu Sonlandır')).toBeInTheDocument();
    await user.click(screen.getByText('İptal'));
    expect(screen.queryByText('Evet, Sonlandır')).not.toBeInTheDocument();
  });
});
