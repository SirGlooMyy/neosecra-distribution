export default function App() {
  return (
    <div className="min-h-screen p-6">
      <h1>Hotspot Platform Admin</h1>
      <p>Super Admin / Partner / Customer / Location / Operations panel skeleton.</p>
    </div>
  );
}
