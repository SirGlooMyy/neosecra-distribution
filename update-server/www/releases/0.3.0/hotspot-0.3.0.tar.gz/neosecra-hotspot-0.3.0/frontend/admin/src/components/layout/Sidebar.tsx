import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { logout } from '../../lib/api'
import { ChevronDown, LogOut } from 'lucide-react'
import {
  Home, Users, MapPin, Server,
  Globe, Key, Hotel, Clock, Wifi, FileStack, Bell, AlertTriangle,
  Database, PenSquare, Activity, BarChart2, Calendar, Settings, Search, UserCheck, Award, RefreshCw,
} from 'lucide-react'

interface MenuItem {
  label: string
  path: string
  icon: any
}

interface MenuSection {
  title: string
  items: MenuItem[]
}

const sections: MenuSection[] = [
  {
    title: 'Genel',
    items: [
      { label: 'Genel Bakış', path: '/', icon: Home },
      { label: 'Lokasyonlar', path: '/locations', icon: MapPin },
    ],
  },
  {
    title: 'Altyapı',
    items: [
      { label: 'Cihazlar', path: '/devices', icon: Server },
    ],
  },
  {
    title: 'Kullanıcılar',
    items: [
      { label: 'Erişim Profilleri', path: '/user-groups', icon: Users },
      { label: 'Kullanıcı Yönetimi', path: '/users', icon: Users },
    ],
  },
  {
    title: 'Portal',
    items: [
      { label: 'Captive Portal', path: '/portal-templates', icon: Globe },
      { label: 'Auth Yöntemleri', path: '/auth-methods', icon: Key },
      { label: 'Otel / PMS', path: '/pms-config', icon: Hotel },
    ],
  },
  {
    title: 'İzleme',
    items: [
      { label: 'Oturumlar', path: '/sessions', icon: Clock },
      { label: 'Onay İstekleri', path: '/approval-requests', icon: UserCheck },
      { label: 'Online Kullanıcılar', path: '/online-users', icon: Wifi },
      { label: 'Firewall Analyzer', path: '/firewall-logs', icon: FileStack },
      { label: 'Syslog Triggers', path: '/syslog-triggers', icon: Bell },
      { label: 'Alarm Panosu', path: '/alarm-dashboard', icon: AlertTriangle },
    ],
  },
  {
    title: 'Loglar & Raporlar',
    items: [
      { label: '5651 Logları', path: '/archives', icon: Database },
      { label: 'Signing Config', path: '/signing-config', icon: PenSquare },
      { label: 'Trafik Analizi', path: '/traffic-analysis', icon: Activity },
      { label: 'Raporlar', path: '/reports', icon: BarChart2 },
      { label: 'Report Scheduler', path: '/report-scheduler', icon: Calendar },
      { label: 'Log Arama', path: '/logs/search', icon: Search },
    ],
  },
    {
      title: 'Sistem',
      items: [
        { label: 'Ayarlar', path: '/settings', icon: Settings },
        { label: 'Platform Lisansı', path: '/platform-license', icon: Award },
        { label: 'Güncelleme Merkezi', path: '/platform-upgrade', icon: RefreshCw },
      ],
  },
]

export const Sidebar: React.FC<{
  className?: string
  isOpen?: boolean
  onClose?: () => void
}> = ({ className = '', isOpen = false, onClose }) => {
  const navigate = useNavigate()
  const location = useLocation()
  const [expanded, setExpanded] = useState<string[]>([
    'Genel', 'Altyapı', 'Kullanıcılar', 'Portal',
    'İzleme', 'Loglar & Raporlar', 'Sistem',
  ])

  const toggleSection = (title: string) => {
    setExpanded(prev =>
      prev.includes(title) ? prev.filter(t => t !== title) : [...prev, title]
    )
  }

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/'
    // /firewall-log is the legacy singular bookmark for the Analyzer route.
    // Keep the canonical sidebar item highlighted for both URLs.
    if (path === '/firewall-logs') {
      return location.pathname === '/firewall-logs' || location.pathname === '/firewall-log'
    }
    return location.pathname.startsWith(path)
  }

  const handleLogout = () => {
    if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
      logout()
    }
  }

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 z-20 bg-black/60 backdrop-blur-sm md:hidden" onClick={() => onClose?.()} />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-30 flex w-64 flex-col border-r border-border bg-surface-secondary p-5 transition-transform duration-200 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 md:static ${className}`}
      >
        <div className="mb-6 flex items-center space-x-3 px-2">
          <div className="flex items-center justify-center rounded-ds-md bg-gradient-to-tr from-indigo-500 to-violet-600 p-2 text-white shadow-md">
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span className="bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-xl font-bold text-transparent dark:from-indigo-400 dark:to-violet-400">
            Hotspot
          </span>
        </div>

        <nav className="flex-1 space-y-4 overflow-y-auto pr-1">
          {sections.map((section) => {
            const isExpanded = expanded.includes(section.title)
            const hasActive = section.items.some(i => isActive(i.path))
            return (
              <div key={section.title}>
                <button
                  onClick={() => toggleSection(section.title)}
                  className={`flex w-full items-center justify-between px-4 py-1.5 text-[10px] font-semibold uppercase tracking-widest transition-colors ${
                    hasActive && !isExpanded
                      ? 'text-primary'
                      : 'text-muted'
                  } hover:text-primary`}
                >
                  {section.title}
                  <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                </button>
                {isExpanded && (
                  <ul className="mt-1 space-y-0.5">
                    {section.items.map((item) => {
                      const Icon = item.icon
                      const active = isActive(item.path)
                      return (
                        <li key={item.label}>
                          <a
                            href={item.path}
                            onClick={(e) => { e.preventDefault(); navigate(item.path); onClose?.() }}
                            className={`flex items-center rounded-ds-md px-4 py-2 text-sm font-medium transition-all duration-150 ${
                              active
                                ? 'bg-surface-selected text-primary'
                                : 'text-secondary hover:bg-surface-hover hover:text-primary'
                            }`}
                          >
                            <Icon className={`mr-3 h-4.5 w-4.5 ${active ? 'text-primary' : 'text-muted'}`} />
                            {item.label}
                          </a>
                        </li>
                      )
                    })}
                  </ul>
                )}
              </div>
            )
          })}
        </nav>

        <div className="mt-auto border-t border-border pt-4">
          <div className="flex items-center justify-between rounded-ds-md border border-border-subtle bg-white/[0.01] p-3 transition-colors hover:bg-white/[0.03]">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-tr from-indigo-500 to-violet-600 text-sm font-bold text-white shadow-[0_0_12px_rgba(59,130,246,0.2)]">
                H
              </div>
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold text-primary">Hasan Coşan</div>
                <div className="text-[11px] uppercase tracking-wider text-muted">Süper Admin</div>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="rounded-ds-sm p-1.5 text-muted transition-colors hover:bg-rose-500/10 hover:text-rose-400"
              aria-label="Çıkış Yap"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  )
}
