import React, { useState, useEffect } from "react";
import { getAuthMethodsConfig, getSmsAuthStatus, getSmsAuthConfig, updateSmsAuthConfig, testSmsAuth, updateWhatsAppConfig, testWhatsApp, updateLdapConfig, testLdapConnection, getMeetingCodes, createMeetingCode, deleteMeetingCode, getLocalUsers, createLocalUser, updateLocalUser, deleteLocalUser, getVpnMfaConfig, updateVpnMfaConfig, getVpnMfaUsers, createVpnMfaUser, deleteVpnMfaUser, generateVpnMfaRadiusConfig, testVpnRadius } from "../lib/api";
import { MessageCircle, Server, QrCode, Users, Plus, Trash2, Edit3, Save, RefreshCw, Send, CheckCircle2, XCircle, Activity, ShieldCheck, Mail, Phone, KeyRound, Copy } from "lucide-react";

const BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function generateTotpSecret(length = 20) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  let bits = 0;
  let value = 0;
  let output = "";
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  return output;
}

const vpnMethodLabel = (method: string) => method === "totp" ? "Authenticator (TOTP)" : method === "sms" ? "SMS OTP" : "E-posta OTP";
const maskContact = (value?: string | null) => {
  if (!value) return "—";
  if (value.includes("@")) {
    const [name, domain] = value.split("@");
    return `${name.slice(0, 2)}•••@${domain}`;
  }
  return value.length > 6 ? `${value.slice(0, 3)}•••${value.slice(-2)}` : "••••••";
};

export const AuthMethodsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"sms" | "vpn" | "whatsapp" | "ldap" | "meeting" | "users">("sms");
  const [config, setConfig] = useState<any>({ whatsapp: {}, ldap: {} });
  const [smsStatus, setSmsStatus] = useState<any>(null);
  const [smsConfig, setSmsConfig] = useState<any>({ provider: "console", username: "", password: "", api_key: "", api_secret: "", sender: "", http_url: "", http_token: "", http_template: "", provider_options: {} });
  const [smsTestPhone, setSmsTestPhone] = useState("");
  const [smsTestMessage, setSmsTestMessage] = useState("Hotspot SMS test mesajı");
  const [meetingCodes, setMeetingCodes] = useState<any[]>([]);
  const [localUsers, setLocalUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [testing, setTesting] = useState(false);
  const [waTestPhone, setWaTestPhone] = useState("");
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [userForm, setUserForm] = useState({ username: "", password: "", display_name: "", email: "", phone: "", role: "guest" });
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [codeForm, setCodeForm] = useState({ code: "", event_name: "", max_uses: 50, duration_minutes: 480, expires_at: "" });
  const [vpnConfig, setVpnConfig] = useState<any>({ is_enabled: false, gateway_host: "", gateway_port: 1812, radius_nas_ip: "", radius_accounting_port: 1813, radius_secret_configured: false, radius_shared_secret: "", allowed_groups: [], mfa_method: "totp" });
  const [vpnUsers, setVpnUsers] = useState<any[]>([]);
  const [vpnUserForm, setVpnUserForm] = useState({ username: "", mfa_method: "totp", secret: "", phone: "", email: "" });
  const [vpnSnippet, setVpnSnippet] = useState("");
  const [vpnBusy, setVpnBusy] = useState(false);
  const [vpnUserQuery, setVpnUserQuery] = useState("");
  const [vpnUserMethod, setVpnUserMethod] = useState("all");
  const [showVpnUserForm, setShowVpnUserForm] = useState(false);

  const smsOptions = smsConfig.provider_options || {};
  const setSmsOption = (key: string, value: any) => setSmsConfig((current: any) => ({ ...current, provider_options: { ...(current.provider_options || {}), [key]: value } }));
  const smsRequestPreview = () => {
    const provider = smsConfig.provider || "console";
    if (provider === "vatansms") return { method: "POST", url: "https://api.vatansms.net/api/v1/1toN", auth: "JSON body credentials", body: { api_id: "API_ID", api_key: "API_KEY", sender: smsConfig.sender || "HOTSPOT", message_type: smsOptions.message_type || "normal", message: "Dogrulama kodunuz: 123456", message_content_type: smsOptions.message_content_type || "bilgi", phones: ["5xxxxxxxxx"] } };
    if (provider === "netgsm") return { method: "POST", url: "https://api.netgsm.com.tr/sms/rest/v2/send", auth: "Basic (kullanıcı kodu:şifre)", body: { msgheader: smsConfig.sender || "HOTSPOT", messages: [{ msg: "Dogrulama kodunuz: 123456", no: "905xxxxxxxxx" }], encoding: smsOptions.encoding || "TR", iysfilter: smsOptions.iysfilter || "0", ...(smsOptions.appname ? { appname: smsOptions.appname } : {}) } };
    if (provider === "iletimerkezi") return { method: "POST", url: smsOptions.endpoint || "https://api.iletimerkezi.com/v1/send-sms", auth: "JSON authentication.key + authentication.hash", body: { request: { authentication: { key: "API_KEY", hash: "API_HASH" }, order: { sender: smsConfig.sender || "HOTSPOT", message: { text: "Dogrulama kodunuz: 123456" }, receipents: { number: ["905xxxxxxxxx"] } } } } };
    if (provider === "twilio") return { method: "POST", url: "https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json", auth: "Basic (Account SID:Auth Token)", body: { To: "+905xxxxxxxxx", ...(smsOptions.messaging_service_sid ? { MessagingServiceSid: smsOptions.messaging_service_sid } : { From: smsConfig.sender || "+1..." }), Body: "Dogrulama kodunuz: 123456" } };
    if (provider === "http") return { method: smsOptions.method || "POST", url: smsConfig.http_url || "https://sms.example.com/send", auth: smsOptions.auth_type || "bearer", body: smsOptions.body_template || { [smsOptions.sender_field || "sender"]: smsConfig.sender || "HOTSPOT", [smsOptions.recipient_field || "to"]: "+905xxxxxxxxx", [smsOptions.message_field || "message"]: "Dogrulama kodunuz: 123456" } };
    return { method: "-", url: "-", body: "Demo: kod sunucu loguna yazılır" };
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [c, sms, smsCfg, m, u] = await Promise.all([getAuthMethodsConfig(), getSmsAuthStatus(), getSmsAuthConfig(), getMeetingCodes(), getLocalUsers()]);
      setConfig(c); setMeetingCodes(m); setLocalUsers(u);
      setSmsStatus(sms);
      if (smsCfg) setSmsConfig((current: any) => ({ ...current, ...smsCfg }));
      const [vpn, registered] = await Promise.allSettled([getVpnMfaConfig(), getVpnMfaUsers()]);
      if (vpn.status === "fulfilled" && vpn.value) setVpnConfig((current: any) => ({ ...current, ...vpn.value }));
      if (registered.status === "fulfilled" && Array.isArray(registered.value)) setVpnUsers(registered.value);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, []);

  const showSuccess = () => { setSavedSuccess(true); setTimeout(() => setSavedSuccess(false), 3000); };

  const handleWaSave = async () => {
    try { await updateWhatsAppConfig(config.whatsapp); showSuccess(); }
    catch (err) { console.error(err); }
  };

  const handleWaTest = async () => {
    if (!waTestPhone) return;
    setTesting(true); setTestResult(null);
    try {
      const res = await testWhatsApp(waTestPhone);
      setTestResult(res);
    } catch (err: any) { setTestResult({ success: false, message: err.message }); }
    finally { setTesting(false); }
  };

  const handleLdapSave = async () => {
    try { await updateLdapConfig(config.ldap); showSuccess(); }
    catch (err) { console.error(err); }
  };

  const handleLdapTest = async () => {
    setTesting(true); setTestResult(null);
    try {
      const res = await testLdapConnection();
      setTestResult(res);
    } catch (err: any) { setTestResult({ success: false, message: err.message }); }
    finally { setTesting(false); }
  };

  const handleSmsSave = async () => {
    setTesting(true); setTestResult(null);
    try {
      const saved = await updateSmsAuthConfig(smsConfig);
      setSmsConfig((current: any) => ({ ...current, ...saved, password: saved.password || current.password, api_key: saved.api_key || current.api_key, api_secret: saved.api_secret || current.api_secret, http_token: saved.http_token || current.http_token, provider_options: saved.provider_options || current.provider_options || {} }));
      setSmsStatus((current: any) => ({ ...current, provider: saved.provider, configured: saved.configured, source: saved.source, sender: saved.sender }));
      showSuccess();
    } catch (err: any) { setTestResult({ success: false, message: err?.message || "SMS ayarları kaydedilemedi" }); }
    finally { setTesting(false); }
  };

  const handleSmsTest = async () => {
    if (!smsTestPhone.trim()) return;
    setTesting(true); setTestResult(null);
    try { setTestResult(await testSmsAuth(smsTestPhone, smsTestMessage)); }
    catch (err: any) { setTestResult({ success: false, message: err?.message || "SMS testi başarısız" }); }
    finally { setTesting(false); }
  };

  const handleVpnSave = async () => {
    setVpnBusy(true);
    try {
      const payload = { ...vpnConfig, gateway_port: Number(vpnConfig.gateway_port) || 1812, radius_accounting_port: Number(vpnConfig.radius_accounting_port) || 1813, radius_shared_secret: vpnConfig.radius_shared_secret?.trim() || undefined };
      await updateVpnMfaConfig(payload);
      setVpnConfig((v: any) => ({ ...v, radius_shared_secret: "", radius_secret_configured: Boolean(v.radius_shared_secret?.trim()) || v.radius_secret_configured }));
      showSuccess();
    }
    catch (err: any) { setTestResult({ success: false, message: err?.message || "VPN MFA ayarı kaydedilemedi" }); }
    finally { setVpnBusy(false); }
  };

  const handleVpnRadiusTest = async () => {
    setVpnBusy(true); setTestResult(null);
    try { setTestResult(await testVpnRadius()); }
    catch (err: any) { setTestResult({ ok: false, message: err?.message || "RADIUS bağlantı testi başarısız" }); }
    finally { setVpnBusy(false); }
  };

  const handleVpnUserSave = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!vpnUserForm.username.trim()) return;
    if (vpnUserForm.mfa_method === "totp" && !vpnUserForm.secret.trim()) {
      setTestResult({ success: false, message: "TOTP için secret üretin veya mevcut secretı girin." });
      return;
    }
    if (vpnUserForm.mfa_method === "sms" && !vpnUserForm.phone.trim()) {
      setTestResult({ success: false, message: "SMS MFA için telefon numarası gereklidir." });
      return;
    }
    if (vpnUserForm.mfa_method === "email" && !vpnUserForm.email.trim()) {
      setTestResult({ success: false, message: "E-posta MFA için e-posta adresi gereklidir." });
      return;
    }
    setVpnBusy(true);
    try {
      const payload = { ...vpnUserForm, username: vpnUserForm.username.trim(), secret: vpnUserForm.secret || undefined, phone: vpnUserForm.phone || undefined, email: vpnUserForm.email || undefined };
      const created = await createVpnMfaUser(payload);
      setVpnUsers((current) => [...current, created]);
      setVpnUserForm({ username: "", mfa_method: vpnConfig.mfa_method || "totp", secret: "", phone: "", email: "" });
      setShowVpnUserForm(false);
      showSuccess();
    } catch (err: any) { setTestResult({ success: false, message: err?.message || "VPN kullanıcısı eklenemedi" }); }
    finally { setVpnBusy(false); }
  };

  const handleVpnUserDelete = async (id: string) => {
    if (!confirm("Bu VPN kullanıcısının MFA kaydını devre dışı bırakmak istiyor musunuz?")) return;
    try { await deleteVpnMfaUser(id); setVpnUsers((current) => current.filter((item) => item.id !== id)); }
    catch (err: any) { setTestResult({ success: false, message: err?.message || "VPN kullanıcısı silinemedi" }); }
  };

  const handleGenerateVpnSnippet = async () => {
    setVpnBusy(true);
    try { const result = await generateVpnMfaRadiusConfig(); setVpnSnippet(result.config || ""); }
    catch (err: any) { setTestResult({ success: false, message: err?.message || "RADIUS yapılandırması üretilemedi" }); }
    finally { setVpnBusy(false); }
  };

  const openUserCreate = () => {
    setEditingUser(null); setUserForm({ username: "", password: "", display_name: "", email: "", phone: "", role: "guest" }); setShowUserModal(true);
  };
  const openUserEdit = (u: any) => {
    setEditingUser(u); setUserForm({ username: u.username, password: "", display_name: u.display_name, email: u.email || "", phone: u.phone || "", role: u.role || "guest" }); setShowUserModal(true);
  };

  const handleUserSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingUser) {
        const payload = { ...userForm };
        if (!payload.password) delete payload.password;
        const updated = await updateLocalUser(editingUser.id, payload);
        setLocalUsers(localUsers.map(u => u.id === editingUser.id ? updated : u));
      } else {
        const created = await createLocalUser(userForm);
        setLocalUsers([created, ...localUsers]);
      }
      setShowUserModal(false);
    } catch (err) { console.error(err); }
  };

  const handleUserDelete = async (id: string) => {
    if (!confirm("Bu kullanıcıyı silmek istediğinize emin misiniz?")) return;
    try { await deleteLocalUser(id); setLocalUsers(localUsers.filter(u => u.id !== id)); }
    catch (err) { console.error(err); }
  };

  const handleCodeSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const created = await createMeetingCode({ ...codeForm, expires_at: new Date(codeForm.expires_at).toISOString() });
      setMeetingCodes([created, ...meetingCodes]);
      setShowCodeModal(false);
    } catch (err) { console.error(err); }
  };

  const handleCodeDelete = async (id: string) => {
    if (!confirm("Bu toplantı kodunu silmek istediğinize emin misiniz?")) return;
    try { await deleteMeetingCode(id); setMeetingCodes(meetingCodes.filter(c => c.id !== id)); }
    catch (err) { console.error(err); }
  };

  const filteredVpnUsers = vpnUsers.filter((item) => {
    const query = vpnUserQuery.trim().toLowerCase();
    const matchesQuery = !query || [item.username, item.phone, item.email].filter(Boolean).some((value: string) => value.toLowerCase().includes(query));
    return matchesQuery && (vpnUserMethod === "all" || item.mfa_method === vpnUserMethod);
  });

  const handleVpnUsersRefresh = async () => {
    setVpnBusy(true);
    try {
      const users = await getVpnMfaUsers();
      setVpnUsers(Array.isArray(users) ? users : []);
    } catch (err: any) {
      setTestResult({ success: false, message: err?.message || "VPN kullanıcıları alınamadı" });
    } finally {
      setVpnBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Kimlik Doğrulama Yöntemleri</h2>
        <p className="text-sm text-slate-500">FortiGate captive portal için SMS/OTP doğrulama ve erişim kullanıcılarını yönetin.</p>
      </div>

      {savedSuccess && <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/50 rounded-xl text-sm font-medium">Ayarlar kaydedildi!</div>}

      <div className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        {(["sms", "vpn", "meeting", "users"] as const).map(tab => (
          <button key={tab} onClick={() => { setActiveTab(tab); setTestResult(null); }}
            className={`inline-flex items-center px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeTab === tab ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 shadow-sm" : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"}`}>
            {tab === "sms" ? <MessageCircle className="w-4 h-4 mr-2" /> : tab === "vpn" ? <ShieldCheck className="w-4 h-4 mr-2" /> : tab === "meeting" ? <QrCode className="w-4 h-4 mr-2" /> : <Users className="w-4 h-4 mr-2" />}
            {tab === "sms" ? "Portal SMS / OTP" : tab === "vpn" ? "VPN MFA (FortiGate)" : tab === "meeting" ? "Toplantı Kodları" : "Yerel Kullanıcılar"}
          </button>
        ))}
      </div>

      {activeTab === "sms" && (
        <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1.35fr)_minmax(300px,0.65fr)] gap-6">
          <details className="xl:col-span-2 rounded-2xl border border-indigo-200 bg-slate-950 p-4 text-xs shadow-sm dark:border-indigo-900/50"><summary className="cursor-pointer font-semibold text-slate-200">Sağlayıcıya gidecek örnek POST</summary><pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap text-[11px] leading-5 text-emerald-300">{JSON.stringify(smsRequestPreview(), null, 2)}</pre></details>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-5">
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div><h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center"><MessageCircle className="w-4 h-4 mr-2 text-indigo-500" /> Captive Portal SMS / OTP</h3><p className="mt-1 text-sm text-slate-500">Misafir doğrulama kodları burada seçtiğiniz sağlayıcı üzerinden gönderilir.</p></div>
              <span className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${smsStatus?.configured ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300" : "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300"}`}>{smsStatus?.configured ? "Üretim" : "Demo"}</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block text-sm font-medium">SMS sağlayıcısı<select value={smsConfig.provider || "console"} onChange={(e) => setSmsConfig((v: any) => ({ ...v, provider: e.target.value, provider_options: {} }))} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950"><option value="console">Console (demo)</option><option value="netgsm">NetGSM (Türkiye)</option><option value="iletimerkezi">İleti Merkezi</option><option value="vatansms">VatanSMS</option><option value="twilio">Twilio</option><option value="muttl">Muttl</option><option value="relateddigital">Related Digital</option><option value="http">Özel HTTP gateway</option></select></label>
              <label className="block text-sm font-medium">Gönderici başlığı<input value={smsConfig.sender || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, sender: e.target.value }))} placeholder="HOTSPOT" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /><span className="mt-1 block text-[11px] font-normal text-slate-500">Operatör onaylı başlık veya Twilio From numarası</span></label>
            </div>
            {smsConfig.provider === "netgsm" && <div className="space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/50"><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">NetGSM kullanıcı kodu<input value={smsConfig.username || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, username: e.target.value }))} placeholder="850xxxx" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label><label className="block text-sm font-medium">NetGSM API şifresi<input type="password" autoComplete="new-password" value={smsConfig.password || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, password: e.target.value }))} placeholder={smsConfig.password_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div><div className="grid gap-4 sm:grid-cols-3"><label className="block text-sm font-medium">Encoding<select value={smsOptions.encoding || "TR"} onChange={(e) => setSmsOption("encoding", e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950"><option value="TR">TR</option><option value="UTF-8">UTF-8</option><option value="UNICODE">UNICODE</option></select></label><label className="block text-sm font-medium">IYS filtresi<select value={smsOptions.iysfilter ?? "0"} onChange={(e) => setSmsOption("iysfilter", e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950"><option value="0">Uygulama yok</option><option value="11">Bireysel izinli</option><option value="12">Ticari izinli</option></select></label><label className="block text-sm font-medium">Uygulama adı<input value={smsOptions.appname || ""} onChange={(e) => setSmsOption("appname", e.target.value)} placeholder="Hotspot Portal" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div><p className="text-[11px] text-slate-500">NetGSM REST v2: Basic Auth + JSON messages[] gövdesi kullanılır. Telefon +90 olmadan 905xxxxxxxxx biçiminde gönderilir.</p></div>}
            {smsConfig.provider === "twilio" && <div className="space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/50"><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">Account SID<input value={smsConfig.username || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, username: e.target.value }))} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Auth Token<input type="password" autoComplete="new-password" value={smsConfig.password || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, password: e.target.value }))} placeholder={smsConfig.password_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">Messaging Service SID <span className="font-normal text-slate-500">(opsiyonel)</span><input value={smsOptions.messaging_service_sid || ""} onChange={(e) => setSmsOption("messaging_service_sid", e.target.value)} placeholder="MG..." className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Status callback <span className="font-normal text-slate-500">(opsiyonel)</span><input value={smsOptions.status_callback || ""} onChange={(e) => setSmsOption("status_callback", e.target.value)} placeholder="https://..." className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div><p className="text-[11px] text-slate-500">From numarası veya Messaging Service SID kullanın; ikisini birlikte göndermiyoruz.</p></div>}
            {smsConfig.provider === "iletimerkezi" && <div className="space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/50"><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">API anahtarı<input type="password" autoComplete="new-password" value={smsConfig.api_key || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_key: e.target.value }))} placeholder={smsConfig.api_key_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label><label className="block text-sm font-medium">API hash<input type="password" autoComplete="new-password" value={smsConfig.api_secret || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_secret: e.target.value }))} placeholder={smsConfig.api_secret_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div><p className="text-[11px] text-slate-500">İleti Merkezi v1 nested JSON: authentication.key/hash + order.sender/message/receipents.number.</p></div>}
            {smsConfig.provider === "vatansms" && <div className="space-y-3 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/50"><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">VatanSMS API ID<input value={smsConfig.username || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, username: e.target.value }))} placeholder="API_ID" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label><label className="block text-sm font-medium">VatanSMS API anahtarı<input type="password" autoComplete="new-password" value={smsConfig.api_key || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_key: e.target.value }))} placeholder={smsConfig.api_key_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">Mesaj tipi<select value={smsOptions.message_type || "normal"} onChange={(e) => setSmsOption("message_type", e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950"><option value="normal">normal</option><option value="turkce">turkce</option><option value="unicode">unicode</option></select></label><label className="block text-sm font-medium">İçerik tipi<select value={smsOptions.message_content_type || "bilgi"} onChange={(e) => setSmsOption("message_content_type", e.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950"><option value="bilgi">bilgi</option><option value="reklam">reklam</option></select></label></div><p className="text-[11px] text-slate-500">VatanSMS REST: POST /api/v1/1toN, JSON api_id + api_key + phones[] sözleşmesi.</p></div>}
            {(smsConfig.provider === "muttl" || smsConfig.provider === "relateddigital") && <div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">API anahtarı<input type="password" autoComplete="new-password" value={smsConfig.api_key || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_key: e.target.value }))} placeholder={smsConfig.api_key_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label><label className="block text-sm font-medium">API URL (opsiyonel)<input value={smsConfig.http_url || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, http_url: e.target.value }))} placeholder="https://api..." className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div>}
            {smsConfig.provider === "http" && <div className="space-y-4 rounded-xl border border-indigo-100 bg-indigo-50/50 p-4 dark:border-indigo-900/40 dark:bg-indigo-950/20"><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">Gateway URL<input required value={smsConfig.http_url || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, http_url: e.target.value }))} placeholder="https://sms.example.com/send" className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Kimlik doğrulama<select value={smsOptions.auth_type || "bearer"} onChange={(e) => setSmsOption("auth_type", e.target.value)} className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950"><option value="bearer">Bearer token</option><option value="header">Header token</option><option value="basic">HTTP Basic</option><option value="body">Body alanları</option><option value="none">Yok</option></select></label></div><div className="grid gap-4 sm:grid-cols-3"><label className="block text-sm font-medium">HTTP metodu<select value={smsOptions.method || "POST"} onChange={(e) => setSmsOption("method", e.target.value)} className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950"><option value="POST">POST</option><option value="PUT">PUT</option><option value="PATCH">PATCH</option><option value="GET">GET</option></select></label><label className="block text-sm font-medium">Gövde formatı<select value={smsOptions.payload_format || "json"} onChange={(e) => setSmsOption("payload_format", e.target.value)} className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950"><option value="json">JSON</option><option value="form">Form URL encoded</option></select></label><label className="block text-sm font-medium">Auth header adı<input value={smsOptions.auth_header || ""} onChange={(e) => setSmsOption("auth_header", e.target.value)} placeholder="X-API-Key" className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950" /></label></div><div className="grid gap-4 sm:grid-cols-3"><label className="block text-sm font-medium">Alıcı alanı<input value={smsOptions.recipient_field || "to"} onChange={(e) => setSmsOption("recipient_field", e.target.value)} placeholder="messages.0.to" className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Mesaj alanı<input value={smsOptions.message_field || "message"} onChange={(e) => setSmsOption("message_field", e.target.value)} placeholder="message.text" className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Gönderici alanı<input value={smsOptions.sender_field || "sender"} onChange={(e) => setSmsOption("sender_field", e.target.value)} placeholder="sender" className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950" /></label></div><label className="block text-sm font-medium">JSON gövde şablonu <span className="font-normal text-slate-500">(opsiyonel)</span><textarea rows={4} value={smsOptions.body_template || smsConfig.http_template || ""} onChange={(e) => setSmsOption("body_template", e.target.value)} placeholder={'{"to":"{phone}","message":"{message}","sender":"{sender}"}'} className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 font-mono text-xs dark:border-indigo-900 dark:bg-slate-950" /><span className="mt-1 block text-[11px] font-normal text-slate-500">Yer tutucular: {"{phone}"}, {"{message}"}, {"{sender}"}. Nested alanlar için nokta kullanabilirsiniz.</span></label><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">Başarı alanı <span className="font-normal text-slate-500">(opsiyonel)</span><input value={smsOptions.success_path || ""} onChange={(e) => setSmsOption("success_path", e.target.value)} placeholder="status" className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Job ID alanı <span className="font-normal text-slate-500">(opsiyonel)</span><input value={smsOptions.job_id_path || ""} onChange={(e) => setSmsOption("job_id_path", e.target.value)} placeholder="data.id" className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950" /></label></div><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">Bearer token<input type="password" autoComplete="new-password" value={smsConfig.http_token || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, http_token: e.target.value }))} placeholder={smsConfig.http_token_configured ? "Değiştirmek için girin" : "Opsiyonel"} className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 text-sm dark:border-indigo-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Özel header JSON <span className="font-normal text-slate-500">(secret koymayın)</span><input value={smsOptions.headers_json || ""} onChange={(e) => { setSmsOption("headers_json", e.target.value); try { setSmsOption("headers", JSON.parse(e.target.value || "{}")); } catch { /* preview only */ } }} placeholder='{"X-Client":"hotspot"}' className="mt-1 w-full rounded-xl border border-indigo-200 bg-white px-3 py-2.5 font-mono text-xs dark:border-indigo-900 dark:bg-slate-950" /></label></div><p className="text-[11px] text-slate-500">Özel gateway için kimlik bilgileri üstteki şifreli alanlarda saklanır. Gönderimden önce örnek POST gövdesini test endpointiyle doğrulayın.</p></div>}
            {smsConfig.provider === "http" && smsOptions.auth_type === "basic" && <div className="grid gap-4 rounded-xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-900/50 dark:bg-amber-950/20 sm:grid-cols-2"><label className="block text-sm font-medium">Basic kullanıcı adı<input value={smsConfig.username || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, username: e.target.value }))} className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Basic şifre<input type="password" autoComplete="new-password" value={smsConfig.password || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, password: e.target.value }))} placeholder={smsConfig.password_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-900 dark:bg-slate-950" /></label></div>}
            {smsConfig.provider === "http" && smsOptions.auth_type === "body" && <div className="grid gap-4 rounded-xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-900/50 dark:bg-amber-950/20 sm:grid-cols-2"><label className="block text-sm font-medium">API key<input type="password" autoComplete="new-password" value={smsConfig.api_key || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_key: e.target.value }))} placeholder={smsConfig.api_key_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium">API secret / hash<input type="password" autoComplete="new-password" value={smsConfig.api_secret || ""} onChange={(e) => setSmsConfig((v: any) => ({ ...v, api_secret: e.target.value }))} placeholder={smsConfig.api_secret_configured ? "Değiştirmek için girin" : "••••••••"} className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium sm:col-span-2">API key alan yolu<input value={smsOptions.api_key_field || ""} onChange={(e) => setSmsOption("api_key_field", e.target.value)} placeholder="request.authentication.key" className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-900 dark:bg-slate-950" /></label><label className="block text-sm font-medium sm:col-span-2">API secret alan yolu<input value={smsOptions.api_secret_field || ""} onChange={(e) => setSmsOption("api_secret_field", e.target.value)} placeholder="request.authentication.hash" className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-900 dark:bg-slate-950" /></label></div>}
            <div className="flex flex-wrap items-center gap-2"><button type="button" onClick={handleSmsSave} disabled={testing} className="inline-flex items-center rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50"><Save className="mr-2 h-4 w-4" />SMS ayarlarını kaydet</button><span className="text-xs text-slate-500">Gizli bilgiler veritabanında şifreli saklanır.</span></div>
            <div className="border-t border-slate-100 pt-4 dark:border-slate-800"><div className="mb-2 flex items-center gap-2 text-sm font-semibold"><Send className="h-4 w-4 text-indigo-500" /> Test SMS'i</div><div className="grid gap-2 sm:grid-cols-[180px_minmax(0,1fr)_auto]"><input value={smsTestPhone} onChange={(e) => setSmsTestPhone(e.target.value)} placeholder="5XX XXX XX XX" className="rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /><input value={smsTestMessage} onChange={(e) => setSmsTestMessage(e.target.value)} maxLength={160} className="rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /><button type="button" onClick={handleSmsTest} disabled={testing || !smsTestPhone.trim()} className="inline-flex items-center justify-center rounded-xl border border-indigo-200 px-4 py-2.5 text-sm font-semibold text-indigo-600 hover:bg-indigo-50 disabled:opacity-50 dark:border-indigo-900 dark:hover:bg-indigo-950/30">{testing ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Activity className="mr-2 h-4 w-4" />}Gönder</button></div></div>
            {testResult && activeTab === "sms" && <div className={`rounded-xl border p-3 text-sm ${testResult.success ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-900 dark:bg-emerald-950/20 dark:text-emerald-300" : "border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900 dark:bg-rose-950/20 dark:text-rose-300"}`}><div className="flex items-start gap-2">{testResult.success ? <CheckCircle2 className="mt-0.5 h-4 w-4" /> : <XCircle className="mt-0.5 h-4 w-4" />}<span>{testResult.message}</span></div></div>}
          </div>
          <div className="space-y-4"><div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm"><h3 className="font-semibold border-b border-slate-100 pb-3 dark:border-slate-800">SMS çalışma durumu</h3><div className={`mt-4 rounded-xl p-4 text-sm ${smsStatus?.configured ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-300" : "bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-300"}`}>{smsStatus?.configured ? "Gerçek SMS sağlayıcısı etkin." : "Demo modu etkin: OTP kodu sunucu loguna yazılır."}</div><div className="mt-4 space-y-3 text-sm"><div className="flex justify-between"><span className="text-slate-500">Kaynak</span><span className="font-semibold">{smsConfig.source === "database" ? "Panel ayarı" : "Ortam değişkeni"}</span></div><div className="flex justify-between"><span className="text-slate-500">Sağlayıcı</span><span className="font-semibold">{smsStatus?.provider || smsConfig.provider || "console"}</span></div><div className="flex justify-between"><span className="text-slate-500">Kod / süre</span><span className="font-semibold">{smsStatus?.otp_length || 6} hane · {Math.round((smsStatus?.otp_ttl_seconds || 180) / 60)} dk</span></div><div className="flex justify-between"><span className="text-slate-500">Deneme sınırı</span><span className="font-semibold">{smsStatus?.max_attempts || 3}</span></div></div></div><div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 text-xs leading-5 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400"><strong className="mb-1 block text-slate-800 dark:text-slate-200">Kurulum akışı</strong>1. Sağlayıcı hesabından API bilgilerini alın.<br />2. Bu formda kaydedin ve test SMS'i gönderin.<br />3. Portal SMS yöntemi etkin olduğunda her doğrulama 5651 için telefon, IP, MAC ve lokasyonla ilişkilendirilir.</div></div>
        </div>
      )}

      {activeTab === "vpn" && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-indigo-200 bg-indigo-50/70 p-5 dark:border-indigo-900/50 dark:bg-indigo-950/20">
            <div className="flex items-start gap-3"><ShieldCheck className="mt-0.5 h-5 w-5 text-indigo-600 dark:text-indigo-400" /><div><h3 className="font-semibold text-indigo-950 dark:text-indigo-100">FortiGate RADIUS + VPN MFA</h3><p className="mt-1 text-sm leading-6 text-indigo-900/70 dark:text-indigo-200/70">Aynı RADIUS bağlantısı captive portal kurumsal girişinde ve FortiGate VPN MFA akışında kullanılabilir. FortiGate, FreeRADIUS üzerinden kullanıcı adı/şifreyi; VPN’de ise Access-Challenge ile TOTP, SMS veya e-posta kodunu doğrular.</p></div></div>
          </div>
          <div className="space-y-6">
            <div className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800"><div><h3 className="font-semibold">VPN MFA politikası</h3><p className="mt-1 text-xs text-slate-500">FortiGate SSL-VPN / IPsec için ortak ikinci faktör.</p></div><label className="inline-flex items-center gap-2 text-xs font-semibold"><input type="checkbox" checked={Boolean(vpnConfig.is_enabled)} onChange={(e) => setVpnConfig((v: any) => ({ ...v, is_enabled: e.target.checked }))} className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500" /> Etkin</label></div>
              <label className="block text-sm font-medium">İkinci faktör yöntemi<select value={vpnConfig.mfa_method || "totp"} onChange={(e) => setVpnConfig((v: any) => ({ ...v, mfa_method: e.target.value }))} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950"><option value="totp">Authenticator uygulaması (TOTP)</option><option value="sms">SMS OTP</option><option value="email">E-posta OTP</option></select></label>
              <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_110px]"><label className="block text-sm font-medium">FreeRADIUS sunucu adresi<input value={vpnConfig.gateway_host || ""} onChange={(e) => setVpnConfig((v: any) => ({ ...v, gateway_host: e.target.value }))} placeholder="radius.example.local" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /><span className="mt-1 block text-[11px] font-normal text-slate-500">FortiGate’in bağlanacağı RADIUS listener adresi</span></label><label className="block text-sm font-medium">Auth port<input type="number" value={vpnConfig.gateway_port || 1812} onChange={(e) => setVpnConfig((v: any) => ({ ...v, gateway_port: Number(e.target.value) }))} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div>
              <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-4 dark:border-amber-900/50 dark:bg-amber-950/20"><div className="mb-3 flex items-center justify-between"><div><h4 className="text-sm font-semibold text-amber-950 dark:text-amber-100">FortiGate RADIUS istemcisi</h4><p className="mt-1 text-xs text-amber-900/70 dark:text-amber-200/70">FortiGate’te tanımladığınız shared secret ile aynı olmalıdır. Secret veritabanında şifreli tutulur ve tekrar gösterilmez.</p></div><span className={`rounded-full px-2 py-1 text-[11px] font-semibold ${vpnConfig.radius_secret_configured ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300" : "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300"}`}>{vpnConfig.radius_secret_configured ? "Secret kayıtlı" : "Secret eksik"}</span></div><div className="grid gap-3 sm:grid-cols-2"><label className="block text-sm font-medium text-amber-950 dark:text-amber-100">FortiGate/NAS IP<input value={vpnConfig.radius_nas_ip || ""} onChange={(e) => setVpnConfig((v: any) => ({ ...v, radius_nas_ip: e.target.value }))} placeholder="10.0.0.1" className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-800 dark:bg-slate-950" /></label><label className="block text-sm font-medium text-amber-950 dark:text-amber-100">Shared secret<input type="password" autoComplete="new-password" value={vpnConfig.radius_shared_secret || ""} onChange={(e) => setVpnConfig((v: any) => ({ ...v, radius_shared_secret: e.target.value }))} placeholder={vpnConfig.radius_secret_configured ? "Değiştirmek için girin" : "FortiGate RADIUS şifresi"} className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-800 dark:bg-slate-950" /></label></div><label className="mt-3 block max-w-[180px] text-sm font-medium text-amber-950 dark:text-amber-100">Accounting port<input type="number" value={vpnConfig.radius_accounting_port || 1813} onChange={(e) => setVpnConfig((v: any) => ({ ...v, radius_accounting_port: Number(e.target.value) }))} className="mt-1 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm dark:border-amber-800 dark:bg-slate-950" /></label></div>
              <div className="flex flex-wrap gap-2"><button type="button" onClick={handleVpnSave} disabled={vpnBusy} className="inline-flex items-center rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50"><Save className="mr-2 h-4 w-4" />Politikayı kaydet</button><button type="button" onClick={handleVpnRadiusTest} disabled={vpnBusy || !vpnConfig.radius_secret_configured} className="inline-flex items-center rounded-xl border border-emerald-200 px-4 py-2.5 text-sm font-semibold text-emerald-700 hover:bg-emerald-50 disabled:opacity-50 dark:border-emerald-900 dark:text-emerald-300 dark:hover:bg-emerald-950/30"><Activity className="mr-2 h-4 w-4" />RADIUS bağlantısını test et</button><button type="button" onClick={handleGenerateVpnSnippet} disabled={vpnBusy || !vpnConfig.is_enabled} className="inline-flex items-center rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-800 dark:text-slate-200 dark:hover:bg-slate-800"><Server className="mr-2 h-4 w-4" />FreeRADIUS metni üret</button></div>
              {testResult && activeTab === "vpn" && <div className={`rounded-xl border p-3 text-sm ${testResult.ok || testResult.success ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-900 dark:bg-emerald-950/20 dark:text-emerald-300" : "border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900 dark:bg-rose-950/20 dark:text-rose-300"}`}>{testResult.message || (testResult.ok ? "Başarılı" : "İşlem başarısız")}</div>}
              {vpnSnippet && <div className="relative"><button type="button" onClick={() => navigator.clipboard?.writeText(vpnSnippet)} className="absolute right-2 top-2 rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white" title="Kopyala"><Copy className="h-4 w-4" /></button><pre className="max-h-56 overflow-auto rounded-xl bg-slate-950 p-4 pr-10 text-[11px] leading-5 text-emerald-300">{vpnSnippet}</pre></div>}
            </div>
          </div>
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-col gap-4 border-b border-slate-100 px-5 py-4 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <div>
                <div className="flex items-center gap-2"><Users className="h-4 w-4 text-indigo-500" /><h3 className="font-semibold text-slate-900 dark:text-slate-100">VPN MFA kayıtları</h3><span className="rounded-full bg-indigo-50 px-2 py-0.5 text-[11px] font-bold text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300">{vpnUsers.length}</span></div>
                <p className="mt-1 max-w-2xl text-xs leading-5 text-slate-500">Bu liste FortiGate’ten çekilen kullanıcı listesi değildir; RADIUS’ta bulunan kullanıcılara hangi ikinci faktörün atanacağını gösteren güvenli MFA kayıtlarıdır.</p>
              </div>
              <button type="button" onClick={() => setShowVpnUserForm((value) => !value)} className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm transition hover:bg-indigo-700"><Plus className="h-3.5 w-3.5" /> {showVpnUserForm ? "Formu kapat" : "VPN kullanıcısı ekle"}</button>
            </div>
            <div className="grid grid-cols-3 gap-3 border-b border-slate-100 p-5 dark:border-slate-800 sm:px-6">
              <div className="rounded-xl border border-slate-100 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950/50"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Toplam</div><div className="mt-1 text-xl font-bold text-slate-900 dark:text-slate-100">{vpnUsers.length}</div></div>
              <div className="rounded-xl border border-slate-100 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950/50"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">TOTP</div><div className="mt-1 text-xl font-bold text-indigo-600 dark:text-indigo-400">{vpnUsers.filter((item) => item.mfa_method === "totp").length}</div></div>
              <div className="rounded-xl border border-slate-100 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950/50"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">SMS / e-posta</div><div className="mt-1 text-xl font-bold text-emerald-600 dark:text-emerald-400">{vpnUsers.filter((item) => item.mfa_method !== "totp").length}</div></div>
            </div>
            <div className="flex flex-col gap-2 border-b border-slate-100 p-5 dark:border-slate-800 sm:flex-row sm:items-center sm:px-6">
              <div className="relative min-w-0 flex-1"><Users className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" /><input value={vpnUserQuery} onChange={(event) => setVpnUserQuery(event.target.value)} placeholder="Kullanıcı adı, telefon veya e-posta ara" className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm outline-none transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-800 dark:bg-slate-950" /></div>
              <select value={vpnUserMethod} onChange={(event) => setVpnUserMethod(event.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950"><option value="all">Tüm yöntemler</option><option value="totp">Authenticator (TOTP)</option><option value="sms">SMS OTP</option><option value="email">E-posta OTP</option></select>
              <button type="button" onClick={handleVpnUsersRefresh} disabled={vpnBusy} className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-50 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800"><RefreshCw className={`h-3.5 w-3.5 ${vpnBusy ? "animate-spin" : ""}`} /> Yenile</button>
            </div>
            {showVpnUserForm && <form onSubmit={handleVpnUserSave} className="grid gap-3 border-b border-indigo-100 bg-indigo-50/40 p-5 dark:border-indigo-900/30 dark:bg-indigo-950/10 sm:grid-cols-2 sm:p-6">
              <div className="sm:col-span-2"><div className="mb-1 text-xs font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">Yeni MFA eşlemesi</div><p className="text-xs text-slate-500">Kullanıcının FortiGate/RADIUS hesabı önceden mevcut olmalı. Burada yalnızca ikinci faktör kaydını oluşturuyoruz.</p></div>
              <label className="block text-sm font-medium">FortiGate kullanıcı adı<input required value={vpnUserForm.username} onChange={(event) => setVpnUserForm((value) => ({ ...value, username: event.target.value }))} placeholder="alice.vpn" className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
              <label className="block text-sm font-medium">MFA yöntemi<select value={vpnUserForm.mfa_method} onChange={(event) => setVpnUserForm((value) => ({ ...value, mfa_method: event.target.value }))} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950"><option value="totp">Authenticator uygulaması (TOTP)</option><option value="sms">SMS OTP</option><option value="email">E-posta OTP</option></select></label>
              <label className="block text-sm font-medium sm:col-span-2">{vpnUserForm.mfa_method === "totp" ? "TOTP secret" : vpnUserForm.mfa_method === "sms" ? "Telefon numarası" : "E-posta adresi"}<div className="mt-1 flex gap-2"><input value={vpnUserForm.mfa_method === "totp" ? vpnUserForm.secret : vpnUserForm.mfa_method === "sms" ? vpnUserForm.phone : vpnUserForm.email} onChange={(event) => setVpnUserForm((value) => value.mfa_method === "totp" ? { ...value, secret: event.target.value } : value.mfa_method === "sms" ? { ...value, phone: event.target.value } : { ...value, email: event.target.value })} placeholder={vpnUserForm.mfa_method === "totp" ? "Base32 secret" : vpnUserForm.mfa_method === "sms" ? "+905..." : "user@example.com"} className="min-w-0 flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" />{vpnUserForm.mfa_method === "totp" && <button type="button" onClick={() => setVpnUserForm((value) => ({ ...value, secret: generateTotpSecret() }))} className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300"><RefreshCw className="h-3.5 w-3.5" /> Üret</button>}</div></label>
              <div className="flex items-center justify-end gap-2 sm:col-span-2"><button type="button" onClick={() => setShowVpnUserForm(false)} className="rounded-xl border border-slate-200 px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-white dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-900">İptal</button><button type="submit" disabled={vpnBusy} className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-700 disabled:opacity-50"><Plus className="h-3.5 w-3.5" /> Kaydı oluştur</button></div>
            </form>}
            <div className="overflow-x-auto"><table className="w-full min-w-[700px] text-left text-sm"><thead><tr className="border-b border-slate-200 bg-slate-50/60 text-[10px] uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-950/40"><th className="px-5 py-3 font-semibold sm:px-6">Kullanıcı</th><th className="px-3 py-3 font-semibold">İkinci faktör</th><th className="px-3 py-3 font-semibold">Hedef / iletişim</th><th className="px-3 py-3 font-semibold">Durum</th><th className="px-5 py-3 text-right font-semibold sm:px-6">İşlem</th></tr></thead><tbody className="divide-y divide-slate-100 dark:divide-slate-800">{filteredVpnUsers.map((item) => <tr key={item.id} className="transition hover:bg-slate-50/60 dark:hover:bg-slate-800/30"><td className="px-5 py-3 sm:px-6"><div className="flex items-center gap-3"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-300"><Users className="h-4 w-4" /></div><div><div className="font-semibold text-slate-900 dark:text-slate-100">{item.username}</div><div className="mt-0.5 text-[10px] text-slate-500">RADIUS kullanıcı adı</div></div></div></td><td className="px-3 py-3"><span className="inline-flex rounded-full bg-indigo-50 px-2.5 py-1 text-[11px] font-semibold text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300">{vpnMethodLabel(item.mfa_method)}</span></td><td className="px-3 py-3 text-xs text-slate-500">{item.mfa_method === "sms" ? maskContact(item.phone) : item.mfa_method === "email" ? maskContact(item.email) : <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400"><ShieldCheck className="h-3.5 w-3.5" /> Secret şifreli</span>}</td><td className="px-3 py-3"><span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-100 bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 dark:border-emerald-900/40 dark:bg-emerald-950/30 dark:text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Aktif</span></td><td className="px-5 py-3 text-right sm:px-6"><button type="button" onClick={() => handleVpnUserDelete(item.id)} className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-rose-600 transition hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/30"><Trash2 className="h-3.5 w-3.5" /> Kaldır</button></td></tr>)}{!filteredVpnUsers.length && <tr><td colSpan={5} className="px-5 py-12 text-center text-sm text-slate-500 sm:px-6">{vpnUsers.length ? "Aramanızla eşleşen VPN MFA kaydı yok." : "Henüz VPN MFA kaydı yok. İlk kaydı oluşturarak başlayın."}</td></tr>}</tbody></table></div>
          </div>
          <div className="grid gap-3 text-xs text-slate-500 md:grid-cols-3"><div className="rounded-xl border border-slate-200 p-3 dark:border-slate-800"><KeyRound className="mb-2 h-4 w-4 text-indigo-500" /><strong className="block text-slate-700 dark:text-slate-200">1. FortiGate</strong> RADIUS sunucusunu bu kurulumun adresiyle tanımlayın.</div><div className="rounded-xl border border-slate-200 p-3 dark:border-slate-800"><Server className="mb-2 h-4 w-4 text-indigo-500" /><strong className="block text-slate-700 dark:text-slate-200">2. FreeRADIUS</strong> Üretilen REST Access-Challenge metnini etkinleştirin.</div><div className="rounded-xl border border-slate-200 p-3 dark:border-slate-800"><ShieldCheck className="mb-2 h-4 w-4 text-indigo-500" /><strong className="block text-slate-700 dark:text-slate-200">3. Kullanıcı</strong> Her VPN kullanıcısına ikinci faktör yöntemi atayın.</div></div>
        </div>
      )}

      {activeTab === "whatsapp" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <MessageCircle className="w-4 h-4 mr-2 text-indigo-500" /> WhatsApp Cloud API Yapılandırması
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">API Token</label>
              <input type="password" value={config.whatsapp?.api_token || ""} onChange={(e) => setConfig({ ...config, whatsapp: { ...config.whatsapp, api_token: e.target.value } })}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Phone Number ID</label>
                <input type="text" value={config.whatsapp?.phone_number_id || ""} onChange={(e) => setConfig({ ...config, whatsapp: { ...config.whatsapp, phone_number_id: e.target.value } })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Business Account ID</label>
                <input type="text" value={config.whatsapp?.business_account_id || ""} onChange={(e) => setConfig({ ...config, whatsapp: { ...config.whatsapp, business_account_id: e.target.value } })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button onClick={handleWaSave} className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold"><Save className="w-4 h-4 mr-2" /> Kaydet</button>
              <div className="flex-1 flex items-center gap-2">
                <input type="text" value={waTestPhone} onChange={(e) => setWaTestPhone(e.target.value)} placeholder="+905321112233"
                  className="flex-1 px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                <button onClick={handleWaTest} disabled={testing || !waTestPhone}
                  className="inline-flex items-center px-3 py-2 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl text-sm font-semibold disabled:opacity-50">
                  {testing ? <RefreshCw className="w-4 h-4 mr-1.5 animate-spin" /> : <Send className="w-4 h-4 mr-1.5" />} Test Gönder
                </button>
              </div>
            </div>
            {testResult && (
              <div className={`p-3 rounded-xl text-sm font-medium flex items-start space-x-2 ${testResult.success ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800" : "bg-rose-50 dark:bg-rose-950/20 text-rose-800"} border`}>
                {testResult.success ? <CheckCircle2 className="w-4 h-4 mt-0.5" /> : <XCircle className="w-4 h-4 mt-0.5" />}
                <span>{testResult.message}</span>
              </div>
            )}
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">WhatsApp Durumu</h3>
            <div className="space-y-3 mt-3">
              <div className="flex justify-between text-sm"><span className="text-slate-500">Yapılandırma</span>
                <span className={`font-semibold ${config.whatsapp?.is_configured ? "text-emerald-600" : "text-amber-600"}`}>{config.whatsapp?.is_configured ? "Tamamlandı" : "Eksik"}</span>
              </div>
              <div className="flex justify-between text-sm"><span className="text-slate-500">Phone ID</span><span className="text-xs font-mono">{config.whatsapp?.phone_number_id || "-"}</span></div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "ldap" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Server className="w-4 h-4 mr-2 text-indigo-500" /> LDAP Yapılandırması
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Sunucu URL</label>
              <input type="text" value={config.ldap?.server_url || ""} onChange={(e) => setConfig({ ...config, ldap: { ...config.ldap, server_url: e.target.value } })} placeholder="ldap://dc01.hotspot.local:389"
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Bind DN</label>
              <input type="text" value={config.ldap?.bind_dn || ""} onChange={(e) => setConfig({ ...config, ldap: { ...config.ldap, bind_dn: e.target.value } })} placeholder="cn=admin,dc=hotspot,dc=local"
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Bind Şifresi</label>
                <input type="password" value={config.ldap?.bind_password || ""} onChange={(e) => setConfig({ ...config, ldap: { ...config.ldap, bind_password: e.target.value } })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Base DN</label>
                <input type="text" value={config.ldap?.base_dn || ""} onChange={(e) => setConfig({ ...config, ldap: { ...config.ldap, base_dn: e.target.value } })} placeholder="ou=users,dc=hotspot,dc=local"
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Arama Filtresi</label>
              <input type="text" value={config.ldap?.search_filter || ""} onChange={(e) => setConfig({ ...config, ldap: { ...config.ldap, search_filter: e.target.value } })} placeholder="(objectClass=person)"
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div className="flex items-center gap-3">
              <button onClick={handleLdapSave} className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold"><Save className="w-4 h-4 mr-2" /> Kaydet</button>
              <button onClick={handleLdapTest} disabled={testing}
                className="inline-flex items-center px-4 py-2 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl text-sm font-semibold disabled:opacity-50">
                {testing ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Activity className="w-4 h-4 mr-2" />} Bağlantıyı Test Et
              </button>
            </div>
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">LDAP Durumu</h3>
            <div className="space-y-3 mt-3">
              <div className="flex justify-between text-sm"><span className="text-slate-500">Yapılandırma</span>
                <span className={`font-semibold ${config.ldap?.is_configured ? "text-emerald-600" : "text-amber-600"}`}>{config.ldap?.is_configured ? "Tamamlandı" : "Eksik"}</span>
              </div>
              <div className="flex justify-between text-sm"><span className="text-slate-500">Sunucu</span><span className="text-xs font-mono">{config.ldap?.server_url || "-"}</span></div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "meeting" && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button onClick={() => { setCodeForm({ code: "", event_name: "", max_uses: 50, duration_minutes: 480, expires_at: new Date(Date.now() + 86400000 * 30).toISOString().slice(0, 16) }); setShowCodeModal(true); }}
              className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors">
              <Plus className="w-4 h-4 mr-2" /> Yeni Toplantı Kodu
            </button>
          </div>
          <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Kod</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Etkinlik</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Maks. Kullanım</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Kullanılan</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Süre (dk)</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Son Geçerlilik</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {meetingCodes.map(c => (
                    <tr key={c.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                      <td className="px-6 py-4 text-sm font-mono font-bold text-indigo-600 dark:text-indigo-400">{c.code}</td>
                      <td className="px-6 py-4 text-sm text-slate-800 dark:text-slate-200">{c.event_name}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">{c.max_uses}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">{c.used_count}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">{c.duration_minutes}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">{new Date(c.expires_at).toLocaleDateString("tr-TR")}</td>
                      <td className="px-6 py-4 text-right">
                        <button onClick={() => handleCodeDelete(c.id)} className="inline-flex items-center p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </td>
                    </tr>
                  ))}
                  {meetingCodes.length === 0 && <tr><td colSpan={7} className="px-6 py-12 text-center text-slate-500">Henüz toplantı kodu oluşturulmamış.</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === "users" && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <button onClick={openUserCreate} className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors">
              <Plus className="w-4 h-4 mr-2" /> Yeni Kullanıcı
            </button>
          </div>
          <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Kullanıcı Adı</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Ad Soyad</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">E-Posta</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Telefon</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Rol</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Durum</th>
                    <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {localUsers.map(u => (
                    <tr key={u.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                      <td className="px-6 py-4 text-sm font-medium text-slate-900 dark:text-slate-100">{u.username}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">{u.display_name}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">{u.email || "-"}</td>
                      <td className="px-6 py-4 text-sm text-slate-500">{u.phone || "-"}</td>
                      <td className="px-6 py-4 text-sm">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">{u.role}</span>
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${u.is_active ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100" : "bg-slate-100 dark:bg-slate-800 text-slate-500 border-slate-200"}`}>
                          {u.is_active ? "Aktif" : "Pasif"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right space-x-1">
                        <button onClick={() => openUserEdit(u)} className="inline-flex items-center p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl transition-colors"><Edit3 className="w-4 h-4" /></button>
                        <button onClick={() => handleUserDelete(u.id)} className="inline-flex items-center p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </td>
                    </tr>
                  ))}
                  {localUsers.length === 0 && <tr><td colSpan={7} className="px-6 py-12 text-center text-slate-500">Henüz yerel kullanıcı yok.</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {showCodeModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowCodeModal(false)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 w-full max-w-md p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Yeni Toplantı Kodu</h3>
            <form onSubmit={handleCodeSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Kod</label>
                  <input type="text" required value={codeForm.code} onChange={(e) => setCodeForm({ ...codeForm, code: e.target.value.toUpperCase() })} placeholder="TOPLANTI2026"
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Etkinlik Adı</label>
                  <input type="text" required value={codeForm.event_name} onChange={(e) => setCodeForm({ ...codeForm, event_name: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Maks. Kullanım</label>
                  <input type="number" value={codeForm.max_uses} onChange={(e) => setCodeForm({ ...codeForm, max_uses: Number(e.target.value) })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Süre (dk)</label>
                  <input type="number" value={codeForm.duration_minutes} onChange={(e) => setCodeForm({ ...codeForm, duration_minutes: Number(e.target.value) })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Son Geçerlilik Tarihi</label>
                <input type="datetime-local" required value={codeForm.expires_at} onChange={(e) => setCodeForm({ ...codeForm, expires_at: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="flex justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowCodeModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800">İptal</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold">Oluştur</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showUserModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowUserModal(false)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 w-full max-w-md p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">{editingUser ? "Kullanıcı Düzenle" : "Yeni Kullanıcı"}</h3>
            <form onSubmit={handleUserSave} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Kullanıcı Adı</label>
                <input type="text" required value={userForm.username} onChange={(e) => setUserForm({ ...userForm, username: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">{editingUser ? "Yeni Şifre (boş bırakılırsa değişmez)" : "Şifre"}</label>
                <input type="password" value={userForm.password} onChange={(e) => setUserForm({ ...userForm, password: e.target.value })} required={!editingUser}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Ad Soyad</label>
                <input type="text" value={userForm.display_name} onChange={(e) => setUserForm({ ...userForm, display_name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">E-Posta</label>
                  <input type="email" value={userForm.email} onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Telefon</label>
                  <input type="text" value={userForm.phone} onChange={(e) => setUserForm({ ...userForm, phone: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Rol</label>
                <select value={userForm.role} onChange={(e) => setUserForm({ ...userForm, role: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="guest">Misafir</option>
                  <option value="operator">Operatör</option>
                  <option value="admin">Yönetici</option>
                </select>
              </div>
              <div className="flex justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowUserModal(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800">İptal</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold">{editingUser ? "Güncelle" : "Oluştur"}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {testResult && activeTab !== "whatsapp" && activeTab !== "ldap" && null}
    </div>
  );
};
