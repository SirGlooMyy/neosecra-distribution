import React, { useState, useCallback, useRef, useEffect } from 'react';
import { LogsToolbar } from '../components/logs/LogsToolbar';
import { LogsFilterPanel } from '../components/logs/LogsFilterPanel';
import { LogsFacets } from '../components/logs/LogsFacets';
import { LogsTable } from '../components/logs/LogsTable';
import { LogHistogram } from '../components/logs/LogHistogram';
import { CorrelateModal } from '../components/logs/CorrelateModal';
import {
  searchLogs,
  getFacets,
  correlateSession,
  exportLogs,
  listSavedSearches,
  createSavedSearch,
  deleteSavedSearch,
} from '../api/logs';
import { getCurrentScope } from '../lib/api';
import type {
  SearchFilters,
  FirewallLog,
  FacetResult,
  CorrelateResult,
  TimeWindow,
  SearchView,
  LogType,
} from '../types/logs';
import { Bookmark, X, Save, ShieldAlert, Ban, Users, Activity, SlidersHorizontal, RotateCcw } from 'lucide-react';

const DEFAULT_FILTERS: SearchFilters = {
  time_window: '24h',
  vendor: 'fortigate',
  page: 1,
  page_size: 50,
};

export const LogsSearch: React.FC = () => {
  const [filters, setFilters] = useState<SearchFilters>(DEFAULT_FILTERS);
  // Preserve quick searches launched from the dashboard (e.g. /logs/search?q=1.2.3.4).
  // Reading the value lazily avoids touching window during the initial render in
  // non-browser tooling while still pre-populating the toolbar before the first
  // automatic search runs.
  const [q, setQ] = useState(
    () => (typeof window === 'undefined' ? '' : new URLSearchParams(window.location.search).get('q') || ''),
  );
  const [timeWindow, setTimeWindow] = useState<TimeWindow>('24h');
  const [fromDate, setFromDate] = useState<string>('');
  const [toDate, setToDate] = useState<string>('');

  const [logs, setLogs] = useState<FirewallLog[]>([]);
  const [total, setTotal] = useState(0);
  const [hasNext, setHasNext] = useState(false);
  const [loading, setLoading] = useState(false);
  const [facetLoading, setFacetLoading] = useState(false);
  const [facets, setFacets] = useState<FacetResult | null>(null);
  const [selectedLog, setSelectedLog] = useState<FirewallLog | null>(null);

  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [tenantName, setTenantName] = useState<string | null>(null);
  const [correlateOpen, setCorrelateOpen] = useState(false);
  const [correlateSessionId, setCorrelateSessionId] = useState<string | null>(null);
  const [correlateResult, setCorrelateResult] = useState<CorrelateResult | null>(null);
  const [correlateLoading, setCorrelateLoading] = useState(false);

  // Saved Searches
  const [savedSearches, setSavedSearches] = useState<SearchView[]>([]);
  const [saveModalOpen, setSaveModalOpen] = useState(false);
  const [newSearchName, setNewSearchName] = useState('');
  const [savingSearch, setSavingSearch] = useState(false);

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchSavedSearches = useCallback(async () => {
    try {
      const res = await listSavedSearches('firewall_logs');
      if (Array.isArray(res)) {
        setSavedSearches(res);
      }
    } catch {
      // silent
    }
  }, []);

  useEffect(() => {
    getCurrentScope().then((scope) => {
      if (scope?.tenant_id) setTenantName(scope.tenant_id);
    });
    fetchSavedSearches();
  }, [fetchSavedSearches]);

  const buildFilters = useCallback(
    (page = 1): SearchFilters => ({
      ...filters,
      q: q || undefined,
      time_window: timeWindow,
      from: timeWindow === 'custom' && fromDate ? fromDate : undefined,
      to: timeWindow === 'custom' && toDate ? toDate : undefined,
      page,
      page_size: 50,
    }),
    [filters, q, timeWindow, fromDate, toDate],
  );

  const doSearch = useCallback(
    async (page = 1, override?: Partial<SearchFilters>) => {
      setLoading(true);
      setError(null);
      try {
        const f = { ...buildFilters(page), ...override, page };
        const result = await searchLogs(f);
        if (page === 1) {
          setLogs(result.items);
        } else {
          setLogs((prev) => [...prev, ...result.items]);
        }
        setTotal(result.total);
        setHasNext(result.has_next);
        setFilters((prev) => ({ ...prev, page }));
      } catch (err: any) {
        setError(err.message || 'Arama başarısız');
      } finally {
        setLoading(false);
      }
    },
    [buildFilters],
  );

  const doFacets = useCallback(async (override?: Partial<SearchFilters>) => {
    setFacetLoading(true);
    try {
      const result = await getFacets({ ...buildFilters(1), ...override, page: 1 });
      setFacets(result);
    } catch {
      // silent
    } finally {
      setFacetLoading(false);
    }
  }, [buildFilters]);

  const handleSearch = useCallback((override?: Partial<SearchFilters>) => {
    setLogs([]);
    doSearch(1, override);
    doFacets(override);
  }, [doSearch, doFacets]);

  // Auto-load last 24h on mount
  useEffect(() => {
    handleSearch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleFilterApply = useCallback(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      handleSearch();
    }, 300);
  }, [handleSearch]);

  const handleFilterClear = useCallback(() => {
    setFilters(DEFAULT_FILTERS);
    setQ('');
    setTimeWindow('24h');
    setFromDate('');
    setToDate('');
    setLogs([]);
    setFacets(null);
    setTotal(0);
    setHasNext(false);
    setError(null);
    setSelectedLog(null);
  }, []);

  const applyQuickFilter = useCallback((kind: string) => {
    const next: SearchFilters = { ...DEFAULT_FILTERS };
    if (kind === 'critical') next.severity = ['critical', 'alert', 'emergency'];
    if (kind === 'blocked') next.action = ['deny', 'block', 'blocked', 'timeout'];
    if (kind === 'vpn') next.log_type = ['vpn'];
    if (kind === 'admin') { next.log_type = ['event']; setQ('admin'); }
    else setQ('');
    if (kind === 'last15') setTimeWindow('15m'); else setTimeWindow('24h');
    setFilters(next);
    handleSearch({ ...next, q: kind === 'admin' ? 'admin' : undefined, time_window: kind === 'last15' ? '15m' : '24h' });
  }, [handleSearch]);

  const handleFacetClick = useCallback(
    (facetKey: keyof FacetResult, value: string) => {
      const next = { ...filters };
        if (facetKey === 'vendor') {
          next.vendor = value;
        } else if (facetKey === 'severity') {
          const current = next.severity || [];
          next.severity = current.includes(value) ? current.filter((x) => x !== value) : [...current, value];
        } else if (facetKey === 'log_type') {
          const current = next.log_type || [];
          const ltValue = value as LogType;
          next.log_type = current.includes(ltValue) ? current.filter((x) => x !== ltValue) : [...current, ltValue];
        } else if (facetKey === 'action') {
          const current = next.action || [];
          next.action = current.includes(value) ? current.filter((x) => x !== value) : [...current, value];
        } else if (facetKey === 'src_ip') {
          next.src_ip = next.src_ip === value ? undefined : value;
        } else if (facetKey === 'dst_ip') {
          next.dst_ip = next.dst_ip === value ? undefined : value;
        } else if (facetKey === 'user') {
          next.user = next.user === value ? undefined : value;
        }
      setFilters(next);
      handleSearch(next);
    },
    [filters, handleSearch],
  );

  const handleBucketClick = useCallback(
    (bucketFrom: string, bucketTo: string) => {
      setTimeWindow('custom');
      setFromDate(bucketFrom);
      setToDate(bucketTo);
      setTimeout(() => handleSearch(), 50);
    },
    [handleSearch],
  );

  const handleLoadMore = useCallback(() => {
    const nextPage = (filters.page || 1) + 1;
    doSearch(nextPage);
  }, [filters.page, doSearch]);

  const handleExport = useCallback(async () => {
    setExporting(true);
    try {
      const { blob, filename } = await exportLogs(buildFilters(1), 'csv');
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
    } catch (err: any) {
      setError(err.message || 'Dışa aktarma başarısız');
    } finally {
      setExporting(false);
    }
  }, [buildFilters]);

  const handleCorrelate = useCallback(async (sessionId: string) => {
    setCorrelateSessionId(sessionId);
    setCorrelateOpen(true);
    setCorrelateLoading(true);
    setCorrelateResult(null);
    try {
      const result = await correlateSession(sessionId);
      setCorrelateResult(result);
    } catch {
      setCorrelateResult(null);
    } finally {
      setCorrelateLoading(false);
    }
  }, []);

  const handleSaveSearchSubmit = useCallback(async () => {
    if (!newSearchName.trim()) return;
    setSavingSearch(true);
    try {
      const activeFilters = buildFilters(1);
      await createSavedSearch(newSearchName.trim(), activeFilters, 'firewall_logs');
      setNewSearchName('');
      setSaveModalOpen(false);
      await fetchSavedSearches();
    } catch (err: any) {
      setError(err.message || 'Arama kaydetme başarısız');
    } finally {
      setSavingSearch(false);
    }
  }, [newSearchName, buildFilters, fetchSavedSearches]);

  const handleSelectSavedSearch = useCallback(
    (sv: SearchView) => {
      const qObj = (sv.query || {}) as SearchFilters;
      setFilters(qObj);
      if (qObj.q) setQ(qObj.q);
      if (qObj.time_window) setTimeWindow(qObj.time_window);
      if (qObj.from) setFromDate(qObj.from);
      if (qObj.to) setToDate(qObj.to);
      setTimeout(() => handleSearch(), 50);
    },
    [handleSearch],
  );

  return (
    <div className="space-y-5 pb-8">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 px-6 py-6 text-white shadow-xl shadow-indigo-950/20">
        <div className="absolute -right-16 -top-24 h-64 w-64 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="relative flex flex-wrap items-start justify-between gap-5">
          <div>
            <div className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-indigo-300"><Activity className="h-3.5 w-3.5" /> Firewall Analyzer</div>
            <h2 className="text-2xl font-bold tracking-tight">Güvenlik olaylarını araştırın</h2>
            <p className="mt-1 max-w-xl text-sm text-slate-300">FortiGate trafik, VPN, UTM ve kimlik olaylarını tek bir zaman çizgisinde korele edin.</p>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1.5 text-xs font-medium text-emerald-300"><span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" /> Canlı veri akışı</div>
        </div>
        <div className="relative mt-5 flex flex-wrap gap-2">
          {[['all', 'Tüm olaylar'], ['critical', 'Kritik olaylar'], ['blocked', 'Engellenenler'], ['vpn', 'VPN'], ['last15', 'Son 15 dakika'], ['admin', 'Yönetici olayları']].map(([key, label]) => (
            <button key={key} onClick={() => applyQuickFilter(key)} className="rounded-full border border-white/15 bg-white/10 px-3 py-1.5 text-xs font-medium text-slate-200 transition hover:border-white/30 hover:bg-white/20">{label}</button>
          ))}
        </div>
      </div>

      <LogsToolbar
        q={q}
        timeWindow={timeWindow}
        from={fromDate}
        to={toDate}
        loading={loading}
        exporting={exporting}
        tenantName={tenantName}
        savedSearches={savedSearches}
        onQChange={setQ}
        onTimeWindowChange={setTimeWindow}
        onFromChange={setFromDate}
        onToChange={setToDate}
        onSearch={handleSearch}
        onExport={handleExport}
        onRefresh={handleSearch}
        onSaveSearchClick={() => setSaveModalOpen(true)}
        onSelectSavedSearch={handleSelectSavedSearch}
      />

      {error && (
        <div className="bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/30 text-rose-700 dark:text-rose-400 px-4 py-3 rounded-2xl text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={handleSearch} className="text-sm font-semibold underline">
            Tekrar Dene
          </button>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { label: 'Toplam olay', value: total, icon: Activity, color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40' },
          { label: 'Kritik / hata', value: logs.filter((l) => ['critical', 'alert', 'emergency', 'error'].includes(l.severity)).length, icon: ShieldAlert, color: 'text-rose-600 bg-rose-50 dark:bg-rose-950/30' },
          { label: 'Engellenen', value: logs.filter((l) => ['deny', 'block', 'blocked', 'timeout'].includes(l.action)).length, icon: Ban, color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/30' },
          { label: 'Benzersiz kimlik', value: new Set(logs.map((l) => l.user || l.src_ip).filter(Boolean)).size, icon: Users, color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30' },
        ].map((item) => (
          <div key={item.label} className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className={`rounded-xl p-2 ${item.color}`}><item.icon className="h-4 w-4" /></div><div><div className="text-xl font-bold text-slate-900 dark:text-slate-100">{item.value.toLocaleString('tr-TR')}</div><div className="text-[11px] font-medium text-slate-500">{item.label}</div></div>
          </div>
        ))}
      </div>

      {(q || filters.vendor || filters.log_type?.length || filters.severity?.length || filters.action?.length || filters.src_ip || filters.dst_ip || filters.user || timeWindow !== '24h') && (
        <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-indigo-100 bg-indigo-50/70 px-3 py-2 dark:border-indigo-900/40 dark:bg-indigo-950/20">
          <span className="mr-1 text-[11px] font-bold uppercase tracking-wider text-indigo-500">Aktif filtreler</span>
          {q && <button onClick={() => setQ('')} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Arama: {q} ×</button>}
          {timeWindow !== '24h' && <button onClick={() => setTimeWindow('24h')} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">{timeWindow} ×</button>}
          {filters.vendor && <button onClick={() => setFilters((f) => ({ ...f, vendor: undefined }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Vendor: {filters.vendor} ×</button>}
          {filters.severity?.map((v) => <button key={v} onClick={() => setFilters((f) => ({ ...f, severity: f.severity?.filter((x) => x !== v) }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Severity: {v} ×</button>)}
          {filters.action?.map((v) => <button key={v} onClick={() => setFilters((f) => ({ ...f, action: f.action?.filter((x) => x !== v) }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Action: {v} ×</button>)}
          {filters.src_ip && <button onClick={() => setFilters((f) => ({ ...f, src_ip: undefined }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Kaynak: {filters.src_ip} ×</button>}
          {filters.dst_ip && <button onClick={() => setFilters((f) => ({ ...f, dst_ip: undefined }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Hedef: {filters.dst_ip} ×</button>}
          {filters.user && <button onClick={() => setFilters((f) => ({ ...f, user: undefined }))} className="rounded-full bg-white px-2.5 py-1 text-xs text-slate-600 shadow-sm dark:bg-slate-900 dark:text-slate-300">Kullanıcı: {filters.user} ×</button>}
          <button onClick={handleFilterClear} className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-indigo-600"><RotateCcw className="h-3 w-3" /> Temizle</button>
        </div>
      )}

      {/* Time Histogram */}
      {logs.length > 0 && <LogHistogram logs={logs} histogram={facets?.histogram} onBucketClick={handleBucketClick} />}

      <div className="grid grid-cols-1 gap-5 2xl:grid-cols-[230px_minmax(0,1fr)_260px]">
        <aside className="w-full 2xl:order-1">
          <div className="sticky top-6 space-y-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-2"><SlidersHorizontal className="h-4 w-4 text-indigo-500" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Filtreler</h3>
            </div>
            <LogsFilterPanel
              filters={filters}
              onChange={setFilters}
              onApply={handleFilterApply}
              onClear={handleFilterClear}
            />
          </div>
        </aside>

        <div className="min-w-0 2xl:order-2">
          <LogsTable
            logs={logs}
            loading={loading}
            hasNext={hasNext}
            total={total}
            onLoadMore={handleLoadMore}
            onCorrelate={handleCorrelate}
            onSelectLog={setSelectedLog}
          />
        </div>

        <aside className="w-full 2xl:order-3">
          <div className="sticky top-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-1">Dinamik Facetler</h3>
            <p className="text-[11px] text-slate-400 mb-3">Filtreye eklemek için tıklayın</p>
            <LogsFacets facets={facets} loading={facetLoading} onFacetClick={handleFacetClick} />
          </div>
        </aside>
      </div>

      {selectedLog && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/30 backdrop-blur-[2px]" onClick={() => setSelectedLog(null)}>
          <section className="h-full w-full max-w-xl overflow-y-auto border-l border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-950" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-200 bg-white/95 px-5 py-4 backdrop-blur dark:border-slate-800 dark:bg-slate-950/95">
              <div><div className="text-[11px] font-bold uppercase tracking-[0.16em] text-indigo-500">Log detayı</div><h3 className="mt-1 text-lg font-bold text-slate-900 dark:text-slate-100">{selectedLog.log_type} · {selectedLog.action || 'olay'}</h3></div>
              <button onClick={() => setSelectedLog(null)} className="rounded-xl p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"><X className="h-5 w-5" /></button>
            </div>
            <div className="space-y-5 p-5">
              <div className="grid grid-cols-2 gap-3">
                {[['Zaman', new Date(selectedLog.timestamp).toLocaleString('tr-TR')], ['Vendor', selectedLog.vendor], ['Severity', selectedLog.severity], ['Korelasyon', selectedLog.correlation_id || '—'], ['Kullanıcı', selectedLog.user || '—'], ['Hostname', selectedLog.hostname || '—']].map(([label, value]) => <div key={label} className="rounded-xl border border-slate-200 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-900"><div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">{label}</div><div className="mt-1 break-all text-sm font-medium text-slate-800 dark:text-slate-200">{value}</div></div>)}
              </div>
              <div className="rounded-2xl border border-indigo-100 bg-indigo-50/70 p-4 dark:border-indigo-900/40 dark:bg-indigo-950/20"><div className="text-[10px] font-semibold uppercase tracking-wider text-indigo-500">Akış</div><div className="mt-2 font-mono text-sm"><span className="text-indigo-600 dark:text-indigo-300">{selectedLog.src_ip || '—'}{selectedLog.src_port ? `:${selectedLog.src_port}` : ''}</span><span className="mx-2 text-slate-400">→</span><span className="text-amber-600 dark:text-amber-300">{selectedLog.dst_ip || '—'}{selectedLog.dst_port ? `:${selectedLog.dst_port}` : ''}</span></div></div>
              <div><div className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Mesaj</div><p className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm leading-6 text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">{selectedLog.message || '—'}</p></div>
              {selectedLog.correlation_reason && <div><div className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Korelasyon açıklaması</div><p className="text-sm text-slate-600 dark:text-slate-400">{selectedLog.correlation_reason}</p></div>}
              <details className="group rounded-xl border border-slate-200 dark:border-slate-800"><summary className="cursor-pointer px-4 py-3 text-xs font-semibold text-slate-600 dark:text-slate-300">Ham kayıt ve ayrıştırılmış alanlar</summary><div className="space-y-3 border-t border-slate-200 p-4 dark:border-slate-800"><pre className="max-h-56 overflow-auto whitespace-pre-wrap break-all rounded-lg bg-slate-950 p-3 text-[11px] leading-5 text-emerald-300">{selectedLog.raw || 'Ham kayıt yok'}</pre><pre className="max-h-72 overflow-auto rounded-lg bg-slate-100 p-3 text-[11px] leading-5 text-slate-700 dark:bg-slate-900 dark:text-slate-300">{JSON.stringify(selectedLog.parsed || {}, null, 2)}</pre></div></details>
            </div>
          </section>
        </div>
      )}

      <CorrelateModal
        open={correlateOpen}
        sessionId={correlateSessionId}
        result={correlateResult}
        loading={correlateLoading}
        onClose={() => setCorrelateOpen(false)}
      />

      {/* Save Search Modal */}
      {saveModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 w-full max-w-md p-5 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-slate-900 dark:text-slate-100 flex items-center">
                <Bookmark className="w-4 h-4 mr-2 text-indigo-600" />
                Aramayı Kaydet
              </h3>
              <button onClick={() => setSaveModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Arama İsmi</label>
              <input
                type="text"
                value={newSearchName}
                onChange={(e) => setNewSearchName(e.target.value)}
                placeholder="Örn: Fortigate Kritik Engellemeler"
                className="mt-1 w-full px-3 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setSaveModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 rounded-xl"
              >
                İptal
              </button>
              <button
                onClick={handleSaveSearchSubmit}
                disabled={savingSearch || !newSearchName.trim()}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-xl flex items-center"
              >
                <Save className="w-3.5 h-3.5 mr-1" />
                {savingSearch ? 'Kaydediliyor...' : 'Kaydet'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
