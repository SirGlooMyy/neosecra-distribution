import React, { useState } from 'react';
import { X, GitCompare, Loader2, Clock, Activity } from 'lucide-react';
import type { CorrelateResult, FirewallLog } from '../../types/logs';

interface Props {
  open: boolean;
  sessionId: string | null;
  result: CorrelateResult | null;
  loading: boolean;
  onClose: () => void;
}

export const CorrelateModal: React.FC<Props> = ({ open, sessionId, result, loading, onClose }) => {
  const [viewMode, setViewMode] = useState<'timeline' | 'table'>('timeline');

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-4xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl text-indigo-600 dark:text-indigo-400">
              <GitCompare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50">
                Oturum Korelasyon Zaman Çizelgesi (Timeline)
              </h3>
              <p className="text-xs text-slate-500">RADIUS, Syslog ve Firewall log ilişkisi</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setViewMode('timeline')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  viewMode === 'timeline' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500'
                }`}
              >
                Zaman Çizelgesi
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  viewMode === 'table' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500'
                }`}
              >
                Tablo
              </button>
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="w-7 h-7 text-indigo-500 animate-spin mr-3" />
              <span className="text-sm font-medium text-slate-500">Oturum korelasyon verileri analiz ediliyor...</span>
            </div>
          ) : result ? (
            <div className="space-y-6">
              {/* Meta bar */}
              <div className="flex flex-wrap items-center justify-between bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
                <div>
                  <span className="text-slate-400">Oturum ID:</span>{' '}
                  <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{sessionId}</span>
                </div>
                <div>
                  <span className="text-slate-400">İlişkili Olaylar:</span>{' '}
                  <span className="font-bold text-indigo-600 dark:text-indigo-400">{result.total} Kayıt</span>
                </div>
                {result.items.length > 0 && (
                  <div>
                    <span className="text-slate-400">Zaman Aralığı:</span>{' '}
                    <span className="font-mono text-slate-600 dark:text-slate-300">
                      {new Date(result.items[result.items.length - 1].timestamp).toLocaleTimeString('tr-TR')} -{' '}
                      {new Date(result.items[0].timestamp).toLocaleTimeString('tr-TR')}
                    </span>
                  </div>
                )}
              </div>

              {viewMode === 'timeline' ? (
                /* Timeline Visualization */
                <div className="relative pl-6 space-y-6 before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-indigo-200 dark:before:bg-slate-800">
                  {result.items.map((log: FirewallLog, idx: number) => (
                    <div key={log.id || idx} className="relative group">
                      {/* Timeline node icon */}
                      <div className="absolute -left-6 top-1.5 w-6 h-6 rounded-full bg-white dark:bg-slate-900 border-2 border-indigo-600 dark:border-indigo-400 flex items-center justify-center shadow-sm">
                        <Activity className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                      </div>

                      {/* Event Card */}
                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm hover:border-indigo-300 dark:hover:border-indigo-800 transition-colors space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center space-x-2">
                            <span className="font-mono text-slate-400 flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {new Date(log.timestamp).toLocaleString('tr-TR')}
                            </span>
                            <span className="uppercase px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-600 dark:text-slate-400">
                              {log.vendor || 'firewall'}
                            </span>
                            <span className="lowercase px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/40 text-[10px] font-medium text-indigo-600 dark:text-indigo-400">
                              {log.log_type}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <SeverityBadge severity={log.severity} />
                            <ActionBadge action={log.action} />
                          </div>
                        </div>

                        {/* Network IPs */}
                        <div className="flex items-center space-x-4 text-xs font-mono text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-2 rounded-lg">
                          <div>
                            <span className="text-slate-400">Kaynak:</span> {log.src_ip}
                            {log.src_port ? `:${log.src_port}` : ''}
                          </div>
                          <span className="text-slate-400">➔</span>
                          <div>
                            <span className="text-slate-400">Hedef:</span> {log.dst_ip}
                            {log.dst_port ? `:${log.dst_port}` : ''}
                          </div>
                          {log.user && (
                            <div className="ml-auto font-sans font-medium text-indigo-600 dark:text-indigo-400">
                              Kullanıcı: {log.user}
                            </div>
                          )}
                        </div>

                        {/* Message */}
                        <p className="text-xs text-slate-600 dark:text-slate-400 font-mono bg-slate-100/50 dark:bg-slate-950/40 p-2 rounded-lg overflow-x-auto">
                          {log.message || log.raw}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                /* Table View */
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                        <th className="px-3 py-2 text-xs font-semibold uppercase text-slate-500">Zaman</th>
                        <th className="px-3 py-2 text-xs font-semibold uppercase text-slate-500">Kaynak</th>
                        <th className="px-3 py-2 text-xs font-semibold uppercase text-slate-500">Hedef</th>
                        <th className="px-3 py-2 text-xs font-semibold uppercase text-slate-500">Severity</th>
                        <th className="px-3 py-2 text-xs font-semibold uppercase text-slate-500">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {result.items.map((log) => (
                        <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                          <td className="px-3 py-2 text-xs text-slate-500 whitespace-nowrap">
                            {new Date(log.timestamp).toLocaleString('tr-TR')}
                          </td>
                          <td className="px-3 py-2 text-xs font-mono text-slate-700 dark:text-slate-300">{log.src_ip}</td>
                          <td className="px-3 py-2 text-xs font-mono text-slate-700 dark:text-slate-300">{log.dst_ip}</td>
                          <td className="px-3 py-2 text-xs">
                            <SeverityBadge severity={log.severity} />
                          </td>
                          <td className="px-3 py-2 text-xs">
                            <ActionBadge action={log.action} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ) : (
            <p className="text-sm text-slate-400 text-center py-8">Korelasyon sonucu bulunamadı.</p>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end p-4 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};

function SeverityBadge({ severity }: { severity: string }) {
  const colors: Record<string, string> = {
    critical: 'bg-rose-100 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400',
    high: 'bg-red-100 text-red-700 dark:bg-red-950/30 dark:text-red-400',
    medium: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400',
    low: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400',
    info: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
  };
  return (
    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${colors[severity] || colors.info}`}>
      {severity}
    </span>
  );
}

function ActionBadge({ action }: { action: string }) {
  const colors: Record<string, string> = {
    accept: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400',
    deny: 'bg-rose-100 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400',
    'client-rst': 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400',
    'server-rst': 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400',
  };
  return (
    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${colors[action] || 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'}`}>
      {action}
    </span>
  );
}
