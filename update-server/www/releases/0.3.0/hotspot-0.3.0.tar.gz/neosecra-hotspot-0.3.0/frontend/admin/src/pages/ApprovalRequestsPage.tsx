import React, { useCallback, useEffect, useMemo, useState } from "react";
import { CheckCircle, Clock3, Mail, RefreshCw, Search, ShieldCheck, UserCheck, UserX, XCircle } from "lucide-react";
import { approveSession, getPendingSessions, rejectSession } from "../lib/api";

type Decision = "approve" | "reject";

const formatDate = (value?: string | null) => {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString("tr-TR");
};

const formatValue = (value: unknown) => {
  if (typeof value === "boolean") return value ? "Evet" : "Hayır";
  if (value === null || value === undefined || value === "") return "—";
  return String(value);
};

export const ApprovalRequestsPage: React.FC = () => {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [query, setQuery] = useState("");
  const [decisionId, setDecisionId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (initial = false) => {
    if (initial) setLoading(true);
    else setRefreshing(true);
    setError(null);
    try {
      const pending = await getPendingSessions();
      setRows((pending || []).filter((item: any) => item?.meta?.approval?.required === true));
    } catch (err: any) {
      setError(err?.message || "Onay istekleri yüklenemedi.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { void load(true); }, [load]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter((row) => {
      const formData = row?.meta?.form_data || {};
      return [
        row?.phone, row?.mac, row?.ip, row?.ssid, row?.auth_method,
        ...Object.values(formData),
      ].some((value) => String(value ?? "").toLowerCase().includes(needle));
    });
  }, [query, rows]);

  const decide = async (id: string, decision: Decision) => {
    setDecisionId(id);
    setError(null);
    try {
      if (decision === "approve") await approveSession(id);
      else await rejectSession(id);
      setRows((current) => current.filter((row) => String(row.id) !== id));
    } catch (err: any) {
      setError(err?.message || "Onay işlemi tamamlanamadı.");
    } finally {
      setDecisionId(null);
    }
  };

  const total = rows.length;
  const displayed = filtered.length;

  return (
    <div className="space-y-6">
      <header className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 px-6 py-6 text-white shadow-xl shadow-indigo-950/20">
        <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-indigo-300">Captive portal operasyonu</div>
            <h1 className="mt-1 text-2xl font-bold tracking-tight">Onay İstekleri</h1>
            <p className="mt-1 max-w-2xl text-sm text-slate-300">Yönetici onayı bekleyen misafirleri inceleyin. Onay verilmeden FortiGate erişimi açılmaz.</p>
          </div>
          <div className="grid grid-cols-2 gap-2 text-center text-xs">
            <div className="rounded-xl border border-white/15 bg-white/10 px-4 py-2"><div className="text-2xl font-bold">{total}</div><div className="text-slate-300">Bekleyen</div></div>
            <div className="rounded-xl border border-white/15 bg-white/10 px-4 py-2"><div className="text-2xl font-bold">{displayed}</div><div className="text-slate-300">Görüntülenen</div></div>
          </div>
        </div>
      </header>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-md">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Telefon, ad, MAC, IP veya form alanı ara" className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm shadow-sm outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-900" />
        </div>
        <button type="button" onClick={() => void load()} disabled={refreshing} className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm font-semibold text-slate-700 shadow-sm hover:border-indigo-300 disabled:opacity-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200">
          <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} /> Yenile
        </button>
      </div>

      {error && <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700 dark:border-rose-900/40 dark:bg-rose-950/20 dark:text-rose-300">{error}</div>}

      {loading ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-sm text-slate-500 shadow-sm dark:border-slate-800 dark:bg-slate-900">Onay istekleri yükleniyor...</div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <ShieldCheck className="mx-auto h-10 w-10 text-emerald-500" />
          <h2 className="mt-3 text-lg font-bold text-slate-900 dark:text-slate-100">Bekleyen onay yok</h2>
          <p className="mt-1 text-sm text-slate-500">Yeni bir misafir yönetici onayı istediğinde kayıt burada görünecek.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((row) => {
            const formData = row?.meta?.form_data && typeof row.meta.form_data === "object" ? row.meta.form_data : {};
            const approval = row?.meta?.approval || {};
            const busy = decisionId === String(row.id);
            const guestName = formData.full_name || formData.first_name || row.phone || "Misafir";
            return (
              <article key={row.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
                <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <UserCheck className="h-5 w-5 text-amber-500" />
                      <h2 className="truncate text-base font-bold text-slate-900 dark:text-slate-100">{formatValue(guestName)}</h2>
                      <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-1 text-[11px] font-semibold text-amber-700 dark:bg-amber-950/30 dark:text-amber-300"><Clock3 className="h-3 w-3" /> Bekliyor</span>
                    </div>
                    <div className="mt-2 grid grid-cols-1 gap-x-6 gap-y-1 text-xs text-slate-500 sm:grid-cols-2">
                      <span>Talep: {formatDate(row.started_at || row.created_at)}</span>
                      <span>Yöntem: <strong className="font-semibold text-slate-700 dark:text-slate-300">{row.auth_method || "—"}</strong></span>
                      <span>Telefon: {row.phone || formatValue(formData.phone)}</span>
                      <span>MAC / IP: <code>{row.mac || "—"}</code> / <code>{row.ip || "—"}</code></span>
                      <span>Lokasyon: {row.location_id || "—"}</span>
                      <span>Onay süresi: {formatDate(approval.token_expires_at)}</span>
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <button type="button" onClick={() => void decide(String(row.id), "approve")} disabled={busy} className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"><CheckCircle className="h-4 w-4" /> Onayla</button>
                    <button type="button" onClick={() => void decide(String(row.id), "reject")} disabled={busy} className="inline-flex items-center gap-1.5 rounded-xl bg-rose-600 px-3 py-2 text-xs font-semibold text-white hover:bg-rose-700 disabled:opacity-50"><XCircle className="h-4 w-4" /> Reddet</button>
                  </div>
                </div>
                <div className="mt-4 grid gap-3 border-t border-slate-100 pt-4 dark:border-slate-800 md:grid-cols-[minmax(0,1fr)_minmax(240px,0.7fr)]">
                  <div>
                    <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">Form bilgileri</div>
                    {Object.keys(formData).length ? <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">{Object.entries(formData).map(([key, value]) => <div key={key} className="rounded-lg bg-slate-50 px-3 py-2 dark:bg-slate-950/50"><div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">{key}</div><div className="mt-0.5 break-words text-xs font-medium text-slate-700 dark:text-slate-200">{formatValue(value)}</div></div>)}</div> : <p className="text-xs text-slate-500">Ek form alanı gönderilmemiş.</p>}
                  </div>
                  <div className="rounded-xl border border-indigo-100 bg-indigo-50/60 p-3 text-xs text-indigo-900 dark:border-indigo-900/40 dark:bg-indigo-950/20 dark:text-indigo-200"><div className="flex items-center gap-2 font-semibold"><Mail className="h-4 w-4" /> E-posta kararı da geçerli</div><p className="mt-1 leading-relaxed">Yöneticiye gönderilen bağlantıdan verilen karar bu ekrandaki listeyle aynı oturumu günceller.</p></div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
