import React from 'react';
import { GitCompare } from 'lucide-react';
import type { FirewallLog } from '../../types/logs';

interface Props {
  log: FirewallLog;
  onCorrelate: (sessionId: string) => void;
}

export const LogsRowExpand: React.FC<Props> = ({ log, onCorrelate }) => {
  const parsedEntries = log.parsed ? Object.entries(log.parsed) : [];

  return (
    <tr className="bg-slate-50/80 dark:bg-slate-950/40">
      <td colSpan={9} className="px-6 py-4">
        <div className="space-y-4">
          {parsedEntries.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-slate-400 uppercase mb-2">Çözümlenmiş Alanlar</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                {parsedEntries.map(([key, val]) => (
                  <div key={key} className="text-xs">
                    <span className="font-semibold text-slate-500">{key}:</span>{' '}
                    <span className="text-slate-700 dark:text-slate-300 font-mono">{String(val)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          <div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase mb-2">Ham Syslog</h4>
            <pre className="text-xs font-mono bg-slate-100 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 overflow-x-auto text-slate-700 dark:text-slate-300 leading-relaxed max-h-40 overflow-y-auto">
              {log.raw}
            </pre>
          </div>
          <div className="flex justify-end">
            <button
              onClick={() => onCorrelate(log.correlation_id || log.id)}
              className="inline-flex items-center px-3 py-1.5 text-xs font-semibold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 rounded-xl transition-colors"
            >
              <GitCompare className="w-3.5 h-3.5 mr-1" />
              Korele
            </button>
          </div>
        </div>
      </td>
    </tr>
  );
};
