import React, { useState } from "react";
import { Terminal, Settings, Play, Database } from "lucide-react";

export const SyslogPage: React.FC = () => {
  const [logs, setLogs] = useState<string[]>([
    "2026-07-10T22:10:01Z dev-1 firewall: [NAT] src=10.0.8.23:49210 dst=1.1.1.1:53 trans=192.168.1.10:1025",
    "2026-07-10T22:10:02Z dev-1 firewall: [HTTP] src=10.0.8.23:49211 dst=104.244.42.1:443 host=twitter.com status=allow",
    "2026-07-10T22:10:03Z dev-2 firewall: [DHCP] ACK to A0:C5:59:7D:66:10 IP=10.0.8.23 lease=86400",
    "2026-07-10T22:11:15Z dev-1 firewall: [NAT] src=10.0.8.45:51203 dst=8.8.8.8:53 trans=192.168.1.10:1026",
    "2026-07-10T22:11:16Z dev-1 firewall: [HTTPS] src=10.0.8.45:51204 dst=172.217.17.142:443 host=google.com status=allow",
  ]);

  const [port, setPort] = useState(514);
  const [protocol, setProtocol] = useState("UDP");
  const [simulating, setSimulating] = useState(false);

  const simulateLog = () => {
    setSimulating(true);
    setTimeout(() => {
      const time = new Date().toISOString();
      const newLogs = [
        `${time} dev-1 firewall: [DHCP] REQUEST from 4C:5E:0C:FA:90:3D via vlan10`,
        `${time} dev-1 firewall: [DHCP] OFFER IP=10.0.8.99 to 4C:5E:0C:FA:90:3D`,
        `${time} dev-1 firewall: [DHCP] ACK to 4C:5E:0C:FA:90:3D IP=10.0.8.99 lease=86400`,
      ];
      setLogs((prev) => [...prev, ...newLogs]);
      setSimulating(false);
    }, 800);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Syslog Alıcısı (Collector)</h2>
          <p className="text-sm text-slate-500">Firewall/gateway DHCP ve NAT syslog loglarının gerçek zamanlı dinlenmesi ve parser ayarları.</p>
        </div>
        <button
          onClick={simulateLog}
          disabled={simulating}
          className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
        >
          <Play className="w-4 h-4 mr-2" />
          {simulating ? "Veri Akıyor..." : "Syslog Event Simüle Et"}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Syslog Config */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
            <Settings className="w-4 h-4 mr-2 text-indigo-500" />
            Alıcı Ayarları
          </h3>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Syslog Portu</label>
              <input
                type="number"
                value={port}
                onChange={(e) => setPort(Number(e.target.value))}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Protokol</label>
              <select
                value={protocol}
                onChange={(e) => setProtocol(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="UDP">UDP (Önerilen - Kayıpsız CPU)</option>
                <option value="TCP">TCP</option>
              </select>
            </div>
            <div className="p-3 bg-indigo-50 dark:bg-indigo-950/20 text-indigo-800 dark:text-indigo-400 rounded-xl text-xs flex items-start space-x-2">
              <Database className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>
                Cihazınızda (FortiGate vb.) syslog yönlendirme IP adresini bu sunucunun IP'si ve yukarıdaki port olarak ayarlamanız yeterlidir.
              </span>
            </div>
          </div>
        </div>

        {/* Live Syslog Console */}
        <div className="lg:col-span-8 bg-slate-950 text-slate-100 border border-slate-900 rounded-2xl p-6 shadow-2xl flex flex-col h-[400px]">
          <h3 className="font-semibold text-slate-50 flex items-center mb-4 pb-2 border-b border-slate-900">
            <Terminal className="w-4 h-4 mr-2 text-indigo-400" />
            Syslog Canlı Akış Konsolu
          </h3>
          <div className="flex-1 overflow-y-auto font-mono text-[11px] space-y-1.5 pr-2 custom-scrollbar">
            {logs.map((log, index) => (
              <div key={index} className={`leading-relaxed ${
                log.includes('[HTTP]') || log.includes('[HTTPS]')
                  ? 'text-cyan-400'
                  : log.includes('[DHCP]')
                  ? 'text-yellow-400'
                  : 'text-slate-400'
              }`}>
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
