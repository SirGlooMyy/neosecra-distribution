import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, Play, RefreshCw, RotateCcw } from 'lucide-react';
import {
  checkPlatformUpdates, getPlatformVersion, getUpdateCapability, getUpdateHistory,
  getUpdateSession, rollbackPlatformUpdate, runUpdatePreflight, startPlatformUpdate,
} from '../lib/api';

const terminal = new Set(['COMPLETED', 'FAILED', 'ROLLED_BACK']);
const stateLabel: Record<string, string> = { PREFLIGHT: 'Ön koşul', BACKING_UP: 'Yedekleme', MIGRATING: 'Migrasyon', VERIFYING: 'Doğrulama', COMPLETED: 'Tamamlandı', FAILED: 'Başarısız', ROLLED_BACK: 'Geri alındı' };

export const PlatformUpgradePage: React.FC = () => {
  const [version, setVersion] = useState<any>(null);
  const [capability, setCapability] = useState<any>(null);
  const [updates, setUpdates] = useState<any>({ updates: [], has_update: false });
  const [session, setSession] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [preflight, setPreflight] = useState<any[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const load = async () => {
    try {
      const [v, c, u, s, h] = await Promise.all([getPlatformVersion(), getUpdateCapability(), checkPlatformUpdates(), getUpdateSession(), getUpdateHistory()]);
      setVersion(v); setCapability(c); setUpdates(u); setSession(s?.session || null); setHistory(h?.history || []);
    } catch (error: any) { setMessage(error?.message || 'Güncelleme merkezi yüklenemedi.'); }
  };
  useEffect(() => { void load(); }, []);
  useEffect(() => {
    if (!session || terminal.has(session.state)) return;
    const timer = window.setInterval(async () => {
      try { const value = await getUpdateSession(); const next = value?.session || null; setSession(next); if (!next || terminal.has(next.state)) { await load(); } } catch { /* next poll retries */ }
    }, 4000);
    return () => window.clearInterval(timer);
  }, [session?.state]);

  const action = async (fn: () => Promise<any>, success: string) => {
    setBusy(true); setMessage(null);
    try { const value = await fn(); setMessage(success); return value; }
    catch (error: any) { setMessage(error?.message || 'İşlem başarısız.'); }
    finally { setBusy(false); }
  };
  const start = async (target: string) => {
    if (!window.confirm(`${target} sürümüne güncelleme başlatılsın mı? Host update-agent yedek alıp servisleri güncelleyecek.`)) return;
    const value = await action(() => startPlatformUpdate(target), 'Güncelleme host agent kuyruğuna bırakıldı.');
    if (value?.session) setSession(value.session);
  };

  const current = version?.current_version || '-';
  return <div className="space-y-6">
    <div className="flex flex-wrap items-start justify-between gap-4"><div><h2 className="text-2xl font-bold">Güncelleme Merkezi</h2><p className="text-sm text-slate-500">Neosecra Distribution imzalı kanal ve host update-agent ile güvenli tek tık güncelleme.</p></div><div className="flex gap-2"><button onClick={() => action(async () => { const x = await checkPlatformUpdates(); setUpdates(x); return x; }, 'Kanal yeniden kontrol edildi.')} disabled={busy} className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm"><RefreshCw className="h-4 w-4" /> Kanalı kontrol et</button><button onClick={() => action(async () => { const x = await runUpdatePreflight(); setPreflight(x.checks || []); return x; }, 'Ön koşul analizi tamamlandı.')} disabled={busy} className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm">Ön koşulları çalıştır</button></div></div>
    {message && <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm dark:border-slate-800 dark:bg-slate-900">{message}</div>}
    <div className="grid gap-4 md:grid-cols-4"><div className="rounded-2xl border p-5"><p className="text-xs uppercase text-slate-500">Çalışan sürüm</p><p className="mt-2 text-2xl font-bold">{current}</p></div><div className="rounded-2xl border p-5"><p className="text-xs uppercase text-slate-500">Kanal</p><p className="mt-2 text-sm font-semibold">{version?.release_channel || capability?.release_channel || '-'}</p></div><div className="rounded-2xl border p-5"><p className="text-xs uppercase text-slate-500">Agent</p><p className={`mt-2 text-sm font-semibold ${capability?.can_auto_upgrade ? 'text-emerald-600' : 'text-amber-600'}`}>{capability?.can_auto_upgrade ? 'Hazır / heartbeat güncel' : capability?.heartbeat_reason || 'Devre dışı'}</p></div><div className="rounded-2xl border p-5"><p className="text-xs uppercase text-slate-500">Durum</p><p className="mt-2 text-sm font-semibold">{stateLabel[session?.state || version?.upgrade_status] || session?.state || 'Boşta'}</p></div></div>
    {updates.has_update && <section className="rounded-2xl border border-indigo-200 bg-indigo-50/40 p-6 dark:border-indigo-900 dark:bg-indigo-950/20"><h3 className="mb-4 text-lg font-semibold">İmzalı sürümler</h3><div className="space-y-3">{(updates.updates || []).map((item: any) => <div key={item.target_version} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-white p-4 dark:bg-slate-900"><div><p className="font-semibold">{item.target_version}</p><p className="text-sm text-slate-500">Minimum: {item.minimum_current_version || '-'} · {item.release_notes || 'Sürüm notu yok'}</p></div><button onClick={() => start(item.target_version)} disabled={busy || !capability?.can_auto_upgrade} className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-40"><Play className="h-4 w-4" /> Tek tık güncelle</button></div>)}</div></section>}
    {!updates.has_update && <div className="rounded-2xl border p-6 text-sm text-slate-500">Çalışan sürüm güncel veya imzalı kanal şu anda erişilemiyor.</div>}
    {preflight && <section className="rounded-2xl border p-6"><h3 className="mb-3 font-semibold">Ön koşul sonuçları</h3><div className="grid gap-2 md:grid-cols-2">{preflight.map((check: any) => <div key={check.name} className="flex gap-2 rounded-xl border p-3 text-sm">{check.status === 'PASS' ? <CheckCircle2 className="h-4 w-4 text-emerald-500" /> : <AlertTriangle className="h-4 w-4 text-amber-500" />}<span><strong>{check.name}</strong><br /><span className="text-slate-500">{check.message}</span></span></div>)}</div></section>}
    {history.length > 0 && <section className="rounded-2xl border p-6"><h3 className="mb-3 font-semibold">Güncelleme geçmişi</h3><div className="space-y-2">{history.slice(0, 10).map((item: any) => <div key={item.id} className="flex flex-wrap items-center justify-between gap-3 border-b py-3 text-sm"><div><strong>{item.from_version || '?'} → {item.target_version}</strong><p className="text-xs text-slate-500">{item.finished_at ? new Date(item.finished_at).toLocaleString('tr-TR') : '-'} · {stateLabel[item.state] || item.state}</p></div>{capability?.can_rollback && item.backup_path && <button onClick={() => action(() => rollbackPlatformUpdate(item.id), 'Rollback isteği agent kuyruğuna bırakıldı.')} disabled={busy} className="inline-flex items-center gap-1 rounded-lg border px-3 py-1.5 text-xs"><RotateCcw className="h-3.5 w-3.5" /> Geri al</button>}</div>)}</div></section>}
  </div>;
};
