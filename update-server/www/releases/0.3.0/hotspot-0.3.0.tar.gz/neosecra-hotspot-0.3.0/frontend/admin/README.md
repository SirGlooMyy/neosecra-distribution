# Admin Panel Skeleton

React + TypeScript + Tailwind admin panel.

## Ana Sayfalar
- Dashboard
- Partners / Resellers
- Customers
- Locations
- Devices
- Portal Templates
- Guest Sessions
- 5651 Archives
- Reports
- Licenses
- Audit Logs
- Support / Operations
