import React from 'react';
import type { FacetResult } from '../../types/logs';

interface Props {
  facets: FacetResult | null;
  loading: boolean;
  onFacetClick?: (facetKey: keyof FacetResult, value: string) => void;
}

function FacetSection({
  title,
  facetKey,
  items,
  color,
  onFacetClick,
}: {
  title: string;
  facetKey: keyof FacetResult;
  items: { value: string; count: number }[];
  color: string;
  onFacetClick?: (facetKey: keyof FacetResult, value: string) => void;
}) {
  const maxCount = Math.max(...items.map((item) => item.count), 1);
  return (
    <div>
      <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">{title}</h4>
      {items.length === 0 ? (
        <p className="text-xs text-slate-400">Veri yok</p>
      ) : (
        <ul className="space-y-1">
          {items.slice(0, 10).map((item) => (
          <li
              key={item.value}
              onClick={() => onFacetClick && onFacetClick(facetKey, item.value)}
              className="flex items-center justify-between text-sm p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/60 cursor-pointer transition-colors group"
              title={`"${item.value}" değerini filtreye eklemek için tıklayın`}
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-slate-600 dark:text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                    {item.value}
                  </span>
                  <span className={`ml-2 text-xs font-semibold ${color}`}>{item.count}</span>
                </div>
                <div className="mt-1 h-1 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800"><div className="h-full rounded-full bg-current opacity-50" style={{ width: `${Math.max(4, (item.count / maxCount) * 100)}%` }} /></div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export const LogsFacets: React.FC<Props> = ({ facets, loading, onFacetClick }) => {
  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="animate-pulse space-y-2">
            <div className="h-3 w-16 bg-slate-200 dark:bg-slate-800 rounded" />
            <div className="h-4 w-full bg-slate-100 dark:bg-slate-800/50 rounded" />
            <div className="h-4 w-3/4 bg-slate-100 dark:bg-slate-800/50 rounded" />
          </div>
        ))}
      </div>
    );
  }

  if (!facets) return <p className="text-sm text-slate-400">Filtre uygulayın</p>;

  // Older API responses occasionally returned an object for an empty facet.
  // Normalize every bucket before rendering so a partial/empty response never
  // crashes the whole analyzer with “map is not a function”.
  const safeItems = (value: unknown) => (Array.isArray(value) ? value : []);

  return (
    <div className="space-y-5">
      <FacetSection title="Vendor" facetKey="vendor" items={safeItems(facets.vendor) as { value: string; count: number }[]} color="text-indigo-600 dark:text-indigo-400" onFacetClick={onFacetClick} />
      <FacetSection title="Severity" facetKey="severity" items={safeItems(facets.severity) as { value: string; count: number }[]} color="text-amber-600 dark:text-amber-400" onFacetClick={onFacetClick} />
      <FacetSection title="Log Türü" facetKey="log_type" items={safeItems(facets.log_type) as { value: string; count: number }[]} color="text-emerald-600 dark:text-emerald-400" onFacetClick={onFacetClick} />
      <FacetSection title="Action" facetKey="action" items={safeItems(facets.action) as { value: string; count: number }[]} color="text-rose-600 dark:text-rose-400" onFacetClick={onFacetClick} />
      {safeItems(facets.src_ip).length ? <FacetSection title="Kaynak IP" facetKey="src_ip" items={safeItems(facets.src_ip) as { value: string; count: number }[]} color="text-indigo-600 dark:text-indigo-400" onFacetClick={onFacetClick} /> : null}
      {safeItems(facets.dst_ip).length ? <FacetSection title="Hedef IP" facetKey="dst_ip" items={safeItems(facets.dst_ip) as { value: string; count: number }[]} color="text-amber-600 dark:text-amber-400" onFacetClick={onFacetClick} /> : null}
      {safeItems(facets.user).length ? <FacetSection title="Kullanıcı" facetKey="user" items={safeItems(facets.user) as { value: string; count: number }[]} color="text-emerald-600 dark:text-emerald-400" onFacetClick={onFacetClick} /> : null}
    </div>
  );
};
