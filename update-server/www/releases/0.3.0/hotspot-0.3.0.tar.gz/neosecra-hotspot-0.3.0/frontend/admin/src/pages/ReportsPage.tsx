import React, { useState, useEffect } from "react";
import { BarChart3, Download, RefreshCw, TrendingUp, ShieldCheck, Database, MapPin, UserCheck, HardDrive, FileSpreadsheet, FileText, Gauge, Activity, Radio } from "lucide-react";
import { getReportSummary, getDailyTrendData, downloadQuickReport, downloadReportFile } from "../lib/api";

interface DifferentiatorReportCardProps {
  id: string;
  title: string;
  description: string;
  badge: string;
  icon: React.ReactNode;
  dateRange: string;
}

const DifferentiatorReportCard: React.FC<DifferentiatorReportCardProps> = ({ id, title, description, badge, icon, dateRange }) => {
  const getFromTime = () => {
    const now = new Date();
    if (dateRange === "Bugün") {
      return new Date(now.setHours(0, 0, 0, 0)).toISOString();
    } else if (dateRange === "Son 7 Gün") {
      return new Date(now.setDate(now.getDate() - 7)).toISOString();
    } else if (dateRange === "Son 30 Gün") {
      return new Date(now.setDate(now.getDate() - 30)).toISOString();
    }
    return "";
  };

  const handleExportCSV = () => {
    const fromTime = getFromTime();
    const params = new URLSearchParams({ report_type: id, format: "csv" });
    if (fromTime) params.set("date_from", fromTime);
    void downloadReportFile(`/reports/differentiator/export?${params.toString()}`, `${id}.csv`);
  };

  const handleExportPDF = () => {
    const fromTime = getFromTime();
    const params = new URLSearchParams({ report_type: id, format: "pdf" });
    if (fromTime) params.set("date_from", fromTime);
    void downloadReportFile(`/reports/differentiator/export?${params.toString()}`, `${id}.pdf`);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 flex flex-col justify-between hover:border-indigo-200 dark:hover:border-indigo-900 transition-colors">
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="p-2.5 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl text-indigo-600 dark:text-indigo-400">
            {icon}
          </div>
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
            {badge}
          </span>
        </div>
        <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base mb-1">{title}</h3>
        <p className="text-xs text-slate-500 line-clamp-2">{description}</p>
      </div>

      <div className="flex items-center space-x-2 pt-2 border-t border-slate-100 dark:border-slate-800">
        <button
          onClick={handleExportCSV}
          className="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-xl text-xs font-semibold transition-colors"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 mr-1.5" />
          CSV İndir
        </button>
        <button
          onClick={handleExportPDF}
          className="flex-1 inline-flex items-center justify-center px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/30 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 text-indigo-700 dark:text-indigo-400 rounded-xl text-xs font-semibold transition-colors"
        >
          <FileText className="w-3.5 h-3.5 mr-1.5" />
          PDF İndir
        </button>
      </div>
    </div>
  );
};

interface QuickReportCardProps {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  accent: string;
}

const QuickReportCard: React.FC<QuickReportCardProps> = ({ id, title, description, icon, accent }) => {
  const [busy, setBusy] = useState<"pdf" | "csv" | null>(null);

  const download = async (format: "pdf" | "csv") => {
    setBusy(format);
    try {
      await downloadQuickReport(id, { days: 30, format });
    } catch (error) {
      console.error("Hızlı rapor indirilemedi", error);
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-indigo-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
      <div className={`absolute inset-x-0 top-0 h-1 ${accent}`} />
      <div className="mb-4 flex items-start justify-between gap-3">
        <div className="rounded-xl bg-indigo-50 p-2.5 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-300">{icon}</div>
        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-slate-500 dark:bg-slate-800 dark:text-slate-400">30 gün</span>
      </div>
      <h4 className="mb-1 text-sm font-bold text-slate-900 dark:text-slate-100">{title}</h4>
      <p className="mb-5 min-h-[34px] text-xs leading-5 text-slate-500">{description}</p>
      <div className="flex gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
        <button
          type="button"
          disabled={Boolean(busy)}
          onClick={() => void download("pdf")}
          className="inline-flex flex-1 items-center justify-center rounded-xl bg-indigo-600 px-3 py-2 text-xs font-bold text-white transition hover:bg-indigo-700 disabled:cursor-wait disabled:opacity-60"
        >
          {busy === "pdf" ? <RefreshCw className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <FileText className="mr-1.5 h-3.5 w-3.5" />}
          PDF al
        </button>
        <button
          type="button"
          disabled={Boolean(busy)}
          onClick={() => void download("csv")}
          className="inline-flex items-center justify-center rounded-xl bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700 transition hover:bg-emerald-100 disabled:cursor-wait disabled:opacity-60 dark:bg-emerald-950/30 dark:text-emerald-300"
          aria-label={`${title} CSV indir`}
        >
          {busy === "csv" ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <FileSpreadsheet className="h-3.5 w-3.5" />}
        </button>
      </div>
    </div>
  );
};

export const ReportsPage: React.FC = () => {
  const [dateRange, setDateRange] = useState("Son 7 Gün");
  const [summary, setSummary] = useState<any>({ total: 0, by_status: {}, by_auth_method: {}, bytes_total: 0, avg_duration_minutes: 0 });
  const [dailyTrend, setDailyTrend] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        let fromTime = "";
        const now = new Date();
        if (dateRange === "Bugün") {
          fromTime = new Date(now.setHours(0, 0, 0, 0)).toISOString();
        } else if (dateRange === "Son 7 Gün") {
          fromTime = new Date(now.setDate(now.getDate() - 7)).toISOString();
        } else if (dateRange === "Son 30 Gün") {
          fromTime = new Date(now.setDate(now.getDate() - 30)).toISOString();
        }

        const results = await Promise.allSettled([
          getReportSummary(fromTime),
          // getDailyTrendData(customerId, days): keep the platform/global
          // scope implicit and pass the selected period as the second arg.
          getDailyTrendData(undefined, dateRange === "Son 30 Gün" ? 30 : 7),
        ]);

        if (results[0].status === "fulfilled" && results[0].value) setSummary(results[0].value);
        if (results[1].status === "fulfilled" && results[1].value) {
          // The dashboard endpoint returns an envelope ({ daily, weekly, ... })
          // while older installations returned the array directly. Keep the
          // chart tolerant of both response shapes so a backend mismatch never
          // crashes the whole Reports page.
          const trendPayload: any = results[1].value;
          const daily = Array.isArray(trendPayload)
            ? trendPayload
            : Array.isArray(trendPayload.daily)
              ? trendPayload.daily
              : Array.isArray(trendPayload.data)
                ? trendPayload.data
                : [];
          setDailyTrend(daily);
        }
        results.forEach((result) => {
          if (result.status === "rejected") console.warn("Rapor bileşeni yüklenemedi", result.reason);
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [dateRange]);

  const handleExport = () => {
    let fromTime = "";
    const now = new Date();
    if (dateRange === "Bugün") {
      fromTime = new Date(now.setHours(0, 0, 0, 0)).toISOString();
    } else if (dateRange === "Son 7 Gün") {
      fromTime = new Date(now.setDate(now.getDate() - 7)).toISOString();
    } else if (dateRange === "Son 30 Gün") {
      fromTime = new Date(now.setDate(now.getDate() - 30)).toISOString();
    }
    const params = new URLSearchParams({ format: "csv" });
    if (fromTime) params.set("date_from", fromTime);
    void downloadReportFile(`/reports/sessions/export?${params.toString()}`, "sessions.csv");
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const maxTrendCount = dailyTrend.length > 0 ? Math.max(...dailyTrend.map(d => d.count), 1) : 1;
  const sessionChartData = dailyTrend.map((d: any) => {
    const parts = d.date.split("-");
    const label = parts.length === 3 ? `${parts[2]}/${parts[1]}` : d.date;
    const pct = Math.max(10, Math.round((d.count / maxTrendCount) * 100));
    return {
      label,
      value: d.count,
      heightStyle: { height: `${pct}%` }
    };
  });

  const totalAuthCount = Object.values(summary.by_auth_method || {}).reduce((a: any, b: any) => a + b, 0) as number;
  const authMethodsBreakdown = Object.entries(summary.by_auth_method || {}).map(([method, count]: [string, any], idx) => {
    const pct = totalAuthCount > 0 ? Math.round((count / totalAuthCount) * 100) : 0;
    const colors = ["bg-indigo-600", "bg-violet-600", "bg-pink-600", "bg-emerald-600", "bg-amber-600", "bg-teal-600"];
    const labels: Record<string, string> = {
      sms: "SMS OTP Doğrulama",
      tc: "T.C. Kimlik Doğrulama",
      voucher: "Bilet / Voucher Girişi",
      free: "Ücretsiz Giriş",
      whatsapp: "WhatsApp Doğrulama",
      ldap: "LDAP Entegrasyonu"
    };
    return {
      label: labels[method] || method.toUpperCase(),
      percentage: pct,
      count,
      color: colors[idx % colors.length]
    };
  });

  if (loading) {
    return (
      <div className="flex justify-center items-center py-24 space-x-2">
        <RefreshCw className="w-6 h-6 text-indigo-500 animate-spin" />
        <span className="text-sm font-medium text-slate-500">Raporlar yükleniyor...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Raporlar & Analitik</h2>
          <p className="text-sm text-slate-500">Firewall Analyzer olaylarını, VPN trafiğini, misafir kullanımını ve 5651 rapor setlerini tek merkezden dışa aktarın.</p>
        </div>
        <div className="flex items-center space-x-3">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="Bugün">Bugün</option>
            <option value="Son 7 Gün">Son 7 Gün</option>
            <option value="Son 30 Gün">Son 30 Gün</option>
          </select>
          <button
            onClick={handleExport}
            className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" />
            Genel Oturum Raporu (CSV)
          </button>
        </div>
      </div>

      {/* Operator one-click presets: these are the recurring questions that
          normally require several Analyzer filters and spreadsheet work. */}
      <section className="space-y-4 rounded-3xl border border-indigo-100 bg-gradient-to-br from-indigo-50/80 via-white to-white p-5 dark:border-indigo-950/60 dark:from-indigo-950/30 dark:via-slate-900 dark:to-slate-900">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="mb-1 flex items-center gap-2">
              <Gauge className="h-4 w-4 text-indigo-600 dark:text-indigo-300" />
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Tek Tık Operasyon Raporları</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">Analyzer ve captive portal verisini birleştirir; yöneticiye gönderilebilir düzenli PDF üretir.</p>
          </div>
          <span className="rounded-full border border-indigo-200 bg-white px-3 py-1 text-[11px] font-semibold text-indigo-700 dark:border-indigo-900 dark:bg-slate-900 dark:text-indigo-300">FortiGate + Portal</span>
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          <QuickReportCard id="vpn_activity_30d" title="VPN aktivitesi" description="SSL-VPN ve IPsec tünel olayları, kullanıcılar ve trafik." icon={<Radio className="h-5 w-5" />} accent="bg-violet-500" />
          <QuickReportCard id="top_bandwidth_users_30d" title="En çok bandwidth kullananlar" description="Gönderilen/alınan byte toplamına göre ilk 50 kullanıcı veya IP." icon={<Gauge className="h-5 w-5" />} accent="bg-cyan-500" />
          <QuickReportCard id="firewall_security_30d" title="Firewall güvenlik özeti" description="Allow/deny, UTM, kritik olay ve en son Analyzer kayıtları." icon={<ShieldCheck className="h-5 w-5" />} accent="bg-rose-500" />
          <QuickReportCard id="captive_portal_usage_30d" title="Portal kullanım özeti" description="Oturum, doğrulama metodu, lokasyon ve portal veri tüketimi." icon={<Activity className="h-5 w-5" />} accent="bg-emerald-500" />
        </div>
      </section>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-2">
          <div className="text-xs text-slate-500 font-semibold">Toplam Oturum</div>
          <div className="flex justify-between items-baseline">
            <span className="text-3xl font-bold text-slate-900 dark:text-slate-50">{summary.total.toLocaleString()}</span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium flex items-center bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded-full">
              <TrendingUp className="w-3 h-3 mr-1" />
              %100.0
            </span>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-2">
          <div className="text-xs text-slate-500 font-semibold">Ortalama Oturum Süresi</div>
          <div className="flex justify-between items-baseline">
            <span className="text-3xl font-bold text-slate-900 dark:text-slate-50">{summary.avg_duration_minutes} dk</span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium flex items-center bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded-full">
              <TrendingUp className="w-3 h-3 mr-1" />
              %0.0
            </span>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-2">
          <div className="text-xs text-slate-500 font-semibold">Veri Tüketimi (Toplam)</div>
          <div className="flex justify-between items-baseline">
            <span className="text-3xl font-bold text-slate-900 dark:text-slate-50">{formatBytes(summary.bytes_total)}</span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium flex items-center bg-emerald-50 dark:bg-emerald-950/20 px-2 py-0.5 rounded-full">
              %0.0
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Daily Oturum Trend Chart */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center mb-1">
              <BarChart3 className="w-4 h-4 mr-2 text-indigo-500" />
              Günlük Oturum İstatistikleri
            </h3>
            <p className="text-xs text-slate-500 mb-6">Seçilen periyoda ait toplam Wi-Fi bağlantı oturumu grafiği.</p>
          </div>
          {/* Chart Columns Area */}
          <div className="flex items-end justify-between h-72 px-4 pb-4 border-b border-slate-100 dark:border-slate-800">
            {sessionChartData.length === 0 ? (
              <div className="flex items-center justify-center w-full h-full text-slate-400 text-xs">
                Grafik verisi bulunamadı.
              </div>
            ) : (
              sessionChartData.map((d, index) => (
                <div key={index} className="flex flex-col items-center space-y-2 flex-1 group">
                  <div className="opacity-0 group-hover:opacity-100 bg-slate-800 text-white text-[10px] px-1.5 py-0.5 rounded transition-opacity duration-150 -translate-y-1">
                    {d.value}
                  </div>
                  <div 
                    className="w-8 bg-gradient-to-t from-indigo-500 to-indigo-600 dark:from-indigo-600 dark:to-indigo-400 rounded-lg shadow-sm hover:from-indigo-600 hover:to-indigo-700 transition-all duration-300"
                    style={d.heightStyle}
                  />
                  <span className="text-xs text-slate-400 font-medium">{d.label}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Auth breakdown percentage bars */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100">Giriş Metotları Dağılımı</h3>
            <p className="text-xs text-slate-500">Misafirlerin Wi-Fi doğrulamada tercih ettiği yöntemler.</p>
          </div>
          <div className="space-y-4">
            {authMethodsBreakdown.length === 0 ? (
              <div className="text-slate-400 text-xs py-8 text-center">
                Veri bulunamadı.
              </div>
            ) : (
              authMethodsBreakdown.map((m, index) => (
                <div key={index} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-600 dark:text-slate-400">{m.label}</span>
                    <span className="text-slate-800 dark:text-slate-200">%{m.percentage} ({m.count})</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div 
                      className={`${m.color} h-2 rounded-full transition-all duration-500`}
                      style={{ width: `${m.percentage}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Differentiator Reports Section (Phase 4) */}
      <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Farklılaştırıcı Rapor Setleri</h3>
          <p className="text-xs text-slate-500">5651 yasal uyum, mahkeme delil paketleri ve ileri düzey operasyonel raporlar.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <DifferentiatorReportCard
            id="5651_evidence"
            title="5651 Mahkeme Delil Paketi"
            description="Mahkeme ve kolluk kuvvetlerine sunulabilir imzalı hash zincirli yasal delil paketi."
            badge="Yasal Uyum"
            icon={<ShieldCheck className="w-5 h-5" />}
            dateRange={dateRange}
          />

          <DifferentiatorReportCard
            id="ip_identity_matrix"
            title="IP ↔ Kimlik Korelasyon Matrisi"
            description="IP, MAC, Telefon, TC Kimlik ve Voucher doğrulamalarının uçtan uca korelasyon matrisi."
            badge="Güvenlik"
            icon={<Database className="w-5 h-5" />}
            dateRange={dateRange}
          />

          <DifferentiatorReportCard
            id="venue_density"
            title="Lokasyon & Mekan Yoğunluk"
            description="Mekan ve şube bazlı Wi-Fi bağlantı yoğunluğu, ortalama kalınan süre ve data tüketimi."
            badge="Mekan Analitiği"
            icon={<MapPin className="w-5 h-5" />}
            dateRange={dateRange}
          />

          <DifferentiatorReportCard
            id="operator_audit"
            title="BTK / Operatör Denetim Raporu"
            description="Sistem yöneticisi işlem izleri, kural güncellemeleri ve denetim günlükleri."
            badge="Denetim"
            icon={<UserCheck className="w-5 h-5" />}
            dateRange={dateRange}
          />

          <DifferentiatorReportCard
            id="quota_license_usage"
            title="Kota & Lisans Kullanım Raporu"
            description="Aktif cihaz ve kullanıcı oturum lisansı tüketimi ile bandwidth kota analizleri."
            badge="Lisans & Kota"
            icon={<HardDrive className="w-5 h-5" />}
            dateRange={dateRange}
          />
        </div>
      </div>
    </div>
  );
};
