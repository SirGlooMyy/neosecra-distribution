import React from "react";
import { DataTable } from "../ui/DataTable";
import { Session } from "../../types/dashboard";

interface Props {
  sessions: Session[];
}

export const RecentSessionsTable: React.FC<Props> = ({ sessions }) => {
  const columns = [
    { header: "Kullanıcı", accessor: "user" as keyof Session },
    { header: "Cihaz", accessor: "device" as keyof Session },
    { header: "Başlangıç", accessor: "startTime" as keyof Session },
    { header: "Süre (dk)", accessor: "durationMinutes" as keyof Session },
    { header: "Durum", accessor: "status" as keyof Session },
  ];

  return <DataTable columns={columns} data={sessions} className="mt-4" />;
};
