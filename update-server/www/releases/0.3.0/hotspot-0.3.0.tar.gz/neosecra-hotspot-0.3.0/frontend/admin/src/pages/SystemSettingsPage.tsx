import React, { useState, useEffect } from "react";
import {
  Save, Server, Eye, EyeOff, Palette, Monitor, Mail, Upload,
  Download, Trash2, RefreshCw, Activity, Database, HardDrive,
  CheckCircle, XCircle, Clock, Users, Smartphone,
} from "lucide-react";
import { useTheme } from "../theme/ThemeProvider";
import {
  listBackups, createBackup, restoreBackup, deleteBackup,
  getWhitelabelConfig, updateWhitelabelConfig, uploadBrandAsset,
  getEmailConfig, updateEmailConfig, testEmailConfig,
  getSystemHealth,
  getCurrentUser,
  updateCurrentUserProfile,
} from "../lib/api";

const TABS = [
  { id: "backup", label: "Yedekleme & Geri Yükleme", icon: Server },
  { id: "smtp", label: "E-Posta (SMTP)", icon: Mail },
  { id: "dashboard", label: "Dashboard Ayarları", icon: Monitor },
  { id: "profile", label: "Profil & Güvenlik", icon: Activity },
];

const SYSTEM_SECURITY_PREFS_KEY = "hotspot_admin_system_security_prefs_v1";

interface SystemSettingsPageProps {
  initialTab?: string;
}

export const SystemSettingsPage: React.FC<SystemSettingsPageProps> = ({ initialTab = "profile" }) => {
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState(initialTab);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [health, setHealth] = useState<any>(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [profileSaving, setProfileSaving] = useState(false);

  const showSuccess = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const showError = (msg: string) => {
    setError(msg);
    setTimeout(() => setError(null), 5000);
  };

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  // ---- Profile & Security ----
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    role: "Süper Admin",
  });
  const [security, setSecurity] = useState({ twoFaEnabled: false, sessionTimeout: 60 });

  useEffect(() => {
    try {
      const stored = localStorage.getItem(SYSTEM_SECURITY_PREFS_KEY);
      if (!stored) return;
      const parsed = JSON.parse(stored);
      if (parsed?.security) {
        setSecurity((prev) => ({ ...prev, ...parsed.security }));
      }
    } catch (err) {
      console.warn("Failed to load system preferences", err);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setProfileLoading(true);
      try {
        const user = await getCurrentUser();
        if (cancelled || !user) return;
        setProfile({
          name: user.full_name || "",
          email: user.email || "",
          role: user.role || "Süper Admin",
        });
      } catch (err) {
        console.warn("Failed to load current user profile", err);
      } finally {
        if (!cancelled) setProfileLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(
        SYSTEM_SECURITY_PREFS_KEY,
        JSON.stringify({ security })
      );
    } catch (err) {
      console.warn("Failed to persist security preferences", err);
    }
  }, [security]);

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaving(true);
    try {
      const updated = await updateCurrentUserProfile({
        email: profile.email,
        full_name: profile.name,
      });
      setProfile({
        name: updated.full_name || "",
        email: updated.email || "",
        role: updated.role || profile.role,
      });
    } catch (err) {
      console.warn("Failed to persist profile", err);
      showError("Profil kaydedilemedi.");
      return;
    } finally {
      setProfileSaving(false);
    }
    showSuccess();
  };

  // ---- Backup ----
  const [backups, setBackups] = useState<any[]>([]);
  const [backingUp, setBackingUp] = useState(false);
  const [backupType, setBackupType] = useState("full");

  const loadBackups = async () => {
    try {
      const data = await listBackups();
      setBackups(Array.isArray(data) ? data : []);
    } catch { setBackups([]); }
  };

  useEffect(() => { if (activeTab === "backup") loadBackups(); }, [activeTab]);

  const handleCreateBackup = async () => {
    setBackingUp(true);
    try {
      await createBackup(backupType);
      showSuccess();
      await loadBackups();
    } catch (err: any) {
      showError(err.message || "Yedekleme baslatilamadi");
    } finally { setBackingUp(false); }
  };

  const handleRestore = async (id: string) => {
    if (!confirm("Geri yukleme islemi mevcut verileri degistirebilir. Devam etmek istiyor musunuz?")) return;
    try {
      await restoreBackup(id);
      showSuccess();
    } catch (err: any) { showError(err.message || "Geri yukleme basarisiz"); }
  };

  const handleDeleteBackup = async (id: string) => {
    if (!confirm("Bu yedegi silmek istediginize emin misiniz?")) return;
    try {
      await deleteBackup(id);
      await loadBackups();
    } catch (err: any) { showError(err.message || "Silme basarisiz"); }
  };

  // ---- White-Label ----
  const [wlConfig, setWlConfig] = useState<any>({
    brand_name: "", primary_color: "#4F46E5", secondary_color: "#7C3AED",
    accent_color: "#10B981", support_email: "", support_phone: "",
    footer_text: "", terms_url: "", privacy_url: "", custom_domain: "",
  });
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [faviconFile, setFaviconFile] = useState<File | null>(null);
  const [wlScope, setWlScope] = useState("platform");

  useEffect(() => {
    if (activeTab !== "whitelabel") return;
    let cancelled = false;
    (async () => {
      try {
        const config = await getWhitelabelConfig();
        if (!cancelled) {
          setWlConfig(config);
        }
      } catch (err) {
        if (!cancelled) {
          showError(err instanceof Error ? err.message : "Beyaz etiket ayarları yüklenemedi.");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeTab]);

  const handleWlSave = async () => {
    try {
      await updateWhitelabelConfig({ ...wlConfig, scope_type: wlScope });
      if (logoFile) await uploadBrandAsset(logoFile, "logo", wlScope);
      if (faviconFile) await uploadBrandAsset(faviconFile, "favicon", wlScope);
      showSuccess();
    } catch (err: any) { showError(err.message || "Kayit basarisiz"); }
  };

  // ---- SMTP ----
  const [smtpConfig, setSmtpConfig] = useState<any>({
    smtp_host: "", smtp_port: 587, smtp_username: "", smtp_password: "",
    smtp_use_tls: true, smtp_use_ssl: false, from_address: "", from_name: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);

  useEffect(() => {
    if (activeTab !== "smtp") return;
    let cancelled = false;
    (async () => {
      try {
        const config = await getEmailConfig();
        if (!cancelled) {
          setSmtpConfig(config);
        }
      } catch (err) {
        if (!cancelled) {
          showError(err instanceof Error ? err.message : "SMTP ayarları yüklenemedi.");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeTab]);

  const handleSmtpSave = async () => {
    try {
      const data = await updateEmailConfig(smtpConfig);
      setSmtpConfig(data);
      showSuccess();
    } catch (err: any) { showError(err.message || "Kayit basarisiz"); }
  };

  const handleTestSmtp = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const result = await testEmailConfig(smtpConfig.id || "none");
      setTestResult(result);
    } catch (err: any) {
      setTestResult({ success: false, message: err.message || "Baglanti testi basarisiz" });
    } finally { setTesting(false); }
  };

  // ---- Health ----
  useEffect(() => {
    if (activeTab !== "dashboard") return;
    let cancelled = false;
    (async () => {
      try {
        const value = await getSystemHealth();
        if (!cancelled) {
          setHealth(value);
        }
      } catch (err) {
        if (!cancelled) {
          setHealth(null);
          showError(err instanceof Error ? err.message : "Sistem sağlığı yüklenemedi.");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeTab]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Sistem Yönetimi</h2>
        <p className="text-sm text-slate-500">Yedekleme, e-posta SMTP, dashboard ve yönetici güvenlik ayarlarını yapılandırın.</p>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/50 rounded-xl text-sm font-medium">
          Ayarlar basariyla kaydedildi!
        </div>
      )}
      {error && (
        <div className="p-3 bg-rose-50 dark:bg-rose-950/20 text-rose-800 dark:text-rose-400 border border-rose-100 dark:border-rose-900/50 rounded-xl text-sm font-medium">
          {error}
        </div>
      )}
      {profileLoading && (
        <div className="p-3 bg-sky-50 dark:bg-sky-950/20 text-sky-800 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50 rounded-xl text-sm font-medium">
          Profil bilgileri yükleniyor...
        </div>
      )}

      {/* Sub-tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`inline-flex items-center px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              activeTab === tab.id
                ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
          >
            <tab.icon className="w-4 h-4 mr-2" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* ---- Profile & Security ---- */}
      {activeTab === "profile" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <form onSubmit={handleProfileSave} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Activity className="w-4 h-4 mr-2 text-indigo-500" />
              Profil Bilgileri
            </h3>
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Adiniz Soyadiniz</label>
                <input type="text" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">E-Posta Adresi</label>
                <input type="email" value={profile.email} onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Sistem Rolu</label>
                <input type="text" disabled value={profile.role}
                  className="w-full px-4 py-2 border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-slate-400 rounded-xl text-sm" />
              </div>
            </div>
            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={profileLoading || profileSaving}
                className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Save className="w-4 h-4 mr-2" /> {profileSaving ? "Güncelleniyor..." : "Profili Guncelle"}
              </button>
            </div>
          </form>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                <Activity className="w-4 h-4 mr-2 text-indigo-500" />
                Guvenlik Ayarlari
              </h3>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-slate-800 dark:text-slate-200">Iki Faktorlu Dogrulama (2FA)</div>
                  <div className="text-xs text-slate-400">TOTP (Google Authenticator) dogrulamasini zorunlu kilin.</div>
                </div>
                <button type="button" onClick={() => setSecurity({ ...security, twoFaEnabled: !security.twoFaEnabled })}
                  className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none ${security.twoFaEnabled ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-800'}`}>
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${security.twoFaEnabled ? 'left-5.5' : 'left-0.5'}`} />
                </button>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Maksimum Oturum Zaman Asimi (Dakika)</label>
                <input type="number" value={security.sessionTimeout}
                  onChange={(e) => setSecurity({ ...security, sessionTimeout: Number(e.target.value) })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                <Monitor className="w-4 h-4 mr-2 text-indigo-500" />
                Sistem Arayuz Tercihi
              </h3>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-slate-800 dark:text-slate-200">Karanlik Mod (Dark Mode)</div>
                  <div className="text-xs text-slate-400">Arayuz renklerini gece moduna gecirin.</div>
                </div>
                <button type="button" onClick={toggleTheme}
                  className={`w-11 h-6 rounded-full transition-colors relative focus:outline-none ${theme === 'dark' ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-800'}`}>
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${theme === 'dark' ? 'left-5.5' : 'left-0.5'}`} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---- Backup ---- */}
      {activeTab === "backup" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Server className="w-4 h-4 mr-2 text-indigo-500" />
              Yeni Yedek Olustur
            </h3>
            <p className="text-xs text-slate-500">
              Geri yukleme yalnızca tam yedek ve veritabani yedekleri icin desteklenir.
            </p>
            <div className="flex flex-wrap items-end gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Yedekleme Tipi</label>
                <select value={backupType} onChange={(e) => setBackupType(e.target.value)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="full">Tam Yedek (DB + Config + Arsiv)</option>
                  <option value="db">Sadece Veritabani (PostgreSQL)</option>
                  <option value="config">Sadece Konfigurasyon</option>
                </select>
              </div>
              <button onClick={handleCreateBackup} disabled={backingUp}
                className="inline-flex items-center px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-sm font-semibold transition-colors">
                {backingUp ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                {backingUp ? "Yedekleniyor..." : "Yedek Baslat"}
              </button>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Database className="w-4 h-4 mr-2 text-indigo-500" />
              Yedek Listesi
            </h3>
            {backups.length === 0 ? (
              <p className="text-sm text-slate-400 py-4 text-center">Henuz yedek bulunmuyor.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-100 dark:border-slate-800 text-xs font-semibold text-slate-500 uppercase">
                      <th className="text-left py-3 px-2">Ad</th>
                      <th className="text-left py-3 px-2">Tip</th>
                      <th className="text-left py-3 px-2">Durum</th>
                      <th className="text-left py-3 px-2">Tarih</th>
                      <th className="text-right py-3 px-2">Islem</th>
                    </tr>
                  </thead>
                  <tbody>
                    {backups.map((b: any) => (
                      <tr key={b.id} className="border-b border-slate-50 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/20">
                        <td className="py-3 px-2 font-medium">{b.name}</td>
                        <td className="py-3 px-2">
                          <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                            {b.type}
                          </span>
                        </td>
                        <td className="py-3 px-2">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                            b.status === "completed" ? "bg-emerald-100 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400" :
                            b.status === "running" ? "bg-amber-100 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400" :
                            "bg-rose-100 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400"
                          }`}>
                            {b.status === "completed" ? <CheckCircle className="w-3 h-3 mr-1" /> :
                             b.status === "running" ? <RefreshCw className="w-3 h-3 mr-1 animate-spin" /> :
                             <XCircle className="w-3 h-3 mr-1" />}
                            {b.status === "completed" ? "Tamamlandi" : b.status === "running" ? "Calisiyor" : "Hata"}
                          </span>
                        </td>
                        <td className="py-3 px-2 text-slate-500">{b.created_at ? new Date(b.created_at).toLocaleString("tr-TR") : "-"}</td>
                        <td className="py-3 px-2 text-right">
                          {b.status === "completed" && (b.type === "full" || b.type === "db") && (
                            <button onClick={() => handleRestore(b.id)}
                              className="inline-flex items-center px-2 py-1 text-xs font-medium text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-lg transition-colors mr-1">
                              <Upload className="w-3 h-3 mr-1" /> Geri Yukle
                            </button>
                          )}
                          {b.status === "completed" && b.type === "config" && (
                            <span className="inline-flex items-center px-2 py-1 text-[11px] font-medium text-slate-400 mr-1">
                              Geri yukleme yok
                            </span>
                          )}
                          <button onClick={() => handleDeleteBackup(b.id)}
                            className="inline-flex items-center px-2 py-1 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors">
                            <Trash2 className="w-3 h-3 mr-1" /> Sil
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div className="flex justify-end">
              <button onClick={loadBackups} className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
                <RefreshCw className="w-3 h-3 mr-1" /> Yenile
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---- White-Label ---- */}
      {activeTab === "whitelabel" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Palette className="w-4 h-4 mr-2 text-indigo-500" />
              Beyaz Etiket Yapilandirmasi
            </h3>
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Kapsam (Scope)</label>
                <select value={wlScope} onChange={(e) => setWlScope(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="platform">Platform Geneli</option>
                  <option value="tenant">Tenant</option>
                  <option value="customer">Musteri</option>
                </select>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Marka Adi</label>
                  <input type="text" value={wlConfig.brand_name || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, brand_name: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Ozel Domain</label>
                  <input type="text" value={wlConfig.custom_domain || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, custom_domain: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Ana Renk (Primary)</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={wlConfig.primary_color || "#4F46E5"}
                      onChange={(e) => setWlConfig({ ...wlConfig, primary_color: e.target.value })}
                      className="w-10 h-10 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer" />
                    <input type="text" value={wlConfig.primary_color || ""}
                      onChange={(e) => setWlConfig({ ...wlConfig, primary_color: e.target.value })}
                      className="flex-1 px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Ikincil Renk (Secondary)</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={wlConfig.secondary_color || "#7C3AED"}
                      onChange={(e) => setWlConfig({ ...wlConfig, secondary_color: e.target.value })}
                      className="w-10 h-10 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer" />
                    <input type="text" value={wlConfig.secondary_color || ""}
                      onChange={(e) => setWlConfig({ ...wlConfig, secondary_color: e.target.value })}
                      className="flex-1 px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Vurgu Rengi (Accent)</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={wlConfig.accent_color || "#10B981"}
                      onChange={(e) => setWlConfig({ ...wlConfig, accent_color: e.target.value })}
                      className="w-10 h-10 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer" />
                    <input type="text" value={wlConfig.accent_color || ""}
                      onChange={(e) => setWlConfig({ ...wlConfig, accent_color: e.target.value })}
                      className="flex-1 px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono" />
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Destek E-Posta</label>
                  <input type="email" value={wlConfig.support_email || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, support_email: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Destek Telefon</label>
                  <input type="text" value={wlConfig.support_phone || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, support_phone: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Alt Bilgi Metni (Footer)</label>
                <input type="text" value={wlConfig.footer_text || ""}
                  onChange={(e) => setWlConfig({ ...wlConfig, footer_text: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Kullanim Kosullari URL</label>
                  <input type="url" value={wlConfig.terms_url || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, terms_url: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500">Gizlilik Politikasi URL</label>
                  <input type="url" value={wlConfig.privacy_url || ""}
                    onChange={(e) => setWlConfig({ ...wlConfig, privacy_url: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
            </div>
            <div className="flex justify-end pt-2">
              <button onClick={handleWlSave} className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-colors">
                <Save className="w-4 h-4 mr-2" /> Kaydet
              </button>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                <Upload className="w-4 h-4 mr-2 text-indigo-500" />
                Logo Yukle
              </h3>
              <div className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-6 text-center">
                <input type="file" accept="image/*" onChange={(e) => setLogoFile(e.target.files?.[0] || null)}
                  className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-950/30 file:text-indigo-600 dark:file:text-indigo-400 hover:file:bg-indigo-100" />
                {logoFile && <p className="text-xs text-emerald-600 mt-2">{logoFile.name}</p>}
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                <Upload className="w-4 h-4 mr-2 text-indigo-500" />
                Favicon Yukle
              </h3>
              <div className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-6 text-center">
                <input type="file" accept="image/*,.ico" onChange={(e) => setFaviconFile(e.target.files?.[0] || null)}
                  className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-950/30 file:text-indigo-600 dark:file:text-indigo-400 hover:file:bg-indigo-100" />
                {faviconFile && <p className="text-xs text-emerald-600 mt-2">{faviconFile.name}</p>}
              </div>
            </div>
            <div className="bg-slate-50 dark:bg-slate-950 rounded-xl p-4">
              <h4 className="text-xs font-semibold text-slate-500 mb-2">Onizleme</h4>
              <div className="flex items-center gap-3 p-3 rounded-lg" style={{ backgroundColor: wlConfig.primary_color + "15" || "#EEF2FF" }}>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-xs" style={{ backgroundColor: wlConfig.primary_color || "#4F46E5" }}>
                  H
                </div>
                <div>
                  <div className="text-sm font-semibold" style={{ color: wlConfig.primary_color || "#4F46E5" }}>
                    {wlConfig.brand_name || "Marka Adi"}
                  </div>
                  <div className="text-xs text-slate-400">Portal Branding</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---- SMTP ---- */}
      {activeTab === "smtp" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Mail className="w-4 h-4 mr-2 text-indigo-500" />
              SMTP E-Posta Yapilandirmasi
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">SMTP Sunucu (Host)</label>
                <input type="text" value={smtpConfig.smtp_host || ""}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_host: e.target.value })}
                  placeholder="smtp.example.com"
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">SMTP Port</label>
                <input type="number" value={smtpConfig.smtp_port || 587}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_port: Number(e.target.value) })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Kullanici Adi</label>
                <input type="text" value={smtpConfig.smtp_username || ""}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_username: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Sifre</label>
                <div className="relative">
                  <input type={showPassword ? "text" : "password"} value={smtpConfig.smtp_password || ""}
                    onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_password: e.target.value })}
                    className="w-full px-4 py-2 pr-10 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Gonderici E-Posta (From)</label>
                <input type="email" value={smtpConfig.from_address || ""}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, from_address: e.target.value })}
                  placeholder="noreply@hotspot.local"
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500">Gonderici Adi (From Name)</label>
                <input type="text" value={smtpConfig.from_name || ""}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, from_name: e.target.value })}
                  placeholder="Hotspot Platform"
                  className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2">
                <input type="checkbox" checked={smtpConfig.smtp_use_tls}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_use_tls: e.target.checked })}
                  className="rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500" />
                <span className="text-sm text-slate-700 dark:text-slate-300">TLS Kullan</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" checked={smtpConfig.smtp_use_ssl}
                  onChange={(e) => setSmtpConfig({ ...smtpConfig, smtp_use_ssl: e.target.checked })}
                  className="rounded border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500" />
                <span className="text-sm text-slate-700 dark:text-slate-300">SSL Kullan</span>
              </label>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button onClick={handleSmtpSave} className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition-colors">
                <Save className="w-4 h-4 mr-2" /> Kaydet
              </button>
              <button onClick={handleTestSmtp} disabled={testing || !smtpConfig.smtp_host}
                className="inline-flex items-center px-4 py-2 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl text-sm font-semibold transition-colors disabled:opacity-50">
                {testing ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Activity className="w-4 h-4 mr-2" />}
                {testing ? "Test Ediliyor..." : "Baglantiyi Test Et"}
              </button>
            </div>
            {testResult && (
              <div className={`p-3 rounded-xl text-sm font-medium ${
                testResult.success
                  ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/50"
                  : "bg-rose-50 dark:bg-rose-950/20 text-rose-800 dark:text-rose-400 border border-rose-100 dark:border-rose-900/50"
              }`}>
                {testResult.success ? <CheckCircle className="w-4 h-4 inline mr-1" /> : <XCircle className="w-4 h-4 inline mr-1" />}
                {testResult.message || (testResult.success ? "Baglanti basarili" : "Baglanti basarisiz")}
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Mail className="w-4 h-4 mr-2 text-indigo-500" />
              E-Posta Durumu
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-sm">
                <span className="text-slate-600 dark:text-slate-400">Dogrulama</span>
                <span className={`font-semibold ${smtpConfig.is_verified ? 'text-emerald-600' : 'text-amber-600'}`}>
                  {smtpConfig.is_verified ? 'Dogrulandi' : 'Dogrulanmadi'}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-sm">
                <span className="text-slate-600 dark:text-slate-400">Host</span>
                <span className="font-mono text-xs">{smtpConfig.smtp_host || "-"}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-sm">
                <span className="text-slate-600 dark:text-slate-400">Port</span>
                <span className="font-mono text-xs">{smtpConfig.smtp_port || "-"}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-sm">
                <span className="text-slate-600 dark:text-slate-400">Guvenlik</span>
                <span className="text-xs">
                  {smtpConfig.smtp_use_ssl ? "SSL" : smtpConfig.smtp_use_tls ? "STARTTLS" : "Yok"}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---- Dashboard / Health ---- */}
      {activeTab === "dashboard" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
              <Activity className="w-4 h-4 mr-2 text-indigo-500" />
              Sistem Sagligi
            </h3>
            {!health ? (
              <div className="flex items-center justify-center py-8">
                <RefreshCw className="w-6 h-6 text-indigo-500 animate-spin" />
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <div className="flex items-center gap-2 text-sm font-medium mb-1">
                    <Database className="w-4 h-4 text-indigo-500" />
                    Veritabani
                  </div>
                  <span className={`text-xs font-semibold ${health.database === "ok" ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {health.database === "ok" ? 'Calisiyor' : health.database}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <div className="flex items-center gap-2 text-sm font-medium mb-1">
                    <Server className="w-4 h-4 text-indigo-500" />
                    Redis
                  </div>
                  <span className={`text-xs font-semibold ${health.redis === "ok" ? 'text-emerald-600' : health.redis === "unknown" ? 'text-slate-400' : 'text-rose-600'}`}>
                    {health.redis === "ok" ? 'Calisiyor' : health.redis === "unknown" ? 'Bilinmiyor' : health.redis}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <div className="flex items-center gap-2 text-sm font-medium mb-1">
                    <HardDrive className="w-4 h-4 text-indigo-500" />
                    MinIO
                  </div>
                  <span className={`text-xs font-semibold ${health.minio === "ok" ? 'text-emerald-600' : health.minio === "unknown" ? 'text-slate-400' : 'text-rose-600'}`}>
                    {health.minio === "ok" ? 'Calisiyor' : health.minio === "unknown" ? 'Bilinmiyor' : health.minio}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <div className="flex items-center gap-2 text-sm font-medium mb-1">
                    <Users className="w-4 h-4 text-indigo-500" />
                    Celery Worker
                  </div>
                  <span className={`text-xs font-semibold ${health.celery?.includes("ok") ? 'text-emerald-600' : 'text-amber-600'}`}>
                    {health.celery || "Bilinmiyor"}
                  </span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl">
                  <div className="flex items-center gap-2 text-sm font-medium mb-1">
                    <Clock className="w-4 h-4 text-indigo-500" />
                    Disk Kullanimi
                  </div>
                  <span className="text-xs font-semibold text-slate-600">
                    {health.disk_usage?.percent_used != null ? `%${health.disk_usage.percent_used}` : "-"}
                  </span>
                </div>
              </div>
            )}
            <div className="flex justify-end">
              <button onClick={() => getSystemHealth().then(setHealth)}
                className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
                <RefreshCw className="w-3 h-3 mr-1" /> Yenile
              </button>
            </div>
          </div>

          {health?.disk_usage && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
                <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                  <HardDrive className="w-4 h-4 mr-2 text-indigo-500" />
                  Disk Kullanim Detayi
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm"><span className="text-slate-500">Toplam</span><span className="font-semibold">{health.disk_usage.total_gb} GB</span></div>
                  <div className="flex justify-between text-sm"><span className="text-slate-500">Kullanilan</span><span className="font-semibold">{health.disk_usage.used_gb} GB</span></div>
                  <div className="flex justify-between text-sm"><span className="text-slate-500">Bos</span><span className="font-semibold">{health.disk_usage.free_gb} GB</span></div>
                  <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-2">
                    <div className="bg-indigo-600 h-2 rounded-full" style={{ width: `${Math.min(health.disk_usage.percent_used, 100)}%` }} />
                  </div>
                </div>
              </div>
              {health.memory_usage && (
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
                  <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center border-b border-slate-100 dark:border-slate-800 pb-3">
                    <Smartphone className="w-4 h-4 mr-2 text-indigo-500" />
                    Bellek Kullanimi
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm"><span className="text-slate-500">Toplam</span><span className="font-semibold">{health.memory_usage.total_gb} GB</span></div>
                    <div className="flex justify-between text-sm"><span className="text-slate-500">Kullanilabilir</span><span className="font-semibold">{health.memory_usage.available_gb} GB</span></div>
                    <div className="flex justify-between text-sm"><span className="text-slate-500">Kullanim</span><span className="font-semibold">%{health.memory_usage.percent_used}</span></div>
                    <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-2">
                      <div className="bg-indigo-600 h-2 rounded-full" style={{ width: `${Math.min(health.memory_usage.percent_used, 100)}%` }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
