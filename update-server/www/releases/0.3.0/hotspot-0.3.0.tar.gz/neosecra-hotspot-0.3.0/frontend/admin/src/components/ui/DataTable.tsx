import React from "react";

interface Column<T> {
  header: string;
  accessor: keyof T;
}

interface Props<T> {
  columns: Column<T>[];
  data: T[];
  className?: string;
}

export function DataTable<T extends Record<string, any>>({ columns, data, className = "" }: Props<T>) {
  return (
    <div className={`w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm ${className}`}>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
              {columns.map((col) => (
                <th
                  key={String(col.accessor)}
                  className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400"
                >
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {data.map((row, i) => (
              <tr 
                key={i} 
                className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors duration-150"
              >
                {columns.map((col) => {
                  const value = row[col.accessor];
                  return (
                    <td 
                      key={String(col.accessor)} 
                      className="px-6 py-4 text-sm text-slate-700 dark:text-slate-200"
                    >
                      {/* Highlight status badge specially or keep it normal */}
                      {col.accessor === 'status' && typeof value === 'string' ? (
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          value.toLowerCase() === 'aktif' || value.toLowerCase() === 'online' || value.toLowerCase() === 'completed'
                            ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}>
                          {value}
                        </span>
                      ) : (
                        String(value)
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
