import React, { useState, useEffect } from "react";
import {
  getDevices,
  getLocations,
  getVendorCapabilities,
  addDevice,
  deleteDevice,
  getDeviceCredential,
  setDeviceCredential,
  testDeviceConnection,
  refreshDeviceInfo,
  syncActiveSessions,
} from "../lib/api";
import type { DeviceCredentialMetadata } from "../lib/api";
import {
  Plus,
  Trash2,
  Search,
  Server,
  Play,
  CheckCircle2,
  XCircle,
  RefreshCw,
  AlertTriangle,
  WifiOff,
  HardDrive,
  Shield,
  ShieldOff,
  Check,
  X,
  Wifi,
} from "lucide-react";

interface Device {
  id: string;
  name: string;
  vendor: string;
  model: string;
  mgmt_ip: string;
  location_id: string;
  locationName: string;
  status: string;
  serial_number?: string | null;
  firmware_version?: string | null;
  last_seen_at?: string | null;
  meta?: Record<string, any>;
}

interface LocationOption {
  id: string;
  name: string;
}

interface VendorOption {
  vendor: string;
  display_name: string;
}

// Only firewall/gateway integrations belong in the Hotspot device registry.
// Switch/AP/controller brands are intentionally not exposed here: Hotspot
// does not manage ports, NAC or 802.1X infrastructure.
const FALLBACK_VENDOR_OPTIONS: VendorOption[] = [
  { vendor: "fortigate", display_name: "Fortinet" },
];

const HOTSPOT_VENDOR_IDS = new Set(FALLBACK_VENDOR_OPTIONS.map((option) => option.vendor));

export const DevicesPage: React.FC = () => {
  const [devices, setDevices] = useState<Device[]>([]);
  const [locations, setLocations] = useState<LocationOption[]>([]);
  const [vendorOptions, setVendorOptions] = useState<VendorOption[]>(FALLBACK_VENDOR_OPTIONS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [refreshingId, setRefreshingId] = useState<string | null>(null);
  const [syncingId, setSyncingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ id: string; success: boolean; msg: string } | null>(null);
  const [credentials, setCredentials] = useState<Record<string, DeviceCredentialMetadata | null>>({});
  const [credentialDevice, setCredentialDevice] = useState<Device | null>(null);
  const [credentialForm, setCredentialForm] = useState({
    api_token: "",
    api_username: "",
    api_vdom: "root",
    verify_tls: true,
  });
  const [credentialSaving, setCredentialSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    vendor: "fortigate",
    model: "",
    mgmtIp: "",
    locationId: "",
    apiPort: 443,
    apiToken: "",
    apiUsername: "",
    apiVdom: "root",
    verifyTls: true,
    apiTls: true,
  });

  const isOffline = error === "offline";

  const formatDate = (value?: string | null) => {
    if (!value) return "—";
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return "—";
    return parsed.toLocaleString("tr-TR");
  };

  const readMetric = (meta: Record<string, any> | undefined, ...keys: string[]) => {
    if (!meta) return null;
    for (const key of keys) {
      const value = meta[key];
      if (typeof value === "number" && Number.isFinite(value)) return value;
      if (typeof value === "string" && value.trim()) {
        const parsed = Number(value);
        if (Number.isFinite(parsed)) return parsed;
      }
    }
    return null;
  };

  const readMetaString = (meta: Record<string, any> | undefined, ...keys: string[]) => {
    if (!meta) return null;
    for (const key of keys) {
      const value = meta[key];
      if (typeof value === "string" && value.trim()) return value.trim();
    }
    return null;
  };

  const normalizeDevice = (device: any, locationLookup: Record<string, string>): Device => {
    const locationId = String(device.location_id || device.locationId || "");
    return {
      id: String(device.id),
      name: String(device.name || ""),
      vendor: String(device.vendor || ""),
      model: String(device.model || ""),
      mgmt_ip: String(device.mgmt_ip || device.mgmtIp || ""),
      location_id: locationId,
      locationName: locationLookup[locationId] || String(device.locationName || device.location_name || locationId || "—"),
      status: String(device.status || "unknown"),
      serial_number: device.serial_number ?? device.serialNumber ?? null,
      firmware_version: device.firmware_version ?? device.firmwareVersion ?? null,
      last_seen_at: device.last_seen_at ?? device.lastSeenAt ?? null,
      meta: device.meta || {},
    };
  };

  const loadDevices = async () => {
    setLoading(true);
    setError(null);
    try {
      const [deviceData, locationData, vendorData] = await Promise.all([
        getDevices(),
        getLocations().catch(() => []),
        getVendorCapabilities().catch(() => []),
      ]);
      const locationLookup = Object.fromEntries(
        (locationData || []).map((location: any) => [String(location.id), String(location.name || location.id)])
      );
      setLocations((locationData || []).map((location: any) => ({
        id: String(location.id),
        name: String(location.name || location.id),
      })));
      const apiVendors = (vendorData || [])
        .map((item: any) => String(item.vendor || "").trim().toLowerCase())
        .filter((vendor: string) => HOTSPOT_VENDOR_IDS.has(vendor));
      setVendorOptions(
        apiVendors.length > 0
          ? apiVendors.map((vendor: string) => ({
              vendor,
              display_name: FALLBACK_VENDOR_OPTIONS.find((option) => option.vendor === vendor)?.display_name || vendor,
            }))
          : FALLBACK_VENDOR_OPTIONS,
      );
      const normalizedDevices = (deviceData || []).map((device: any) => normalizeDevice(device, locationLookup));
      setDevices(normalizedDevices);
      const credentialEntries = await Promise.all(
        normalizedDevices.map(async (device) => [device.id, await getDeviceCredential(device.id).catch(() => null)] as const),
      );
      setCredentials(Object.fromEntries(credentialEntries));
    } catch (err: any) {
      console.error(err);
      if (err instanceof TypeError || err.message?.includes("Failed to fetch") || err.message?.includes("NetworkError")) {
        setError("offline");
      } else {
        setError(err?.message || "Cihazlar yüklenirken bir hata oluştu.");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDevices();
  }, []);

  const filtered = devices.filter(
    (d) =>
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      d.model.toLowerCase().includes(search.toLowerCase()) ||
      d.mgmt_ip.toLowerCase().includes(search.toLowerCase()) ||
      d.locationName.toLowerCase().includes(search.toLowerCase()) ||
      (d.serial_number && d.serial_number.toLowerCase().includes(search.toLowerCase())) ||
      (d.firmware_version && d.firmware_version.toLowerCase().includes(search.toLowerCase()))
  );

  const onlineCount = devices.filter((device) => device.status === "online").length;
  const warningCount = devices.filter((device) => device.status === "warning").length;
  const offlineCount = devices.filter((device) => device.status === "offline").length;
  const recentCount = devices.filter((device) => {
    if (!device.last_seen_at) return false;
    const parsed = new Date(device.last_seen_at);
    if (Number.isNaN(parsed.getTime())) return false;
    return Date.now() - parsed.getTime() < 24 * 60 * 60 * 1000;
  }).length;

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.mgmtIp || !formData.locationId) return;

    try {
      if (formData.vendor === "fortigate" && !formData.apiToken.trim()) {
        setError("FortiGate cihazı için API token zorunludur.");
        return;
      }

      const newDev = await addDevice({
        name: formData.name,
        vendor: formData.vendor,
        model: formData.model || "Genel Cihaz",
        location_id: formData.locationId,
        mgmt_ip: formData.mgmtIp,
        api_host: formData.mgmtIp,
        api_port: formData.apiPort,
        meta: {
          device_type: "firewall",
          api_tls: formData.apiTls,
        },
      });
      let credentialError: any = null;
      if (formData.apiToken.trim() || formData.apiUsername.trim()) {
        try {
          const savedCredential = await setDeviceCredential(String(newDev.id), {
            api_token: formData.apiToken.trim() || undefined,
            api_username: formData.apiUsername.trim() || undefined,
            api_vdom: formData.apiVdom.trim() || undefined,
            verify_tls: formData.verifyTls,
          });
          setCredentials((prev) => ({ ...prev, [String(newDev.id)]: savedCredential }));
        } catch (err) {
          credentialError = err;
        }
      }
      const locationLookup = Object.fromEntries(locations.map((location) => [location.id, location.name]));
      setDevices((prev) => [normalizeDevice(newDev, locationLookup), ...prev]);
      setFormData({ name: "", vendor: vendorOptions[0]?.vendor || "fortigate", model: "", mgmtIp: "", locationId: "", apiPort: 443, apiToken: "", apiUsername: "", apiVdom: "root", verifyTls: true, apiTls: true });
      setShowAddForm(false);
      setError(null);
      if (credentialError) {
        setTestResult({
          id: String(newDev.id),
          success: false,
          msg: `Cihaz eklendi ancak kimlik bilgileri kaydedilemedi: ${credentialError?.message || "bilinmeyen hata"}`,
        });
      }
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Cihaz eklenemedi.");
    }
  };

  const openCredentialEditor = async (device: Device) => {
    const cached = credentials[device.id];
    const existing = cached !== undefined ? cached : await getDeviceCredential(device.id).catch(() => null);
    if (existing) {
      setCredentials((prev) => ({ ...prev, [device.id]: existing }));
    }
    setCredentialForm({
      api_token: "",
      api_username: existing?.api_username || "",
      api_vdom: existing?.api_vdom || "root",
      verify_tls: existing?.verify_tls !== false,
    });
    setCredentialDevice(device);
  };

  const handleCredentialSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!credentialDevice) return;
    setCredentialSaving(true);
    try {
      const current = credentials[credentialDevice.id];
      if (!current?.has_token && !credentialForm.api_token.trim()) {
        throw new Error("İlk kayıt için API token zorunludur.");
      }
      const saved = await setDeviceCredential(credentialDevice.id, {
        api_token: credentialForm.api_token || undefined,
        api_username: credentialForm.api_username || undefined,
        api_vdom: credentialForm.api_vdom || undefined,
        verify_tls: credentialForm.verify_tls,
      });
      setCredentials((prev) => ({ ...prev, [credentialDevice.id]: saved }));
      setCredentialDevice(null);
      setTestResult({ id: credentialDevice.id, success: true, msg: "Cihaz kimlik bilgileri kaydedildi." });
    } catch (err: any) {
      setTestResult({ id: credentialDevice.id, success: false, msg: err?.message || "Kimlik bilgileri kaydedilemedi." });
    } finally {
      setCredentialSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm("Bu cihazı silmek istediğinize emin misiniz?")) {
      try {
        await deleteDevice(id);
        setDevices(devices.filter((d) => d.id !== id));
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleTestConnection = async (id: string, name: string, ip: string) => {
    setTestingId(id);
    setTestResult(null);
    try {
      const res = await testDeviceConnection(id);
      if (res.success) {
        setDevices((prev) => prev.map((device) => (
          device.id === id ? { ...device, status: "online", last_seen_at: new Date().toISOString() } : device
        )));
      } else {
        setDevices((prev) => prev.map((device) => (
          device.id === id ? { ...device, status: "warning" } : device
        )));
      }
      setTestResult({
        id,
        success: res.success,
        msg: res.message || `${name} bağlantısı tamamlandı.`,
      });
      const refreshedCredential = await getDeviceCredential(id).catch(() => null);
      setCredentials((prev) => ({ ...prev, [id]: refreshedCredential }));
    } catch (err: any) {
      setDevices((prev) => prev.map((device) => (
        device.id === id ? { ...device, status: "offline" } : device
      )));
      setTestResult({
        id,
        success: false,
        msg: err.message || "Bilinmeyen bağlantı hatası.",
      });
    } finally {
      setTestingId(null);
    }
  };

  const handleRefreshDeviceInfo = async (id: string) => {
    setRefreshingId(id);
    try {
      const result = await refreshDeviceInfo(id);
      if (result) {
        setDevices((prev) => prev.map((device) => {
          if (device.id !== id) return device;
          // `discover` returns a partial authoritative info object rather
          // than a complete Device row; never overwrite the row with
          // undefined/id-less fields.
          return {
            ...device,
            model: result.model || device.model,
            serial_number: result.serial_number || device.serial_number,
            firmware_version: result.firmware_version || device.firmware_version,
          };
        }));
      }
      setTestResult({ id, success: true, msg: "Cihaz bilgileri güncellendi." });
    } catch (err: any) {
      console.error("Refresh failed:", err);
      setTestResult({ id, success: false, msg: err?.message || "Cihaz bilgileri alınamadı." });
    } finally {
      setRefreshingId(null);
    }
  };

  const handleSyncSessions = async (id: string) => {
    setSyncingId(id);
    try {
      const result = await syncActiveSessions(id);
      const count = Array.isArray(result)
        ? result.length
        : Array.isArray(result?.sessions) ? result.sessions.length : null;
      setTestResult({
        id,
        success: true,
        msg: count === null ? "Cihaz oturumları sorgulandı." : `${count} aktif oturum cihazdan alındı.`,
      });
    } catch (err: any) {
      console.error("Sync sessions failed:", err);
      setTestResult({ id, success: false, msg: err?.message || "Cihaz oturumları alınamadı." });
    } finally {
      setSyncingId(null);
    }
  };

  const renderCredentialFields = () => (
    <div className="md:col-span-2 rounded-xl border border-indigo-100 dark:border-indigo-900/40 bg-indigo-50/50 dark:bg-indigo-950/20 p-4 space-y-3">
      <div>
        <div className="text-sm font-semibold text-slate-800 dark:text-slate-100">FortiGate API erişimi</div>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          Canlı veri çekmek için FortiGate üzerinde oluşturduğunuz REST API tokenını girin. Token şifrelenerek saklanır ve tekrar gösterilmez.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-300">
          API token {formData.vendor === "fortigate" ? "*" : "(opsiyonel)"}
          <input
            type="password"
            value={formData.apiToken}
            onChange={(e) => setFormData((prev) => ({ ...prev, apiToken: e.target.value }))}
            placeholder="FortiGate REST API token"
            required={formData.vendor === "fortigate"}
            autoComplete="new-password"
            className="mt-1 w-full px-3 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </label>
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-300">
          API kullanıcı adı (opsiyonel)
          <input
            value={formData.apiUsername}
            onChange={(e) => setFormData((prev) => ({ ...prev, apiUsername: e.target.value }))}
            placeholder="API admin adı"
            autoComplete="off"
            className="mt-1 w-full px-3 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </label>
        <label className="block text-xs font-medium text-slate-600 dark:text-slate-300">
          VDOM
          <input
            value={formData.apiVdom}
            onChange={(e) => setFormData((prev) => ({ ...prev, apiVdom: e.target.value }))}
            placeholder="root"
            className="mt-1 w-full px-3 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </label>
        <div className="flex flex-col justify-end gap-2 text-xs text-slate-600 dark:text-slate-300">
          <label className="inline-flex items-center gap-2">
            <input
              type="checkbox"
              checked={formData.apiTls}
              onChange={(e) => setFormData((prev) => ({ ...prev, apiTls: e.target.checked }))}
              className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
            />
            HTTPS kullan (önerilen)
          </label>
          <label className="inline-flex items-center gap-2">
            <input
              type="checkbox"
              checked={formData.verifyTls}
              onChange={(e) => setFormData((prev) => ({ ...prev, verifyTls: e.target.checked }))}
              disabled={!formData.apiTls}
              className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 disabled:opacity-50"
            />
            TLS sertifikasını doğrula
          </label>
        </div>
      </div>
      {!formData.apiTls && (
        <p className="text-[11px] text-amber-700 dark:text-amber-400">
          HTTP yalnızca yerel simulator/lab ortamı için kullanılmalı; üretimde HTTPS ve sertifika doğrulaması açık kalmalıdır.
        </p>
      )}
    </div>
  );

  // Loading Skeleton
  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Cihazlar</h2>
            <p className="text-sm text-slate-500">Captive portal için yalnızca firewall/gateway bağlantılarını yönetin ve API durumlarını izleyin.</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm animate-pulse">
              <div className="h-3 w-20 bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="mt-2 h-8 w-16 bg-slate-200 dark:bg-slate-800 rounded" />
            </div>
          ))}
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
          <div className="p-6 space-y-4 animate-pulse">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex gap-4">
                <div className="h-4 w-1/4 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/6 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/6 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/6 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/6 bg-slate-200 dark:bg-slate-800 rounded" />
                <div className="h-4 w-1/12 bg-slate-200 dark:bg-slate-800 rounded" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Error / Offline State
  if (error && devices.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Cihazlar</h2>
            <p className="text-sm text-slate-500">Captive portal için yalnızca firewall/gateway bağlantılarını yönetin ve API durumlarını izleyin.</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 shadow-sm">
          <div className="flex flex-col items-center justify-center text-center">
            {isOffline ? (
              <>
                <div className="p-4 rounded-full bg-amber-100 dark:bg-amber-900/30 mb-4">
                  <WifiOff className="w-10 h-10 text-amber-600 dark:text-amber-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50 mb-2">Sunucuya Bağlanılamıyor</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6">
                  Backend sunucusuna ulaşılamıyor. İnternet bağlantınızı ve API adresini kontrol edin.
                </p>
              </>
            ) : (
              <>
                <div className="p-4 rounded-full bg-rose-100 dark:bg-rose-900/30 mb-4">
                  <AlertTriangle className="w-10 h-10 text-rose-600 dark:text-rose-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50 mb-2">Yükleme Hatası</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6">{error}</p>
              </>
            )}
            <button
              onClick={loadDevices}
              className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Tekrar Dene
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Empty State
  if (!loading && devices.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Cihazlar</h2>
          <p className="text-sm text-slate-500">Captive portal için yalnızca firewall/gateway bağlantılarını yönetin ve API durumlarını izleyin.</p>
          </div>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            Yeni Cihaz Ekle
          </button>
        </div>
        {showAddForm && (
          <form onSubmit={handleAddSubmit} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center">
              <Server className="w-4 h-4 mr-2 text-indigo-500" />
              Yeni Firewall Cihazı Ekle
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input value={formData.name} onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))} placeholder="Cihaz Adı *" required className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              <input value={formData.mgmtIp} onChange={(e) => setFormData((prev) => ({ ...prev, mgmtIp: e.target.value }))} placeholder="Yönetim IP *" required className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              <select value={formData.vendor} onChange={(e) => setFormData((prev) => ({ ...prev, vendor: e.target.value }))} className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                {vendorOptions.map((option) => (
                  <option key={option.vendor} value={option.vendor}>{option.display_name}</option>
                ))}
              </select>
              <input value={formData.model} onChange={(e) => setFormData((prev) => ({ ...prev, model: e.target.value }))} placeholder="Cihaz Modeli" className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              <select value={formData.locationId} onChange={(e) => setFormData((prev) => ({ ...prev, locationId: e.target.value }))} required className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="">Lokasyon Seç *</option>
                {locations.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}
              </select>
              <input type="number" value={formData.apiPort} onChange={(e) => setFormData((prev) => ({ ...prev, apiPort: Number(e.target.value) }))} placeholder="API Port (443)" className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              {renderCredentialFields()}
            </div>
            <div className="flex justify-end gap-3">
              <button type="button" onClick={() => setShowAddForm(false)} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors">İptal</button>
              <button type="submit" className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors">Ekle</button>
            </div>
          </form>
        )}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 shadow-sm">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="p-4 rounded-full bg-slate-100 dark:bg-slate-800 mb-4">
              <Server className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50 mb-2">Henüz Cihaz Yok</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mb-6">
              Sistemde kayıtlı hiçbir cihaz bulunamadı. Yeni bir cihaz eklemek için "Yeni Cihaz Ekle" butonuna tıklayın.
            </p>
            <button
              onClick={() => setShowAddForm(true)}
              className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              İlk Cihazı Ekle
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Main Content
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Cihazlar</h2>
          <p className="text-sm text-slate-500">Captive portal için yalnızca firewall/gateway bağlantılarını yönetin ve API durumlarını izleyin.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={loadDevices}
            className="inline-flex items-center px-3 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-colors"
          >
            <RefreshCw className="w-4 h-4 mr-1.5" />
            Yenile
          </button>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            Yeni Cihaz Ekle
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
          <div className="text-xs uppercase tracking-wider text-slate-500">Toplam Cihaz</div>
          <div className="mt-2 text-3xl font-extrabold text-slate-900 dark:text-slate-100">{devices.length}</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900/40 rounded-2xl p-4 shadow-sm">
          <div className="text-xs uppercase tracking-wider text-emerald-500">Aktif</div>
          <div className="mt-2 text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">{onlineCount}</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-900/40 rounded-2xl p-4 shadow-sm">
          <div className="text-xs uppercase tracking-wider text-amber-500">Uyarı</div>
          <div className="mt-2 text-3xl font-extrabold text-amber-600 dark:text-amber-400">{warningCount}</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/40 rounded-2xl p-4 shadow-sm">
          <div className="text-xs uppercase tracking-wider text-rose-500">Çevrimdışı</div>
          <div className="mt-2 text-3xl font-extrabold text-rose-600 dark:text-rose-400">{offlineCount}</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
          <div className="text-xs uppercase tracking-wider text-slate-500">Son 24 Saat</div>
          <div className="mt-2 text-3xl font-extrabold text-slate-900 dark:text-slate-100">{recentCount}</div>
        </div>
      </div>

      {/* Offline Banner */}
      {isOffline && (
        <div className="flex items-center gap-3 px-4 py-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/30 rounded-2xl text-sm text-amber-700 dark:text-amber-400">
          <WifiOff className="w-5 h-5 flex-shrink-0" />
          <span>Sunucuya bağlantı kurulamıyor. Veriler önbellekten gösteriliyor olabilir.</span>
        </div>
      )}

      {/* Add Form */}
      {showAddForm && (
        <form onSubmit={handleAddSubmit} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center">
            <Server className="w-4 h-4 mr-2 text-indigo-500" />
            Yeni Firewall Cihazı Ekle
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input value={formData.name} onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))} placeholder="Cihaz Adı *" required className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            <input value={formData.mgmtIp} onChange={(e) => setFormData((prev) => ({ ...prev, mgmtIp: e.target.value }))} placeholder="Yönetim IP *" required className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            <select value={formData.vendor} onChange={(e) => setFormData((prev) => ({ ...prev, vendor: e.target.value }))} className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
              {vendorOptions.map((option) => (
                <option key={option.vendor} value={option.vendor}>{option.display_name}</option>
              ))}
            </select>
            <input value={formData.model} onChange={(e) => setFormData((prev) => ({ ...prev, model: e.target.value }))} placeholder="Cihaz Modeli" className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            <select value={formData.locationId} onChange={(e) => setFormData((prev) => ({ ...prev, locationId: e.target.value }))} required className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option value="">Lokasyon Seç *</option>
              {locations.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}
            </select>
            <input type="number" value={formData.apiPort} onChange={(e) => setFormData((prev) => ({ ...prev, apiPort: Number(e.target.value) }))} placeholder="API Port (443)" className="w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            {renderCredentialFields()}
          </div>
          <div className="flex justify-end gap-3">
            <button type="button" onClick={() => setShowAddForm(false)} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors">İptal</button>
            <button type="submit" className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors">Ekle</button>
          </div>
        </form>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-3 text-slate-400 w-4 h-4" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Cihaz adı, model, IP, seri no veya firmware ara..."
          className="w-full pl-11 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
        />
      </div>

      {/* Table */}
      <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Cihaz</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Vendor / Model</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Seri No</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Firmware</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">VDOM</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">TLS</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Kimlik</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Yönetim IP</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Lokasyon</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Son Test</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Durum</th>
                <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((d) => {
                const meta = d.meta || {};
                const credential = credentials[d.id];
                const vdom = credential?.api_vdom || readMetaString(meta, "vdom", "VDOM");
                const verifyTls = credential ? credential.verify_tls : meta.verify_tls !== false;
                const hasCredential = Boolean(credential?.has_token);
                const lastTest = credential?.last_check_at || readMetaString(meta, "last_test_at", "lastTestAt", "lastConnectionTest");

                return (
                  <tr key={d.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                          d.status === "online" ? "bg-emerald-500" :
                          d.status === "warning" ? "bg-amber-500" :
                          d.status === "offline" ? "bg-rose-500" : "bg-slate-400"
                        }`} />
                        <div>
                          <div className="text-sm font-semibold text-slate-950 dark:text-slate-50 truncate max-w-[140px]">{d.name}</div>
                          <div className="text-[11px] text-slate-400">
                            {d.status === "online" ? "Çevrimiçi" : d.status === "warning" ? "Uyarı" : d.status === "offline" ? "Çevrimdışı" : "Bilinmiyor"}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <div className="font-medium text-slate-700 dark:text-slate-300">
                        {d.vendor === "fortigate" ? "Fortinet" : d.vendor}
                      </div>
                      <div className="text-xs text-slate-400">{d.model || "—"}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs font-mono text-slate-600 dark:text-slate-400">
                        {d.serial_number || "—"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-400">
                      {d.firmware_version ? (
                        <span className="inline-flex items-center gap-1">
                          <HardDrive className="w-3 h-3 text-slate-400" />
                          {d.firmware_version}
                        </span>
                      ) : "—"}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600 dark:text-slate-400">
                      {vdom || "—"}
                    </td>
                    <td className="px-6 py-4">
                      {verifyTls ? (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                          <Shield className="w-3.5 h-3.5" />
                          TLS
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600 dark:text-amber-400" title="TLS doğrulaması devre dışı">
                          <ShieldOff className="w-3.5 h-3.5" />
                          Uyarı
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {hasCredential ? (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                          <Check className="w-3.5 h-3.5" />
                          Var
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-400">
                          <X className="w-3.5 h-3.5" />
                          Yok
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm font-mono text-xs text-slate-500">{d.mgmt_ip}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{d.locationName}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {lastTest ? (
                        <span className="text-xs">{formatDate(lastTest)}</span>
                      ) : (
                        <span className="text-xs text-slate-400">Test edilmedi</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                        d.status === "online"
                          ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30"
                          : d.status === "warning"
                          ? "bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-900/30"
                          : d.status === "offline"
                          ? "bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-900/30"
                          : "bg-slate-50 dark:bg-slate-950/30 text-slate-700 dark:text-slate-400 border-slate-100 dark:border-slate-900/30"
                      }`}>
                        {d.status === "online" ? "Aktif" : d.status === "warning" ? "Uyarı" : d.status === "offline" ? "Bağlantı Yok" : "Bilinmiyor"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => openCredentialEditor(d)}
                          title="Kimlik Bilgilerini Yönet"
                          className={`inline-flex items-center p-2 rounded-xl transition-all ${
                            hasCredential
                              ? "text-emerald-600 hover:text-emerald-950 dark:text-emerald-400 dark:hover:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/30"
                              : "text-amber-600 hover:text-amber-950 dark:text-amber-400 dark:hover:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/30"
                          }`}
                        >
                          <Shield className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleTestConnection(d.id, d.name, d.mgmt_ip)}
                          disabled={testingId === d.id}
                          title="Test Et"
                          className="inline-flex items-center text-indigo-600 hover:text-indigo-950 dark:text-indigo-400 dark:hover:text-indigo-300 p-2 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-xl transition-all disabled:opacity-50"
                        >
                          <Play className={`w-4 h-4 ${testingId === d.id ? "animate-spin" : ""}`} />
                        </button>
                        <button
                          onClick={() => handleRefreshDeviceInfo(d.id)}
                          disabled={refreshingId === d.id}
                          title="Cihaz Bilgilerini Yenile"
                          className="inline-flex items-center text-sky-600 hover:text-sky-950 dark:text-sky-400 dark:hover:text-sky-300 p-2 hover:bg-sky-50 dark:hover:bg-sky-950/30 rounded-xl transition-all disabled:opacity-50"
                        >
                          <RefreshCw className={`w-4 h-4 ${refreshingId === d.id ? "animate-spin" : ""}`} />
                        </button>
                        <button
                          onClick={() => handleSyncSessions(d.id)}
                          disabled={syncingId === d.id}
                          title="Oturumları Senkronize Et"
                          className="inline-flex items-center text-emerald-600 hover:text-emerald-950 dark:text-emerald-400 dark:hover:text-emerald-300 p-2 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 rounded-xl transition-all disabled:opacity-50"
                        >
                          <Wifi className={`w-4 h-4 ${syncingId === d.id ? "animate-spin" : ""}`} />
                        </button>
                        <button
                          onClick={() => handleDelete(d.id)}
                          title="Sil"
                          className="text-rose-600 hover:text-rose-900 dark:hover:text-rose-400 p-2 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-colors inline-flex"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      {testResult && testResult.id === d.id && (
                        <div className={`mt-2 text-[11px] flex items-center gap-1 ${
                          testResult.success ? "text-emerald-600" : "text-rose-600"
                        }`}>
                          {testResult.success ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                          <span className="truncate max-w-[160px]">{testResult.msg}</span>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={12} className="px-6 py-12 text-center text-slate-500">
                    <div className="flex flex-col items-center gap-2">
                      <Search className="w-5 h-5 text-slate-400" />
                      <span>Arama kriterlerinize uygun cihaz bulunamadı.</span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {credentialDevice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4" role="dialog" aria-modal="true" aria-labelledby="credential-dialog-title">
          <form onSubmit={handleCredentialSave} className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 id="credential-dialog-title" className="text-lg font-semibold text-slate-950 dark:text-slate-50">Kimlik Bilgileri</h3>
                <p className="mt-1 text-sm text-slate-500">{credentialDevice.name} · {credentialDevice.mgmt_ip}</p>
              </div>
              <button type="button" onClick={() => setCredentialDevice(null)} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Kapat">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50 p-3 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex items-center gap-2 font-medium">
                {credentials[credentialDevice.id]?.has_token ? <Check className="w-4 h-4 text-emerald-500" /> : <AlertTriangle className="w-4 h-4 text-amber-500" />}
                {credentials[credentialDevice.id]?.has_token ? "API token kayıtlı" : "API token henüz tanımlı değil"}
              </div>
              <p className="mt-1">Token güvenlik nedeniyle burada gösterilmez. Yeni token girerseniz eskisi döndürülür; alanı boş bırakmak mevcut tokenı korur.</p>
            </div>

            <div className="space-y-4">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                API token {credentials[credentialDevice.id]?.has_token ? "(değiştirmek için)" : "*"}
                <input
                  type="password"
                  value={credentialForm.api_token}
                  onChange={(e) => setCredentialForm((prev) => ({ ...prev, api_token: e.target.value }))}
                  placeholder={credentials[credentialDevice.id]?.has_token ? "Değiştirmeyecekseniz boş bırakın" : "FortiGate REST API token"}
                  required={!credentials[credentialDevice.id]?.has_token}
                  autoComplete="new-password"
                  className="mt-1 w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                  API kullanıcı adı
                  <input
                    value={credentialForm.api_username}
                    onChange={(e) => setCredentialForm((prev) => ({ ...prev, api_username: e.target.value }))}
                    placeholder="API admin adı (opsiyonel)"
                    autoComplete="off"
                    className="mt-1 w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </label>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                  VDOM
                  <input
                    value={credentialForm.api_vdom}
                    onChange={(e) => setCredentialForm((prev) => ({ ...prev, api_vdom: e.target.value }))}
                    placeholder="root"
                    className="mt-1 w-full px-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </label>
              </div>
              <label className="inline-flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                <input
                  type="checkbox"
                  checked={credentialForm.verify_tls}
                  onChange={(e) => setCredentialForm((prev) => ({ ...prev, verify_tls: e.target.checked }))}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                />
                TLS sertifikasını doğrula
              </label>
              {!credentialForm.verify_tls && (
                <p className="text-xs text-amber-700 dark:text-amber-400">TLS doğrulaması kapalı. Bu ayarı yalnızca self-signed sertifikalı lab cihazlarında kullanın.</p>
              )}
            </div>

            <div className="flex justify-end gap-3">
              <button type="button" onClick={() => setCredentialDevice(null)} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl">İptal</button>
              <button type="submit" disabled={credentialSaving} className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-sm font-semibold">
                {credentialSaving && <RefreshCw className="w-4 h-4 mr-2 animate-spin" />}
                Kaydet
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
