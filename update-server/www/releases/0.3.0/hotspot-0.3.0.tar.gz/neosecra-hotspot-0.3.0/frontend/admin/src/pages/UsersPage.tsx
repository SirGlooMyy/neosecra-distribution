import React, { useState, useEffect } from "react";
import { getOnlineSessions, getSessions, getBanRules, getWhitelist, createBanRule, deleteBanRule, createWhitelistEntry, deleteWhitelistEntry, getMeetingCodes, deleteMeetingCode, getPendingSessions, approveSession, rejectSession, closeSession, getCurrentCustomerId } from "../lib/api";
import { Search, UserCheck, UserX, Shield, ShieldOff, Plus, Trash2, Ban, CheckCircle, Clock, Wifi, Users, RefreshCw, UserPlus, Mail, Phone } from "lucide-react";

const buildWhitelistForm = (customerId: string = "") => ({
  customer_id: customerId,
  mac_address: "",
  phone: "",
  description: "",
});

const buildBanForm = (customerId: string = "") => ({
  customer_id: customerId,
  mac_address: "",
  phone: "",
  ip_address: "",
  reason: "",
});

function normalizeSession(session: any) {
  const startedAt = session?.started_at || session?.created_at;
  const endedAt = session?.ended_at;
  const end = endedAt ? new Date(endedAt).getTime() : Date.now();
  const start = startedAt ? new Date(startedAt).getTime() : end;
  const durationMinutes = Number.isFinite(start) ? Math.max(0, Math.round((end - start) / 60000)) : 0;
  return {
    ...session,
    user: session?.phone || session?.username || session?.user || session?.mac || "Bilinmeyen",
    device: session?.ssid || session?.device_name || session?.nas_ip || (session?.device_id ? "Cihaz " + String(session.device_id).slice(0, 8) : "—"),
    durationMinutes,
    startTime: startedAt,
    endTime: endedAt,
  };
}

export const UsersPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState(
    () => (typeof window !== 'undefined' && window.location.pathname === '/users' ? 'all' : 'online'),
  );
  const [onlineUsers, setOnlineUsers] = useState<any[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [pendingUsers, setPendingUsers] = useState<any[]>([]);
  const [banRules, setBanRules] = useState<any[]>([]);
  const [whitelist, setWhitelist] = useState<any[]>([]);
  const [meetingCodes, setMeetingCodes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showBanForm, setShowBanForm] = useState(false);
  const [showWhitelistForm, setShowWhitelistForm] = useState(false);
  const [currentCustomerId, setCurrentCustomerId] = useState('');
  const [whitelistForm, setWhitelistForm] = useState(() => buildWhitelistForm());
  const [banForm, setBanForm] = useState(() => buildBanForm());
  const [localForm, setLocalForm] = useState({ username: '', password: '', display_name: '', email: '', phone: '', max_devices: 3 });

  const tabs = [
    { key: 'online', label: 'Online Kullanıcılar', icon: Wifi },
    { key: 'all', label: 'Tüm Kullanıcılar', icon: Users },
    { key: 'offline', label: 'Offline/Geçmiş', icon: Clock },
    { key: 'pending', label: 'Onay Bekleyenler', icon: UserCheck },
    { key: 'manual', label: 'Manuel Kullanıcılar', icon: UserCheck },
    { key: 'banned', label: 'Yasaklılar', icon: Ban },
    { key: 'whitelist', label: 'Beyaz Liste', icon: Shield },
    { key: 'meeting', label: 'Toplantı Kodları', icon: Clock },
  ];

  const loadAll = async () => {
      setLoading(true);
      try {
        const results = await Promise.allSettled([
          getOnlineSessions(),
          getSessions(),
          getPendingSessions(),
          getBanRules(),
          getWhitelist(),
          getMeetingCodes(),
        ]);
        const value = <T,>(index: number, fallback: T): T => (
          results[index].status === "fulfilled" ? results[index].value as T : fallback
        );
        setOnlineUsers(value<any[]>(0, []).map(normalizeSession));
        setAllUsers(value<any[]>(1, []).map(normalizeSession));
        setPendingUsers(value<any[]>(2, []).map(normalizeSession));
        setBanRules(value<any[]>(3, []));
        setWhitelist(value<any[]>(4, []));
        setMeetingCodes(value<any[]>(5, []));
        results.forEach((result, index) => {
          if (result.status === "rejected") console.warn("Kullanıcı verisi (" + index + ") yüklenemedi", result.reason);
        });
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadAll(); }, []);

  useEffect(() => {
    (async () => {
      const customerId = await getCurrentCustomerId();
      if (customerId) {
        setCurrentCustomerId(customerId);
      }
    })();
  }, []);

  useEffect(() => {
    if (!currentCustomerId) return;
    setWhitelistForm((prev) => prev.customer_id === currentCustomerId ? prev : buildWhitelistForm(currentCustomerId));
    setBanForm((prev) => prev.customer_id === currentCustomerId ? prev : buildBanForm(currentCustomerId));
  }, [currentCustomerId]);

  const handleBan = async () => {
    try {
      await createBanRule(banForm);
      setShowBanForm(false);
      setBanForm(buildBanForm(currentCustomerId));
      await loadAll();
    } catch (err) { console.error(err); }
  };

  const handleUnban = async (id: string) => {
    if (!confirm('Bu yasağı kaldırmak istediğinize emin misiniz?')) return;
    try { await deleteBanRule(id); await loadAll(); } catch (err) { console.error(err); }
  };

  const handleAddWhitelist = async () => {
    try {
      await createWhitelistEntry(whitelistForm);
      setShowWhitelistForm(false);
      setWhitelistForm(buildWhitelistForm(currentCustomerId));
      await loadAll();
    } catch (err) { console.error(err); }
  };

  const handleCloseSession = async (sessionId: string) => {
    if (!sessionId || !confirm('Bu kullanıcının internet oturumunu kapatmak istediğinize emin misiniz?')) return;
    try {
      await closeSession(sessionId, 'Yönetici tarafından kapatıldı');
      await loadAll();
    } catch (err) {
      console.error(err);
    }
  };

  const renderOnline = () => (
    <div>
      <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
          <div><span className="text-lg font-semibold">{onlineUsers.length} aktif kullanıcı</span><p className="text-xs text-slate-500">FortiGate oturumu açık olan misafirler</p></div>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative min-w-[220px]"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Kullanıcı, MAC veya IP ara" className="w-full rounded-xl border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm dark:border-slate-800 dark:bg-slate-950" /></div>
          <button onClick={loadAll} className="rounded-xl border border-slate-200 p-2 text-slate-400 transition hover:border-indigo-200 hover:text-indigo-600 dark:border-slate-800" title="Yenile"><RefreshCw className="w-4 h-4" /></button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-slate-500">
              <th className="pb-3 font-medium">Kullanıcı / Telefon</th>
              <th className="pb-3 font-medium">MAC Adresi</th>
              <th className="pb-3 font-medium">IP</th>
              <th className="pb-3 font-medium">Cihaz</th>
              <th className="pb-3 font-medium">Süre</th>
              <th className="pb-3 font-medium">Auth</th>
              <th className="pb-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {onlineUsers.filter((s: any) => !search || [s.user, s.mac, s.ip, s.device].some((value) => String(value || '').toLowerCase().includes(search.toLowerCase()))).map((s: any, i: number) => (
              <tr key={s.id || i} className="border-b border-slate-100 dark:border-slate-800/50">
                <td className="py-3 font-medium">{s.user || s.phone || '-'}</td>
                <td className="py-3 text-slate-500">{s.mac}</td>
                <td className="py-3 text-slate-500">{s.ip || '-'}</td>
                <td className="py-3 text-slate-500">{s.device || '-'}</td>
                <td className="py-3 text-slate-500">{s.durationMinutes ? `${s.durationMinutes} dk` : '-'}</td>
                <td className="py-3"><span className="text-xs bg-green-50 dark:bg-green-950/30 text-green-600 px-2 py-0.5 rounded-full">{s.auth_method || 'SMS'}</span></td>
                <td className="py-3">
                  <div className="flex items-center gap-1">
                    <button onClick={() => { setBanForm({ ...banForm, mac_address: s.mac, phone: s.user || s.phone || '' }); setShowBanForm(true); }} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg" title="Yasakla"><Ban className="w-4 h-4" /></button>
                    <button onClick={() => handleCloseSession(s.id)} className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg" title="Oturumu kapat"><UserX className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {onlineUsers.length === 0 && <tr><td colSpan={7} className="py-10 text-center text-slate-500">Aktif kullanıcı bulunmuyor.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderAll = () => (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} className="w-full pl-9 pr-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="Kullanıcı ara..." />
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-slate-500">
              <th className="pb-3 font-medium">Kullanıcı</th>
              <th className="pb-3 font-medium">MAC</th>
              <th className="pb-3 font-medium">IP</th>
              <th className="pb-3 font-medium">Durum</th>
              <th className="pb-3 font-medium">Başlangıç</th>
              <th className="pb-3 font-medium">Süre</th>
            </tr>
          </thead>
          <tbody>
            {allUsers.filter((s: any) => !search || s.user?.includes(search) || s.mac?.includes(search)).map((s: any, i: number) => (
              <tr key={s.id || i} className="border-b border-slate-100 dark:border-slate-800/50">
                <td className="py-3 font-medium">{s.user || s.phone || '-'}</td>
                <td className="py-3 text-slate-500">{s.mac}</td>
                <td className="py-3 text-slate-500">{s.ip || '-'}</td>
                <td className="py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${s.status === 'active' ? 'bg-green-50 text-green-600 dark:bg-green-950/30' : 'bg-slate-100 text-slate-500 dark:bg-slate-800'}`}>{s.status === 'active' ? 'Aktif' : 'Kapalı'}</span></td>
                <td className="py-3 text-slate-500">{s.startTime ? new Date(s.startTime).toLocaleString('tr-TR') : '-'}</td>
                <td className="py-3 text-slate-500">{s.durationMinutes ? `${s.durationMinutes} dk` : '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderBanned = () => (
    <div>
      <div className="flex items-center justify-between mb-4">
        <span className="text-lg font-semibold">{banRules.length} Yasaklı</span>
        <button onClick={() => setShowBanForm(true)} className="px-3 py-1.5 bg-red-600 text-white rounded-xl hover:bg-red-700 text-sm flex items-center gap-1.5"><Plus className="w-3.5 h-3.5" />Yasakla</button>
      </div>
      {showBanForm && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 mb-4 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <input value={banForm.mac_address} onChange={e => setBanForm({ ...banForm, mac_address: e.target.value })} className="px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="MAC Adresi (isteğe bağlı)" />
            <input value={banForm.phone} onChange={e => setBanForm({ ...banForm, phone: e.target.value })} className="px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="Telefon (isteğe bağlı)" />
            <input value={banForm.ip_address} onChange={e => setBanForm({ ...banForm, ip_address: e.target.value })} className="px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="IP (isteğe bağlı)" />
            <input value={banForm.reason} onChange={e => setBanForm({ ...banForm, reason: e.target.value })} className="px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="Sebep" />
          </div>
          <div className="flex justify-end gap-2 mt-3">
            <button onClick={() => setShowBanForm(false)} className="px-3 py-1.5 border border-slate-300 dark:border-slate-700 rounded-xl text-sm">İptal</button>
            <button onClick={handleBan} className="px-3 py-1.5 bg-red-600 text-white rounded-xl hover:bg-red-700 text-sm">Yasakla</button>
          </div>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-slate-500">
              <th className="pb-3 font-medium">MAC</th>
              <th className="pb-3 font-medium">Telefon</th>
              <th className="pb-3 font-medium">IP</th>
              <th className="pb-3 font-medium">Sebep</th>
              <th className="pb-3 font-medium">Bitiş</th>
              <th className="pb-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {banRules.map((b: any) => (
              <tr key={b.id} className="border-b border-slate-100 dark:border-slate-800/50">
                <td className="py-3 font-mono text-xs">{b.mac_address || '-'}</td>
                <td className="py-3">{b.phone || '-'}</td>
                <td className="py-3">{b.ip_address || '-'}</td>
                <td className="py-3 text-slate-500">{b.reason || '-'}</td>
                <td className="py-3 text-slate-500">{b.expires_at ? new Date(b.expires_at).toLocaleDateString('tr-TR') : 'Süresiz'}</td>
                <td className="py-3"><button onClick={() => handleUnban(b.id)} className="p-1.5 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded-lg" title="Yasağı Kaldır"><CheckCircle className="w-4 h-4" /></button></td>
              </tr>
            ))}
            {banRules.length === 0 && <tr><td colSpan={6} className="py-8 text-center text-slate-500">Yasaklı kullanıcı bulunmuyor.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderWhitelist = () => (
    <div>
      <div className="flex items-center justify-between mb-4">
        <span className="text-lg font-semibold">{whitelist.length} Kayıt</span>
        <button onClick={() => { setShowWhitelistForm(true); setWhitelistForm(buildWhitelistForm(currentCustomerId)); }} className="px-3 py-1.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 text-sm flex items-center gap-1.5"><Plus className="w-3.5 h-3.5" />Ekle</button>
      </div>
      {showWhitelistForm && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 mb-4 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input value={whitelistForm.mac_address} onChange={e => setWhitelistForm({ ...whitelistForm, mac_address: e.target.value })} className="px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="MAC Adresi" />
            <input value={whitelistForm.phone} onChange={e => setWhitelistForm({ ...whitelistForm, phone: e.target.value })} className="px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="Telefon" />
            <input value={whitelistForm.description} onChange={e => setWhitelistForm({ ...whitelistForm, description: e.target.value })} className="px-3 py-2 border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-sm" placeholder="Açıklama" />
          </div>
          <div className="flex justify-end gap-2 mt-3">
            <button onClick={() => setShowWhitelistForm(false)} className="px-3 py-1.5 border border-slate-300 dark:border-slate-700 rounded-xl text-sm">İptal</button>
            <button onClick={handleAddWhitelist} className="px-3 py-1.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 text-sm">Ekle</button>
          </div>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-slate-500">
              <th className="pb-3 font-medium">MAC</th>
              <th className="pb-3 font-medium">Telefon</th>
              <th className="pb-3 font-medium">Açıklama</th>
              <th className="pb-3 font-medium"></th>
            </tr>
          </thead>
          <tbody>
            {whitelist.map((w: any) => (
              <tr key={w.id} className="border-b border-slate-100 dark:border-slate-800/50">
                <td className="py-3 font-mono text-xs">{w.mac_address || '-'}</td>
                <td className="py-3">{w.phone || '-'}</td>
                <td className="py-3 text-slate-500">{w.description || '-'}</td>
                <td className="py-3"><button onClick={async () => { try { await deleteWhitelistEntry(w.id); await loadAll(); } catch (err) { console.error(err); } }} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button></td>
              </tr>
            ))}
            {whitelist.length === 0 && <tr><td colSpan={4} className="py-8 text-center text-slate-500">Beyaz liste kaydı bulunmuyor.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderOffline = () => {
    const offlineUsers = allUsers.filter((u: any) => u.status === 'closed' || u.status === 'expired');
    return (
      <div>
        <div className="flex items-center justify-between mb-4">
          <span className="text-lg font-semibold">{offlineUsers.length} Geçmiş Kullanıcı</span>
        </div>
        {offlineUsers.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-slate-100 dark:border-slate-800 text-left">
                <th className="pb-2 font-semibold text-slate-500">Kullanıcı</th>
                <th className="pb-2 font-semibold text-slate-500">MAC</th>
                <th className="pb-2 font-semibold text-slate-500">IP</th>
                <th className="pb-2 font-semibold text-slate-500">Süre</th>
                <th className="pb-2 font-semibold text-slate-500">Durum</th>
                <th className="pb-2 font-semibold text-slate-500">Bitiş</th>
              </tr></thead>
              <tbody>
                {offlineUsers.map((u: any, i: number) => (
                  <tr key={u.id || i} className="border-b border-slate-50 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/30">
                    <td className="py-2.5 font-medium text-slate-800 dark:text-slate-200">{u.user || u.username || '—'}</td>
                    <td className="py-2.5 font-mono text-slate-600 text-xs">{u.mac || '—'}</td>
                    <td className="py-2.5 font-mono text-slate-600 text-xs">{u.ip || '—'}</td>
                    <td className="py-2.5 text-slate-600">{u.durationMinutes ? `${u.durationMinutes} dk` : '—'}</td>
                    <td className="py-2.5"><span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600">Kapalı</span></td>
                    <td className="py-2.5 text-slate-600 text-xs">{u.endTime || u.updated_at ? new Date(u.updated_at || u.endTime).toLocaleString('tr-TR') : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-slate-400">Henüz kapanmış oturum bulunmuyor</div>
        )}
      </div>
    );
  };

  const renderPending = () => (
    <div>
      <div className="flex items-center justify-between mb-4">
        <span className="text-lg font-semibold">{pendingUsers.length} Onay Bekleyen</span>
      </div>
      {pendingUsers.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-100 dark:border-slate-800 text-left">
              <th className="pb-2 font-semibold text-slate-500">Kullanıcı / Telefon</th>
              <th className="pb-2 font-semibold text-slate-500">MAC</th>
              <th className="pb-2 font-semibold text-slate-500">Yöntem</th>
              <th className="pb-2 font-semibold text-slate-500">Talep Zamanı</th>
              <th className="pb-2 font-semibold text-slate-500">İşlem</th>
            </tr></thead>
            <tbody>
              {pendingUsers.map((u: any, i: number) => (
                <tr key={u.id || i} className="border-b border-slate-50 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/30">
                  <td className="py-2.5 font-medium text-slate-800 dark:text-slate-200">{u.phone || u.user || '—'}</td>
                  <td className="py-2.5 font-mono text-xs text-slate-500">{u.mac || '—'}</td>
                  <td className="py-2.5 text-slate-600">{u.auth_method || 'SMS'}</td>
                  <td className="py-2.5 text-slate-600 text-xs">{u.started_at || u.created_at ? new Date(u.started_at || u.created_at).toLocaleString('tr-TR') : '—'}</td>
                  <td className="py-2.5 flex gap-2">
                    <button onClick={async () => { try { await approveSession(u.id); await loadAll(); } catch (err) { console.error(err); } }} className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 rounded-lg text-xs font-medium hover:bg-emerald-100 dark:hover:bg-emerald-950/50 transition-colors"><CheckCircle className="w-3 h-3" /> Onayla</button>
                    <button onClick={async () => { try { await rejectSession(u.id); await loadAll(); } catch (err) { console.error(err); } }} className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400 rounded-lg text-xs font-medium hover:bg-rose-100 dark:hover:bg-rose-950/50 transition-colors"><UserX className="w-3 h-3" /> Reddet</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-8 text-slate-400">Onay bekleyen kullanıcı bulunmuyor</div>
      )}
    </div>
  );

  const renderManual = () => {
    const handleCreate = async () => {
      try {
        const { createLocalUser } = await import('../lib/api');
        await createLocalUser(localForm);
        setLocalForm({ username: '', password: '', display_name: '', email: '', phone: '', max_devices: 3 });
      } catch (err) { console.error(err); }
    };
    return (
      <div>
        <div className="flex items-center justify-between mb-4">
          <span className="text-lg font-semibold">Manuel Kullanıcılar</span>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-3 flex items-center gap-2"><UserPlus className="w-4 h-4" /> Yeni Kullanıcı Oluştur</h4>
            <div className="space-y-3">
              <input type="text" placeholder="Kullanıcı Adı" value={localForm.username} onChange={e => setLocalForm(f => ({ ...f, username: e.target.value }))} className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              <input type="password" placeholder="Parola" value={localForm.password} onChange={e => setLocalForm(f => ({ ...f, password: e.target.value }))} className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              <input type="text" placeholder="Ad Soyad" value={localForm.display_name} onChange={e => setLocalForm(f => ({ ...f, display_name: e.target.value }))} className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              <div className="grid grid-cols-2 gap-3">
                <input type="email" placeholder="E-posta" value={localForm.email} onChange={e => setLocalForm(f => ({ ...f, email: e.target.value }))} className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                <input type="text" placeholder="Telefon" value={localForm.phone} onChange={e => setLocalForm(f => ({ ...f, phone: e.target.value }))} className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <button onClick={handleCreate} className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl transition-colors">Kullanıcı Oluştur</button>
            </div>
          </div>
          <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-3 flex items-center gap-2"><Users className="w-4 h-4" /> Mevcut Kullanıcılar</h4>
            <p className="text-xs text-slate-400 mb-3">Mevcut lokal kullanıcı listesi için Auth Methods {'>'} Local Users bölümüne bakın.</p>
            <div className="text-center py-6 text-slate-400 text-sm">
              <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>Lokal kullanıcı yönetimi için <span className="text-indigo-500 font-medium">Auth Methods</span> sayfasını kullanın</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderMeeting = () => (
    <div>
      <div className="flex items-center justify-between mb-4">
        <span className="text-lg font-semibold">{meetingCodes.length} Kod</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-slate-500">
              <th className="pb-3 font-medium">Kod</th>
              <th className="pb-3 font-medium">Etkinlik</th>
              <th className="pb-3 font-medium">Kullanım</th>
              <th className="pb-3 font-medium">Süre</th>
              <th className="pb-3 font-medium">Bitiş</th>
            </tr>
          </thead>
          <tbody>
            {meetingCodes.map((m: any) => (
              <tr key={m.id} className="border-b border-slate-100 dark:border-slate-800/50">
                <td className="py-3 font-mono font-bold">{m.code}</td>
                <td className="py-3">{m.event_name || '-'}</td>
                <td className="py-3">{m.used_count || 0}/{m.max_uses || 0}</td>
                <td className="py-3 text-slate-500">{m.duration_minutes ? `${m.duration_minutes} dk` : '-'}</td>
                <td className="py-3 text-slate-500">{m.expires_at ? new Date(m.expires_at).toLocaleDateString('tr-TR') : '-'}</td>
              </tr>
            ))}
            {meetingCodes.length === 0 && <tr><td colSpan={5} className="py-8 text-center text-slate-500">Toplantı kodu bulunmuyor.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const TabIcon = tabs.find(t => t.key === activeTab)?.icon || Users;

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 px-6 py-6 text-white shadow-xl shadow-indigo-950/20">
        <div className="absolute -right-16 -top-24 h-64 w-64 rounded-full bg-indigo-500/20 blur-3xl" />
        <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-indigo-300">Kimlik ve oturum operasyonu</div>
            <h2 className="mt-1 text-2xl font-bold tracking-tight">Kullanıcı Yönetimi</h2>
            <p className="mt-1 max-w-2xl text-sm text-slate-300">Online misafirleri izleyin, geçmiş oturumları inceleyin ve gerektiğinde erişimi sonlandırın. <strong className="text-white">/users</strong> tüm kayıtları, <strong className="text-white">/online-users</strong> yalnızca canlı oturumları açar.</p>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="rounded-xl border border-white/15 bg-white/10 px-3 py-2"><div className="text-lg font-bold">{onlineUsers.length}</div><div className="text-slate-300">Online</div></div>
            <div className="rounded-xl border border-white/15 bg-white/10 px-3 py-2"><div className="text-lg font-bold">{pendingUsers.length}</div><div className="text-slate-300">Bekleyen</div></div>
            <div className="rounded-xl border border-white/15 bg-white/10 px-3 py-2"><div className="text-lg font-bold">{banRules.length}</div><div className="text-slate-300">Yasaklı</div></div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-1 border-b border-slate-200 dark:border-slate-800 pb-1">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)} className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-t-xl transition-all ${activeTab === tab.key ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 border border-b-0 border-slate-200 dark:border-slate-800' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50'}`}>
              <Icon className="w-4 h-4" /> {tab.label}
            </button>
          );
        })}
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        {loading ? <div className="text-center py-8 text-slate-500">Yükleniyor...</div> : (
          <>
            {activeTab === 'online' && renderOnline()}
            {activeTab === 'all' && renderAll()}
            {activeTab === 'offline' && renderOffline()}
            {activeTab === 'pending' && renderPending()}
            {activeTab === 'manual' && renderManual()}
            {activeTab === 'banned' && renderBanned()}
            {activeTab === 'whitelist' && renderWhitelist()}
            {activeTab === 'meeting' && renderMeeting()}
          </>
        )}
      </div>
    </div>
  );
};
