import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate, useParams, useNavigate } from "react-router-dom";
import { ThemeProvider } from "../theme/ThemeProvider";
import { AppShell } from "../components/layout/AppShell";
import { LoginPage } from "../pages/LoginPage";
import { routeConfig } from "../routes";
import { TemplateEditorPage } from "../pages/TemplateEditorPage";
import { getCurrentUser } from "../lib/api";
import { RefreshCw } from "lucide-react";

const TemplateEditorWrapper: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  return <TemplateEditorPage portalId={id!} onBack={() => navigate("/portal-templates")} />;
};

export const App: React.FC = () => {
  const [user, setUser] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    async function checkAuth() {
      try {
        const currentUser = await getCurrentUser();
        if (currentUser) {
          setUser(currentUser);
        }
      } catch (err) {
        console.error("Auth check failed:", err);
      } finally {
        setLoading(false);
      }
    }
    checkAuth();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen w-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200">
        <div className="flex flex-col items-center gap-4">
          <RefreshCw className="h-8 w-8 text-indigo-600 animate-spin" />
          <p className="text-sm font-semibold tracking-wide animate-pulse">Oturum doğrulanıyor...</p>
        </div>
      </div>
    );
  }

  const path = window.location.pathname;

  if (!user) {
    if (path === "/login") {
      return <LoginPage onLoginSuccess={setUser} />;
    }
    return <Navigate to="/login" replace />;
  }

  return (
    <ThemeProvider>
      <AppShell>
        <Routes>
          {routeConfig.map((r) => (
            <Route key={r.path} path={r.path} element={r.element} />
          ))}
          <Route path="/portal-templates/:id/edit" element={<TemplateEditorWrapper />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AppShell>
    </ThemeProvider>
  );
};
