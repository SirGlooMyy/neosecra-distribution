import React, { useState, useEffect } from "react";
import { getLogArchives, buildLogArchive, verifyLogChain, getCurrentCustomerId, signArchive } from "../lib/api";
import { Database, Plus, CheckCircle, Search, ShieldCheck, RefreshCw, PenSquare } from "lucide-react";

interface LogArchive {
  id: string;
  customerName: string;
  date: string;
  recordCount: number;
  fileSizeKb: number;
  hash: string;
  isVerified: boolean;
  signatureOrigin: string | null;
}

export const LogsPage: React.FC = () => {
  const [archives, setArchives] = useState<LogArchive[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [currentCustomerId, setCurrentCustomerId] = useState("");
  
  // Simulations states
  const [building, setBuilding] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [verifyNotice, setVerifyNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [signingId, setSigningId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    customerId: "",
    date: new Date().toISOString().split("T")[0],
  });

  const loadArchives = async () => {
    setLoading(true);
    try {
      const archData = await getLogArchives();
      
      const mapped = (archData || []).map((a: any) => ({
        id: a.id,
        customerName: a.customer_name || "Bilinmeyen",
        date: new Date(a.period_start).toLocaleDateString(),
        recordCount: a.item_count,
        fileSizeKb: Math.round(a.content_size / 1024),
        hash: a.content_hash,
        isVerified: Boolean(a.signature_value),
        signatureOrigin: a.signature_origin ?? null,
      }));
      
      setArchives(mapped);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadArchives();
  }, []);

  useEffect(() => {
    (async () => {
      const customerId = await getCurrentCustomerId();
      if (customerId) {
        setCurrentCustomerId(customerId);
      }
    })();
  }, []);

  useEffect(() => {
    if (!currentCustomerId) return;
    setFormData((prev) => prev.customerId ? prev : { ...prev, customerId: currentCustomerId });
  }, [currentCustomerId]);

  const filtered = archives.filter(
    (a) =>
      a.customerName.toLowerCase().includes(search.toLowerCase()) ||
      a.hash.toLowerCase().includes(search.toLowerCase()) ||
      a.date.includes(search)
  );

  const handleBuildArchive = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.date) return;

    setBuilding(true);

    try {
      const start = new Date(formData.date);
      start.setHours(0, 0, 0, 0);
      const end = new Date(formData.date);
      end.setHours(23, 59, 59, 999);

      const newArchRaw = await buildLogArchive({
        ...(formData.customerId ? { customer_id: formData.customerId } : {}),
        period_start: start.toISOString(),
        period_end: end.toISOString(),
        record_type: "session_archive",
      });

      const newArch = {
        id: newArchRaw.id,
        customerName: newArchRaw.customer_name || "Kurulum müşterisi",
        date: new Date(newArchRaw.period_start).toLocaleDateString(),
        recordCount: newArchRaw.item_count,
        fileSizeKb: Math.round(newArchRaw.content_size / 1024),
        hash: newArchRaw.content_hash,
        isVerified: Boolean(newArchRaw.signature_value),
        signatureOrigin: newArchRaw.signature_origin ?? null,
      };

      setArchives([newArch, ...archives]);
      setShowAddForm(false);
      setFormData((prev) => ({ ...prev, customerId: currentCustomerId }));
    } catch (err) {
      console.error(err);
    } finally {
      setBuilding(false);
    }
  };

  const handleVerifyChain = async () => {
    setVerifying(true);
    setVerifyNotice(null);

    try {
      const msg = await verifyLogChain();
      setVerifyNotice({ type: "success", text: typeof msg === "string" ? msg : "Zincir bütünlüğü doğrulandı." });
    } catch (err: any) {
      setVerifyNotice({ type: "error", text: err.message || "Bütünlük doğrulanamadı." });
    } finally {
      setVerifying(false);
    }
  };

  const handleSignArchive = async (id: string) => {
    setSigningId(id);
    setVerifyNotice(null);
    try {
      await signArchive(id);
      setVerifyNotice({ type: "success", text: "Arşiv zaman damgası ile imzalandı. İmza kaynağını ve saati listede görebilirsiniz." });
      await loadArchives();
    } catch (err: any) {
      setVerifyNotice({ type: "error", text: err?.message || "Arşiv imzalanamadı." });
    } finally {
      setSigningId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">5651 Log Arşivleri</h2>
          <p className="text-sm text-slate-500">
            Günlük IP, MAC ve NAT kayıtlarını hash zinciriyle arşivleyin; ardından KamuSM, yerel sertifika veya demo zaman damgası ile imzalayıp doğrulayın.
          </p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={handleVerifyChain}
            disabled={verifying}
            className="inline-flex items-center px-4 py-2 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 rounded-xl text-sm font-semibold transition-colors disabled:opacity-50"
          >
            <ShieldCheck className={`w-4 h-4 mr-2 ${verifying ? 'animate-pulse' : ''}`} />
            {verifying ? "Zincir Doğrulanıyor..." : "Zincir Bütünlüğünü Doğrula"}
          </button>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            Manuel Arşiv Derle
          </button>
        </div>
      </div>

      {verifyNotice && (
        <div className={`p-4 rounded-xl text-sm font-medium flex justify-between items-center ${verifyNotice.type === "success" ? "bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50 text-emerald-800 dark:text-emerald-400" : "bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/50 text-rose-800 dark:text-rose-300"}`}>
          <div className="flex items-center">
            <CheckCircle className={`w-5 h-5 mr-2 flex-shrink-0 ${verifyNotice.type === "success" ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400"}`} />
            {verifyNotice.text}
          </div>
          <button onClick={() => setVerifyNotice(null)} className="underline text-xs hover:no-underline ml-4">Kapat</button>
        </div>
      )}

      {showAddForm && (
        <form onSubmit={handleBuildArchive} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4 animate-slide-in">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center">
            <Database className="w-4 h-4 mr-2 text-indigo-500" />
            5651 Log Arşivi Oluştur
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Kurulum müşterisi</label>
              <div className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm text-slate-500">
                {currentCustomerId || "Otomatik atanır"}
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Log Tarihi</label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={building}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold flex items-center"
            >
              {building && <RefreshCw className="w-4 h-4 mr-2 animate-spin" />}
              {building ? "İmzalanıyor ve Arşivleniyor..." : "Zaman Damgalı Arşiv Oluştur"}
            </button>
          </div>
        </form>
      )}

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-3 text-slate-400 w-4 h-4" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Müşteri adı veya dosya hash araması..."
          className="w-full pl-11 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
        />
      </div>

      {/* Table Container */}
      <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
        {loading ? (
          <div className="flex justify-center items-center py-12 space-x-2">
            <RefreshCw className="w-6 h-6 text-indigo-500 animate-spin" />
            <span className="text-sm font-medium text-slate-500">Log arşivleri yükleniyor...</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Müşteri</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Dönem / Gün</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Kayıt Sayısı</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Boyut</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">TÜBİTAK Zaman Damgası Hash (SHA-256)</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">İmza Durumu</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 text-right">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((a) => (
                  <tr key={a.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-slate-950 dark:text-slate-50">{a.customerName}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{a.date}</td>
                    <td className="px-6 py-4 text-sm text-slate-500 font-semibold">{a.recordCount.toLocaleString()} log</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{(a.fileSizeKb / 1024).toFixed(2)} MB</td>
                    <td className="px-6 py-4 text-sm text-slate-500 font-mono text-xs max-w-[200px] truncate" title={a.hash}>
                      {a.hash}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${a.isVerified ? "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30" : "bg-slate-100 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700"}`}>
                        <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                        {a.isVerified ? "İmzalı" : "Beklemede"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {a.isVerified ? (
                        <span className="text-xs text-slate-400">İmzalı</span>
                      ) : (
                        <button onClick={() => handleSignArchive(a.id)} disabled={signingId === a.id} className="inline-flex items-center rounded-xl px-3 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 disabled:opacity-50 dark:text-indigo-400 dark:hover:bg-indigo-950/30">
                          <PenSquare className="mr-1 h-3.5 w-3.5" />
                          {signingId === a.id ? "İmzalanıyor" : "İmzala"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-slate-500">
                      Arama kriterlerinize uygun log arşivi bulunamadı.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
