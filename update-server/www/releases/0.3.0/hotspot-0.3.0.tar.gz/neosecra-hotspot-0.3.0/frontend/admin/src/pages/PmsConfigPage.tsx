import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Database,
  Hotel,
  Plug,
  RefreshCw,
  Save,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import {
  getPmsConfig,
  updatePmsConfig,
  testPmsConnection,
  getCustomSources,
} from '../lib/api';

type PmsConfig = {
  pms_type: string;
  host: string;
  port: number;
  username: string;
  api_key: string;
  password: string;
  db_host: string;
  db_port: number;
  db_name: string;
  db_user: string;
  db_password: string;
  is_active: boolean;
};

const EMPTY_CONFIG: PmsConfig = {
  pms_type: 'mock',
  host: '',
  port: 443,
  username: '',
  api_key: '',
  password: '',
  db_host: '',
  db_port: 3306,
  db_name: '',
  db_user: '',
  db_password: '',
  is_active: false,
};

const PMS_VENDORS: Record<string, string> = {
  mock: 'Demo / Mock',
  opera: 'Oracle Opera',
  elektra: 'Elektra',
  sispar: 'Sispar',
  fidelio: 'Fidelio (Micros)',
  otelplus: 'OtelPlus',
  setur: 'Setur',
  custom: 'Özel veri kaynağı',
};

export const PmsConfigPage: React.FC = () => {
  const [config, setConfig] = useState<PmsConfig>(EMPTY_CONFIG);
  const [sourceCount, setSourceCount] = useState(0);
  const [testRoom, setTestRoom] = useState('101');
  const [testSurname, setTestSurname] = useState('DEMO');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [testResult, setTestResult] = useState<{ success: boolean; text: string } | null>(null);
  const [lastTestAt, setLastTestAt] = useState<string | null>(null);
  const [lastTestMode, setLastTestMode] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setNotice(null);
    try {
      const [saved, sources] = await Promise.all([getPmsConfig(), getCustomSources()]);
      setConfig({ ...EMPTY_CONFIG, ...(saved || {}), api_key: '', password: '', db_password: '' });
      setSourceCount(Array.isArray(sources) ? sources.length : 0);
    } catch (error: any) {
      setNotice({ type: 'error', text: error?.message || 'PMS ayarları yüklenemedi.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const patch = (next: Partial<PmsConfig>) => setConfig((current) => ({ ...current, ...next }));

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setNotice(null);
    try {
      const payload: Record<string, unknown> = {
        pms_type: config.pms_type,
        host: config.host || null,
        port: config.port || null,
        username: config.username || null,
        db_host: config.db_host || null,
        db_port: config.db_port || null,
        db_name: config.db_name || null,
        db_user: config.db_user || null,
        is_active: config.is_active,
      };
      if (config.api_key) payload.api_key = config.api_key;
      if (config.password) payload.password = config.password;
      if (config.db_password) payload.db_password = config.db_password;
      const saved = await updatePmsConfig(payload);
      setConfig((current) => ({ ...current, ...saved, api_key: '', password: '', db_password: '' }));
      setNotice({ type: 'success', text: 'PMS ayarları kaydedildi.' });
    } catch (error: any) {
      setNotice({ type: 'error', text: error?.message || 'PMS ayarları kaydedilemedi.' });
    } finally {
      setSaving(false);
    }
  };

  const test = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const result = await testPmsConnection(config.pms_type, testRoom, testSurname);
      setTestResult({
        success: Boolean(result?.verified ?? result?.success),
        text: result?.message || (result?.verified ? 'Misafir kaydı doğrulandı.' : 'Misafir kaydı doğrulanamadı.'),
      });
      setLastTestAt(new Date().toISOString());
      setLastTestMode(config.pms_type || 'mock');
    } catch (error: any) {
      setTestResult({ success: false, text: error?.message || 'PMS bağlantı testi başarısız.' });
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center py-24 text-sm text-slate-500"><RefreshCw className="mr-2 h-5 w-5 animate-spin" /> PMS ayarları yükleniyor...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Hotel className="h-6 w-6 text-indigo-600" />
            <h2 className="text-2xl font-bold tracking-tight">Otel / PMS Entegrasyonu</h2>
          </div>
          <p className="mt-1 max-w-3xl text-sm text-slate-500">
            Misafirin oda numarası ve soyadıyla doğrulanmasını, FortiGate captive portal oturumuyla ilişkilendirilmesini sağlar.
            Bu modül switch veya NAC yönetmez; yalnızca konaklama doğrulaması yapar.
          </p>
        </div>
          <div className={`inline-flex h-fit items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold ${config.is_active ? 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-300' : 'border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-300'}`}>
          <span className={`h-2 w-2 rounded-full ${config.is_active ? 'bg-emerald-500' : 'bg-amber-500'}`} />
          {config.is_active ? 'PMS doğrulaması etkin' : 'PMS doğrulaması kapalı'}
        </div>
      </div>

      {notice && (
        <div className={`flex items-center gap-2 rounded-xl border px-4 py-3 text-sm ${notice.type === 'success' ? 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-300' : 'border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-300'}`}>
          {notice.type === 'success' ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
          {notice.text}
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <form onSubmit={save} className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3 dark:border-slate-800">
            <Database className="h-4 w-4 text-indigo-500" />
            <h3 className="font-semibold">PMS bağlantı ayarları</h3>
          </div>

          <label className="block text-sm font-medium">
            PMS sağlayıcısı
            <select value={config.pms_type} onChange={(event) => patch({ pms_type: event.target.value })} className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950">
              {Object.entries(PMS_VENDORS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
          </label>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block text-sm font-medium">API / DB host<input value={config.host} onChange={(event) => patch({ host: event.target.value })} placeholder="pms.example.local" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
            <label className="block text-sm font-medium">Port<input type="number" min={1} value={config.port} onChange={(event) => patch({ port: Number(event.target.value) })} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
            <label className="block text-sm font-medium">Kullanıcı adı<input value={config.username} onChange={(event) => patch({ username: event.target.value })} autoComplete="off" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
            <label className="block text-sm font-medium">API anahtarı / şifre<input type="password" value={config.api_key || config.password} onChange={(event) => patch({ api_key: event.target.value, password: '' })} autoComplete="new-password" placeholder="Değiştirmeyecekseniz boş bırakın" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
          </div>

          <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-800">
            <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Doğrudan veritabanı (opsiyonel)</div>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block text-sm font-medium">DB host<input value={config.db_host} onChange={(event) => patch({ db_host: event.target.value })} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
              <label className="block text-sm font-medium">DB port<input type="number" min={1} value={config.db_port} onChange={(event) => patch({ db_port: Number(event.target.value) })} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
              <label className="block text-sm font-medium">DB adı<input value={config.db_name} onChange={(event) => patch({ db_name: event.target.value })} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
              <label className="block text-sm font-medium">DB kullanıcı adı<input value={config.db_user} onChange={(event) => patch({ db_user: event.target.value })} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
              <label className="block text-sm font-medium sm:col-span-2">DB şifresi<input type="password" value={config.db_password} onChange={(event) => patch({ db_password: event.target.value })} autoComplete="new-password" placeholder="Değiştirmeyecekseniz boş bırakın" className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label>
            </div>
          </div>

          <label className="inline-flex items-center gap-2 text-sm font-medium"><input type="checkbox" checked={config.is_active} onChange={(event) => patch({ is_active: event.target.checked })} className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500" /> Captive portalda “Otel Odası” girişini etkinleştir</label>
          <div className="flex justify-end"><button type="submit" disabled={saving} className="inline-flex items-center rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-60"><Save className="mr-2 h-4 w-4" />{saving ? 'Kaydediliyor...' : 'Ayarları Kaydet'}</button></div>
        </form>

        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3 dark:border-slate-800"><ShieldCheck className="h-4 w-4 text-indigo-500" /><h3 className="font-semibold">Misafir doğrulama testi</h3></div>
            <p className="mt-3 text-xs leading-5 text-slate-500">Oda ve soyadıyla gerçek PMS sorgusunu veya demo sağlayıcıyı test edin. Demo/Mock sonucu gerçek PMS bağlantısı anlamına gelmez.</p>
            <div className="mt-4 space-y-3"><label className="block text-sm font-medium">Oda numarası<input value={testRoom} onChange={(event) => setTestRoom(event.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label><label className="block text-sm font-medium">Soyadı / doğum yılı<input value={testSurname} onChange={(event) => setTestSurname(event.target.value)} className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm dark:border-slate-800 dark:bg-slate-950" /></label></div>
            <button type="button" onClick={test} disabled={testing || !testRoom || !testSurname} className="mt-4 inline-flex w-full items-center justify-center rounded-xl border border-indigo-200 px-4 py-2.5 text-sm font-semibold text-indigo-600 hover:bg-indigo-50 disabled:opacity-50 dark:border-indigo-800 dark:text-indigo-400 dark:hover:bg-indigo-950/30"><Plug className="mr-2 h-4 w-4" />{testing ? 'Test ediliyor...' : 'Misafir doğrulamasını test et'}</button>
            {testResult && <div className={`mt-4 flex items-start gap-2 rounded-xl border p-3 text-sm ${testResult.success ? 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-300' : 'border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-300'}`}>{testResult.success ? <CheckCircle2 className="mt-0.5 h-4 w-4" /> : <XCircle className="mt-0.5 h-4 w-4" />}<span>{testResult.text}</span></div>}
            <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs dark:border-slate-800 dark:bg-slate-950">
              <div className="font-semibold text-slate-700 dark:text-slate-200">Bağlantı kanıtı</div>
              <div className="mt-1 text-slate-500">Son test: {lastTestAt ? new Date(lastTestAt).toLocaleString('tr-TR') : 'Henüz test edilmedi'}</div>
              <div className="mt-1 text-slate-500">Mod: <span className="font-semibold text-slate-700 dark:text-slate-300">{lastTestMode ? (lastTestMode === 'mock' ? 'Demo / Mock' : PMS_VENDORS[lastTestMode] || lastTestMode) : '—'}</span></div>
              <div className="mt-1 text-slate-500">{config.is_active ? 'Portalda Otel yöntemi kullanılabilir.' : 'Portalda Otel yöntemi kapalı.'}</div>
            </div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <h3 className="font-semibold">Portal akışı</h3>
            <ol className="mt-3 space-y-3 text-sm text-slate-600 dark:text-slate-400"><li><span className="mr-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300">1</span>Misafir “Otel Odası” yöntemini seçer.</li><li><span className="mr-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300">2</span>Oda numarası ve soyadı PMS’e sorulur.</li><li><span className="mr-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-indigo-100 text-xs font-bold text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300">3</span>Başarılı doğrulama FortiGate oturumuna ve 5651 kaydına bağlanır.</li></ol>
            <div className="mt-4 rounded-xl bg-slate-50 p-3 text-xs text-slate-500 dark:bg-slate-950">Özel veri kaynakları: <strong className="text-slate-700 dark:text-slate-300">{sourceCount}</strong></div>
          </div>
        </div>
      </div>
    </div>
  );
};
