import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { LoginPage } from '../src/pages/LoginPage';

// Mock the api module
vi.mock('../src/lib/api', () => ({
  login: vi.fn(),
}));

import { login } from '../src/lib/api';

describe('LoginPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders the login form with heading', () => {
    render(<LoginPage onLoginSuccess={() => {}} />);
    expect(screen.getByText('Hotspot Platformu')).toBeInTheDocument();
    expect(screen.getByText('Yönetim ve 5651 Loglama Kontrol Paneli')).toBeInTheDocument();
  });

  it('shows error when submitting with empty fields', async () => {
    const user = userEvent.setup();
    render(<LoginPage onLoginSuccess={() => {}} />);
    
    // Try submitting without filling fields
    const submitButton = screen.getByText('Giriş Yap');
    await user.click(submitButton);
    
    // login should not be called since form validation prevents empty submit
    expect(login).not.toHaveBeenCalled();
  });

  it('calls login and onLoginSuccess on successful submission', async () => {
    const user = userEvent.setup();
    const onLoginSuccess = vi.fn();
    const mockUser = { id: '1', email: 'admin@test.com', role: 'super_admin' };
    (login as any).mockResolvedValue(mockUser);
    
    render(<LoginPage onLoginSuccess={onLoginSuccess} />);
    
    await user.type(screen.getByPlaceholderText('admin@hotspot.com'), 'admin@test.com');
    await user.type(screen.getByPlaceholderText('••••••••'), 'password123');
    await user.click(screen.getByText('Giriş Yap'));
    
    expect(login).toHaveBeenCalledWith('admin@test.com', 'password123');
    expect(onLoginSuccess).toHaveBeenCalledWith(mockUser);
  });

  it('shows error message when login fails', async () => {
    const user = userEvent.setup();
    (login as any).mockRejectedValue(new Error('Geçersiz kimlik bilgileri'));
    
    render(<LoginPage onLoginSuccess={() => {}} />);
    
    await user.type(screen.getByPlaceholderText('admin@hotspot.com'), 'admin@test.com');
    await user.type(screen.getByPlaceholderText('••••••••'), 'wrong-password');
    await user.click(screen.getByText('Giriş Yap'));
    
    expect(await screen.findByText('Geçersiz kimlik bilgileri')).toBeInTheDocument();
  });

  it('shows loading state during login', async () => {
    const user = userEvent.setup();
    // Never resolves during test
    (login as any).mockImplementation(() => new Promise(() => {}));
    
    render(<LoginPage onLoginSuccess={() => {}} />);
    
    await user.type(screen.getByPlaceholderText('admin@hotspot.com'), 'admin@test.com');
    await user.type(screen.getByPlaceholderText('••••••••'), 'password123');
    await user.click(screen.getByText('Giriş Yap'));
    
    expect(screen.getByText('Giriş Yapılıyor...')).toBeInTheDocument();
  });

  it('shows demo mode banner when VITE_DEMO_MODE is true', () => {
    // Set demo mode
    import.meta.env.VITE_DEMO_MODE = 'true';
    
    render(<LoginPage onLoginSuccess={() => {}} />);
    expect(screen.getByText(/Demo modu aktif/)).toBeInTheDocument();
  });
});
