import React, { useState, useEffect } from "react";
import { getTrafficTrend, getTrafficDashboard } from "../lib/api";
import { ArrowRight, BarChart2, TrendingUp, Download, Wifi, Users, Clock, Gauge, MapPin, PieChart, RefreshCw } from "lucide-react";

export const TrafficAnalysisPage: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [dashboard, setDashboard] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState(30);

  const load = async () => {
    setLoading(true);
    try {
      const [trend, dash] = await Promise.all([
        getTrafficTrend(period),
        getTrafficDashboard(),
      ]);
      setData(trend);
      setDashboard(dash);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [period]);

  const formatBytes = (b: number) => {
    if (!b) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    let val = b;
    while (val >= 1024 && i < units.length - 1) { val /= 1024; i++; }
    return `${val.toFixed(1)} ${units[i]}`;
  };

  const maxBytes = data?.daily?.length ? Math.max(...data.daily.map((d: any) => d.bytes_in + d.bytes_out)) : 1;

  if (loading) return <div className="flex items-center justify-center gap-2 py-24 text-sm text-slate-500"><RefreshCw className="h-4 w-4 animate-spin" /> Trafik verisi yükleniyor...</div>;

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-cyan-950 to-slate-900 px-6 py-6 text-white shadow-xl shadow-cyan-950/20">
        <div className="absolute -right-16 -top-24 h-64 w-64 rounded-full bg-cyan-500/20 blur-3xl" />
        <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-cyan-300">Kullanım ve kapasite</div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight">Trafik Analizi</h2>
          <p className="mt-1 max-w-2xl text-sm text-slate-300">İndirilen/yüklenen trafiği, en yoğun kullanıcıları ve lokasyon kapasitesini karşılaştırın.</p>
        </div>
        <div className="flex items-center gap-2"><select value={period} onChange={e => setPeriod(parseInt(e.target.value))} className="rounded-xl border border-white/15 bg-white/10 px-3 py-2 text-sm text-white"><option className="text-slate-900" value={7}>Son 7 Gün</option><option className="text-slate-900" value={30}>Son 30 Gün</option><option className="text-slate-900" value={90}>Son 90 Gün</option></select><button type="button" onClick={() => window.location.assign('/reports')} className="inline-flex items-center gap-1 rounded-xl border border-white/15 bg-white/10 px-3 py-2 text-xs font-semibold text-white hover:bg-white/15">Raporlar <ArrowRight className="h-3.5 w-3.5" /></button></div>
        </div>
      </div>

      {/* KPI Cards */}
      {data?.summary && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="bg-indigo-50 dark:bg-indigo-950/30 p-2.5 rounded-xl"><TrendingUp className="w-5 h-5 text-indigo-600" /></div>
              <div>
                <div className="text-xs text-slate-500 font-medium">Toplam Trafik</div>
                <div className="text-xl font-bold">{formatBytes(data.summary.total_bytes_in + data.summary.total_bytes_out)}</div>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="bg-green-50 dark:bg-green-950/30 p-2.5 rounded-xl"><Wifi className="w-5 h-5 text-green-600" /></div>
              <div>
                <div className="text-xs text-slate-500 font-medium">Toplam Oturum</div>
                <div className="text-xl font-bold">{data.summary.total_sessions.toLocaleString()}</div>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="bg-amber-50 dark:bg-amber-950/30 p-2.5 rounded-xl"><Users className="w-5 h-5 text-amber-600" /></div>
              <div>
                <div className="text-xs text-slate-500 font-medium">Tekil Kullanıcı</div>
                <div className="text-xl font-bold">{data.summary.unique_macs.toLocaleString()}</div>
              </div>
            </div>
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="bg-rose-50 dark:bg-rose-950/30 p-2.5 rounded-xl"><Gauge className="w-5 h-5 text-rose-600" /></div>
              <div>
                <div className="text-xs text-slate-500 font-medium">Peak Eşzamanlı</div>
                <div className="text-xl font-bold">{data.summary.peak_concurrent}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Daily Traffic Chart */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <h3 className="text-lg font-semibold mb-4">Günlük Trafik (Son {period} Gün)</h3>
        <div className="relative h-48">
          <div className="absolute inset-0 flex items-end space-x-1">
            {data?.daily?.map((d: any, i: number) => {
              const total = d.bytes_in + d.bytes_out;
              const pct = maxBytes > 0 ? (total / maxBytes) * 100 : 0;
              return (
                <div key={i} className="flex-1 flex flex-col items-center" title={`${d.date}: ${formatBytes(total)}`}>
                  <div className="w-full bg-gradient-to-t from-indigo-500 to-violet-500 rounded-t" style={{ height: `${Math.max(pct, 1)}%` }}></div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="flex justify-between text-xs text-slate-400 mt-2">
          <span>{data?.daily?.[0]?.date}</span>
          <span>{data?.daily?.[data.daily.length - 1]?.date}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hourly Traffic */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Saatlik Trafik Dağılımı (Son 24s)</h3>
          <div className="space-y-2">
            {data?.hourly?.map((h: any, i: number) => {
              const maxH = Math.max(...(data?.hourly?.map((x: any) => x.bytes_in + x.bytes_out) || [1]));
              const pct = maxH > 0 ? ((h.bytes_in + h.bytes_out) / maxH) * 100 : 0;
              return (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <span className="w-10 text-right text-slate-500">{h.hour}</span>
                  <div className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
                    <div className="bg-gradient-to-r from-blue-500 to-cyan-500 h-full rounded-full transition-all" style={{ width: `${pct}%` }}></div>
                  </div>
                  <span className="w-20 text-right text-slate-500">{formatBytes(h.bytes_in + h.bytes_out)}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top Talkers */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Top Talkers (En Çok Trafik)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-slate-500">
                  <th className="pb-2 font-medium">#</th>
                  <th className="pb-2 font-medium">MAC</th>
                  <th className="pb-2 font-medium">Telefon</th>
                  <th className="pb-2 font-medium">Download</th>
                  <th className="pb-2 font-medium">Upload</th>
                  <th className="pb-2 font-medium">Oturum</th>
                </tr>
              </thead>
              <tbody>
                {data?.top_talkers?.map((t: any, i: number) => (
                  <tr key={i} className="border-b border-slate-100 dark:border-slate-800/50">
                    <td className="py-2 font-bold text-slate-400">{t.rank}</td>
                    <td className="py-2 font-mono text-xs">{t.mac}</td>
                    <td className="py-2">{t.phone || '-'}</td>
                    <td className="py-2 text-green-600 font-medium">{formatBytes(t.bytes_out)}</td>
                    <td className="py-2 text-blue-600 font-medium">{formatBytes(t.bytes_in)}</td>
                    <td className="py-2">{t.session_count}</td>
                  </tr>
                ))}
                {(!data?.top_talkers || data.top_talkers.length === 0) && <tr><td colSpan={6} className="py-4 text-center text-slate-500">Veri bulunmuyor.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Auth Method Distribution */}
      {dashboard?.auth_method_distribution && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2"><PieChart className="w-4 h-4 text-indigo-500" /> Doğrulama Yöntemi Dağılımı</h3>
          <div className="space-y-3">
            {Object.entries(dashboard.auth_method_distribution).map(([method, pct]: [string, any]) => (
              <div key={method} className="flex items-center gap-3">
                <span className="w-28 text-sm font-medium truncate">{method}</span>
                <div className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-full h-4 overflow-hidden">
                  <div className="bg-gradient-to-r from-indigo-500 to-violet-500 h-full rounded-full flex items-center justify-end px-2 text-[10px] text-white font-bold" style={{ width: `${pct}%` }}>{pct}%</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Top Locations */}
      {dashboard?.top_locations && dashboard.top_locations.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2"><MapPin className="w-4 h-4 text-indigo-500" /> En Yoğun Lokasyonlar</h3>
          <div className="space-y-3">
            {dashboard.top_locations.map((loc: any, i: number) => {
              const maxB = Math.max(...dashboard.top_locations.map((x: any) => x.total_bytes || 0), 1);
              const pct = ((loc.total_bytes || 0) / maxB) * 100;
              return (
                <div key={i} className="flex items-center gap-3">
                  <span className="w-6 text-sm font-bold text-slate-400">#{i + 1}</span>
                  <div className="flex-1">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium">{loc.location_id || loc.name || '-'}</span>
                      <span className="text-slate-500">{formatBytes(loc.total_bytes)}</span>
                    </div>
                    <div className="bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                      <div className="bg-gradient-to-r from-indigo-500 to-violet-500 h-full rounded-full transition-all" style={{ width: `${pct}%` }}></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Hourly Stats Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <h3 className="text-lg font-semibold mb-4">Saatlik Detay</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-slate-500">
                <th className="pb-2 font-medium">Saat</th>
                <th className="pb-2 font-medium">Download</th>
                <th className="pb-2 font-medium">Upload</th>
                <th className="pb-2 font-medium">Oturum</th>
                <th className="pb-2 font-medium">Aktif</th>
              </tr>
            </thead>
            <tbody>
              {data?.hourly?.map((h: any, i: number) => (
                <tr key={i} className="border-b border-slate-100 dark:border-slate-800/50">
                  <td className="py-2 font-medium">{h.hour}</td>
                  <td className="py-2 text-green-600">{formatBytes(h.bytes_out)}</td>
                  <td className="py-2 text-blue-600">{formatBytes(h.bytes_in)}</td>
                  <td className="py-2">{h.sessions}</td>
                  <td className="py-2">{h.active}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
