import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { StatusBadge } from '../src/components/ui/StatusBadge';

describe('StatusBadge', () => {
  it('renders Aktif label for online status', () => {
    render(<StatusBadge status="online" />);
    expect(screen.getByText('Aktif')).toBeInTheDocument();
  });

  it('renders Çevrimdışı label for offline status', () => {
    render(<StatusBadge status="offline" />);
    expect(screen.getByText('Çevrimdışı')).toBeInTheDocument();
  });

  it('renders Uyarı label for warning status', () => {
    render(<StatusBadge status="warning" />);
    expect(screen.getByText('Uyarı')).toBeInTheDocument();
  });
});
