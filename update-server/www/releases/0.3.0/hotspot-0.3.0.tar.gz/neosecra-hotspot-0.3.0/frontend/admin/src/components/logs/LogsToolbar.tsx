import React from 'react';
import { Search, Download, RefreshCw, BookmarkPlus, Bookmark } from 'lucide-react';
import type { TimeWindow, SearchView } from '../../types/logs';

interface Props {
  q: string;
  timeWindow: TimeWindow;
  from?: string;
  to?: string;
  loading: boolean;
  exporting: boolean;
  tenantName: string | null;
  savedSearches?: SearchView[];
  onQChange: (v: string) => void;
  onTimeWindowChange: (v: TimeWindow) => void;
  onFromChange?: (v: string) => void;
  onToChange?: (v: string) => void;
  onSearch: () => void;
  onExport: () => void;
  onRefresh: () => void;
  onSaveSearchClick?: () => void;
  onSelectSavedSearch?: (sv: SearchView) => void;
  onDeleteSavedSearch?: (id: string) => void;
}

const TIME_OPTIONS: { value: TimeWindow; label: string }[] = [
  { value: '15m', label: 'Son 15 dk' },
  { value: '1h', label: 'Son 1 saat' },
  { value: '24h', label: 'Son 24 saat' },
  { value: '7d', label: 'Son 7 gün' },
  { value: 'custom', label: 'Özel (Tarih Seç)' },
];

export const LogsToolbar: React.FC<Props> = ({
  q,
  timeWindow,
  from,
  to,
  loading,
  exporting,
  tenantName,
  savedSearches = [],
  onQChange,
  onTimeWindowChange,
  onFromChange,
  onToChange,
  onSearch,
  onExport,
  onRefresh,
  onSaveSearchClick,
  onSelectSavedSearch,
  onDeleteSavedSearch,
}) => {
  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-slate-200 bg-white p-2 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[260px] flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-500" />
          <input
            type="text"
            value={q}
            onChange={(e) => onQChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') onSearch();
            }}
            placeholder="Ara: IP, kullanıcı, mesaj, action veya korelasyon ID…"
            className="w-full rounded-xl border-0 bg-slate-50 py-3 pl-10 pr-4 text-sm outline-none ring-0 placeholder:text-slate-400 focus:bg-indigo-50/50 dark:bg-slate-950 dark:focus:bg-indigo-950/20"
          />
        </div>

        <select
          value={timeWindow}
          onChange={(e) => onTimeWindowChange(e.target.value as TimeWindow)}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-slate-800 dark:bg-slate-950"
        >
          {TIME_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>

        {savedSearches.length > 0 && onSelectSavedSearch && (
          <div className="relative">
            <select
              defaultValue=""
              onChange={(e) => {
                const s = savedSearches.find((item) => item.id === e.target.value);
                if (s) onSelectSavedSearch(s);
              }}
            className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:border-slate-800 dark:bg-slate-950"
            >
              <option value="" disabled>
                Kaydedilen Aramalar ({savedSearches.length})
              </option>
              {savedSearches.map((sv) => (
                <option key={sv.id} value={sv.id}>
                  {sv.name}
                </option>
              ))}
            </select>
          </div>
        )}

        {onSaveSearchClick && (
          <button
            onClick={onSaveSearchClick}
            title="Aramayı Kaydet"
            className="inline-flex items-center rounded-xl border border-slate-200 px-3 py-2.5 text-sm font-semibold transition-colors hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800"
          >
            <BookmarkPlus className="w-4 h-4 text-indigo-600 dark:text-indigo-400 mr-1.5" />
            Kaydet
          </button>
        )}

        <button
          onClick={onSearch}
          disabled={loading}
          className="inline-flex items-center rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm shadow-indigo-600/20 transition-colors hover:bg-indigo-700 disabled:opacity-60"
        >
          <Search className="w-4 h-4 mr-1.5" />
          Ara
        </button>

        <button
          onClick={onExport}
          disabled={exporting}
          className="inline-flex items-center rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold transition-colors hover:bg-slate-50 disabled:opacity-60 dark:border-slate-800 dark:hover:bg-slate-800"
        >
          <Download className={`w-4 h-4 mr-1.5 ${exporting ? 'animate-pulse' : ''}`} />
          {exporting ? 'Dışa Aktarılıyor...' : 'Dışa Aktar'}
        </button>

        <button
          onClick={onRefresh}
          disabled={loading}
          className="inline-flex items-center rounded-xl border border-slate-200 px-3 py-2.5 text-sm font-semibold transition-colors hover:bg-slate-50 disabled:opacity-60 dark:border-slate-800 dark:hover:bg-slate-800"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>

        {tenantName && (
          <div className="ml-auto text-xs font-semibold text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl">
            Tenant: {tenantName}
          </div>
        )}
      </div>
      </div>

      {timeWindow === 'custom' && (
        <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-900/50 p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
          <span className="font-semibold text-slate-500">Özel Zaman Aralığı:</span>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Başlangıç:</span>
            <input
              type="datetime-local"
              value={from ? from.substring(0, 16) : ''}
              onChange={(e) => onFromChange && onFromChange(e.target.value ? new Date(e.target.value).toISOString() : '')}
              className="px-2 py-1 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded-lg text-xs"
            />
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Bitiş:</span>
            <input
              type="datetime-local"
              value={to ? to.substring(0, 16) : ''}
              onChange={(e) => onToChange && onToChange(e.target.value ? new Date(e.target.value).toISOString() : '')}
              className="px-2 py-1 border border-slate-200 dark:border-slate-700 dark:bg-slate-800 rounded-lg text-xs"
            />
          </div>
        </div>
      )}
    </div>
  );
};
