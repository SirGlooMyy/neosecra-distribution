import React, { useState, useEffect } from "react";
import { getLocations, addLocation, deleteLocation, getCurrentScope } from "../lib/api";
import { Plus, Trash2, Search, MapPin, RefreshCw } from "lucide-react";

interface Location {
  id: string;
  customer_id?: string;
  name: string;
  customerName: string;
  ssid: string;
  timezone: string;
  devicesCount: number;
  status: string;
}

export const LocationsPage: React.FC = () => {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    defaultSsid: "",
    timezone: "Europe/Istanbul",
  });
  const [installationCustomerId, setInstallationCustomerId] = useState<string | null>(null);

  const loadLocations = async () => {
    setLoading(true);
    try {
      const data = await getLocations();
      setLocations((data || []).map((location: any) => ({
        ...location,
        id: String(location.id),
        customer_id: location.customer_id,
        customerName: location.customer_name || location.customer_id || "Kurulum müşterisi",
        ssid: location.default_ssid || "—",
        timezone: location.timezone || "Europe/Istanbul",
        devicesCount: Number(location.devices_count ?? location.devicesCount ?? 0),
        status: location.status || "online",
      })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLocations();
    getCurrentScope().then((scope) => {
      if (scope?.customer_id) setInstallationCustomerId(scope.customer_id);
    }).catch(() => undefined);
  }, []);

  const filtered = locations.filter(
    (l) =>
      l.name.toLowerCase().includes(search.toLowerCase()) ||
      l.customerName.toLowerCase().includes(search.toLowerCase()) ||
      l.ssid.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.defaultSsid) return;

    try {
      const newLoc = await addLocation({
        name: formData.name,
        ...(installationCustomerId ? { customer_id: installationCustomerId } : {}),
        default_ssid: formData.defaultSsid,
        timezone: formData.timezone,
      });
      setLocations([{ ...newLoc, customerName: newLoc.customer_id || "Kurulum müşterisi", ssid: newLoc.default_ssid || "—", devicesCount: 0, status: "online" }, ...locations]);
      setFormData({ name: "", defaultSsid: "", timezone: "Europe/Istanbul" });
      setShowAddForm(false);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm("Bu lokasyonu silmek istediğinize emin misiniz?")) {
      try {
        await deleteLocation(id);
        setLocations(locations.filter((l) => l.id !== id));
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Lokasyonlar</h2>
          <p className="text-sm text-slate-500">Wi-Fi ağlarının yayınlandığı fiziksel lokasyonları ve SSID profillerini yönetin.</p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-600/10 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Yeni Lokasyon Ekle
        </button>
      </div>

      {showAddForm && (
        <form onSubmit={handleAddSubmit} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4 animate-slide-in">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center">
            <MapPin className="w-4 h-4 mr-2 text-indigo-500" />
            Yeni Lokasyon Kartı Tanımla
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Lokasyon Adı</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Örn. Kadıköy Cafe Teras"
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Kurulum müşterisi</label>
              <div className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 rounded-xl text-sm text-slate-500">
                {installationCustomerId || "Otomatik atanır"}
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Default SSID (Kablosuz Ağ Adı)</label>
              <input
                type="text"
                required
                value={formData.defaultSsid}
                onChange={(e) => setFormData({ ...formData, defaultSsid: e.target.value })}
                placeholder="Örn. Cafe_Wifi_Guest"
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-500">Saat Dilimi</label>
              <select
                value={formData.timezone}
                onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
                className="w-full px-4 py-2 border border-slate-200 dark:border-slate-800 dark:bg-slate-950 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Europe/Istanbul">Europe/Istanbul (GMT+3)</option>
                <option value="Europe/London">Europe/London (GMT+0)</option>
                <option value="Europe/Berlin">Europe/Berlin (GMT+1)</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              İptal
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold"
            >
              Kaydet ve Oluştur
            </button>
          </div>
        </form>
      )}

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-3 text-slate-400 w-4 h-4" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Lokasyon, müşteri veya SSID ara..."
          className="w-full pl-11 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
        />
      </div>

      {/* Table Container */}
      <div className="w-full overflow-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
        {loading ? (
          <div className="flex justify-center items-center py-12 space-x-2">
            <RefreshCw className="w-6 h-6 text-indigo-500 animate-spin" />
            <span className="text-sm font-medium text-slate-500">Lokasyonlar yükleniyor...</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Lokasyon Adı</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Müşteri</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">SSID</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Zaman Dilimi</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Aktif Cihazlar</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Durum</th>
                  <th className="px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 text-right">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((l) => (
                  <tr key={l.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-slate-950 dark:text-slate-50 flex items-center">
                      <MapPin className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0" />
                      {l.name}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">{l.customerName}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      <span className="font-mono text-xs bg-slate-50 dark:bg-slate-950 px-2 py-1 rounded border border-slate-100 dark:border-slate-900 inline-block">
                        {l.ssid}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">{l.timezone}</td>
                    <td className="px-6 py-4 text-sm text-slate-500 font-semibold">{l.devicesCount} Cihaz</td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                        l.status === 'online'
                          ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30'
                          : 'bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-900/30'
                      }`}>
                        {l.status === 'online' ? 'Aktif' : 'Uyarı'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-right">
                      <button
                        onClick={() => handleDelete(l.id)}
                        className="text-rose-600 hover:text-rose-900 dark:hover:text-rose-400 p-2 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl transition-colors"
                      >
                        <Trash2 className="w-4.5 h-4.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-slate-500">
                      Arama kriterlerinize uygun lokasyon bulunamadı.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
