import React, { useEffect, useState } from 'react';
import { Award, CheckCircle2, RefreshCw, Upload, XCircle } from 'lucide-react';
import {
  activatePlatformLicense,
  getPlatformLicense,
  getPlatformLicenseUsage,
  removePlatformLicense,
  uploadPlatformLicense,
  validatePlatformLicense,
} from '../lib/api';

const statusLabel: Record<string, string> = {
  ACTIVE: 'Aktif', EXPIRING_SOON: 'Yakında sona eriyor', GRACE_PERIOD: 'Ek süre',
  EXPIRED: 'Süresi doldu', INVALID: 'Geçersiz', NOT_ACTIVATED: 'Kurulu değil',
};

export const PlatformLicensePage: React.FC = () => {
  const [license, setLicense] = useState<any>(null);
  const [usage, setUsage] = useState<any>(null);
  const [envelope, setEnvelope] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const [nextLicense, nextUsage] = await Promise.all([getPlatformLicense(), getPlatformLicenseUsage()]);
      setLicense(nextLicense);
      setUsage(nextUsage);
    } catch (error: any) {
      setMessage(error?.message || 'Lisans bilgisi yüklenemedi.');
    } finally { setLoading(false); }
  };
  useEffect(() => { void load(); }, []);

  const install = async () => {
    setSaving(true); setMessage(null);
    try {
      if (file) await uploadPlatformLicense(file);
      else if (envelope.trim()) await activatePlatformLicense(envelope.trim());
      else throw new Error('Bir .lic dosyası veya lisans envelope metni seçin.');
      setEnvelope(''); setFile(null); setMessage('Lisans doğrulandı ve kuruldu.'); await load();
    } catch (error: any) { setMessage(error?.message || 'Lisans kurulamadı.'); }
    finally { setSaving(false); }
  };

  const validate = async () => {
    setSaving(true); setMessage(null);
    try { await validatePlatformLicense(); setMessage('Lisans yeniden doğrulandı.'); await load(); }
    catch (error: any) { setMessage(error?.message || 'Lisans doğrulanamadı.'); }
    finally { setSaving(false); }
  };

  const remove = async () => {
    if (!window.confirm('Kurulu platform lisansı kaldırılacak. Devam edilsin mi?')) return;
    setSaving(true);
    try { await removePlatformLicense(); setMessage('Lisans kaldırıldı.'); await load(); }
    catch (error: any) { setMessage(error?.message || 'Lisans kaldırılamadı.'); }
    finally { setSaving(false); }
  };

  const status = license?.status || 'NOT_ACTIVATED';
  return <div className="space-y-6">
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div><h2 className="text-2xl font-bold">Platform Lisansı</h2><p className="text-sm text-slate-500">Neosecra lisans sunucusundan gelen imzalı envelope burada doğrulanır.</p></div>
      <div className="flex gap-2"><button onClick={validate} disabled={saving || !license?.license_id} className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm"><RefreshCw className="h-4 w-4" /> Yeniden doğrula</button><button onClick={remove} disabled={saving || !license?.license_id} className="inline-flex items-center gap-2 rounded-xl border border-rose-200 px-4 py-2 text-sm text-rose-600"><XCircle className="h-4 w-4" /> Kaldır</button></div>
    </div>
    {message && <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm dark:border-slate-800 dark:bg-slate-900">{message}</div>}
    <div className="grid gap-4 md:grid-cols-4">
      <div className="rounded-2xl border p-5"><p className="text-xs uppercase text-slate-500">Durum</p><p className="mt-2 text-xl font-bold">{loading ? '...' : statusLabel[status] || status}</p></div>
      <div className="rounded-2xl border p-5"><p className="text-xs uppercase text-slate-500">Edition</p><p className="mt-2 text-xl font-bold">{license?.edition || '-'}</p></div>
      <div className="rounded-2xl border p-5"><p className="text-xs uppercase text-slate-500">Güncelleme hakkı</p><p className="mt-2 text-sm font-semibold">{license?.update_entitlement_until ? new Date(license.update_entitlement_until).toLocaleDateString('tr-TR') : 'Eski lisans / sınırsız'}</p></div>
      <div className="rounded-2xl border p-5"><p className="text-xs uppercase text-slate-500">Kurulum ID</p><p className="mt-2 truncate text-sm font-mono">{license?.installation_id || '-'}</p></div>
    </div>
    <div className="grid gap-6 lg:grid-cols-2">
      <section className="rounded-2xl border p-6"><h3 className="mb-4 flex items-center gap-2 font-semibold"><Award className="h-5 w-5 text-indigo-500" /> Lisans kurulumu</h3><label className="mb-2 block text-xs font-semibold text-slate-500">.lic dosyası</label><input type="file" accept=".lic,.json,.txt" onChange={(e) => setFile(e.target.files?.[0] || null)} className="mb-4 block w-full text-sm" /><label className="mb-2 block text-xs font-semibold text-slate-500">veya envelope metni</label><textarea value={envelope} onChange={(e) => setEnvelope(e.target.value)} rows={7} placeholder="{ schema_version, key_id, payload, signature }" className="w-full rounded-xl border bg-transparent p-3 font-mono text-xs" /><button onClick={install} disabled={saving} className="mt-4 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"><Upload className="h-4 w-4" /> {saving ? 'Doğrulanıyor...' : 'Lisansı kur'}</button></section>
      <section className="rounded-2xl border p-6"><h3 className="mb-4 font-semibold">Modüller ve kullanım</h3><div className="mb-5 flex flex-wrap gap-2">{(license?.enabled_modules || []).map((module: string) => <span key={module} className="rounded-full bg-indigo-50 px-3 py-1 text-xs text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300">{module}</span>)}</div><div className="space-y-3 text-sm">{Object.entries(usage || {}).filter(([key]) => key !== 'scope').map(([key, value]) => <div key={key} className="flex justify-between border-b py-2"><span className="text-slate-500">{key}</span><strong>{String(value)}</strong></div>)}</div>{license?.status === 'ACTIVE' && <p className="mt-5 flex items-center gap-2 text-sm text-emerald-600"><CheckCircle2 className="h-4 w-4" /> İmza ve ürün eşleşmesi doğrulandı.</p>}</section>
    </div>
  </div>;
};
