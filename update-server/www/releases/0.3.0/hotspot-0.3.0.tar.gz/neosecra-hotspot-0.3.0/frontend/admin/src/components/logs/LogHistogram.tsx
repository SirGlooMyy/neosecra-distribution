import React, { useMemo } from 'react';
import type { FirewallLog } from '../../types/logs';
import { BarChart2 } from 'lucide-react';

interface Props {
  logs: FirewallLog[];
  histogram?: { timestamp: string; count: number }[];
  onBucketClick?: (from: string, to: string) => void;
}

export const LogHistogram: React.FC<Props> = ({ logs, histogram: serverHistogram, onBucketClick }) => {
  const histogram = useMemo(() => {
    if (!logs || logs.length === 0) return [];

    // The API aggregates all matching rows (not just the first page). Use it
    // when available so the timeline reflects the real result set.
    if (serverHistogram?.length) {
      const counts = serverHistogram.map((item) => ({
        startTime: new Date(item.timestamp).getTime(),
        endTime: new Date(item.timestamp).getTime() + 60 * 60 * 1000,
        label: new Date(item.timestamp).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
        count: item.count,
      }));
      const maxCount = Math.max(...counts.map((b) => b.count), 1);
      return counts.map((b) => ({ ...b, heightPct: Math.max(8, Math.round((b.count / maxCount) * 100)) }));
    }

    const timestamps = logs
      .map((l) => new Date(l.timestamp).getTime())
      .filter((t) => !isNaN(t))
      .sort((a, b) => a - b);

    if (timestamps.length === 0) return [];

    const min = timestamps[0];
    const max = timestamps[timestamps.length - 1];

    // Create 12 equal interval buckets
    const bucketCount = 12;
    const interval = Math.max((max - min) / bucketCount, 60000); // at least 1 min

    const buckets = Array.from({ length: bucketCount }, (_, i) => {
      const start = min + i * interval;
      const end = i === bucketCount - 1 ? max + 1 : start + interval;
      return {
        startTime: start,
        endTime: end,
        label: new Date(start).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
        count: 0,
      };
    });

    for (const ts of timestamps) {
      const idx = Math.min(Math.floor((ts - min) / interval), bucketCount - 1);
      if (buckets[idx]) {
        buckets[idx].count += 1;
      }
    }

    const maxCount = Math.max(...buckets.map((b) => b.count), 1);
    return buckets.map((b) => ({
      ...b,
      heightPct: Math.max(8, Math.round((b.count / maxCount) * 100)),
    }));
  }, [logs, serverHistogram]);

  if (!logs || logs.length === 0) {
    return null;
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3 dark:border-slate-800">
        <div className="flex items-center space-x-2">
          <BarChart2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
            Zaman yoğunluğu <span className="ml-1 font-normal normal-case text-slate-400">({logs.length} yüklenen / toplam sonuç)</span>
          </h3>
        </div>
        <span className="text-[11px] text-slate-400 font-mono">
          {new Date(logs[logs.length - 1]?.timestamp || Date.now()).toLocaleTimeString('tr-TR')} - {new Date(logs[0]?.timestamp || Date.now()).toLocaleTimeString('tr-TR')}
        </span>
      </div>

      <div className="relative flex h-32 items-end justify-between gap-1.5 px-4 pb-2 pt-4">
        <div className="pointer-events-none absolute inset-x-4 top-4 border-t border-dashed border-slate-100 dark:border-slate-800" />
        <div className="pointer-events-none absolute inset-x-4 top-1/2 border-t border-dashed border-slate-100 dark:border-slate-800" />
        {histogram.map((b, idx) => (
          <div
            key={idx}
            onClick={() => onBucketClick && onBucketClick(new Date(b.startTime).toISOString(), new Date(b.endTime).toISOString())}
            className="flex-1 flex flex-col items-center group cursor-pointer"
            title={`${b.label}: ${b.count} log (Zaman aralığına gitmek için tıklayın)`}
          >
            <div className="opacity-0 group-hover:opacity-100 bg-slate-800 text-white text-[10px] px-1.5 py-0.5 rounded transition-opacity duration-150 -translate-y-1 z-10 whitespace-nowrap">
              {b.count} log ({b.label})
            </div>
            <div
              style={{ height: `${b.heightPct}%` }}
              className="relative z-[1] w-full rounded-t-md bg-gradient-to-t from-indigo-600 to-violet-400 opacity-90 transition-all duration-200 group-hover:from-indigo-500 group-hover:to-cyan-300"
            />
            <span className="text-[10px] text-slate-400 mt-1 font-mono">{b.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
