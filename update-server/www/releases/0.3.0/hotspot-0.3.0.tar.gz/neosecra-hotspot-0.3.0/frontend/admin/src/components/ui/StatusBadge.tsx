import React from "react";
import { CheckCircle, XCircle, AlertCircle } from "lucide-react";

interface Props {
  status: "online" | "offline" | "warning" | string;
  className?: string;
}

export const StatusBadge: React.FC<Props> = ({ status, className = "" }) => {
  // Device adapters may report vendor-specific states (unknown, error,
  // degraded, maintenance, ...). Normalize those to a safe visual state so
  // an unexpected API value never becomes an undefined React element.
  const normalizedStatus: "online" | "offline" | "warning" =
    status === "online"
      ? "online"
      : status === "offline"
        ? "offline"
        : "warning";
  const colors = {
    online: "bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/30",
    offline: "bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-900/30",
    warning: "bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-900/30",
  } as const;

  const icons = {
    online: CheckCircle,
    offline: XCircle,
    warning: AlertCircle,
  } as const;

  const labels = {
    online: "Aktif",
    offline: "Çevrimdışı",
    warning: "Uyarı",
  } as const;

  const Icon = icons[normalizedStatus];
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${colors[normalizedStatus]} ${className}`}
    >
      <Icon className="w-3 h-3 mr-1.5 flex-shrink-0" />
      {normalizedStatus === "warning" && status !== "warning" ? status : labels[normalizedStatus]}
    </span>
  );
};
