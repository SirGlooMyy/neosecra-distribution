import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Download,
  FileCheck2,
  FileText,
  Gauge,
  MapPin,
  Radio,
  RefreshCw,
  Search,
  Server,
  ShieldAlert,
  ShieldCheck,
  Signal,
  UserRound,
  UsersRound,
  Wifi,
  Zap,
} from "lucide-react";
import { getDashboardOverview, getDevices, getFirewallLogs, getSessions } from "../lib/api";

type AnyRecord = Record<string, any>;

const RANGE_OPTIONS = [
  { label: "24 saat", days: 1 },
  { label: "7 gün", days: 7 },
  { label: "30 gün", days: 30 },
];

const toArray = (value: any): any[] => {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.items)) return value.items;
  if (Array.isArray(value?.results)) return value.results;
  if (Array.isArray(value?.data)) return value.data;
  return [];
};

const asNumber = (value: any, fallback = 0): number => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};

const formatNumber = (value: any) => new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 0 }).format(asNumber(value));

const formatBytes = (bytes: any) => {
  const value = asNumber(bytes);
  if (value < 1024) return `${formatNumber(value)} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  return `${(value / (1024 * 1024 * 1024)).toFixed(2)} GB`;
};

const formatTime = (value: any) => {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
};

const formatDate = (value: any) => {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleDateString("tr-TR", { day: "2-digit", month: "short" });
};

const sessionUser = (session: AnyRecord) => session.phone || session.username || session.user || session.mac || "Misafir";
const sessionLocation = (session: AnyRecord) => session.location_name || session.location?.name || session.ssid || session.nas_ip || session.device_name || "Lokasyon belirtilmedi";
const sessionBytes = (session: AnyRecord) => asNumber(session.bytes_in ?? session.bytesIn) + asNumber(session.bytes_out ?? session.bytesOut);

const toneForLog = (log: AnyRecord) => {
  const severity = String(log.severity || "info").toLowerCase();
  const action = String(log.action || log.event || "").toLowerCase();
  const message = String(log.message || "").toLowerCase();
  if (["critical", "alert", "emergency", "error"].includes(severity)) return "critical";
  if (["deny", "blocked", "block", "reject", "drop"].includes(action) || /\b(deny|blocked|block|reject|drop)\b/.test(message)) return "blocked";
  if (severity === "warning") return "warning";
  return "normal";
};

const logLabel = (log: AnyRecord) => {
  const type = String(log.log_type || log.logType || log.type || "event").toUpperCase();
  return `${type} · ${log.action || "olay"}`;
};

const Panel: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = "" }) => (
  <section className={`rounded-2xl border border-border bg-surface-panel shadow-[0_10px_30px_rgba(0,0,0,0.10)] ${className}`}>{children}</section>
);

const PanelHeader: React.FC<{ eyebrow?: string; title: string; description?: string; action?: React.ReactNode }> = ({ eyebrow, title, description, action }) => (
  <div className="flex items-start justify-between gap-4 border-b border-border-subtle px-5 py-4 sm:px-6">
    <div className="min-w-0">
      {eyebrow && <div className="mb-1 text-[10px] font-bold uppercase tracking-[0.18em] text-blue-400">{eyebrow}</div>}
      <h2 className="text-sm font-semibold text-primary sm:text-[15px]">{title}</h2>
      {description && <p className="mt-1 text-xs text-muted">{description}</p>}
    </div>
    {action}
  </div>
);

const EmptyState: React.FC<{ icon?: React.ReactNode; title: string; description: string; action?: React.ReactNode }> = ({ icon, title, description, action }) => (
  <div className="flex min-h-[170px] flex-col items-center justify-center px-5 text-center">
    <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-surface-elevated text-muted">{icon || <Activity className="h-4 w-4" />}</div>
    <div className="text-sm font-medium text-primary">{title}</div>
    <p className="mt-1 max-w-xs text-xs leading-5 text-muted">{description}</p>
    {action && <div className="mt-3">{action}</div>}
  </div>
);

const Metric: React.FC<{
  label: string;
  value: string | number;
  detail: string;
  icon: React.ReactNode;
  tone: "blue" | "cyan" | "amber" | "rose" | "violet";
  onClick?: () => void;
}> = ({ label, value, detail, icon, tone, onClick }) => {
  const toneClasses = {
    blue: "bg-blue-500/10 text-blue-400 border-blue-400/20",
    cyan: "bg-cyan-500/10 text-cyan-400 border-cyan-400/20",
    amber: "bg-amber-500/10 text-amber-400 border-amber-400/20",
    rose: "bg-rose-500/10 text-rose-400 border-rose-400/20",
    violet: "bg-violet-500/10 text-violet-400 border-violet-400/20",
  }[tone];
  return (
    <button type="button" onClick={onClick} className={`group rounded-2xl border border-border bg-surface-panel p-4 text-left transition duration-200 hover:-translate-y-0.5 hover:border-border-light hover:bg-surface-elevated ${onClick ? "cursor-pointer" : "cursor-default"}`}>
      <div className="flex items-center justify-between gap-3">
        <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted">{label}</span>
        <span className={`flex h-8 w-8 items-center justify-center rounded-xl border ${toneClasses}`}>{icon}</span>
      </div>
      <div className="mt-4 flex items-end justify-between gap-2">
        <span className="text-2xl font-bold tracking-tight text-primary sm:text-[28px]">{value}</span>
        {onClick && <ArrowRight className="mb-1 h-4 w-4 text-muted transition group-hover:translate-x-0.5 group-hover:text-blue-400" />}
      </div>
      <p className="mt-1 truncate text-xs text-muted">{detail}</p>
    </button>
  );
};

const Sparkline: React.FC<{ values: number[]; tone?: "blue" | "emerald" | "amber" }> = ({ values, tone = "blue" }) => {
  const colors = { blue: "#60a5fa", emerald: "#34d399", amber: "#fbbf24" };
  if (!values.length) return <div className="h-12 rounded-lg bg-surface-elevated" />;
  const max = Math.max(...values, 1);
  const points = values.map((value, index) => `${(index / Math.max(values.length - 1, 1)) * 100},${42 - (value / max) * 34}`).join(" ");
  return (
    <svg viewBox="0 0 100 46" preserveAspectRatio="none" className="h-12 w-full overflow-visible">
      <defs><linearGradient id={`spark-${tone}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={colors[tone]} stopOpacity=".28" /><stop offset="1" stopColor={colors[tone]} stopOpacity="0" /></linearGradient></defs>
      <polyline points={`0,46 ${points} 100,46`} fill={`url(#spark-${tone})`} stroke="none" />
      <polyline points={points} fill="none" stroke={colors[tone]} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
};

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const [range, setRange] = useState(30);
  const [refreshKey, setRefreshKey] = useState(0);
  const [overview, setOverview] = useState<AnyRecord | null>(null);
  const [sessions, setSessions] = useState<AnyRecord[]>([]);
  const [devices, setDevices] = useState<AnyRecord[]>([]);
  const [logs, setLogs] = useState<AnyRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [partialErrors, setPartialErrors] = useState<string[]>([]);
  const [quickSearch, setQuickSearch] = useState("");
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const errors: string[] = [];
    const safe = async <T,>(label: string, fn: () => Promise<T>, fallback: T): Promise<T> => {
      try { return await fn(); } catch (reason: any) {
        errors.push(`${label}: ${reason?.message || "veri alınamadı"}`);
        return fallback;
      }
    };
    const [nextOverview, nextSessions, nextDevices, nextLogs] = await Promise.all([
      safe("dashboard", () => getDashboardOverview(range), null),
      safe("sessions", () => getSessions(), []),
      safe("devices", () => getDevices(), []),
      safe("firewall logs", () => getFirewallLogs({ page: 1, page_size: 40, correlation_window_minutes: 15 }), []),
    ]);
    if (!nextOverview) setError("Dashboard verileri alınamadı. Oturumunuzu ve API bağlantısını kontrol edin.");
    setOverview(nextOverview || null);
    setSessions(toArray(nextSessions));
    setDevices(toArray(nextDevices));
    setLogs(toArray(nextLogs));
    setPartialErrors(errors);
    setLastUpdated(new Date().toISOString());
    setLoading(false);
  }, [range]);

  useEffect(() => { void load(); }, [load, refreshKey]);
  useEffect(() => {
    const timer = window.setInterval(() => setRefreshKey((value) => value + 1), 60000);
    return () => window.clearInterval(timer);
  }, []);

  const realtime = overview?.realtime || {};
  const traffic = overview?.traffic || {};
  const authentication = overview?.authentication || {};
  const trend = overview?.trend || {};
  const trendRows = toArray(trend.daily).map((item: AnyRecord) => ({ date: item.date, count: asNumber(item.count ?? item.total) }));
  const locations = toArray(overview?.top_locations);
  const authMethods = toArray(overview?.auth_methods);
  const activeSessions = sessions.filter((session) => String(session.status || "").toLowerCase() === "active");
  const onlineDevices = devices.filter((device) => ["online", "connected", "healthy"].includes(String(device.status || "").toLowerCase()));
  const criticalLogs = logs.filter((log) => toneForLog(log) === "critical");
  const blockedLogs = logs.filter((log) => toneForLog(log) === "blocked");
  const warningLogs = logs.filter((log) => toneForLog(log) === "warning");
  const trafficTotal = asNumber(traffic.bytes_total) || asNumber(traffic.bytes_in) + asNumber(traffic.bytes_out);
  const authRate = asNumber(authentication.success_rate);
  const today = asNumber(realtime.today_guests);
  const todayDelta = asNumber(trend.change_percent);

  const leaderRows = useMemo(() => {
    const byUser = new Map<string, { name: string; bytes: number; sessions: number }>();
    [...sessions, ...toArray(overview?.top_users)].forEach((item: AnyRecord) => {
      const name = sessionUser(item);
      const row = byUser.get(name) || { name, bytes: 0, sessions: 0 };
      row.bytes += sessionBytes(item) || asNumber(item.bytes_total);
      row.sessions += asNumber(item.session_count) || 1;
      byUser.set(name, row);
    });
    return Array.from(byUser.values()).sort((a, b) => (b.bytes || b.sessions) - (a.bytes || a.sessions)).slice(0, 5);
  }, [sessions, overview]);

  const trendValues = trendRows.slice(-14).map((item) => item.count);
  const maxLeader = Math.max(...leaderRows.map((item) => item.bytes || item.sessions), 1);

  const submitQuickSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const value = quickSearch.trim();
    if (value) navigate(`/logs/search?q=${encodeURIComponent(value)}`);
  };

  if (loading && !overview) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center">
        <div className="flex items-center gap-3 rounded-2xl border border-border bg-surface-panel px-5 py-4 text-sm text-secondary shadow-elevated"><RefreshCw className="h-4 w-4 animate-spin text-blue-400" /> Operasyon merkezi yükleniyor…</div>
      </div>
    );
  }

  return (
    <div className="space-y-5 pb-8">
      <header className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
        <div>
          <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-blue-400"><span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" /> Operasyon merkezi</div>
          <h1 className="mt-2 text-2xl font-bold tracking-tight text-primary sm:text-3xl">Hotspot genel bakış</h1>
          <p className="mt-1 max-w-2xl text-sm text-secondary">Captive portal trafiğini, misafir oturumlarını ve FortiGate güvenlik akışını tek bakışta yönetin.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-xl border border-border bg-surface-panel p-1">
            {RANGE_OPTIONS.map((option) => <button key={option.days} type="button" onClick={() => setRange(option.days)} className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${range === option.days ? "bg-blue-500/15 text-blue-400" : "text-muted hover:text-primary"}`}>{option.label}</button>)}
          </div>
          <button type="button" onClick={() => setRefreshKey((value) => value + 1)} className="inline-flex items-center gap-2 rounded-xl border border-border bg-surface-panel px-3 py-2 text-xs font-semibold text-secondary transition hover:border-border-light hover:text-primary"><RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Yenile</button>
          <button type="button" onClick={() => navigate("/reports")} className="inline-flex items-center gap-2 rounded-xl bg-blue-500 px-3 py-2 text-xs font-bold text-white shadow-lg shadow-blue-500/20 transition hover:bg-blue-400"><FileText className="h-3.5 w-3.5" /> Rapor oluştur</button>
        </div>
      </header>

      {error && <div className="flex items-center justify-between gap-3 rounded-xl border border-rose-400/20 bg-rose-500/10 px-4 py-3 text-xs text-rose-300"><span>{error}</span><button type="button" onClick={() => setRefreshKey((value) => value + 1)} className="font-semibold underline">Tekrar dene</button></div>}
      {partialErrors.length > 0 && !error && <div className="flex items-center gap-2 rounded-xl border border-amber-400/20 bg-amber-500/10 px-4 py-3 text-xs text-amber-300"><ShieldAlert className="h-4 w-4" /> Bazı ikincil veri kaynakları yanıt vermedi; mevcut veriler gösteriliyor.</div>}

      <form onSubmit={submitQuickSearch} className="group flex flex-col gap-2 rounded-2xl border border-border bg-surface-panel p-2 shadow-[0_8px_24px_rgba(0,0,0,0.12)] sm:flex-row sm:items-center">
        <div className="flex min-w-0 flex-1 items-center gap-3 px-3"><Search className="h-4 w-4 shrink-0 text-muted" /><input value={quickSearch} onChange={(event) => setQuickSearch(event.target.value)} placeholder="IP, MAC, telefon, kullanıcı, domain veya session ID ile hızlı ara" className="min-w-0 flex-1 bg-transparent py-2 text-sm text-primary outline-none placeholder:text-muted" /></div>
        <button type="submit" disabled={!quickSearch.trim()} className="inline-flex items-center justify-center gap-2 rounded-xl bg-surface-elevated px-4 py-2 text-xs font-bold text-primary transition hover:bg-blue-500 hover:text-white disabled:cursor-not-allowed disabled:opacity-40"><Search className="h-3.5 w-3.5" /> Loglarda ara</button>
      </form>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Metric label="Aktif misafir" value={formatNumber(realtime.online_guests)} detail="Şu an captive portal üzerinde" icon={<UsersRound className="h-4 w-4" />} tone="blue" onClick={() => navigate("/online-users")} />
        <Metric label="Bugünkü oturum" value={formatNumber(today)} detail={`${todayDelta >= 0 ? "+" : ""}${todayDelta.toFixed(1)}% dünkü trende göre`} icon={todayDelta >= 0 ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />} tone="cyan" onClick={() => navigate("/sessions")} />
        <Metric label="Trafik" value={formatBytes(trafficTotal)} detail={`${formatBytes(traffic.bytes_in)} giriş · ${formatBytes(traffic.bytes_out)} çıkış`} icon={<BarChart3 className="h-4 w-4" />} tone="violet" onClick={() => navigate("/traffic-analysis")} />
        <Metric label="Engellenen olay" value={formatNumber(blockedLogs.length)} detail={`${formatNumber(criticalLogs.length)} kritik güvenlik olayı`} icon={<ShieldAlert className="h-4 w-4" />} tone="rose" onClick={() => navigate("/firewall-logs")} />
        <Metric label="FortiGate bağlantısı" value={formatNumber(onlineDevices.length || realtime.active_devices)} detail={`${formatNumber(devices.length)} tanımlı cihaz · ${formatNumber(warningLogs.length)} uyarı`} icon={<Server className="h-4 w-4" />} tone="amber" onClick={() => navigate("/devices")} />
      </div>

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1.65fr)_minmax(340px,0.85fr)]">
        <Panel className="overflow-hidden">
          <PanelHeader eyebrow="Canlı görünüm" title="Portal aktivitesi" description="Son seçili dönemin oturum ritmi ve anlık misafir durumu" action={<button type="button" onClick={() => navigate("/sessions")} className="inline-flex items-center gap-1 text-xs font-semibold text-blue-400 hover:text-blue-300">Oturumları aç <ChevronRight className="h-3.5 w-3.5" /></button>} />
          <div className="grid gap-5 p-5 sm:p-6 lg:grid-cols-[1fr_250px]">
            <div>
              <div className="flex items-end justify-between gap-4"><div><div className="text-3xl font-bold tracking-tight text-primary">{formatNumber(realtime.online_guests)}</div><div className="mt-1 flex items-center gap-2 text-xs text-muted"><span className="inline-flex items-center gap-1 text-emerald-400"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> canlı bağlantı</span><span>·</span><span>{formatNumber(realtime.peak_today)} saatlik pik</span></div></div><div className="text-right"><div className="text-xs font-semibold text-secondary">{range} günlük toplam</div><div className="mt-1 text-sm text-muted">{formatNumber(trendRows.reduce((sum, item) => sum + item.count, 0))} oturum</div></div></div>
              <div className="mt-5 rounded-xl border border-border-subtle bg-surface-elevated/60 p-3"><Sparkline values={trendValues} tone="blue" /><div className="mt-1 flex justify-between text-[10px] text-muted"><span>{trendRows[trendRows.length - 14]?.date ? formatDate(trendRows[trendRows.length - 14].date) : "—"}</span><span>{trendRows[trendRows.length - 1]?.date ? formatDate(trendRows[trendRows.length - 1].date) : "bugün"}</span></div></div>
              <div className="mt-5 grid grid-cols-3 gap-2"><div className="rounded-xl border border-border-subtle bg-surface-elevated/50 p-3"><div className="text-[10px] uppercase tracking-wider text-muted">Başarılı OTP</div><div className="mt-1 text-lg font-bold text-primary">%{authRate.toFixed(1)}</div></div><div className="rounded-xl border border-border-subtle bg-surface-elevated/50 p-3"><div className="text-[10px] uppercase tracking-wider text-muted">Toplam deneme</div><div className="mt-1 text-lg font-bold text-primary">{formatNumber(authentication.attempts)}</div></div><div className="rounded-xl border border-border-subtle bg-surface-elevated/50 p-3"><div className="text-[10px] uppercase tracking-wider text-muted">Aktif lokasyon</div><div className="mt-1 text-lg font-bold text-primary">{formatNumber(locations.length)}</div></div></div>
            </div>
            <div className="rounded-2xl border border-border-subtle bg-gradient-to-br from-blue-500/15 via-surface-elevated to-surface-elevated p-4"><div className="flex items-center justify-between"><span className="text-xs font-semibold text-secondary">Canlı kapasite</span><Gauge className="h-4 w-4 text-blue-400" /></div><div className="mt-8 flex items-center justify-center"><div className="relative flex h-32 w-32 items-center justify-center rounded-full" style={{ background: `conic-gradient(#60a5fa ${Math.min(100, asNumber(realtime.online_guests) / Math.max(asNumber(realtime.peak_today), asNumber(realtime.online_guests), 1) * 100)}%, rgba(148,163,184,.12) 0)` }}><div className="flex h-24 w-24 flex-col items-center justify-center rounded-full bg-surface-panel"><span className="text-2xl font-bold text-primary">{formatNumber(realtime.online_guests)}</span><span className="text-[10px] text-muted">aktif</span></div></div></div><div className="mt-6 flex items-center justify-between text-xs"><span className="text-muted">Günlük pik</span><span className="font-semibold text-primary">{formatNumber(realtime.peak_today)}</span></div><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-surface-panel"><div className="h-full rounded-full bg-blue-400" style={{ width: `${Math.min(100, asNumber(realtime.online_guests) / Math.max(asNumber(realtime.peak_today), asNumber(realtime.online_guests), 1) * 100)}%` }} /></div></div>
          </div>
        </Panel>

        <Panel className="overflow-hidden">
          <PanelHeader eyebrow="Güvenlik pulse" title="Firewall olayları" description="Son 40 kayıt içindeki risk dağılımı" action={<button type="button" onClick={() => navigate("/firewall-logs")} className="text-xs font-semibold text-blue-400">Tüm kayıtlar</button>} />
          <div className="grid grid-cols-3 gap-2 px-5 pt-5 sm:px-6"><div className="rounded-xl border border-rose-400/20 bg-rose-500/10 p-3"><div className="text-[10px] uppercase tracking-wider text-rose-300">Kritik</div><div className="mt-1 text-xl font-bold text-rose-300">{criticalLogs.length}</div></div><div className="rounded-xl border border-amber-400/20 bg-amber-500/10 p-3"><div className="text-[10px] uppercase tracking-wider text-amber-300">Bloklandı</div><div className="mt-1 text-xl font-bold text-amber-300">{blockedLogs.length}</div></div><div className="rounded-xl border border-blue-400/20 bg-blue-500/10 p-3"><div className="text-[10px] uppercase tracking-wider text-blue-300">Toplam</div><div className="mt-1 text-xl font-bold text-blue-300">{logs.length}</div></div></div>
          <div className="mt-4 divide-y divide-border-subtle px-5 pb-3 sm:px-6">{logs.slice(0, 5).map((log, index) => { const tone = toneForLog(log); return <button key={log.id || index} type="button" onClick={() => navigate("/firewall-logs")} className="flex w-full items-center gap-3 py-3 text-left transition hover:bg-surface-hover/50"><span className={`h-2 w-2 shrink-0 rounded-full ${tone === "critical" ? "bg-rose-400" : tone === "blocked" ? "bg-amber-400" : tone === "warning" ? "bg-yellow-300" : "bg-emerald-400"}`} /><div className="min-w-0 flex-1"><div className="truncate text-xs font-medium text-primary">{log.message || logLabel(log)}</div><div className="mt-1 flex items-center gap-2 text-[10px] text-muted"><span>{log.source_ip || log.src_ip || "—"}</span><span>·</span><span>{log.vendor || "FortiGate"}</span></div></div><div className="shrink-0 text-right"><div className="text-[10px] font-semibold text-secondary">{String(log.severity || "info")}</div><div className="mt-1 text-[10px] text-muted">{formatTime(log.timestamp || log.event_time || log.received_at)}</div></div></button>; })}</div>
          {!logs.length && <EmptyState icon={<ShieldCheck className="h-4 w-4" />} title="Henüz firewall olayı yok" description="FortiGate syslog akışı bağlandığında güvenlik olayları burada görünür." action={<button type="button" onClick={() => navigate("/firewall-logs")} className="text-xs font-semibold text-blue-400">Log kaynağını kontrol et</button>} />}
        </Panel>
      </div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]">
        <Panel className="overflow-hidden">
          <PanelHeader eyebrow="Operasyon kuyruğu" title="Aktif oturumlar" description="Captive portal üzerinden şu anda yetkilendirilmiş kullanıcılar" action={<button type="button" onClick={() => navigate("/online-users")} className="inline-flex items-center gap-1 text-xs font-semibold text-blue-400">Canlı liste <ChevronRight className="h-3.5 w-3.5" /></button>} />
          {activeSessions.length ? <div className="overflow-x-auto"><table className="w-full min-w-[620px] text-left"><thead><tr className="border-b border-border-subtle text-[10px] uppercase tracking-wider text-muted"><th className="px-5 py-3 font-semibold sm:px-6">Kullanıcı</th><th className="px-3 py-3 font-semibold">Lokasyon</th><th className="px-3 py-3 font-semibold">Başlangıç</th><th className="px-3 py-3 font-semibold">Trafik</th><th className="px-5 py-3 text-right font-semibold sm:px-6">Durum</th></tr></thead><tbody className="divide-y divide-border-subtle">{activeSessions.slice(0, 6).map((session, index) => <tr key={session.id || index} className="transition hover:bg-surface-hover/40"><td className="px-5 py-3 sm:px-6"><div className="flex items-center gap-3"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500/10 text-blue-400"><UserRound className="h-4 w-4" /></div><div className="min-w-0"><div className="max-w-[150px] truncate text-xs font-semibold text-primary">{sessionUser(session)}</div><div className="mt-0.5 max-w-[150px] truncate text-[10px] text-muted">{session.mac || session.ip || "kimlik bilgisi yok"}</div></div></div></td><td className="px-3 py-3 text-xs text-secondary">{sessionLocation(session)}</td><td className="px-3 py-3 text-xs text-secondary">{formatTime(session.started_at || session.start_time)}</td><td className="px-3 py-3 text-xs font-semibold text-primary">{formatBytes(sessionBytes(session))}</td><td className="px-5 py-3 text-right sm:px-6"><span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2 py-1 text-[10px] font-semibold text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Aktif</span></td></tr>)}</tbody></table></div> : <EmptyState icon={<Wifi className="h-4 w-4" />} title="Aktif oturum yok" description="Yeni bir misafir doğrulandığında canlı oturumlar bu tabloda görünecek." action={<button type="button" onClick={() => navigate("/auth-methods")} className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-secondary hover:text-primary">Doğrulama yöntemleri <ArrowRight className="h-3 w-3" /></button>} />}
        </Panel>

        <Panel className="overflow-hidden">
          <PanelHeader eyebrow="5651 hazırlık" title="Kanıt zinciri" description="Arşivleme ve imza operasyonu için hızlı durum" action={<button type="button" onClick={() => navigate("/archives")} className="text-xs font-semibold text-blue-400">Arşivleri aç</button>} />
          <div className="space-y-3 p-5 sm:p-6"><div className="flex items-center gap-3 rounded-xl border border-emerald-400/20 bg-emerald-500/10 p-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-400/15 text-emerald-300"><FileCheck2 className="h-4 w-4" /></div><div className="min-w-0 flex-1"><div className="text-xs font-semibold text-primary">Log alımı aktif</div><div className="mt-1 text-[10px] text-emerald-200/70">FortiGate olayları arşiv zincirine hazırlanıyor</div></div><CheckCircle2 className="h-4 w-4 text-emerald-300" /></div><div className="grid grid-cols-2 gap-3"><div className="rounded-xl border border-border-subtle bg-surface-elevated/60 p-3"><div className="flex items-center gap-2 text-[10px] text-muted"><Clock3 className="h-3.5 w-3.5" /> Zaman damgası</div><div className="mt-2 text-sm font-bold text-primary">Hazır</div></div><div className="rounded-xl border border-border-subtle bg-surface-elevated/60 p-3"><div className="flex items-center gap-2 text-[10px] text-muted"><ShieldCheck className="h-3.5 w-3.5" /> İmza</div><div className="mt-2 text-sm font-bold text-primary">Kontrol et</div></div></div><button type="button" onClick={() => navigate("/archives")} className="flex w-full items-center justify-between rounded-xl border border-border bg-surface-elevated/50 px-3 py-2.5 text-left text-xs font-semibold text-secondary transition hover:border-border-light hover:text-primary"><span>Arşiv ve imza akışını yönet</span><ArrowRight className="h-3.5 w-3.5" /></button></div>
        </Panel>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Panel className="overflow-hidden lg:col-span-2">
          <PanelHeader eyebrow="Lokasyon karşılaştırması" title="En yoğun lokasyonlar" description="Oturum hacmine göre ilk lokasyonlar" action={<button type="button" onClick={() => navigate("/locations")} className="inline-flex items-center gap-1 text-xs font-semibold text-blue-400">Lokasyonları yönet <ChevronRight className="h-3.5 w-3.5" /></button>} />
          {locations.length ? <div className="grid gap-3 p-5 sm:grid-cols-2 sm:p-6">{locations.slice(0, 6).map((location: AnyRecord, index) => { const count = asNumber(location.session_count ?? location.count ?? location.sessions); const max = Math.max(...locations.map((item: AnyRecord) => asNumber(item.session_count ?? item.count ?? item.sessions)), 1); return <div key={location.id || index} className="rounded-xl border border-border-subtle bg-surface-elevated/50 p-3"><div className="flex items-center justify-between gap-3"><div className="flex min-w-0 items-center gap-2"><span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-lg text-[10px] font-bold ${index === 0 ? "bg-amber-400/20 text-amber-300" : "bg-blue-500/10 text-blue-400"}`}>{index + 1}</span><span className="truncate text-xs font-semibold text-primary">{location.name || location.location_name || "Lokasyon"}</span></div><span className="text-xs font-bold text-secondary">{formatNumber(count)}</span></div><div className="mt-3 h-1.5 overflow-hidden rounded-full bg-surface-panel"><div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-400" style={{ width: `${Math.max(5, (count / max) * 100)}%` }} /></div><div className="mt-2 flex justify-between text-[10px] text-muted"><span><MapPin className="mr-1 inline h-3 w-3" />{location.city || location.address || "çok lokasyonlu yapı"}</span><span>oturum</span></div></div>; })}</div> : <EmptyState icon={<MapPin className="h-4 w-4" />} title="Lokasyon verisi yok" description="Lokasyonlar tanımlandığında performans karşılaştırması burada görünecek." action={<button type="button" onClick={() => navigate("/locations")} className="text-xs font-semibold text-blue-400">Lokasyon ekle</button>} />}
        </Panel>

        <Panel className="overflow-hidden">
          <PanelHeader eyebrow="Doğrulama" title="Kullanım dağılımı" description="Son seçili dönem" action={<button type="button" onClick={() => navigate("/auth-methods")} className="text-xs font-semibold text-blue-400">Yapılandır</button>} />
          <div className="space-y-4 p-5 sm:p-6">{authMethods.length ? authMethods.slice(0, 5).map((method: AnyRecord, index) => { const count = asNumber(method.count); const total = Math.max(authMethods.reduce((sum: number, item: AnyRecord) => sum + asNumber(item.count), 0), 1); const colors = ["bg-blue-400", "bg-violet-400", "bg-cyan-400", "bg-amber-400", "bg-emerald-400"]; return <div key={method.method || index}><div className="flex items-center justify-between gap-3 text-xs"><span className="flex min-w-0 items-center gap-2 text-secondary"><span className={`h-2 w-2 rounded-full ${colors[index % colors.length]}`} /> <span className="truncate">{method.method || "Bilinmeyen"}</span></span><span className="font-semibold text-primary">%{Math.round((count / total) * 100)} · {formatNumber(count)}</span></div><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-surface-elevated"><div className={`h-full rounded-full ${colors[index % colors.length]}`} style={{ width: `${(count / total) * 100}%` }} /></div></div>; }) : <EmptyState icon={<Signal className="h-4 w-4" />} title="Doğrulama verisi yok" description="SMS/OTP veya diğer portal yöntemleri kullanılmaya başladığında dağılım burada oluşur." />}</div>
        </Panel>
      </div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(260px,0.7fr)]">
        <Panel className="overflow-hidden">
          <PanelHeader eyebrow="Kullanıcı analizi" title="Trafik liderleri" description="Oturum ve byte verisine göre öne çıkan kullanıcılar" action={<button type="button" onClick={() => navigate("/traffic-analysis")} className="inline-flex items-center gap-1 text-xs font-semibold text-blue-400">Detaylı analiz <ChevronRight className="h-3.5 w-3.5" /></button>} />
          {leaderRows.length ? <div className="space-y-3 p-5 sm:p-6">{leaderRows.map((leader, index) => { const value = leader.bytes || leader.sessions; return <div key={leader.name} className="flex items-center gap-3"><span className="w-4 text-center text-xs font-bold text-muted">{index + 1}</span><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-elevated text-secondary"><UserRound className="h-3.5 w-3.5" /></div><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-3"><span className="truncate text-xs font-semibold text-primary">{leader.name}</span><span className="shrink-0 text-xs font-semibold text-secondary">{leader.bytes ? formatBytes(leader.bytes) : `${formatNumber(leader.sessions)} oturum`}</span></div><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-surface-elevated"><div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-blue-400" style={{ width: `${Math.max(6, (value / maxLeader) * 100)}%` }} /></div></div></div>; })}</div> : <EmptyState icon={<BarChart3 className="h-4 w-4" />} title="Trafik lideri oluşmadı" description="Oturumlarda byte bilgisi veya kullanıcı trafiği oluştuğunda sıralama burada görünür." />}
        </Panel>
        <Panel className="overflow-hidden">
          <PanelHeader eyebrow="Hızlı aksiyon" title="Operasyon kısayolları" />
          <div className="space-y-2 p-5 sm:p-6"><button type="button" onClick={() => navigate("/firewall-logs")} className="flex w-full items-center gap-3 rounded-xl border border-border-subtle bg-surface-elevated/50 p-3 text-left transition hover:border-border-light hover:bg-surface-elevated"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-500/10 text-rose-300"><Search className="h-4 w-4" /></div><div className="min-w-0 flex-1"><div className="text-xs font-semibold text-primary">Güvenlik olayı ara</div><div className="mt-0.5 text-[10px] text-muted">Trafik, VPN, UTM</div></div><ChevronRight className="h-3.5 w-3.5 text-muted" /></button><button type="button" onClick={() => navigate("/reports")} className="flex w-full items-center gap-3 rounded-xl border border-border-subtle bg-surface-elevated/50 p-3 text-left transition hover:border-border-light hover:bg-surface-elevated"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500/10 text-blue-300"><Download className="h-4 w-4" /></div><div className="min-w-0 flex-1"><div className="text-xs font-semibold text-primary">5651 raporu al</div><div className="mt-0.5 text-[10px] text-muted">PDF / arşiv çıktısı</div></div><ChevronRight className="h-3.5 w-3.5 text-muted" /></button><button type="button" onClick={() => navigate("/auth-methods")} className="flex w-full items-center gap-3 rounded-xl border border-border-subtle bg-surface-elevated/50 p-3 text-left transition hover:border-border-light hover:bg-surface-elevated"><div className="flex h-8 w-8 items-center justify-center rounded-lg bg-violet-500/10 text-violet-300"><Zap className="h-4 w-4" /></div><div className="min-w-0 flex-1"><div className="text-xs font-semibold text-primary">OTP ayarlarını aç</div><div className="mt-0.5 text-[10px] text-muted">SMS ve VPN MFA</div></div><ChevronRight className="h-3.5 w-3.5 text-muted" /></button></div>
        </Panel>
      </div>

      <footer className="flex flex-col gap-2 border-t border-border-subtle pt-4 text-[11px] text-muted sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-2"><Radio className="h-3.5 w-3.5 text-emerald-400" /> Veri akışı izleniyor <span className="text-border-light">·</span> <CalendarDays className="h-3.5 w-3.5" /> {range} günlük görünüm</div><div>Son güncelleme {formatTime(lastUpdated)} · <button type="button" onClick={() => navigate("/settings")} className="text-blue-400 hover:text-blue-300">Sistem durumunu aç</button></div></footer>
    </div>
  );
};
