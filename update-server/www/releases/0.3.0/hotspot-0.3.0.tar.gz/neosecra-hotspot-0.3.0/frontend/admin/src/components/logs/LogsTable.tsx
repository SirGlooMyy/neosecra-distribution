import React from 'react';
import { GitCompare, Loader2, ChevronRight } from 'lucide-react';
import type { FirewallLog } from '../../types/logs';

interface Props {
  logs: FirewallLog[];
  loading: boolean;
  hasNext: boolean;
  total: number;
  onLoadMore: () => void;
  onCorrelate: (sessionId: string) => void;
  onSelectLog?: (log: FirewallLog) => void;
}

const severityColor: Record<string, string> = {
  emergency: 'bg-rose-100 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400 border-rose-200 dark:border-rose-900/30',
  alert: 'bg-rose-100 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400 border-rose-200 dark:border-rose-900/30',
  critical: 'bg-rose-100 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400 border-rose-200 dark:border-rose-900/30',
  error: 'bg-orange-100 text-orange-700 dark:bg-orange-950/30 dark:text-orange-400 border-orange-200 dark:border-orange-900/30',
  high: 'bg-red-100 text-red-700 dark:bg-red-950/30 dark:text-red-400 border-red-200 dark:border-red-900/30',
  medium: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400 border-amber-200 dark:border-amber-900/30',
  warning: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400 border-amber-200 dark:border-amber-900/30',
  notice: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/30 dark:text-cyan-400 border-cyan-200 dark:border-cyan-900/30',
  low: 'bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400 border-blue-200 dark:border-blue-900/30',
  info: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border-slate-200 dark:border-slate-700',
};

const actionColor: Record<string, string> = {
  accept: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/30',
  deny: 'bg-rose-100 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400 border-rose-200 dark:border-rose-900/30',
  'client-rst': 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400 border-amber-200 dark:border-amber-900/30',
  'server-rst': 'bg-orange-100 text-orange-700 dark:bg-orange-950/30 dark:text-orange-400 border-orange-200 dark:border-orange-900/30',
  block: 'bg-rose-100 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400 border-rose-200 dark:border-rose-900/30',
  blocked: 'bg-rose-100 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400 border-rose-200 dark:border-rose-900/30',
  timeout: 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400 border-amber-200 dark:border-amber-900/30',
};

export const LogsTable: React.FC<Props> = ({ logs, loading, hasNext, total, onLoadMore, onCorrelate, onSelectLog }) => {

  if (loading && logs.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
        <div className="space-y-3 p-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="animate-pulse flex gap-4">
              <div className="h-4 w-32 bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="h-4 w-48 bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="h-4 w-24 bg-slate-200 dark:bg-slate-800 rounded" />
              <div className="h-4 w-16 bg-slate-200 dark:bg-slate-800 rounded" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!loading && logs.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm p-12 text-center">
        <p className="text-slate-400 text-sm">Son 24 saatte eşleşme yok</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Zaman</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Kaynak → Hedef</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Kullanıcı</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Action</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Severity</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Log Türü</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Mesaj</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-slate-500 text-right">Detay</th>
              <th className="px-4 py-3 w-10" />
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {logs.map((log) => (
              <React.Fragment key={log.id}>
                <tr
                  className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors cursor-pointer"
                  onClick={() => onSelectLog?.(log)}
                >
                  <td className="px-4 py-3 text-sm text-slate-500 whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleString('tr-TR')}
                  </td>
                  <td className="px-4 py-3 text-sm font-mono text-xs text-slate-700 dark:text-slate-300">
                    <span className="text-indigo-600 dark:text-indigo-400">{log.src_ip}</span>
                    {log.src_port != null && <span className="text-slate-400">:{log.src_port}</span>}
                    <span className="text-slate-400 mx-1">→</span>
                    <span className="text-amber-600 dark:text-amber-400">{log.dst_ip}</span>
                    {log.dst_port != null && <span className="text-slate-400">:{log.dst_port}</span>}
                  </td>
                  <td className="px-4 py-3 text-sm text-slate-600 dark:text-slate-400">
                    {log.user || <span className="text-slate-300">—</span>}
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium border ${actionColor[log.action] || 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'}`}>
                      {log.action}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium border ${severityColor[log.severity] || severityColor.info}`}>
                      {log.severity}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-slate-600 dark:text-slate-400">{log.log_type}</td>
                  <td className="px-4 py-3 text-sm text-slate-500 max-w-[260px] truncate">{log.message}</td>
                  <td className="px-4 py-3 text-right">
                    <ChevronRight className="w-4 h-4 text-slate-400 inline transition-transform group-hover:translate-x-0.5" />
                  </td>
                  <td className="px-2 py-3">
                    <button
                      onClick={(e) => { e.stopPropagation(); onCorrelate(log.correlation_id || log.id); }}
                      className="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Korele"
                    >
                      <GitCompare className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
        <span className="text-xs text-slate-500">Toplam: {total} kayıt</span>
        {hasNext && (
          <button
            onClick={onLoadMore}
            disabled={loading}
            className="inline-flex items-center px-4 py-2 text-sm font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/30 hover:bg-indigo-100 dark:hover:bg-indigo-900/30 rounded-xl transition-colors disabled:opacity-60"
          >
            {loading ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : null}
            Daha fazla yükle
          </button>
        )}
      </div>
    </div>
  );
};
