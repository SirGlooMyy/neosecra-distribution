import React from 'react';
import { MessageSquare, UserCheck, Ticket, Hotel, MessageCircle, CalendarCheck, Globe, UserCircle, Building2, Radio } from 'lucide-react';
import { AuthMethod } from '../../types/portal';

interface AuthMethodSelectorProps {
  methods: AuthMethod[];
  activeMethod: AuthMethod;
  onChange: (method: AuthMethod) => void;
}

export const AuthMethodSelector: React.FC<AuthMethodSelectorProps> = ({
  methods,
  activeMethod,
  onChange,
}) => {
  const methodDetails = {
    sms: {
      label: 'SMS ile Giriş',
      description: 'Sadece Telefon No',
      icon: <MessageSquare className="h-5 w-5" />,
    },
    tc_sms: {
      label: 'TC Kimlik + SMS',
      description: 'TC No & Telefon',
      icon: <UserCheck className="h-5 w-5" />,
    },
    voucher: {
      label: 'Voucher Kodu',
      description: 'İnternet Bilet Kodu',
      icon: <Ticket className="h-5 w-5" />,
    },
    pms: {
      label: 'Otel Odası',
      description: 'Oda No & Soyad',
      icon: <Hotel className="h-5 w-5" />,
    },
    whatsapp: {
      label: 'WhatsApp ile Giriş',
      description: 'WhatsApp Kodu',
      icon: <MessageCircle className="h-5 w-5" />,
    },
    meeting: {
      label: 'Toplantı Kodu',
      description: 'Etkinlik Kodu',
      icon: <CalendarCheck className="h-5 w-5" />,
    },
    foreigner: {
      label: 'Pasaport Giriş',
      description: 'Yabancı Misafir',
      icon: <Globe className="h-5 w-5" />,
    },
    local: {
      label: 'Kullanıcı Giriş',
      description: 'Hesap & Şifre',
      icon: <UserCircle className="h-5 w-5" />,
    },
    ldap: {
      label: 'Kurumsal Giriş',
      description: 'AD / LDAP Hesabı',
      icon: <Building2 className="h-5 w-5" />,
    },
    radius: {
      label: 'RADIUS Giriş',
      description: 'Firewall kullanıcı hesabı',
      icon: <Radio className="h-5 w-5" />,
    },
  };

  const colCountClass = methods.length >= 6
    ? 'grid-cols-3 sm:grid-cols-4'
    : methods.length === 5
    ? 'grid-cols-2 sm:grid-cols-5'
    : methods.length === 4
    ? 'grid-cols-2 sm:grid-cols-4'
    : methods.length === 3
    ? 'grid-cols-3'
    : 'grid-cols-2';

  return (
    <div className={`grid ${colCountClass} gap-2 w-full`}>
      {methods.map((method) => {
        const details = methodDetails[method];
        if (!details) return null;

        const isActive = activeMethod === method;

        return (
          <button
            key={method}
            onClick={() => onChange(method)}
            type="button"
            className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all duration-300 ${
              isActive
                ? 'border-indigo-500 bg-indigo-50/50 text-indigo-700 dark:bg-indigo-950/20 dark:text-indigo-300 ring-2 ring-indigo-500/20'
                : 'border-slate-200 bg-white/50 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900/50 dark:text-slate-400 dark:hover:bg-slate-800/50'
            }`}
          >
            <div className={`p-2 rounded-xl transition-all duration-300 ${
              isActive ? 'bg-indigo-500 text-white' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
            }`}>
              {details.icon}
            </div>
            <span className="mt-2 text-xs font-bold whitespace-nowrap">{details.label}</span>
            <span className="mt-0.5 text-[10px] text-slate-400 dark:text-slate-500 hidden sm:inline">{details.description}</span>
          </button>
        );
      })}
    </div>
  );
};
