import React from 'react';
import { CheckCircle2, Loader2, Wifi, AlertTriangle, ShieldCheck, Clock3 } from 'lucide-react';
import { ConnectionStatus } from '../../types/portal';
import { Button } from '../ui/Button';
import { useLocale } from '../../lib/i18n';

interface ConnectionStatusProps {
  status: ConnectionStatus;
  errorMsg?: string;
  onReset: () => void;
  demoMode?: boolean;
}

export const ConnectionStatusView: React.FC<ConnectionStatusProps> = ({
  status,
  errorMsg,
  onReset,
  demoMode = false,
}) => {
  const { t } = useLocale();
  if (status === 'idle') return null;

  return (
    <div className="flex flex-col items-center justify-center py-6 text-center space-y-6 animate-fade-in">
      {status === 'verifying' && (
        <>
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-indigo-500/10 blur-xl animate-pulse" />
            <Loader2 className="h-16 w-16 text-indigo-600 dark:text-indigo-400 animate-spin relative" />
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
              {t('status_verifying')}
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs">
              {t('verifying_description')}
            </p>
          </div>
        </>
      )}

      {status === 'sms_sent' && (
        <>
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-sky-500/10 blur-xl animate-pulse" />
            <ShieldCheck className="h-16 w-16 text-sky-500 relative" />
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
              {t('status_sms_sent')}
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs">
              {t('sms_sent_description')}
            </p>
          </div>
        </>
      )}

      {status === 'success' && (
        <>
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-emerald-500/20 blur-2xl animate-pulse" />
            <div className="h-20 w-20 rounded-full bg-emerald-500/10 dark:bg-emerald-500/20 flex items-center justify-center animate-bounce">
              <CheckCircle2 className="h-12 w-12 text-emerald-600 dark:text-emerald-400" />
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {t('status_success')}
            </h3>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-300 dark:border-emerald-900/50">
              <Wifi className="h-3.5 w-3.5" />
              {t('internet_active')}
            </div>
            {demoMode && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/30 dark:text-amber-300 dark:border-amber-900/50">
                Demo
              </div>
            )}
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs pt-2 leading-relaxed">
              {t('success_description')}
            </p>
          </div>
          <div className="w-full pt-4">
            <Button variant="secondary" onClick={onReset} fullWidth>
              {t('new_connection')}
            </Button>
          </div>
        </>
      )}

      {status === 'pending' && (
        <>
          <Clock3 className="h-16 w-16 text-amber-500" />
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Yönetici onayı bekleniyor</h3>
            <p className="max-w-xs text-sm leading-relaxed text-slate-500 dark:text-slate-400">Kimliğiniz doğrulandı. Yönetici onayından sonra FortiGate erişiminiz otomatik olarak açılacak.</p>
          </div>
          <div className="w-full pt-4"><Button variant="secondary" onClick={onReset} fullWidth>Yeni bağlantı</Button></div>
        </>
      )}

      {status === 'error' && (
        <>
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-rose-500/10 blur-xl animate-pulse" />
            <div className="h-16 w-16 rounded-full bg-rose-100 dark:bg-rose-950/20 flex items-center justify-center">
              <AlertTriangle className="h-10 w-10 text-rose-600 dark:text-rose-400" />
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">
              {t('status_error')}
            </h3>
            <p className="text-sm text-rose-600 dark:text-rose-400 font-medium bg-rose-50 dark:bg-rose-950/20 px-3 py-2 rounded-xl border border-rose-100 dark:border-rose-900/30 max-w-xs">
              {errorMsg || t('unexpected_error')}
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 pt-1">
              {t('check_info_retry')}
            </p>
          </div>
          <div className="w-full pt-4">
            <Button variant="primary" onClick={onReset} fullWidth>
              {t('try_again')}
            </Button>
          </div>
        </>
      )}
    </div>
  );
};
