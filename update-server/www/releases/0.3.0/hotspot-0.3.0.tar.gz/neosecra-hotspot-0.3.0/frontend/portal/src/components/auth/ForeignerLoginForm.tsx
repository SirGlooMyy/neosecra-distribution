import React, { useState } from 'react';
import { Globe, User, BadgeCheck } from 'lucide-react';

interface ForeignerLoginFormProps {
  onSubmit: (passportNumber: string, fullName: string, country: string) => Promise<void>;
  loading: boolean;
}

const COUNTRY_OPTIONS = [
  { value: '', label: 'Ulke secin...' },
  { value: 'US', label: 'Amerika Birlesik Devletleri' },
  { value: 'DE', label: 'Almanya' },
  { value: 'GB', label: 'Birlesik Krallik' },
  { value: 'FR', label: 'Fransa' },
  { value: 'NL', label: 'Hollanda' },
  { value: 'IT', label: 'Italya' },
  { value: 'ES', label: 'Ispanya' },
  { value: 'CH', label: 'Isvicre' },
  { value: 'AT', label: 'Avusturya' },
  { value: 'BE', label: 'Belcika' },
  { value: 'SE', label: 'Isvec' },
  { value: 'NO', label: 'Norvec' },
  { value: 'DK', label: 'Danimarka' },
  { value: 'FI', label: 'Finlandiya' },
  { value: 'PL', label: 'Polonya' },
  { value: 'CZ', label: 'Çek Cumhuriyeti' },
  { value: 'RU', label: 'Rusya' },
  { value: 'UA', label: 'Ukrayna' },
  { value: 'GR', label: 'Yunanistan' },
  { value: 'TR', label: 'Turkiye' },
  { value: 'CN', label: 'Cin' },
  { value: 'JP', label: 'Japonya' },
  { value: 'KR', label: 'Guney Kore' },
  { value: 'IN', label: 'Hindistan' },
  { value: 'SG', label: 'Singapur' },
  { value: 'AE', label: 'Birlesik Arap Emirlikleri' },
  { value: 'SA', label: 'Suudi Arabistan' },
  { value: 'OTHER', label: 'Diger' },
];

export const ForeignerLoginForm: React.FC<ForeignerLoginFormProps> = ({ onSubmit, loading }) => {
  const [passportNumber, setPassportNumber] = useState('');
  const [fullName, setFullName] = useState('');
  const [country, setCountry] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passportNumber.trim()) {
      setError('Pasaport numarasi zorunludur.');
      return;
    }
    if (passportNumber.trim().length < 5) {
      setError('Pasaport numarasi en az 5 karakter olmalidir.');
      return;
    }
    if (!fullName.trim()) {
      setError('Ad soyad zorunludur.');
      return;
    }
    if (!country) {
      setError('Ulke secimi zorunludur.');
      return;
    }
    setError(null);
    try {
      await onSubmit(passportNumber.trim(), fullName.trim(), country);
    } catch (err: any) {
      setError(err.message || 'Pasaport bilgileri dogrulanamadi.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs font-semibold">
          {error}
        </div>
      )}

      <div className="space-y-3">
        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 block">Pasaport Numarasi</label>
          <div className="relative">
            <BadgeCheck className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
            <input
              type="text"
              required
              disabled={loading}
              value={passportNumber}
              onChange={(e) => setPassportNumber(e.target.value.toUpperCase())}
              placeholder="Örn. U1234567"
              maxLength={20}
              className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 block">Ad Soyad</label>
          <div className="relative">
            <User className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
            <input
              type="text"
              required
              disabled={loading}
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Örn. John DOE"
              maxLength={200}
              className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 block">Uyruk</label>
          <div className="relative">
            <Globe className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
            <select
              required
              disabled={loading}
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 appearance-none bg-white dark:bg-slate-900"
            >
              {COUNTRY_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-lg shadow-indigo-600/10 transition-colors disabled:opacity-50 flex items-center justify-center"
      >
        {loading ? 'Dogrulaniyor...' : 'Pasaport ile Giris Yap'}
      </button>
    </form>
  );
};
