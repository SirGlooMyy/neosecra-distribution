import React, { useEffect, useState } from 'react';
import { ThemeProvider } from '../theme/ThemeProvider';
import { PortalShell } from '../components/layout/PortalShell';
import { PortalLoginPage } from '../pages/PortalLoginPage';
import { fetchPortalConfig, setPortalDemoMode } from '../utils/api';
import { PortalConfig } from '../types/portal';
import { Wifi, AlertCircle } from 'lucide-react';
import { I18nProvider } from '../lib/i18n/context';

export function App() {
  const [config, setConfig] = useState<PortalConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [locationId, setLocationId] = useState<string>('');

  useEffect(() => {
    async function loadConfig() {
      try {
        // Captive redirects carry device_id; it is the trust anchor for the
        // canonical public portal flow. Keep location_id only for legacy/demo
        // links that do not yet include a device identifier.
        const params = new URLSearchParams(window.location.search);
        const locId = params.get('location_id') || params.get('location') || undefined;
        const deviceId = params.get('device_id') || params.get('device') || undefined;
        const langParam = params.get('lang');
        
        const fetchedConfig = await fetchPortalConfig(locId, deviceId);
        setConfig(fetchedConfig);
        setPortalDemoMode(Boolean(fetchedConfig.isDemoMode));
        
        // Use the returned locationId from the backend, or fallback to the query parameter
        setLocationId(fetchedConfig.locationId || locId || '');
      } catch (err: any) {
        setPortalDemoMode(false);
        setError(err.message || 'Portal ayarları yüklenemedi. Sunucu bağlantısını kontrol edin.');
      } finally {
        setLoading(false);
      }
    }

    loadConfig();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200">
        <div className="flex flex-col items-center gap-4">
          <div className="bg-indigo-600 p-4 rounded-2xl shadow-xl shadow-indigo-500/20 text-white animate-bounce">
            <Wifi className="h-8 w-8" />
          </div>
          <p className="text-sm font-semibold tracking-wide animate-pulse">Ağ ayarları yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (error || !config) {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200">
        <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 rounded-3xl shadow-xl flex flex-col items-center text-center space-y-4">
          <div className="bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 p-3 rounded-full border border-red-100 dark:border-red-900/30">
            <AlertCircle className="h-8 w-8" />
          </div>
          <h2 className="text-xl font-bold">Bağlantı Hatası</h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
            {error || 'Portal yapılandırması alınamadı.'}
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 rounded-2xl transition-colors duration-200 shadow-lg shadow-indigo-500/25"
          >
            Yeniden Dene
          </button>
        </div>
      </div>
    );
  }

  return (
    <ThemeProvider>
      <I18nProvider initialLang={config.defaultLanguage as any || 'tr'}>
        <PortalShell config={config}>
          <PortalLoginPage config={config} locationId={locationId} />
        </PortalShell>
      </I18nProvider>
    </ThemeProvider>
  );
}
