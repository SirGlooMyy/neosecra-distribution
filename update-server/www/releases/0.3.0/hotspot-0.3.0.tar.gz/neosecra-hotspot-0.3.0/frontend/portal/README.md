# Captive Portal Frontend

Portal template engine için başlangıç iskeleti.

## İlk Gün Desteklenecek Özellikler
- Logo
- Renk
- Arka plan
- Karşılama metni
- KVKK / kullanım şartları
- TR/EN dil
- SMS/TC/Voucher blokları
- Ön izleme
- Lokasyon bazlı tema
- Bayi white-label tema
