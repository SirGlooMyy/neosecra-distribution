import React, { useState } from 'react';
import { UserCircle, Lock } from 'lucide-react';

interface LocalLoginFormProps {
  onSubmit: (username: string, password: string) => Promise<void>;
  loading: boolean;
}

export const LocalLoginForm: React.FC<LocalLoginFormProps> = ({ onSubmit, loading }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      setError('Kullanici adi zorunludur.');
      return;
    }
    if (!password) {
      setError('Sifre zorunludur.');
      return;
    }
    setError(null);
    try {
      await onSubmit(username.trim(), password);
    } catch (err: any) {
      setError(err.message || 'Kullanici adi veya sifre hatali.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs font-semibold">
          {error}
        </div>
      )}

      <div className="space-y-3">
        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 block">Kullanici Adi</label>
          <div className="relative">
            <UserCircle className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
            <input
              type="text"
              required
              disabled={loading}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Kullanici adinizi girin"
              maxLength={100}
              className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 block">Sifre</label>
          <div className="relative">
            <Lock className="absolute left-3.5 top-3 text-slate-400 w-4 h-4" />
            <input
              type="password"
              required
              disabled={loading}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Sifrenizi girin"
              className="w-full pl-10 pr-4 py-2.5 border border-slate-200 dark:border-slate-800 dark:bg-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
            />
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-lg shadow-indigo-600/10 transition-colors disabled:opacity-50 flex items-center justify-center"
      >
        {loading ? 'Dogrulaniyor...' : 'Kullanici Hesabi ile Giris Yap'}
      </button>
    </form>
  );
};
