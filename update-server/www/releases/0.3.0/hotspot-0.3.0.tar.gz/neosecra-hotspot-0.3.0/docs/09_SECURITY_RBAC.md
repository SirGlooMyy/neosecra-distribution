# Güvenlik ve RBAC

## Roller
- Super Admin
- Partner Admin
- Customer Admin
- Location Manager
- Support / Operations

## Zorunlu Kontroller
- RBAC
- Tenant isolation
- Audit log
- 2FA
- API token encryption
- Rate limit
- JWT hardening
- Redis token blacklist
- Secret rotation hazırlığı

## IDOR Koruması
Her kaynak şu scope'lardan biriyle doğrulanmalı:
- tenant_id
- partner_id
- customer_id
- location_id

## Audit Gerektiren İşlemler
- Cihaz ekleme/silme
- API credential güncelleme
- RADIUS secret değişimi
- Portal template yayınlama
- Voucher batch üretimi
- Log arşiv exportu
- Lisans limiti değişimi
- Site Bridge registration
