# Captive Portal Akışı

## MVP Akışı
```text
Guest Wi-Fi / VLAN
  -> Firewall captive redirect
  -> External Hotspot Portal URL
  -> Tenant/location/device context çözümü
  -> Portal template/theme yükleme
  -> SMS + TC + Voucher auth
  -> Guest session oluşturma
  -> RADIUS/API ile erişim izni
  -> RADIUS accounting + Syslog takip
  -> 5651 correlation
```

## Portal Context
Portal başlamadan şu contextler çözülmeli:
- tenant_id
- partner_id
- customer_id
- location_id
- device_id
- ssid/vlan bilgisi
- portal_template_id
- auth_policy_id
- license durumu

## Portal Template Engine
İlk günden desteklenecek:
- Logo
- Renkler
- Arka plan
- Karşılama metni
- KVKK / kullanım şartları
- Dil TR/EN
- SMS/TC/Voucher bloklarını aç/kapat
- Ön izleme
- Lokasyon bazlı tema
- Bayi white-label tema
