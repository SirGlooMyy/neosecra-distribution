# Güvenlik Haritası — Kural → Kod Konumu

`CLAUDE.md` Mutlak Kuralları'nın koda tam olarak nerede uygulandığı. "Tenant isolation
nerede? hash update yasağı nerede?" gibi sorulara hızlı cevap. **Bu dosyayı değişiklik
önce kontrol et** — kuralların uygulandığı yerleri bozmamak için.

## Mutlak Kurallar

### #1 Tenant isolation asla bypass edilmeyecek
- **Scope primitive:** `app/core/tenant.py` — `ScopeContext`, `scope_for(user)`, `TenantLevel`.
- **Her repository sorgusu scope alır:** `_scoped_query(db, scope)` pattern'i.
  Örnekler: `logs_5651/service.py:201`, `licensing/service.py`, `sessions/service.py` (`_scoped_query_async`).
- **Fail-closed:** scoped rolün ataması yoksa `allowed=False` → boş sonuç (asla tüm veri).
- **Captive flow'da:** synthetic CUSTOMER scope (`portal/flow.py:start_session`) — adapter
  device↔customer'yı TEKRAR doğrular, GLOBAL bypass YOK.

### #2 Tüm API sorguları scope ile filtrelenecek
- Tüm router'lar `scope_for(user)` → service → repository zinciri. Filterless listing YASAK.
- `reports/service.py` ve `logs_5651/service.py` sorguları `sessions.service._scoped_query_async` üzerinden.
- **IDOR guard'ları:** `licensing/service.py:_authorize_customer`, `logs_5651/router.py:_authorize_build`.

### #3 Firewall tokenları plaintext saklanmayacak
- Fernet şifreleme: `app/core/security.py` (+ `CRYPTO_KEY` config).
- `DeviceCredential` tokenı şifreli; response şemasında ASLA token alanı yok (`devices/schemas.py` CredentialOut).
- Voucher code: unsalted sha256 lookup (`vouchers/models.py` code_hash); plaintext SADECE `BatchCreateResult`'ta bir kez.
- OTP code: salted sha256 (`sms/models.py`).

### #4 5651 log/arşiv değiştirilemez — append-only; hash update EDİLMEZ
- Tablo: `logs_5651/models.py:ArchiveRecord` — **SoftDeleteMixin YOK**, UPDATE/DELETE yapılmaz.
- Seal: `logs_5651/service.py:build_session_archive` — her seferinde YENİ chain satır (chain_seq+1).
- Hash chain: `prev_hash→curr_hash = sha256(prev|content_hash|period_key|record_type)`.
- Deterministic payload: `_serialize_sessions` (sorted, sort_keys, gzip mtime=0) → aynı input aynı hash.
- Tamper kanıtı: `verify_chain` — DB satır değişikliğini matematiksel tespit (object store'a güvenmeden).
- **Asla yapma:** `UPDATE archive_records`, hash sütununu değiştirme, ArchiveRecord'a soft-delete ekleme.

### #5 Syslog/RADIUS/API eventleri korelasyonsuz silinmeyecek
- Silme YOK: `sessions/service.py:expire_due` → status=active→expired işaretler (siler değildir).
- Korelasyon: `sessions/correlation.py:correlate` → `complete=all(sources_matched)`.
- **Purge gate:** `complete=False` iken retention/purge yasak (gate olarak kullanılır).

### #6 Captive portal context olmadan başlamayacak
- `portal/flow.py:resolve_context(device_id)` — device→location→customer→template eksiksiz; herhangi biri yok/pasif → 404. Akış buradan önce hiçbir şey yapmaz.

### #7 Adapter pattern; FortiGate özel kodu core service'te DEĞİL
- `firewall_adapters/base.py:FirewallAdapter` ABC + somut `fortigate.py`/`paloalto.py`.
- `service.py` dispatch eder, vendor mantığı yazmaz. `get_adapter_class(vendor)` registry.

### #8/#9/#10  Site Bridge ↔ Platform Worker karışmaz; on-prem connector bağımsız; SaaS bridge'siz çalışır
- `site_bridge/` ayrı modül (şu an stub). Worker `workers/` bağımsız Celery process.

### #11 Migration geri dönüş + veri güvenliği
- `alembic/env.py` async + tüm modelleri import eder. Migration'lar review'la.
- Soft delete (`shared/types.py:SoftDeleteMixin`) — tenant/customer/location ağacı hard-delete YOK.

### #12 Security-first: RBAC, audit, 2FA, rate limit, token blacklist, secrets encryption
- RBAC: `app/core/rbac.py` + `auth/deps.py:require_permission`.
- Audit: `audit/service.py:log_audit` — kritik işlemlerde (session, archive, license, login).
- 2FA: `auth/` (TWO_FA_ENABLED flag), token blacklist `auth/` logout'ta.
- Rate limit: `app/core/security.py:rate_limit`; portal public `portal/public_router.py:_rl` (IP bazlı 60/60s).
- Secrets encryption: Fernet (`core/security.py`), `CRYPTO_KEY` config.

## Yasaklar → koruyucu konum

| Yasak | Uygulandığı yer |
|-------|----------------|
| Vendor mantığı core service'te | `firewall_adapters/` izolasyonu |
| Tenant filtresiz listeleme | `_scoped_query` her repo'da |
| API token response'da | `devices/schemas.py` (CredentialOut'da yok) |
| 5651 hash update | ArchiveRecord append-only + verify_chain |
| Background job sonucu auditsiz değişiklik | worker task'ları `log_audit` çağırır; expire/archive audit log yazar |
| `delete` ile kritik log | soft delete / retention policy (hard delete YOK) |

## RBAC matrisi (özet — ayrıntı `app/core/rbac.py`)

| Rol | Kapsam | Örnek yetkiler |
|-----|--------|----------------|
| super_admin | GLOBAL | `*` (her şey) |
| partner_admin | PARTNER | customer/location/device/portal/voucher/session/identity/archive/report/license **+ license.write** |
| customer_admin | CUSTOMER | kendi customer'ı; **license.read var, license.write YOK** (self-serve kota engeli) |
| location_manager | LOCATION | read: device/session/report/voucher/portal/identity/archive |
| support | CUSTOMER (read) | session/report/device/log/identity/archive |

> `license.write` niçin customer_admin'de yok? Müşteri kendi kotasını sınırsız yapamasın diye (upstream partner/super belirler).

## Config'te güvenlik ayarları (`app/core/config.py`)

- `CRYPTO_KEY` — boşsa startup'ta ephemeral (SADECE dev). Prod sabit key zorunlu.
- `SECRET_KEY`, `JWT_ALGORITHM`, `ACCESS_TOKEN_EXPIRE_MINUTES`, `REFRESH_TOKEN_EXPIRE_DAYS`.
- `LOGIN_MAX_ATTEMPTS`, `LOGIN_WINDOW_MINUTES`, `TWO_FA_ENABLED`.
- `SMS_*` — OTP TTL/attempts/send rate-limit.
- `ARCHIVE_MINIO_SECRET_KEY` — env'den, loglanmaz.

## Bilinen GAP'ler (dikkat)

- **Migration yok:** `alembic/versions/` boş. Dev `create_all` ile. İlk migration üretilmeli.
- **2FA / token blacklist:** flag/altyapı var, tam akış kontrol edilmeli (`auth/`).
- **radius/syslog/archive:** korelasyon `sources_matched`'de hep False → session hiçbir zaman `complete` değil → purge gate hep kapalı (kasıtlı, veri güvenliği için).
