# Hata Ayıklama Haritası — Semptom → Nereye Bakılır

"X hatası alıyorum, nereden başlayayım?" rehberi. Her satır: olası neden + bakılacak dosya.

## 403 Yetkisiz islem
- **RBAC matrisinde yetki yok:** `app/core/rbac.py` `ROLE_PERMISSIONS`. Rol→yetki var mı?
- **Yanlış scope:** `app/core/tenant.py:scope_for(user)`. Rolün zorunlu ataması (partner_id/customer_id/location_id) var mı? Yoksa `allowed=False`.
- **License yazamaz:** customer_admin'de `license.write` bilerek yok → `license.read` var sadece (self-serve kota engeli). Partner/super kullan.
- **IDOR guard:** service katmanı `_authorize_customer` / `get_*` scope doğrulaması fail-closed.

## 402 Lisans/kota limiti (captive flow)
- `licensing/service.py:enforce_quota` → `quota_status` aktif/günlük/expires kontrol.
- Lisans yoksa = unlimited dev default (izin verir). Sorun varsa `customer_licenses` satırına bak.
- `GET /licenses/{customer_id}/quota` ile canlı durumu gör.
- Tetiklenme yeri: `portal/flow.py:start_session` (authorize öncesi).

## 404 Captive flow (context/send/verify/start)
- `portal/flow.py:resolve_context(device_id)`: device aktif mi? location/customer var+aktif mi?
- PortalTemplate var mı + is_active + is_default? (`portal/models.py`).
- → 6 adımdan hangisi eksikse o 404 verir. Cihaz→lokasyon→müşteri→template zinciri.

## 429 Rate limit
- Public flow: `portal/public_router.py:_rl` (IP bazlı 60/60s).
- SMS: `sms/service.py` per-phone send limit (`SMS_SEND_MAX_PER_WINDOW`).
- Login: `auth/` `LOGIN_MAX_ATTEMPTS`.

## Captive authorize başarısız (session yine oluşur ama authorize_ok=False)
- `portal/flow.py:start_session`: HTTPException catch → authorize_ok=False, session yine kaydedilir (görünürlük için).
- Adapter: `firewall_adapters/service.py:authorize_guest_service` → `get_adapter_for_device`.
- Credential: `firewall_adapters/service.py:_load_credential` (Fernet decrypt; CRYPTO_KEY boşsa dev ephemeral).
- Log: `flow.py` WARNING satırı `portal authorize failed for device=...`.

## 5651 hash mismatch / verify_chain ok=False
- `logs_5651/service.py:verify_chain` → broken_seq + message.
  - "prev_hash kopuklugu" = satır eklenmiş/silinmiş (zincir sırası bozulmuş).
  - "curr_hash uyusmazligi" = bir satırın içeriği sonradan değiştirilmiş.
- ArchiveRecord SATIR değişikliği yapılmamalı (append-only, Kural #4). Migration/manual SQL ile mi dokunuldu?
- Object store değişse bile verify DB satırından gider (content hash stored). Upload'da `archive_service.py`.

## Session hiç "complete" olmuyor (Kural #5 purge gate kapalı)
- Beklenen davranış: `sessions/correlation.py` — radius/syslog/firewall_api kaynakları M6'da henüz False.
- → retention/purge gate bilerek kapalı. radius/syslog feed'leri gelince True olacak.

## Boş liste dönüyor (veri var ama görünmüyor)
- Scope filtresi: `_scoped_query(db, scope)`. `allowed=False` → boş. Rol atamasını kontrol et.
- tenant.py `scope_for` ile scope'u yazdır.

## Worker crash / "different event loop"
- `workers/runtime.py` NullPool engine kullanıyor mu? (asyncpg cross-loop). App engine'i (`core/database.py`) worker'da kullanma.
- Task SYNC + `asyncio.run`. Her task kendi session'ı.
- Beat çalışmıyor: `celery -A app.modules.workers.celery_app beat -l info` (broker REDIS_URL).

## Migration / tablo yok
- `alembic/versions/` BOŞ. Dev: `DEV_CREATE_TABLES=1` → `scripts/dev_create_tables.py` (create_all).
- Yeni model görünmüyor → `alembic/env.py` import listesinde mi? `dev_create_tables.py`'de mi?
- FK sırası: env.py import sırası bağımlılık hiyerarşisine uygun olmalı.

## Pydantic validation error
- Schema alanı eksik/fazla: `schemas.py`. `from_attributes=True` var mı (ORM → schema)?
- Modelde yok schema bekliyor: örn `identity/models.py:phone_masked` @property (IdentityOut bekliyordu).

## Adapter / vendor hatası
- `firewall_adapters/registry.py:get_adapter_class(vendor)` — vendor adı doğru mu?
- Somut adapter: `fortigate.py` / `paloalto.py`. Base ABC: `base.py:FirewallAdapter`.
- Vendor mantığı core'da DEĞİL (Kural #7).

## Hızlı sembol bulma
- Endpoint → router → service → repository zincirini [MODULE-MAP.md](MODULE-MAP.md)'den takip et.
- Güvenlik sorusu → [SECURITY-MAP.md](SECURITY-MAP.md).
- Dosya nerede → `grep -rn "def <sembol>" backend/app` veya repo içinde arama.

## Çalıştırma (doğrulama)
- Docker: `docker compose up -d` → `/health`, loglar `docker compose logs -f api worker`.
- Elle (deps yoksa): doğrulama AST-parse ile (`python -c "import ast, pathlib; ..."`), runtime import Docker içinde.
