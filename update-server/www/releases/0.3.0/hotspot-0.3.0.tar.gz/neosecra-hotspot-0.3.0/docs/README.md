# Hotspot Platform — Dokümantasyon Haritası

Ticari Hotspot / Captive Portal / 5651 Loglama / RADIUS / Firewall entegrasyon
platformu. Bu klasör, kodu sonra kolay bulmak için bir **harita** setidir:
bug ararken ya da bir özellik eklerken saatlerce dosya gezmemek için buradan başla.

## Hızlı başlangıç

```bash
# Full dev stack (postgres + redis + minio + api + worker + beat)
docker compose up -d
# API:        http://localhost:8000/health
# MinIO UI:   http://localhost:9001  (minioadmin / minioadmin)
# Loglar:     docker compose logs -f api worker

# İlk gerçek migration (versions/ boş):
docker compose run --rm api alembic revision --autogenerate -m "initial"
```

> **Not:** `alembic/versions/` henüz boş. Dev stack `DEV_CREATE_TABLES=1` ile
> `Base.metadata.create_all` yapar (idempotent). Prod'da bu kapatılır ve gerçek
> migration'lar kullanılır.

## Bu klasörde ne var

| Dosya | Ne zaman açılır |
|-------|-----------------|
| [ARCHITECTURE.md](ARCHITECTURE.md) | Sistemin genel mantığını / veri akışlarını anlamak |
| [MODULE-MAP.md](MODULE-MAP.md) | "X özelliği hangi dosyada?" — modül bazlı dosya→sorumluluk haritası |
| [SECURITY-MAP.md](SECURITY-MAP.md) | "Tenant isolation / hash update yasağı / quota nerede uygulanır?" — Mutlak Kural → kod konumu |
| [API-MAP.md](API-MAP.md) | Tüm endpoint'ler tek tabloda (method, path, yetki, scope) |
| [DEBUGGING.md](DEBUGGING.md) | Semptom → nereye bakılır (403, 402, IDOR, 5651 hash, worker crash) |

## Repo yapısı

```
backend/
  app/
    core/            config, database, rbac, tenant (scope), security (crypto/rate-limit)
    shared/types.py  UUIDPK, TimestampMixin, SoftDeleteMixin, fk()
    api/v1/router.py TEK router kayıt noktası (tüm modüller burada prefix'lenir)
    main.py          FastAPI app + /health
    modules/
      tenants partners customers locations   # tenant/partner/customer/location hiyerarşisi
      devices firewall_adapters              # cihaz + vendor-agnostic adapter katmanı
      portal                                  # captive portal template + PUBLIC flow
      sms identity vouchers                   # guest auth yöntemleri
      sessions logs_5651                      # oturum + 5651 append-only arşiv
      reports licensing audit                 # rapor + kota + audit log
      workers                                 # Celery tasks + beat schedule
      auth                                    # JWT login/refresh/logout, RBAC deps
      radius syslog archive site_bridge       # stub modüller (henüz tablo yok)
  alembic/        env.py (model import listesi), versions/ (BOŞ)
  scripts/dev_create_tables.py   dev bootstrap (create_all)
  Dockerfile docker-entrypoint.sh
docker-compose.yml   repo root — full dev stack
docs/                bu klasör
```

## Stack

FastAPI · SQLAlchemy 2.x (async) · Alembic · PostgreSQL · Redis · Celery ·
MinIO/S3 (boto3) · bcrypt/JWT/Fernet · reportlab (opsiyonel, lazy).

## Geliştirme akışı (bu projenin değişmez kuralları için)

Tüm iş `CLAUDE.md` Mutlak Kuralları'na tabidir. Bunların koda yansıması için
[SECURITY-MAP.md](SECURITY-MAP.md)'e bak. Yeni modül eklersen [MODULE-MAP.md](MODULE-MAP.md)'deki
`models/schemas/service/router/repository` ayrımını koru ve `api/v1/router.py`'ye kayıt ekle.
