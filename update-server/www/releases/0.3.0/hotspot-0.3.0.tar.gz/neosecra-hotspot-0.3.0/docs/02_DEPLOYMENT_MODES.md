# Deployment Modları

## 1. On-prem Mode
Müşteri local network'ünde çalışır. Connector gerekmez.

```text
Hotspot Platform local network içinde
  -> FortiGate/Palo API
  -> Syslog
  -> RADIUS
```

## 2. SaaS Mode
Merkezi panel cloud'da çalışır. Müşteri firewall API dışarı açılmayacaksa Site Bridge kullanılır.

```text
Cloud SaaS Backend
  -> Secure channel
Site Bridge customer local network
  -> Firewall API / Syslog / RADIUS
```

## 3. Offline Appliance Mode
On-prem modelin paketli halidir. Tamamen lokal çalışabilir.

```text
Appliance VM/Box
  -> Backend + Portal + Radius + Syslog + DB + Archive
```

## İlk Paketleme
- Docker Compose first
- Kubernetes ready folder structure
- Offline appliance için local MinIO + PostgreSQL + Redis
