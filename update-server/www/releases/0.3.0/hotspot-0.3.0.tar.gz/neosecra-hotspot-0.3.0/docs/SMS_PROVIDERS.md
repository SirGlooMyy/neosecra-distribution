# SMS sağlayıcı sözleşmeleri

Paneldeki SMS profili, sağlayıcının gerçek HTTP sözleşmesini kullanır. API
şifreleri ve tokenlar sms_configs tablosunda Fernet ile şifreli tutulur; config
GET yanıtları yalnızca ******** döndürür.

## Hazır profiller

| Sağlayıcı | İstek | Panel alanları |
|---|---|---|
| NetGSM | POST https://api.netgsm.com.tr/sms/rest/v2/send, Basic Auth, JSON messages[] | kullanıcı kodu, API şifresi, başlık, encoding, IYS filtresi, uygulama adı |
| İleti Merkezi | POST https://api.iletimerkezi.com/v1/send-sms, nested JSON authentication.key/hash | API key, API hash, başlık |
| VatanSMS | POST https://api.vatansms.net/api/v1/1toN, JSON api_id/api_key/phones[] | API ID, API key, başlık, mesaj tipi, içerik tipi |
| Twilio | POST .../Accounts/{SID}/Messages.json, Basic Auth, form-urlencoded | Account SID, Auth Token, From veya Messaging Service SID, callback |

Telefon numarası portalda Türkiye E.164 (+905...) olarak normalize edilir;
sağlayıcı adapteri kendi sözleşmesinin istediği biçime çevirir.

## Özel HTTP profili

JSON veya form-urlencoded seçilebilir. recipient_field, message_field ve
sender_field noktalı yolları destekler; örneğin request.message.text veya
messages.0.to. JSON şablonunda {phone}, {message} ve {sender} yer tutucuları
kullanılabilir. Başarı alanı ve job ID yolu tanımlanırsa test yanıtı bunları
gösterir.

Gizli değerleri özel header veya body şablonuna yazmak yerine üstteki şifreli
alanları (Bearer token, Basic kullanıcı/şifre, API key/secret) kullanın.
