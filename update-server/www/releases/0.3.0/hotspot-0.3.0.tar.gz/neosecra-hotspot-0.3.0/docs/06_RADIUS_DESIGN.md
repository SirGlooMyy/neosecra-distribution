# RADIUS Tasarımı

## Amaç
Captive portal authentication ve accounting eventlerini platforma bağlamak.

## Event Tipleri
- Access-Request
- Access-Accept
- Access-Reject
- Accounting-Start
- Accounting-Stop
- Interim-Update

## MVP Yaklaşımı
- FreeRADIUS kullanılacak.
- Backend RADIUS kararlarını REST/API veya DB entegrasyonu ile sağlayacak.
- Accounting eventleri `radius_events` tablosuna yazılacak.
- Session correlation worker bu eventleri guest session ile eşleştirecek.

## Güvenlik
- RADIUS shared secret encrypted saklanmalı.
- RADIUS client tenant/location/device scope'a bağlı olmalı.
- Unknown client eventleri ayrı auditlenmeli.
