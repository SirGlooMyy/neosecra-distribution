# Hotspot Platform — Goal Haritası

## North Star
Ticari, multi-tenant, 5651 uyumlu Hotspot / Captive Portal platformu.
Kullanıcı WiFi'ye bağlanır → captive portal → SMS/TC/Voucher doğrulama → RADIUS authorize → internet + 5651 uyumlu korelasyonlu log/arşiv/rapor. Bayi + white-label + on-prem/SaaS desteği.

## Kilit Kararlar (bağlandı)
| Karar | Seçim |
|---|---|
| Tenant derinliği | Tam hiyerarşi: tenant → partner → customer → location → device |
| İlk deployment | On-prem / local Docker. Platform Worker zorunlu, Site Bridge opsiyonel (yok) |
| MVP derinliği | Sağlam temel + tek uçtan uca akış tam; kalan maddeler roadmap/future-phase notu |
| Vendor | Sadece FortiGate (gerçek adapter). Palo Alto iskelet |
| Auth | Admin: JWT+RBAC+2FA. Misafir: SMS+TC+Voucher |

## Üç Değer Sütunu
1. **Kimlik & Erişim** — captive portal redirect, SMS/TC/Voucher, RADIUS auth+accounting, guest authorize
2. **5651 Uyumluluk** — IP/MAC/NAT/zaman korelasyonu, append-only + hash, MinIO arşiv, CSV/PDF rapor
3. **İşletme & Yönetim** — tenant hiyerarşi, bayi, lisans/kota, RBAC + audit + 2FA

## MVP Kritik Yol (bağımlılık zinciri — sıra bozulmaz)
Foundation Core → Tenant Hiyerarşi → Auth/RBAC → Device (FortiGate) → Captive Portal → Identity → RADIUS → Guest Session → 5651 Archive → Report

## Milestone Haritas
| M | Hedef | Çıktı |
|---|---|---|
| **M1** | Core Foundation | config/db genişlet, security(JWT/bcrypt/blacklist), crypto(Fernet), audit(append-only), rbac, tenant scope, shared mixins, alembic setup |
| **M2** | Tenant + Users + Auth | tenants/partners/customers/locations CRUD (scoped), users, login/JWT/2FA/rate-limit/blacklist, seed |
| **M3** | Devices + FortiGate Adapter | devices/credentials(encrypted), syslog/radius sources, FortiGate REAL adapter, portal_templates |
| **M4** | Portal + Identity | portal context resolver, captive flow, SMS OTP, TC validation, voucher |
| **M5** | Sessions + 5651 | guest_sessions, correlation engine, append-only archive+hash, MinIO, export/report |
| **M6** | Licensing + Workers + Infra + Frontend | licensing/kota, celery workers, docker-compose full, React admin |

## Mutlak Mimari Taşlar (sonradan değişmesi pahalı)
- Tenant modeli (4 seviye FK zinciri)
- RBAC + scope filtreleme (Mutlak Kural #2)
- Encryption layer (Mutlak Kural #3)
- Audit + append-only (Mutlak Kural #4, #9)
- Adapter pattern (Mutlak Kural #7)
- Module boundary (cross-module = service layer)

## Test-Trip %90 Tanımı
Çalışır: login → tenant/customer/location CRUD → device ekle (FortiGate test_connection) → portal template → captive flow (SMS/TC/Voucher) → guest authorize → session → 5651 archive+hash → PDF/CSV report.
Gelecek faz notları: sosyal login, OpenSearch ve offline appliance packaging/hardening.
