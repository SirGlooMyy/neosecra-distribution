# Ürün Vizyonu

Ürün; hotspot, captive portal, 5651 loglama, RADIUS, SMS/TC doğrulama, voucher, firewall entegrasyonu, bayi/white-label yönetimi ve raporlama sağlayan ticari bir access platformudur.

## Konumlandırma
Basit hotspot yazılımı değil; güvenli misafir erişimi, kimlik doğrulama, oturum korelasyonu, 5651 arşivleme ve bayi yönetimi sağlayan enterprise access platformu.

## Rakiplerden Farklılaşma
- API-first mimari
- Hybrid/on-prem/SaaS/offline appliance hazır tasarım
- Multi-tenant + bayi + white-label doğuştan
- FortiGate/Palo Alto adapter-first entegrasyon
- RADIUS + Syslog + API üçlü omurga
- 5651 hash/arşiv ve raporlama odaklı
- Portal template engine ilk günden
- Platform worker/agent mimarisi
