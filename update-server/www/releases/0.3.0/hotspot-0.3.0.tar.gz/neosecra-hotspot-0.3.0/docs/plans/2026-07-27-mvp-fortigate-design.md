# Hotspot MVP Design — SubGate / FortiLogger / SignLogger

**Tarih:** 2026-07-27
**Run:** RUN-20260727-001
**Branch:** feature/hotspot-mvp-readiness
**Risk tier:** T3 (5651/RADIUS/firewall/sessions path'leri)
**Status:** DRAFT — kullanıcı onayı bekleniyor (brainstorming HARD-GATE)

---

## 1. Ürün Ailesi ve MVP Sınırları

Hedef: FortiGate odaklı, tek tenant, demo-kanıtlı MVP. Üç alt ürün birbiriyle
çalışır ama ayrı modüler sınırlara sahip.

| Ürün | MVP Rolü | Out-of-Scope (sonra) |
|---|---|---|
| **SubGate** | FortiGate external captive portal + SMS/Voucher auth + IP allowlist yetkilendirme | Diğer 11 vendor, RADIUS CoA, RADSEC, WPA3, LDAP, sosyal login |
| **FortiLogger** | FortiGate syslog receiver (RFC 5424) + traffic/event/utm parse + PostgreSQL | ClickHouse/OpenSearch (adapter hazır ama MVP'de aktif değil), FortiAnalyzer |
| **SignLogger** | Sequential hash chain + günlük local-cert CAdES imza + MinIO WORM | KamuSM REST, E-Tuğra REST, e-Mühür, PAdES/ASiC kapsül, aylık rapor |

**Hukuki not:** 5651 yasal yükümlülük olarak imza **zorunlu değildir**. SignLogger'ın
MVP'de local-cert ile hash chain + CAdES imza üretmesi, adli süreçte "log
değiştirilmedi" ispatının **teknik temelini** atar. Üretimde e-Mühür (Kamu SM)
MVP sonrası eklenir. Bu sınır `five651_archive_change` gate'inde NEEDS_HUMAN
olarak işaretlendi.

---

## 2. Mimari (MVP runtime)

```
                 ┌─────────────────────────────────────────────────┐
                 │            FortiGate (lab/sim)                   │
                 │  external captive portal URL = SubGate endpoint  │
                 │  syslog target = FortiLogger TCP 514             │
                 └────────────────┬────────────────────────────────┘
                                  │
                ┌─────────────────┼──────────────────┐
                │ redirect (HTTP) │ syslog (RFC 5424)│
                ▼                 ▼                  
        ┌──────────────┐  ┌──────────────────┐
        │   SubGate    │  │   FortiLogger    │
        │ (FastAPI)    │  │ (async collector)│
        │              │  │                  │
        │ /portal/conf │  │ TCP 514 listener │
        │ /sms/verify  │  │ RFC 5424 parser  │
        │ /voucher     │  │ traffic/event/utm│
        │              │  │ tenant scope     │
        └──────┬───────┘  └────────┬─────────┘
               │                   │
               │ authorize_guest   │ insert parsed log
               │ (REST API)        │
               ▼                   ▼
        ┌──────────────────────────────────────┐
        │           PostgreSQL (hotspot)        │
        │  sessions, firewall_logs, syslog_raw  │
        └─────────────────┬────────────────────┘
                          │
                          │ nightly 02:00 trigger (Celery beat)
                          ▼
                  ┌──────────────────┐
                  │   SignLogger     │
                  │                  │
                  │ hash chain H(n)  │
                  │ CAdES local cert │
                  │ MinIO WORM put   │
                  └────────┬─────────┘
                           │
                           ▼
                  ┌──────────────────┐
                  │  MinIO bucket    │
                  │ hotspot-5651     │
                  │ (governance 730d)│
                  └──────────────────┘
```

---

## 3. Sprint Planı (6 sprint × ~2 gün = ~12 iş günü)

### Sprint 06 — Test Baseline + Compose Ayağa Kalkma (2 gün)
**Amaç:** project.yaml'daki "DOĞRULANMAMIŞ" notunu kaldır, sağlam zemin.

- Kök `pytest.ini` (5651 smoke 4 dosya) çalıştır, passed/failed/skipped say
- `backend/tests/` tam suite çalıştır, baseline çıkar (node id'leri ile)
- `docker compose -p hotspot-run-20260727-001 up -d` default profile
- `GET /health` 200, DB+Redis+ClickHouse OK kanıtı
- `MinIO bucket hotspot-5651` governance 730d WORM aktif kanıtı
- project.yaml `test_commands.notes` güncelle

**Acceptance:**
- [ ] baseline sayıları project.yaml'da
- [ ] compose healthy (docker ps çıktısı)
- [ ] MinIO WORM `mc retention get` çıktısı

**Worker:** kimi-direct (T0 read-only + 1-2 config değişikliği)

### Sprint 07 — FortiLogger MVP (2 gün)
**Amaç:** FortiGate syslog toplama çalışsın, parse edilsin, DB'ye yazılsın.

- `backend/app/modules/syslog/service.py` async TCP 514 receiver
- RFC 5424 parser (PRI, version, timestamp, hostname, structured-data, msg)
- FortiGate `key=value` payload parser (mevcut `parse_syslog_event` güncellenir)
- `firewall_logs` tablosuna insert: log_type (traffic/event/utm), src/dst ip/port, user, byte, duration, action
- Tenant scope filtresi (hostname/device_id → tenant eşlemesi)
- Test: fake syslog akışı (Python socket) → DB'de doğru satırlar

**Acceptance:**
- [ ] RFC 5424 trafik logu parse + DB insert (unit test)
- [ ] traffic/event/utm type ayrımı (unit test)
- [ ] tenant cross-leak testi (test_idor pattern)

**Worker:** cline (T3, localizes scope syslog + sessions)
**Gate:** `captive_portal_flow_change` N/A; security-auditor tenant scope için

### Sprint 07b — Detaylı ve Hızlı Log Arama (2 gün)
**Amaç:** FortiLogger topladığı logları hızlı ve detaylı aranabilir hale getir.
SIEM komplexitesi yok (query dili, dashboard, alert yok); bunun yerine
**çok filtreli + hızlı** odak. PostgreSQL GIN full-text + structured filter.

**Backend (`search` modülü):**
- `GET /api/v1/logs/search` — query param olarak filtreler (Lucene/SQL syntax yok):
  - `vendor`, `log_type` (traffic/utm/event/iap), `severity` (critical/high/medium/low/info)
  - `action` (accept/deny/client-rst/server-rst), `src_ip`, `dst_ip`, `src_port`, `dst_port`
  - `user`, `device_id`, `location_id`, `policyid`, `service`, `proto`
  - `q` (serbest metin — raw syslog içinde ara, tsvector üzerinden)
  - `from`, `to` (ISO 8601), `time_window` (15m/1h/24h/7d preset)
  - `limit` (max 1000, default 100), `offset` (pagination)
- PostgreSQL tarafında:
  - `firewall_logs.search_vector` (tsvector) GENERATED column + **GIN index**
  - `firewall_logs(ts DESC)` B-tree index
  - Composite index `(tenant_id, ts DESC)` — tenant scope filtresi index'den gelsin
  - `EXPLAIN ANALYZE` ile sub-100ms hedef (100K kayıt üzerinde)
- `GET /api/v1/logs/facets` — aktif filtreye göre facet sayımları:
  - Sadece: vendor, log_type, severity, action (4 facet — fazlası UI kirliliği)
  - Her biri top-10 with count
- `GET /api/v1/logs/correlate?session_id=` — session_id ile birleştir:
  - sessions + firewall_logs (traffic) + firewall_logs (captive auth) birleşik JSON
- `GET /api/v1/logs/export?format=csv|jsonl` — aktif sorguyu dışa aktar (max 100K satır)

**Frontend (`LogsSearch.tsx`):**
- Üst bar: serbest metin arama (`q`) + zaman preset (15dk/1sa/24sa/7g/Özel)
- Sol panel: filter form (vendor dropdown, log_type multiselect, severity checkboxes,
  action checkboxes, src_ip/dst_ip/user input). "Filtreleri Uygula" butonu (debounced
  değil, basit — 300ms debounce var ama manual apply da var)
- Orta: tablo (zaman, src→dst, user, action badge, severity badge, log_type) —
  virtualized (react-window), 100K satır akıcı
- Row expand: raw syslog JSON + parsed fields tablosu + "Bu session'ı korele et" linki
- Pagination: "Daha fazla yükle" (offset artı), sayfa numarası yok
- Export button: CSV/JSONL
- Boş durum: "Son 24 saatte eşleşme yok" + filter önerileri
- **Yükseklik vurgu:** kritik satırlar (severity=critical, action=deny) hafif kırmızı bg

**Performans hedefleri:**
- 100K kayıt tabloda: query < 100ms, facet < 200ms (paralel 4 aggregation)
- 1M kayıt: query < 500ms (index hit), facet < 1s
- Export 100K satır: < 5s

**Tenant isolation:** her sorguya otomatik `tenant_id = current.tenant_id` eklenir.
test_idor pattern: tenant A tokeni ile tenant B loglarını göremez.

**Acceptance:**
- [ ] `/logs/search` en az 10 filter destekliyor (vendor/log_type/severity/action/src_ip/dst_ip/user/from/to/q)
- [ ] tsvector GIN index aktif, `EXPLAIN ANALYZE` Seq Scan yok
- [ ] `/logs/facets` 4 facet (vendor/severity/log_type/action) dönüyor
- [ ] `/logs/correlate?session_id=` en az 3 kaynak (session + traffic + auth) birleştiriyor
- [ ] `/logs/export?format=csv` 1000 kayıt < 3s
- [ ] Frontend `LogsSearch` filter form + tablo + row expand render oluyor
- [ ] 100K seed kayıt ile query < 100ms (benchmark test)
- [ ] test_idor: cross-tenant log sızıntısı yok
- [ ] test_search_views + test_search_export yeşil (var olan testler güncellenir)

**Worker:** cline (T3, search + sessions) + opencode (frontend test gen)
**Gate:** security-auditor tenant scope + IDOR yüzeyi

**Out-of-scope (MVP'de YOK):**
- Lucene/KQL query dili (sadece filter params + serbest `q`)
- Real-time stream / SSE / WebSocket (manuel "Yenile" butonu var)
- Saved search / alert / notification
- Custom dashboard / widget builder
- Machine learning / anomaly detection
- Histogram/grafik (sadece tablo yeterli MVP için)
- Facet kombinasyonu (UI'da sadece 4 ayrı facet listesi)

---

### Sprint 08 — SubGate Captive Portal Doğrulama (2 gün)
**Amaç:** Captive portal akışı fake FortiGate ile uçtan uca çalışsın.

- `fortigate_simulator_integration` testini genişlet: redirect → /portal/config → SMS verify → authorize_guest (REST) → session log row
- `parse_syslog_event` ile captive auth event correlation (session_id ↔ firewall log)
- Frontend portal ile gerçek backend akışı (playwright e2e)
- Gerçek FortiGate lab planı yaz (NEEDS_HUMAN — cihazlı doğrulama MVP dışı)

**Acceptance:**
- [ ] Fake FortiGate captive portal akışı yeşil (integration test)
- [ ] Session log row: session_id, user_id, MAC, IP, start_ts, byte, duration
- [ ] Captive event correlation syslog ile (test_sessions_correlation genişletme)

**Worker:** cline (T3, firewall_adapters + sessions + portal)
**Gate:** `captive_portal_flow_change` → backend_tests_pass + tenant_isolation_check

### Sprint 09 — SignLogger Hash Chain + Local Cert (3 gün)
**Amaç:** Append-only hash chain + günlük CAdES imza + WORM put.

- `backend/app/modules/archive/` (şu an boş) → doldur: models, service, repository
- Sequential hash chain: `H(n) = SHA256(log_n || H(n-1))`, genesis H(0) = SHA256("HOTSPOT-GENESIS-RUN-20260727-001")
- `signing_service.py` zaten local-cert imzayı destekliyor — wire up
- Celery beat task: her gece 02:00 önceki günün loglarını paketle, hash'le, imzala, MinIO'ya at
- MinIO WORM put + governance retention doğrula
- Hash chain verify testi (append-only proof, hash immutability)

**Acceptance:**
- [ ] Hash chain unit testi (3 log ekle → chain doğru)
- [ ] Local cert CAdES imza test sertifikası ile çalışıyor
- [ ] MinIO WORM put + `mc retention info` çıktısı
- [ ] **NEEDS_HUMAN gate:** `five651_archive_change` — kullanıcı onayı "bu paketleme hukuken yeterli MVP olarak kabul ediliyor mu?"

**Worker:** cline (T3, logs_5651 + archive)
**Gate:** `five651_archive_change` → NEEDS_HUMAN

### Sprint 10 — End-to-End Integration (2 gün)
**Amaç:** Tüm akış bir test senaryosunda çalışsın.

- E2E test scripti:
  1. Fake FortiGate syslog akışı başlat (traffic + captive event)
  2. Captive portal auth (SMS/Voucher)
  3. Session log row oluştu
  4. Celery beat mock: günlük signer tetikle
  5. Hash chain + imzalı paket MinIO'da
  6. Verify: chain + imza + WORM
- `verify_service.py` (mevcut) ile paket doğrulama
- BTK export format örneği (CSV): session + traffic logs birleşik

**Acceptance:**
- [ ] E2E test yeşil
- [ ] İmzalı paket verify edilebilir
- [ ] CSV export örneği oluştu (BTK denetim formatı referansı)

**Worker:** cline + opencode (test üretimi)

### Sprint 11 — Hardening + Quality Close (1 gün)
**Amaç:** MVP'yi dürüst bir terminal statüyle kapat.

- `quality-close` skill ile final.md yaz
- DECISIONS.md + TODO.md + CLAUDE.md "Mevcut Durum" güncelle
- Bilinen riskler: KamuSM gerçek, FortiGate cihaz testi, RADIUS CoA (out-of-scope)
- Branch finalize (`finishing-a-development-branch`)

**Hedef terminal status:** `PARTIAL` (MVP çalışıyor ama üretim hukuki/gerçek cihaz doğrulaması NEEDS_HUMAN)

---

## 3b. Detaylı Hızlı Log Arama — Spec Özeti (Sprint 07b)

Kullanıcı notu (2026-07-27): "siem gibi istemiyorum ama detaylı log arama istiyorum,
hızlı bir log search istiyorum"

### Tasarım felsefesi
- **SIEM değil:** query dili (Lucene/KQL), dashboard, alert, real-time stream YOK
- **Detaylı:** 10+ structured filter + serbest metin + raw view + korelasyon
- **Hızlı:** PostgreSQL GIN full-text index + composite index, sub-100ms hedef

### Filtreler (filter params — query string)
| Filter | Type | Notlar |
|---|---|---|
| `vendor` | enum | fortigate (MVP'de tek) |
| `log_type` | enum multi | traffic / utm / event / iap |
| `severity` | enum multi | critical / high / medium / low / info |
| `action` | enum multi | accept / deny / client-rst / server-rst |
| `src_ip` | string | prefix match destekli (`10.0.0.` gibi) |
| `dst_ip` | string | prefix match |
| `src_port` | int | exact |
| `dst_port` | int | exact |
| `user` | string | exact veya substring |
| `device_id` | uuid | exact |
| `location_id` | uuid | exact |
| `policyid` | int | exact |
| `service` | string | HTTP/HTTPS/SSH vb. |
| `proto` | enum | TCP/UDP/ICMP/numara |
| `q` | serbest metin | tsvector üzerinde, raw syslog içeriği |
| `from` / `to` | ISO 8601 | zaman aralığı |
| `time_window` | preset | 15m / 1h / 24h / 7d |
| `limit` / `offset` | int | pagination (max 1000 / default 100) |

### Hız zdroğu (PostgreSQL)
```sql
-- tsvector generated column
ALTER TABLE firewall_logs ADD COLUMN search_vector tsvector
  GENERATED ALWAYS AS (
    to_tsvector('english',
      coalesce(raw_syslog, '') || ' ' ||
      coalesce(src_ip, '') || ' ' ||
      coalesce(dst_ip, '') || ' ' ||
      coalesce(user, '')
    )
  ) STORED;
CREATE INDEX firewall_logs_search_gin ON firewall_logs USING GIN(search_vector);
CREATE INDEX firewall_logs_tenant_ts ON firewall_logs(tenant_id, ts DESC);
CREATE INDEX firewall_logs_session ON firewall_logs(session_id) WHERE session_id IS NOT NULL;
```

### Endpoint'ler (4 tane — sade)
1. `GET /api/v1/logs/search` — filter params ile sorgu, JSON array dön
2. `GET /api/v1/logs/facets` — aktif filtreye göre 4 facet (vendor/log_type/severity/action)
3. `GET /api/v1/logs/correlate?session_id=` — session bazlı birleşik view
4. `GET /api/v1/logs/export?format=csv|jsonl` — dışa aktar

### Frontend UI akışı
1. Sol panel filter form (vendor/log_type/severity/action checkboxes + IP/user inputs)
2. Üst bar: serbest `q` input + zaman preset + "Ara" + "Dışa Aktar"
3. Orta: tablo (virtualized) — satıra tıkla → expand → raw JSON + korelasyon linki
4. "Yenile" butonu (manuel — auto-refresh YOK)
5. Tenant görsel göstergesi (sağ üst): hangi tenant'ta olduğu yazsın

### Performans hedefi
| Senaryo | Hedef |
|---|---|
| 100K kayıt, tek filter | < 100ms |
| 100K kayıt, 4 filter combo | < 200ms |
| 1M kayıt, index hit | < 500ms |
| Facets 4'lü paralel | < 200ms (Promise.all) |
| Export 100K satır CSV | < 5s |

### MVP dışı (kullanıcı talebiyle)
- Query dili (Lucene/KQL/SPL)
- Real-time stream / WebSocket / SSE
- Saved search / alert / notification
- Dashboard / widget / chart / histogram
- Facet on-the-fly seçimi (sadece 4 sabit facet)
- Anomaly detection / ML
- Distributed search / ClickHouse (MVP'de PostgreSQL yeterli)

---

---

## 4. Riskler ve Azaltıcı Önlemler

| Risk | Olasılık | Etki | Azaltma |
|---|---|---|---|
| Mevcut test baseline kırmızı | Yüksek | Orta | Sprint 06 ilk görev; kırmızı testler NEEDS_HUMAN değil, fixlenir |
| 5651 hash chain hukuken yetersiz | Orta | Yüksek | `five651_archive_change` NEEDS_HUMAN gate; kullanıcı onayı şart |
| FortiGate fake server ile gerçek cihaz arası fark | Yüksek | Yüksek | Lab test planı yaz, cihaz zamanı NEEDS_HUMAN |
| Local cert CAdES ile gerçek KamuSM arası format farkı | Orta | Orta | Signing abstraction `sign_with_kamusm` zaten ayrı, MVP'de `localfile` branch |
| T3 path'lerde worker scope sızıntısı | Orta | Yüksek | security-auditor her sprint, reviewer diff disiplin |
| Hash chain sequential kırılma | Düşük | Yüksek | Append-only proof test, hourly checkpoint (günlük değil) opsiyonel |
| Celery beat nightly job timing sorunu | Düşük | Orta | Beat config ve `CELERY_TIMEZONE` doğrula |

---

## 5. Out-of-Scope (MVP Sonrası — TODO.md backlog)

- Diğer 11 firewall vendor (sadece FortiGate adapter gerçek)
- KamuSM REST API entegrasyonu (TUBITAK MA3 lisansı alımı gerekli)
- E-Tuğra REST API alternatifi
- E-Mühür ( tüzel kişi sertifikası)
- Aylık PAdES rapor + ASiC kapsül
- RADSEC, RADIUS CoA, WPA3-SAE, OpenRoaming
- Multi-tenant (sadece demo tenant)
- ClickHouse/OpenSearch search aktif edilmesi
- SaaS site-bridge hardening
- Real SMS/Email provider
- Gerçek FortiGate cihaz lab testi
- iOS/macOS captive portal mini-browser uyumu (7.6.4 manual trigger)

---

## 5b. GUI Uyumu — NeoSecra Ailesi ile Tutarlılık (KESİN ZORUNLULUK)

**Kullanıcı kararı (2026-07-27):** Hotspot admin GUI'si NeoSecra Assessment,
SOC ve PISH projeleriyle **aynı tasarım diline** sahip olmalı. Tek marka/look
kullanılacak.

**Etkilenen projeler:**
- `/home/sirgloomy/projects/neosecra-assessment`
- `/home/sirgloomy/projects/neosecra-soc`
- `/home/sirgloomy/projects/neosecra-pish`
- `/home/sirgloomy/projects/Hotspot` (hedef)

**Kapsam (frontend/admin):**
- **Tema:** Tailwind config (renk paleti, font, spacing)
- **Layout shell:** Sidebar + header + breadcrumb yapısı
- **Component primitives:** Button, Card, Badge, Input, Modal, Table
- **Iconography:** Aynı icon seti (lucide-react önerisi)
- **Typography:** Aynı font (Inter / system-ui)
- **Renk değişkenleri:** CSS custom properties / Tailwind theme tokens
- **Auth/login sayfası:** Aynı görsel kimlik

**Strateji:**
1. Audit: NeoSecra projelerinde hangi GUI dosyaları (tailwind.config, index.css,
   Layout.tsx, components/ui/*) canonical kabul ediliyor?
2. Extraction: NeoSecra "gui-core" pattern'i tek bir referansa topla
3. Port: Hotspot frontend/admin'e uygula (overlay olarak, mevcut sayfaları bozmadan)
4. Verification: Login + Dashboard screenshot ile görsel teyit

**Sprint yerleşimi:** Sprint 07b (Log Search) başlamadan önce mini-sprint veya
Sprint 07b'nin ilk günü GUI hizalaması yapılır — log search sayfası NeoSecra
shell'inde render olmalı.

---

## 6. Onay Bekleyen Kararlar (Kullanıcı Onayı)

Bu design üzerinde aşağıdaki kritik kararlar için kullanıcı onayı gerekiyor
(brainstorming HARD-GATE):

1. **MVP scope** = sadece FortiGate + tek tenant + demo kanıtları. ✓/✗
2. **SignLogger MVP'de local-cert CAdES**, KamuSM/E-Tuğra out-of-scope. ✓/✗
3. **SignLogger hash chain** sequential (Merkle değil). ✓/✗
4. **7 sprint × ~2 gün = ~14 iş günü** tahmin (detaylı log arama sprinti eklendi). ✓/✗
5. **Detaylı hızlı log arama** = 10+ structured filter + serbest `q` + GIN index, NO Lucene/stream/dashboard. ✓/✗
6. **Hedef terminal status PARTIAL** (DONE değil, çünkü gerçek cihaz + KamuSM NEEDS_HUMAN). ✓/✗
7. **Worker seçimi**: Sprint 06 kimi-direct, Sprint 07/07b/08/09/10 cline (07b+10 opencode ile paralel frontend test). ✓/✗

Onay verilirse: `writing-plans` ile implementation plan yazılır, Sprint 06 başlar.
Onay verilmezse: itiraz edilen maddeler için alternative tasarım yapılır.

---

**Onay:** _____________ (kullanıcı) **Tarih:** _________
