# Log Arama / 5651 / Raporlama — Gap Analizi ve Yol Haritası

**Tarih:** 2026-08-20
**Branch:** feature/hotspot-mvp-readiness
**Run:** RUN-20260727-001 (devamı)
**Risk tier:** T3 (logs_5651 / search / syslog / radius / sessions path'leri)
**Status:** APPROVED — Kullanıcı tarafından onaylandı (2026-08-20)

---

## 1. Amaç ve Bağlam

Kullanıcı talebi (2026-08-20): "uçtan uca incele, eksikleri çıkar; 5651 ve
captive portal önemli ama en önemlisi log arama/raporlama. ELK search gibi bir
şey lazım. Diğer çözümlerden daha farklı rapor setleri vermemiz lazım."

Bu doküman uçtan uca inceleme sonucu çıkan eksik listesini ve bunları kapatacak
4 fazlı yol haritasını sabitler. Captive portal akışı sağlam kabul edilmiş,
5651 yarı-hazır, **log arama/raporlama rekabet edemeyecek seviyede** bulunmuştur.

---

## 2. Teknoloji Kararı: ClickHouse (güçlendir), OpenSearch sonraya

**Karar:** Mevcut ClickHouse'u full-text + aggregasyon yetenekleriyle güçlendir.
OpenSearch/Elasticsearch bu fazda eklenmez.

**Gerekçe:**
1. Veri **doğal dil değil key=value** (FortiGate `src_ip= dst_ip= policyid= app= ...`).
   Arama ihtiyacının ~%90'ı yapısal (IP/MAC/user/vendor/zaman) + `message` substring.
   ClickHouse `ngrambf_v1`/`tokenbf_v1` bloom index bunu karşılar; Lucene stemming/fuzzy gerekmez.
2. **White-label + multi-tenant** (Mutlak Kural #1/#2): arama kendi React admin'ine
   gömülmeli. OpenSearch Dashboards müşteriye gösterilmeyeceği için "Kibana bedava
   gelir" avantajı burada geçersiz; UI zaten custom yazılacak.
3. ClickHouse **zaten koşuyor** (docker-compose servisi var), syslog dual-write çalışıyor
   (`syslog/service.py`). İkinci JVM cluster + ingest + DLS/RBAC overhead'ından kaçınılır.
   On-prem appliance ayak izi küçük kalır (Kural #11).
4. `infra/opensearch-clickhouse/README.md` zaten "full-text için OpenSearch, zaman
   serisi için ClickHouse" diyor; bu fazda full-text'i ClickHouse'da pratik karşılarız,
   ileride gerçek relevance-ranked arama gerekirse OpenSearch index'i service katmanının
   arkasına eklenebilir (servis arayüzü değişmez).

**Kaçış kapısı:** `unified_search()` servisi veri kaynağından bağımsız yazılırsa,
OpenSearch sonradan plug-in olarak eklenebilir.

---

## 3. Uçtan Uca İnceleme — Bulgular

### 3.1 Log Arama (EN KRİTİK)

Şu an **3 ayrı, tutarsız** arama yolu var; birleşik katman yok:

| Endpoint | Veri kaynağı | Sorun |
|---|---|---|
| `GET /search/syslog` | ClickHouse + arşiv + PG fallback | ClickHouse'da `q` free-text YOK (sadece exact match). Arşiv araması `ArchiveIndex.searchable_fields`'a bakıyor ama bu alan hiçbir yerde doldurulmuyor → arşiv araması pratikte boş döner (`search/service.py:644`). |
| `GET /logs/search` + facets + correlate + export | PostgreSQL `firewall_logs` (GIN tsvector) | Full-text `plainto_tsquery("english", ...)` → **Türkçe loglar için yanlış dil, stemming yok** (`search/service.py:949`). |
| `GET /firewall-logs` + export | `search_syslog` sarmalayıcı | Scope `user.tenant_id` üzerinden kuruluyor ama `FirewallLog.tenant_id` hostname'den çözülüyor → scope tutarsız (`search/router.py:342`, `search/service.py:945`). |

**Eksikler (ELK/Kibana eşdeğeri):**
- **Gerçek full-text yok**: ClickHouse `syslog_logs` tablosunda `message`/`raw` üzerinde
  token/ngram index yok (bloom index sadece mac/ip/user/device/domain). `q` ClickHouse
  tarafında hiç çalışmıyor.
- **Birleşik federated search yok**: syslog + radius + firewall + session + identity
  tek sorguda birleşmiyor.
- **Aggregation/dashboard yok**: facets sadece 4 kolon (vendor/log_type/severity/action).
  Histogram, top-N, zaman serisi, drill-down yok.
- **Saved search/alerting bağlı değil**: `SearchView` modeli var (`search/models.py`)
  ama UI'da ve alarm'a bağlanmamış.
- **OpenSearch tamamen boş**: kodda `opensearch`/`elasticsearch`/`ELK` referansı sıfır
  (grep ile doğrulandı). Sadece placeholder README.

### 3.2 5651 — Yasal Eksikler

- **Arşiv sadece session metadata** içeriyor; traffic/syslog/radius **raw kaydı
  arşivlenmiyor** (`logs_5651/service.py:86` `_serialize_sessions`). 5651 IP↔kimlik
  korelasyonu için yetersiz.
- **KamuSM gerçek API değil**: `signing_service.py` demo'da mock imza, prod'da URL/creds
  gerekli. PKCS#11 stub (`signing_service.py:293`).
- **Retention**: ClickHouse TTL 730g var ama PostgreSQL tarafında retention policy yok.
  MinIO WORM 730d gerçekte doğrulanmamış (TODO.md P3).
- `archive_catalog` ClickHouse tablosu tanımlı ama `archive_service` onu kullanmıyor
  (MinIO/local'a gidiyor) → iki ayrı katalog.
- Court evidence paketi syslog'u `hostname==nas_ip` + `message.contains(ip)` ile bağlıyor
  (`report_service.py:444`) — kırılgan, MAC/IP/NAT korelasyonu yok.

### 3.3 Raporlama — Farklılaşma Yok

- `ReportsPage.tsx` sadece 3 KPI + günlük trend + auth dağılımı. Her rakibin verdiği şey.
- `olap_service.py` 200+ template üretiyor ama **frontend hiç kullanmıyor**; üstelik
  sadece PostgreSQL `GuestSession`/`SyslogRecord` sorguluyor (ClickHouse/FirewallLog yok).
  Efektif olarak ölü kod.
- PDF raporları reportlab/weasyprint kurulu değilse 501 (`reports/service.py:131`,
  `logs_5651/report_service.py:118`). Varsayılan imajda kütüphane yok.
- Farklılaştırıcı özel rapor tipi yok (5651 delil paketi, IP↔kimlik matrisi, lokasyon
  ısı haritası, operatör denetim raporu, quota/lisans kullanımı, auth-funnel).

### 3.4 Captive Portal (durum: iyi)

- Akış sağlam: SMS/TC/voucher/PMS/WhatsApp/meeting/foreigner/local/LDAP/free,
  KVKK consent, quota gate, user-group policy, ban check (`portal/flow.py`).
- **RADIUS metodu 501** (`portal/flow.py:560`) → 802.1X yok.
- Gerçek FortiGate cihaz testi yok (fake server ile doğrulanmış).

---

## 4. Yol Haritası (4 Faz)

### Faz 1 — Birleşik Arama Servisi (backend, en kritik)

**Amaç:** Tek giriş noktası, doğru scope, ClickHouse full-text, gerçek facets.

- [ ] `search/unified_search()` tek servis; 3 paralel yolu (`/search/syslog`,
      `/logs/search`, `/firewall-logs`) buna topla, eskileri deprecate (yanıt şeması
      geriye uyumlu tutulur).
- [ ] **Scope bugfix**: `user.tenant_id` kullanımını `scope_for(user)` ile değiştir
      (`search/service.py:945`, `search/router.py:342`). `FirewallLog.tenant_id` ↔
      `customer_id` karmaşası netleştirilir (tek kanonik alan).
- [ ] ClickHouse `syslog_logs` tablosuna `message`+`raw` için `ngrambf_v1`/`tokenbf_v1`
      full-text index ekle; `query_syslog`'a `q` desteği (hasToken/LIKE + ascii lowercase
      normalizasyonu, Türkçe karakter fold).
- [ ] Arşiv arama yolu: ya `searchable_fields` doldur ya da (önerilen) arşiv aramasını
      ClickHouse'a yönlendir (730g TTL zaten var), PG fallback sadece CH offline iken.
- [ ] Facets'i 4 kolondan → date histogram + top-N (src_ip, dst_ip, domain, app, policy,
      user) çıkar; ClickHouse GROUP BY ile.
- [ ] Korelasyonu tekleştir (`correlate_session` + `_build_correlation_metadata` iki
      implementation); MAC/IP/NAT korelasyonu ekle.

**Acceptance:**
- [ ] `q` free-text ClickHouse'da çalışıyor (test: substring `message` içinde bulur)
- [ ] scope cross-tenant IDOR testi geçer
- [ ] facets histogram + top-N döner
- [ ] mevcut arama testleri yeşil (regression yok)

**Worker:** kimi subagent (exploration-required değil; spec burada). Testler opencode.

### Faz 2 — ELK-benzeri UI (React admin)

**Amaç:** Kibana benzeri deneyim: histogram, drill-down, saved search, korelasyon.

- [ ] `LogsSearch.tsx` v2: zaman histogramı, tıklayınca filtre ekleyen dynamic facets,
      absolute+relative time picker, saved search (mevcut `SearchView` API'sini bağla).
- [ ] Korelasyon timeline görselleştirme (`CorrelateModal`).
- [ ] Dashboard KPI/chart'ları ClickHouse agregasyonlarına bağla (`get_traffic_aggregation`).

**Acceptance:**
- [ ] saved search oluştur/listele/sil UI'dan çalışır
- [ ] facet değerine tıklama filtre ekler
- [ ] vitest yeşil (admin)

**Worker:** opencode (mechanical/UI) + kimi (UI ile servis entegrasyonu).

### Faz 3 — 5651 Tamamlama

**Amaç:** Yasal uyum + delil bütünlüğü.

- [ ] Arşive **raw traffic/syslog/radius** ekle: yeni `record_type`(lar), aynı
      per-(customer,record_type) hash chain. `_serialize_sessions`'a ek/ayrı serializer.
- [ ] Gerçek KamuSM API entegrasyonu (`_sign_kamusm_api` prod path) + PKCS#11 (ya da
      açıkça out-of-scope işaretle — NEEDS_HUMAN).
- [ ] PostgreSQL retention policy (soft-delete/partition/purge task) + MinIO WORM
      doğrulama kanıtı (`mc retention`).
- [ ] Delil paketi korelasyonu `message.contains(ip)` → MAC/IP/NAT eşleştirme.

**Acceptance:**
- [ ] raw traffic log arşivi hash chain'e giriyor + verify ediliyor
- [ ] MinIO WORM kanıtı (mc retention get çıktısı)
- [ ] NEEDS_HUMAN: KamuSM gerçek entegrasyon kapsamı onayı

**Worker:** kimi subagent (T3, logs_5651). Security-auditor her sprint.

### Faz 4 — Farklılaştırıcı Rapor Setleri (rekabet avantajı)

**Amaç:** Rakipte olmayan rapor kataloğu.

- [ ] Özel rapor setleri:
  - 5651 mahkeme delil paketi (mevcut `generate_court_evidence_package` güçlendirilir)
  - IP↔kimlik matrisi (IP ↔ phone ↔ TC ↔ voucher ↔ MAC)
  - Lokasyon ısı haritası / yoğunluk
  - Operatör denetim raporu (BTK/5651 hazır format)
  - Quota/lisans kullanım raporu
  - Auth-method funnel + peak-hour/venue analitiği
- [ ] `olap_service`'i ClickHouse'a bağla (FirewallLog/syslog kaynakları), template'leri
      rapor scheduler + email'e bağla.
- [ ] weasyprint'i Docker imajına ekle (PDF 501 fix).

**Acceptance:**
- [ ] en az 4 farklılaştırıcı rapor template'i üretilir + PDF/CSV çıktı alınır
- [ ] scheduler job email + download çalışır
- [ ] frontend ReportsPage bu raporları sunar

**Worker:** opencode (scheduler/PDF/UI mekanik) + kimi (olap→ClickHouse).

---

## 5. Önerilen Sıra ve Tahmin

| Faz | İçerik | Tahmin |
|---|---|---|
| 1 | Birleşik arama + ClickHouse full-text + facets | 3-4 gün |
| 2 | ELK-benzeri UI | 2-3 gün |
| 3 | 5651 raw arşiv + retention + KamuSM | 3-4 gün |
| 4 | Farklılaştırıcı rapor setleri | 3-4 gün |

Faz 1+2 birlikte "ELK gibi arama"yı verir (ilk teslim edilecek hedef).
Faz 3 yasal uyum, Faz 4 farklılaşma.

---

## 6. Riskler

| Risk | Olasılık | Etki | Azaltma |
|---|---|---|---|
| ClickHouse ngram full-text büyük hacimde yavaş | Orta | Orta | index_granularity ayarı + sıcak/soğuk partition; gereksizse OpenSearch escape |
| Scope bugfix mevcut testleri bozar | Orta | Orta | regression suite'i önce baseline al |
| KamuSM gerçek entegrasyon hukuki/kurumsal gecikme | Yüksek | Orta | Faz 3'te NEEDS_HUMAN gate; local-cert geçici çözüm kalır |
| Rapor farklılaşması rakip analizine dayalı değil | Orta | Yüksek | Faz 4 başında rakip rapor seti kıyası (kullanıcı girdisi) |
| OLAP ölü kod canlandırma maliyeti | Orta | Orta | olap yerine doğrudan ClickHouse aggregation yaz |

---

## 7. Onay Bekleyen Kararlar

1. **Teknoloji**: ClickHouse güçlendir, OpenSearch sonraya. ✓/✗
2. **Faz sırası**: 1→2→3→4 (arama önce, rapor sonra). ✓/✗
3. **5651 raw arşiv kapsamı**: traffic+syslog+radius aynı hash chain'e girsin. ✓/✗
4. **KamuSM**: Faz 3'te gerçek entegrasyon mu, yoksa açıkça out-of-scope mu? ✓/✗
5. **Farklılaştırıcı rapor seti**: yukarıdaki 6 set mi, ek/çıkar var mı? ✓/✗

---

**Onay:** _____________ (kullanıcı) **Tarih:** _________
