# FortiOS 7.6 Captive Portal — Apple iOS/macOS Compatibility Guide

## Overview

Apple iOS (since iOS 7) and macOS (since 10.13) implement a **Captive
Network Assistant (CNA)** that detects captive portals by fetching
well-known URLs before allowing full network access. If the device
receives an unexpected response (redirect, different content), it
opens the captive portal login page in a restricted browser.

## Detection URLs

Apple devices probe these URLs on connecting to a Wi-Fi network:

| URL | Expected Response (no captive) | Captive Response |
|-----|-------------------------------|------------------|
| `/hotspot-detect.html` | `200 OK` with `Success` body | `302 Redirect` to portal |
| `/generate_204` | `204 No Content` | `302 Redirect` to portal |
| `/ncsi.txt` | `200 OK` with `Microsoft NCSI` | `302 Redirect` to portal |

## FortiOS 7.6.4 Configuration

### Bridge SSID with Captive Portal

```
config user group
    edit "guest-users"
        set member "guest"
    next
end

config wireless-controller vap
    edit "guest"
        set ssid "Hotel-Guest"
        set security captive-portal
        set captive-portal-type external
        set external-portal-ip <hotspot-platform-ip>
        set external-portal-port 80
        set external-portal-https enable
        set external-portal-url "https://hotspot.example.com/?device_id=<HOTSPOT_DEVICES_ID_UUID>"
    next
end
```

### Captive Portal Parameters

| Parameter | Value | Description |
|-----------|-------|-------------|
| `security` | `captive-portal` | Enables captive portal authentication |
| `captive-portal-type` | `external` | Uses external captive portal (Hotspot) |
| `external-portal-ip` | Platform IP | Hotspot platform public IP |
| `external-portal-url` | Full URL | Redirect URL with the UUID from Hotspot `devices.id` |

The `<HOTSPOT_DEVICES_ID_UUID>` value is copied from the Hotspot admin
portal configuration after the FortiGate has been registered and assigned to
its location. The portal resolves `device_id` against the Hotspot SQL
`devices.id`, then loads that location's template and policy.

## Hotspot Platform Configuration

The platform serves the three Apple detection endpoints at:

```
GET /hotspot-detect.html  → 200 (Success) if authenticated
GET /generate_204         → 204 (No Content) if authenticated
GET /ncsi.txt             → 200 (Microsoft NCSI) if authenticated
```

When a client has no valid portal token (cookie or header), all three
endpoints return `302 Redirect → /portal/config` which triggers the
full captive portal login flow.

### Token Detection

The platform checks for a `portal_token` cookie or `X-Portal-Token`
header. If absent or expired, the device is considered captive.

## iOS/macOS CNA Behavior

1. User connects to `Hotel-Guest` SSID
2. iOS sends `GET /hotspot-detect.html`
3. Hotspot returns `302 → /portal/config`
4. iOS CNA opens the portal URL in a full-screen web view
5. User authenticates via SMS/Voucher/Meeting Code/etc.
6. On success, Hotspot sets `portal_token` cookie
7. iOS re-probes `/hotspot-detect.html` → gets `200 Success`
8. CNA dismisses, iOS enables full network access

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| "Captive" icon persists after login | Cookie not set on redirect domain | Ensure portal_token cookie domain matches detection endpoint |
| Endless redirect loop | Token check always fails | Check token expiry and cookie path |
| CNA doesn't open | Wrong detection URL | Verify `/hotspot-detect.html` resolves to platform IP |
| Android devices stuck | Missing `/generate_204` | Ensure 204 endpoint responds correctly |
| Windows NCSI warning | Missing `/ncsi.txt` | Ensure ncsi.txt returns "Microsoft NCSI" text |
