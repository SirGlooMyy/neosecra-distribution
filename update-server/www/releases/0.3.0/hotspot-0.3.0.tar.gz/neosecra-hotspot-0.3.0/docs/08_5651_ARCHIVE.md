# 5651 Loglama ve Arşiv Tasarımı

## Hedef Korelasyon
- Kullanıcı/kimlik
- Telefon
- TC doğrulama sonucu
- Voucher
- IP
- MAC
- NAT IP/Port
- Başlangıç/bitiş zamanı
- Lokasyon
- Cihaz
- RADIUS accounting
- Syslog event
- Hash/arşiv

## Arşiv Akışı
```text
Session + Radius + Syslog + NAT mapping
  -> correlation
  -> daily/hourly archive batch
  -> canonical log file
  -> hash calculation
  -> MinIO/S3 upload
  -> archive_hashes record
  -> report/export ready
```

## Tasarım Notları
- Archive records append-only kabul edilmeli.
- Hash kayıtları update edilmemeli; yeni versiyon event olarak eklenmeli.
- Arşiv bütünlük raporu üretilebilmeli.
- Retention policy tenant/license'a göre uygulanmalı.
