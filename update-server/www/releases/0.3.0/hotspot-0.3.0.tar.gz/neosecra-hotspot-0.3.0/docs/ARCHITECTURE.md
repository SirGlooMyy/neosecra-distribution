# Mimari

## Katmanlar (her modül için aynı ayrım)

```
router.py      → HTTP girişi, yetki/scope kontrolü, request parsing. İş yapmaz.
service.py     → iş mantığı. Cross-module erişim BURADAN olur.
repository.py  → DB erişimi (select/insert/scope filtre). 
schemas.py     → Pydantic I/O modelleri.
models.py      → SQLAlchemy tabloları (Base, UUIDPK, TimestampMixin, SoftDeleteMixin).
```

Kural: router service'i çağırır, service repository'i/other service'i çağırır.
Router'dan doğrudan SQL yok. Cross-module import `service` üzerinden.

## Tenant scope modeli (her şeyin kalbi — Mutlak Kural #1/#2)

```
backend/app/core/tenant.py
  TenantLevel:  GLOBAL > PARTNER > CUSTOMER > LOCATION   (TENANT = partner için alias)
  ScopeContext: { level, tenant_id, partner_id, customer_id, location_id, allowed }
  scope_for(user): User → ScopeContext. Scoped rolün zorunlu ataması yoksa allowed=False (fail-closed).

backend/app/core/rbac.py
  ROLE_PERMISSIONS: role → yetki seti. "*" = süper admin (her şey).
  has_permission(role, perm)
```

Her repository sorgusu `ScopeContext` alır ve filtre uygular:
- `GLOBAL` → filtre yok (sadece super_admin).
- `PARTNER` → `Customer.partner_id == scope.partner_id` join.
- `CUSTOMER` → `customer_id == scope.customer_id`.
- `LOCATION` → önce location→customer çöz, customer ekseninde filtre.
- `allowed=False` → **boş sonuç döndür** (IDOR fail-closed; asla tüm veri).

Ortak pattern: `async def _scoped_query(db, scope) -> (query, allowed)`.
Örnek konumlar: `logs_5651/service.py`, `licensing/service.py`,
`sessions/service.py` (`_scoped_query_async`), `reports/service.py` (onu kullanır).

## Akış 1 — Captive Portal (PUBLIC, JWT yok)

```
Misafir cihaz → firewall → /api/v1/portal/public/...  (device_id trust anchor)

portal/public_router.py  (rate-limit IP bazlı, JWT YOK)
  POST /portal/public/context          → flow.resolve_context(device_id)
  POST /portal/public/send-code        → flow.send_code         (SMS OTP)
  POST /portal/public/verify           → flow.verify            → PortalTokenOut (bir kez)
  POST /portal/public/start-session    → flow.start_session     → StartSessionOut

portal/flow.py:
  resolve_context(device_id): device→location→customer→PortalTemplate. Herhangi biri yok/pasif → 404 (Kural #6).
  verify(): method TEMPLATE'den alınır (client'tan DEĞİL → downgrade engeli).
            SMS→sms.verify_otp+identity.issue_for_sms | TC→issue_for_tc |
            VOUCHER→voucher.redeem+issue_for_voucher | FREE→issue_free | RADIUS→501
  start_session(): validate_portal_token → enforce_quota (Kural #12) →
            sentetik CUSTOMER ScopeContext ile firewall.authorize_guest_service
            (GLOBAL bypass YOK; adapter device↔customer tekrar doğrular) →
            sessions.create_session → identity.consume(token one-shot).
```

Güvenlik: device_id = trust anchor; tüm downstream resolved customer/location'a bound
→ misafir kimliği farklı siteye taşıyamaz (cross-site replay engeli).

## Akış 2 — 5651 Append-Only Arşiv (Mutlak Kural #4, hukuki-kritik)

```
logs_5651/service.py  build_session_archive(customer_id, period_start, period_end)
  1. [start,end) aralığındaki GuestSession'ları topla
  2. deterministic JSONL (sort_keys, sorted by started_at,id) → gzip(mtime=0)
  3. content_hash = sha256(payload)
  4. archive_service.upload() → content_ref (local | minio | none provider)
  5. zincir: prev_hash = last.curr_hash (veya GENESIS) ; chain_seq+1
     curr_hash = sha256(prev_hash | content_hash | period_key | record_type)
  6. ArchiveRecord SATIR ekle (append-only; UPDATE/DELETE YOK; SoftDelete YOK)
  7. log_audit("5651.archive_created") + commit

verify_chain(customer_id): chain_seq sırasıyla yürür, prev_hash bağı + curr_hash
  yeniden hesap. Mismatch = satır değiştirilmiş/silinmiş/eklenmiş → tamper kanıtı.

Tetikleyiciler:
  - Worker beat: tasks.archive_5651_daily (her gün 02:30 UTC, dün için)
  - Admin: POST /api/v1/logs-5651/build  (IDOR-guarded)
  - Manuel: tasks.archive_5651_for_customer(customer_id, date)
```

## Akış 3 — Session Expiry (Worker, Mutlak Kural #5)

```
sessions/service.py  expire_due(db): status=active + expires_at<now → status=expired + ended_at.
  ASLA SİLMEZ (soft state). log_audit("session.expired_batch") + commit.
Tetikleyici: tasks.expire_due_sessions (beat */5 dk).
```

## Akış 4 — Session Correlation (Mutlak Kural #5 purge gate)

```
sessions/correlation.py  correlate(db, guest_session_id):
  sources_matched = { portal:True, identity: var, radius: radius_session_id?,
                      syslog:False (M?), firewall_api:False (M?) }
  complete = ALL(sources).  complete=False iken purge/retention yasak.
GET /api/v1/sessions/{id}/correlation  (session.read, önce scope check)
Task: tasks.session_correlation_job(session_id)
```

## Akış 5 — Firewall Adapter (Mutlak Kural #7, vendor-agnostic)

```
firewall_adapters/
  base.py        FirewallAdapter ABC (test_connection, get_device_info,
                 authorize_guest, revoke_guest, parse_syslog_event)
  fortigate.py paloalto.py   somut adapter'lar
  registry.py    get_adapter_class(vendor)
  service.py     authorize_guest_service / revoke_guest_service / discover_device /
                 test_connection_service / parse_syslog(vendor, raw)
  Credential: firewall API tokenı Fernet ile şifreli (Kural #3), response'da ASLA yok.
```

Core service'e vendor mantığı GÖMÜLMEZ — adapter dispatch eder.

## Worker (Celery)

```
backend/app/modules/workers/
  celery_app.py  Celery("hotspot", broker=REDIS_URL, backend=REDIS_URL) + beat schedule
  runtime.py     worker_engine = NullPool async engine (asyncpg cross-loop güvenliği)
                 WorkerSession — her task kendi session'unu açar, asyncio.run içinde.
  tasks.py       expire_due_sessions / archive_5651_daily / archive_5651_for_customer /
                 session_correlation_job / firewall_sync_job(discover) / syslog_parse_job /
                 report_generation_job (graceful stub)
```

Worker task'ları SYNC'dir; async servis çağrısını `asyncio.run` ile çalıştırır.
Global scope (platform job, user request değil).

## Konfigürasyon & bootstrap

```
backend/app/core/config.py   Settings (pydantic-settings). DATABASE_URL, REDIS_URL,
                             MINIO_*, ARCHIVE_*, SMS_*, PORTAL_*, GUEST_SESSION_DEFAULT_MINUTES.
backend/scripts/dev_create_tables.py  create_all (dev, versions/ boş olduğu için).
backend/alembic/env.py      async migration env + model import listesi.
```
