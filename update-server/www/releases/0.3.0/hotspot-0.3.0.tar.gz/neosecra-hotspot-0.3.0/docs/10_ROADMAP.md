# Roadmap

## [TAMAMLANDI] Sprint 00 - Foundation
- [x] Domain model tanımları
- [x] Repo yapısının kurulması
- [x] CLAUDE/Cursor kuralları (`CLAUDE.md`)
- [x] Docker compose altyapısı (taslak)
- [x] Backend module iskeleti
- [x] Frontend rota ve dizin yapısı
- [x] Adapter interface tasarımı
- [x] Worker mimarisi ve görev şablonları
- [x] DB migration altyapısı hazırlığı

## [TAMAMLANDI] Sprint 01 - Core Platform & Frontend Foundations
- [x] Admin Dashboard Frontend Temeli (`frontend/admin/` altında React + TS + Tailwind)
- [x] Captive Portal Frontend Temeli (`frontend/portal/` altında Türkçe, SMS/TC/Voucher modlu arayüz)
- [x] Auth/RBAC/tenant yapısı kodlandı
- [x] Partner/customer/location hiyerarşisi kodlandı
- [x] Cihaz ve Lokasyon CRUD işlemleri hazırlandı
- [x] Portal template CRUD işlemleri iskeleti kuruldu
- [x] SMS/TC/Voucher alan doğrulayıcılar ve servis iskeleti yapıldı
- [x] Lisans taban modelleri entegre edildi

## [TAMAMLANDI] Sprint 02 - Backend Foundation & API Mock Integration
- [x] FastAPI + SQLAlchemy 2.x Async tabanlı API altyapısı (`backend/app/api/v1/endpoints/`)
- [x] Tüm domainlere ait veritabanı modelleri (`backend/app/models/`) ve şemalar (`backend/app/schemas/`)
- [x] Test bağlantısı özellikli FortiGate / Palo Alto adapter sınıfları (`backend/app/adapters/firewall/`)
- [x] SMS OTP gönderme/doğrulama servisleri, TC algoritma doğrulaması ve mock voucher denetimi
- [x] Celery Beat zamanlayıcı ve arka plan işleri şablonları (`backend/app/workers/`)
- [x] 9 adet üniteden oluşan test paketinin yeşillendirilmesi (`backend/tests/`)
- [x] Geçici dosyaların (`__pycache__`, `.venv`) temizlenmesi ve `.gitignore` yapılandırması

## [SIRADAKİ] Sprint 03 - Database Schema & Canlı Veri Katmanı
- [ ] PostgreSQL üzerinde gerçek veritabanı tablolarının oluşturulması (Alembic migration dosyalarının üretilmesi)
- [ ] Admin Dashboard ve Captive Portal frontend uygulamalarının canlı backend API'leri ile uçtan uca haberleşmesinin sağlanması
- [ ] Guest session oluşturulması (Gerçek oturum başlatma ve sonlandırma akışları)
- [ ] Oturum korelasyonu (IP/MAC/NAT eşleştirmeleri)
- [ ] Arşiv işçisi (Archive Worker) ve 5651 uyumlu hash/imza üretimi
- [ ] MinIO nesne deposuna logların otomatik yüklenmesi
- [ ] CSV/PDF raporlama motorunun tabanının yazılması

## [GELECEK] Sprint 04 - Ürünleştirme & SaaS Bridge
- [ ] Bayi (Partner) Yönetim Arayüzü
- [ ] White-label tema özelleştirmeleri
- [ ] Kullanım sayaçları ve kota aşımları kontrolü
- [ ] SaaS Site Bridge PoC (SaaS panelden yerel ağdaki cihazlara güvenli erişim)
- [x] OpenSearch / ClickHouse log analitiği entegrasyonu kararı: mevcut ürün ClickHouse + archive index ile ilerliyor; OpenSearch sonraki faz opsiyonel
