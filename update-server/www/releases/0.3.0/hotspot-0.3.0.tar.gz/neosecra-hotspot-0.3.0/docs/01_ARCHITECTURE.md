# Yüksek Seviye Mimari

```text
Admin Panel / Portal Frontend
        |
FastAPI Backend
        |
PostgreSQL + Redis + MinIO
        |
Platform Workers / Agents
        |
RADIUS Service + Syslog Collector + Firewall Adapter Layer
        |
FortiGate / Palo Alto / Other Gateways
```

## Ana Bileşenler

| Bileşen | Görev |
|---|---|
| API Server | Admin, portal, tenant, cihaz, rapor API'leri |
| Portal Service | Captive portal context ve auth akışı |
| RADIUS Service | Auth ve accounting eventleri |
| Syslog Collector | Firewall/gateway loglarını toplar |
| Firewall Adapter | Vendor API ve parser soyutlama katmanı |
| Session Correlator | Kullanıcı-IP-MAC-NAT-zaman korelasyonu |
| 5651 Archive Worker | Hash, arşiv, rapor ve export üretimi |
| SMS Worker | OTP gönderim/doğrulama kuyruğu |
| License Worker | Kullanım ve limit kontrolleri |
| Site Bridge | SaaS için opsiyonel local bridge |

## Tasarım İlkeleri
- On-prem first, SaaS-ready.
- Every module tenant-aware.
- Adapter-first firewall integration.
- Append-only log/archive events.
- Background jobs traceable/auditable.
