# API Haritası

Tüm endpoint'ler `/api/v1` prefix'i altında (kayıt: `app/api/v1/router.py`).
`JWT` = `get_current_user` zorunlu; yetki = `has_permission(role, X)`. `PUBLIC` = JWT yok.

## Auth (`/auth`)

| Method | Path | Yetki | Açıklama |
|--------|------|-------|----------|
| POST | `/auth/login` | PUBLIC | JWT + refresh token |
| GET | `/auth/me` | JWT | Mevcut kullanıcı |
| POST | `/auth/refresh` | JWT | Token yenile |
| POST | `/auth/logout` | JWT | Token blacklist |

## Tenant hiyerarşisi

| Method | Path | Yetki |
|--------|------|-------|
| GET/POST | `/tenants` | tenant.read / tenant.write |
| GET/PUT/DELETE | `/tenants/{id}` | tenant.read / tenant.write |
| GET/POST | `/partners` | partner.read / partner.write |
| GET/PUT/DELETE | `/partners/{id}` | partner.read / partner.write |
| GET/POST | `/customers` | customer.read / customer.write |
| GET/PUT/DELETE | `/customers/{id}` | customer.read / customer.write |
| GET/POST | `/locations` | location.read / location.write |
| GET/PUT/DELETE | `/locations/{id}` | location.read / location.write |

## Devices (`/devices`)

| Method | Path | Yetki | Açıklama |
|--------|------|-------|----------|
| GET | `/devices` | device.read | Liste (scope-filtreli) |
| GET | `/devices/{id}` | device.read | Detay |
| POST | `/devices` | device.write | Oluştur |
| PUT | `/devices/{id}` | device.write | Güncelle |
| DELETE | `/devices/{id}` | device.write | Soft delete |
| PUT/GET | `/devices/{id}/credential` | device.write / device.read | Şifreli API credential (Kural #3) |
| POST | `/devices/{id}/test-connection` | device.write | Adapter canlı kontrol |
| POST | `/devices/{id}/discover` | device.write | Metadata mirror |
| POST | `/devices/{id}/authorize-guest` | device.write | Misafir yetkilendir (adapter) |
| POST | `/devices/{id}/revoke-guest` | device.write | Misafir yetki geri al |

## Portal — admin template (`/portal`)

| Method | Path | Yetki |
|--------|------|-------|
| GET | `/portal` | portal.read |
| GET | `/portal/{id}` | portal.read |
| POST | `/portal` | portal.write |
| PUT | `/portal/{id}` | portal.write |
| DELETE | `/portal/{id}` | portal.write |

## Portal — PUBLIC captive flow (`/portal/public`) — JWT YOK, IP rate-limit

| Method | Path | Açıklama |
|--------|------|----------|
| POST | `/portal/public/context` | device_id → site context + template |
| POST | `/portal/public/send-code` | SMS OTP gönder |
| POST | `/portal/public/verify` | doğrula → PortalTokenOut (bir kez) |
| POST | `/portal/public/start-session` | token → yetkili oturum |

## Sessions (`/sessions`)

| Method | Path | Yetki | Açıklama |
|--------|------|-------|----------|
| GET | `/sessions` | session.read | Liste (scope) |
| GET | `/sessions/{id}` | session.read | Detay (scope check) |
| GET | `/sessions/{id}/correlation` | session.read | Korelasyon kaydı (Kural #5) |
| POST | `/sessions/{id}/close` | session.write | Manuel kapat |

## Vouchers (`/vouchers`)

| Method | Path | Yetki | Açıklama |
|--------|------|-------|----------|
| GET | `/vouchers/batches` | voucher.read | Batch listesi |
| POST | `/vouchers/batches` | voucher.write | Batch oluştur (code bir kez döner) |
| GET | `/vouchers/batches/{id}` | voucher.read | Batch detayı |
| PUT | `/vouchers/batches/{id}` | voucher.write | Batch güncelle |
| POST | `/vouchers/batches/{id}/deactivate` | voucher.write | Batch pasif |
| GET | `/vouchers/batches/{id}/vouchers` | voucher.read | Voucher listesi |

## Identity (`/identities`) — read-only (append-only)

| Method | Path | Yetki |
|--------|------|-------|
| GET | `/identities` | identity.read |
| GET | `/identities/{id}` | identity.read |

## 5651 Archive (`/logs-5651`)

| Method | Path | Yetki | Açıklama |
|--------|------|-------|----------|
| GET | `/logs-5651` | archive.read | Archive kayıtları (scope) |
| GET | `/logs-5651/{id}` | archive.read | Kayıt detayı |
| POST | `/logs-5651/build` | archive.write | Manuel archive (IDOR guarded) |
| GET | `/logs-5651/verify/{customer_id}` | archive.read | Hash chain doğrulama |

## Licensing (`/licenses`)

| Method | Path | Yetki | Açıklama |
|--------|------|-------|----------|
| GET | `/licenses` | license.read | Liste (partner; customer kendi) |
| GET | `/licenses/{customer_id}` | license.read | Detay (IDOR) |
| GET | `/licenses/{customer_id}/quota` | license.read | Canlı kota snapshot |
| PUT | `/licenses/{customer_id}` | license.write | Kota upsert (partner/super; customer YAZAMAZ) |

> Quota gate API'de değil, captive flow'da: `portal/flow.py:start_session → licensing.service.enforce_quota`.

## Reports (`/reports`)

| Method | Path | Yetki | Açıklama |
|--------|------|-------|----------|
| GET | `/reports` | report.read | Özet (total/by_status/by_method/bytes) |
| GET | `/reports/sessions/export?format=csv\|pdf` | report.read | CSV (stdlib, utf-8-sig) / PDF (reportlab lazy → 501) |

## Sistem

| Method | Path | Yetki |
|--------|------|-------|
| GET | `/health` | PUBLIC | Sağlık kontrolü |

## Notlar
- Tüm listelemeler scope-filtreli (`scope_for(user)`). Filtresiz liste yok.
- IDOR: `{id}` path parametreli endpoint'lerde service katmanı scope doğrular (fail-closed 403/404).
- Yeni endpoint ekle → `app/api/v1/router.py`'ye `include_router` + `app/core/rbac.py`'ye yetki.
