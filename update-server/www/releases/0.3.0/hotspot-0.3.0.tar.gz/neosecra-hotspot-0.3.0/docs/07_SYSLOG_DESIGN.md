# Syslog Tasarımı

## Amaç
Firewall/gateway loglarını 5651 ve session correlation için toplamak.

## MVP
- UDP/TCP syslog collector iskeleti.
- FortiGate parser MVP.
- Palo Alto parser iskeleti.
- Raw event saklama.
- Parse edilmiş alanları ayrı event tablosuna yazma.

## Pipeline
```text
Syslog input
  -> source detection
  -> tenant/location/device matching
  -> raw event persist
  -> parser selection
  -> normalized event
  -> session correlation queue
```

## Saklama
- Raw event: PostgreSQL veya file batch.
- Arşiv: MinIO/S3.
- Yüksek hacim: OpenSearch/ClickHouse sonraki faz ama klasör/adapter hazır.
