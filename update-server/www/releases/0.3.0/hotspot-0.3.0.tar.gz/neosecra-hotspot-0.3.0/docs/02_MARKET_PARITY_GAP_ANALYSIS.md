# Hotspot Market Parity Gap Analysis

Ek not: `5651` court evidence package artık `session.json` içinde `authorize_message`, `group_id` ve `group_policy` de taşıyor; evidence ZIP içindeki session kanıtı policy bağlamını da saklıyor.
Ek not 2: Public ürün sayfası, portal login ekranı ve backend portal config demo/trial akışını açık biçimde ayırıyor; backend demo tenant flag'i taşınıyor, trial provisioning endpoint'i sandbox paketini oluşturuyor ve cleanup worker expired sandboxes'ı decommission ediyor; trial sandbox renewal/reactivation otomasyonu da eklendi.
Ek not 3: Update/release yüzeyi şimdi saklanan bundle envanterini, publish-time distribution manifestini, activation record'unu ve dağıtım telemetry özetini ayrı gösteriyor; activation aynı kanaldaki önceki aktif release'i de supersede ediyor, kalan paket işi daha çok rollout orchestration / channel promotion automation tarafında.
Ek not 4: SystemSettingsPage artık whitelabel, SMTP ve health yükleme hatalarını sessizce yutmuyor; bu yüzeylerde hata görünür hale geldi.
Ek not 5: Portal auth simülasyonları artık runtime portal demo state'ine bağlı; backend demo sinyaliyle UI fallback aynı kaynağı kullanıyor.
Ek not 6: Trial inquiry provisioning artık sandbox tenant/customer/location/device/template/license/voucher paketi üretebiliyor; cleanup worker da expire olan sandbox'ları decommission ediyor ve renewal/reactivation otomasyonu da eklendi.

Not: Aşağıdaki "Acik Gaps" tablosu tarihsel referans amaçlı tutulur; çekirdek ürün yüzeyi tamamlandı, kalan maddeler sonraki faz / opsiyonel genişleme notu olarak okunmalıdır.

Bu not, mevcut repo durumunu ve piyasa referanslarını yan yana koyar. Cekirdek admin yuzeyler artık büyük ölçüde canlı; son slice'ta demo/mock yolları explicit `DEMO_MODE` altında sertleştirildi. Public content/versioning backend-veri katmanına bağlandı; public katalogda prod ortamda hardcoded fallback yerine boş durum, demo ortamda ise açık etiketli fallback kullanılıyor. Firewall log saved views, vendor filtreleme, correlation summary, source visibility ve evidence export eklendi; artık aynı correlation grubunda clickhouse/archive/postgres kaynağı görülebiliyor. User-group ve ban/whitelist policy gate'leri captive flow'a bağlandı; user-group CRUD artık VLAN profile mirror sync ve stable RADIUS anahtarı da üretiyor, update/release center ve bundle indirme yüzeyi eklenerek package story'nin ilk kısmı kapatıldı; release note bundle'ları artık publish sırasında saklanıyor, publish-time distribution manifesti üretilebiliyor, activation record saklanıyor ve public/system download route'ları bu stored artifact'i servis edebiliyor, dağıtım telemetry özeti de görünür hale geldi. Cihaz listesi de gerçek lokasyon/vendor mapping ve health özetiyle düzeltildi; syslog trigger'ları alarm event feed'ine ve delivery history'ye bağlandı; session listesi backend guest-session shape'i ve group policy/meta ile görünür hale getirildi; UserGroups formu location scope seçimini açtı ve policy preview ile captive kararı görünür kıldı; PMS vendor config akışları fail-closed çizgide; MFA kod teslimi de artık demo dışı sessiz başarı üretmiyor. Sistem güncellemeleri artık admin içinde doğrudan bir sidebar yüzeyinden açılabiliyor; release bundle'lar yayıncı izi, audit trail ve arşiv/geçmiş görünürlüğü ile izlenebilir; update kayıtları boş artifact URL durumunda otomatik release download path üretiyor, backup/restore akışı da config/full/db için doğru worker'lara bağlandı; public inquiry capture için admin lead inbox, trial inquiry provisioning, cleanup automation ve renewal/reactivation yüzeyleri eklendi; Support KB icin de admin CRUD, taxonomy, etiket, related metadata ve backend-ranked arama/öneri yuzeyi eklendi. Portal template editörü artık backend'e gerçek update atıyor, revision history/restore gösteriyor, live preview kullanıyor ve method field set ile legal metadata'yı da kaydediyor; captive portal tasarım yüzeyi de aynı portal güncelleme API'sine bağlandı. Kalan risk daha çok canonical portal context, publish akışı ve vendor-specific shaping/accounting ile adapter VLAN uygulamasında; adapter authorize path'leri artık policy notu ve normalize policy data taşıyor ama vendor-native enforcement derinliği hâlâ genişleyebilir. 5651 signing tarafında demo/gerçek provenance etiketi artık API ve admin yüzeyinde görünür; kalan risk prod/dev env karışması ve legacy kayıtların provenance bilgisiz kalması. Kalan riskler daha çok policy depth, cross-source stitching ve channel rollout otomasyonunda toplanıyor.

## Referans Kaynaklari

- SignLogger referans ekranlari:
  - `.ai-ops/signlogger-reference/home.png`
  - `.ai-ops/signlogger-reference/features.png`
  - `.ai-ops/signlogger-reference/downloads.png`
  - `.ai-ops/signlogger-reference/docs.png`
- Subgate referans ekranlari:
  - `.ai-ops/subgate-reference/dashboard.png`
  - `.ai-ops/subgate-reference/kullanici-yonetimi.png`
  - `.ai-ops/subgate-reference/kullanici-gruplari.png`
  - `.ai-ops/subgate-reference/log-yonetimi.png`
  - `.ai-ops/subgate-reference/trafik-analizi.png`
  - `.ai-ops/subgate-reference/alarm-tetikleyiciler.png`
  - `.ai-ops/subgate-reference/captive-portal.png`
  - `.ai-ops/subgate-reference/radius-8021x.png`
  - `.ai-ops/subgate-reference/mfa-cok-faktorlu-dogrulama.png`
  - `.ai-ops/subgate-reference/gelismis-raporlama.png`
  - `.ai-ops/subgate-reference/cihaz-yonetimi.png`
  - `.ai-ops/subgate-reference/5651-sayili-kanun.png`
  - `.ai-ops/subgate-reference/sistem-ayarlari.png`
- FortiLogger sinifi:
  - Public kaynaklar repo icinde net bulunmadi.
  - Bu kategori; log toplama, arama, korelasyon, arsiv, alarm ve compliance derinligi olarak ele alinmali.

## Mevcut Durum

Zaten var olan ve artik tekrar inşa edilmemesi gereken alanlar:

- Dashboard, Reports, Traffic Analysis, Alarm Dashboard, Users, UserGroups ve public route yuzeyleri
- 5651 archive scaffolding, RADIUS/MFA plumbing, firewall adapter altyapisi, search modulu
- Portal public flow ve template preview mantigi
- Public content/versioning kataloğu, release notes, downloads, update center ve partner lead capture
- Auth truthfulness ve fail-closed kontrolu sertlestirildi; demo/mock davranisi explicit env ile ayriliyor ve portal config demo tenant flag'i taşıyor.

Bu nedenle kalan is; UI cogaltmak degil, dogru scope, dogru fallback ve versioned content calismasidir.

## Tarihsel Gap Kaydı

| Oncelik | Alan | Mevcut Durum | Risk | Ilk Hamle |
|---|---|---|---|---|
| P0 | Auth truthfulness | Login ekranı explicit demo env'e bağlandı; prod login akışı temiz kalmalı | Başka yüzeylerde demo mesajı geri gelebilir | Login / portal / onboarding ekranlarında demo mesajı regrese etmiyor mu doğrula |
| P0 | Scope hygiene | `cust-1` ve `current-portal-id` gibi hardcoded context degerleri ana admin akışlarından temizleniyor | Kalan modal/form yüzeylerinde tenant/customer/portal karisimi olabilir | Aktif scope'u auth/context API'dan çek ve tüm formlara yay |
| P0 | Silent success fallbacks | Backend devices listesi, PMS vendor config akışları, MFA delivery, WhatsApp send ve signing fail-closed'e çekildi; portal shell artık demo banner gösteriyor, portal utils runtime demo state'ine bağlı demo-labeled response üretiyor ve SystemSettingsPage load hatalarını açık gösteriyor | Network error'larda prod/demoya karışma riski kalabilir | Portal utils, admin helper'lar ve testler demo-only davranışı doğrulasın |
| P0 | 5651 trust chain | Signing path explicit demo mode ile ayrıldı; demo/gerçek provenance etiketi API ve admin UI'da görünür, court evidence package session.json artık `authorize_message`, `group_id` ve `group_policy` de taşıyor | Dev/prod env karışırsa kanıt zinciri zedelenir | Prod testleriyle mock signature'ı engelle ve legacy kayıtları provenance ile backfill et |
| P1 | Public content/versioning | Public yuzey backend-driven; prod'da hardcoded fallback yerine boş durum, demo modunda explicit fallback kullanılıyor | Demo/prod ayrımı bozulursa sahte içerik görünebilir | Knowledge base taksonomisi, release guide ve partner lead telemetry |
| P1 | Log search / correlation | Search, saved views, vendor filtreleme, correlation summary, source visibility, ayarlanabilir korelasyon penceresi ve evidence export var; session modalında ilişkili firewall grup özeti görünüyor | FortiLogger sinifi fark korrelasyon kural derinligi ve daha geniş rule authoring tarafında hâlâ alan var | Query builder, correlation rule depth, evidence timeline ve case stitching |
| P1 | Policy enforcement | User-group seçimi, concurrency cap, ban/whitelist ve location scope captive flow'a baglandi; session listesi group policy/meta ile görünür, policy preview admin'da aktif; adapter authorize path'leri policy notu ve normalize policy data taşıyor | Kotalar, shaping ve vendor-native VLAN uygulaması bazı cihazlarda hâlâ derinleşebilir | Group policy runtime authorize payload'una ve adapter VLAN/shaping akışına bağlanmalı |
| P1 | Portal/template lifecycle | Portal template editor live preview + revision history/restore ile canlı; method field set, success message ve terms URL kaydı eklendi | Yanlis portal context veya publish akışı yüzünden preview/uygulama sapabilir | Gercek portal context ve publish akisi |
| P1 | Device / alarm ops | Cihaz sağlığı ve connection test yüzeyi var; syslog trigger'ları alarm event feed'ine ve delivery history'ye bağlandı, cooldown görünür | Operasyonel görünürlük artıyor ama broader case stitching hâlâ sınırlı | Health ve case stitching |
| P2 | Package / release story | Update/release center, changelog yüzeyi, bundle indirme, public release download route ve arşiv/geçmiş görünürlüğü canlı; yayıncı izi ve audit trail eklendi, release bundle'ları publish sırasında saklanıyor, stored artifact metadata artık API ve admin UI'da görünür, saklanan bundle envanteri ayrı panel olarak listeleniyor, distribution manifest ve activation record da servis ediliyor; activation aynı kanaldaki önceki aktif release'i supersede ediyor, dağıtım telemetry özeti de görünür | Ticari packaging hikayesi artık daha çok rollout orchestration tarafında alan bırakıyor | Release rollout orchestration ve channel promotion automation |
| P2 | Support KB | KB admin yuzeyi canli; taxonomy, etiket, workflow status, related article gezinimi ve backend-ranked arama/öneri eklendi | Destek yukunu azaltma etkisi artik daha iyi; yine de arama kapsamı ve kullanım telemetrisi genişleyebilir | Makale taksonomisi, arama ve içerik öneri derinliği |
| P2 | Demo / trial onboarding | Public ürün CTA'ları, portal login banner'ı ve backend portal config demo tenant flag'i artık açık; trial inquiry provisioning endpoint'i sandbox tenant/customer/location/device/template/license/voucher paketi oluşturuyor, cleanup worker expire olan sandbox'ları decommission ediyor ve renewal/reactivation otomasyonu da eklendi | Satış ve operasyon karışabilir; lifecycle telemetry ve handoff runbook'u hâlâ güçlendirilebilir | Sandbox lifecycle metrics ve operasyon handoff'u |

## Tarihsel Ozet

Hotspot'un ana boslugu artik "ekran eksigi" degil; trust, scope, fallback ve versioned content eksigi.

En kritik 5 başlık:

1. Demo login mesajini ve sahte basari yollarini prod'da kapali tutmak
2. Hardcoded scope/context degerlerini tamamen temizlemek
3. PMS, device, license ve portal fallback'lerini fail-closed halde korumak
4. 5651 signing zincirini prod/dev ayrimi ile sertlestirmek
5. Log correlation, evidence export ve policy enforcement derinligini tamamlamak

## Tarihsel Tavsiye Edilen Ilk Dilim

En yuksek etki / en dusuk risk sirasi:

1. `LoginPage` demo modu mesajini ve auth akisi dogrulugunu duzelt.
2. `UsersPage`, `UserGroupsPage` ve `CaptivePortalPage` icindeki hardcoded scope/context degerlerini kaldir.
3. `devices/test-connection`, `licenses/usage`, `pms` ve `signing` fallback'lerini explicit dev flag'e bagla.
4. Global log correlation ve evidence export'u daha derin hale getir.
5. Sonra shaping/quota/VLAN enforcement ve device ops derinligini arttir.

## Sonraki Parça

Session korelasyonu artık ilişkili firewall grup özetleri ve araştırma penceresi gösteriyor; update/release yüzeyinde de arşiv ve geçmiş görünürlüğü var ve bundle'lar publish sırasında saklanıyor, distribution manifest ve activation record servis ediliyor; aynı kanaldaki önceki release rollout sırasında supersede ediliyor ve dağıtım telemetry özeti de görünür; Support KB de backend-ranked arama ve öneri yüzeyi ile güçlendi. Demo/trial tarafında backend demo tenant flag'i de taşınıyor, trial provisioning, cleanup ve renewal/reactivation otomasyonu var; sonraki log/case ve package slice'ları bu temel üzerinden daha geniş rule authoring, bundle enrichment ve rollout automation'a geçmeli.
