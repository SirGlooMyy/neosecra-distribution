# Firewall Adapter Mimarisi

## Amaç
Vendor bağımlılığını core logic'ten ayırmak.

## Ortak Interface
```python
class FirewallAdapter:
    async def test_connection(self) -> AdapterResult: ...
    async def get_device_info(self) -> dict: ...
    async def get_interfaces(self) -> list[dict]: ...
    async def get_captive_portal_config(self) -> dict: ...
    async def get_active_sessions(self) -> list[dict]: ...
    async def get_user_ip_mac_mapping(self) -> list[dict]: ...
    async def authorize_guest(self, session) -> AdapterResult: ...
    async def revoke_guest(self, session) -> AdapterResult: ...
    async def parse_syslog_event(self, raw_event) -> dict: ...
```

## Implementasyonlar
- FortiGateAdapter: MVP ana adapter.
- PaloAltoAdapter: iskelet + ikinci faz.
- MikroTikAdapter: sonraki faz.
- PfSenseAdapter: sonraki faz.
- OpenNDSAdapter: vendor bağımsız gateway fazı.

Aruba, Ruijie ve TP-Link Omada gibi switch/AP/controller yüzeyleri bu
ürünün cihaz kayıt alanına dahil değildir. Hotspot yalnızca captive portal
ile ilişkili firewall/gateway entegrasyonlarını kabul eder; port, NAC ve
802.1X yönetimi yapmaz.

## Kritik Not
FortiGate özel API endpointleri `devices` veya `sessions` modülüne gömülmeyecek. Sadece adapter içinde olacak.
