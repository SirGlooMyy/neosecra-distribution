# Domain Model

## Hiyerarşi
```text
Super Admin
  -> Partner / Reseller
    -> Customer
      -> Location
        -> Device / SSID / Portal / Log Profile
```

## Ana Entity Grupları

### Tenant / Organizasyon
- tenants
- partners
- customers
- locations
- users
- roles
- permissions

### Device / Integration
- devices
- device_credentials
- device_integrations
- firewall_adapter_configs
- radius_clients
- syslog_sources

### Portal
- portal_templates
- portal_theme_settings
- portal_pages
- portal_terms
- portal_languages

### Identity/Auth
- guest_identities
- otp_requests
- tc_validations
- voucher_batches
- vouchers

### Sessions / Logs
- guest_sessions
- guest_devices
- radius_events
- syslog_events
- traffic_events
- session_correlations
- nat_mappings

### 5651 Archive
- log_archives
- archive_hashes
- archive_exports
- report_jobs

### License
- licenses
- license_limits
- sms_packages
- usage_counters

### Operations
- audit_logs
- worker_jobs
- site_bridges
- system_settings
