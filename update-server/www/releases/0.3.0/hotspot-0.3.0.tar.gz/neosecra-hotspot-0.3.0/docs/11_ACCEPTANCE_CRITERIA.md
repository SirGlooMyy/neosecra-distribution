# Sprint 00 Acceptance Criteria

| Alan | Kabul Kriteri |
|---|---|
| Repo yapısı | Backend, frontend, portal, site-bridge, infra, docs, prompts ayrılmış |
| Mimari kararlar | DECISIONS.md içinde kayıtlı |
| Agent/Connector ayrımı | Platform worker ve SaaS Site Bridge net ayrılmış |
| Modüller | Backend modules klasörü domainlere ayrılmış |
| Adapter | FirewallAdapter base interface mevcut |
| Vendor | FortiGate ve Palo Alto adapter skeleton mevcut |
| Portal | Template engine skeleton mevcut |
| 5651 | Archive/hash service skeleton mevcut |
| RADIUS | FreeRADIUS entegrasyon notu mevcut |
| Syslog | Collector tasarım dokümanı mevcut |
| Güvenlik | RBAC/tenant/audit kuralları dokümante |
| Deployment | On-prem/SaaS/offline modları dokümante |
| Kod ajanları | CLAUDE.md, Cursor rules, prompts mevcut |
