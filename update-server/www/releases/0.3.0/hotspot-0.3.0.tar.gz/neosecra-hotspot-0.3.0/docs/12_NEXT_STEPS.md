# Sonraki Adımlar (Sprint 03 Hazırlığı)

## Tamamlanan Son Sprint İşleri (Sprint 01 & 02)
1. **Admin Dashboard Arayüz Temeli**: React, TypeScript, Tailwind ve Lucide ikonları ile durum bazlı menü yönetimi ve KPI kartları tamamlandı.
2. **Captive Portal Arayüz Temeli**: Türkçe karşılama ekranları, SMS/TC/Voucher giriş seçenekleri, KVKK kontrol mekanizması ve durum/hata bildirimleri tamamlandı.
3. **Backend Altyapısı**: FastAPI, SQLAlchemy async modeller, Pydantic şemaları ve API rotaları oluşturularak test edildi.
4. **Mock Servis & Doğrulayıcılar**: TC kimlik no algoritmik kontrolü, GSM normalizasyonu ve mock voucher redeem özellikleri yazıldı.
5. **Test Paketi**: 9 adet birim ve entegrasyon testinin tamamı yeşillendirildi.
6. **Git Temizliği**: `__pycache__` ve `.venv` klasörlerinin git dışı bırakılması için `.gitignore` güncellendi ve index temizlendi.

## Sıradaki Sprint (Sprint 03) Hemen Yapılacaklar
1. **Alembic Veritabanı Migrasyonu**: 
   * `backend/` üzerinde Alembic migrasyon dosyalarını (`alembic revision --autogenerate`) üreterek PostgreSQL üzerinde fiziksel tabloları oluştur.
2. **Veri Tabanı Seeding (Geliştirici Verileri)**:
   * Mevcut `seed.py` dosyasını yeni `app/models/` yollarına göre güncelleyerek veritabanını test verileriyle doldur.
3. **Frontend & Backend Entegrasyonu**:
   * Portal ekranındaki form alanlarının (SMS gönderimi, TC kimlik doğrulaması, bilet doğrulama) backend endpoint'lerine (`/api/v1/portal/auth/...`) bağlanması.
   * Admin dashboard özet ekranının `/api/v1/portal/dashboard/summary` endpoint'ine bağlanması.
4. **Gerçek Zamanlı Oturum Yönetimi**:
   * Guest Session oluşturulması ve firewall adapter'larının (`authorize_guest`) tetiklenerek ağ izni verilmesi akışının gerçeklenmesi.
5. **5651 Uyumlu Arşivleme (Archive Worker)**:
   * Arka planda çalışacak Celery taskları ile günlük session loglarının toplanması, sha256 hash zinciri oluşturularak imzalanması ve MinIO/S3 depolama katmanına yüklenmesi.

