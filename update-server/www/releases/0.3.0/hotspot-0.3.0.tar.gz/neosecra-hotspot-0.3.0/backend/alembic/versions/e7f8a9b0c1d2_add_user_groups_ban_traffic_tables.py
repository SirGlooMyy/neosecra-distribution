"""add user_groups ban traffic tables

Revision ID: e7f8a9b0c1d2
Revises: 83647f94ec81
Create Date: 2026-07-11 15:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = 'e7f8a9b0c1d2'
down_revision: Union[str, None] = '83647f94ec81'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- user_groups ---
    op.create_table('user_groups',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('location_id', sa.UUID(), nullable=True),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('bandwidth_up', sa.BigInteger(), nullable=True, comment='Upload speed limit in kbps'),
        sa.Column('bandwidth_down', sa.BigInteger(), nullable=True, comment='Download speed limit in kbps'),
        sa.Column('session_timeout', sa.Integer(), nullable=True, comment='Max session duration in minutes'),
        sa.Column('idle_timeout', sa.Integer(), nullable=True, comment='Idle timeout in minutes'),
        sa.Column('daily_quota', sa.BigInteger(), nullable=True, comment='Daily data quota in MB'),
        sa.Column('weekly_quota', sa.BigInteger(), nullable=True, comment='Weekly data quota in MB'),
        sa.Column('monthly_quota', sa.BigInteger(), nullable=True, comment='Monthly data quota in MB'),
        sa.Column('hourly_quota', sa.BigInteger(), nullable=True, comment='Hourly data quota in MB'),
        sa.Column('max_sessions', sa.Integer(), nullable=False, server_default='1', comment='Max concurrent sessions per user'),
        sa.Column('access_start', sa.DateTime(timezone=True), nullable=True, comment='Allowed access start time'),
        sa.Column('access_end', sa.DateTime(timezone=True), nullable=True, comment='Allowed access end time'),
        sa.Column('vlan_id', sa.Integer(), nullable=True, comment='VLAN ID for this group'),
        sa.Column('is_default', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('priority', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['location_id'], ['locations.id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_user_groups_customer_id'), 'user_groups', ['customer_id'], unique=False)

    # --- ban_rules ---
    op.create_table('ban_rules',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('location_id', sa.UUID(), nullable=True),
        sa.Column('mac_address', sa.String(32), nullable=True, index=True),
        sa.Column('phone', sa.String(20), nullable=True, index=True),
        sa.Column('ip_address', sa.String(64), nullable=True, index=True),
        sa.Column('reason', sa.Text(), nullable=True),
        sa.Column('banned_by', sa.UUID(), nullable=True),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=True, index=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['location_id'], ['locations.id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('id'),
    )

    # --- whitelist_entries ---
    op.create_table('whitelist_entries',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('location_id', sa.UUID(), nullable=True),
        sa.Column('mac_address', sa.String(32), nullable=True, index=True),
        sa.Column('phone', sa.String(20), nullable=True, index=True),
        sa.Column('description', sa.String(500), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['location_id'], ['locations.id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('id'),
    )

    # --- traffic_hourly ---
    op.create_table('traffic_hourly',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('location_id', sa.UUID(), nullable=False),
        sa.Column('hour', sa.DateTime(timezone=True), nullable=False, index=True),
        sa.Column('session_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('bytes_in', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('bytes_out', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('active_users', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('new_users', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['location_id'], ['locations.id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('id'),
    )

    # --- traffic_daily ---
    op.create_table('traffic_daily',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('location_id', sa.UUID(), nullable=True),
        sa.Column('date', sa.DateTime(timezone=True), nullable=False, index=True),
        sa.Column('session_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('bytes_in', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('bytes_out', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('peak_concurrent', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('avg_session_duration_min', sa.Float(), nullable=True),
        sa.Column('unique_macs', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('auth_methods', postgresql.JSONB(), nullable=True, comment='JSON: {sms: 10, voucher: 5, ...}'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['location_id'], ['locations.id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('id'),
    )

    # --- top_talkers ---
    op.create_table('top_talkers',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('location_id', sa.UUID(), nullable=True),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False, index=True),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('mac', sa.String(32), nullable=False),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('bytes_in', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('bytes_out', sa.BigInteger(), nullable=False, server_default='0'),
        sa.Column('session_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('rank', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['location_id'], ['locations.id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('id'),
    )

    # --- Add group_id to guest_sessions ---
    op.add_column('guest_sessions',
        sa.Column('group_id', sa.UUID(), nullable=True)
    )
    op.create_foreign_key(
        'fk_guest_sessions_group_id_user_groups',
        'guest_sessions', 'user_groups',
        ['group_id'], ['id'],
        ondelete='SET NULL'
    )


def downgrade() -> None:
    op.drop_constraint('fk_guest_sessions_group_id_user_groups', 'guest_sessions', type_='foreignkey')
    op.drop_column('guest_sessions', 'group_id')
    op.drop_table('top_talkers')
    op.drop_table('traffic_daily')
    op.drop_table('traffic_hourly')
    op.drop_table('whitelist_entries')
    op.drop_table('ban_rules')
    op.drop_table('user_groups')
