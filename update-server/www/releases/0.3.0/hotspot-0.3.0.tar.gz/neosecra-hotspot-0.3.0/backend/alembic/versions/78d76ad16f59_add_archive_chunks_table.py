"""add archive_chunks table for hash chain + local cert CAdES signing

Revision ID: 78d76ad16f59
Revises: 78d76ad16f58
Create Date: 2026-07-27 02:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = '78d76ad16f59'
down_revision: Union[str, None] = '78d76ad16f58'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'archive_chunks',
        sa.Column('id', sa.Uuid(), nullable=False),
        sa.Column('customer_id', sa.Uuid(), nullable=False, index=True),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False, index=True),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False, index=True),
        sa.Column('log_count', sa.Integer(), nullable=False, server_default=sa.text('0')),
        sa.Column('content_hash', sa.String(length=64), nullable=False, index=True),
        sa.Column('curr_hash', sa.String(length=64), nullable=False, index=True),
        sa.Column('prev_hash', sa.String(length=64), nullable=False),
        sa.Column('intermediate_hashes', postgresql.JSONB(), nullable=False, server_default=sa.text("'[]'::jsonb")),
        sa.Column('signature_value', sa.Text(), nullable=True),
        sa.Column('signature_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('certificate_serial', sa.String(length=100), nullable=True),
        sa.Column('sign_method', sa.String(length=20), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=False, server_default=sa.text("'pending'"), index=True),
        sa.Column('minio_object_key', sa.String(length=500), nullable=True),
        sa.Column('content_size', sa.BigInteger(), nullable=False, server_default=sa.text('0')),
        sa.Column('meta', postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_archive_chunks_customer_period', 'archive_chunks', ['customer_id', sa.text('period_start DESC')])
    op.create_index('ix_archive_chunks_customer_created', 'archive_chunks', ['customer_id', sa.text('created_at DESC')])


def downgrade() -> None:
    op.drop_index('ix_archive_chunks_customer_created', table_name='archive_chunks')
    op.drop_index('ix_archive_chunks_customer_period', table_name='archive_chunks')
    op.drop_table('archive_chunks')
