"""add FortiGate authorization lifecycle fields to guest_sessions

Revision ID: b7c8d9e0f1a2
Revises: 78d76ad16f58
Create Date: 2026-07-18 03:15:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = 'b7c8d9e0f1a2'
down_revision: Union[str, None] = '78d76ad16f58'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # FortiGate authorization lifecycle columns
    op.add_column('guest_sessions', sa.Column('authorization_status', sa.String(length=20),
                  server_default=sa.text("'pending'"), nullable=False))
    op.add_column('guest_sessions', sa.Column('authorized_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('guest_sessions', sa.Column('authorization_attempts', sa.Integer(),
                  server_default=sa.text('0'), nullable=False))
    op.add_column('guest_sessions', sa.Column('authorization_error_code', sa.String(length=100), nullable=True))
    op.add_column('guest_sessions', sa.Column('authorization_error_message', sa.Text(), nullable=True))
    op.add_column('guest_sessions', sa.Column('external_session_id', sa.String(length=255), nullable=True))
    op.add_column('guest_sessions', sa.Column('external_reference', sa.String(length=255), nullable=True))
    op.add_column('guest_sessions', sa.Column('revoked_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('guest_sessions', sa.Column('revoke_attempts', sa.Integer(),
                  server_default=sa.text('0'), nullable=False))
    op.add_column('guest_sessions', sa.Column('last_device_sync_at', sa.DateTime(timezone=True), nullable=True))

    # Indexes for queried fields
    op.create_index(op.f('ix_guest_sessions_authorization_status'),
                    'guest_sessions', ['authorization_status'], unique=False)
    op.create_index(op.f('ix_guest_sessions_external_session_id'),
                    'guest_sessions', ['external_session_id'], unique=False)


def downgrade() -> None:
    # Drop indexes first
    op.drop_index(op.f('ix_guest_sessions_external_session_id'),
                  table_name='guest_sessions')
    op.drop_index(op.f('ix_guest_sessions_authorization_status'),
                  table_name='guest_sessions')

    # Drop columns (reverse order of upgrade)
    op.drop_column('guest_sessions', 'last_device_sync_at')
    op.drop_column('guest_sessions', 'revoke_attempts')
    op.drop_column('guest_sessions', 'revoked_at')
    op.drop_column('guest_sessions', 'external_reference')
    op.drop_column('guest_sessions', 'external_session_id')
    op.drop_column('guest_sessions', 'authorization_error_message')
    op.drop_column('guest_sessions', 'authorization_error_code')
    op.drop_column('guest_sessions', 'authorization_attempts')
    op.drop_column('guest_sessions', 'authorized_at')
    op.drop_column('guest_sessions', 'authorization_status')
