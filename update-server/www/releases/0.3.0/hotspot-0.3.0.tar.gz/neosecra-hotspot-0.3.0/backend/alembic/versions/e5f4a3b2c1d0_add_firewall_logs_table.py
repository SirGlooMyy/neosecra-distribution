"""add firewall_logs table

Revision ID: e5f4a3b2c1d0
Revises: b7c8d9e0f1a2
Create Date: 2026-07-27 20:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB, UUID

# revision identifiers, used by Alembic.
revision: str = "e5f4a3b2c1d0"
down_revision: Union[str, None] = "b7c8d9e0f1a2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "firewall_logs",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", UUID(as_uuid=True), nullable=False, index=True),
        sa.Column("customer_id", UUID(as_uuid=True), sa.ForeignKey("customers.id", ondelete="RESTRICT"), nullable=False, index=True),
        sa.Column("device_id", UUID(as_uuid=True), nullable=True, index=True),
        sa.Column("received_at", sa.DateTime(timezone=True), nullable=False, index=True, server_default=sa.text("now()")),
        sa.Column("event_time", sa.DateTime(timezone=True), nullable=True, index=True),
        sa.Column("vendor", sa.String(50), nullable=False, index=True, server_default=sa.text("'fortigate'")),
        sa.Column("log_type", sa.String(50), nullable=False, index=True),
        sa.Column("log_subtype", sa.String(50), nullable=True),
        sa.Column("severity", sa.String(20), nullable=False, index=True),
        sa.Column("action", sa.String(50), nullable=True, index=True),
        sa.Column("src_ip", sa.String(64), nullable=True, index=True),
        sa.Column("dst_ip", sa.String(64), nullable=True, index=True),
        sa.Column("src_port", sa.Integer(), nullable=True),
        sa.Column("dst_port", sa.Integer(), nullable=True),
        sa.Column("proto", sa.String(20), nullable=True),
        sa.Column("service", sa.String(100), nullable=True),
        sa.Column("user", sa.String(255), nullable=True, index=True),
        sa.Column("policyid", sa.Integer(), nullable=True),
        sa.Column("duration", sa.Integer(), nullable=True),
        sa.Column("sentbyte", sa.BigInteger(), nullable=True),
        sa.Column("rcvdbyte", sa.BigInteger(), nullable=True),
        sa.Column("session_id", sa.String(100), nullable=True, index=True),
        sa.Column("raw_syslog", sa.Text(), nullable=False),
        sa.Column("parsed_fields", JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
    )

    op.create_index("ix_firewall_logs_tenant_received", "firewall_logs", ["tenant_id", sa.text("received_at DESC")])
    op.create_index("ix_firewall_logs_tenant_event", "firewall_logs", ["tenant_id", sa.text("event_time DESC")])


def downgrade() -> None:
    op.drop_index("ix_firewall_logs_tenant_event", table_name="firewall_logs")
    op.drop_index("ix_firewall_logs_tenant_received", table_name="firewall_logs")
    op.drop_table("firewall_logs")
