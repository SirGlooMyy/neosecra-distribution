"""add public content and inquiry tables

Revision ID: f1a2b3c4d5e6
Revises: 83647f94ec81
Create Date: 2026-07-13 02:10:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "f1a2b3c4d5e6"
down_revision: Union[str, None] = "83647f94ec81"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "public_assets",
        sa.Column("section", sa.String(length=50), nullable=False),
        sa.Column("slug", sa.String(length=120), nullable=False),
        sa.Column("version", sa.String(length=50), nullable=False),
        sa.Column("title", sa.String(length=255), nullable=False),
        sa.Column("category", sa.String(length=120), nullable=True),
        sa.Column("summary", sa.String(length=500), nullable=True),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("asset_url", sa.String(length=500), nullable=True),
        sa.Column("checksum", sa.String(length=64), nullable=True),
        sa.Column("file_size_kb", sa.Integer(), nullable=True),
        sa.Column("is_current", sa.Boolean(), nullable=False),
        sa.Column("sort_order", sa.Integer(), nullable=False),
        sa.Column("meta", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.CheckConstraint("section <> ''", name="ck_public_assets_section_not_blank"),
        sa.CheckConstraint("slug <> ''", name="ck_public_assets_slug_not_blank"),
        sa.CheckConstraint("version <> ''", name="ck_public_assets_version_not_blank"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("section", "slug", "version", name="uq_public_assets_section_slug_version"),
    )
    op.create_index(op.f("ix_public_assets_category"), "public_assets", ["category"], unique=False)
    op.create_index(op.f("ix_public_assets_is_current"), "public_assets", ["is_current"], unique=False)
    op.create_index(op.f("ix_public_assets_section"), "public_assets", ["section"], unique=False)
    op.create_index(op.f("ix_public_assets_slug"), "public_assets", ["slug"], unique=False)
    op.create_index(op.f("ix_public_assets_sort_order"), "public_assets", ["sort_order"], unique=False)
    op.create_index(op.f("ix_public_assets_version"), "public_assets", ["version"], unique=False)

    op.create_table(
        "public_inquiries",
        sa.Column("inquiry_type", sa.String(length=30), nullable=False),
        sa.Column("source_tab", sa.String(length=30), nullable=True),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("email", sa.String(length=255), nullable=False),
        sa.Column("phone", sa.String(length=40), nullable=True),
        sa.Column("company", sa.String(length=255), nullable=False),
        sa.Column("role", sa.String(length=100), nullable=True),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("status", sa.String(length=30), nullable=False),
        sa.Column("meta", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.CheckConstraint("inquiry_type <> ''", name="ck_public_inquiries_type_not_blank"),
        sa.CheckConstraint("name <> ''", name="ck_public_inquiries_name_not_blank"),
        sa.CheckConstraint("email <> ''", name="ck_public_inquiries_email_not_blank"),
        sa.CheckConstraint("company <> ''", name="ck_public_inquiries_company_not_blank"),
        sa.CheckConstraint("message <> ''", name="ck_public_inquiries_message_not_blank"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_public_inquiries_email"), "public_inquiries", ["email"], unique=False)
    op.create_index(op.f("ix_public_inquiries_inquiry_type"), "public_inquiries", ["inquiry_type"], unique=False)
    op.create_index(op.f("ix_public_inquiries_source_tab"), "public_inquiries", ["source_tab"], unique=False)
    op.create_index(op.f("ix_public_inquiries_status"), "public_inquiries", ["status"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_public_inquiries_status"), table_name="public_inquiries")
    op.drop_index(op.f("ix_public_inquiries_source_tab"), table_name="public_inquiries")
    op.drop_index(op.f("ix_public_inquiries_inquiry_type"), table_name="public_inquiries")
    op.drop_index(op.f("ix_public_inquiries_email"), table_name="public_inquiries")
    op.drop_table("public_inquiries")

    op.drop_index(op.f("ix_public_assets_version"), table_name="public_assets")
    op.drop_index(op.f("ix_public_assets_sort_order"), table_name="public_assets")
    op.drop_index(op.f("ix_public_assets_slug"), table_name="public_assets")
    op.drop_index(op.f("ix_public_assets_section"), table_name="public_assets")
    op.drop_index(op.f("ix_public_assets_is_current"), table_name="public_assets")
    op.drop_index(op.f("ix_public_assets_category"), table_name="public_assets")
    op.drop_table("public_assets")

