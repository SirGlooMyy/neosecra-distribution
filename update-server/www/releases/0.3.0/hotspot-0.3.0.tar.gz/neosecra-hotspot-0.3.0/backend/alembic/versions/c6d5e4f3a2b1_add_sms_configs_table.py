"""add sms_configs table

Revision ID: c6d5e4f3a2b1
Revises: b5c4d3e2f1a0
Create Date: 2026-07-12 02:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'c6d5e4f3a2b1'
down_revision: Union[str, None] = 'b5c4d3e2f1a0'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('sms_configs',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=True),
        sa.Column('provider', sa.String(length=50), server_default='console', nullable=False),
        sa.Column('username', sa.String(length=255), nullable=True),
        sa.Column('password_encrypted', sa.String(length=500), nullable=True),
        sa.Column('api_key_encrypted', sa.String(length=500), nullable=True),
        sa.Column('sender', sa.String(length=100), nullable=True),
        sa.Column('http_url', sa.String(length=500), nullable=True),
        sa.Column('http_token_encrypted', sa.String(length=500), nullable=True),
        sa.Column('http_template', sa.String(length=1000), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_sms_configs_customer_id'), 'sms_configs', ['customer_id'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_sms_configs_customer_id'), table_name='sms_configs')
    op.drop_table('sms_configs')
