"""merge all heads into single chain

Revision ID: f56d1701d0b3
Revises: a2b3c4d5e6f7, a3b4c5d6e7f8, c6d5e4f3a2b1, c7d8e9f0a1b2
Create Date: 2026-07-16 14:37:59.589658

"""
from typing import Sequence, Union



# revision identifiers, used by Alembic.
revision: str = 'f56d1701d0b3'
down_revision: Union[str, None] = ('a2b3c4d5e6f7', 'a3b4c5d6e7f8', 'c6d5e4f3a2b1', 'c7d8e9f0a1b2')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
