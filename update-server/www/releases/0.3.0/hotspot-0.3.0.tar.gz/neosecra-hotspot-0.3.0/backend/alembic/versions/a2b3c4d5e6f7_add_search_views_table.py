"""add search_views table

Revision ID: a2b3c4d5e6f7
Revises: f1a2b3c4d5e6
Create Date: 2026-07-13 02:35:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "a2b3c4d5e6f7"
down_revision: Union[str, None] = "f1a2b3c4d5e6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "search_views",
        sa.Column("created_by_user_id", sa.UUID(), nullable=False),
        sa.Column("surface", sa.String(length=50), nullable=False),
        sa.Column("title", sa.String(length=255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("filters", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("is_shared", sa.Boolean(), nullable=False),
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.CheckConstraint("surface <> ''", name="ck_search_views_surface_not_blank"),
        sa.CheckConstraint("title <> ''", name="ck_search_views_title_not_blank"),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["created_by_user_id"], ["users.id"], ondelete="CASCADE"),
    )
    op.create_index(op.f("ix_search_views_created_by_user_id"), "search_views", ["created_by_user_id"], unique=False)
    op.create_index(op.f("ix_search_views_is_shared"), "search_views", ["is_shared"], unique=False)
    op.create_index(op.f("ix_search_views_surface"), "search_views", ["surface"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_search_views_surface"), table_name="search_views")
    op.drop_index(op.f("ix_search_views_is_shared"), table_name="search_views")
    op.drop_index(op.f("ix_search_views_created_by_user_id"), table_name="search_views")
    op.drop_table("search_views")

