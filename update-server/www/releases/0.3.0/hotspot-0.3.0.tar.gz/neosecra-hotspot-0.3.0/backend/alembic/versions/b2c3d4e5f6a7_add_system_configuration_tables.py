"""add system email and white-label configuration tables

Revision ID: b2c3d4e5f6a7
Revises: b1c2d3e4f5a6
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "b2c3d4e5f6a7"
down_revision: Union[str, None] = "b1c2d3e4f5a6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # These models were present in the API before their tables were included
    # in the migration chain. Keep both platform defaults (NULL customer) and
    # customer overrides supported by the service layer.
    op.create_table(
        "email_configs",
        sa.Column("customer_id", sa.UUID(), nullable=True),
        sa.Column("smtp_host", sa.String(length=255), nullable=False),
        sa.Column("smtp_port", sa.Integer(), nullable=False, server_default="587"),
        sa.Column("smtp_username", sa.String(length=255), nullable=True),
        sa.Column("smtp_password_encrypted", sa.String(length=500), nullable=True),
        sa.Column("smtp_use_tls", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("smtp_use_ssl", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("from_address", sa.String(length=255), nullable=False),
        sa.Column("from_name", sa.String(length=255), nullable=True),
        sa.Column("is_verified", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["customer_id"], ["customers.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_email_configs_customer_id", "email_configs", ["customer_id"], unique=False)

    op.create_table(
        "whitelabel_configs",
        sa.Column("tenant_id", sa.UUID(), nullable=True),
        sa.Column("customer_id", sa.UUID(), nullable=True),
        sa.Column("brand_name", sa.String(length=255), nullable=True),
        sa.Column("brand_logo_url", sa.String(length=500), nullable=True),
        sa.Column("primary_color", sa.String(length=20), nullable=True),
        sa.Column("secondary_color", sa.String(length=20), nullable=True),
        sa.Column("accent_color", sa.String(length=20), nullable=True),
        sa.Column("custom_domain", sa.String(length=255), nullable=True),
        sa.Column("custom_favicon_url", sa.String(length=500), nullable=True),
        sa.Column("support_email", sa.String(length=255), nullable=True),
        sa.Column("support_phone", sa.String(length=50), nullable=True),
        sa.Column("footer_text", sa.String(length=500), nullable=True),
        sa.Column("terms_url", sa.String(length=500), nullable=True),
        sa.Column("privacy_url", sa.String(length=500), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["customer_id"], ["customers.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_whitelabel_configs_tenant_id", "whitelabel_configs", ["tenant_id"], unique=False)
    op.create_index("ix_whitelabel_configs_customer_id", "whitelabel_configs", ["customer_id"], unique=False)


def downgrade() -> None:
    op.drop_index("ix_whitelabel_configs_customer_id", table_name="whitelabel_configs")
    op.drop_index("ix_whitelabel_configs_tenant_id", table_name="whitelabel_configs")
    op.drop_table("whitelabel_configs")
    op.drop_index("ix_email_configs_customer_id", table_name="email_configs")
    op.drop_table("email_configs")
