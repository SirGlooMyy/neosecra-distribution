"""add radius_challenge vpn_mfa_user tables for VPN MFA Access-Challenge

Revision ID: f0e1d2c3b4a5
Revises: a1b2c3d4e5f6
Create Date: 2026-07-11 17:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = 'f0e1d2c3b4a5'
down_revision: Union[str, None] = 'a1b2c3d4e5f6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # --- vpn_mfa_users ---
    op.create_table('vpn_mfa_users',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('username', sa.String(255), nullable=False),
        sa.Column('mfa_method', sa.String(20), nullable=False),
        sa.Column('secret_encrypted', sa.String(512), nullable=True),
        sa.Column('phone', sa.String(64), nullable=True),
        sa.Column('email', sa.String(255), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_vpn_mfa_users_customer_id'), 'vpn_mfa_users', ['customer_id'], unique=False)
    op.create_index(op.f('ix_vpn_mfa_users_username'), 'vpn_mfa_users', ['username'], unique=False)

    # --- radius_challenges ---
    op.create_table('radius_challenges',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('username', sa.String(255), nullable=False),
        sa.Column('nas_ip', sa.String(64), nullable=True),
        sa.Column('state', sa.String(255), nullable=False),
        sa.Column('mfa_method', sa.String(20), nullable=False),
        sa.Column('code_hash', sa.String(255), nullable=True),
        sa.Column('session_token', sa.String(255), nullable=True),
        sa.Column('verified', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('consumed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('attempt_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_radius_challenges_customer_id'), 'radius_challenges', ['customer_id'], unique=False)
    op.create_index(op.f('ix_radius_challenges_username'), 'radius_challenges', ['username'], unique=False)
    op.create_index(op.f('ix_radius_challenges_state'), 'radius_challenges', ['state'], unique=True)


def downgrade() -> None:
    op.drop_table('radius_challenges')
    op.drop_table('vpn_mfa_users')
