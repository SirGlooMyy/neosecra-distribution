"""add firewall_logs search_vector tsvector GIN index + composite indexes

Revision ID: f7a8b9c0d1e2
Revises: e5f4a3b2c1d0
Create Date: 2026-07-27 22:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID

revision: str = "f7a8b9c0d1e2"
down_revision: Union[str, None] = "e5f4a3b2c1d0"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        """
        ALTER TABLE firewall_logs ADD COLUMN search_vector tsvector
        GENERATED ALWAYS AS (
            to_tsvector('english',
                coalesce(raw_syslog, '') || ' ' ||
                coalesce(src_ip, '') || ' ' ||
                coalesce(dst_ip, '') || ' ' ||
                coalesce("user", '')
            )
        ) STORED
        """
    )
    op.create_index(
        "ix_firewall_logs_search_gin",
        "firewall_logs",
        [sa.text("search_vector")],
        postgresql_using="gin",
    )
    op.create_index(
        "ix_firewall_logs_tenant_event_time",
        "firewall_logs",
        ["tenant_id", sa.text("event_time DESC")],
    )
    op.create_index(
        "ix_firewall_logs_session_id",
        "firewall_logs",
        ["session_id"],
        postgresql_where=sa.text("session_id IS NOT NULL"),
    )
    op.create_index(
        "ix_firewall_logs_src_dst_ip",
        "firewall_logs",
        ["tenant_id", "src_ip", "dst_ip"],
    )


def downgrade() -> None:
    op.drop_index("ix_firewall_logs_src_dst_ip", table_name="firewall_logs")
    op.drop_index("ix_firewall_logs_session_id", table_name="firewall_logs")
    op.drop_index("ix_firewall_logs_tenant_event_time", table_name="firewall_logs")
    op.drop_index("ix_firewall_logs_search_gin", table_name="firewall_logs")
    op.drop_column("firewall_logs", "search_vector")
