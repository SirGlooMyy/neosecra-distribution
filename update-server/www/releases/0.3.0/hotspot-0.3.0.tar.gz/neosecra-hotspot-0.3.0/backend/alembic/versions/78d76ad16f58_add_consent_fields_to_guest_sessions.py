"""add consent fields to guest_sessions

Revision ID: 78d76ad16f58
Revises: a4b5c6d7e8f0
Create Date: 2026-07-18 02:48:33.462771
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = '78d76ad16f58'
down_revision: Union[str, None] = 'a4b5c6d7e8f0'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('guest_sessions', sa.Column('terms_accepted', sa.Boolean(), server_default=sa.text('false'), nullable=False))
    op.add_column('guest_sessions', sa.Column('terms_accepted_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('guest_sessions', sa.Column('privacy_accepted', sa.Boolean(), server_default=sa.text('false'), nullable=False))
    op.add_column('guest_sessions', sa.Column('privacy_accepted_at', sa.DateTime(timezone=True), nullable=True))
    op.add_column('guest_sessions', sa.Column('terms_version', sa.String(length=20), nullable=True))
    op.add_column('guest_sessions', sa.Column('privacy_version', sa.String(length=20), nullable=True))
    op.add_column('guest_sessions', sa.Column('consent_ip', sa.String(length=64), nullable=True))
    op.add_column('guest_sessions', sa.Column('consent_user_agent', sa.Text(), nullable=True))


def downgrade() -> None:
    op.drop_column('guest_sessions', 'consent_user_agent')
    op.drop_column('guest_sessions', 'consent_ip')
    op.drop_column('guest_sessions', 'privacy_version')
    op.drop_column('guest_sessions', 'terms_version')
    op.drop_column('guest_sessions', 'privacy_accepted_at')
    op.drop_column('guest_sessions', 'privacy_accepted')
    op.drop_column('guest_sessions', 'terms_accepted_at')
    op.drop_column('guest_sessions', 'terms_accepted')
