"""Async Alembic environment.

Runs migrations against the same async engine config used by the app.
All domain models are imported so autogenerate sees every table.
"""
import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

from app.core.config import settings
from app.core.database import Base

# Register all models on Base.metadata (import side-effect).
import app.modules.tenants.models  # noqa: F401,E402
import app.modules.partners.models  # noqa: F401,E402
import app.modules.customers.models  # noqa: F401,E402
import app.modules.locations.models  # noqa: F401,E402
import app.modules.audit.models  # noqa: F401,E402
import app.modules.auth.models  # noqa: F401,E402
import app.modules.devices.models  # noqa: F401,E402
import app.modules.portal.models  # noqa: F401,E402
import app.modules.sms.models  # noqa: F401,E402
import app.modules.vouchers.models  # noqa: F401,E402
import app.modules.identity.models  # noqa: F401,E402
import app.modules.sessions.models  # noqa: F401,E402
import app.modules.logs_5651.models  # noqa: F401,E402
import app.modules.licensing.models  # noqa: F401,E402
import app.modules.radius.models  # noqa: F401,E402
import app.modules.syslog.models  # noqa: F401,E402
import app.modules.whatsapp.models  # noqa: F401,E402
import app.modules.meeting.models  # noqa: F401,E402
import app.modules.foreigner.models  # noqa: F401,E402
import app.modules.local_auth.models  # noqa: F401,E402
import app.modules.mfa.models  # noqa: F401,E402
import app.modules.reports.models  # noqa: F401,E402
import app.modules.system.models  # noqa: F401,E402
import app.modules.archive.models  # noqa: F401,E402
import app.modules.firewall_adapters.models  # noqa: F401,E402
import app.modules.pms.models  # noqa: F401,E402
import app.modules.site_bridge.models  # noqa: F401,E402
import app.modules.workers.models  # noqa: F401,E402
import app.modules.user_groups.models  # noqa: F401,E402
import app.modules.ban.models  # noqa: F401,E402
import app.modules.traffic.models  # noqa: F401,E402
import app.modules.alarm.models  # noqa: F401,E402
import app.modules.public_content.models  # noqa: F401,E402
import app.modules.search.models  # noqa: F401,E402


config = context.config
config.set_main_option("sqlalchemy.url", settings.DATABASE_URL)

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=config.get_main_option("sqlalchemy.url"),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(connection=connection, target_metadata=target_metadata)
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await connectable.dispose()


def run_migrations_online() -> None:
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
