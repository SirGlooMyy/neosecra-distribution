"""persist verifier-side MFA challenge state.

Revision ID: b1c2d3e4f5a6
Revises: a0b1c2d3e4f5
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "b1c2d3e4f5a6"
down_revision: Union[str, None] = "a0b1c2d3e4f5"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("mfa_sessions", sa.Column("code_hash", sa.String(length=64), nullable=True))
    op.add_column(
        "mfa_sessions",
        sa.Column("attempt_count", sa.Integer(), nullable=False, server_default="0"),
    )
    op.alter_column("mfa_sessions", "attempt_count", server_default=None)


def downgrade() -> None:
    op.drop_column("mfa_sessions", "attempt_count")
    op.drop_column("mfa_sessions", "code_hash")
