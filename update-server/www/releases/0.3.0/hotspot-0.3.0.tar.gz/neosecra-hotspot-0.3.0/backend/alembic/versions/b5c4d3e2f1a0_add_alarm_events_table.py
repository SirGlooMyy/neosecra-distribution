"""add alarm_events table

Revision ID: b5c4d3e2f1a0
Revises: f0e1d2c3b4a5
Create Date: 2026-07-11 18:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = 'b5c4d3e2f1a0'
down_revision: Union[str, None] = 'f0e1d2c3b4a5'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('alarm_events',
        sa.Column('customer_id', sa.UUID(), nullable=False),
        sa.Column('location_id', sa.UUID(), nullable=True),
        sa.Column('trigger_id', sa.UUID(), nullable=True),
        sa.Column('severity', sa.String(length=20), nullable=False),
        sa.Column('title', sa.String(length=255), nullable=False),
        sa.Column('message', sa.Text(), nullable=True),
        sa.Column('source', sa.String(length=255), nullable=True),
        sa.Column('acknowledged', sa.Boolean(), nullable=False),
        sa.Column('acknowledged_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('acknowledged_by', sa.UUID(), nullable=True),
        sa.Column('event_time', sa.DateTime(timezone=True), nullable=False),
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['location_id'], ['locations.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['trigger_id'], ['syslog_triggers.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_alarm_events_customer_id'), 'alarm_events', ['customer_id'], unique=False)
    op.create_index(op.f('ix_alarm_events_event_time'), 'alarm_events', ['event_time'], unique=False)
    op.create_index(op.f('ix_alarm_events_severity'), 'alarm_events', ['severity'], unique=False)


def downgrade() -> None:
    op.drop_index(op.f('ix_alarm_events_severity'), table_name='alarm_events')
    op.drop_index(op.f('ix_alarm_events_event_time'), table_name='alarm_events')
    op.drop_index(op.f('ix_alarm_events_customer_id'), table_name='alarm_events')
    op.drop_table('alarm_events')
