"""Add archive_index table + location_id to archive_records_5651

Revision ID: a1b2c3d4e5f6
Revises: e7f8a9b0c1d2
Create Date: 2026-07-11 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID, JSONB, BIGINT

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f6'
down_revision: Union[str, None] = 'e7f8a9b0c1d2'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # archive_records_5651: add location_id (optional FK)
    op.add_column(
        'archive_records_5651',
        sa.Column('location_id', UUID(as_uuid=True),
                  sa.ForeignKey('locations.id', ondelete='RESTRICT'),
                  nullable=True),
    )
    op.create_index('ix_archive_records_5651_location_id',
                    'archive_records_5651', ['location_id'])

    # archive_index: quick-search catalog for archived syslog .zst files
    op.create_table(
        'archive_index',
        sa.Column('id', UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text('gen_random_uuid()')),
        sa.Column('customer_id', UUID(as_uuid=True),
                  sa.ForeignKey('customers.id', ondelete='RESTRICT'),
                  nullable=False),
        sa.Column('location_id', UUID(as_uuid=True),
                  sa.ForeignKey('locations.id', ondelete='RESTRICT'),
                  nullable=True),
        sa.Column('period_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('period_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('record_count', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('file_ref', sa.String(500), nullable=False),
        sa.Column('file_size', BIGINT(), nullable=False, server_default='0'),
        sa.Column('compression', sa.String(10), nullable=False, server_default='zstd'),
        sa.Column('content_hash', sa.String(64), nullable=False),
        sa.Column('prev_hash', sa.String(64), nullable=False),
        sa.Column('signature_value', sa.Text(), nullable=True),
        sa.Column('searchable_fields', JSONB(), nullable=True,
                  comment="{'ips':[],'macs':[],'users':[],'domains':[],'devices':[]}"),
        sa.Column('created_at', sa.DateTime(timezone=True),
                  server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True),
                  server_default=sa.text('now()'), nullable=False),
    )
    op.create_index('ix_archive_index_customer_id', 'archive_index', ['customer_id'])
    op.create_index('ix_archive_index_period_start', 'archive_index', ['period_start'])
    op.create_index('ix_archive_index_period_end', 'archive_index', ['period_end'])
    op.create_index('ix_archive_index_content_hash', 'archive_index', ['content_hash'])


def downgrade() -> None:
    op.drop_table('archive_index')
    op.drop_index('ix_archive_records_5651_location_id',
                  table_name='archive_records_5651')
    op.drop_column('archive_records_5651', 'location_id')
