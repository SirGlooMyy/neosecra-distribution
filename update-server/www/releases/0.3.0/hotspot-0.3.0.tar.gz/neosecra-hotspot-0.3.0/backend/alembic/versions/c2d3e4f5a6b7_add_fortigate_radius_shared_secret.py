"""store encrypted FortiGate RADIUS client settings for VPN MFA"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "c2d3e4f5a6b7"
down_revision: Union[str, None] = "c1d2e3f4a5b6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("vpn_mfa_config", sa.Column("radius_nas_ip", sa.String(length=64), nullable=True))
    op.add_column("vpn_mfa_config", sa.Column("radius_accounting_port", sa.Integer(), nullable=False, server_default="1813"))
    op.add_column("vpn_mfa_config", sa.Column("radius_shared_secret_encrypted", sa.String(length=2000), nullable=True))
    op.add_column("vpn_mfa_config", sa.Column("radius_secret_updated_at", sa.DateTime(timezone=True), nullable=True))
    op.alter_column("vpn_mfa_config", "radius_accounting_port", server_default=None)


def downgrade() -> None:
    op.drop_column("vpn_mfa_config", "radius_secret_updated_at")
    op.drop_column("vpn_mfa_config", "radius_shared_secret_encrypted")
    op.drop_column("vpn_mfa_config", "radius_accounting_port")
    op.drop_column("vpn_mfa_config", "radius_nas_ip")
