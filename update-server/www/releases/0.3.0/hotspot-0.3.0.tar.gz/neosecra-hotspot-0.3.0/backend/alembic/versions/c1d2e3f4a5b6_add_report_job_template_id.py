"""add report preset selection to scheduled jobs

Revision ID: c1d2e3f4a5b6
Revises: b2c3d4e5f6a7
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "c1d2e3f4a5b6"
down_revision: Union[str, None] = "b2c3d4e5f6a7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("report_jobs", sa.Column("template_id", sa.String(length=80), nullable=True))


def downgrade() -> None:
    op.drop_column("report_jobs", "template_id")
