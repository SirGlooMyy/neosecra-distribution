"""persist safe captive portal form values on identity verifications

Revision ID: e1f2a3b4c5d6
Revises: c2d3e4f5a6b7, da1e2f3a4b5c
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "e1f2a3b4c5d6"
down_revision: Union[str, Sequence[str], None] = ("c2d3e4f5a6b7", "da1e2f3a4b5c")
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "identity_verifications",
        sa.Column("form_data", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
    )
    op.alter_column("identity_verifications", "form_data", server_default=None)


def downgrade() -> None:
    op.drop_column("identity_verifications", "form_data")
