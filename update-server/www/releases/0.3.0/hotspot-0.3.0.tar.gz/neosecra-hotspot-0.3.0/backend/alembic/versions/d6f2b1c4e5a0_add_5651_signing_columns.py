"""add 5651 signing columns to archive_records_5651

Revision ID: d6f2b1c4e5a0
Revises: bd3a07a1583c
Create Date: 2026-07-11 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'd6f2b1c4e5a0'
down_revision: Union[str, None] = 'bd3a07a1583c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        'archive_records_5651',
        sa.Column('signature_value', sa.Text(), nullable=True),
    )
    op.add_column(
        'archive_records_5651',
        sa.Column('signature_time', sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        'archive_records_5651',
        sa.Column('certificate_serial', sa.String(length=100), nullable=True),
    )
    op.add_column(
        'archive_records_5651',
        sa.Column('sign_method', sa.String(length=20), nullable=True),
    )


def downgrade() -> None:
    op.drop_column('archive_records_5651', 'sign_method')
    op.drop_column('archive_records_5651', 'certificate_serial')
    op.drop_column('archive_records_5651', 'signature_time')
    op.drop_column('archive_records_5651', 'signature_value')
