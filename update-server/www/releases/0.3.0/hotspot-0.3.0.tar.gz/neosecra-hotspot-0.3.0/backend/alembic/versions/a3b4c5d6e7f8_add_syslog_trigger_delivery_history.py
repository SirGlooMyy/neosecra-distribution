"""add syslog trigger delivery history

Revision ID: a3b4c5d6e7f8
Revises: f1a2b3c4d5e6
Create Date: 2026-07-13 21:45:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "a3b4c5d6e7f8"
down_revision: Union[str, None] = "f1a2b3c4d5e6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("syslog_trigger_events", sa.Column("delivery_channel", sa.String(length=20), nullable=True))
    op.add_column("syslog_trigger_events", sa.Column("delivery_status", sa.String(length=20), nullable=True))
    op.add_column("syslog_trigger_events", sa.Column("delivery_target", sa.String(length=255), nullable=True))
    op.add_column("syslog_trigger_events", sa.Column("delivery_detail", sa.Text(), nullable=True))
    op.add_column("syslog_trigger_events", sa.Column("delivered_at", sa.DateTime(timezone=True), nullable=True))


def downgrade() -> None:
    op.drop_column("syslog_trigger_events", "delivered_at")
    op.drop_column("syslog_trigger_events", "delivery_detail")
    op.drop_column("syslog_trigger_events", "delivery_target")
    op.drop_column("syslog_trigger_events", "delivery_status")
    op.drop_column("syslog_trigger_events", "delivery_channel")
