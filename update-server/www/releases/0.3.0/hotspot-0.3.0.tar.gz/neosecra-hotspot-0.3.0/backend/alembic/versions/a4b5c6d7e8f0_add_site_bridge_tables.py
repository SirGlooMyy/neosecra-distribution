"""add site_bridge tables

Revision ID: a4b5c6d7e8f0
Revises: f56d1701d0b3
Create Date: 2026-07-16
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = 'a4b5c6d7e8f0'
down_revision: Union[str, None] = 'f56d1701d0b3'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('bridge_agents',
        sa.Column('id', sa.Uuid(), nullable=False),
        sa.Column('tenant_id', sa.Uuid(), nullable=False),
        sa.Column('location_id', sa.Uuid(), nullable=True),
        sa.Column('agent_id', sa.String(128), nullable=False, index=True),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('version', sa.String(20), nullable=True),
        sa.Column('public_key', sa.Text(), nullable=True),
        sa.Column('is_active', sa.Boolean(), default=True, nullable=False),
        sa.Column('last_heartbeat_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_ip', sa.String(64), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('agent_id'),
        sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['location_id'], ['locations.id'], ondelete='SET NULL'),
    )
    op.create_table('bridge_commands',
        sa.Column('id', sa.Uuid(), nullable=False),
        sa.Column('agent_id', sa.String(128), nullable=False, index=True),
        sa.Column('command_type', sa.String(50), nullable=False),
        sa.Column('payload', sa.Text(), nullable=True),
        sa.Column('signature', sa.String(255), nullable=True),
        sa.Column('status', sa.String(20), default='pending'),
        sa.Column('executed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('result', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_table('bridge_events',
        sa.Column('id', sa.Uuid(), nullable=False),
        sa.Column('agent_id', sa.String(128), nullable=False, index=True),
        sa.Column('event_type', sa.String(50), nullable=False),
        sa.Column('payload', sa.Text(), nullable=True),
        sa.Column('status', sa.String(20), default='received'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
def downgrade() -> None:
    op.drop_table('bridge_events')
    op.drop_table('bridge_commands')
    op.drop_table('bridge_agents')
