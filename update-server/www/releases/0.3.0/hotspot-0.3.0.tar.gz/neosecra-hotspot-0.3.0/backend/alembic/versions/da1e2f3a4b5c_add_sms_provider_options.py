"""add provider-specific SMS credentials and request options"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "da1e2f3a4b5c"
down_revision: Union[str, None] = "f56d1701d0b3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("sms_configs", sa.Column("api_secret_encrypted", sa.String(length=500), nullable=True))
    op.add_column("sms_configs", sa.Column("provider_options", sa.JSON(), nullable=True))


def downgrade() -> None:
    op.drop_column("sms_configs", "provider_options")
    op.drop_column("sms_configs", "api_secret_encrypted")
