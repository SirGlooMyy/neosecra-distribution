import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Integer, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


class TrafficHourly(Base, UUIDPK, TimestampMixin):
    """Hourly aggregated traffic stats per location."""

    __tablename__ = "traffic_hourly"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID] = fk("locations", ondelete="RESTRICT")
    hour: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    session_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    bytes_in: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    bytes_out: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    active_users: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    new_users: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class TrafficDaily(Base, UUIDPK, TimestampMixin):
    """Daily aggregated traffic stats per customer."""

    __tablename__ = "traffic_daily"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    session_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    bytes_in: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    bytes_out: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    peak_concurrent: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    avg_session_duration_min: Mapped[float | None] = mapped_column(nullable=True)
    unique_macs: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    auth_methods: Mapped[dict | None] = mapped_column(JSONB, nullable=True, comment="JSON: {sms: 10, voucher: 5, ...}")


class TopTalker(Base, UUIDPK, TimestampMixin):
    """Top bandwidth consumers per period."""

    __tablename__ = "top_talkers"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    period_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    period_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    mac: Mapped[str] = mapped_column(String(32), nullable=False)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    bytes_in: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    bytes_out: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    session_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rank: Mapped[int] = mapped_column(Integer, nullable=False)
