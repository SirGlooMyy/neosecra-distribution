"""Update / release management built on top of versioned public assets.

The system uses the existing `public_assets` table for release notes so the
public marketing page and the admin update center always read from the same
source of truth.
"""
from __future__ import annotations

import io
import json
import logging
import os
import re
import uuid
from collections import Counter
from datetime import datetime, timezone
import zipfile

from fastapi import Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.audit.service import log_audit
from app.modules.public_content.models import PublicAsset
from app.modules.public_content.schemas import PublicAssetOut
from app.modules.public_content.service import list_public_assets, release_download_path
from app.modules.system.schemas import (
    SystemUpdateOut,
    SystemUpdateSnapshotOut,
    SystemUpdateUpsertIn,
)

RELEASE_SECTION = "release_notes"
_UPDATE_BUNDLE_BUCKET_CACHE: str | None = None

log = logging.getLogger(__name__)


def _normalize_text(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = " ".join(str(value).split()).strip()
    return normalized or None


def _normalize_steps(value: object) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str):
        return [line.strip(" -\t") for line in value.splitlines() if line.strip()]
    normalized = str(value).strip()
    return [normalized] if normalized else []


def _normalize_slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    return slug or "release"


def _release_type_label(release_type: str) -> str:
    labels = {
        "feature": "Feature",
        "fix": "Fix",
        "security": "Security",
        "hotfix": "Hotfix",
        "maintenance": "Maintenance",
    }
    return labels.get(release_type, release_type.title())


def _version_key(version: str) -> tuple[tuple[int, int | str], ...]:
    tokens = re.findall(r"\d+|[A-Za-z]+", version or "")
    if not tokens:
        return ((0, version.lower()),)
    key: list[tuple[int, int | str]] = []
    for token in tokens:
        if token.isdigit():
            key.append((1, int(token)))
        else:
            key.append((0, token.lower()))
    return tuple(key)


def _is_upgrade_available(current_version: str, latest_version: str) -> bool:
    return _version_key(latest_version) > _version_key(current_version)


def _parse_datetime(value: object) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str) and value:
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            return None
    return None


def _max_datetime(values: list[datetime | None]) -> datetime | None:
    filtered = [value for value in values if value is not None]
    if not filtered:
        return None
    return max(filtered)


def _release_status(asset: PublicAsset | PublicAssetOut) -> str:
    meta = dict(getattr(asset, "meta", None) or {})
    status = str(meta.get("status") or ("published" if getattr(asset, "is_current", False) else "draft")).lower()
    if status not in {"draft", "published", "archived"}:
        return "draft"
    return status


def _release_audit_details(release: SystemUpdateOut) -> dict[str, object]:
    return {
        "version": release.version,
        "slug": release.slug,
        "status": release.status,
        "channel": release.channel,
        "release_type": release.release_type,
        "is_mandatory": release.is_mandatory,
        "minimum_version": release.minimum_version,
        "artifact_name": release.artifact_name,
        "artifact_ref": release.artifact_ref,
        "artifact_generated_at": release.artifact_generated_at.isoformat() if release.artifact_generated_at else None,
        "artifact_size_bytes": release.artifact_size_bytes,
        "distribution_status": release.distribution_status,
        "distribution_manifest_ref": release.distribution_manifest_ref,
        "distribution_manifest_generated_at": release.distribution_manifest_generated_at.isoformat() if release.distribution_manifest_generated_at else None,
        "distribution_activation_ref": release.distribution_activation_ref,
        "distribution_activated_at": release.distribution_activated_at.isoformat() if release.distribution_activated_at else None,
        "distribution_activated_by": release.distribution_activated_by,
        "distribution_targets": release.distribution_targets,
        "published_by": release.published_by,
        "published_at": release.published_at.isoformat() if release.published_at else None,
    }


def _safe_path_part(value: str) -> str:
    part = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip()).strip("._-")
    return part or "release"


def _update_bundle_filename(release_out: SystemUpdateOut, *, generated_at: datetime | None = None) -> str:
    generated_at = generated_at or datetime.now(timezone.utc)
    artifact_name = _normalize_text(release_out.artifact_name)
    if artifact_name:
        filename = os.path.basename(artifact_name)
        if filename:
            return filename
    return f"hotspot-update-{release_out.version}-{generated_at.strftime('%Y%m%d-%H%M%S')}.zip"


def _update_bundle_key(release_out: SystemUpdateOut) -> str:
    return f"updates/{_safe_path_part(release_out.slug)}/{_safe_path_part(release_out.version)}/bundle.zip"


def _update_bundle_local_path(release_out: SystemUpdateOut) -> str:
    base = settings.ARCHIVE_LOCAL_DIR or "./_archives"
    base_abs = os.path.abspath(base)
    path = os.path.abspath(os.path.join(base_abs, _update_bundle_key(release_out)))
    try:
        if os.path.commonpath([base_abs, path]) != base_abs:
            path = os.path.join(base_abs, f"{_safe_path_part(release_out.slug)}-{_safe_path_part(release_out.version)}-bundle.zip")
    except ValueError:
        path = os.path.join(base_abs, f"{_safe_path_part(release_out.slug)}-{_safe_path_part(release_out.version)}-bundle.zip")
    return path


def _ensure_update_bundle_bucket_minio(client, bucket: str) -> None:
    global _UPDATE_BUNDLE_BUCKET_CACHE
    if _UPDATE_BUNDLE_BUCKET_CACHE == bucket:
        return
    if not client.bucket_exists(bucket):
        client.make_bucket(bucket)
    _UPDATE_BUNDLE_BUCKET_CACHE = bucket


def _ensure_update_bundle_bucket_boto(s3, bucket: str) -> None:
    global _UPDATE_BUNDLE_BUCKET_CACHE
    if _UPDATE_BUNDLE_BUCKET_CACHE == bucket:
        return
    try:
        s3.head_bucket(Bucket=bucket)
    except Exception:  # noqa: BLE001
        s3.create_bucket(Bucket=bucket)
    _UPDATE_BUNDLE_BUCKET_CACHE = bucket


def _store_update_bundle_local(content: bytes, release_out: SystemUpdateOut) -> str:
    path = _update_bundle_local_path(release_out)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(content)
    return f"local:{path}"


def _store_update_bundle_minio(content: bytes, release_out: SystemUpdateOut) -> str:
    key = _update_bundle_key(release_out)
    bucket = settings.MINIO_BUCKET_UPDATES or "hotspot-updates"
    try:
        from minio import Minio  # type: ignore
    except ImportError:
        try:
            import boto3  # type: ignore

            s3 = boto3.client(
                "s3",
                endpoint_url=f"http{'s' if settings.MINIO_SECURE else ''}://{settings.MINIO_ENDPOINT.replace('http://', '').replace('https://', '')}",
                aws_access_key_id=settings.MINIO_ACCESS_KEY,
                aws_secret_access_key=settings.MINIO_SECRET_KEY,
            )
            _ensure_update_bundle_bucket_boto(s3, bucket)
            s3.put_object(Bucket=bucket, Key=key, Body=content)
            return f"minio:{bucket}/{key}"
        except ImportError as exc:
            raise RuntimeError("neither minio nor boto3 installed for update bundle storage") from exc

    client = Minio(
        settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE,
    )
    _ensure_update_bundle_bucket_minio(client, bucket)
    client.put_object(bucket, key, io.BytesIO(content), length=len(content))
    return f"minio:{bucket}/{key}"


def _store_update_bundle(content: bytes, release_out: SystemUpdateOut) -> str:
    provider = (settings.ARCHIVE_PROVIDER or "local").lower()
    if provider == "minio":
        try:
            return _store_update_bundle_minio(content, release_out)
        except Exception as exc:  # noqa: BLE001
            log.warning("update bundle minio upload failed, falling back to local: %s", exc)
            return _store_update_bundle_local(content, release_out)
    if provider == "none":
        return f"none:{_update_bundle_key(release_out)}"
    return _store_update_bundle_local(content, release_out)


def _distribution_targets(channel: str) -> list[str]:
    channel = (channel or "stable").lower()
    if channel == "beta":
        return ["public-download", "client-auto-update", "channel:beta"]
    if channel == "hotfix":
        return ["public-download", "client-auto-update", "channel:hotfix"]
    return ["public-download", "client-auto-update", "channel:stable"]


def _distribution_manifest_key(release_out: SystemUpdateOut) -> str:
    return f"updates/{_safe_path_part(release_out.slug)}/{_safe_path_part(release_out.version)}/distribution-manifest.json"


def _distribution_manifest_filename(release_out: SystemUpdateOut, *, generated_at: datetime | None = None) -> str:
    generated_at = generated_at or datetime.now(timezone.utc)
    return f"hotspot-update-{release_out.version}-{generated_at.strftime('%Y%m%d-%H%M%S')}-distribution.json"


def _distribution_manifest_local_path(release_out: SystemUpdateOut) -> str:
    base = settings.ARCHIVE_LOCAL_DIR or "./_archives"
    base_abs = os.path.abspath(base)
    path = os.path.abspath(os.path.join(base_abs, _distribution_manifest_key(release_out)))
    try:
        if os.path.commonpath([base_abs, path]) != base_abs:
            path = os.path.join(base_abs, f"{_safe_path_part(release_out.slug)}-{_safe_path_part(release_out.version)}-distribution-manifest.json")
    except ValueError:
        path = os.path.join(base_abs, f"{_safe_path_part(release_out.slug)}-{_safe_path_part(release_out.version)}-distribution-manifest.json")
    return path


def _store_distribution_manifest_local(content: bytes, release_out: SystemUpdateOut) -> str:
    path = _distribution_manifest_local_path(release_out)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(content)
    return f"local:{path}"


def _store_distribution_manifest_minio(content: bytes, release_out: SystemUpdateOut) -> str:
    key = _distribution_manifest_key(release_out)
    bucket = settings.MINIO_BUCKET_UPDATES or "hotspot-updates"
    try:
        from minio import Minio  # type: ignore
    except ImportError:
        try:
            import boto3  # type: ignore

            s3 = boto3.client(
                "s3",
                endpoint_url=f"http{'s' if settings.MINIO_SECURE else ''}://{settings.MINIO_ENDPOINT.replace('http://', '').replace('https://', '')}",
                aws_access_key_id=settings.MINIO_ACCESS_KEY,
                aws_secret_access_key=settings.MINIO_SECRET_KEY,
            )
            _ensure_update_bundle_bucket_boto(s3, bucket)
            s3.put_object(Bucket=bucket, Key=key, Body=content)
            return f"minio:{bucket}/{key}"
        except ImportError as exc:
            raise RuntimeError("neither minio nor boto3 installed for update distribution storage") from exc

    client = Minio(
        settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE,
    )
    _ensure_update_bundle_bucket_minio(client, bucket)
    client.put_object(bucket, key, io.BytesIO(content), length=len(content))
    return f"minio:{bucket}/{key}"


def _store_distribution_manifest(content: bytes, release_out: SystemUpdateOut) -> str:
    provider = (settings.ARCHIVE_PROVIDER or "local").lower()
    if provider == "minio":
        try:
            return _store_distribution_manifest_minio(content, release_out)
        except Exception as exc:  # noqa: BLE001
            log.warning("distribution manifest minio upload failed, falling back to local: %s", exc)
            return _store_distribution_manifest_local(content, release_out)
    if provider == "none":
        return f"none:{_distribution_manifest_key(release_out)}"
    return _store_distribution_manifest_local(content, release_out)


def _distribution_activation_key(release_out: SystemUpdateOut) -> str:
    return f"updates/{_safe_path_part(release_out.slug)}/{_safe_path_part(release_out.version)}/distribution-activation.json"


def _distribution_activation_filename(release_out: SystemUpdateOut, *, generated_at: datetime | None = None) -> str:
    generated_at = generated_at or datetime.now(timezone.utc)
    return f"hotspot-update-{release_out.version}-{generated_at.strftime('%Y%m%d-%H%M%S')}-activation.json"


def _distribution_activation_local_path(release_out: SystemUpdateOut) -> str:
    base = settings.ARCHIVE_LOCAL_DIR or "./_archives"
    base_abs = os.path.abspath(base)
    path = os.path.abspath(os.path.join(base_abs, _distribution_activation_key(release_out)))
    try:
        if os.path.commonpath([base_abs, path]) != base_abs:
            path = os.path.join(base_abs, f"{_safe_path_part(release_out.slug)}-{_safe_path_part(release_out.version)}-distribution-activation.json")
    except ValueError:
        path = os.path.join(base_abs, f"{_safe_path_part(release_out.slug)}-{_safe_path_part(release_out.version)}-distribution-activation.json")
    return path


def _store_distribution_activation_local(content: bytes, release_out: SystemUpdateOut) -> str:
    path = _distribution_activation_local_path(release_out)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(content)
    return f"local:{path}"


def _store_distribution_activation_minio(content: bytes, release_out: SystemUpdateOut) -> str:
    key = _distribution_activation_key(release_out)
    bucket = settings.MINIO_BUCKET_UPDATES or "hotspot-updates"
    try:
        from minio import Minio  # type: ignore
    except ImportError:
        try:
            import boto3  # type: ignore

            s3 = boto3.client(
                "s3",
                endpoint_url=f"http{'s' if settings.MINIO_SECURE else ''}://{settings.MINIO_ENDPOINT.replace('http://', '').replace('https://', '')}",
                aws_access_key_id=settings.MINIO_ACCESS_KEY,
                aws_secret_access_key=settings.MINIO_SECRET_KEY,
            )
            _ensure_update_bundle_bucket_boto(s3, bucket)
            s3.put_object(Bucket=bucket, Key=key, Body=content)
            return f"minio:{bucket}/{key}"
        except ImportError as exc:
            raise RuntimeError("neither minio nor boto3 installed for update activation storage") from exc

    client = Minio(
        settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE,
    )
    _ensure_update_bundle_bucket_minio(client, bucket)
    client.put_object(bucket, key, io.BytesIO(content), length=len(content))
    return f"minio:{bucket}/{key}"


def _store_distribution_activation(content: bytes, release_out: SystemUpdateOut) -> str:
    provider = (settings.ARCHIVE_PROVIDER or "local").lower()
    if provider == "minio":
        try:
            return _store_distribution_activation_minio(content, release_out)
        except Exception as exc:  # noqa: BLE001
            log.warning("distribution activation minio upload failed, falling back to local: %s", exc)
            return _store_distribution_activation_local(content, release_out)
    if provider == "none":
        return f"none:{_distribution_activation_key(release_out)}"
    return _store_distribution_activation_local(content, release_out)


def build_update_distribution_manifest(
    release: SystemUpdateOut | PublicAsset | PublicAssetOut,
    *,
    generated_at: datetime | None = None,
) -> tuple[bytes, str, dict[str, object]]:
    release_out = release if isinstance(release, SystemUpdateOut) else _serialize_release(release)
    generated_at = generated_at or datetime.now(timezone.utc)
    filename = _distribution_manifest_filename(release_out, generated_at=generated_at)
    distribution_status = _normalize_text(release_out.distribution_status)
    if not distribution_status:
        distribution_status = "ready" if release_out.status == "published" else release_out.status
    manifest = {
        "release_id": str(release_out.id),
        "title": release_out.title,
        "version": release_out.version,
        "slug": release_out.slug,
        "section": release_out.section,
        "status": release_out.status,
        "release_type": release_out.release_type,
        "channel": release_out.channel,
        "distribution_status": distribution_status,
        "distribution_targets": _distribution_targets(release_out.channel),
        "download_url": release_out.asset_url or release_download_path(release_out.slug, release_out.version),
        "artifact_name": release_out.artifact_name,
        "artifact_ref": release_out.artifact_ref,
        "artifact_generated_at": release_out.artifact_generated_at.isoformat() if release_out.artifact_generated_at else None,
        "artifact_size_bytes": release_out.artifact_size_bytes,
        "minimum_version": release_out.minimum_version,
        "is_mandatory": release_out.is_mandatory,
        "summary": release_out.summary,
        "upgrade_steps": release_out.upgrade_steps,
        "published_by": release_out.published_by,
        "published_at": release_out.published_at.isoformat() if release_out.published_at else None,
        "generated_at": generated_at.isoformat(),
    }
    payload = json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    return payload, filename, manifest


def build_update_distribution_activation(
    release: SystemUpdateOut | PublicAsset | PublicAssetOut,
    *,
    generated_at: datetime | None = None,
    activated_by: str | None = None,
) -> tuple[bytes, str, dict[str, object]]:
    release_out = release if isinstance(release, SystemUpdateOut) else _serialize_release(release)
    generated_at = generated_at or datetime.now(timezone.utc)
    filename = _distribution_activation_filename(release_out, generated_at=generated_at)
    activation = {
        "release_id": str(release_out.id),
        "title": release_out.title,
        "version": release_out.version,
        "slug": release_out.slug,
        "section": release_out.section,
        "status": release_out.status,
        "distribution_status": "activated",
        "distribution_manifest_ref": release_out.distribution_manifest_ref,
        "distribution_targets": _distribution_targets(release_out.channel),
        "download_url": release_out.asset_url or release_download_path(release_out.slug, release_out.version),
        "artifact_ref": release_out.artifact_ref,
        "published_by": release_out.published_by,
        "published_at": release_out.published_at.isoformat() if release_out.published_at else None,
        "activated_by": activated_by,
        "activated_at": generated_at.isoformat(),
        "generated_at": generated_at.isoformat(),
    }
    payload = json.dumps(activation, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
    return payload, filename, activation


def _store_release_distribution_manifest(
    asset: PublicAsset,
    release_out: SystemUpdateOut,
    *,
    generated_at: datetime,
) -> SystemUpdateOut:
    payload, _, manifest = build_update_distribution_manifest(release_out, generated_at=generated_at)
    manifest_ref = _store_distribution_manifest(payload, release_out)
    meta = dict(asset.meta or {})
    meta["distribution_status"] = manifest["distribution_status"]
    meta["distribution_manifest_ref"] = manifest_ref
    meta["distribution_manifest_generated_at"] = generated_at.isoformat()
    meta["distribution_targets"] = manifest["distribution_targets"]
    asset.meta = meta
    return _serialize_release(asset)


def _store_release_distribution_activation(
    asset: PublicAsset,
    release_out: SystemUpdateOut,
    *,
    generated_at: datetime,
    activated_by: str | None,
) -> SystemUpdateOut:
    payload, _, activation = build_update_distribution_activation(
        release_out,
        generated_at=generated_at,
        activated_by=activated_by,
    )
    activation_ref = _store_distribution_activation(payload, release_out)
    meta = dict(asset.meta or {})
    meta["distribution_status"] = activation["distribution_status"]
    meta["distribution_activation_ref"] = activation_ref
    meta["distribution_activated_at"] = generated_at.isoformat()
    if activated_by:
        meta["distribution_activated_by"] = activated_by
    meta["distribution_targets"] = activation["distribution_targets"]
    asset.meta = meta
    return _serialize_release(asset)


async def _supersede_channel_releases(
    db: AsyncSession,
    release_out: SystemUpdateOut,
    *,
    superseded_by: str | None,
    superseded_at: datetime,
) -> list[str]:
    result = await db.execute(select(PublicAsset).where(PublicAsset.section == RELEASE_SECTION))
    superseded_release_ids: list[str] = []
    for asset in result.scalars().all():
        if str(getattr(asset, "id", "")) == str(release_out.id):
            continue
        meta = dict(getattr(asset, "meta", None) or {})
        if str(meta.get("channel") or "stable") != (release_out.channel or "stable"):
            continue
        if _release_status(asset) != "published" or not getattr(asset, "is_current", False):
            continue

        meta["distribution_status"] = "superseded"
        meta["distribution_superseded_at"] = superseded_at.isoformat()
        if superseded_by:
            meta["distribution_superseded_by"] = superseded_by
        meta["distribution_superseded_by_release_id"] = str(release_out.id)
        asset.meta = meta
        asset.is_current = False
        asset.updated_at = superseded_at
        superseded_release_ids.append(str(asset.id))

    if superseded_release_ids:
        await db.flush()
    return superseded_release_ids


def _read_update_bundle_ref(ref: str) -> bytes | None:
    cleaned = (ref or "").strip()
    if not cleaned or cleaned.startswith("none:"):
        return None
    try:
        if cleaned.startswith("local:"):
            path = cleaned[len("local:") :]
            with open(path, "rb") as fh:
                return fh.read()
        if cleaned.startswith("minio:"):
            bucket_and_key = cleaned[len("minio:") :]
            bucket, _, key = bucket_and_key.partition("/")
            if not bucket or not key:
                return None
            try:
                from minio import Minio  # type: ignore

                client = Minio(
                    settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
                    access_key=settings.MINIO_ACCESS_KEY,
                    secret_key=settings.MINIO_SECRET_KEY,
                    secure=settings.MINIO_SECURE,
                )
                obj = client.get_object(bucket, key)
                try:
                    return obj.read()
                finally:
                    obj.close()
                    obj.release_conn()
            except ImportError:
                import boto3  # type: ignore

                s3 = boto3.client(
                    "s3",
                    endpoint_url=f"http{'s' if settings.MINIO_SECURE else ''}://{settings.MINIO_ENDPOINT.replace('http://', '').replace('https://', '')}",
                    aws_access_key_id=settings.MINIO_ACCESS_KEY,
                    aws_secret_access_key=settings.MINIO_SECRET_KEY,
                )
                obj = s3.get_object(Bucket=bucket, Key=key)
                return obj["Body"].read()
        if os.path.isabs(cleaned) and os.path.exists(cleaned):
            with open(cleaned, "rb") as fh:
                return fh.read()
    except Exception as exc:  # noqa: BLE001
        log.warning("Update bundle read failed ref=%s: %s", cleaned, exc)
        return None
    return None


def _store_release_artifact(asset: PublicAsset, release_out: SystemUpdateOut, *, generated_at: datetime) -> SystemUpdateOut:
    artifact_name = _update_bundle_filename(release_out, generated_at=generated_at)
    bundle_release = release_out.model_copy(update={"artifact_name": artifact_name})
    bundle, filename = build_update_release_bundle(bundle_release, generated_at=generated_at)
    artifact_ref = _store_update_bundle(bundle, bundle_release)
    meta = dict(asset.meta or {})
    meta["artifact_ref"] = artifact_ref
    meta["artifact_name"] = artifact_name or filename
    meta["artifact_generated_at"] = generated_at.isoformat()
    meta["artifact_size_bytes"] = len(bundle)
    asset.meta = meta
    return _serialize_release(asset)


def get_release_bundle_payload(release: SystemUpdateOut | PublicAsset | PublicAssetOut) -> tuple[bytes, str]:
    release_out = release if isinstance(release, SystemUpdateOut) else _serialize_release(release)
    meta = dict(getattr(release, "meta", None) or {})
    generated_at = _parse_datetime(meta.get("artifact_generated_at")) or release_out.published_at or datetime.now(timezone.utc)
    filename = _update_bundle_filename(release_out, generated_at=generated_at)
    artifact_ref = _normalize_text(meta.get("artifact_ref"))
    if artifact_ref:
        stored = _read_update_bundle_ref(artifact_ref)
        if stored is not None:
            return stored, filename
        log.warning("Stored update bundle unavailable, regenerating slug=%s version=%s ref=%s", release_out.slug, release_out.version, artifact_ref)
    return build_update_release_bundle(release_out, generated_at=generated_at)


def build_update_release_bundle(
    release: SystemUpdateOut | PublicAsset | PublicAssetOut,
    *,
    generated_at: datetime | None = None,
) -> tuple[bytes, str]:
    """Package a release note into a portable update bundle."""
    release_out = release if isinstance(release, SystemUpdateOut) else _serialize_release(release)
    generated_at = generated_at or datetime.now(timezone.utc)
    filename = _update_bundle_filename(release_out, generated_at=generated_at)
    artifact_name = filename

    manifest = {
        "title": release_out.title,
        "version": release_out.version,
        "slug": release_out.slug,
        "section": release_out.section,
        "status": release_out.status,
        "release_type": release_out.release_type,
        "channel": release_out.channel,
        "minimum_version": release_out.minimum_version,
        "is_mandatory": release_out.is_mandatory,
        "artifact_name": artifact_name,
        "artifact_url": release_out.asset_url,
        "checksum": release_out.checksum,
        "file_size_kb": release_out.file_size_kb,
        "published_by": release_out.published_by,
        "upgrade_steps": release_out.upgrade_steps,
        "summary": release_out.summary,
        "archived_by": release_out.archived_by,
        "archived_at": release_out.archived_at.isoformat() if release_out.archived_at else None,
        "generated_at": generated_at.isoformat(),
        "published_at": release_out.published_at.isoformat() if release_out.published_at else None,
    }

    upgrade_lines = [
        f"Release: {release_out.title}",
        f"Version: {release_out.version}",
        f"Status: {release_out.status}",
        f"Channel: {release_out.channel}",
        f"Minimum version: {release_out.minimum_version or '—'}",
        f"Mandatory: {'yes' if release_out.is_mandatory else 'no'}",
        f"Artifact: {artifact_name or release_out.asset_url or '—'}",
        f"Checksum: {release_out.checksum or '—'}",
        f"Published by: {release_out.published_by or '—'}",
        f"Generated at: {generated_at.isoformat()}",
        "",
        "Release notes:",
        release_out.body.strip(),
    ]
    if release_out.upgrade_steps:
        upgrade_lines.extend(["", "Upgrade steps:"])
        upgrade_lines.extend(f"- {step}" for step in release_out.upgrade_steps)
    if release_out.summary:
        upgrade_lines.extend(["", f"Summary: {release_out.summary}"])
    if release_out.published_at:
        upgrade_lines.extend(["", f"Published at: {release_out.published_at.isoformat()}"])
    if release_out.archived_at:
        upgrade_lines.extend(["", f"Archived at: {release_out.archived_at.isoformat()}"])
    if release_out.archived_by:
        upgrade_lines.extend(["", f"Archived by: {release_out.archived_by}"])

    readme_lines = [
        "Hotspot Update Bundle",
        "====================",
        "",
        f"Title: {release_out.title}",
        f"Version: {release_out.version}",
        f"Status: {release_out.status}",
        f"Channel: {release_out.channel}",
        "Files: manifest.json, RELEASE_NOTES.txt, UPGRADE_GUIDE.txt",
    ]
    if artifact_name or release_out.asset_url:
        readme_lines.append(f"Artifact: {artifact_name or release_out.asset_url}")
    if release_out.published_by:
        readme_lines.append(f"Published by: {release_out.published_by}")
    if release_out.archived_by:
        readme_lines.append(f"Archived by: {release_out.archived_by}")
    if release_out.upgrade_steps:
        readme_lines.extend(["", "Upgrade steps are included in UPGRADE_GUIDE.txt."])

    bundle = io.BytesIO()
    with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True))
        archive.writestr("RELEASE_NOTES.txt", (release_out.body.strip() + "\n").encode("utf-8"))
        archive.writestr("UPGRADE_GUIDE.txt", ("\n".join(upgrade_lines) + "\n").encode("utf-8"))
        archive.writestr("README.txt", ("\n".join(readme_lines) + "\n").encode("utf-8"))

    return bundle.getvalue(), filename


def _serialize_release(asset: PublicAsset | PublicAssetOut) -> SystemUpdateOut:
    base = asset if isinstance(asset, PublicAssetOut) else PublicAssetOut.model_validate(asset)
    meta = dict(base.meta or {})
    upgrade_steps = _normalize_steps(meta.get("upgrade_steps"))
    release_type = str(meta.get("release_type") or base.category or "feature")
    channel = str(meta.get("channel") or "stable")
    status = _release_status(base)
    published_by = meta.get("published_by") if status in {"published", "archived"} else None
    archived_by = meta.get("archived_by") if status == "archived" else None

    return SystemUpdateOut.model_validate(
        {
            **base.model_dump(),
            "release_type": release_type,
            "channel": channel,
            "status": status,
            "minimum_version": meta.get("minimum_version"),
            "is_mandatory": bool(meta.get("is_mandatory", False)),
            "upgrade_steps": upgrade_steps,
            "artifact_name": meta.get("artifact_name"),
            "artifact_ref": meta.get("artifact_ref"),
            "artifact_generated_at": _parse_datetime(meta.get("artifact_generated_at")),
            "artifact_size_bytes": meta.get("artifact_size_bytes"),
            "distribution_status": meta.get("distribution_status"),
            "distribution_manifest_ref": meta.get("distribution_manifest_ref"),
            "distribution_manifest_generated_at": _parse_datetime(meta.get("distribution_manifest_generated_at")),
            "distribution_activation_ref": meta.get("distribution_activation_ref"),
            "distribution_activated_at": _parse_datetime(meta.get("distribution_activated_at")),
            "distribution_activated_by": meta.get("distribution_activated_by"),
            "distribution_targets": list(meta.get("distribution_targets") or []),
            "asset_url": base.asset_url
            or meta.get("artifact_url")
            or (release_download_path(base.slug, base.version) if status == "published" else None),
            "published_by": published_by,
            "published_at": _parse_datetime(meta.get("published_at")) if status in {"published", "archived"} else None,
            "archived_by": archived_by,
            "archived_at": _parse_datetime(meta.get("archived_at")) if status == "archived" else None,
        }
    )


def _build_meta(
    body: SystemUpdateUpsertIn,
    *,
    status: str,
    published_at: datetime | None = None,
    published_by: str | None = None,
    base_meta: dict | None = None,
) -> dict:
    meta = dict(base_meta or {})
    meta.update(body.meta or {})
    meta.update(
        {
            "release_type": body.release_type,
            "channel": body.channel,
            "status": status,
            "minimum_version": body.minimum_version,
            "is_mandatory": body.is_mandatory,
            "upgrade_steps": _normalize_steps(body.upgrade_steps),
            "artifact_name": body.artifact_name,
            "artifact_url": body.artifact_url,
        }
    )
    if published_at:
        meta["published_at"] = published_at.isoformat()
    if published_by:
        meta["published_by"] = published_by
    return meta


async def _fetch_release(db: AsyncSession, release_id) -> PublicAsset:
    result = await db.execute(
        select(PublicAsset).where(
            PublicAsset.section == RELEASE_SECTION,
            PublicAsset.id == release_id,
        )
    )
    asset = result.scalar_one_or_none()
    if not asset:
        raise ValueError("Guncelleme kaydi bulunamadi")
    return asset


async def list_update_releases(db: AsyncSession, *, include_drafts: bool = True) -> list[SystemUpdateOut]:
    stmt = (
        select(PublicAsset)
        .where(PublicAsset.section == RELEASE_SECTION)
        .order_by(PublicAsset.created_at.desc(), PublicAsset.updated_at.desc())
    )
    result = await db.execute(stmt)
    rows = list(result.scalars().all())

    if not rows:
        fallback_assets = await list_public_assets(db)
        rows = [asset for asset in fallback_assets if asset.section == RELEASE_SECTION]

    if not include_drafts:
        rows = [asset for asset in rows if asset.is_current]

    return [_serialize_release(asset) for asset in rows]


async def get_update_snapshot(db: AsyncSession) -> SystemUpdateSnapshotOut:
    releases = await list_update_releases(db, include_drafts=True)
    active_releases = [release for release in releases if release.status != "archived"]
    published = [release for release in active_releases if release.status == "published"]
    drafts = [release for release in active_releases if release.status == "draft"]
    archived = [release for release in releases if release.status == "archived"]
    stored_artifacts = [release for release in releases if release.artifact_ref]
    distribution_status_counts = Counter(
        ((release.distribution_status or release.status) or "unset").lower()
        for release in releases
    )
    channel_counts = Counter((release.channel or "stable").lower() for release in releases)
    stored_artifacts.sort(
        key=lambda release: (
            release.artifact_generated_at or release.published_at or release.updated_at,
            release.updated_at,
        ),
        reverse=True,
    )
    latest_distribution_manifest_at = _max_datetime(
        [release.distribution_manifest_generated_at for release in releases]
    )
    latest_distribution_activation_at = _max_datetime(
        [release.distribution_activated_at for release in releases]
    )
    featured = active_releases[0] if active_releases else None
    latest_release_version = featured.version if featured else (releases[0].version if releases else settings.VERSION)
    latest_published_version = published[0].version if published else None
    upgrade_available = bool(latest_published_version and _is_upgrade_available(settings.VERSION, latest_published_version))
    draft_count = len(drafts)
    archived_count = len(archived)

    highlights = [
        f"Çalışan sürüm: {settings.VERSION}",
        f"Son yayınlı sürüm: {latest_published_version or settings.VERSION}",
        f"{len(published)} yayın, {draft_count} taslak, {archived_count} arşiv",
    ]
    if featured:
        highlights.insert(
            0,
            featured.summary
            if featured.summary
            else featured.body[:140],
        )
    if upgrade_available and featured:
        highlights.append(f"Yükseltme hazır: {featured.version}")

    return SystemUpdateSnapshotOut(
        current_version=settings.VERSION,
        latest_release_version=latest_release_version,
        latest_published_version=latest_published_version,
        upgrade_available=upgrade_available,
        release_count=len(releases),
        draft_count=draft_count,
        archived_count=archived_count,
        distribution_status_counts=dict(sorted(distribution_status_counts.items())),
        channel_counts=dict(sorted(channel_counts.items())),
        latest_distribution_manifest_at=latest_distribution_manifest_at,
        latest_distribution_activation_at=latest_distribution_activation_at,
        highlights=highlights,
        featured_release=featured,
        releases=releases,
        stored_artifacts=stored_artifacts,
    )


async def create_update_release(
    db: AsyncSession,
    body: SystemUpdateUpsertIn,
    *,
    publish: bool = False,
    published_by: str | None = None,
    request: Request | None = None,
) -> SystemUpdateOut:
    version = body.version.strip()
    slug = _normalize_slug(body.slug or f"release-{version}")

    existing = await db.execute(
        select(PublicAsset).where(
            PublicAsset.section == RELEASE_SECTION,
            PublicAsset.version == version,
        )
    )
    if existing.scalar_one_or_none():
        raise ValueError("Bu surum zaten kayitli")

    now = datetime.now(timezone.utc)
    asset = PublicAsset(
        id=uuid.uuid4(),
        section=RELEASE_SECTION,
        slug=slug,
        version=version,
        title=body.title.strip(),
        category=_release_type_label(body.release_type),
        summary=_normalize_text(body.summary),
        body=body.body.strip(),
        asset_url=_normalize_text(body.artifact_url),
        checksum=_normalize_text(body.checksum),
        file_size_kb=body.file_size_kb,
        is_current=publish,
        sort_order=body.sort_order,
        meta=_build_meta(
            body,
            status="published" if publish else "draft",
            published_at=now if publish else None,
            published_by=published_by,
        ),
        created_at=now,
        updated_at=now,
    )
    db.add(asset)
    await db.flush()
    release_out = _serialize_release(asset)
    release_out = _store_release_artifact(asset, release_out, generated_at=now)
    if release_out.status == "published":
        release_out = _store_release_distribution_manifest(asset, release_out, generated_at=now)
    await log_audit(
        db,
        "system.update_release.created",
        "system_update_release",
        str(asset.id),
        published_by,
        request,
        details=_release_audit_details(release_out),
    )
    await db.commit()
    await db.refresh(asset)
    return _serialize_release(asset)


async def update_update_release(
    db: AsyncSession,
    release_id,
    body: SystemUpdateUpsertIn,
    *,
    publish: bool = False,
    published_by: str | None = None,
    request: Request | None = None,
) -> SystemUpdateOut:
    asset = await _fetch_release(db, release_id)
    version = body.version.strip()

    duplicate = await db.execute(
        select(PublicAsset).where(
            PublicAsset.section == RELEASE_SECTION,
            PublicAsset.version == version,
            PublicAsset.id != release_id,
        )
    )
    if duplicate.scalar_one_or_none():
        raise ValueError("Bu surum zaten kayitli")

    now = datetime.now(timezone.utc)
    asset.slug = _normalize_slug(body.slug or asset.slug or f"release-{version}")
    asset.version = version
    asset.title = body.title.strip()
    asset.category = _release_type_label(body.release_type)
    asset.summary = _normalize_text(body.summary)
    asset.body = body.body.strip()
    if body.artifact_url is not None:
        asset.asset_url = _normalize_text(body.artifact_url)
    asset.checksum = _normalize_text(body.checksum)
    asset.file_size_kb = body.file_size_kb
    asset.sort_order = body.sort_order
    asset.updated_at = now

    current_meta = dict(asset.meta or {})
    current_status = _release_status(asset)
    if publish:
        status = "published"
        published_at = now
        published_by_value = published_by
        is_current = True
    elif current_status == "archived":
        status = "archived"
        published_at = _parse_datetime(current_meta.get("published_at"))
        published_by_value = current_meta.get("published_by")
        is_current = False
    elif asset.is_current or current_status == "published":
        status = "published"
        published_at = _parse_datetime(current_meta.get("published_at"))
        published_by_value = current_meta.get("published_by")
        is_current = True
    else:
        status = "draft"
        published_at = None
        published_by_value = None
        is_current = False

    meta = _build_meta(
        body,
        status=status,
        published_at=published_at,
        published_by=published_by_value,
        base_meta=current_meta,
    )
    if status != "archived":
        meta.pop("archived_at", None)
        meta.pop("archived_by", None)
    asset.meta = meta
    asset.is_current = is_current

    release_out = _serialize_release(asset)
    release_out = _store_release_artifact(asset, release_out, generated_at=now)
    if release_out.status == "published":
        release_out = _store_release_distribution_manifest(asset, release_out, generated_at=now)
    await log_audit(
        db,
        "system.update_release.updated",
        "system_update_release",
        str(asset.id),
        published_by,
        request,
        details=_release_audit_details(release_out),
    )
    await db.commit()
    await db.refresh(asset)
    return _serialize_release(asset)


async def publish_update_release(
    db: AsyncSession,
    release_id,
    *,
    published_by: str | None = None,
    request: Request | None = None,
) -> SystemUpdateOut:
    asset = await _fetch_release(db, release_id)
    now = datetime.now(timezone.utc)
    meta = dict(asset.meta or {})
    meta["status"] = "published"
    meta["published_at"] = now.isoformat()
    if published_by:
        meta["published_by"] = published_by
    meta.pop("archived_at", None)
    meta.pop("archived_by", None)
    asset.meta = meta
    asset.is_current = True
    asset.updated_at = now

    release_out = _serialize_release(asset)
    release_out = _store_release_artifact(asset, release_out, generated_at=now)
    if release_out.status == "published":
        release_out = _store_release_distribution_manifest(asset, release_out, generated_at=now)
    await log_audit(
        db,
        "system.update_release.published",
        "system_update_release",
        str(asset.id),
        published_by,
        request,
        details=_release_audit_details(release_out),
    )
    await db.commit()
    await db.refresh(asset)
    return _serialize_release(asset)


async def activate_update_release(
    db: AsyncSession,
    release_id,
    *,
    activated_by: str | None = None,
    request: Request | None = None,
) -> SystemUpdateOut:
    asset = await _fetch_release(db, release_id)
    current_status = _release_status(asset)
    if current_status != "published":
        raise ValueError("Sadece yayınli surumler aktive edilebilir")

    now = datetime.now(timezone.utc)
    meta = dict(asset.meta or {})
    meta["status"] = "published"
    meta["distribution_status"] = "activated"
    meta["distribution_activated_at"] = now.isoformat()
    if activated_by:
        meta["distribution_activated_by"] = activated_by
    asset.meta = meta
    asset.is_current = True
    asset.updated_at = now

    release_out = _serialize_release(asset)
    superseded_release_ids = await _supersede_channel_releases(
        db,
        release_out,
        superseded_by=activated_by,
        superseded_at=now,
    )
    release_out = _store_release_distribution_manifest(asset, release_out, generated_at=now)
    release_out = _store_release_distribution_activation(
        asset,
        release_out,
        generated_at=now,
        activated_by=activated_by,
    )
    await log_audit(
        db,
        "system.update_release.distribution_activated",
        "system_update_release",
        str(asset.id),
        activated_by,
        request,
        details=_release_audit_details(release_out),
    )
    if superseded_release_ids:
        await log_audit(
            db,
            "system.update_release.distribution_superseded",
            "system_update_release",
            str(asset.id),
            activated_by,
            request,
            details={
                "version": release_out.version,
                "slug": release_out.slug,
                "channel": release_out.channel,
                "superseded_release_ids": superseded_release_ids,
            },
        )
    await db.commit()
    await db.refresh(asset)
    return _serialize_release(asset)


async def archive_update_release(
    db: AsyncSession,
    release_id,
    *,
    archived_by: str | None = None,
    request: Request | None = None,
) -> SystemUpdateOut:
    asset = await _fetch_release(db, release_id)
    now = datetime.now(timezone.utc)
    meta = dict(asset.meta or {})
    meta["status"] = "archived"
    meta["archived_at"] = now.isoformat()
    if archived_by:
        meta["archived_by"] = archived_by
    asset.meta = meta
    asset.is_current = False
    asset.updated_at = now

    release_out = _serialize_release(asset)
    release_out = _store_release_artifact(asset, release_out, generated_at=now)
    await log_audit(
        db,
        "system.update_release.archived",
        "system_update_release",
        str(asset.id),
        archived_by,
        request,
        details=_release_audit_details(release_out),
    )
    await db.commit()
    await db.refresh(asset)
    return _serialize_release(asset)
