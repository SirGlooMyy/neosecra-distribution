"""TP-Link Omada adapter — Omada SDN Controller API.

Supports TP-Link Omada Controller (OC200, OC300, software controller)
REST API. Uses Omada API login flow: POST to /api/v2/login for session token,
then Bearer auth for subsequent requests. Guest management via hotspot pass.
"""
from __future__ import annotations

import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class TplinkOmadaAdapter(FirewallAdapter):
    vendor = "tplink"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        self._base_url = f"https://{host}:{port}/api/v2"
        self._token = config.api_token or ""
        self._username = config.api_username or "admin"
        self._password = config.extra.get("password", "admin")
        self._headers = {"Content-Type": "application/json", "Accept": "application/json"}
        self._logged_in = False

    async def _login(self) -> None:
        if self._token:
            self._headers["Authorization"] = f"Bearer {self._token}"
            self._logged_in = True
            return
        url = f"{self._base_url}/login"
        payload = {"username": self._username, "password": self._password}
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=30.0) as client:
            resp = await client.post(url, json=payload)
        if resp.status_code >= 400:
            raise AdapterError(f"Omada login failed: HTTP {resp.status_code}")
        data = resp.json()
        token = data.get("result", {}).get("token", "")
        if not token:
            raise AdapterError("Omada login: no token in response")
        self._headers["Authorization"] = f"Bearer {token}"
        self._logged_in = True

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code == 401 and not self._logged_in:
            await self._login()
            async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
                resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"Omada {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    def _result(self, data: dict[str, Any]) -> dict[str, Any]:
        return data.get("result", data)

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=True,
            radius_authentication=True,
            radius_accounting=True,
            mac_auth_bypass=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            data = await self._request("GET", "controller/info")
            r = self._result(data)
            model = r.get("model", "?")
            version = r.get("swVersion", "?")
            return AdapterResult(
                ok=True,
                message=f"connected: Omada {model} v{version}",
                data={"model": model, "version": version},
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        data = await self._request("GET", "controller/info")
        r = self._result(data)
        return {
            "hostname": r.get("hostname", r.get("controllerName", "")),
            "model": r.get("model", ""),
            "serial_number": r.get("serialNumber", r.get("sn", "")),
            "firmware_version": r.get("swVersion", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "devices")
        r = self._result(data)
        raw = r.get("data", r) if isinstance(r, dict) else r
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for dev in raw:
            results.append({
                "name": dev.get("name", ""),
                "ip": dev.get("ip", ""),
                "model": dev.get("model", ""),
                "status": "up" if dev.get("status") == 1 else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._request("GET", "portal/portalSetting")
            r = self._result(data)
            return {
                "enabled": r.get("enable", False) if isinstance(r, dict) else False,
                "redirect_url": r.get("redirectUrl", "") if isinstance(r, dict) else "",
                "auth_mode": r.get("authMode", "") if isinstance(r, dict) else "",
            }
        except AdapterError:
            return {"enabled": False}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "portal/authorized")
        r = self._result(data)
        raw = r.get("data", r) if isinstance(r, dict) else r
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for s in raw:
            results.append({
                "ip": s.get("ip", ""),
                "user": s.get("userName", ""),
                "mac": s.get("mac", ""),
                "vlan": s.get("vlan"),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "clients/active")
        r = self._result(data)
        raw = r.get("data", r) if isinstance(r, dict) else r
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for c in raw:
            results.append({
                "ip": c.get("ip", ""),
                "mac": c.get("mac", ""),
                "device": c.get("deviceName", ""),
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        policy = self._guest_policy(session)
        payload = {
            "ip": ip,
            "mac": mac,
            "duration": session.get("duration", 240),
            "comment": self._guest_comment(session),
        }
        try:
            await self._request("POST", "portal/hotspot/pass", json=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={**payload, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "")
        try:
            await self._request("DELETE", f"portal/authorized/{mac}", params={"ip": ip})
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "tplink", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("host")
        parsed["event_type"] = parsed.get("type") or parsed.get("logtype")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        return parsed
