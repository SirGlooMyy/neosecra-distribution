import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class BanRuleCreate(BaseModel):
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    mac_address: str | None = Field(None, max_length=32)
    phone: str | None = Field(None, max_length=20)
    ip_address: str | None = Field(None, max_length=64)
    reason: str | None = None
    expires_at: datetime | None = None


class BanRuleUpdate(BaseModel):
    location_id: uuid.UUID | None = None
    reason: str | None = None
    expires_at: datetime | None = None


class BanRuleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    mac_address: str | None = None
    phone: str | None = None
    ip_address: str | None = None
    reason: str | None = None
    is_active: bool
    expires_at: datetime | None = None
    created_at: datetime


class WhitelistEntryCreate(BaseModel):
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    mac_address: str | None = Field(None, max_length=32)
    phone: str | None = Field(None, max_length=20)
    description: str | None = None


class WhitelistEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    mac_address: str | None = None
    phone: str | None = None
    description: str | None = None
    is_active: bool
    created_at: datetime
