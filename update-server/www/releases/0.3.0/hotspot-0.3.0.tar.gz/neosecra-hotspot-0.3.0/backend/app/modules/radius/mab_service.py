"""MAC Bypass (MAB) servisi — yetkili cihaz MAC whitelist yonetimi.

802.1X yapmayan cihazlarin MAC adresine gore aga erisimine izin verir.
"""
from __future__ import annotations

import logging
import uuid

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.radius.models import MdbWhitelist

log = logging.getLogger(__name__)


async def add_mac(
    db: AsyncSession,
    mac_address: str,
    description: str | None,
    customer_id: uuid.UUID,
) -> MdbWhitelist:
    """Whitelist'e yeni MAC adresi ekle.

    Args:
        db: Veritabani oturumu.
        mac_address: 17 karakter MAC (XX:XX:XX:XX:XX:XX).
        description: Aciklama.
        customer_id: Musteri ID.

    Returns:
        Olusturulan MdbWhitelist kaydi.
    """
    entry = MdbWhitelist(
        customer_id=customer_id,
        mac_address=mac_address.upper(),
        description=description,
    )
    db.add(entry)
    await db.commit()
    await db.refresh(entry)
    return entry


async def remove_mac(db: AsyncSession, mac_id: uuid.UUID) -> bool:
    """Whitelist'ten MAC adresini sil.

    Args:
        db: Veritabani oturumu.
        mac_id: Silinecek kaydin ID'si.

    Returns:
        True basarili, False kayit bulunamadi.
    """
    entry = await db.get(MdbWhitelist, mac_id)
    if not entry:
        return False
    await db.delete(entry)
    await db.commit()
    return True


async def list_macs(
    db: AsyncSession,
    customer_id: uuid.UUID,
    *,
    active_only: bool = False,
) -> list[MdbWhitelist]:
    """Musterinin MAC whitelist kayitlarini listele.

    Args:
        db: Veritabani oturumu.
        customer_id: Musteri ID.
        active_only: Sadece aktif kayitlar.

    Returns:
        MdbWhitelist kayit listesi.
    """
    q = select(MdbWhitelist).where(MdbWhitelist.customer_id == customer_id)
    if active_only:
        q = q.where(MdbWhitelist.is_active)
    q = q.order_by(MdbWhitelist.created_at.desc())
    res = await db.execute(q)
    return list(res.scalars().all())


async def is_mac_allowed(db: AsyncSession, mac_address: str) -> bool:
    """MAC adresinin whitelist'te olup olmadigini kontrol et.

    Args:
        db: Veritabani oturumu.
        mac_address: MAC adresi.

    Returns:
        True whitelist'te ve aktif.
    """
    mac = mac_address.upper()
    q = select(func.count()).select_from(MdbWhitelist).where(
        MdbWhitelist.mac_address == mac,
        MdbWhitelist.is_active,
    )
    count = (await db.execute(q)).scalar_one()
    return count > 0


async def import_macs(
    db: AsyncSession,
    mac_list: list[dict[str, str]],
    customer_id: uuid.UUID,
) -> int:
    """Toplu MAC adresi import et.

    Args:
        db: Veritabani oturumu.
        mac_list: [{"mac_address": "...", "description": "..."}, ...].
        customer_id: Musteri ID.

    Returns:
        Basariyla eklenen kayit sayisi.
    """
    count = 0
    for item in mac_list:
        mac = item.get("mac_address", "").strip().upper()
        if not mac or len(mac) < 12:
            continue
        desc = item.get("description", "").strip() or None
        try:
            entry = MdbWhitelist(
                customer_id=customer_id,
                mac_address=mac,
                description=desc,
            )
            db.add(entry)
            count += 1
        except Exception as exc:
            log.warning("MAC import hatasi (%s): %s", mac, exc)
    if count:
        await db.commit()
    return count
