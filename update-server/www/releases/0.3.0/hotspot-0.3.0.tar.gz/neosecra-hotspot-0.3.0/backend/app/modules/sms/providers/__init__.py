"""SMS provider registry.

Provider selection is stored per installation from the admin panel.  The
environment variables below remain a backwards-compatible fallback when no
panel configuration exists:
  - "console" (default) — logs code, no real delivery
  - "netgsm"   — Netgsm.com.tr (TR). Env: NETGSM_USERCODE, NETGSM_PASSWORD, NETGSM_MSGHEADER
  - "vatansms" — VatanSMS.com.tr (TR). Env: VATANSMS_API_KEY
  - "iletimerkezi" — İleti Merkezi JSON API. Env: ILETIMERKEZI_API_KEY, ILETIMERKEZI_API_HASH
  - "twilio"   — Twilio.com. Env: TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER
  - "muttl"    — Muttl.com. Env: MUTTL_API_KEY, MUTTL_API_URL
  - "relateddigital" — RelatedDigital.com. Env: RELATEDDIGITAL_API_KEY, RELATEDDIGITAL_API_URL
  - "http"     — Generic HTTP POST. Env: SMS_HTTP_URL, SMS_HTTP_TOKEN
"""

from .base import SmsProvider
from .netgsm import NetGSMProvider
from .vatansms import VatanSMSProvider
from .iletimerkezi import IletiMerkeziProvider
from .twilio import TwilioProvider
from .muttl import MuttlProvider
from .relateddigital import RelatedDigitalProvider
from .custom_http import CustomHttpProvider

__all__ = [
    "SmsProvider",
    "NetGSMProvider",
    "VatanSMSProvider",
    "IletiMerkeziProvider",
    "TwilioProvider",
    "MuttlProvider",
    "RelatedDigitalProvider",
    "CustomHttpProvider",
]

PROVIDER_MAP: dict[str, type[SmsProvider]] = {
    "netgsm": NetGSMProvider,
    "vatansms": VatanSMSProvider,
    "iletimerkezi": IletiMerkeziProvider,
    "twilio": TwilioProvider,
    "muttl": MuttlProvider,
    "relateddigital": RelatedDigitalProvider,
    "http": CustomHttpProvider,
}
