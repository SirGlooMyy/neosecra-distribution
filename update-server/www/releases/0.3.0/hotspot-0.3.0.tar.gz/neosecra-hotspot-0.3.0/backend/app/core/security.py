"""Security primitives: password hashing, JWT issue/decode, Redis-backed
token blacklist and login rate limiting.

User/role aware logic lives in app.modules.auth.deps; this module is the
stateless primitive layer it builds on.
"""
from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import uuid4

import redis.asyncio as redis
from jose import jwt
import bcrypt

# Workaround for passlib + bcrypt >= 4.0.0 compatibility bug on Python 3.12+
_original_hashpw = bcrypt.hashpw
def _patched_hashpw(password: bytes, salt: bytes) -> bytes:
    if len(password) > 72:
        password = password[:72]
    return _original_hashpw(password, salt)
bcrypt.hashpw = _patched_hashpw

from passlib.context import CryptContext

from app.core.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


_redis: redis.Redis | None = None


def _get_redis() -> redis.Redis:
    global _redis
    if _redis is None:
        _redis = redis.from_url(settings.REDIS_URL, decode_responses=True)
    return _redis


def get_redis() -> redis.Redis:
    """Public accessor for the shared Redis connection."""
    return _get_redis()


# --- Secure cookie config (for refresh token cookies) ---
SECURE_COOKIE_KWARGS: dict = {
    "httponly": True,
    "samesite": "lax",
    "secure": True,  # Must be True in production (HTTPS)
}


# --- Password hashing ---

def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


# --- JWT ---

def create_access_token(
    subject: str,
    extra: dict[str, Any] | None = None,
    expires_minutes: int | None = None,
) -> str:
    now = datetime.now(timezone.utc)
    exp = now + timedelta(minutes=expires_minutes or settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    payload: dict[str, Any] = {
        "sub": subject,
        "type": "access",
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
        "jti": str(uuid4()),
    }
    if extra:
        payload.update(extra)
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_refresh_token(subject: str) -> str:
    now = datetime.now(timezone.utc)
    exp = now + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    payload = {
        "sub": subject,
        "type": "refresh",
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
        "jti": str(uuid4()),
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def decode_token(token: str) -> dict[str, Any]:
    return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])


# --- Token blacklist (Redis) ---

async def blacklist_token(jti: str, expires_at: int) -> None:
    now = int(datetime.now(timezone.utc).timestamp())
    ttl = max(expires_at - now, 1)
    await _get_redis().setex(f"jwt:blacklist:{jti}", ttl, "1")


async def is_token_blacklisted(jti: str) -> bool:
    return bool(await _get_redis().get(f"jwt:blacklist:{jti}"))


# --- Rate limiting (Redis INCR + window) ---

async def rate_limit(key: str, max_attempts: int, window_seconds: int) -> tuple[bool, int]:
    """Generic fixed-window counter. Returns (blocked, attempts).

    Used by login (below) and by the SMS/captive flow (per-phone send limits).
    Blocks once attempts exceed max_attempts within the window."""
    r = _get_redis()
    redis_key = f"rl:{key}"
    attempts = await r.incr(redis_key)
    if attempts == 1:
        await r.expire(redis_key, window_seconds)
    return attempts > max_attempts, attempts


async def rate_limit_check(key: str) -> tuple[bool, int]:
    """Login-specific limit (kept for the auth module). Returns (blocked, attempts)."""
    return await rate_limit(
        key, settings.LOGIN_MAX_ATTEMPTS, settings.LOGIN_WINDOW_MINUTES * 60
    )


async def rate_limit_reset(key: str) -> None:
    await _get_redis().delete(f"rl:{key}")
