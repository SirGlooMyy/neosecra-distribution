"""PMS admin API endpoints.

Requires customer.read / customer.write permissions.
All PMS configs and custom sources are scoped to the caller's customer.
"""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.crypto import encrypt
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.pms import custom_service
from app.modules.pms.models import PmsConfig
from app.modules.pms.schemas import (
    PMS_VENDOR_META,
    CustomSourceCreate,
    CustomSourceOut,
    CustomSourceUpdate,
    PmsConfigOut,
    PmsConfigUpdate,
    PmsVerifyResult,
)
from app.modules.pms.service import PMS_VENDORS, verify_guest_stay

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu islem icin gerekli yetkiye sahip degilsiniz",
        )


async def _get_customer_id(
    db: AsyncSession,
    user: User,
    requested: uuid.UUID | None = None,
) -> uuid.UUID | None:
    scope = scope_for(user)
    if scope.level.name == "GLOBAL":
        # The deployment is single-installation (with multiple locations), so
        # the admin UI must not be forced to manufacture a customer_id for
        # every PMS request. Keep an explicit id for backwards compatibility,
        # otherwise resolve the installation's active customer automatically.
        return await resolve_installation_customer(db, requested)
    cid = scope.customer_id
    if not cid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Kullaniciya bagli musteri bulunamadi",
        )
    return cid


# ---- Vendor list ------------------------------------------------------------

@router.get("/vendors", summary="List supported PMS vendors and their descriptions", description="Returns all supported Property Management System (PMS) vendors with metadata including connection types and features. Useful for configuring PMS integration. Requires the customer.read permission.")
async def list_vendors(user: User = Depends(get_current_user)):
    _require(user, "customer.read")
    return {"vendors": PMS_VENDOR_META}


# ---- PMS Config -------------------------------------------------------------

@router.get("/config", response_model=PmsConfigOut | None, summary="Get PMS configuration for the customer", description="Returns the Property Management System (PMS) configuration for the authenticated user's customer. Includes connection settings and active status. Requires the customer.read permission.")
async def get_pms_config(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    customer_id = await _get_customer_id(db, user, customer_id)
    if customer_id is None:
        return None
    result = await db.execute(
        select(PmsConfig).where(PmsConfig.customer_id == customer_id)
    )
    config = result.scalar_one_or_none()
    return config


@router.put("/config", response_model=PmsConfigOut, summary="Create or update PMS configuration", description="Creates or updates the Property Management System (PMS) connection configuration. Sensitive fields such as passwords and API keys are encrypted before storage. Requires the customer.write permission.")
async def update_pms_config(
    body: PmsConfigUpdate,
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    customer_id = await _get_customer_id(db, user, customer_id)
    if customer_id is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Super Admin must specify customer_id")

    result = await db.execute(
        select(PmsConfig).where(PmsConfig.customer_id == customer_id)
    )
    config = result.scalar_one_or_none()

    if not config:
        config = PmsConfig(customer_id=customer_id)
        db.add(config)

    patch = body.model_dump(exclude_unset=True)

    if "api_key" in patch and patch["api_key"]:
        config.api_key_enc = encrypt(patch.pop("api_key"))  # type: ignore[assignment]
    patch.pop("api_key", None)

    if "password" in patch and patch["password"]:
        config.password_enc = encrypt(patch.pop("password"))  # type: ignore[assignment]
    patch.pop("password", None)

    if "db_password" in patch and patch["db_password"]:
        config.db_password_enc = encrypt(patch.pop("db_password"))  # type: ignore[assignment]
    patch.pop("db_password", None)

    for field, value in patch.items():
        if hasattr(config, field):
            setattr(config, field, value)

    config.updated_at = None  # type: ignore[assignment] # trigger onupdate
    await db.flush()
    await db.refresh(config)
    return config


# ---- Test Connection --------------------------------------------------------

@router.post("/test-connection", response_model=dict)
async def test_pms_connection_legacy(
    vendor: str = Query("mock"),
    room_number: str = Query("DEMO"),
    surname: str = Query("DEMO"),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Backward-compatible route used by older admin bundles."""
    _require(user, "customer.read")
    resolved = await _get_customer_id(db, user, customer_id)
    if resolved is None:
        return {"vendor": vendor, "verified": False, "message": "Müşteri seçilmedi"}
    return await test_pms_connection(
        vendor=vendor,
        room_number=room_number,
        surname=surname,
        customer_id=resolved,
        db=db,
        user=user,
    )

@router.post("/test/{vendor}", response_model=dict, summary="Test PMS connection with a guest lookup", description="Tests the PMS connection by performing a guest lookup with the specified room number and surname. Returns verification status and guest details. Useful for validating PMS configuration. Requires the customer.read permission.")
async def test_pms_connection(
    vendor: str,
    room_number: str = Query(..., description="Test oda numarasi"),
    surname: str = Query(..., description="Test soyad"),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.read")
    customer_id = await _get_customer_id(db, user, customer_id)
    if customer_id is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Super Admin must specify customer_id")

    if vendor not in PMS_VENDORS and vendor != "mock":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Desteklenmeyen PMS vendor: {vendor}. Secenekler: {', '.join(PMS_VENDORS.keys())}",
        )

    result = await db.execute(
        select(PmsConfig).where(PmsConfig.customer_id == customer_id)
    )
    config_row = result.scalar_one_or_none()

    pms_config = {"pms_type": vendor}
    if config_row and config_row.is_active:  # type: ignore[union-attr]
        pms_config["host"] = config_row.host  # type: ignore[union-attr]
        pms_config["port"] = config_row.port  # type: ignore[union-attr]
        pms_config["username"] = config_row.username  # type: ignore[union-attr]
        pms_config["db_host"] = config_row.db_host  # type: ignore[union-attr]
        pms_config["db_port"] = config_row.db_port  # type: ignore[union-attr]
        pms_config["db_name"] = config_row.db_name  # type: ignore[union-attr]
        pms_config["db_user"] = config_row.db_user  # type: ignore[union-attr]

    result_data = await verify_guest_stay(room_number, surname, pms_config)

    return {
        "vendor": vendor,
        "verified": result_data.verified,
        "guest_name": result_data.guest_name,
        "check_in": str(result_data.check_in) if result_data.check_in else None,
        "check_out": str(result_data.check_out) if result_data.check_out else None,
        "stay_status": result_data.stay_status,
        "message": result_data.message,
    }


# ---- Custom Sources ---------------------------------------------------------

@router.get("/custom-sources", response_model=list[CustomSourceOut], summary="List PMS custom data sources", description="Returns all custom PMS data sources configured for the customer. Custom sources allow integrating with non-standard PMS systems via custom queries. Requires the customer.read permission.")
async def list_custom_sources(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.read")
    customer_id = await _get_customer_id(db, user, customer_id)
    if customer_id is None:
        # Platform admins may open this page before choosing a customer.
        # An empty collection is a valid state, not a failed request.
        return []
    return await custom_service.list_sources(db, customer_id)


@router.post("/custom-sources", response_model=CustomSourceOut, status_code=status.HTTP_201_CREATED, summary="Create a custom PMS data source", description="Adds a new custom data source for PMS integration with custom query configuration. Useful for connecting to non-standard property management systems. Requires the customer.write permission.")
async def create_custom_source(
    body: CustomSourceCreate,
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    customer_id = await _get_customer_id(db, user, customer_id)
    if customer_id is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Super Admin must specify customer_id")
    source = await custom_service.create_source(
        db,
        {
            "customer_id": customer_id,
            **body.model_dump(),
        },
    )
    return source


@router.put("/custom-sources/{source_id}", response_model=CustomSourceOut, summary="Update a custom PMS data source", description="Updates the configuration of an existing custom PMS data source. Supports modifying query parameters and connection details. Requires the customer.write permission.")
async def update_custom_source(
    source_id: uuid.UUID,
    body: CustomSourceUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    source = await custom_service.update_source(db, source_id, body.model_dump(exclude_unset=True))
    if not source:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kaynak bulunamadi")
    return source


@router.delete("/custom-sources/{source_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete a custom PMS data source", description="Permanently removes the specified custom PMS data source. Queries using this source will no longer function. Requires the customer.write permission.")
async def delete_custom_source(
    source_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    deleted = await custom_service.delete_source(db, source_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kaynak bulunamadi")


@router.post("/custom-sources/{source_id}/test", response_model=PmsVerifyResult, summary="Test a custom PMS data source with guest lookup", description="Tests the specified custom PMS data source by performing a guest lookup with room number and surname. Returns verification status and guest details. Requires the customer.read permission.")
async def test_custom_source(
    source_id: uuid.UUID,
    room_number: str = Query(..., description="Test oda numarasi"),
    surname: str = Query(..., description="Test soyad"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.read")
    return await custom_service.query_custom_source(db, source_id, room_number, surname)
