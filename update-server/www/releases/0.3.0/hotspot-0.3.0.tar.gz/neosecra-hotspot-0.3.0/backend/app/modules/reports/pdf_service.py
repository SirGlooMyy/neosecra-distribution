"""PDF generation service — reportlab preferred, weasyprint fallback.
"""
from __future__ import annotations

import io
import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        PageBreak,
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )
    import weasyprint

log = logging.getLogger(__name__)

_REPORTLAB_AVAIL = False
_WEASYPRINT_AVAIL = False

try:
    from reportlab.lib.pagesizes import A4, landscape  # type: ignore[misc] # noqa: F401
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle  # type: ignore[misc] # noqa: F401
    from reportlab.lib.units import cm  # type: ignore[misc] # noqa: F401
    from reportlab.platypus import (  # type: ignore[misc] # noqa: F401
        Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak,
    )
    from reportlab.lib import colors  # type: ignore[misc] # noqa: F401
    _REPORTLAB_AVAIL = True
except ImportError:
    _REPORTLAB_AVAIL = False

try:
    import weasyprint  # noqa: F401
    _WEASYPRINT_AVAIL = True
except ImportError:
    _WEASYPRINT_AVAIL = False


def render_report_to_pdf(report_data: dict, template_name: str = "session_report") -> bytes:
    """Render report data to PDF bytes. Uses reportlab by default, weasyprint fallback."""
    if _REPORTLAB_AVAIL:
        return _render_reportlab(report_data, template_name)
    if _WEASYPRINT_AVAIL:
        return _render_weasyprint(report_data, template_name)
    raise RuntimeError(
        "PDF olusturmak icin reportlab veya weasyprint kurulu olmali. "
        "pip install reportlab veya pip install weasyprint"
    )


def _render_reportlab(report_data: dict, template_name: str) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title="Hotspot Report")
    styles = getSampleStyleSheet()
    elems = []

    title = report_data.get("title", "Hotspot Platform Report")
    elems.append(Paragraph(title, styles["Title"]))
    elems.append(Spacer(1, 0.5 * cm))

    period_start = report_data.get("period_start", "")
    period_end = report_data.get("period_end", "")
    generated_at = report_data.get("generated_at", datetime.now(timezone.utc).isoformat())
    elems.append(Paragraph(f"Donem: {period_start} - {period_end}", styles["Normal"]))
    elems.append(Paragraph(f"Olusturulma: {generated_at}", styles["Normal"]))
    elems.append(Spacer(1, 0.5 * cm))

    sessions = report_data.get("sessions", {})
    if sessions:
        elems.append(Paragraph("Session Summary", styles["Heading2"]))
        _add_summary_table(elems, sessions, styles)

    syslog_data = report_data.get("syslog", {})
    if syslog_data:
        elems.append(Spacer(1, 0.5 * cm))
        elems.append(Paragraph("Syslog Summary", styles["Heading2"]))
        _add_summary_table(elems, syslog_data, styles)

    detail = report_data.get("sessions_detail", [])
    if detail:
        elems.append(PageBreak())
        elems.append(Paragraph("Session Details", styles["Heading2"]))
        _add_detail_table(elems, detail)

    doc.build(elems)
    return buf.getvalue()


def _add_summary_table(elems: list, data: dict, styles) -> None:
    rows = [["Metric", "Value"]]
    for k, v in data.items():
        if isinstance(v, (int, float)):
            rows.append([k.replace("_", " ").title(), str(v)])
        elif isinstance(v, dict):
            for sk, sv in v.items():
                rows.append([f"  {sk}", str(sv)])
    if len(rows) > 1:
        t = Table(rows, repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        elems.append(t)


def _add_detail_table(elems: list, detail: list) -> None:
    if not detail:
        return
    headers = list(detail[0].keys())
    rows = [headers]
    for item in detail:
        rows.append([str(item.get(h, ""))[:30] for h in headers])

    t = Table(rows, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    elems.append(t)


def _render_weasyprint(report_data: dict, template_name: str) -> bytes:
    html = _render_html_template(template_name, report_data)
    pdf_bytes = weasyprint.HTML(string=html).write_pdf()
    if pdf_bytes is None:
        raise RuntimeError("weasyprint PDF uretemedi")
    return pdf_bytes


def _render_html_template(template_name: str, data: dict) -> str:
    sessions = data.get("sessions", {})
    syslog_data = data.get("syslog", {})
    detail = data.get("sessions_detail", [])

    detail_rows = ""
    for s in detail:
        detail_rows += f"""<tr>
            <td>{s.get('mac', '')}</td>
            <td>{s.get('ip', '')}</td>
            <td>{s.get('phone', '')}</td>
            <td>{s.get('auth_method', '')}</td>
            <td>{s.get('status', '')}</td>
            <td>{s.get('started_at', '')[:19]}</td>
        </tr>
"""

    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
body {{ font-family: DejaVu Sans, sans-serif; font-size: 11px; }}
h1 {{ color: #1f2937; }}
table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
th, td {{ border: 1px solid #ccc; padding: 6px; text-align: left; }}
th {{ background: #1f2937; color: white; }}
</style></head><body>
<h1>{data.get('title', 'Hotspot Platform Report')}</h1>
<p><strong>Donem:</strong> {data.get('period_start', '')} - {data.get('period_end', '')}</p>
<p><strong>Olusturulma:</strong> {data.get('generated_at', '')}</p>
<h2>Session Summary</h2>
<table>
<tr><th>Metric</th><th>Value</th></tr>
<tr><td>Total</td><td>{sessions.get('total', 0)}</td></tr>
<tr><td>Bytes Total</td><td>{sessions.get('bytes_total', 0)}</td></tr>
<tr><td>Avg Duration</td><td>{sessions.get('avg_duration_seconds', 0):.1f}s</td></tr>
</table>
<h2>Syslog Summary</h2>
<table>
<tr><th>Metric</th><th>Value</th></tr>
<tr><td>Total</td><td>{syslog_data.get('total', 0)}</td></tr>
</table>
<h2>Session Details</h2>
<table>
<tr><th>MAC</th><th>IP</th><th>Phone</th><th>Method</th><th>Status</th><th>Started</th></tr>
{detail_rows}
</table>
</body></html>"""


def generate_5651_pdf(archive_data: dict) -> bytes:
    """5651-compliant PDF with hash chain information."""
    if _REPORTLAB_AVAIL:
        return _render_5651_reportlab(archive_data)
    if _WEASYPRINT_AVAIL:
        return _render_5651_weasyprint(archive_data)
    raise RuntimeError("PDF kutuphanesi yok")


def _render_5651_reportlab(data: dict) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title="5651 Archive Report")
    styles = getSampleStyleSheet()
    elems = []

    elems.append(Paragraph("5651 Log Archive Report", styles["Title"]))
    elems.append(Spacer(1, 0.5 * cm))

    rows = [["Field", "Value"]]
    for k, v in data.items():
        if isinstance(v, str):
            rows.append([k.replace("_", " ").title(), v[:80]])

    t = Table(rows, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ]))
    elems.append(t)
    doc.build(elems)
    return buf.getvalue()


def _render_5651_weasyprint(data: dict) -> bytes:
    rows = ""
    for k, v in data.items():
        rows += f"<tr><td>{k}</td><td>{str(v)[:80]}</td></tr>\n"
    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
body {{ font-family: DejaVu Sans, sans-serif; font-size: 11px; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #ccc; padding: 6px; text-align: left; }}
th {{ background: #1f2937; color: white; }}
</style></head><body>
<h1>5651 Log Archive Report</h1>
<table><tr><th>Field</th><th>Value</th></tr>{rows}</table>
</body></html>"""
    pdf_bytes = weasyprint.HTML(string=html).write_pdf()
    if pdf_bytes is None:
        raise RuntimeError("weasyprint PDF uretemedi")
    return pdf_bytes


def generate_session_report_pdf(sessions: list, period: dict) -> bytes:
    """Generate PDF from session list and period info."""
    data = {
        "title": "Session Report",
        "period_start": period.get("start", ""),
        "period_end": period.get("end", ""),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "sessions": {
            "total": len(sessions),
            "bytes_total": sum(int(s.get("bytes_in", 0) or 0) + int(s.get("bytes_out", 0) or 0) for s in sessions),
        },
        "sessions_detail": sessions,
    }
    return render_report_to_pdf(data, "session_report")
