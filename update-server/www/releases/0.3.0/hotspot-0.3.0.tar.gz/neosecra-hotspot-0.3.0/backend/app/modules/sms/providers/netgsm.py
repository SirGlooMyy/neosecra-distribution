import httpx
import base64
import json
from app.core.config import settings
from .base import SmsProvider

NETGSM_REST_URL = "https://api.netgsm.com.tr/sms/rest/v2/send"


class NetGSMProvider(SmsProvider):
    async def send(self, phone: str, message: str) -> tuple[bool, str | None]:
        usercode = self.value("username", settings.NETGSM_USERCODE or settings.NETGSM_USER)
        password = self.value("password", settings.NETGSM_PASSWORD or settings.NETGSM_PASS)
        msgheader = self.value("sender", settings.NETGSM_MSGHEADER or settings.SMS_SENDER)
        options = self.config.get("provider_options") or {}

        if not usercode or not password:
            return False, "netgsm-missing-credentials"

        # NetGSM REST v2 expects Basic Auth and a JSON array of messages.
        # Their examples use 905xxxxxxxxx (without the leading '+').
        number = phone.lstrip("+")
        payload = {
            "msgheader": msgheader,
            "messages": [{"msg": message, "no": number}],
            "encoding": str(options.get("encoding") or "TR").upper(),
            "iysfilter": str(options.get("iysfilter") or "0"),
        }
        if options.get("appname"):
            payload["appname"] = str(options["appname"])
        for key in ("startdate", "stopdate"):
            if options.get(key):
                payload[key] = str(options[key])
        url = str(options.get("endpoint") or NETGSM_REST_URL)
        token = base64.b64encode(f"{usercode}:{password}".encode()).decode()
        headers = {"Authorization": f"Basic {token}", "Content-Type": "application/json"}
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json=payload, headers=headers)
            if 200 <= resp.status_code < 300:
                try:
                    data = resp.json()
                except (ValueError, json.JSONDecodeError):
                    data = {}
                code = str(data.get("code") or "").strip()
                if code == "00":
                    return True, str(data.get("jobid") or data.get("jobId") or "") or None
                description = str(data.get("description") or data.get("message") or "unknown")
                return False, f"netgsm-{code or 'error'}:{description[:120]}"
            return False, f"netgsm-http-{resp.status_code}"
        except httpx.TimeoutException:
            return False, "netgsm-timeout"
        except httpx.RequestError as exc:
            return False, f"netgsm-request-error:{type(exc).__name__}"
