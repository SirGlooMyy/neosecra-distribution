"""Celery worker DB runtime.

Celery tasks are SYNC and each task runs its coroutine via asyncio.run, which
means a fresh event loop per invocation. asyncpg connections bind to the loop
they were created on, so reusing the app's QueuePool engine across loops raises
"attached to a different event loop". We therefore give the worker its own
engine with NullPool — connections are created and discarded per use, never
handed across loops (safe under per-task asyncio.run).

This is the ONLY place a NullPool async engine is created; the FastAPI app keeps
its pooled engine in core.database for request-scoped use.
"""
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from app.core.config import settings

worker_engine = create_async_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    poolclass=NullPool,
)

WorkerSession = async_sessionmaker(
    worker_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)
