"""Public marketing content endpoints.

These endpoints are intentionally auth-free. They back the product marketing
pages, versioned downloads and partner/trial inquiry capture.
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.rbac import has_permission
from app.core.database import get_db
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.public_content import service
from app.modules.public_content.schemas import (
    PublicAssetOut,
    PublicAssetUpsert,
    PublicInquiryCreate,
    PublicInquiryOut,
    PublicInquiryStatusUpdate,
    PublicMarketplaceOut,
    PublicTrialProvisionOut,
)
from app.modules.system import update_service

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


def _http_error_for_value_error(exc: ValueError) -> HTTPException:
    detail = str(exc)
    if detail == "Icerik bulunamadi":
        code = status.HTTP_404_NOT_FOUND
    elif detail == "Ayni slug ve surum zaten kullaniliyor":
        code = status.HTTP_409_CONFLICT
    else:
        code = status.HTTP_400_BAD_REQUEST
    return HTTPException(status_code=code, detail=detail)


@router.get("/marketplace", response_model=PublicMarketplaceOut, summary="Get public marketplace snapshot with product info", description="Returns the public marketplace snapshot including available products, pricing tiers, and feature highlights. This endpoint is intentionally auth-free for marketing pages.")
async def get_marketplace(db: AsyncSession = Depends(get_db)):
    return await service.get_marketplace_snapshot(db)


@router.post("/inquiries", response_model=PublicInquiryOut, status_code=status.HTTP_201_CREATED, summary="Submit a public inquiry form for sales or support", description="Accepts public inquiry submissions from the marketing website for sales, partnership, or trial requests. This endpoint is intentionally auth-free. Returns the created inquiry record.")
async def create_inquiry(body: PublicInquiryCreate, db: AsyncSession = Depends(get_db)):
    return await service.submit_public_inquiry(db, body)


@router.get("/inquiries", response_model=list[PublicInquiryOut], summary="List public inquiries with status and type filters", description="Returns a paginated list of public inquiries with optional type and status filters. Used by admin staff to manage sales and trial requests. Requires the system.read permission.")
async def list_inquiries(
    inquiry_type: str | None = Query(None),
    status_filter: str | None = Query(None, alias="status"),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    return await service.list_public_inquiries(
        db,
        inquiry_type=inquiry_type,
        status=status_filter,
        limit=limit,
        offset=offset,
    )


@router.patch("/inquiries/{inquiry_id}", response_model=PublicInquiryOut, summary="Update the status of a public inquiry", description="Updates the processing status of a public inquiry (e.g., new, contacted, converted, closed). Used by admin staff to track inquiry lifecycle. Requires the system.write permission.")
async def update_inquiry_status(
    inquiry_id: uuid.UUID,
    body: PublicInquiryStatusUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await service.update_public_inquiry_status(db, inquiry_id, status=body.status)
    except ValueError as exc:
        raise _http_error_for_value_error(exc)


@router.post("/inquiries/{inquiry_id}/provision-trial", response_model=PublicTrialProvisionOut, summary="Provision a trial environment for an inquiry", description="Creates a fully provisioned trial environment for the specified inquiry. Sets up a tenant, customer, and demo configuration for the trial period. Requires the system.write permission.")
async def provision_trial_inquiry(
    inquiry_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await service.provision_trial_environment(
            db,
            inquiry_id,
            actor_id=user.id,
            request=request,
        )
    except ValueError as exc:
        raise _http_error_for_value_error(exc)


@router.post("/inquiries/{inquiry_id}/renew-trial", response_model=PublicTrialProvisionOut, summary="Renew or extend a trial environment", description="Extends the trial period for an existing provisioned environment by the specified number of extra days. Useful for trial extension requests. Requires the system.write permission.")
async def renew_trial_inquiry(
    inquiry_id: uuid.UUID,
    request: Request,
    extra_days: int = Query(14, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await service.renew_trial_environment(
            db,
            inquiry_id,
            actor_id=user.id,
            extra_days=extra_days,
            request=request,
        )
    except ValueError as exc:
        raise _http_error_for_value_error(exc)


@router.get("/assets", response_model=list[PublicAssetOut], summary="List public content assets with section filter", description="Returns all public content assets such as documentation, KB articles, and downloads. Optionally filtered by section. Requires the system.read permission.")
async def list_assets(
    section: str | None = Query(None),
    include_inactive: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    return await service.list_public_assets_admin(
        db,
        section=section,
        include_inactive=include_inactive,
    )


@router.get("/assets/search", response_model=list[PublicAssetOut], summary="Search public content assets by query", description="Searches public content assets with full-text query support. Supports filtering by section, KB type, and workflow status. Useful for knowledge base and documentation search. Requires the system.read permission.")
async def search_assets(
    q: str | None = Query(None),
    section: str | None = Query("kb"),
    include_inactive: bool = Query(True),
    kb_type: str | None = Query(None),
    workflow_status: str | None = Query(None),
    limit: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    return await service.search_public_assets(
        db,
        query=q,
        section=section,
        include_inactive=include_inactive,
        kb_type=kb_type,
        workflow_status=workflow_status,
        limit=limit,
    )


@router.post("/assets", response_model=PublicAssetOut, status_code=status.HTTP_201_CREATED, summary="Create a new public content asset", description="Creates a new content asset for the public-facing site such as a KB article, documentation page, or download entry. Requires the system.write permission.")
async def create_asset(
    body: PublicAssetUpsert,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    return await service.upsert_public_asset(db, body)


@router.put("/assets/{asset_id}", response_model=PublicAssetOut, summary="Update an existing public content asset", description="Updates the content and metadata of the specified public asset. Supports changing section, content body, and SEO metadata. Requires the system.write permission.")
async def update_asset(
    asset_id: uuid.UUID,
    body: PublicAssetUpsert,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await service.upsert_public_asset(db, body, asset_id=asset_id)
    except ValueError as exc:
        raise _http_error_for_value_error(exc)


@router.patch("/assets/{asset_id}/archive", response_model=PublicAssetOut, summary="Archive a public content asset", description="Archives the specified public asset, removing it from active display while preserving the content. Archived assets can be restored. Requires the system.write permission.")
async def archive_asset(
    asset_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await service.archive_public_asset(db, asset_id)
    except ValueError as exc:
        raise _http_error_for_value_error(exc)


@router.get("/assets/{asset_id}/suggestions", response_model=list[PublicAssetOut], summary="Suggest related KB assets for an article", description="Returns related knowledge base article suggestions based on content similarity to the specified asset. Useful for cross-linking and discovery. Requires the system.read permission.")
async def suggest_asset_relations(
    asset_id: uuid.UUID,
    limit: int = Query(5, ge=1, le=12),
    include_inactive: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    return await service.suggest_public_kb_assets(
        db,
        asset_id=asset_id,
        include_inactive=include_inactive,
        limit=limit,
    )


@router.get("/downloads/{slug}/download", summary="Download a public asset by slug and version", description="Downloads the specified public asset bundle as a ZIP file. Asset versioning allows access to specific releases. This endpoint is intentionally auth-free for public distribution.")
async def download_asset(
    slug: str,
    version: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
):
    asset = await service.get_download_asset(db, slug=slug, version=version)
    if not asset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="İndirme paketi bulunamadı")

    bundle, filename = service.build_download_bundle(asset)
    return Response(
        content=bundle,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/releases/{slug}/download", summary="Download a release bundle by slug and version", description="Downloads the specified release bundle as a ZIP file. Includes release artifacts and metadata. This endpoint is intentionally auth-free for public distribution.")
async def download_release_bundle(
    slug: str,
    version: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
):
    asset = await service.get_release_asset(db, slug=slug, version=version)
    if not asset:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Yayın notu bulunamadı")

    bundle, filename = update_service.get_release_bundle_payload(asset)
    return Response(
        content=bundle,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/releases/{slug}/history", response_model=list[PublicAssetOut], summary="List release history for a product slug", description="Returns the version history of public releases for the specified product slug. Optionally includes draft releases. This endpoint is intentionally auth-free.")
async def list_release_history(
    slug: str,
    include_drafts: bool = Query(False),
    db: AsyncSession = Depends(get_db),
):
    return await service.list_public_release_history(db, slug=slug, include_drafts=include_drafts)
