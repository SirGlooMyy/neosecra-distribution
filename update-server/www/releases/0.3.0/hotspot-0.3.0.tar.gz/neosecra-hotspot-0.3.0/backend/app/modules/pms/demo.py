"""Explicit demo-mode helpers for PMS vendor integrations."""
from __future__ import annotations

from collections.abc import Awaitable, Callable

from app.core.config import settings
from app.modules.pms.schemas import PmsVerifyResult


async def demo_or_fail(
    *,
    vendor: str,
    room_number: str,
    surname_or_birth: str,
    mock_fn: Callable[[str, str], Awaitable[dict]],
    missing_config_message: str,
) -> PmsVerifyResult:
    """Return mock PMS data only in explicit demo mode; otherwise fail closed."""
    if settings.DEMO_MODE:
        data = await mock_fn(room_number, surname_or_birth)
        return PmsVerifyResult(
            verified=data["verified"],
            guest_name=data.get("guest_name"),
            check_in=data.get("check_in"),
            check_out=data.get("check_out"),
            stay_status=data.get("stay_status"),
            vendor=vendor,
            message=(
                f"Mock mod ({missing_config_message})"
                if not data["verified"]
                else None
            ),
        )

    return PmsVerifyResult(
        verified=False,
        guest_name=None,
        check_in=None,
        check_out=None,
        stay_status=None,
        vendor=vendor,
        message=missing_config_message,
    )
