"""Captive Portal MFA integration: extend portal flow with MFA step."""
from __future__ import annotations

import uuid

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.mfa.models import PortalMfaConfig
from app.modules.mfa.service import verify_mfa_code as _verify_mfa_code


async def create_portal_config(
    db: AsyncSession,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    *,
    mfa_method: str = "sms",
    require_mfa_after: str | None = None,
) -> PortalMfaConfig:
    config = PortalMfaConfig(
        customer_id=customer_id,
        location_id=location_id,
        is_enabled=True,
        mfa_method=mfa_method,
        require_mfa_after=require_mfa_after,
    )
    db.add(config)
    await db.flush()
    await db.refresh(config)
    return config


async def update_portal_config(
    db: AsyncSession,
    config_id: uuid.UUID,
    **updates,
) -> PortalMfaConfig:
    config = await db.get(PortalMfaConfig, config_id)
    if not config:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portal MFA yapilandirmasi bulunamadi",
        )

    for key in ("is_enabled", "mfa_method", "require_mfa_after"):
        if key in updates:
            setattr(config, key, updates[key])
    await db.flush()
    await db.refresh(config)
    return config


async def get_portal_config(
    db: AsyncSession,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
) -> PortalMfaConfig | None:
    if location_id:
        config = (
            await db.execute(
                select(PortalMfaConfig).where(
                    PortalMfaConfig.customer_id == customer_id,
                    PortalMfaConfig.location_id == location_id,
                    PortalMfaConfig.is_enabled.is_(True),
                )
            )
        ).scalar_one_or_none()
        if config:
            return config

    return (
        await db.execute(
            select(PortalMfaConfig).where(
                PortalMfaConfig.customer_id == customer_id,
                PortalMfaConfig.location_id.is_(None),
                PortalMfaConfig.is_enabled.is_(True),
            )
        )
    ).scalar_one_or_none()


async def extend_portal_flow(method: str) -> dict:
    """Return MFA step metadata to include in the portal auth flow."""
    supported_methods = {
        "sms": "SMS ile MFA dogrulama",
        "totp": "TOTP uygulamasi ile MFA dogrulama",
        "whatsapp": "WhatsApp ile MFA dogrulama",
        "email": "E-posta ile MFA dogrulama",
    }

    if method not in supported_methods:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Desteklenmeyen portal MFA yontemi: {method}",
        )

    return {
        "mfa_required": True,
        "mfa_method": method,
        "mfa_label": supported_methods[method],
        "mfa_step": "after_primary_auth",
    }


async def verify_portal_mfa(
    db: AsyncSession,
    session_token: str,
    code: str,
    request=None,
) -> bool:
    return await _verify_mfa_code(db, session_token, code, request)
