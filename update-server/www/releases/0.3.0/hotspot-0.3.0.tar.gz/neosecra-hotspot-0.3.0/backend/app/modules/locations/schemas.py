"""Pydantic schemas for locations."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class LocationBase(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    address: str | None = None
    city: str | None = None
    default_ssid: str | None = None
    timezone: str | None = None


class LocationCreate(LocationBase):
    # Single-installation API: ownership is inferred when omitted.
    customer_id: uuid.UUID | None = None


class LocationUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    address: str | None = None
    city: str | None = None
    default_ssid: str | None = None
    timezone: str | None = None
    is_active: bool | None = None


class LocationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    customer_id: uuid.UUID
    name: str
    address: str | None
    city: str | None
    default_ssid: str | None
    timezone: str | None
    is_active: bool
    created_at: datetime
    updated_at: datetime
