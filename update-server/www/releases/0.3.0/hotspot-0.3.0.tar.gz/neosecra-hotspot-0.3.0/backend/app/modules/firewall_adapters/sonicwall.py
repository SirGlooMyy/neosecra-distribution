"""SonicWall adapter — SonicOS REST API.

Uses the SonicOS REST API at /api/sonicos/. Supports both
SonicOS 6.x and 7.x API patterns. Auth via API key or Basic auth.
"""
from __future__ import annotations

import base64
import re
import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class SonicWallAdapter(FirewallAdapter):
    vendor = "sonicwall"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        self._base_url = f"https://{host}:{port}/api/sonicos"
        token = config.api_token or ""
        username = config.api_username or "admin"
        auth_raw = base64.b64encode(f"{username}:{token}".encode()).decode()
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Basic {auth_raw}",
        }

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"SonicWall {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        data = resp.json()
        if isinstance(data, dict) and data.get("status", {}).get("code") != 200:
            msg = data.get("status", {}).get("message", "sonicos error")
            raise AdapterError(f"SonicWall {path}: {msg}")
        return data

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            radius_authentication=True,
            radius_accounting=True,
            mac_auth_bypass=True,
            active_session_query=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            data = await self._request("GET", "system/info")
            sys_info = data.get("system_info", {})
            model = sys_info.get("model", "?")
            serial = sys_info.get("serial", "?")
            fw = sys_info.get("firmware_version", "?")
            return AdapterResult(
                ok=True,
                message=f"connected: {model} SN:{serial} FW:{fw}",
                data={"model": model, "serial": serial, "firmware": fw},
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        data = await self._request("GET", "system/info")
        sys = data.get("system_info", {})
        return {
            "hostname": sys.get("name", ""),
            "model": sys.get("model", ""),
            "serial_number": sys.get("serial", ""),
            "firmware_version": sys.get("firmware_version", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "interfaces")
        results: list[dict[str, Any]] = []
        for iface in data.get("interfaces", []):
            results.append({
                "name": iface.get("name", ""),
                "ip": iface.get("ip", {}).get("address", ""),
                "type": iface.get("type", ""),
                "zone": iface.get("zone", ""),
                "status": "up" if iface.get("status") == "up" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._request("GET", "captive-portal")
            cp = data.get("captive_portal", {})
            return {
                "enabled": cp.get("enable", False),
                "redirect_url": cp.get("redirect_url", ""),
                "auth_page": cp.get("auth_page", ""),
            }
        except AdapterError:
            return {"enabled": False}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "report/connections")
        results: list[dict[str, Any]] = []
        for conn in data.get("connections", []):
            results.append({
                "ip": conn.get("src_ip", ""),
                "user": conn.get("user", ""),
                "protocol": conn.get("protocol", ""),
                "src_port": conn.get("src_port"),
                "dst_port": conn.get("dst_port"),
                "state": conn.get("state", ""),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "report/arp")
        results: list[dict[str, Any]] = []
        for entry in data.get("arp_entries", []):
            results.append({
                "ip": entry.get("ip_address", ""),
                "mac": entry.get("mac_address", ""),
                "interface": entry.get("interface", ""),
                "type": entry.get("type", ""),
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        addr_payload = {
            "address_object": {
                "name": name,
                "host": {"ip": ip},
                "zone": "LAN",
            }
        }
        rule_payload = {
            "access_rule": {
                "name": name,
                "from_zone": "LAN",
                "to_zone": "WAN",
                "source": {"address": [name]},
                "destination": {"address": ["any"]},
                "service": ["any"],
                "action": "allow",
                "enable": True,
                "comment": self._guest_comment(session),
            }
        }
        try:
            await self._request("POST", "address-objects/ipv4/host", json=addr_payload)
            await self._request("POST", "access-rules/ipv4", json=rule_payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"rule": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            await self._request("DELETE", f"access-rules/ipv4/{name}")
            await self._request("DELETE", f"address-objects/ipv4/host/{name}")
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "sonicwall", "raw": raw_event}
        m = re.search(r"msg=\"([^\"]+)\"", line)
        msg_body = m.group(1) if m else line
        try:
            for tok in shlex.split(msg_body, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in msg_body.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("hostname")
        parsed["event_type"] = parsed.get("type") or parsed.get("category")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        parsed["rule"] = parsed.get("rule_name") or parsed.get("firewall_rule")
        return parsed
