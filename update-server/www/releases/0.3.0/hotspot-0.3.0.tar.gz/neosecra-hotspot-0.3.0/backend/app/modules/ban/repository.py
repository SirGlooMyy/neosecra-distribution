# Business logic lives in service.py; no separate repo layer needed.
