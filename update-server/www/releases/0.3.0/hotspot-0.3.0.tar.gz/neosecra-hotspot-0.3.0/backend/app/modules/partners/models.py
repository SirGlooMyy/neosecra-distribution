"""Partner / Reseller. Belongs to a tenant; resells to customers."""
import uuid

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk


class Partner(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "partners"

    tenant_id: Mapped[uuid.UUID] = fk("tenants", ondelete="RESTRICT")
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    reseller_code: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    contact_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    contact_phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
