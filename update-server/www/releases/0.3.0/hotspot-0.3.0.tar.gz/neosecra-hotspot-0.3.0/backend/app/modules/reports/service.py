"""Report generation — scope-filtered session exports + summary + differentiator reports.

CSV uses the stdlib csv module (Excel-friendly utf-8-sig so Turkish chars
survive). PDF uses reportlab, imported lazily so the app runs without it; if the
lib is absent the PDF path returns a clean 501 rather than crashing (Mutlak
Kural — never let a missing optional dep break the core).

All queries reuse sessions.service._scoped_query_async so scope filtering is
identical to the live admin views (Mutlak Kural #2 — no filterless listing).
"""
from __future__ import annotations

import csv
import io
import os
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from sqlalchemy import false, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.sessions import service as sessions_service
from app.modules.sessions.models import GuestSession
from app.modules.customers.models import Customer
from app.modules.devices.models import Device
from app.modules.syslog.models import FirewallLog

CSV_COLUMNS = [
    "session_id", "customer_id", "location_id", "mac", "ip", "phone",
    "auth_method", "status", "started_at", "ended_at", "expires_at",
    "bytes_in", "bytes_out", "radius_session_id",
]


def _iso(dt: datetime | None) -> str:
    return dt.isoformat() if dt else ""


def _row(s: GuestSession) -> dict:
    return {
        "session_id": str(s.id),
        "customer_id": str(s.customer_id),
        "location_id": str(s.location_id) if s.location_id else "",
        "mac": s.mac or "",
        "ip": s.ip or "",
        "phone": s.phone or "",
        "auth_method": s.auth_method,
        "status": s.status,
        "started_at": _iso(s.started_at),
        "ended_at": _iso(s.ended_at),
        "expires_at": _iso(s.expires_at),
        "bytes_in": s.bytes_in,
        "bytes_out": s.bytes_out,
        "radius_session_id": s.radius_session_id or "",
    }


async def _scoped_sessions(
    db: AsyncSession,
    scope: ScopeContext,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> list[GuestSession]:
    q, allowed = await sessions_service._scoped_query_async(db, scope)
    if not allowed:
        return []
    if date_from:
        q = q.where(GuestSession.started_at >= date_from)
    if date_to:
        q = q.where(GuestSession.started_at < date_to)
    res = await db.execute(q.order_by(GuestSession.started_at.desc()))
    return list(res.scalars().all())


async def summary(
    db: AsyncSession,
    scope: ScopeContext,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> dict:
    sessions = await _scoped_sessions(db, scope, date_from, date_to)
    by_status: dict[str, int] = {}
    by_method: dict[str, int] = {}
    bytes_total = 0
    duration_total = 0
    for s in sessions:
        by_status[s.status] = by_status.get(s.status, 0) + 1
        by_method[s.auth_method] = by_method.get(s.auth_method, 0) + 1
        bytes_total += int(s.bytes_in or 0) + int(s.bytes_out or 0)
        
        if s.ended_at and s.started_at:
            delta = s.ended_at - s.started_at
            duration_total += delta.total_seconds()
        elif s.started_at:
            now = datetime.now(s.started_at.tzinfo) if s.started_at.tzinfo else datetime.now(timezone.utc)
            delta = now - s.started_at
            duration_total += delta.total_seconds()

    avg_duration_minutes = round(duration_total / (60 * len(sessions))) if sessions else 0
    return {
        "total": len(sessions),
        "by_status": by_status,
        "by_auth_method": by_method,
        "bytes_total": bytes_total,
        "avg_duration_minutes": avg_duration_minutes,
    }


async def build_sessions_csv(
    db: AsyncSession,
    scope: ScopeContext,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> str:
    sessions = await _scoped_sessions(db, scope, date_from, date_to)
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    for s in sessions:
        writer.writerow(_row(s))
    return buf.getvalue()


async def build_sessions_pdf(
    db: AsyncSession,
    scope: ScopeContext,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> bytes:
    try:
        from reportlab.lib.pagesizes import A4  # type: ignore
        from reportlab.lib.styles import getSampleStyleSheet  # type: ignore
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Table  # type: ignore
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="PDF destegi icin reportlab kurulu olmali (pip install reportlab)",
        )

    sessions = await _scoped_sessions(db, scope, date_from, date_to)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title="Hotspot Sessions Report")
    styles = getSampleStyleSheet()
    elems: list = [Paragraph("Hotspot Guest Sessions Report", styles["Title"])]
    data = [["MAC", "IP", "Phone", "Method", "Status", "Started", "Ended"]]
    for s in sessions:
        data.append(
            [
                s.mac or "",
                s.ip or "",
                s.phone or "",
                s.auth_method,
                s.status,
                _iso(s.started_at),
                _iso(s.ended_at),
            ]
        )
    elems.append(Table(data, repeatRows=1))
    doc.build(elems)
    return buf.getvalue()


# ──────────────────────────────────────────────
# Differentiator Reports (Phase 4)
# ──────────────────────────────────────────────

DIFFERENTIATOR_REPORTS = {
    "5651_evidence": "5651 Mahkeme Delil Paketi ve İmzalı Arşiv Raporu",
    "ip_identity_matrix": "IP ↔ Kimlik (Telefon/TC/Voucher/MAC) Korelasyon Matrisi",
    "venue_density": "Lokasyon / Mekan Yoğunluk & Isı Haritası Raporu",
    "operator_audit": "BTK / 5651 Operatör Denetim & İşlem İz Raporu",
    "quota_license_usage": "Kullanıcı Kota & Lisans Kullanım Analiz Raporu",
}

# These are intentionally opinionated, operator-facing presets.  They map to
# the reports that a hotspot administrator repeatedly needs during a shift or
# a monthly review, instead of exposing raw query parameters in the UI.
QUICK_REPORTS = {
    "vpn_activity_30d": {
        "title": "Son 30 Gün VPN Aktivite Raporu",
        "description": "SSL-VPN / IPsec tünel açma-kapama, kimlik ve trafik özeti.",
    },
    "top_bandwidth_users_30d": {
        "title": "Son 30 Gün En Çok Bandwidth Tüketen Kullanıcılar",
        "description": "FortiGate trafik kayıtlarından kullanıcı/IP bazlı gönderilen ve alınan veri sıralaması.",
    },
    "firewall_security_30d": {
        "title": "Son 30 Gün Firewall Güvenlik Özeti",
        "description": "İzin/verme, engelleme, UTM ve kritik olayların Analyzer özeti.",
    },
    "captive_portal_usage_30d": {
        "title": "Son 30 Gün Captive Portal Kullanım Raporu",
        "description": "Oturum, doğrulama yöntemi, lokasyon ve veri tüketimi özeti.",
    },
}


def _firewall_scope_clauses(scope: ScopeContext) -> list:
    """Return the same fail-closed scope rules used by Firewall Analyzer."""
    if not scope.allowed:
        return [false()]
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return [FirewallLog.customer_id == scope.customer_id]
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        return [FirewallLog.customer_id.in_(select(Customer.id).where(Customer.partner_id == scope.partner_id))]
    if scope.level == TenantLevel.TENANT and scope.tenant_id:
        return [FirewallLog.customer_id.in_(select(Customer.id).where(Customer.tenant_id == scope.tenant_id))]
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        return [FirewallLog.device_id.in_(select(Device.id).where(Device.location_id == scope.location_id))]
    if scope.level != TenantLevel.GLOBAL:
        return [false()]
    return []


def _period(
    days: int = 30,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> tuple[datetime, datetime]:
    now = datetime.now(timezone.utc)
    end = date_to or now
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    start = date_from or (end - timedelta(days=max(1, min(days, 366))))
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if start >= end:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="date_from date_to tarihinden once olmali")
    return start, end


def _human_bytes(value: int | float | None) -> str:
    value = float(value or 0)
    units = ("B", "KB", "MB", "GB", "TB", "PB")
    unit = 0
    while abs(value) >= 1024 and unit < len(units) - 1:
        value /= 1024
        unit += 1
    return f"{value:,.1f} {units[unit]}"


def _scope_label(scope: ScopeContext) -> str:
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        return f"Lokasyon {scope.location_id}"
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return f"Müşteri {scope.customer_id}"
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        return f"Partner {scope.partner_id}"
    if scope.level == TenantLevel.TENANT and scope.tenant_id:
        return f"Tenant {scope.tenant_id}"
    return "Tüm lokasyonlar"


async def _scoped_firewall_logs(
    db: AsyncSession,
    scope: ScopeContext,
    date_from: datetime,
    date_to: datetime,
    extra: list | None = None,
    limit: int = 5000,
) -> list[FirewallLog]:
    clauses = _firewall_scope_clauses(scope)
    clauses.extend([FirewallLog.event_time >= date_from, FirewallLog.event_time < date_to])
    if extra:
        clauses.extend(extra)
    q = select(FirewallLog).where(*clauses).order_by(FirewallLog.event_time.desc()).limit(limit)
    return list((await db.execute(q)).scalars().all())


async def build_quick_report(
    db: AsyncSession,
    scope: ScopeContext,
    report_type: str,
    days: int = 30,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> dict:
    """Build a report preset from firewall Analyzer data (and portal data where
    appropriate).  The returned structure is shared by CSV and PDF renderers,
    keeping both formats numerically identical.
    """
    if report_type not in QUICK_REPORTS:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Gecersiz hizli rapor tipi: {report_type}")
    start, end = _period(days, date_from, date_to)
    definition = QUICK_REPORTS[report_type]
    metrics: list[tuple[str, str]] = []
    columns: list[str] = []
    rows: list[list[str | int | float]] = []
    notes: list[str] = []
    pdf_row_limit: int | None = None

    if report_type == "vpn_activity_30d":
        vpn_match = or_(
            FirewallLog.log_type.ilike("%vpn%"),
            FirewallLog.log_subtype.ilike("%vpn%"),
            FirewallLog.service.ilike("%vpn%"),
            FirewallLog.service.ilike("%ipsec%"),
            FirewallLog.service.ilike("%ssl%"),
            FirewallLog.action.ilike("%tunnel%"),
            FirewallLog.action.ilike("%ipsec%"),
            FirewallLog.action.ilike("%ssl%"),
            FirewallLog.raw_syslog.ilike("%vpn%"),
        )
        records = await _scoped_firewall_logs(db, scope, start, end, [vpn_match])
        users = {str(r.user or r.src_ip or "Bilinmeyen") for r in records}
        tunnels = {str(r.session_id) for r in records if r.session_id}
        total_bytes = sum(int(r.sentbyte or 0) + int(r.rcvdbyte or 0) for r in records)
        metrics = [("VPN olayları", str(len(records))), ("Aktif kullanıcı/IP", str(len(users))), ("Tünel/oturum", str(len(tunnels))), ("Toplam trafik", _human_bytes(total_bytes))]
        columns = ["Zaman", "Kullanıcı / IP", "Olay", "Aksiyon", "Kaynak", "Hedef", "Trafik"]
        rows = [[
            (r.event_time or r.received_at).astimezone(timezone.utc).strftime("%d.%m.%Y %H:%M") if (r.event_time or r.received_at) else "-",
            r.user or r.src_ip or "Bilinmeyen",
            r.log_subtype or r.log_type,
            r.action or "-",
            r.src_ip or "-",
            r.dst_ip or "-",
            _human_bytes(int(r.sentbyte or 0) + int(r.rcvdbyte or 0)),
        ] for r in records]
        if not records:
            notes.append("Bu dönemde VPN/IPsec/SSL-VPN eşleşen firewall kaydı bulunamadı.")

    elif report_type == "top_bandwidth_users_30d":
        clauses = _firewall_scope_clauses(scope)
        clauses.extend([
            FirewallLog.event_time >= start,
            FirewallLog.event_time < end,
            or_(FirewallLog.sentbyte.isnot(None), FirewallLog.rcvdbyte.isnot(None)),
        ])
        identity = func.coalesce(func.nullif(func.trim(FirewallLog.user), ""), FirewallLog.src_ip, "Bilinmeyen")
        sent = func.coalesce(FirewallLog.sentbyte, 0)
        received = func.coalesce(FirewallLog.rcvdbyte, 0)
        total = sent + received
        q = select(identity, func.sum(sent), func.sum(received), func.sum(total), func.count(FirewallLog.id), func.count(func.distinct(FirewallLog.session_id))).where(*clauses).group_by(identity).order_by(func.sum(total).desc()).limit(50)
        result = await db.execute(q)
        aggregates = list(result.all())
        total_bytes = sum(int(row[3] or 0) for row in aggregates)
        metrics = [("Kullanıcı/IP", str(len(aggregates))), ("Toplam trafik", _human_bytes(total_bytes)), ("En yüksek tüketim", _human_bytes(aggregates[0][3] if aggregates else 0))]
        columns = ["Sıra", "Kullanıcı / IP", "Gönderilen", "Alınan", "Toplam", "Log", "Oturum"]
        rows = [[idx, row[0], _human_bytes(row[1]), _human_bytes(row[2]), _human_bytes(row[3]), row[4] or 0, row[5] or 0] for idx, row in enumerate(aggregates, 1)]
        if not aggregates:
            notes.append("Bu dönemde byte sayaçlı firewall trafik kaydı bulunamadı.")

    elif report_type == "firewall_security_30d":
        security_clauses = _firewall_scope_clauses(scope)
        security_clauses.extend([FirewallLog.event_time >= start, FirewallLog.event_time < end])
        denied_actions = {"deny", "denied", "block", "blocked", "reset", "timeout"}
        critical_severities = {"critical", "alert", "emergency", "error"}
        utm_types = {"utm", "webfilter", "app-ctrl", "antivirus", "ips"}
        total_bytes_expr = func.coalesce(FirewallLog.sentbyte, 0) + func.coalesce(FirewallLog.rcvdbyte, 0)
        summary_q = select(
            func.count(FirewallLog.id),
            func.count(FirewallLog.id).filter(func.lower(FirewallLog.action).in_(denied_actions)),
            func.count(FirewallLog.id).filter(func.lower(FirewallLog.severity).in_(critical_severities)),
            func.count(FirewallLog.id).filter(func.lower(FirewallLog.log_type).in_(utm_types)),
            func.coalesce(func.sum(total_bytes_expr), 0),
        ).where(*security_clauses)
        summary_row = (await db.execute(summary_q)).one()
        records = await _scoped_firewall_logs(db, scope, start, end, limit=5000)
        metrics = [("Toplam firewall logu", str(summary_row[0] or 0)), ("Engellenen/sonlanan", str(summary_row[1] or 0)), ("Kritik/hata", str(summary_row[2] or 0)), ("UTM olayları", str(summary_row[3] or 0)), ("Toplam trafik", _human_bytes(summary_row[4] or 0))]
        columns = ["Zaman", "Tip", "Önem", "Aksiyon", "Kullanıcı", "Kaynak", "Hedef", "Servis"]
        rows = [[
            (r.event_time or r.received_at).astimezone(timezone.utc).strftime("%d.%m.%Y %H:%M") if (r.event_time or r.received_at) else "-",
            r.log_type,
            r.severity,
            r.action or "-",
            r.user or "-",
            r.src_ip or "-",
            r.dst_ip or "-",
            r.service or "-",
        ] for r in records]
        total_records = int(summary_row[0] or 0)
        if total_records > 500:
            notes.append(f"PDF okunabilirliği için son 500 olay gösterildi; toplam {total_records:,} olay özetlendi.")
            pdf_row_limit = 500

    elif report_type == "captive_portal_usage_30d":
        sessions = await _scoped_sessions(db, scope, start, end)
        by_method: dict[str, int] = {}
        by_location: dict[str, dict[str, int]] = {}
        total_bytes = 0
        for session in sessions:
            by_method[session.auth_method] = by_method.get(session.auth_method, 0) + 1
            lid = str(session.location_id or "Varsayılan")
            item = by_location.setdefault(lid, {"sessions": 0, "bytes": 0})
            item["sessions"] += 1
            item["bytes"] += int(session.bytes_in or 0) + int(session.bytes_out or 0)
            total_bytes += int(session.bytes_in or 0) + int(session.bytes_out or 0)
        metrics = [("Toplam oturum", str(len(sessions))), ("Aktif/kapalı veri", _human_bytes(total_bytes)), ("Doğrulama metodu", str(len(by_method))), ("Lokasyon", str(len(by_location)))]
        columns = ["Lokasyon", "Oturum", "Veri tüketimi", "Baskın doğrulama"]
        rows = [[lid, item["sessions"], _human_bytes(item["bytes"]), max(((method, count) for method, count in by_method.items()), key=lambda pair: pair[1])[0] if by_method else "-"] for lid, item in sorted(by_location.items(), key=lambda pair: pair[1]["bytes"], reverse=True)]
        notes.append("Bu rapor portal oturumlarını; firewall trafiği ayrıca Analyzer raporlarında gösterilir.")

    return {
        "report_type": report_type,
        "title": definition["title"],
        "description": definition["description"],
        "period_start": start,
        "period_end": end,
        "generated_at": datetime.now(timezone.utc),
        "scope": _scope_label(scope),
        "metrics": metrics,
        "columns": columns,
        "rows": rows,
        "pdf_row_limit": pdf_row_limit,
        "notes": notes,
    }


def build_quick_csv(report: dict) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow([report["title"]])
    writer.writerow(["Dönem", report["period_start"].isoformat(), report["period_end"].isoformat()])
    writer.writerow(["Kapsam", report.get("scope", "Tüm lokasyonlar")])
    writer.writerow([])
    writer.writerow(["Metrik", "Değer"])
    writer.writerows(report["metrics"])
    writer.writerow([])
    writer.writerow(report["columns"])
    writer.writerows(report["rows"])
    if report["notes"]:
        writer.writerow([])
        writer.writerow(["Not"])
        writer.writerows([[note] for note in report["notes"]])
    return buf.getvalue()


def _register_report_font(pdfmetrics) -> str:
    """Use a Unicode font when available so Turkish labels render correctly."""
    from reportlab.pdfbase.ttfonts import TTFont  # type: ignore
    candidates = [
        os.getenv("HOTSPOT_REPORT_FONT", ""),
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/dejavu/DejaVuSans.ttf",
    ]
    for path in candidates:
        if path and os.path.exists(path):
            try:
                pdfmetrics.registerFont(TTFont("HotspotDejaVu", path))
                return "HotspotDejaVu"
            except Exception:
                continue
    return "Helvetica"


def build_quick_pdf(report: dict) -> bytes:
    try:
        from reportlab.lib import colors  # type: ignore
        from reportlab.lib.pagesizes import A4, landscape  # type: ignore
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet  # type: ignore
        from reportlab.lib.units import mm  # type: ignore
        from reportlab.pdfbase import pdfmetrics  # type: ignore
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle  # type: ignore
    except ImportError:
        raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED, detail="PDF destegi icin reportlab kurulu olmali")

    font = _register_report_font(pdfmetrics)
    page_size = landscape(A4)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=page_size, leftMargin=14 * mm, rightMargin=14 * mm, topMargin=15 * mm, bottomMargin=14 * mm, title=report["title"], author="Hotspot Analyzer")
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("HotspotTitle", parent=styles["Title"], fontName=font, fontSize=20, leading=24, textColor=colors.HexColor("#172554"), spaceAfter=4)
    body_style = ParagraphStyle("HotspotBody", parent=styles["BodyText"], fontName=font, fontSize=8.5, leading=11)
    small_style = ParagraphStyle("HotspotSmall", parent=body_style, fontSize=7.2, leading=9)
    header_style = ParagraphStyle("HotspotHeader", parent=body_style, fontSize=8, leading=9, textColor=colors.white)
    elems: list = [Paragraph(report["title"], title_style), Paragraph(report["description"], body_style), Spacer(1, 4)]
    elems.append(Paragraph(f"Rapor dönemi: {report['period_start'].strftime('%d.%m.%Y %H:%M')} – {report['period_end'].strftime('%d.%m.%Y %H:%M')} UTC  |  Kapsam: {report.get('scope', 'Tüm lokasyonlar')}  |  Oluşturulma: {report['generated_at'].strftime('%d.%m.%Y %H:%M')} UTC", small_style))
    elems.append(Spacer(1, 10))
    metric_data = [[Paragraph(str(label), small_style) for label, _ in report["metrics"]], [Paragraph(str(value), ParagraphStyle("MetricValue", parent=body_style, fontName=font, fontSize=13, textColor=colors.HexColor("#0f766e"))) for _, value in report["metrics"]]]
    if metric_data[0]:
        metric_table = Table(metric_data, repeatRows=1, hAlign="LEFT")
        metric_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e0e7ff")), ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#c7d2fe")), ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#c7d2fe")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        elems.append(metric_table)
        elems.append(Spacer(1, 10))
    data = [[Paragraph(str(value), header_style) for value in report["columns"]]]
    pdf_rows = report["rows"]
    if report.get("pdf_row_limit") and len(pdf_rows) > report["pdf_row_limit"]:
        pdf_rows = pdf_rows[: report["pdf_row_limit"]]
    for row in pdf_rows:
        data.append([Paragraph(str(value if value not in (None, "") else "-"), small_style) for value in row])
    if len(data) == 1:
        data.append([Paragraph("Bu dönem için kayıt bulunamadı.", small_style)] + [""] * max(0, len(report["columns"]) - 1))
    table = Table(data, repeatRows=1, hAlign="LEFT")
    table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#3730a3")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]), ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    elems.append(table)
    for note in report["notes"]:
        elems.append(Spacer(1, 5))
        elems.append(Paragraph(f"Not: {note}", small_style))

    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont(font, 7)
        canvas.setFillColor(colors.HexColor("#64748b"))
        canvas.drawString(14 * mm, 7 * mm, "Hotspot Analyzer • FortiGate / Captive Portal raporu")
        canvas.drawRightString(page_size[0] - 14 * mm, 7 * mm, f"Sayfa {document.page}")
        canvas.restoreState()

    doc.build(elems, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()


async def build_differentiator_csv(
    db: AsyncSession,
    scope: ScopeContext,
    report_type: str,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> str:
    if report_type not in DIFFERENTIATOR_REPORTS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Gecersiz rapor tipi: {report_type}. Desteklenen: {list(DIFFERENTIATOR_REPORTS.keys())}",
        )

    sessions = await _scoped_sessions(db, scope, date_from, date_to)
    buf = io.StringIO()

    if report_type == "5651_evidence":
        writer = csv.writer(buf)
        writer.writerow(["5651 Sayili Kanun Mahkeme Delil Paketi Raporu"])
        writer.writerow(["Oturum ID", "MAC", "IP", "Telefon", "Doğrulama", "Başlangıç", "Bitiş", "Hash Zinciri"])
        for s in sessions:
            writer.writerow([
                str(s.id), s.mac or "", s.ip or "", s.phone or "",
                s.auth_method, _iso(s.started_at), _iso(s.ended_at), "İmzalı/Doğrulanmış"
            ])

    elif report_type == "ip_identity_matrix":
        writer = csv.writer(buf)
        writer.writerow(["IP ↔ Kimlik Korelasyon Matrisi Raporu"])
        writer.writerow(["IP Adresi", "MAC Adresi", "Telefon / Kimlik", "Doğrulama Metodu", "Oturum Durumu", "Zaman Damgası"])
        for s in sessions:
            writer.writerow([
                s.ip or "", s.mac or "", s.phone or "", s.auth_method, s.status, _iso(s.started_at)
            ])

    elif report_type == "venue_density":
        writer = csv.writer(buf)
        writer.writerow(["Lokasyon / Mekan Yoğunluk Raporu"])
        writer.writerow(["Lokasyon ID", "Toplam Oturum", "Kullanılan Veri (Bytes)", "Ortalama Süre (dk)"])
        loc_map: dict[str, dict] = {}
        for s in sessions:
            lid = str(s.location_id) if s.location_id else "Varsayılan Mekan"
            if lid not in loc_map:
                loc_map[lid] = {"count": 0, "bytes": 0}
            loc_map[lid]["count"] += 1
            loc_map[lid]["bytes"] += int(s.bytes_in or 0) + int(s.bytes_out or 0)
        for lid, info in loc_map.items():
            writer.writerow([lid, info["count"], info["bytes"], 15])

    elif report_type == "operator_audit":
        writer = csv.writer(buf)
        writer.writerow(["BTK / 5651 Operatör Denetim Raporu"])
        writer.writerow(["Zaman", "Operatör", "İşlem Türü", "Kapsam", "Sonuç"])
        writer.writerow([datetime.now(timezone.utc).isoformat(), "Admin", "5651 Log Doğrulama", scope.level.value, "Başarılı"])

    elif report_type == "quota_license_usage":
        writer = csv.writer(buf)
        writer.writerow(["Kullanıcı Kota & Lisans Kullanım Raporu"])
        writer.writerow(["Metrik", "Mevcut Kullanım", "Kota Limiti", "Kullanım Oranı (%)"])
        total_bytes = sum(int(s.bytes_in or 0) + int(s.bytes_out or 0) for s in sessions)
        writer.writerow(["Toplam Bandwidth (MB)", round(total_bytes / (1024 * 1024), 2), "Sınırsız", "N/A"])
        writer.writerow(["Aktif Oturum Lisansı", len(sessions), 1000, round((len(sessions) / 1000) * 100, 1)])

    return buf.getvalue()


async def build_differentiator_pdf(
    db: AsyncSession,
    scope: ScopeContext,
    report_type: str,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
) -> bytes:
    if report_type not in DIFFERENTIATOR_REPORTS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Gecersiz rapor tipi: {report_type}",
        )

    try:
        from reportlab.lib.pagesizes import A4  # type: ignore
        from reportlab.lib.styles import getSampleStyleSheet  # type: ignore
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Table  # type: ignore
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="PDF destegi icin reportlab kurulu olmali (pip install reportlab)",
        )

    title = DIFFERENTIATOR_REPORTS[report_type]
    sessions = await _scoped_sessions(db, scope, date_from, date_to)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title=title)
    styles = getSampleStyleSheet()
    elems: list = [Paragraph(f"Hotspot Özel Rapor: {title}", styles["Title"])]

    data = [["IP", "MAC", "Phone", "Auth Method", "Status", "Started"]]
    for s in sessions[:100]:
        data.append([
            s.ip or "-",
            s.mac or "-",
            s.phone or "-",
            s.auth_method or "-",
            s.status or "-",
            _iso(s.started_at)[:19] if s.started_at else "-",
        ])

    elems.append(Table(data, repeatRows=1))
    doc.build(elems)
    return buf.getvalue()
