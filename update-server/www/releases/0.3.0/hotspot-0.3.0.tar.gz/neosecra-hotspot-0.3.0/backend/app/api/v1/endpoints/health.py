from fastapi import APIRouter
from app.core.config import settings

router = APIRouter()

@router.get("")
async def health():
    return {
        "status": "ok",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
    }
