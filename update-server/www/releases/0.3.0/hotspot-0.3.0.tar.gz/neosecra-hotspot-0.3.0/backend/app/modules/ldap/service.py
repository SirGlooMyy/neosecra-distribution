"""LDAP/Active Directory authentication for captive portal.

Uses ldap3 (sync) wrapped in asyncio.to_thread for async compatibility.
Requires ldap3 to be installed separately (optional dependency).
"""
from __future__ import annotations

import asyncio
import logging
from urllib.parse import urlparse

from app.core.config import settings

log = logging.getLogger(__name__)

try:
    import ldap3  # type: ignore[import-not-found]
    from ldap3 import Server, Connection, ALL  # type: ignore[import-not-found]

    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _parse_ldap_url(url: str | None = None) -> dict:
    """Parse LDAP_URL into host, port, use_ssl."""
    url = url or getattr(settings, "LDAP_URL", "ldap://localhost:389")
    parsed = urlparse(url)
    return {
        "host": parsed.hostname or "localhost",
        "port": parsed.port or (636 if parsed.scheme == "ldaps" else 389),
        "use_ssl": parsed.scheme == "ldaps",
    }


def _build_connection(ldap_info: dict) -> Connection:
    """Create & bind an LDAP connection using the configured service account."""
    server = Server(  # type: ignore[call-arg,possibly-unbound]
        ldap_info["host"],
        port=ldap_info["port"],
        use_ssl=ldap_info["use_ssl"],
        get_info=ALL,  # type: ignore[possibly-unbound]
    )
    conn = Connection(  # type: ignore[call-arg]
        server,
        user=settings.LDAP_BIND_DN,
        password=settings.LDAP_BIND_PASSWORD,
        auto_bind=True,
    )
    return conn


def _get_attr(attrs: dict, key: str) -> str | None:
    values = attrs.get(key, [])
    return str(values[0]) if values else None


# ---------------------------------------------------------------------------
# public API
# ---------------------------------------------------------------------------

async def authenticate(
    username: str,
    password: str,
    domain: str | None = None,
) -> dict | None:
    """Authenticate a user against LDAP/AD.

    Returns a dict with keys (username, display_name, email, groups, dn) on
    success, or *None* on failure.
    """
    if not LDAP_AVAILABLE:
        raise ImportError(
            "ldap3 kutuphanesi yuklu degil. "
            "Yuklemek icin: pip install ldap3"
        )
    if not username or not password:
        return None

    ldap_info = _parse_ldap_url()
    base_dn = settings.LDAP_BASE_DN
    search_filter = getattr(
        settings,
        "LDAP_SEARCH_FILTER",
        "(|(sAMAccountName={username})(uid={username})(userPrincipalName={username}@*))",
    )

    user_domain = domain
    if "\\" in username:
        user_domain, username = username.split("\\", 1)
    elif "@" in username:
        parts = username.split("@", 1)
        username = parts[0]
        user_domain = user_domain or parts[1]

    def _sync() -> dict | None:
        try:
            conn = _build_connection(ldap_info)
        except Exception as exc:
            log.error("LDAP baglanti hatasi: %s", exc)
            return None

        try:
            filter_str = search_filter.format(
                username=username, domain=user_domain or ""
            )
            conn.search(
                search_base=base_dn,
                search_filter=filter_str,
                attributes=[
                    "cn",
                    "displayName",
                    "mail",
                    "sAMAccountName",
                    "uid",
                    "givenName",
                    "sn",
                    "memberOf",
                ],
            )
            if not conn.entries:
                log.warning("LDAP: kullanici bulunamadi — %s", username)
                return None

            entry = conn.entries[0]
            user_dn = entry.entry_dn

            # Verify password by re-binding as the user
            user_conn = Connection(conn.server, user=user_dn, password=password)  # type: ignore[call-arg,possibly-unbound]
            if not user_conn.bind():
                log.warning("LDAP: sifre dogrulamasi basarisiz — %s", username)
                return None
            user_conn.unbind()

            attrs = entry.entry_attributes_as_dict
            display_name = (
                _get_attr(attrs, "displayName")
                or _get_attr(attrs, "cn")
                or username
            )
            email = _get_attr(attrs, "mail") or ""
            groups = [str(g) for g in attrs.get("memberOf", [])]

            return {
                "username": username,
                "display_name": display_name,
                "email": email,
                "groups": groups,
                "dn": user_dn,
            }
        finally:
            try:
                conn.unbind()
            except Exception:
                pass

    return await asyncio.to_thread(_sync)


async def search_user(query: str) -> list[dict]:
    """Search LDAP directory for users matching *query*.

    Returns a list of dicts with keys (dn, username, display_name, email).
    """
    if not LDAP_AVAILABLE:
        raise ImportError("ldap3 kutuphanesi yuklu degil.")
    if not query:
        return []

    ldap_info = _parse_ldap_url()
    base_dn = settings.LDAP_BASE_DN

    def _sync() -> list[dict]:
        try:
            conn = _build_connection(ldap_info)
        except Exception as exc:
            log.error("LDAP search baglanti hatasi: %s", exc)
            return []

        try:
            conn.search(
                search_base=base_dn,
                search_filter=(
                    f"(|(cn=*{query}*)(sAMAccountName=*{query}*)"
                    f"(mail=*{query}*)(displayName=*{query}*)"
                    f"(uid=*{query}*))"
                ),
                attributes=["cn", "displayName", "mail", "sAMAccountName", "uid"],
            )
            results = []
            for entry in conn.entries:
                attrs = entry.entry_attributes_as_dict
                results.append(
                    {
                        "dn": entry.entry_dn,
                        "username": (
                            _get_attr(attrs, "sAMAccountName")
                            or _get_attr(attrs, "uid")
                            or ""
                        ),
                        "display_name": (
                            _get_attr(attrs, "displayName")
                            or _get_attr(attrs, "cn")
                            or ""
                        ),
                        "email": _get_attr(attrs, "mail") or "",
                    }
                )
            return results
        finally:
            try:
                conn.unbind()
            except Exception:
                pass

    return await asyncio.to_thread(_sync)
