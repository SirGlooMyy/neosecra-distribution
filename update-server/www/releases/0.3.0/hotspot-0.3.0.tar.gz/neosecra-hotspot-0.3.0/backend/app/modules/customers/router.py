"""Customer HTTP endpoints. Read scoped; create/update/delete = customer.write."""
import uuid

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.customers import service
from app.modules.customers.schemas import CustomerCreate, CustomerOut, CustomerUpdate
from fastapi import HTTPException

router = APIRouter()


@router.get("", response_model=list[CustomerOut], summary="List all customers accessible to the current user", description="Returns a paginated list of customers scoped to the authenticated user's tenant. Non-super-admin users only see customers within their own tenant scope. Requires a valid access token.")
async def list_customers(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_customers(db, scope_for(user))


@router.get("/{customer_id}", response_model=CustomerOut, summary="Retrieve a single customer by unique identifier", description="Fetches detailed information for the specified customer. Access is scoped to the user's tenant permissions. Requires a valid access token.")
async def get_customer(
    customer_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_customer(db, customer_id, scope_for(user))


@router.post("", response_model=CustomerOut, status_code=status.HTTP_201_CREATED, summary="Create a new customer record", description="Creates a new customer within the user's tenant scope. Requires the customer.write permission. Returns the created customer details including its unique identifier.")
async def create_customer(
    body: CustomerCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not has_permission(user.role, "customer.write"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Musteri olusturma yetkiniz yok")
    return await service.create_customer(db, body, scope_for(user), user.id, request)


@router.put("/{customer_id}", response_model=CustomerOut, summary="Update an existing customer record", description="Updates the specified customer's information such as name, contact details, or status. Requires the customer.write permission. Returns the updated customer object.")
async def update_customer(
    customer_id: uuid.UUID,
    body: CustomerUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not has_permission(user.role, "customer.write"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Musteri guncelleme yetkiniz yok")
    return await service.update_customer(db, customer_id, body, scope_for(user), user.id, request)


@router.delete("/{customer_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Deactivate a customer record (soft delete)", description="Deactivates the specified customer, making it inactive while preserving data for auditing. Requires the customer.write permission. Returns 204 No Content on success.")
async def delete_customer(
    customer_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not has_permission(user.role, "customer.write"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Musteri silme yetkiniz yok")
    await service.deactivate_customer(db, customer_id, scope_for(user), user.id, request)
