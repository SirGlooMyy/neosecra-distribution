"""PUBLIC captive-portal flow endpoints.

NO admin JWT here: the guest is not a platform user. The device_id embedded in
the firewall redirect is the trust anchor, and every step re-resolves the site
context (flow.resolve_context) before doing work (Mutlak Kural #6). Each
endpoint is IP-rate-limited to blunt brute force on OTPs / voucher codes.

Registered under /portal/public so it is visibly separate from the authed
admin/template endpoints (api/v1/router.py).
"""
import uuid

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request, status
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.security import rate_limit
from app.modules.portal import flow
from app.modules.portal.i18n_data import SUPPORTED_LANGUAGES, LANGUAGE_NAMES
from app.modules.portal.i18n_service import get_translations
from app.modules.portal.schemas import (
    PortalContextOut,
    PortalVerifyIn,
    SendCodeIn,
    StartSessionIn,
    StartSessionOut,
    PortalTokenOut,
)
from app.modules.portal.template_service import (
    get_available_templates,
    render_preview_html,
)
from app.modules.sms.schemas import OtpResultOut

router = APIRouter(tags=["captive-portal"])

# Blunt per-IP shield across the whole public flow. Per-credential limits
# (OTP max attempts, voucher single-use, per-phone send window) are enforced
# inside the respective services; this only caps request volume.
_PORTAL_RL_MAX = 60
_PORTAL_RL_WINDOW = 60


def _client_ip(request: Request) -> str:
    return request.client.host if request and request.client else "unknown"


async def _rl(request: Request, bucket: str) -> None:
    if settings.DISABLE_RATE_LIMIT:
        return
    blocked, _ = await rate_limit(
        f"portal:{bucket}:{_client_ip(request)}",
        _PORTAL_RL_MAX,
        _PORTAL_RL_WINDOW,
    )
    if blocked:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Cok fazla istek. Lutfen daha sonra tekrar deneyin.",
        )


@router.get("/context", response_model=PortalContextOut, summary="Get public portal context for a device's site", description="Returns the landing-page configuration for the captive portal associated with the specified device. Includes branding, supported auth methods, and template settings. No authentication required. Rate-limited per IP.")
async def portal_context(
    device_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    await _rl(request, "ctx")
    device, location, customer, template = await flow.resolve_context(
        db, device_id=device_id
    )
    is_demo_mode, demo_fallback_reason = await flow.resolve_demo_state(db, customer)
    return flow.build_context_out(
        template,
        customer,
        is_demo_mode=is_demo_mode,
        demo_fallback_reason=demo_fallback_reason,
    )


@router.post("/send-code", response_model=OtpResultOut, summary="Send an SMS OTP code for portal verification", description="Sends a one-time SMS code to the guest's phone bound to the specified device's site context. Used for SMS-based authentication in the captive portal flow. Rate-limited per IP.")
async def portal_send_code(
    body: SendCodeIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    await _rl(request, "send")
    return await flow.send_code(
        db,
        device_id=body.device_id,
        phone=body.phone,
        tc_number=body.tc_number,
        request=request,
    )


@router.post("/verify", response_model=PortalTokenOut, summary="Verify guest credential and issue a portal token", description="Verifies the guest's authentication credential (SMS code, voucher, PMS, etc.) according to the site's configured method. Issues a one-shot portal token that can be exchanged for network access. Rate-limited per IP.")
async def portal_verify(
    body: PortalVerifyIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    await _rl(request, "verify")
    return await flow.verify(
        db,
        device_id=body.device_id,
        phone=body.phone,
        code=body.code,
        tc_number=body.tc_number,
        voucher_code=body.voucher_code,
        room_number=body.room_number,
        surname_or_birth=body.surname_or_birth,
        username=body.username,
        password=body.password,
        form_data=body.form_data,
        request=request,
    )


# ── i18n ─────────────────────────────────────────────────────────────────────


@router.get("/i18n", summary="Get translations for the captive portal UI", description="Returns all translated strings for the requested language along with the list of available languages. Falls back to Turkish if the requested language is not supported. Publicly accessible.")
async def portal_i18n(
    lang: str = Query("tr", description="Language code"),
):
    return {
        "lang": lang if lang in SUPPORTED_LANGUAGES else "tr",
        "available_languages": {
            code: LANGUAGE_NAMES[code]
            for code in SUPPORTED_LANGUAGES
        },
        "translations": get_translations(lang),
    }


# ── Predefined templates ─────────────────────────────────────────────────────


@router.get("/templates", summary="List available predefined portal templates", description="Returns all available captive portal template presets grouped by category (hotel, cafe, mall, etc.). These templates provide pre-built branding and layout configurations. Publicly accessible.")
async def portal_templates():
    return {
        "templates": get_available_templates(),
        "categories": ["hotel", "residence", "school", "cafe", "public", "mall", "business"],
    }


@router.get("/templates/preview/{template_id}", summary="Get HTML preview of a portal template", description="Renders an HTML preview of the specified portal template with the selected authentication method and language. Useful for visual template selection during setup. Publicly accessible.")
async def portal_template_preview(
    template_id: str,
    method: str = Query("sms", description="Auth method for form fields"),
    lang: str = Query("tr", description="Language for text"),
):
    html = render_preview_html(template_id, method, lang)
    return HTMLResponse(content=html)


# ── Flow endpoints ───────────────────────────────────────────────────────────


@router.post("/start-session", response_model=StartSessionOut, summary="Exchange portal token for an authorized guest session", description="Exchanges a verified portal token for a full guest session with firewall authorization. Creates a GuestSession record and adds the guest's MAC/IP to the firewall allowlist. Rate-limited per IP.")
async def portal_start_session(
    body: StartSessionIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    await _rl(request, "start")
    return await flow.start_session(
        db,
        device_id=body.device_id,
        portal_token=body.portal_token,
        mac=body.mac,
        ip=body.ip,
        ssid=body.ssid,
        request=request,
        terms_accepted=body.terms_accepted,
        privacy_accepted=body.privacy_accepted,
        terms_version=body.terms_version,
        privacy_version=body.privacy_version,
    )


@router.get("/approval/{session_id}", response_class=HTMLResponse, summary="Show manager approval confirmation")
async def manager_approval_link(
    session_id: uuid.UUID,
    token: str = Query(..., min_length=20, max_length=200),
    decision: str = Query("approve"),
):
    """Render a confirmation form; GET never authorizes a firewall session."""
    safe_decision = "reject" if decision.lower() in {"reject", "rejected", "red"} else "approve"
    title = "Hotspot erişim talebini reddet" if safe_decision == "reject" else "Hotspot erişim talebini onayla"
    action = "Reddet" if safe_decision == "reject" else "Erişimi onayla"
    return HTMLResponse(content=f"""<html><body><h2>{title}</h2>
      <p>Devam etmek için aşağıdaki düğmeye basın. E-posta güvenlik tarayıcıları bu sayfayı açsa bile karar verilmez.</p>
      <form method='post'><input type='hidden' name='token' value='{token}' />
      <input type='hidden' name='decision' value='{safe_decision}' />
      <button type='submit'>{action}</button></form></body></html>""")


@router.post("/approval/{session_id}", response_class=HTMLResponse, include_in_schema=False)
async def process_manager_approval(
    session_id: uuid.UUID,
    request: Request,
    token: str = Form(..., min_length=20, max_length=200),
    decision: str = Form("approve"),
    db: AsyncSession = Depends(get_db),
):
    """Consume the one-time manager decision after an explicit click."""
    from app.modules.sessions import service as sessions_service
    try:
        session = await sessions_service.approve_session_by_token(
            db, session_id, token, decision=decision, request=request
        )
    except HTTPException as exc:
        return HTMLResponse(
            content=f"<html><body><h2>Hotspot onayı işlenemedi</h2><p>{exc.detail}</p></body></html>",
            status_code=exc.status_code,
        )
    label = "onaylandı" if decision.lower() not in {"reject", "rejected", "red"} else "reddedildi"
    return HTMLResponse(
        content=f"<html><body><h2>Erişim talebi {label}</h2><p>Bu pencereyi kapatabilirsiniz.</p></body></html>"
    )
