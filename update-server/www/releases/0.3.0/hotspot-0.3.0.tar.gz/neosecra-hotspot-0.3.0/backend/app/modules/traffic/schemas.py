from datetime import datetime

from pydantic import BaseModel, ConfigDict


class TrafficPoint(BaseModel):
    hour: datetime
    bytes_in: int
    bytes_out: int
    session_count: int
    active_users: int


class TrafficSummary(BaseModel):
    total_bytes_in: int
    total_bytes_out: int
    total_sessions: int
    peak_concurrent: int
    avg_session_duration_min: float | None = None
    unique_macs: int


class TopTalkerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    mac: str
    phone: str | None = None
    bytes_in: int
    bytes_out: int
    session_count: int
    rank: int


class TrafficTrend(BaseModel):
    daily: list[dict]  # [{date, bytes_in, bytes_out, session_count}]
    hourly: list[dict]
    top_talkers: list[TopTalkerOut]
    summary: TrafficSummary


class TrafficDashboardOut(BaseModel):
    total_bandwidth: int
    current_throughput: int
    daily_usage: list[dict]
    top_locations: list[dict]
    top_talkers: list[TopTalkerOut]
    auth_method_distribution: dict
