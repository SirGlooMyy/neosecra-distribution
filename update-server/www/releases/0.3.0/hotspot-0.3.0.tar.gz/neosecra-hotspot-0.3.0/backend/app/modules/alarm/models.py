import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


class AlarmEvent(Base, UUIDPK, TimestampMixin):
    """Alarm event for dashboard monitoring.

    Stores alarm/alert events with severity classification.
    Used for the Alarm Dashboard timeline, stats, and trend charts.
    """

    __tablename__ = "alarm_events"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    trigger_id: Mapped[uuid.UUID | None] = fk("syslog_triggers", ondelete="SET NULL", nullable=True)

    severity: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    message: Mapped[str | None] = mapped_column(Text, nullable=True)
    source: Mapped[str | None] = mapped_column(String(255), nullable=True)

    acknowledged: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    acknowledged_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)

    event_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
