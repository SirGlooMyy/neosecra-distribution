"""Device HTTP endpoints + firewall adapter actions.

Read = device.read; create/update/delete/credential = device.write.
Adapter actions (test/discover/authorize/revoke) = device.write.
"""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.devices import service
from app.modules.devices.schemas import (
    CredentialOut,
    CredentialSet,
    DeviceCreate,
    DeviceOut,
    DeviceUpdate,
)
from app.modules.firewall_adapters import service as adapter_service

router = APIRouter()


def _require(role: str, perm: str) -> None:
    if not has_permission(role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


@router.get("/capabilities", summary="List firewall vendor capabilities")
async def list_vendor_capabilities():
    """Expose the capability matrix before the dynamic device-id route."""
    return await adapter_service.list_vendor_capabilities()


@router.get("/{device_id}/capabilities", summary="Get device capabilities")
async def get_device_capabilities(
    device_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await adapter_service.get_device_capabilities(db, device_id, scope_for(user))


# ---- device CRUD --------------------------------------------------------
@router.get("", response_model=list[DeviceOut], summary="List all network devices accessible to the current user", description="Returns a list of network devices (firewalls, access points) scoped to the authenticated user's tenant. Requires device.read permission. Supports filtering by location and device type.")
async def list_devices(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_devices(db, scope_for(user))


@router.get("/{device_id}", response_model=DeviceOut, summary="Retrieve a single network device by ID", description="Fetches detailed information about the specified network device including its configuration and status. Access is scoped to the user's tenant permissions. Requires a valid access token.")
async def get_device(
    device_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_device(db, device_id, scope_for(user))


@router.post("", response_model=DeviceOut, status_code=status.HTTP_201_CREATED, summary="Register a new network device in the system", description="Creates a new device record with its connection details and firewall adapter type. Requires the device.write permission. Returns the created device with its unique identifier.")
async def create_device(
    body: DeviceCreate, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "device.write")
    return await service.create_device(db, body, scope_for(user), user.id, request)


@router.put("/{device_id}", response_model=DeviceOut, summary="Update an existing network device configuration", description="Updates the specified device's settings such as name, IP address, or adapter type. Requires the device.write permission. Returns the updated device object.")
async def update_device(
    device_id: uuid.UUID, body: DeviceUpdate, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "device.write")
    return await service.update_device(db, device_id, body, scope_for(user), user.id, request)


@router.delete("/{device_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Deactivate a network device (soft delete)", description="Deactivates the specified device, removing it from active use while preserving its data for auditing. Requires the device.write permission. Returns 204 No Content on success.")
async def delete_device(
    device_id: uuid.UUID, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "device.write")
    await service.deactivate_device(db, device_id, scope_for(user), user.id, request)


# ---- credentials (secrets never returned in plaintext) -----------------
@router.put("/{device_id}/credential", response_model=CredentialOut, summary="Set or update device authentication credentials", description="Stores encrypted credentials for the specified device used to connect to the firewall adapter. Credentials are never returned in plaintext. Requires the device.write permission.")
async def set_credential(
    device_id: uuid.UUID, body: CredentialSet, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "device.write")
    return await service.set_credential(db, device_id, body, scope_for(user), user.id, request)


@router.get("/{device_id}/credential", response_model=CredentialOut, summary="Retrieve masked device credential metadata", description="Returns metadata about the stored credentials for the specified device. The actual secret value is masked and never exposed in the response. Requires a valid access token.")
async def get_credential(
    device_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    return await service.get_credential_masked(db, device_id, scope_for(user))


# ---- firewall adapter actions ------------------------------------------
@router.post("/{device_id}/test-connection", summary="Test connectivity to the network device", description="Attempts to establish a connection to the specified device using its stored credentials. Returns a success or failure message with diagnostic details. Requires the device.write permission.")
async def test_connection(
    device_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "device.write")
    result = await adapter_service.test_connection_service(db, device_id, scope_for(user))
    return {"ok": result.ok, "message": result.message, "data": result.data}


@router.post("/{device_id}/discover", summary="Discover device capabilities and configuration", description="Probes the specified network device to discover its capabilities, active interfaces, and current configuration. Useful for synchronizing the system with the actual device state. Requires the device.write permission.")
async def discover_device(
    device_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "device.write")
    return await adapter_service.discover_device(db, device_id, scope_for(user))


@router.post("/{device_id}/authorize-guest", summary="Authorize a guest session on the network device", description="Sends an authorization command to the firewall to allow a guest's network access. The request body should contain guest identifier and session parameters. Requires the device.write permission.")
async def authorize_guest(
    device_id: uuid.UUID, body: dict, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "device.write")
    result = await adapter_service.authorize_guest_service(db, device_id, scope_for(user), body)
    return {"ok": result.ok, "message": result.message}


@router.post("/{device_id}/revoke-guest", summary="Revoke an active guest session on the network device", description="Sends a revocation command to the firewall to terminate a guest's network access. The request body should identify the guest session to be revoked. Requires the device.write permission.")
async def revoke_guest(
    device_id: uuid.UUID, body: dict,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "device.write")
    result = await adapter_service.revoke_guest_service(db, device_id, scope_for(user), body)
    return {"ok": result.ok, "message": result.message}
