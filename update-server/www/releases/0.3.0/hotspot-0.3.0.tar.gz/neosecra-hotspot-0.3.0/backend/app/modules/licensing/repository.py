"""Data access for licensing."""
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.licensing.models import CustomerLicense


async def get_for_customer(db: AsyncSession, customer_id: uuid.UUID) -> CustomerLicense | None:
    res = await db.execute(
        select(CustomerLicense).where(CustomerLicense.customer_id == customer_id)
    )
    return res.scalars().first()


async def list_for_customers(
    db: AsyncSession, customer_ids: list[uuid.UUID]
) -> list[CustomerLicense]:
    if not customer_ids:
        return []
    res = await db.execute(
        select(CustomerLicense).where(CustomerLicense.customer_id.in_(customer_ids))
    )
    return list(res.scalars().all())
