"""Alarm event service — CRUD, stats, trend."""
import logging
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.alarm.models import AlarmEvent

log = logging.getLogger(__name__)


async def create_alarm(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None,
    severity: str,
    title: str,
    message: str | None = None,
    source: str | None = None,
    trigger_id: uuid.UUID | None = None,
    commit: bool = True,
) -> AlarmEvent:
    event = AlarmEvent(
        customer_id=customer_id,
        location_id=location_id,
        trigger_id=trigger_id,
        severity=severity,
        title=title,
        message=message,
        source=source,
        event_time=datetime.now(timezone.utc),
    )
    db.add(event)
    if commit:
        await db.commit()
        await db.refresh(event)
    else:
        await db.flush()
    return event


async def list_alarms(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID | None = None,
    severity: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[AlarmEvent]:
    q = select(AlarmEvent)
    if customer_id:
        q = q.where(AlarmEvent.customer_id == customer_id)
    if severity:
        q = q.where(AlarmEvent.severity == severity)
    q = q.order_by(AlarmEvent.event_time.desc()).offset(offset).limit(limit)
    res = await db.execute(q)
    return list(res.scalars().all())


async def acknowledge_alarm(
    db: AsyncSession,
    event_id: uuid.UUID,
    user_id: uuid.UUID,
) -> AlarmEvent:
    event = await db.get(AlarmEvent, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Alarm bulunamadi")
    if event.acknowledged:
        raise HTTPException(status_code=400, detail="Alarm zaten onaylanmis")
    event.acknowledged = True
    event.acknowledged_at = datetime.now(timezone.utc)
    event.acknowledged_by = user_id
    await db.commit()
    await db.refresh(event)
    return event


async def get_alarm_stats(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID | None = None,
) -> dict:
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    q = select(
        func.count().label("total"),
        func.sum(case((AlarmEvent.severity == "critical", 1), else_=0)).label("critical"),
        func.sum(case((AlarmEvent.severity == "warning", 1), else_=0)).label("warning"),
        func.sum(case((AlarmEvent.severity == "info", 1), else_=0)).label("info"),
        func.sum(case((AlarmEvent.acknowledged.is_(True), 1), else_=0)).label("acknowledged"),
    ).where(AlarmEvent.event_time >= today_start)

    if customer_id:
        q = q.where(AlarmEvent.customer_id == customer_id)

    res = await db.execute(q)
    row = res.one()
    total = row.total or 0
    critical = row.critical or 0
    warning = row.warning or 0
    info = row.info or 0
    acknowledged = row.acknowledged or 0

    return {
        "total_today": total,
        "critical": critical,
        "warning": warning,
        "info": info,
        "acknowledged": acknowledged,
        "unacknowledged": total - acknowledged,
    }


async def get_alarm_trend(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID | None = None,
    days: int = 7,
) -> list[dict]:
    from sqlalchemy import cast, Date

    since = datetime.now(timezone.utc) - timedelta(days=days)
    q = select(
        cast(AlarmEvent.event_time, Date).label("date"),
        func.count().label("count"),
        func.sum(case((AlarmEvent.severity == "critical", 1), else_=0)).label("critical"),
        func.sum(case((AlarmEvent.severity == "warning", 1), else_=0)).label("warning"),
        func.sum(case((AlarmEvent.severity == "info", 1), else_=0)).label("info"),
    ).where(AlarmEvent.event_time >= since)

    if customer_id:
        q = q.where(AlarmEvent.customer_id == customer_id)

    q = q.group_by(cast(AlarmEvent.event_time, Date)).order_by(cast(AlarmEvent.event_time, Date))

    res = await db.execute(q)
    return [
        {
            "date": str(r.date),
            "count": r.count or 0,
            "critical": r.critical or 0,
            "warning": r.warning or 0,
            "info": r.info or 0,
        }
        for r in res.all()
    ]


def case(*args, else_=None):
    """Helper for SQL CASE expressions."""
    from sqlalchemy import case as sa_case
    return sa_case(*args, else_=else_)
