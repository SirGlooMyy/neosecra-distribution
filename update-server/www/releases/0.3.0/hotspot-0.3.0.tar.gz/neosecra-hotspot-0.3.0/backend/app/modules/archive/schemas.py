import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ChunkOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    period_start: datetime
    period_end: datetime
    log_count: int
    content_hash: str
    curr_hash: str
    prev_hash: str
    signature_value: str | None = None
    signature_time: datetime | None = None
    certificate_serial: str | None = None
    sign_method: str | None = None
    status: str
    minio_object_key: str | None = None
    content_size: int
    created_at: datetime


class ChunkCreate(BaseModel):
    customer_id: uuid.UUID
    period_start: datetime
    period_end: datetime


class VerifyResult(BaseModel):
    chunk_id: uuid.UUID
    ok: bool
    chain_valid: bool
    signature_valid: bool | None = None
    message: str
    verified_at: datetime


class BuildResult(BaseModel):
    chunk_id: uuid.UUID
    customer_id: uuid.UUID
    period_start: datetime
    period_end: datetime
    log_count: int
    curr_hash: str
    status: str
