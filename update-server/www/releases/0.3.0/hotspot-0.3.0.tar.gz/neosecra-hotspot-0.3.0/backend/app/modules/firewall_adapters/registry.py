"""Vendor adapter registry. Maps a device vendor slug to its adapter class.

Adding a vendor = register it here + ship its adapter module. The service and
portal flow never import concrete adapters directly (Mutlak Kural #7).
"""
from __future__ import annotations

from app.modules.firewall_adapters.base import ConnectionConfig, FirewallAdapter
from app.modules.firewall_adapters.fortigate import FortiGateAdapter

_REGISTRY: dict[str, type[FirewallAdapter]] = {
    FortiGateAdapter.vendor: FortiGateAdapter,
}


def supported_vendors() -> list[str]:
    return list(_REGISTRY)


def get_adapter_class(vendor: str) -> type[FirewallAdapter]:
    key = (vendor or "").strip().lower()
    if key not in _REGISTRY:
        raise ValueError(f"Unsupported firewall vendor: {vendor!r}. Known: {supported_vendors()}")
    return _REGISTRY[key]


def build_adapter(config: ConnectionConfig) -> FirewallAdapter:
    cls = get_adapter_class(config.vendor)
    return cls(config)
