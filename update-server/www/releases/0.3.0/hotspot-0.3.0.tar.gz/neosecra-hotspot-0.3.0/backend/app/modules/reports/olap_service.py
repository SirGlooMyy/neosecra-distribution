"""OLAP engine for multi-dimensional session/syslog analytics.
"""
from __future__ import annotations

import enum
import uuid
from dataclasses import dataclass, field as dataclass_field
from datetime import date, datetime, timezone
from typing import Any

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.sessions.models import GuestSession
from app.modules.syslog.models import SyslogRecord


class OlapDimension(str, enum.Enum):
    TIME = "time"
    LOCATION = "location"
    DEVICE = "device"
    AUTH_METHOD = "auth_method"
    VENDOR = "vendor"
    SEVERITY = "severity"
    CUSTOMER = "customer"
    PARTNER = "partner"
    SESSION_STATUS = "session_status"
    HOUR_OF_DAY = "hour_of_day"
    DAY_OF_WEEK = "day_of_week"
    FACILITY = "facility"
    HOSTNAME = "hostname"


GRANULARITY_HOUR = "hour"
GRANULARITY_DAY = "day"


def parse_dimension(raw: str) -> OlapDimension:
    try:
        return OlapDimension(raw)
    except ValueError:
        raise ValueError(f"Gecersiz dimension: {raw}. Secenekler: {[d.value for d in OlapDimension]}")
GRANULARITY_WEEK = "week"
GRANULARITY_MONTH = "month"
GRANULARITIES = (GRANULARITY_HOUR, GRANULARITY_DAY, GRANULARITY_WEEK, GRANULARITY_MONTH)


@dataclass
class OlapQuery:
    dimensions: list[OlapDimension] = dataclass_field(default_factory=list)
    measures: list[str] = dataclass_field(default_factory=lambda: ["count"])
    filters: dict[str, Any] = dataclass_field(default_factory=dict)
    date_from: date | None = None
    date_to: date | None = None
    granularity: str = GRANULARITY_DAY
    source: str = "sessions"  # sessions | syslog
    customer_id: uuid.UUID | None = None


_DIM_COLUMNS = {
    OlapDimension.LOCATION: ("location_id", GuestSession.location_id),
    OlapDimension.DEVICE: ("device_id", GuestSession.device_id),
    OlapDimension.AUTH_METHOD: ("auth_method", GuestSession.auth_method),
    OlapDimension.SESSION_STATUS: ("status", GuestSession.status),
    OlapDimension.CUSTOMER: ("customer_id", GuestSession.customer_id),
    OlapDimension.HOUR_OF_DAY: ("hour_of_day", func.extract("hour", GuestSession.started_at)),
    OlapDimension.DAY_OF_WEEK: ("day_of_week", func.extract("dow", GuestSession.started_at)),
}

_DIM_COLUMNS_SYSLOG = {
    OlapDimension.SEVERITY: ("severity", SyslogRecord.severity),
    OlapDimension.VENDOR: ("app_name", SyslogRecord.app_name),
    OlapDimension.FACILITY: ("facility", SyslogRecord.facility),
    OlapDimension.HOSTNAME: ("hostname", SyslogRecord.hostname),
    OlapDimension.CUSTOMER: ("tenant_id", SyslogRecord.tenant_id),
    OlapDimension.HOUR_OF_DAY: ("hour_of_day", func.extract("hour", SyslogRecord.created_at)),
    OlapDimension.DAY_OF_WEEK: ("day_of_week", func.extract("dow", SyslogRecord.created_at)),
}


def _time_trunc(granularity: str, column: Any) -> Any:
    if granularity == GRANULARITY_HOUR:
        return func.date_trunc("hour", column)
    if granularity == GRANULARITY_DAY:
        return func.date_trunc("day", column)
    if granularity == GRANULARITY_WEEK:
        return func.date_trunc("week", column)
    if granularity == GRANULARITY_MONTH:
        return func.date_trunc("month", column)
    return func.date_trunc("day", column)


def _measure_expr(measure: str, model: Any) -> Any:
    if measure == "count":
        return func.count(model.id)
    if measure == "unique_users":
        mac_col = getattr(model, "mac", None)
        if mac_col is not None:
            return func.count(func.distinct(mac_col))
        return func.count(func.distinct(model.id))
    if measure == "unique_phones":
        phone_col = getattr(model, "phone", None)
        if phone_col is not None:
            return func.count(func.distinct(phone_col))
        return func.count(func.distinct(model.id))
    if measure == "data_volume":
        return func.coalesce(func.sum(func.coalesce(model.bytes_in, 0) + func.coalesce(model.bytes_out, 0)), 0)
    if measure == "duration_avg":
        return func.avg(
            func.extract("epoch", model.ended_at - model.started_at)
        ).filter(model.ended_at.isnot(None), model.started_at.isnot(None))
    if measure == "duration_max":
        return func.max(
            func.extract("epoch", model.ended_at - model.started_at)
        ).filter(model.ended_at.isnot(None), model.started_at.isnot(None))
    return func.count(model.id)


async def query_olap(db: AsyncSession, query: OlapQuery) -> dict:
    """Build dynamic SQL and execute OLAP query."""
    is_syslog = query.source == "syslog"
    model = SyslogRecord if is_syslog else GuestSession
    date_col = model.created_at if is_syslog else getattr(model, "started_at", model.created_at)
    dim_cols = _DIM_COLUMNS_SYSLOG if is_syslog else _DIM_COLUMNS

    q = select()
    group_by_cols = []

    for dim in query.dimensions:
        if dim == OlapDimension.TIME:
            col = _time_trunc(query.granularity, date_col)
            group_by_cols.append(col)
            q = q.add_columns(col.label("period"))
        elif dim in dim_cols:
            _, col = dim_cols[dim]
            group_by_cols.append(col)
            q = q.add_columns(col.label(str(dim.value)))

    for m in query.measures:
        expr = _measure_expr(m, model)
        q = q.add_columns(expr.label(m))

    q = q.select_from(model)

    if query.customer_id:
        if is_syslog:
            q = q.where(model.tenant_id == query.customer_id)  # type: ignore[attr-defined]
        else:
            q = q.where(model.customer_id == query.customer_id)  # type: ignore[attr-defined]

    if query.date_from:
        q = q.where(date_col >= datetime.combine(query.date_from, datetime.min.time(), tzinfo=timezone.utc))
    if query.date_to:
        q = q.where(date_col < datetime.combine(query.date_to, datetime.min.time(), tzinfo=timezone.utc))

    for field, value in query.filters.items():
        col = getattr(model, field, None)
        if col is not None:
            if isinstance(value, list):
                q = q.where(col.in_(value))
            else:
                q = q.where(col == value)

    if group_by_cols:
        q = q.group_by(*group_by_cols)

    for dim in query.dimensions:
        if dim == OlapDimension.TIME:
            q = q.order_by(text("period"))
            break

    res = await db.execute(q)
    rows = res.all()

    columns = []
    for dim in query.dimensions:
        columns.append(dim.value)
    columns.extend(query.measures)

    data = []
    for row in rows:
        item = {}
        idx = 0
        for dim in query.dimensions:
            item[dim.value] = str(row[idx]) if row[idx] is not None else None
            idx += 1
        for m in query.measures:
            val = row[idx]
            item[m] = float(val) if val is not None else 0 if m in ("count", "unique_users") else None
            idx += 1
        data.append(item)

    return {
        "columns": columns,
        "rows": data,
        "total_rows": len(data),
        "query": {
            "dimensions": [d.value for d in query.dimensions],
            "measures": query.measures,
            "granularity": query.granularity,
            "source": query.source,
        },
    }


def get_report_templates(include_presets: bool = False) -> list[dict]:
    """Return generated OLAP templates and, when requested, Analyzer presets.

    The opt-in flag preserves the original OLAP helper contract for callers
    that expect every id to be a ``tmpl-*`` id; the HTTP endpoint enables it so
    the scheduler sees the same ready-made reports as the Reports page.
    """
    from app.modules.reports.service import DIFFERENTIATOR_REPORTS, QUICK_REPORTS

    templates = []
    if include_presets:
        templates.extend(
            {
                "id": key,
                "name": value["title"],
                "category": "Hazır Analyzer Raporları",
                "source": "analyzer",
                "description": value["description"],
                "scheduleable": True,
            }
            for key, value in QUICK_REPORTS.items()
        )
        templates.extend(
            {
                "id": key,
                "name": value,
                "category": "5651 / Operasyon Raporları",
                "source": "analyzer",
                "description": "Uyum ve operasyon denetimi için hazır rapor.",
                "scheduleable": True,
            }
            for key, value in DIFFERENTIATOR_REPORTS.items()
        )
    _id = [0]

    def _tid() -> str:
        _id[0] += 1
        return f"tmpl-{_id[0]:04d}"

    measures = ["count", "unique_users", "data_volume", "duration_avg", "duration_max"]
    dims_1d = [
        OlapDimension.LOCATION, OlapDimension.DEVICE, OlapDimension.AUTH_METHOD,
        OlapDimension.SESSION_STATUS, OlapDimension.HOUR_OF_DAY, OlapDimension.DAY_OF_WEEK,
        OlapDimension.CUSTOMER,
    ]
    {d.value: d for d in dims_1d}

    # 1. Single-dimension session templates (7 dims x 5 measures = 35)
    for dim in dims_1d:
        for m in measures:
            templates.append({
                "id": _tid(), "name": f"{_measure_label(m)} by {_dim_label(dim.value)}",
                "dimensions": [dim.value], "measures": [m], "source": "sessions",
                "description": f"{_measure_label(m)} grouped by {_dim_label(dim.value)}.",
            })

    # 2. Time-series templates (4 granularities x 5 measures = 20)
    for g in GRANULARITIES:
        for m in measures:
            templates.append({
                "id": _tid(), "name": f"{_measure_label(m)} ({g}ly)",
                "dimensions": ["time"], "measures": [m], "source": "sessions",
                "granularity": g,
                "description": f"{_measure_label(m)} over time ({g} granularity).",
            })

    # 3. Two-dimension templates (21 combos x 3 measures = 63)
    dims_list = list(dims_1d)
    for i in range(len(dims_list)):
        for j in range(i + 1, len(dims_list)):
            for m in measures[:3]:
                templates.append({
                    "id": _tid(),
                    "name": f"{_measure_label(m)} by {_dim_label(dims_list[i].value)} & {_dim_label(dims_list[j].value)}",
                    "dimensions": [dims_list[i].value, dims_list[j].value],
                    "measures": [m], "source": "sessions",
                    "description": f"{_measure_label(m)} cross {_dim_label(dims_list[i].value)} by {_dim_label(dims_list[j].value)}.",
                })

    # 4. Filtered-by-auth-method (7 auth methods x 3 measures = 21)
    auth_methods = ["sms", "voucher", "tc_sms", "whatsapp", "local", "ldap", "meeting"]
    for method in auth_methods:
        for m in ["count", "unique_users", "duration_avg"]:
            templates.append({
                "id": _tid(), "name": f"{_measure_label(m)} - {method.upper()} Auth",
                "dimensions": ["time"], "measures": [m], "source": "sessions",
                "filters": {"auth_method": method},
                "description": f"{_measure_label(m)} for {method} authentication method.",
            })

    # 5. Filtered-by-status (4 statuses x 3 measures = 12)
    statuses = ["active", "closed", "expired", "pending"]
    for st in statuses:
        for m in ["count", "unique_users", "data_volume"]:
            templates.append({
                "id": _tid(), "name": f"{_measure_label(m)} - {st.title()} Sessions",
                "dimensions": ["time"], "measures": [m], "source": "sessions",
                "filters": {"status": st},
                "description": f"{_measure_label(m)} for {st} sessions.",
            })

    # 6. Syslog templates (5 syslog dims = 5)
    syslog_dims = [OlapDimension.VENDOR, OlapDimension.SEVERITY, OlapDimension.FACILITY, OlapDimension.HOSTNAME, OlapDimension.HOUR_OF_DAY]
    for dim in syslog_dims:
        templates.append({
            "id": _tid(), "name": f"Syslog by {_dim_label(dim.value)}",
            "dimensions": [dim.value], "measures": ["count"], "source": "syslog",
            "description": f"Syslog record count grouped by {_dim_label(dim.value)}.",
        })

    # 7. Syslog time-series (4 granularities = 4)
    for g in GRANULARITIES:
        templates.append({
            "id": _tid(), "name": f"Syslog Count ({g}ly)",
            "dimensions": ["time"], "measures": ["count"], "source": "syslog",
            "granularity": g,
            "description": f"Syslog record count over time ({g} granularity).",
        })

    # 8. Syslog severity + dimension (5 severity levels x location/vendor = 10)
    for sev in range(8):
        templates.append({
            "id": _tid(), "name": f"Syslog Severity={sev} by Vendor",
            "dimensions": ["vendor"], "measures": ["count"], "source": "syslog",
            "filters": {"severity": sev},
            "description": f"Vendor distribution for severity {sev} syslog records.",
        })

    # 9. Location + auth method combos (auth_methods x location = 7)
    for method in auth_methods[:5]:
        templates.append({
            "id": _tid(), "name": f"{method.upper()} Auth by Location",
            "dimensions": ["location", "auth_method"], "measures": ["count", "unique_users"],
            "source": "sessions", "filters": {"auth_method": method},
            "description": f"{method} authentication distribution across locations.",
        })

    # 10. Duration-focused (3 templates)
    templates.append({
        "id": _tid(), "name": "Average Session Duration by Auth Method",
        "dimensions": ["auth_method"], "measures": ["duration_avg"], "source": "sessions",
    })
    templates.append({
        "id": _tid(), "name": "Average Session Duration by Location",
        "dimensions": ["location"], "measures": ["duration_avg"], "source": "sessions",
    })
    templates.append({
        "id": _tid(), "name": "Average Session Duration by Day of Week",
        "dimensions": ["day_of_week"], "measures": ["duration_avg"], "source": "sessions",
    })

    # 11. Peak hours (8 hour ranges x 3 measures = 24)
    for hour in range(0, 24, 3):
        templates.append({
            "id": _tid(), "name": f"Peak Hour {hour:02d}:00-{hour+3:02d}:00",
            "dimensions": ["hour_of_day"], "measures": ["count", "unique_users"],
            "source": "sessions",
            "filters": {"hour_of_day": [hour, hour + 1, hour + 2]},
            "description": f"Session activity during {hour:02d}:00-{hour+3:02d}:00.",
        })

    # 12. Day-of-week breakdown (7 days x 2 measures = 14)
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    for i, day in enumerate(days):
        templates.append({
            "id": _tid(), "name": f"{day} Sessions",
            "dimensions": ["day_of_week"], "measures": ["count", "unique_users"],
            "source": "sessions",
            "filters": {"day_of_week": i},
            "description": f"Session count on {day}s.",
        })

    # 13. Data volume focused (2)
    templates.append({
        "id": _tid(), "name": "Data Volume by Device",
        "dimensions": ["device"], "measures": ["data_volume", "count"], "source": "sessions",
    })
    templates.append({
        "id": _tid(), "name": "Data Volume by Auth Method",
        "dimensions": ["auth_method"], "measures": ["data_volume"], "source": "sessions",
    })

    return templates


def _measure_label(m: str) -> str:
    labels = {
        "count": "Session Count",
        "unique_users": "Unique Users",
        "unique_phones": "Unique Phones",
        "data_volume": "Data Volume (MB)",
        "duration_avg": "Avg Duration (sec)",
        "duration_max": "Max Duration (sec)",
    }
    return labels.get(m, m.replace("_", " ").title())


def _dim_label(d: str) -> str:
    labels = {
        "location": "Location",
        "device": "Device",
        "auth_method": "Auth Method",
        "session_status": "Status",
        "hour_of_day": "Hour of Day",
        "day_of_week": "Day of Week",
        "customer": "Customer",
        "partner": "Partner",
        "time": "Time",
        "vendor": "Vendor",
        "severity": "Severity",
        "facility": "Facility",
        "hostname": "Hostname",
    }
    return labels.get(d, d.replace("_", " ").title())
