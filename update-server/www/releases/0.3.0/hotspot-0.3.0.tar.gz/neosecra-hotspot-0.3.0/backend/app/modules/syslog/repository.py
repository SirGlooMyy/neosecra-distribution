"""FirewallLog repository — CRUD for parsed firewall logs."""
from __future__ import annotations

import logging
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.customers.models import Customer
from app.modules.devices.models import Device
from app.modules.locations.models import Location
from app.modules.syslog.models import FirewallLog

log = logging.getLogger(__name__)


async def insert_firewall_log(db: AsyncSession, log_entry: FirewallLog) -> FirewallLog:
    """Insert a single FirewallLog and flush."""
    db.add(log_entry)
    await db.flush()
    return log_entry


async def insert_firewall_log_batch(db: AsyncSession, logs: list[FirewallLog]) -> int:
    """Insert a batch of FirewallLog records and flush.

    Returns the count of records inserted.
    """
    if not logs:
        return 0
    for entry in logs:
        db.add(entry)
    await db.flush()
    return len(logs)


async def resolve_tenant_for_hostname(
    db: AsyncSession, hostname: str
) -> tuple[uuid.UUID, uuid.UUID] | None:
    """Resolve hostname to (tenant_id, customer_id).

    Looks up Device by name → Location → Customer → Tenant.

    Returns None if no matching device is found.
    """
    stmt = (
        select(
            Customer.tenant_id,
            Customer.id,
        )
        .select_from(Device)
        .join(Location, Device.location_id == Location.id)
        .join(Customer, Location.customer_id == Customer.id)
        .where(Device.name == hostname)
        .where(Device.is_active.is_(True))
    )
    result = await db.execute(stmt)
    row = result.one_or_none()
    if row is None:
        # Fallback: try SyslogSource identifier
        from app.modules.devices.models import SyslogSource
        stmt2 = (
            select(
                Customer.tenant_id,
                Customer.id,
            )
            .select_from(SyslogSource)
            .join(Device, SyslogSource.device_id == Device.id)
            .join(Location, Device.location_id == Location.id)
            .join(Customer, Location.customer_id == Customer.id)
            .where(SyslogSource.identifier == hostname)
            .where(Device.is_active.is_(True))
        )
        result2 = await db.execute(stmt2)
        row2 = result2.one_or_none()
        if row2 is None:
            return None
        return row2[0], row2[1]
    return row[0], row[1]
