"""Fidelio (Micros) PMS XML Web Service integration."""
import logging
from datetime import date, datetime

import httpx

from app.modules.pms.demo import demo_or_fail
from app.modules.pms.schemas import PmsVerifyResult
from app.modules.pms.utils import normalize_turkish as _normalize_turkish

log = logging.getLogger(__name__)

XML_TEMPLATE = """<?xml version="1.0" encoding="utf-8"?>
<FidelioRequest>
  <RequestType>GetReservation</RequestType>
  <Credentials>
    <Username>{username}</Username>
    <Password>{password}</Password>
  </Credentials>
  <Reservation>
    <RoomNumber>{room}</RoomNumber>
    <LastName>{surname}</LastName>
  </Reservation>
</FidelioRequest>"""


def _build_xml_request(room: str, surname: str, username: str, password: str) -> str:
    return XML_TEMPLATE.format(
        room=_escape_xml(room),
        surname=_escape_xml(surname),
        username=_escape_xml(username or ""),
        password=_escape_xml(password or ""),
    )


def _escape_xml(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def _parse_fidelio_response(xml_response: str) -> dict:
    import xml.etree.ElementTree as ET

    try:
        root = ET.fromstring(xml_response)
    except ET.ParseError as exc:
        log.warning("[Fidelio] XML parse hatasi: %s", exc)
        return {}

    res = root.find(".//Reservation") or root
    guest = (res.find("GuestName") or res.find("FullName"))
    check_in_el = res.find("CheckIn") or res.find("ArrivalDate")
    check_out_el = res.find("CheckOut") or res.find("DepartureDate")
    status_el = res.find("Status") or res.find("ReservationStatus")
    found_el = res.find("Found") or res.find("Success")

    status = status_el.text if status_el is not None else "in_house"
    found = found_el.text if found_el is not None else "true"

    def _parse(val: str | None) -> date | None:
        if not val:
            return None
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d"):
            try:
                return datetime.strptime(val.strip(), fmt).date()
            except ValueError:
                continue
        return None

    return {
        "verified": (found or "").lower() in ("true", "1", "yes") and (status or "").lower() in ("in_house", "checked_in", "reserved"),
        "guest_name": guest.text if guest is not None else "",
        "check_in": _parse(check_in_el.text if check_in_el is not None else None),
        "check_out": _parse(check_out_el.text if check_out_el is not None else None),
        "stay_status": status.lower() if status else "unknown",
    }


async def _mock_verify(room_number: str, surname: str) -> dict:
    is_valid = room_number.strip().isdigit() and len(_normalize_turkish(surname)) >= 3
    return {
        "verified": is_valid,
        "guest_name": f"GUEST/{surname.upper()}" if is_valid else None,
        "check_in": date.today() if is_valid else None,
        "check_out": date(2026, 12, 31) if is_valid else None,
        "stay_status": "checked_in" if is_valid else "unknown",
    }


async def verify_guest(
    room_number: str,
    surname: str,
    pms_config: dict | None = None,
) -> PmsVerifyResult:
    pms_config = pms_config or {}
    room_clean = (room_number or "").strip()
    surname_clean = _normalize_turkish(surname or "")

    if not room_clean or not surname_clean:
        log.warning("[Fidelio] Oda numarasi veya soyad bos")
        return PmsVerifyResult(verified=False, vendor="fidelio", message="Oda numarasi ve soyad gerekli")

    endpoint = (pms_config.get("host") or "").rstrip("/")
    port = pms_config.get("port", 80)
    username = pms_config.get("username", "")
    password = pms_config.get("password", "")

    if not endpoint:
        log.info("[Fidelio] WS yapilandirilmamis")
        return await demo_or_fail(
            vendor="fidelio",
            room_number=room_clean,
            surname_or_birth=surname_clean,
            mock_fn=_mock_verify,
            missing_config_message="Fidelio WS yapilandirilmemis",
        )

    service_url = f"{endpoint}:{port}/fidelio/service" if port else f"{endpoint}/fidelio/service"
    xml_body = _build_xml_request(room_clean, surname_clean, username, password)

    try:
        async with httpx.AsyncClient(timeout=15.0, verify=False) as client:
            resp = await client.post(
                service_url,
                content=xml_body,
                headers={"Content-Type": "text/xml; charset=utf-8"},
            )
            resp.raise_for_status()
            data = _parse_fidelio_response(resp.text)
            log.info("[Fidelio] Room=%s guest=%s verified=%s", room_clean, data.get("guest_name"), data.get("verified"))
            return PmsVerifyResult(
                verified=data.get("verified", False),
                guest_name=data.get("guest_name"),
                check_in=data.get("check_in"),
                check_out=data.get("check_out"),
                stay_status=data.get("stay_status", "unknown"),
                vendor="fidelio",
            )
    except httpx.TimeoutException:
        log.warning("[Fidelio] Zaman asimi: %s", service_url)
        return PmsVerifyResult(verified=False, vendor="fidelio", message="Fidelio WS zaman asimi")
    except httpx.HTTPStatusError as exc:
        log.warning("[Fidelio] HTTP %s", exc.response.status_code)
        return PmsVerifyResult(verified=False, vendor="fidelio", message=f"Fidelio WS HTTP: {exc.response.status_code}")
    except Exception as exc:
        log.error("[Fidelio] Baglanti hatasi: %s", exc)
        return PmsVerifyResult(verified=False, vendor="fidelio", message=f"Fidelio WS baglanti hatasi: {exc}")
