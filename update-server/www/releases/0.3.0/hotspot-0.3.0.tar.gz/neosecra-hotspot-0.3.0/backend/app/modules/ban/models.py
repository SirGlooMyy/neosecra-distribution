import uuid
from datetime import datetime

from sqlalchemy import DateTime, String, Text, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk


class BanRule(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    """Ban rule for guest users.

    Supports banning by MAC address, phone number, or IP address.
    Banned users are blocked from creating new sessions.
    """

    __tablename__ = "ban_rules"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)

    # Ban target (at least one required)
    mac_address: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True, index=True)
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)

    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    banned_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)


class WhitelistEntry(Base, UUIDPK, TimestampMixin):
    """Whitelisted MAC/phone that bypasses ban rules.

    Used for VIP users, admin devices, or critical infrastructure.
    Independent from RADIUS MAB whitelist.
    """

    __tablename__ = "whitelist_entries"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)

    mac_address: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True, index=True)
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
