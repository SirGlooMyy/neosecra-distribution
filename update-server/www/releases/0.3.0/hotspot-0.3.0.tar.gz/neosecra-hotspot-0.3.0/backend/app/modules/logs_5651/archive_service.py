"""Object-store upload for 5651 archive payloads (zstd compressed).

Provider-agnostic so the same code path works in dev, on-prem and SaaS:
  * "local"  -> file under ARCHIVE_LOCAL_DIR (default; no extra deps)
  * "minio"  -> S3-compatible store (MinIO), client lazy-imported so the app
                boots without the minio/boto3 lib installed
  * "none"   -> dev: no upload; content_ref encodes the content hash only

Compression: zstd (varsayılan, settings.ARCHIVE_COMPRESSION ile kontrol edilir).
zstd > gzip: daha hızlı açılır, log verilerinde daha iyi sıkıştırma sağlar.

Hash chain + digital signature korunur. Arşiv nesneleri silinemez/üzerine
yazılamaz (MinIO Object Lock / WORM ile).
"""
from __future__ import annotations

import hashlib
import io
import logging
import os
import uuid
from datetime import datetime, timezone

from app.core.config import settings

log = logging.getLogger(__name__)

_BUCKET_CACHE: str | None = None

_COMPRESSION_EXT: str = ".jsonl.zst"  # zstd varsayılan


def content_hash(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def compress(data: bytes) -> bytes:
    """Compress data using zstd (or gzip fallback)."""
    if settings.ARCHIVE_COMPRESSION == "zstd":
        try:
            import pyzstd
            return pyzstd.compress(data)
        except ImportError:
            log.warning("pyzstd not available, falling back to gzip")
            import gzip
            return gzip.compress(data)
    else:
        import gzip
        return gzip.compress(data)


def decompress(data: bytes) -> bytes:
    """Decompress zstd (or gzip fallback)."""
    if settings.ARCHIVE_COMPRESSION == "zstd":
        try:
            import pyzstd
            return pyzstd.decompress(data)
        except ImportError:
            import gzip
            return gzip.decompress(data)
    else:
        import gzip
        return gzip.decompress(data)


def serialize_jsonl(records: list[dict]) -> bytes:
    """Serialize records to JSONL bytes."""
    import json
    lines = "\n".join(json.dumps(r, default=str, ensure_ascii=False) for r in records)
    return lines.encode("utf-8")


def serialize_raw_logs(records: list[dict]) -> bytes:
    """Deterministic JSONL of raw traffic/syslog/radius logs, zstd compressed.

    Sorted by (timestamp/event_time/created_at, id) and emitted with sort_keys
    so the same input always yields the same artifact/content_hash.
    """
    import json

    def _sort_key(rec: dict) -> tuple[str, str]:
        ts = str(rec.get("timestamp") or rec.get("event_time") or rec.get("created_at") or "")
        rid = str(rec.get("id") or rec.get("session_id") or "")
        return (ts, rid)

    sorted_records = sorted(records, key=_sort_key)
    lines = "\n".join(json.dumps(r, default=str, ensure_ascii=False, sort_keys=True) for r in sorted_records)
    payload = lines.encode("utf-8") if sorted_records else b""
    return compress(payload)


def extract_searchable_fields(records: list[dict]) -> dict:
    """Extract metadata index (IPs, MACs, usernames, domains, devices) from raw log records."""
    ips: set[str] = set()
    macs: set[str] = set()
    users: set[str] = set()
    domains: set[str] = set()
    devices: set[str] = set()

    for r in records:
        for ip_k in ("ip", "src_ip", "dst_ip", "source_ip", "dest_ip", "nas_ip"):
            val = r.get(ip_k)
            if val and val != "::":
                ips.add(str(val))
        mac = r.get("mac")
        if mac:
            macs.add(str(mac).upper())
        for user_k in ("username", "user", "phone"):
            val = r.get(user_k)
            if val:
                users.add(str(val))
        domain = r.get("domain")
        if domain:
            domains.add(str(domain))
        device_id = r.get("device_id")
        if device_id:
            devices.add(str(device_id))

    return {
        "ips": sorted(list(ips)),
        "macs": sorted(list(macs)),
        "users": sorted(list(users)),
        "domains": sorted(list(domains)),
        "devices": sorted(list(devices)),
    }


def _object_key(customer_id: uuid.UUID, period_start: datetime, content_hash_hex: str) -> str:
    ps = period_start.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{customer_id}/{ps}/{content_hash_hex}{_COMPRESSION_EXT}"


def upload(content: bytes, *, customer_id: uuid.UUID, period_start: datetime) -> str:
    """Store `content` and return a content_ref (object key / path). Idempotent:
    same bytes -> same hash -> same key. Never raises for provider misconfig in
    dev; falls back to 'none' so the archive record can still be sealed.

    Content is compressed with zstd before upload.
    """
    compressed = compress(content)
    chash = content_hash(content)  # hash of UNCOMPRESSED content (chain integrity)
    key = _object_key(customer_id, period_start, chash)
    provider = (settings.ARCHIVE_PROVIDER or "local").lower()

    if provider == "minio":
        try:
            return _upload_minio(compressed, key)
        except Exception as exc:
            log.warning("5651 minio upload failed, falling back to none: %s", exc)
            return f"none:{chash}"
    if provider == "local":
        return _upload_local(compressed, key)
    return f"none:{chash}"


def read_archive_payload(content_ref: str) -> bytes | None:
    """Read and decompress an archive payload from any supported provider.

    Returns the canonical uncompressed JSONL bytes, or None if the payload
    is unavailable in the current environment.
    """
    ref = (content_ref or "").strip()
    if not ref or ref.startswith("none:"):
        return None

    try:
        if ref.startswith("local:"):
            path = ref[len("local:") :]
            with open(path, "rb") as fh:
                compressed = fh.read()
            return decompress(compressed)

        if ref.startswith("minio:"):
            bucket_and_key = ref[len("minio:") :]
            bucket, _, key = bucket_and_key.partition("/")
            if not bucket or not key:
                return None

            try:
                from minio import Minio  # type: ignore
                client = Minio(
                    settings.ARCHIVE_MINIO_ENDPOINT,
                    access_key=settings.ARCHIVE_MINIO_ACCESS_KEY,
                    secret_key=settings.ARCHIVE_MINIO_SECRET_KEY,
                    secure=settings.ARCHIVE_MINIO_SECURE,
                )
                obj = client.get_object(bucket, key)
                try:
                    compressed = obj.read()
                finally:
                    obj.close()
                    obj.release_conn()
                return decompress(compressed)
            except ImportError:
                import boto3  # type: ignore

                s3 = boto3.client(
                    "s3",
                    endpoint_url=f"http{'s' if settings.ARCHIVE_MINIO_SECURE else ''}://{settings.ARCHIVE_MINIO_ENDPOINT}",
                    aws_access_key_id=settings.ARCHIVE_MINIO_ACCESS_KEY,
                    aws_secret_access_key=settings.ARCHIVE_MINIO_SECRET_KEY,
                )
                obj = s3.get_object(Bucket=bucket, Key=key)
                compressed = obj["Body"].read()
                return decompress(compressed)
    except Exception as exc:
        log.warning("Archive payload read failed ref=%s: %s", ref, exc)
        return None

    return None


def _upload_local(content: bytes, key: str) -> str:
    base = os.path.abspath(settings.ARCHIVE_LOCAL_DIR or "./_archives")
    safe = os.path.abspath(os.path.join(base, key)).replace("\\", "/")
    base_abs = base.replace("\\", "/")
    if not safe.startswith(base_abs):
        safe = os.path.join(base_abs, os.path.basename(key))
    os.makedirs(os.path.dirname(safe), exist_ok=True)
    with open(safe, "wb") as fh:
        fh.write(content)
    return f"local:{safe}"


def _upload_minio(content: bytes, key: str) -> str:
    bucket = settings.ARCHIVE_MINIO_BUCKET or "hotspot-5651"
    global _BUCKET_CACHE
    try:
        from minio import Minio  # type: ignore
    except ImportError:
        # boto3 fallback
        try:
            import boto3  # type: ignore
            s3 = boto3.client(
                "s3",
                endpoint_url=f"http{'s' if settings.ARCHIVE_MINIO_SECURE else ''}://{settings.ARCHIVE_MINIO_ENDPOINT}",
                aws_access_key_id=settings.ARCHIVE_MINIO_ACCESS_KEY,
                aws_secret_access_key=settings.ARCHIVE_MINIO_SECRET_KEY,
            )
            _ensure_bucket_boto(s3, bucket)
            s3.put_object(Bucket=bucket, Key=key, Body=content)
            return f"minio:{bucket}/{key}"
        except ImportError:
            raise RuntimeError("neither minio nor boto3 installed for ARCHIVE_PROVIDER=minio")

    client = Minio(
        settings.ARCHIVE_MINIO_ENDPOINT,
        access_key=settings.ARCHIVE_MINIO_ACCESS_KEY,
        secret_key=settings.ARCHIVE_MINIO_SECRET_KEY,
        secure=settings.ARCHIVE_MINIO_SECURE,
    )
    _ensure_bucket_minio(client, bucket)
    client.put_object(bucket, key, io.BytesIO(content), length=len(content))
    return f"minio:{bucket}/{key}"


def _ensure_bucket_minio(client, bucket: str) -> None:
    global _BUCKET_CACHE
    if _BUCKET_CACHE == bucket:
        return
    if not client.bucket_exists(bucket):
        client.make_bucket(bucket)
    _BUCKET_CACHE = bucket


def _ensure_bucket_boto(s3, bucket: str) -> None:
    global _BUCKET_CACHE
    if _BUCKET_CACHE == bucket:
        return
    import boto3.session  # noqa: F401
    try:
        s3.head_bucket(Bucket=bucket)
    except Exception:  # noqa: BLE001
        s3.create_bucket(Bucket=bucket)
    _BUCKET_CACHE = bucket


