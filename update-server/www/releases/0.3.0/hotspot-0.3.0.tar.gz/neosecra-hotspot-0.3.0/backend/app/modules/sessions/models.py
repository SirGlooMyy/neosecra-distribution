"""GuestSession = an authorized guest internet session.

Created by the PUBLIC captive flow (start-session) after the portal token is
validated and the firewall adapter authorizes the guest. Scope axis = customer
(-> partner), with an extra LOCATION filter on location_id. RADIUS accounting
bytes are populated in M5; model the columns now.
"""
import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk

STATUS_PENDING = "pending"
STATUS_ACTIVE = "active"
STATUS_CLOSED = "closed"
STATUS_EXPIRED = "expired"
STATUSES = (STATUS_PENDING, STATUS_ACTIVE, STATUS_CLOSED, STATUS_EXPIRED)

AUTH_STATUS_PENDING = "pending"
AUTH_STATUS_AUTHORIZED = "authorized"
AUTH_STATUS_FAILED = "failed"
AUTH_STATUS_REVOKING = "revoking"
AUTH_STATUS_REVOKED = "revoked"
AUTH_STATUSES = (AUTH_STATUS_PENDING, AUTH_STATUS_AUTHORIZED, AUTH_STATUS_FAILED, AUTH_STATUS_REVOKING, AUTH_STATUS_REVOKED)


class GuestSession(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    """Authorized guest internet session. Created by the captive flow after
    portal-token validation + firewall authorize. MAC/IP are the 5651
    correlation keys. Accounting bytes + radius_session_id filled by the
    RADIUS worker in M5 (Mutlak Kural #5 — events not deleted without
    correlation)."""

    __tablename__ = "guest_sessions"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    device_id: Mapped[uuid.UUID | None] = fk("devices", ondelete="SET NULL", nullable=True)
    identity_verification_id: Mapped[uuid.UUID | None] = fk(
        "identity_verifications", ondelete="SET NULL", nullable=True
    )
    voucher_id: Mapped[uuid.UUID | None] = fk("vouchers", ondelete="SET NULL", nullable=True)
    group_id: Mapped[uuid.UUID | None] = fk("user_groups", ondelete="SET NULL", nullable=True)

    # Normalized E.164 phone for correlation (optional — free/anonymous flows).
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True, index=True)
    # Guest MAC — key for 5651 correlation + firewall authorize.
    mac: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    # Guest IP at session start (best-effort).
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    nas_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    ssid: Mapped[str | None] = mapped_column(String(100), nullable=True)

    auth_method: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(20), default=STATUS_ACTIVE, nullable=False, index=True)

    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    authorize_ok: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    authorize_message: Mapped[str | None] = mapped_column(String(500), nullable=True)

    # Populated by RADIUS worker in M5.
    radius_session_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    bytes_in: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    bytes_out: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)

    meta: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

    # KVKK / Consent evidence (HS-MVP-SLICE-01)
    terms_accepted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    terms_accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    privacy_accepted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    privacy_accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    terms_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
    privacy_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
    consent_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    consent_user_agent: Mapped[str | None] = mapped_column(Text, nullable=True)

    # FortiGate authorization lifecycle (HS-MVP-SLICE-02)
    authorization_status: Mapped[str] = mapped_column(
        String(20), default=AUTH_STATUS_PENDING, nullable=False, index=True
    )
    authorized_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    authorization_attempts: Mapped[int] = mapped_column(default=0, nullable=False)
    authorization_error_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    authorization_error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    external_session_id: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    external_reference: Mapped[str | None] = mapped_column(String(255), nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoke_attempts: Mapped[int] = mapped_column(default=0, nullable=False)
    last_device_sync_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
