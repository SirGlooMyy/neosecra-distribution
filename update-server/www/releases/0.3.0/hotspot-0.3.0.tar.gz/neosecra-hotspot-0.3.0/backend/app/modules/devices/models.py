"""Device = a network/firewall element at a location. Secrets live in
DeviceCredential, encrypted at rest (Mutlak Kural #3). Syslog sources and
RADIUS clients attach to devices for 5651 correlation and auth accounting."""
import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk

# Vendor is stored as a plain string (not an enum) so new adapters can be
# registered without a migration; the registry maps vendor -> adapter class.
VENDOR_FORTIGATE = "fortigate"
VENDOR_PALOALTO = "paloalto"


class Device(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "devices"

    location_id: Mapped[uuid.UUID] = fk("locations", ondelete="RESTRICT")
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    vendor: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    model: Mapped[str | None] = mapped_column(String(100), nullable=True)
    # Management plane reach. `api_host` is used by the adapter; mgmt_ip is
    # informational/for 5651 logging.
    mgmt_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    api_host: Mapped[str | None] = mapped_column(String(255), nullable=True)
    api_port: Mapped[int | None] = mapped_column(nullable=True)
    # Runtime state mirrored from the adapter (best-effort, not authoritative).
    serial_number: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    firmware_version: Mapped[str | None] = mapped_column(String(100), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="unknown", nullable=False)
    last_seen_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    # Free-form capabilities / portal context the adapter may need.
    meta: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)


class DeviceCredential(Base, UUIDPK, TimestampMixin):
    """Encrypted secrets for a device. Never returned over the API in plaintext
    (Mutlak Kural #3 + Yasak: API token response icinde dondurulmez)."""
    __tablename__ = "device_credentials"

    device_id: Mapped[uuid.UUID] = fk("devices", ondelete="CASCADE")
    # Encrypted with app.core.crypto (Fernet). api_token is the FortiGate API
    # key / Palo Alto key; ssh_key holds an optional private key.
    api_token_encrypted: Mapped[str | None] = mapped_column(String(2000), nullable=True)
    api_username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    api_vdom: Mapped[str | None] = mapped_column(String(100), nullable=True)
    ssh_key_encrypted: Mapped[str | None] = mapped_column(String(4000), nullable=True)
    # Secure by default; lab/simulator callers must explicitly opt out.
    verify_tls: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    # Last successful connection check (best-effort health signal).
    last_check_ok: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    last_check_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class SyslogSource(Base, UUIDPK, TimestampMixin):
    """A syslog feed origin (device/host producing 5651-relevant events).
    Used by the correlation layer to attribute raw events to a device."""
    __tablename__ = "syslog_sources"

    device_id: Mapped[uuid.UUID] = fk("devices", ondelete="CASCADE")
    identifier: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    source_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    last_event_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    event_count: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)


class RadiusClient(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    """A RADIUS NAS (Network Access Server) — typically the AP/controller that
    authenticates guests against the platform. shared_secret is encrypted."""
    __tablename__ = "radius_clients"

    location_id: Mapped[uuid.UUID] = fk("locations", ondelete="RESTRICT")
    nas_identifier: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    nas_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    shared_secret_encrypted: Mapped[str] = mapped_column(String(2000), nullable=False)
