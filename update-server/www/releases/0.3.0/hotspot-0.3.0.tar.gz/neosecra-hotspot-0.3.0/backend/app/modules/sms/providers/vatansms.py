import httpx
from app.core.config import settings
from .base import SmsProvider


class VatanSMSProvider(SmsProvider):
    async def send(self, phone: str, message: str) -> tuple[bool, str]:
        api_id = self.value("username", getattr(settings, "VATANSMS_API_ID", ""))
        api_key = self.value("api_key", settings.VATANSMS_API_KEY)
        if not api_id or not api_key:
            return False, "vatansms-missing-api-id-or-api-key"
        options = self.config.get("provider_options") or {}
        url = str(options.get("endpoint") or "https://api.vatansms.net/api/v1/1toN")
        payload = {
            "api_id": api_id,
            "api_key": api_key,
            "sender": self.value("sender", settings.SMS_SENDER),
            "message_type": str(options.get("message_type") or "normal"),
            "message": message,
            "message_content_type": str(options.get("message_content_type") or "bilgi"),
            "phones": [phone.lstrip("+90")],
        }
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json=payload)
            if 200 <= resp.status_code < 300:
                data = resp.json()
                status_value = str(data.get("status") or data.get("success") or "").lower()
                if status_value in {"error", "failed", "failure", "false", "0"}:
                    return False, f"vatansms-response:{data.get('error') or data.get('message') or 'unknown'}"
                return True, str(data.get("job_id") or data.get("jobid") or data.get("id") or "") or None
            return False, f"http-{resp.status_code}"
        except Exception as exc:
            return False, f"vatansms-error:{type(exc).__name__}"
