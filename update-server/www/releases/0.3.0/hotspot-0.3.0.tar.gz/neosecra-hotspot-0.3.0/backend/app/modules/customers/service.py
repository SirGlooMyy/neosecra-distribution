"""Customer CRUD with tenant-tree scope filtering.

- super_admin: all customers
- partner_admin: customers.partner_id == scope.partner_id
- customer_admin: Customer.id == scope.customer_id (own)
- others: deny (fail-closed)
"""
import uuid

from fastapi import HTTPException, Request, status
from sqlalchemy import false, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.customers.schemas import CustomerCreate, CustomerUpdate
from app.modules.partners.models import Partner


def _scoped_query(scope: ScopeContext):
    q = select(Customer)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(Customer.id == scope.customer_id), True
    return q.where(false()), False


async def list_customers(db: AsyncSession, scope: ScopeContext) -> list[Customer]:
    q, _ = _scoped_query(scope)
    result = await db.execute(q.order_by(Customer.created_at.desc()))
    return list(result.scalars().all())


async def get_customer(db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext) -> Customer:
    q, allowed = _scoped_query(scope)
    result = await db.execute(q.where(Customer.id == customer_id))
    customer = result.scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Musteri bulunamadi")
    if not allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu musteriye erisim yetkiniz yok")
    return customer


async def create_customer(
    db: AsyncSession, body: CustomerCreate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> Customer:
    if scope.level == TenantLevel.GLOBAL:
        if not body.partner_id:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="partner_id gerekiyor")
        partner = await db.get(Partner, body.partner_id)
        if not partner:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Partner bulunamadi")
        tenant_id, partner_id = partner.tenant_id, partner.id
    elif scope.level == TenantLevel.PARTNER and scope.partner_id:
        partner = await db.get(Partner, scope.partner_id)
        if not partner:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Partner bulunamadi")
        tenant_id, partner_id = partner.tenant_id, partner.id
    else:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Musteri olusturma yetkiniz yok")

    customer = Customer(
        tenant_id=tenant_id, partner_id=partner_id,
        name=body.name, contact_name=body.contact_name,
        contact_email=body.contact_email, contact_phone=body.contact_phone,
    )
    db.add(customer)
    await log_audit(db, "customer.created", "customer", str(customer.id), str(actor_id), request,
                    details={"name": body.name, "partner_id": str(partner_id)})
    await db.commit()
    await db.refresh(customer)
    return customer


async def update_customer(
    db: AsyncSession, customer_id: uuid.UUID, body: CustomerUpdate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> Customer:
    customer = await get_customer(db, customer_id, scope)
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(customer, k, v)
    await log_audit(db, "customer.updated", "customer", str(customer_id), str(actor_id), request, details=data)
    await db.commit()
    await db.refresh(customer)
    return customer


async def deactivate_customer(
    db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> None:
    customer = await get_customer(db, customer_id, scope)
    customer.is_active = False
    await log_audit(db, "customer.deactivated", "customer", str(customer_id), str(actor_id), request)
    await db.commit()
