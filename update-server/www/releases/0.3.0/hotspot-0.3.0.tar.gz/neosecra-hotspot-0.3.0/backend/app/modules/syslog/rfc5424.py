"""RFC 5424 syslog parser with RFC 3164 fallback.

Parses raw syslog bytes/str into structured dict. Returns None for
malformed lines that cannot be parsed at all (caller stores raw).

References:
  - RFC 5424: https://tools.ietf.org/html/rfc5424
  - RFC 3164: https://tools.ietf.org/html/rfc3164
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

log = logging.getLogger(__name__)

# RFC 5424 header: <PRI>VERSION TIMESTAMP HOSTNAME APP-NAME PROCID MSGID
_RFC5424_HEADER = re.compile(
    r"^<(\d{1,3})>"                              # PRI
    r"(\d+)\s"                                    # VERSION
    r"(\S+)\s"                                    # TIMESTAMP
    r"(\S+)\s"                                    # HOSTNAME
    r"(\S+)\s"                                    # APP-NAME
    r"(\S+)\s"                                    # PROCID
    r"(\S+)"                                      # MSGID
)

# SD element: [sd_id param="val" ...]
_SD_ELEMENT = re.compile(r"\[([^\]]*?)\]")

# RFC 3164 (BSD): <PRI>TIMESTAMP HOSTNAME MSG
_RFC3164_RE = re.compile(
    r"^<(\d{1,3})>"                              # PRI
    r"(\S+\s+\d+\s+\S+)\s"                        # TIMESTAMP (e.g. "Oct  1 12:34:56")
    r"(\S+)\s"                                    # HOSTNAME
    r"(.*)$",                                     # MSG
    re.DOTALL,
)

# PRI = facility * 8 + severity
_PRI_FACILITY_MASK = 0xF8  # top 5 bits


def parse_rfc5424(raw: bytes | str) -> dict | None:
    """Parse a syslog message returning structured fields.

    Returns dict with keys:
      facility, severity, ts (ISO str or None), hostname, app_name,
      procid, msgid, structured_data, msg

    Returns None when the line is completely unparseable (caller
    should store raw).
    """
    if isinstance(raw, bytes):
        try:
            line = raw.decode("utf-8", errors="replace").strip()
        except Exception:
            return None
    else:
        line = raw.strip()

    if not line:
        return None

    # Try RFC 5424 first
    m = _RFC5424_HEADER.match(line)
    if m:
        return _build_5424(line, m)

    # Fallback to RFC 3164
    m = _RFC3164_RE.match(line)
    if m:
        return _build_3164(m)

    # Minimal PRI-only parse (no recognizable format)
    if line.startswith("<"):
        gt = line.find(">")
        if gt != -1 and gt <= 4:
            pri_str = line[1:gt]
            if pri_str.isdigit():
                pri = int(pri_str)
                return {
                    "facility": (pri & _PRI_FACILITY_MASK) >> 3,
                    "severity": pri & 0x07,
                    "ts": None,
                    "hostname": None,
                    "app_name": None,
                    "procid": None,
                    "msgid": None,
                    "structured_data": {},
                    "msg": line[gt + 1:].strip(),
                }

    return None


def _build_5424(line: str, m: re.Match) -> dict:
    pri = int(m.group(1))
    ts_str = m.group(3)
    ts = _parse_timestamp(ts_str) if ts_str and ts_str != "-" else None

    result = {
        "facility": (pri & _PRI_FACILITY_MASK) >> 3,
        "severity": pri & 0x07,
        "ts": ts.isoformat() if ts else None,
        "hostname": m.group(4) if m.group(4) != "-" else None,
        "app_name": m.group(5) if m.group(5) != "-" else None,
        "procid": m.group(6) if m.group(6) != "-" else None,
        "msgid": m.group(7) if m.group(7) != "-" else None,
        "structured_data": {},
        "msg": None,
    }

    # Everything after MSGID
    tail = line[m.end():].strip()

    if not tail:
        return result

    # Parse structured data: starts with "[" or is "-"
    if tail.startswith("["):
        sd_end = _find_sd_end(tail)
        if sd_end > 0:
            sd_part = tail[:sd_end]
            result["structured_data"] = _parse_structured_data(sd_part)
            msg_part = tail[sd_end:].strip()
            if msg_part:
                result["msg"] = msg_part
        else:
            result["msg"] = tail
    elif tail.startswith("-"):
        remaining = tail[1:].strip()
        if remaining:
            result["msg"] = remaining
    else:
        result["msg"] = tail

    return result


def _find_sd_end(tail: str) -> int:
    """Find end of structured data section (bracket-balanced)."""
    depth = 0
    for i, ch in enumerate(tail):
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                return i + 1
    return -1


def _build_3164(m: re.Match) -> dict:
    pri = int(m.group(1))
    ts_str = m.group(2)
    ts = _parse_3164_timestamp(ts_str)

    return {
        "facility": (pri & _PRI_FACILITY_MASK) >> 3,
        "severity": pri & 0x07,
        "ts": ts.isoformat() if ts else None,
        "hostname": m.group(3),
        "app_name": None,
        "procid": None,
        "msgid": None,
        "structured_data": {},
        "msg": m.group(4).strip() if m.group(4) else None,
    }


def _parse_structured_data(sd_raw: str) -> dict:
    """Parse RFC 5424 structured data elements.

    [exampleSDID@32473 iut="3" eventSource="Application"]
    """
    if not sd_raw or sd_raw == "-":
        return {}

    result: dict = {}
    for elem in _SD_ELEMENT.finditer(sd_raw):
        body = elem.group(1).strip()
        if not body:
            continue
        parts = _shlex_split(body)
        if not parts:
            continue
        sd_id = parts[0]
        params: dict[str, str] = {}
        for p in parts[1:]:
            if "=" in p:
                k, _, v = p.partition("=")
                params[k] = v.strip('"')
        if params:
            result[sd_id] = params
    return result


def _shlex_split(s: str) -> list[str]:
    """Split string respecting quoted values, with fallback."""
    import shlex
    try:
        return shlex.split(s, posix=True)
    except ValueError:
        return s.split()


def _parse_timestamp(ts: str) -> datetime | None:
    """Parse RFC 3339 / ISO 8601 timestamp."""
    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
    ):
        try:
            dt = datetime.strptime(ts, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    return None


def _parse_3164_timestamp(ts: str) -> datetime | None:
    """Parse RFC 3164 timestamp like 'Oct  1 12:34:56'."""
    for fmt in ("%b %d %H:%M:%S", "%b %e %H:%M:%S"):
        try:
            dt = datetime.strptime(ts, fmt)
            return dt.replace(year=datetime.now(timezone.utc).year, tzinfo=timezone.utc)
        except ValueError:
            continue
    return None
