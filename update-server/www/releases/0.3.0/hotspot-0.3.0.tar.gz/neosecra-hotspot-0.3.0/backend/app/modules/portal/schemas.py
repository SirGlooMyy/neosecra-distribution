"""Pydantic schemas for portal templates."""
import uuid
from datetime import datetime

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.modules.portal.models import METHODS
from app.modules.portal.field_schema import normalize_fields


class ThemeSpec(BaseModel):
    """Visual config. All optional; renderer applies sensible defaults."""
    primary_color: str | None = Field(None, max_length=20)
    secondary_color: str | None = Field(None, max_length=20)
    bg_color: str | None = Field(None, max_length=20)
    text_color: str | None = Field(None, max_length=20)
    font_family: str | None = Field(None, max_length=200)
    logo_style: str | None = Field(None, max_length=20)
    button_style: str | None = Field(None, max_length=20)
    layout: str | None = Field(None, max_length=20)
    bg_image_url: str | None = Field(None, max_length=500)
    logo_url: str | None = Field(None, max_length=500)
    title: str | None = Field(None, max_length=200)
    subtitle: str | None = Field(None, max_length=500)
    footer: str | None = Field(None, max_length=500)
    terms_text: str | None = Field(None, max_length=1000)
    support_text: str | None = Field(None, max_length=1000)
    internet_policy_text: str | None = Field(None, max_length=2000)
    internet_policy_url: str | None = Field(None, max_length=500)
    kvkk_text: str | None = Field(None, max_length=2000)
    kvkk_url: str | None = Field(None, max_length=500)


class PortalTemplateBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    method: str = "free"
    theme: ThemeSpec = Field(default_factory=ThemeSpec)  # type: ignore[arg-type]
    fields: list[dict] = Field(default_factory=list)
    success_message: str | None = Field(None, max_length=1000)
    terms_url: str | None = Field(None, max_length=500)
    meta: dict = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_method(self):
        if self.method not in METHODS:
            raise ValueError(f"method must be one of {METHODS}")
        return self

    @field_validator("fields")
    @classmethod
    def _check_fields(cls, value: list[dict]) -> list[dict]:
        return normalize_fields(value, None)


class PortalTemplateCreate(PortalTemplateBase):
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    is_default: bool = False


class PortalTemplateUpdate(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=255)
    method: str | None = None
    theme: ThemeSpec | None = None
    fields: list[dict] | None = None
    success_message: str | None = None
    terms_url: str | None = None
    meta: dict | None = None
    is_default: bool | None = None

    @field_validator("fields")
    @classmethod
    def _check_fields(cls, value: list[dict] | None) -> list[dict] | None:
        return None if value is None else normalize_fields(value, None)


class PortalTemplateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    name: str
    method: str
    is_default: bool
    theme: dict
    fields: list
    success_message: str | None = None
    terms_url: str | None = None
    meta: dict
    is_active: bool
    revision: int = 1
    revision_action: str | None = None
    revision_updated_at: datetime | None = None
    revision_updated_by: str | None = None
    created_at: datetime


class PortalTemplateRevisionOut(BaseModel):
    revision: int
    action: str
    saved_at: datetime
    saved_by: str | None = None
    is_active: bool = True
    name: str
    method: str
    is_default: bool
    theme: dict
    fields: list
    success_message: str | None = None
    terms_url: str | None = None
    meta: dict = Field(default_factory=dict)


class PortalTemplateHistoryOut(BaseModel):
    template_id: uuid.UUID
    current_revision: int
    history_count: int
    current: PortalTemplateRevisionOut
    history: list[PortalTemplateRevisionOut] = Field(default_factory=list)


# ---- PUBLIC captive flow schemas (no admin JWT; device_id is the anchor) ----
# These never carry secrets. The portal token is returned ONLY here at verify
# time and is exchanged for a session on start-session (Mutlak Kural #3).
class PortalContextOut(BaseModel):
    """Public landing-page config for a device's site. Rendered for the guest.
    Contains no tenant ids beyond what the renderer needs — no secrets."""
    method: str
    theme: dict
    fields: list
    terms_url: str | None = None
    success_message: str | None = None
    customer_display_name: str | None = None
    is_demo_mode: bool = False
    demo_fallback_reason: str | None = None
    # Only a boolean/message is public; manager e-mail addresses and approval
    # tokens are never included in the guest-facing context.
    approval_required: bool = False
    approval_message: str | None = None


class SendCodeIn(BaseModel):
    device_id: uuid.UUID
    phone: str = Field(..., min_length=10, max_length=20)
    tc_number: str | None = Field(None, min_length=11, max_length=20)


class PortalVerifyIn(BaseModel):
    """Guest submits whatever the template's method requires. method itself is
    NOT client-chosen — it is derived from the resolved template (one method per
    site), so the guest cannot force a weaker auth path."""
    device_id: uuid.UUID
    phone: str | None = Field(None, max_length=20)
    code: str | None = Field(None, max_length=10)
    tc_number: str | None = Field(None, max_length=20)
    voucher_code: str | None = Field(None, max_length=64)
    room_number: str | None = Field(None, max_length=10)
    surname_or_birth: str | None = Field(None, max_length=100)
    username: str | None = Field(None, max_length=100)
    password: str | None = Field(None, max_length=255)
    passport_number: str | None = Field(None, max_length=20)
    full_name: str | None = Field(None, max_length=200)
    country: str | None = Field(None, max_length=100)
    form_data: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="allow")


class ForeignerVerifyIn(BaseModel):
    """Dedicated foreigner (passport) verify input for the separate endpoint."""
    device_id: uuid.UUID
    passport_number: str = Field(..., max_length=20)
    full_name: str = Field(..., max_length=200)
    country: str = Field(..., max_length=100)
    location_id: uuid.UUID | None = None


class PortalTokenOut(BaseModel):
    portal_token: str
    method: str
    expires_at: datetime


class StartSessionIn(BaseModel):
    device_id: uuid.UUID
    portal_token: str
    mac: str = Field(..., min_length=1, max_length=32)
    ip: str | None = Field(None, max_length=64)
    ssid: str | None = Field(None, max_length=100)
    # KVKK / Consent (HS-MVP-SLICE-01)
    terms_accepted: bool = Field(False)
    privacy_accepted: bool = Field(False)
    terms_version: str | None = Field(None, max_length=20)
    privacy_version: str | None = Field(None, max_length=20)


class StartSessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    session_id: uuid.UUID
    status: str
    started_at: datetime
    expires_at: datetime | None = None
    authorize_ok: bool
    authorize_message: str | None = None
    approval_required: bool = False
    approval_status: str | None = None
    terms_accepted: bool = False
    privacy_accepted: bool = False
    terms_version: str | None = None
    privacy_version: str | None = None
