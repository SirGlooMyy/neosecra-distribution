# Pydantic schemas for workers
