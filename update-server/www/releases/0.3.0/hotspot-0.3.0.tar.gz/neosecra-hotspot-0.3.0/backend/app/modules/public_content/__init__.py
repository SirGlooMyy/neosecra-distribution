"""Public marketing content module."""

