"""FortiGate (FortiOS REST API) adapter.

Talks to the real FortiOS REST API at /api/v2/. Auth is a per-admin API token
carried as `Authorization: Bearer <token>` (FortiOS 7.0+ API token admin).
Secrets arrive already decrypted via ConnectionConfig — this adapter never
touches the DB or crypto layer (Mutlak Kural #7).

Guest authorization strategy implemented here: IP allowlist — the guest IP is
published as a FortiGate firewall address with a TTL, referenced by the
captive-portal-exempt policy. The RADIUS/COA strategy is layered on top in the
sessions module; this is the simplest real, testable mechanism and is
production-correct for external captive portal deployments.
"""
from __future__ import annotations

import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)

# FortiOS log_level → severity string mapping
_FORTISEVERITY_MAP: dict[str, str] = {
    "emergency": "critical",
    "alert": "critical",
    "critical": "critical",
    "error": "high",
    "warning": "medium",
    "notice": "low",
    "information": "info",
    "info": "info",
    "debug": "info",
}

# FortiOS type → log_type mapping
_FORTITYPE_MAP: dict[str, str] = {
    "traffic": "traffic",
    "event": "event",
    "utm": "utm",
    "virus": "utm",
    "webfilter": "utm",
    "ips": "utm",
    "emailfilter": "utm",
    "application": "utm",
    "dlp": "utm",
    "anomaly": "anomaly",
    "wanopt": "event",
    "endpoint": "event",
    "voip": "event",
    "wifi": "event",
    "dhcp": "event",
    "system": "event",
    "router": "event",
    "vpn": "event",
    "auth": "event",
    "user": "event",
    "connector": "event",
    "cifs": "event",
    "nac": "event",
    "fabric": "event",
    "gtp": "event",
    "dns": "event",
    "ssh": "event",
    "ssl": "event",
    "scan": "utm",
    "forticast": "utm",
    "iap": "iap",
    "ztna": "event",
}

class AdapterError(RuntimeError):
    """Raised when the device API returns an unrecoverable error."""


class FortiGateAdapter(FirewallAdapter):
    vendor = "fortigate"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        #
        # NOTE: The simulator (fake_fortigate_server.py) runs as plain HTTP.
        #       When testing against the simulator via Docker Compose, tests
        #       override self._base_url to use http://. The production default
        #       of HTTPS is intentionally preserved here — do NOT change it.
        #
        self._base_url = f"{'https' if (getattr(config, 'api_tls', True)) else 'http'}://{config.api_host}:{port}/api/v2"
        self._headers = {"Authorization": f"Bearer {config.api_token}"} if config.api_token else {}

    # ---- low-level transport -------------------------------------------
    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 15.0,
    ) -> dict[str, Any]:
        params = dict(params or {})
        if self.config.api_vdom:
            params.setdefault("vdom", self.config.api_vdom)
        url = f"{self._base_url}/{path.lstrip('/')}"
        # NOTE: TLS verification uses self.config.verify_tls (default True).
        #       See ConnectionConfig.__post_init__ for security warnings.
        #       NEVER log API tokens or certificate content (Mutlak Kural #3).
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(f"FortiGate {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}")
        data = resp.json()
        # FortiOS envelopes responses with {"http_status":..., "results":[...], ...}
        # and an error body when the call logically fails (e.g. HTTP 200 + error).
        if isinstance(data, dict) and data.get("error") not in (None, 0, "0"):
            msg = (data.get("errmessage") or data.get("error_message") or "fortios logical error")
            raise AdapterError(f"FortiGate {path}: {msg}")
        return data

    # ---- capability / discovery ----------------------------------------
    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=True,
            radius_authentication=True,
            radius_accounting=True,
            radius_coa=True,
            disconnect_message=True,
            mac_auth_bypass=True,
            local_guest_users=True,
            active_session_query=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    # ---- connection / discovery ----------------------------------------
    async def test_connection(self) -> AdapterResult:
        try:
            data = await self._request("GET", "monitor/system/status")
            r = (data.get("results") or [{}])[0]
            return AdapterResult(
                ok=True,
                message=f"connected: {r.get('hostname', '?')} {r.get('version', '?')}",
                data=r,
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        data = await self._request("GET", "monitor/system/status")
        r = (data.get("results") or [{}])[0]
        return {
            "hostname": r.get("hostname"),
            "model": r.get("model"),
            "serial_number": r.get("serial"),
            "firmware_version": r.get("version"),
            "bios_version": r.get("bios_version"),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "cmdb/system/interface")
        results = data.get("results") or []
        return [
            {
                "name": i.get("name"),
                "type": i.get("type"),
                "ip": i.get("ip"),
                "vdom": i.get("vdom"),
                "status": "up" if i.get("status") else "down",
            }
            for i in results
        ]

    async def get_captive_portal_config(self) -> dict[str, Any]:
        """Read user groups used by the captive-portal policy (informational)."""
        data = await self._request("GET", "cmdb/user/group")
        groups = [
            {"name": g.get("name"), "members": len(g.get("member") or [])}
            for g in (data.get("results") or [])
        ]
        return {"user_groups": groups}

    # ---- guest session lifecycle ---------------------------------------
    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "monitor/user/fsso/list")
        return [
            {
                "ip": u.get("ip"),
                "user": u.get("name"),
                "mac": u.get("mac"),
                "group": u.get("groups"),
            }
            for u in (data.get("results") or [])
        ]

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "monitor/firewall/ipv4-list")
        return [
            {"ip": r.get("ip"), "mac": r.get("mac"), "interface": r.get("interface")}
            for r in (data.get("results") or [])
        ]

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        """Allowlist the guest IP for the session duration.

        Creates a firewall address named `hsess-<session_id>` with a comment
        carrying the session id; the captive-portal-exempt policy matches it.
        Re-creating is idempotent because we PUT by name.
        """
        ip = session.get("ip")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        payload = {
            "name": name,
            "type": "ipmask",
            "subnet": f"{ip} 255.255.255.255",
            "comment": self._guest_comment(session),
        }
        try:
            await self._request("PUT", f"cmdb/firewall/address/{name}", json=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"address": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            await self._request("DELETE", f"cmdb/firewall/address/{name}")
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    # ---- log ingestion -------------------------------------------------
    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        """Delegate to module-level parse_syslog_event."""
        return parse_syslog_event(raw_event)


def parse_syslog_event(raw_event: str) -> dict[str, Any]:
    """FortiGate syslog key=value parser. Safe to call without a device.

    Returns enriched dict with:
      vendor, raw, device_name, device_id, event_type, event_subtype,
      log_type, log_subtype, severity, src_ip, dst_ip, src_port, dst_port,
      action, duration, sentbyte, rcvdbyte, session_id, user, policyid,
      proto, service, parsed_fields (all key=value pairs).
    """
    line = raw_event.strip()
    # Strip leading <PRI> token if present.
    if line.startswith("<"):
        gt = line.find(">")
        if gt != -1:
            line = line[gt + 1:]
    parsed: dict[str, Any] = {"vendor": "fortigate"}
    try:
        for tok in shlex.split(line, posix=True):
            if "=" in tok:
                k, _, v = tok.partition("=")
                parsed[k] = v
    except ValueError:
        for tok in line.split():
            if "=" in tok:
                k, _, v = tok.partition("=")
                parsed[k] = v

    # Determine log_type from FortiGate type field
    fgt_type = parsed.get("type", "").lower() if parsed.get("type") else "unknown"
    log_type = _FORTITYPE_MAP.get(fgt_type, "unknown")
    log_subtype = parsed.get("subtype", "").lower() if parsed.get("subtype") else None

    # Severity mapping
    sev_raw = parsed.get("level", "").lower() if parsed.get("level") else "info"
    severity = _FORTISEVERITY_MAP.get(sev_raw, "info")

    # Numeric conversions
    def _int(v: Any) -> int | None:
        try:
            return int(v)
        except (ValueError, TypeError):
            return None

    duration = _int(parsed.get("duration"))
    sentbyte = _int(parsed.get("sentbyte")) or _int(parsed.get("sentpkt"))
    rcvdbyte = _int(parsed.get("rcvdbyte")) or _int(parsed.get("rcvdpkt"))
    policyid = _int(parsed.get("policyid"))

    # Session ID — try sessionid, then logid, then use a derived key
    session_id = (
        parsed.get("sessionid")
        or parsed.get("logid")
    )
    src_port = _int(parsed.get("srcport"))
    dst_port = _int(parsed.get("dstport"))

    result: dict[str, Any] = {
        "vendor": "fortigate",
        "device_name": parsed.get("devname"),
        "device_id": parsed.get("devid"),
        "event_type": fgt_type,
        "event_subtype": log_subtype,
        "log_type": log_type,
        "log_subtype": log_subtype,
        "severity": severity,
        "action": parsed.get("action"),
        "src_ip": parsed.get("srcip"),
        "dst_ip": parsed.get("dstip"),
        "src_port": src_port,
        "dst_port": dst_port,
        "proto": parsed.get("proto"),
        "service": parsed.get("service"),
        "user": parsed.get("user"),
        "policyid": policyid,
        "duration": duration,
        "sentbyte": sentbyte,
        "rcvdbyte": rcvdbyte,
        "session_id": session_id,
        "raw": raw_event,
        "parsed_fields": parsed,
    }
    return result
