"""Partner HTTP endpoints. Super_admin manages; partner_admin reads own."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.partners import service
from app.modules.partners.schemas import PartnerCreate, PartnerOut, PartnerUpdate

router = APIRouter()


def _require_super_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "super_admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Super admin gerekiyor")
    return user


@router.get("", response_model=list[PartnerOut], summary="Partners")
async def list_partners(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_partners(db, scope_for(user))


@router.get("/{partner_id}", response_model=PartnerOut, summary="Partner")
async def get_partner(
    partner_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_partner(db, partner_id, scope_for(user))


@router.post("", response_model=PartnerOut, status_code=status.HTTP_201_CREATED, summary="Partner")
async def create_partner(
    body: PartnerCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_require_super_admin),
):
    return await service.create_partner(db, body, user.id, request)


@router.put("/{partner_id}", response_model=PartnerOut, summary="Partner")
async def update_partner(
    partner_id: uuid.UUID,
    body: PartnerUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_require_super_admin),
):
    return await service.update_partner(db, partner_id, body, user.id, request)


@router.delete("/{partner_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Partner")
async def delete_partner(
    partner_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_require_super_admin),
):
    await service.deactivate_partner(db, partner_id, user.id, request)
