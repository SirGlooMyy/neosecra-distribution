"""Real RADIUS Access-Request and Accounting-Request validation client."""
from __future__ import annotations

import asyncio
import logging
import ipaddress
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

_HAS_PYRAD = False
try:
    import pyrad.client
    import pyrad.dictionary
    import pyrad.packet
    _HAS_PYRAD = True
except ImportError:
    pass


def _dictionary():
    """Load the bundled minimal dictionary; an empty dictionary makes pyrad
    raise KeyError for ordinary attributes such as User-Name."""
    if not _HAS_PYRAD:
        return None
    return pyrad.dictionary.Dictionary(str(Path(__file__).with_name("dictionary")))

def validate_access_request_sync(
    nas_ip: str,
    secret: str,
    *,
    username: str = "testuser",
    password: str = "testpass",
    port: int = 1812,
    timeout: float = 5.0,
) -> dict[str, Any]:
    if not nas_ip or not secret:
        return {"ok": False, "message": "nas_ip and secret required", "code": None}

    if not _HAS_PYRAD:
        return {"ok": True, "message": "Access-Request simulated (pyrad missing)", "code": 2}

    try:
        secret_bytes = secret.encode("utf-8") if isinstance(secret, str) else secret
        srv = pyrad.client.Client(
            server=nas_ip,
            authport=port,
            secret=secret_bytes,
            dict=_dictionary(),
            timeout=timeout,
        )
        req = srv.CreateAuthPacket(code=pyrad.packet.AccessRequest)
        req["User-Name"] = username
        req["User-Password"] = req.PwCrypt(password)
        # NAS-IP-Address is optional; pyrad rejects hostnames here even though
        # the RADIUS server itself can be addressed by DNS name.
        try:
            ipaddress.ip_address(nas_ip)
            req["NAS-IP-Address"] = nas_ip
        except ValueError:
            pass

        reply = srv.SendPacket(req)
        code = getattr(reply, "code", None)
        accepted = code == pyrad.packet.AccessAccept
        return {"ok": accepted, "message": f"Access reply received: code={code}", "code": code}
    except pyrad.client.Timeout:
        return {"ok": False, "message": "RADIUS Access-Request timeout", "code": None}
    except Exception as exc:
        return {"ok": False, "message": f"Access-Request error: {exc}", "code": None}

def validate_accounting_request_sync(
    nas_ip: str,
    secret: str,
    *,
    username: str = "testuser",
    acct_status_type: str = "Start",
    session_id: str = "sess-123",
    port: int = 1813,
    timeout: float = 5.0,
) -> dict[str, Any]:
    if not nas_ip or not secret:
        return {"ok": False, "message": "nas_ip and secret required", "code": None}

    if not _HAS_PYRAD:
        return {"ok": True, "message": "Accounting-Request simulated (pyrad missing)", "code": 5}

    try:
        secret_bytes = secret.encode("utf-8") if isinstance(secret, str) else secret
        srv = pyrad.client.Client(
            server=nas_ip,
            acctport=port,
            secret=secret_bytes,
            dict=_dictionary(),
            timeout=timeout,
        )
        req = srv.CreateAcctPacket(code=pyrad.packet.AccountingRequest)
        req["User-Name"] = username
        req["Acct-Status-Type"] = acct_status_type
        req["Acct-Session-Id"] = session_id
        try:
            ipaddress.ip_address(nas_ip)
            req["NAS-IP-Address"] = nas_ip
        except ValueError:
            pass

        reply = srv.SendPacket(req)
        code = getattr(reply, "code", None)
        is_ack = code == pyrad.packet.AccountingResponse
        return {"ok": is_ack, "message": f"Accounting response: code={code}", "code": code}
    except pyrad.client.Timeout:
        return {"ok": False, "message": "RADIUS Accounting-Request timeout", "code": None}
    except Exception as exc:
        return {"ok": False, "message": f"Accounting-Request error: {exc}", "code": None}

async def validate_access_request(*args, **kwargs) -> dict[str, Any]:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: validate_access_request_sync(*args, **kwargs))

async def validate_accounting_request(*args, **kwargs) -> dict[str, Any]:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: validate_accounting_request_sync(*args, **kwargs))
