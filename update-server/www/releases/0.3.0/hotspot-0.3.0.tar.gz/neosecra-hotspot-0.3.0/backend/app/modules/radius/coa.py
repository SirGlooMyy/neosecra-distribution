"""RADIUS CoA (Change of Authorization) & Session Disconnect handler."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

log = logging.getLogger(__name__)

_HAS_PYRAD = False
try:
    import pyrad.client
    import pyrad.dictionary
    import pyrad.packet
    _HAS_PYRAD = True
except ImportError:
    pass

def _create_dictionary():
    if _HAS_PYRAD:
        try:
            return pyrad.dictionary.Dictionary()
        except Exception:
            return None
    return None

def send_coa_disconnect_sync(
    nas_ip: str,
    secret: str,
    *,
    username: str | None = None,
    session_id: str | None = None,
    user_ip: str | None = None,
    mac_address: str | None = None,
    port: int = 3799,
    timeout: float = 5.0,
    retries: int = 2,
) -> dict[str, Any]:
    """Send RADIUS Disconnect-Request (Code 40)."""
    if not nas_ip or not secret:
        return {"ok": False, "message": "nas_ip and secret are required", "code": None}

    if not _HAS_PYRAD:
        log.warning("pyrad missing; simulating CoA disconnect for %s", nas_ip)
        return {"ok": True, "message": "Disconnect-Request simulated", "code": 41, "simulated": True}

    try:
        secret_bytes = secret.encode("utf-8") if isinstance(secret, str) else secret
        srv = pyrad.client.Client(
            server=nas_ip,
            coaport=port,
            secret=secret_bytes,
            dict=_create_dictionary(),
            timeout=timeout,
            retries=retries,
        )
        req = srv.CreateCoAPacket(code=pyrad.packet.DisconnectRequest)
        if username:
            req["User-Name"] = username
        if session_id:
            req["Acct-Session-Id"] = session_id
        if user_ip:
            req["Framed-IP-Address"] = user_ip
        if mac_address:
            req["Calling-Station-Id"] = mac_address
        if nas_ip:
            req["NAS-IP-Address"] = nas_ip

        reply = srv.SendPacket(req)
        code = getattr(reply, "code", None)
        is_ack = code == pyrad.packet.DisconnectACK
        return {"ok": is_ack, "message": f"Disconnect-{'ACK' if is_ack else 'NAK'}", "code": code, "simulated": False}
    except pyrad.client.Timeout:
        return {"ok": False, "message": "CoA Disconnect-Request timeout", "code": None, "simulated": False}
    except Exception as exc:
        return {"ok": False, "message": f"CoA Disconnect error: {exc}", "code": None, "simulated": False}

def send_coa_rate_limit_sync(
    nas_ip: str,
    secret: str,
    *,
    upload_kbps: int = 1000,
    download_kbps: int = 2000,
    username: str | None = None,
    session_id: str | None = None,
    user_ip: str | None = None,
    mac_address: str | None = None,
    port: int = 3799,
    timeout: float = 5.0,
    retries: int = 2,
) -> dict[str, Any]:
    """Send RADIUS CoA-Request (Code 43) for bandwidth rate-limiting."""
    if not nas_ip or not secret:
        return {"ok": False, "message": "nas_ip and secret are required", "code": None}

    if not _HAS_PYRAD:
        return {"ok": True, "message": f"CoA-Request rate-limit ({upload_kbps}/{download_kbps}k) simulated", "code": 44, "simulated": True}

    try:
        secret_bytes = secret.encode("utf-8") if isinstance(secret, str) else secret
        srv = pyrad.client.Client(
            server=nas_ip,
            coaport=port,
            secret=secret_bytes,
            dict=_create_dictionary(),
            timeout=timeout,
            retries=retries,
        )
        req = srv.CreateCoAPacket(code=pyrad.packet.CoARequest)
        if username:
            req["User-Name"] = username
        if session_id:
            req["Acct-Session-Id"] = session_id
        if user_ip:
            req["Framed-IP-Address"] = user_ip
        if mac_address:
            req["Calling-Station-Id"] = mac_address
        if nas_ip:
            req["NAS-IP-Address"] = nas_ip
        try:
            req["Mikrotik-Rate-Limit"] = f"{upload_kbps}k/{download_kbps}k"
        except Exception:
            pass

        reply = srv.SendPacket(req)
        code = getattr(reply, "code", None)
        is_ack = code == pyrad.packet.CoAACK
        return {"ok": is_ack, "message": f"CoA-{'ACK' if is_ack else 'NAK'}", "code": code, "simulated": False}
    except pyrad.client.Timeout:
        return {"ok": False, "message": "CoA-Request timeout", "code": None, "simulated": False}
    except Exception as exc:
        return {"ok": False, "message": f"CoA error: {exc}", "code": None, "simulated": False}

async def send_coa_disconnect(*args, **kwargs) -> dict[str, Any]:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: send_coa_disconnect_sync(*args, **kwargs))

async def send_coa_rate_limit(*args, **kwargs) -> dict[str, Any]:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: send_coa_rate_limit_sync(*args, **kwargs))
