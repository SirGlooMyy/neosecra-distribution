"""İleti Merkezi JSON SMS API adapter.

The provider's documented contract is a nested JSON request authenticated by
an API key and hash.  receipents is intentionally kept as spelled in the
vendor's v1 example/API contract (it is not a typo in this payload).
"""
from __future__ import annotations

import json

import httpx

from app.core.config import settings
from .base import SmsProvider

ILETIMERKEZI_URL = "https://api.iletimerkezi.com/v1/send-sms"


class IletiMerkeziProvider(SmsProvider):
    async def send(self, phone: str, message: str) -> tuple[bool, str | None]:
        options = self.config.get("provider_options") or {}
        api_key = self.value("api_key", getattr(settings, "ILETIMERKEZI_API_KEY", ""))
        api_hash = self.value("api_secret", getattr(settings, "ILETIMERKEZI_API_HASH", ""))
        sender = self.value("sender", settings.SMS_SENDER)
        if not api_key or not api_hash:
            return False, "iletimerkezi-missing-credentials"
        payload = {
            "request": {
                "authentication": {"key": api_key, "hash": api_hash},
                "order": {
                    "sender": sender,
                    "message": {"text": message},
                    "receipents": {"number": [phone.lstrip("+")]},
                },
            }
        }
        url = str(options.get("endpoint") or getattr(settings, "ILETIMERKEZI_API_URL", "") or ILETIMERKEZI_URL)
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json=payload, headers={"Content-Type": "application/json"})
            if not 200 <= resp.status_code < 300:
                return False, f"iletimerkezi-http-{resp.status_code}"
            try:
                data = resp.json()
            except (ValueError, json.JSONDecodeError):
                data = {}
            # Responses vary between XML-compatible and JSON deployments. A
            # 2xx with an explicit failure marker must not be reported as sent.
            status_value = str(
                data.get("status")
                or data.get("response", {}).get("status")
                or data.get("request", {}).get("status")
                or ""
            ).lower()
            if status_value in {"error", "failure", "failed", "false"}:
                detail = data.get("message") or data.get("description") or "provider rejected request"
                return False, f"iletimerkezi-error:{str(detail)[:120]}"
            job_id = (
                data.get("jobid")
                or data.get("job_id")
                or data.get("response", {}).get("order", {}).get("id")
                or data.get("request", {}).get("order", {}).get("id")
            )
            return True, str(job_id) if job_id else None
        except httpx.TimeoutException:
            return False, "iletimerkezi-timeout"
        except httpx.RequestError as exc:
            return False, f"iletimerkezi-request-error:{type(exc).__name__}"
