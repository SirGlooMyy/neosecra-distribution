"""Setur PMS API integration."""
import logging
from datetime import date, datetime

import httpx

from app.modules.pms.demo import demo_or_fail
from app.modules.pms.schemas import PmsVerifyResult
from app.modules.pms.utils import normalize_turkish as _normalize_turkish

log = logging.getLogger(__name__)


async def _mock_verify(room_number: str, surname_or_birth: str) -> dict:
    is_valid = room_number.strip().isdigit() and len(_normalize_turkish(surname_or_birth)) >= 3
    return {
        "verified": is_valid,
        "guest_name": f"GUEST/{surname_or_birth.upper()}" if is_valid else None,
        "check_in": date.today() if is_valid else None,
        "check_out": date(2026, 12, 31) if is_valid else None,
        "stay_status": "checked_in" if is_valid else "unknown",
    }


async def verify_guest(
    room_number: str,
    surname_or_birth: str,
    pms_config: dict | None = None,
) -> PmsVerifyResult:
    pms_config = pms_config or {}
    room_clean = (room_number or "").strip()
    query_clean = _normalize_turkish(surname_or_birth or "")

    if not room_clean or not query_clean:
        log.warning("[Setur] Oda numarasi veya sorgu bos")
        return PmsVerifyResult(verified=False, vendor="setur", message="Oda numarasi ve sorgu bilgisi gerekli")

    api_url = (pms_config.get("host") or "").rstrip("/")
    api_key = pms_config.get("api_key", "")

    if not api_url:
        log.info("[Setur] API yapilandirilmamis")
        return await demo_or_fail(
            vendor="setur",
            room_number=room_clean,
            surname_or_birth=query_clean,
            mock_fn=_mock_verify,
            missing_config_message="Setur API yapilandirilmamis",
        )

    endpoint = f"{api_url}/api/reservations/check"

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    payload = {
        "roomNumber": room_clean,
        "lastName": query_clean,
    }

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(endpoint, json=payload, headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                verified = data.get("success", False) or data.get("found", False)
                res_data = data.get("reservation") or data.get("data", {})
                if isinstance(res_data, dict):
                    full_name = f"{res_data.get('firstName', '')} {res_data.get('lastName', '')}".strip()
                    ci = res_data.get("checkIn") or res_data.get("arrivalDate")
                    co = res_data.get("checkOut") or res_data.get("departureDate")
                    st = res_data.get("status", "checked_in")
                else:
                    full_name = str(res_data) if res_data else ""
                    ci = co = None
                    st = "checked_in"
                log.info("[Setur] Room=%s verified=%s guest=%s", room_clean, verified, full_name)
                return PmsVerifyResult(
                    verified=bool(verified),
                    guest_name=full_name or None,
                    check_in=_parse_date(ci),
                    check_out=_parse_date(co),
                    stay_status=st,
                    vendor="setur",
                )
            log.warning("[Setur] HTTP %s: %s", resp.status_code, resp.text[:200])
            return PmsVerifyResult(
                verified=False,
                vendor="setur",
                message=f"Setur API HTTP {resp.status_code}",
            )
    except httpx.TimeoutException:
        log.warning("[Setur] Zaman asimi: %s", endpoint)
        return PmsVerifyResult(verified=False, vendor="setur", message="Setur API zaman asimi")
    except httpx.HTTPStatusError as exc:
        log.warning("[Setur] HTTP %s", exc.response.status_code)
        return PmsVerifyResult(verified=False, vendor="setur", message=f"Setur API HTTP: {exc.response.status_code}")
    except Exception as exc:
        log.error("[Setur] Baglanti hatasi: %s", exc)
        return PmsVerifyResult(verified=False, vendor="setur", message=f"Setur API baglanti hatasi: {exc}")


def _parse_date(val) -> date | None:
    if val is None:
        return None
    if isinstance(val, date):
        return val
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d"):
        try:
            return datetime.strptime(str(val).strip(), fmt).date()
        except ValueError:
            continue
    return None
