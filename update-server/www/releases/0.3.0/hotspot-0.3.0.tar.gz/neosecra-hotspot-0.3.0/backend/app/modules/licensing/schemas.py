"""Pydantic schemas for licensing."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field



class LicenseUpsert(BaseModel):
    """Admin-set quota. active_guests_quota=-1 means unlimited. All fields
    optional so an admin can PATCH a single field without resending the rest."""

    active_guests_quota: int | None = Field(default=None, ge=-1)
    max_sessions_per_day: int | None = Field(default=None, ge=-1)
    session_minutes_default: int | None = Field(default=None, ge=1)
    expires_at: datetime | None = None
    is_trial: bool | None = None
    is_active: bool | None = None
    plan: str | None = Field(default=None, max_length=40)
    meta: dict | None = None


class LicenseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    customer_name: str | None = None
    active_guests_quota: int
    max_sessions_per_day: int | None
    session_minutes_default: int | None
    expires_at: datetime | None
    is_trial: bool
    is_active: bool
    plan: str
    meta: dict
    created_at: datetime
    updated_at: datetime


class LicenseCreate(BaseModel):
    customer_id: uuid.UUID
    active_guests_quota: int
    max_sessions_per_day: int | None = None
    session_minutes_default: int | None = None
    expires_at: datetime | None = None
    is_trial: bool = False
    is_active: bool = True
    plan: str = "default"


class LicenseUsageOut(BaseModel):
    customer_id: uuid.UUID
    plan: str
    is_active: bool
    active_guests: int
    active_guests_quota: int
    expires_at: datetime | None = None


class QuotaStatus(BaseModel):
    """Live quota snapshot used by the captive flow + admin views."""

    customer_id: uuid.UUID
    active_guests_quota: int
    active_count: int
    active_remaining: int  # -1 = unlimited
    max_sessions_per_day: int | None
    daily_used: int
    daily_remaining: int | None  # None/​-1 = unlimited
    session_minutes_default: int | None
    expired: bool
    active: bool
    within_quota: bool
