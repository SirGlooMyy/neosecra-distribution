# Repository/data access layer for partners
