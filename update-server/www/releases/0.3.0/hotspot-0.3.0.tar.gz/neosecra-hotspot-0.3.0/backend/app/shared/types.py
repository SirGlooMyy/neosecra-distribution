"""Shared SQLAlchemy mixins used by every domain model."""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column


class UUIDPK:
    """UUID primary key, application-generated (no DB round-trip)."""
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class SoftDeleteMixin:
    """Soft-delete flag. Hard deletes are forbidden for tenant/customer/
    location trees; use is_active=False (Mutlak Kural: data safety)."""
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


def fk(table: str, column: str = "id", ondelete: str = "CASCADE", nullable: bool = False):
    """Shortcut for a tenant-tree FK column."""
    return mapped_column(
        UUID(as_uuid=True),
        ForeignKey(f"{table}.{column}", ondelete=ondelete),
        nullable=nullable,
        index=True,
    )
