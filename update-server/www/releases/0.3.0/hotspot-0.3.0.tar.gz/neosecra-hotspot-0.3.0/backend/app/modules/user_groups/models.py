import uuid
from datetime import datetime

from sqlalchemy import BigInteger, Integer, String, Boolean, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk


class UserGroup(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    """User group with bandwidth/QoS limits.

    Groups are defined per-customer and applied to guest sessions.
    A group controls speed limits, session timeouts, and data quotas.
    """

    __tablename__ = "user_groups"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Bandwidth limits (kbps)
    bandwidth_up: Mapped[int | None] = mapped_column(BigInteger, nullable=True, comment="Upload speed limit in kbps")
    bandwidth_down: Mapped[int | None] = mapped_column(BigInteger, nullable=True, comment="Download speed limit in kbps")

    # Session timeouts (minutes)
    session_timeout: Mapped[int | None] = mapped_column(Integer, nullable=True, comment="Max session duration in minutes")
    idle_timeout: Mapped[int | None] = mapped_column(Integer, nullable=True, comment="Idle timeout in minutes")

    # Data quotas (MB)
    daily_quota: Mapped[int | None] = mapped_column(BigInteger, nullable=True, comment="Daily data quota in MB")
    weekly_quota: Mapped[int | None] = mapped_column(BigInteger, nullable=True, comment="Weekly data quota in MB")
    monthly_quota: Mapped[int | None] = mapped_column(BigInteger, nullable=True, comment="Monthly data quota in MB")
    hourly_quota: Mapped[int | None] = mapped_column(BigInteger, nullable=True, comment="Hourly data quota in MB")

    # Concurrent sessions limit
    max_sessions: Mapped[int] = mapped_column(Integer, default=1, nullable=False, comment="Max concurrent sessions per user")

    # Access schedule
    access_start: Mapped[datetime | None] = mapped_column(nullable=True, comment="Allowed access start time")
    access_end: Mapped[datetime | None] = mapped_column(nullable=True, comment="Allowed access end time")

    # Legacy storage retained for existing records; VLAN/NAC is not exposed by
    # the Hotspot management API or UI.
    vlan_id: Mapped[int | None] = mapped_column(Integer, nullable=True)

    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
