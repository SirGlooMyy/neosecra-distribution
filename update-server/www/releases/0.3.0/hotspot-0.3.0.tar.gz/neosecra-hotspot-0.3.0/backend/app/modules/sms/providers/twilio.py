import httpx
from app.core.config import settings
from .base import SmsProvider


class TwilioProvider(SmsProvider):
    async def send(self, phone: str, message: str) -> tuple[bool, str]:
        account_sid = self.value("username", settings.TWILIO_ACCOUNT_SID)
        auth_token = self.value("password", settings.TWILIO_AUTH_TOKEN)
        options = self.config.get("provider_options") or {}
        from_number = self.value("sender", settings.TWILIO_FROM_NUMBER)
        messaging_service_sid = str(options.get("messaging_service_sid") or "").strip()
        if not account_sid or not auth_token:
            return False, "twilio-missing-credentials"
        url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"
        auth = (account_sid, auth_token)
        data = {"To": phone, "Body": message}
        # Twilio accepts either a verified From number or a Messaging Service
        # SID. Sending both is rejected by the API.
        if messaging_service_sid:
            data["MessagingServiceSid"] = messaging_service_sid
        elif from_number:
            data["From"] = from_number
        else:
            return False, "twilio-missing-from-or-messaging-service"
        if options.get("status_callback"):
            data["StatusCallback"] = str(options["status_callback"])
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, data=data, auth=auth)
            if 200 <= resp.status_code < 300:
                try:
                    return True, str(resp.json().get("sid") or "") or None
                except ValueError:
                    return True, None
            try:
                detail = resp.json().get("message") or resp.json().get("code")
            except ValueError:
                detail = None
            return False, f"twilio-{resp.status_code}" + (f":{detail}" if detail else "")
        except Exception as exc:
            return False, f"twilio-error:{type(exc).__name__}"
