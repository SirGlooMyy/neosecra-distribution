"""PMS shared utilities."""


def normalize_turkish(text: str) -> str:
    """Normalize Turkish characters for robust case-insensitive surname matches."""
    if not text:
        return ""
    text = text.upper().strip()
    replacements = {
        "Ş": "S", "Ç": "C", "Ğ": "G", "Ü": "U", "Ö": "O", "İ": "I", "ı": "i",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text
