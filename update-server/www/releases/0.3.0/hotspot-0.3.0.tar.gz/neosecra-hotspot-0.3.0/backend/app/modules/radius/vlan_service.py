"""Dinamik VLAN atama servisi — kullanici grubuna gore VLAN ID.

RADIUS AVPs:
  Tunnel-Type = VLAN (13)
  Tunnel-Medium-Type = IEEE-802 (6)
  Tunnel-Private-Group-ID = <VLAN_ID>
"""
from __future__ import annotations

import logging
import re
import uuid

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.radius.models import VlanProfile

log = logging.getLogger(__name__)

RADIUS_TUNNEL_TYPE_VLAN = 13
RADIUS_TUNNEL_MEDIUM_802 = 6


def build_user_group_key(group_name: str, group_id: uuid.UUID) -> str:
    """Build a stable, human-readable VLAN profile key for a user group."""
    normalized = re.sub(r"[^a-z0-9]+", "-", group_name.strip().lower()).strip("-")
    prefix = normalized or "group"
    return f"{prefix[:80]}-{group_id.hex[:8]}"


async def _get_profile_by_key(
    db: AsyncSession,
    customer_id: uuid.UUID,
    user_group: str,
) -> VlanProfile | None:
    result = await db.execute(
        select(VlanProfile).where(
            VlanProfile.customer_id == customer_id,
            VlanProfile.user_group == user_group,
        ).limit(1)
    )
    return result.scalar_one_or_none()


async def assign_vlan(
    db: AsyncSession,
    user_group: str,
    session_info: dict | None = None,
) -> int:
    """Kullanici grubuna gore VLAN ID bul. Bulunamazsa default 1 don.

    Args:
        db: Veritabani oturumu.
        user_group: Kullanici grubu (employee, guest, iot, ...).
        session_info: Opsiyonel session bilgisi (log icin).

    Returns:
        VLAN ID (int).
    """
    q = select(VlanProfile).where(
        VlanProfile.user_group == user_group,
    ).limit(1)
    res = await db.execute(q)
    profile = res.scalar_one_or_none()
    if not profile:
        log.info("VLAN profili bulunamadi (user_group=%s), default 1", user_group)
        return 1
    return profile.vlan_id


async def sync_profile_for_group(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    group_id: uuid.UUID,
    group_name: str,
    vlan_id: int | None,
    description: str | None = None,
    previous_group_name: str | None = None,
) -> VlanProfile | None:
    """Upsert or remove the VLAN profile mirrored from a user group."""
    key = build_user_group_key(group_name, group_id)
    previous_key = (
        build_user_group_key(previous_group_name, group_id)
        if previous_group_name
        else None
    )

    current = await _get_profile_by_key(db, customer_id, key)
    previous = None
    if previous_key and previous_key != key:
        previous = await _get_profile_by_key(db, customer_id, previous_key)

    if vlan_id is None:
        if current:
            await db.delete(current)
        if previous and previous is not current:
            await db.delete(previous)
        await db.flush()
        return None

    if current is None:
        current = VlanProfile(
            customer_id=customer_id,
            name=group_name,
            vlan_id=vlan_id,
            user_group=key,
            description=description,
        )
        db.add(current)
    else:
        current.name = group_name
        current.vlan_id = vlan_id
        current.user_group = key
        current.description = description

    if previous and previous is not current:
        await db.delete(previous)

    await db.flush()
    return current


def build_vlan_avps(vlan_id: int) -> dict[str, object]:
    """RADIUS VLAN AVPlarini olustur.

    Args:
        vlan_id: VLAN ID.

    Returns:
        Tunnel-Type, Tunnel-Medium-Type, Tunnel-Private-Group-ID.
    """
    return {
        "Tunnel-Type": RADIUS_TUNNEL_TYPE_VLAN,
        "Tunnel-Medium-Type": RADIUS_TUNNEL_MEDIUM_802,
        "Tunnel-Private-Group-ID": str(vlan_id),
    }


async def create_profile(
    db: AsyncSession,
    customer_id: uuid.UUID,
    name: str,
    vlan_id: int,
    user_group: str,
    description: str | None = None,
) -> VlanProfile:
    """Yeni VLAN profili olustur.

    Args:
        db: Veritabani oturumu.
        customer_id: Musteri ID.
        name: Profil adi.
        vlan_id: VLAN ID.
        user_group: Kullanici grubu.
        description: Aciklama.

    Returns:
        Olusturulan VlanProfile.
    """
    exist = await _get_profile_by_key(db, customer_id, user_group)
    if exist:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"'{user_group}' grubu icin zaten bir VLAN profili var",
        )

    profile = VlanProfile(
        customer_id=customer_id,
        name=name,
        vlan_id=vlan_id,
        user_group=user_group,
        description=description,
    )
    db.add(profile)
    await db.commit()
    await db.refresh(profile)
    return profile


async def update_profile(
    db: AsyncSession,
    profile_id: uuid.UUID,
    customer_id: uuid.UUID,
    **kwargs,
) -> VlanProfile:
    """VLAN profili guncelle.

    Args:
        db: Veritabani oturumu.
        profile_id: Profil ID.
        customer_id: Musteri ID (dogrulama icin).
        **kwargs: Guncellenecek alanlar.

    Returns:
        Guncellenen VlanProfile.
    """
    profile = await db.get(VlanProfile, profile_id)
    if not profile or profile.customer_id != customer_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="VLAN profili bulunamadi",
        )
    for key, value in kwargs.items():
        if hasattr(profile, key):
            setattr(profile, key, value)
    await db.commit()
    await db.refresh(profile)
    return profile


async def delete_profile(db: AsyncSession, profile_id: uuid.UUID, customer_id: uuid.UUID) -> bool:
    """VLAN profilini sil.

    Args:
        db: Veritabani oturumu.
        profile_id: Profil ID.
        customer_id: Musteri ID (dogrulama).

    Returns:
        True basarili.
    """
    profile = await db.get(VlanProfile, profile_id)
    if not profile or profile.customer_id != customer_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="VLAN profili bulunamadi",
        )
    await db.delete(profile)
    await db.commit()
    return True


async def delete_profile_for_group(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    group_name: str,
    group_id: uuid.UUID,
) -> bool:
    """Delete the mirrored VLAN profile for a user group."""
    profile = await _get_profile_by_key(db, customer_id, build_user_group_key(group_name, group_id))
    if not profile:
        return False
    await db.delete(profile)
    await db.flush()
    return True


async def list_profiles(db: AsyncSession, customer_id: uuid.UUID) -> list[VlanProfile]:
    """Musterinin VLAN profillerini listele.

    Args:
        db: Veritabani oturumu.
        customer_id: Musteri ID.

    Returns:
        VlanProfile listesi.
    """
    q = select(VlanProfile).where(
        VlanProfile.customer_id == customer_id,
    ).order_by(VlanProfile.name.asc())
    res = await db.execute(q)
    return list(res.scalars().all())
