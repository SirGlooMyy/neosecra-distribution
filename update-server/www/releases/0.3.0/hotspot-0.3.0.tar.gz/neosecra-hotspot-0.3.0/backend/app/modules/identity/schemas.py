"""Identity verification schemas.

portal_token is returned ONLY in PortalTokenOut at issue time; never in
IdentityOut (admin/support view). tc_number is NEVER returned in any schema.
"""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class TcVerifyIn(BaseModel):
    tc_number: str = Field(..., min_length=11, max_length=11)


class PortalTokenOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    portal_token: str
    method: str
    expires_at: datetime


class IdentityOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None
    device_id: uuid.UUID | None
    method: str
    phone_masked: str | None
    verified: bool
    created_at: datetime
    consumed_at: datetime | None
    portal_token_expires_at: datetime