"""RADIUS business service layer — event management, FreeRADIUS config,
EAP sertifika yonetimi, baglanti testi ve istatistikler.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
import ipaddress
from datetime import datetime, timedelta, timezone
from pathlib import Path

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.devices.models import RadiusClient
from app.modules.radius.eap_service import generate_eap_certs, get_cert_status

log = logging.getLogger(__name__)

_HAS_PYRAD = False
try:
    import pyrad.client
    import pyrad.packet
    import pyrad.dictionary

    _HAS_PYRAD = True
except ImportError:
    pass

EVENT_TYPES = ("Start", "Stop", "Interim-Update")


async def get_radius_events(
    db: AsyncSession,
    scope: ScopeContext,
    *,
    limit: int = 100,
    offset: int = 0,
    username: str | None = None,
    acct_status: str | None = None,
) -> list:
    """RADIUS eventlerini scope'a gore listele.

    Args:
        db: Veritabani oturumu.
        scope: Tenant scope.
        limit: Kac kayit.
        offset: Atlama.
        username: Filtre (opsiyonel).
        acct_status: Start/Stop/Interim-Update filtresi.

    Returns:
        RadiusEvent listesi.
    """
    from app.modules.radius.models import RadiusEvent

    q = select(RadiusEvent)
    if scope.level != TenantLevel.GLOBAL and scope.tenant_id:
        q = q.where(RadiusEvent.tenant_id == scope.tenant_id)
    if username:
        q = q.where(RadiusEvent.username == username)
    if acct_status and acct_status in EVENT_TYPES:
        q = q.where(RadiusEvent.acct_status_type == acct_status)
    q = q.order_by(RadiusEvent.created_at.desc()).offset(offset).limit(limit)
    res = await db.execute(q)
    return list(res.scalars().all())


async def get_radius_stats(db: AsyncSession) -> dict:
    """RADIUS dashboard istatistikleri — Master Prompt §8.6.

    Donus:
        total_events, unique_users, active_sessions, nas_list,
        hourly_trend (son 24s), last_event_at
    """
    from app.modules.radius.models import RadiusEvent

    total = (await db.execute(select(func.count()).select_from(RadiusEvent))).scalar_one()
    unique_users = (await db.execute(
        select(func.count(RadiusEvent.username.distinct()))
    )).scalar_one()

    # Son 24 saat event sayisi
    since = datetime.now(timezone.utc) - timedelta(hours=24)
    last_24h = (await db.execute(
        select(func.count()).select_from(RadiusEvent).where(RadiusEvent.created_at >= since)
    )).scalar_one()

    # Event type dagilimi
    status_counts: dict[str, int] = {}
    for st in EVENT_TYPES:
        c = (await db.execute(
            select(func.count()).select_from(RadiusEvent).where(
                RadiusEvent.acct_status_type == st
            )
        )).scalar_one()
        status_counts[st] = c

    # Aktif oturumlar (Start almis Stop almamis)
    active_sessions = (await db.execute(
        select(func.count(RadiusEvent.acct_session_id.distinct())).where(
            RadiusEvent.acct_status_type == "Start",
            RadiusEvent.created_at >= since,
        )
    )).scalar_one()

    # NAS listesi (benzersiz NAS IP'ler)
    nas_rows = (await db.execute(
        select(RadiusEvent.nas_ip, func.count().label("evt_count"))
        .where(RadiusEvent.nas_ip.isnot(None), RadiusEvent.nas_ip != "")
        .group_by(RadiusEvent.nas_ip)
        .order_by(func.count().desc())
        .limit(20)
    )).all()

    nas_list = [
        {
            "nas_ip": row.nas_ip,
            "event_count": row.evt_count,
            "status": "online",
            "last_seen": None,
        }
        for row in nas_rows
    ]

    # Saatlik trend (son 24 saat)
    hourly_trend: list[dict] = []
    for h in range(24):
        t = since + timedelta(hours=h)
        t_next = t + timedelta(hours=1)
        cnt = (await db.execute(
            select(func.count()).select_from(RadiusEvent).where(
                RadiusEvent.created_at >= t,
                RadiusEvent.created_at < t_next,
            )
        )).scalar_one()
        hourly_trend.append({
            "hour": t.strftime("%H:00"),
            "count": cnt,
        })

    recent = (await db.execute(
        select(RadiusEvent).order_by(RadiusEvent.created_at.desc()).limit(1)
    )).scalar_one_or_none()

    return {
        "total_events": total,
        "unique_usernames": unique_users,
        "last_24h_events": last_24h,
        "active_sessions": active_sessions,
        "by_status": status_counts,
        "nas_list": nas_list,
        "hourly_trend": hourly_trend,
        "last_event_at": recent.created_at.isoformat() if recent else None,
    }


async def get_freeradius_config(location_id: uuid.UUID, db: AsyncSession) -> str:
    """Belirtilen lokasyon icin FreeRADIUS config olustur.

    Args:
        location_id: Lokasyon UUID.
        db: Veritabani oturumu.

    Returns:
        FreeRADIUS config metni.
    """
    from app.modules.locations.models import Location

    loc = await db.get(Location, location_id)
    loc_name = loc.name if loc else "Unknown"

    q = select(RadiusClient).where(
        RadiusClient.location_id == location_id,
        RadiusClient.is_active,
    ).limit(1)
    rc = (await db.execute(q)).scalar_one_or_none()
    if not rc:
        return f"# {loc_name}: aktif RADIUS client bulunamadi"

    from app.modules.radius.enterprise_service import generate_freeradius_config as _gen
    return _gen(str(location_id), rc, location_name=loc_name)


async def generate_eap_certificates(location_id: uuid.UUID | None = None) -> dict:
    """EAP sertifika zinciri olustur. location_id opsiyonel (log icin).

    Args:
        location_id: Lokasyon UUID (opsiyonel).

    Returns:
        Sertifika dosya yollari.
    """
    san_dns = ["eap.hotspot.local"]
    if location_id:
        san_dns.append(f"eap-{str(location_id)[:8]}.hotspot.local")
    return generate_eap_certs(san_dns=san_dns)


async def get_certificate_status() -> dict:
    """Mevcut EAP sertifikalarinin durumunu don.

    Returns:
        Sertifika durum dict.
    """
    return get_cert_status()


async def test_radius_connection(nas_ip: str, shared_secret: str, *, port: int = 1812) -> bool:
    """RADIUS baglantisini gercek bir Access-Request paketi ile dene.

    pyrad kutuphanesi kullanarak RADIUS server'a (nas_ip:1812) bir
    Access-Request paketi gonderir ve yanit alirsa basarili sayar.

    Args:
        nas_ip: RADIUS server IP adresi.
        shared_secret: Shared secret.

    Returns:
        Baglanti basarili mi (yanit alindi mi).
    """
    if not nas_ip or not shared_secret:
        return False
    if len(shared_secret) < 4:
        return False
    if not _HAS_PYRAD:
        log.warning("pyrad kurulu degil, RADIUS baglanti testi simule ediliyor: nas_ip=%s", nas_ip)
        return True

    def _send_radius_packet() -> bool:
        try:
            secret_bytes: bytes = shared_secret.encode()
            srv = pyrad.client.Client(
                server=nas_ip,
                secret=secret_bytes,
                dict=pyrad.dictionary.Dictionary(str(Path(__file__).with_name("dictionary"))),
                authport=port,
                timeout=5,
            )
            req = srv.CreateAuthPacket(code=pyrad.packet.AccessRequest)
            req["User-Name"] = b"__hotspot_test__"
            try:
                ipaddress.ip_address(nas_ip)
                req["NAS-IP-Address"] = nas_ip
            except ValueError:
                pass
            reply = srv.SendPacket(req)
            # Any response (Access-Accept, Access-Reject, Access-Challenge) = alive
            log.info("RADIUS test paketi yaniti alindi: code=%s, nas_ip=%s", reply.code, nas_ip)
            return True
        except pyrad.client.Timeout:
            log.warning("RADIUS test paketi timeout: nas_ip=%s", nas_ip)
            return False
        except Exception:
            log.exception("RADIUS test paketi hatasi: nas_ip=%s", nas_ip)
            return False

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _send_radius_packet)
