from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import settings
from app.core.ingest_auth import require_ingest_api_key
from app.modules.syslog.models import SyslogRecord
from app.modules.syslog.schemas import SyslogRecordCreate, SyslogRecordOut

router = APIRouter()


@router.post("/records", response_model=SyslogRecordOut, summary="Ingest a syslog message record", description="Creates a new syslog record from an incoming syslog message. Accepts standard syslog fields such as facility, severity, hostname, and message body. Typically called by the syslog receiver service.")
async def create_syslog_record(
    body: SyslogRecordCreate,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    require_ingest_api_key(request, expected_key=settings.SYSLOG_API_KEY, service="Syslog")
    record = SyslogRecord(
        tenant_id=body.tenant_id,
        facility=body.facility,
        severity=body.severity,
        hostname=body.hostname,
        app_name=body.app_name,
        message=body.message
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)
    return record
