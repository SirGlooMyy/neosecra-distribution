"""Guest session admin endpoints (visibility + manual close).

Read = session.read; close = session.write. Guest sessions are CREATED by the
public captive flow via sessions.service.create_session (internal call), not
through this admin router.

Close also triggers firewall revoke (Mutlak Kural #5 — orphan prevention).
"""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.firewall_adapters.service import (
    get_active_sessions_service,
    revoke_guest_service,
    sync_session_with_device_service,
)
from app.modules.sessions import correlation, service
from app.modules.sessions.schemas import (
    GuestSessionOut,
    SessionCloseIn,
    SessionCorrelationOut,
)

router = APIRouter()
log = __import__("logging").getLogger(__name__)


def _require(role: str, perm: str) -> None:
    if not has_permission(role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


@router.get("", response_model=list[GuestSessionOut], summary="List all guest sessions with optional filters", description="Returns a list of guest sessions scoped to the authenticated user's tenant. Supports filtering by status, date range, and device. Requires the session.read permission.")
async def list_sessions(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_sessions(db, scope_for(user))


@router.get("/online", response_model=list[GuestSessionOut], summary="List currently active online guest sessions", description="Returns only sessions with an active online status. Useful for monitoring currently connected guests in real time. Requires the session.read permission.")
async def list_online_sessions(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_online_sessions(db, scope_for(user))


@router.get("/pending", response_model=list[GuestSessionOut], summary="List guest sessions awaiting approval", description="Returns sessions that are in a pending state waiting for administrative approval. Useful for reviewing and processing new session requests. Requires the session.read permission.")
async def list_pending_sessions(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_pending_sessions(db, scope_for(user))


@router.get("/{session_id}", response_model=GuestSessionOut, summary="Retrieve a single guest session by ID", description="Fetches detailed information about a specific guest session including status, device, and timestamps. Access is scoped to the user's tenant. Requires the session.read permission.")
async def get_session(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    return await service.get_session(db, session_id, scope_for(user))


@router.get("/{session_id}/correlation", response_model=SessionCorrelationOut, summary="Retrieve correlation evidence for a guest session", description="Returns all correlated evidence sources (syslog, RADIUS, firewall logs) for the specified session. This endpoint enforces the evidence-chain requirement for audit compliance. The session must be in the caller's scope.")
async def get_session_correlation(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "session.read")
    await service.get_session(db, session_id, scope_for(user))
    return await correlation.correlate(db, guest_session_id=session_id)


@router.post("/{session_id}/approve", response_model=GuestSessionOut, summary="Approve a pending guest session for network access", description="Approves the specified pending session, triggering authorization on the firewall device. The guest will gain network access once approved. Requires the session.write permission.")
async def approve_session(
    session_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "session.write")
    return await service.approve_session(db, session_id, scope_for(user), user.id, request)


@router.post("/{session_id}/reject", response_model=GuestSessionOut, summary="Reject a pending guest session request", description="Rejects the specified pending session, denying network access to the guest. The session status is updated to rejected and no firewall authorization is performed. Requires the session.write permission.")
async def reject_session(
    session_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "session.write")
    return await service.reject_session(db, session_id, scope_for(user), user.id, request)


@router.post("/{session_id}/close", response_model=GuestSessionOut, summary="Close an active guest session and revoke firewall access", description="Terminates the specified session and automatically revokes the guest's access on the associated firewall device. This prevents orphaned sessions. Requires the session.write permission.")
async def close_session(
    session_id: uuid.UUID,
    body: SessionCloseIn,
    request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "session.write")
    scope = scope_for(user)
    session = await service.close_session(
        db, session_id, scope, user.id, request, reason=body.reason
    )
    if session.device_id:
        try:
            await revoke_guest_service(
                db, session.device_id, scope,
                {
                    "session_id": str(session.id),
                    "ip": session.ip,
                    "mac": session.mac,
                },
            )
        except Exception as exc:
            log.warning("firewall revoke failed for session=%s: %s", session.id, exc)
    return session
@router.get("/active-on-device/{device_id}", summary="List active sessions on a firewall device", description="Queries the firewall device directly for currently active sessions and returns them. Useful for reconciling the system state with actual device state. Requires the session.read permission.")
async def get_active_sessions_on_device(
    device_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "session.read")
    return await get_active_sessions_service(db, device_id, scope_for(user))


@router.post("/{session_id}/sync-device", response_model=GuestSessionOut, summary="Synchronize session status with the firewall device", description="Pushes the current session status (authorize or revoke) to the associated firewall device. Useful for re-syncing after a device reconnection or failure recovery. Requires the session.write permission.")
async def sync_session_with_device(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "session.write")
    scope = scope_for(user)
    session = await service.get_session(db, session_id, scope)
    if not session.device_id:
        raise HTTPException(status_code=400, detail="Oturum bir cihaza bagli degil")
    result = await sync_session_with_device_service(
        db,
        session.device_id,
        scope,
        {
            "session_id": str(session.id),
            "status": session.status,
            "ip": session.ip,
            "mac": session.mac,
            "username": session.phone or session.mac or "guest",
        },
    )
    if not result.ok:
        raise HTTPException(status_code=502, detail=result.message or "Cihaz senkronizasyonu basarisiz")
    return session
