"""Aruba adapter — Aruba Central API / Aruba Instant / ArubaOS.

Supports Aruba Central (REST API at apigw.central.arubanetworks.com),
Aruba Instant (local web server API), and ArubaOS (SSH/REST).
Auth via API token for Central, Basic auth for local devices.
"""
from __future__ import annotations

import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class ArubaAdapter(FirewallAdapter):
    vendor = "aruba"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        token = config.api_token or ""
        username = config.api_username or "admin"
        mode = (config.extra or {}).get("mode", "central")
        self._mode = mode
        if mode == "central":
            self._base_url = "https://apigw.central.arubanetworks.com"
        elif mode == "instant":
            self._base_url = f"https://{host}:{port}/rest/v4"
        else:
            self._base_url = f"https://{host}:{port}/v1/api"
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if mode == "central":
            if token:
                self._headers["Authorization"] = f"Bearer {token}"
                self._headers["Aruba-Customer-Id"] = config.extra.get("customer_id", "")
        else:
            import base64
            auth_str = f"{username}:{token or 'aruba'}"
            self._headers["Authorization"] = f"Basic {base64.b64encode(auth_str.encode()).decode()}"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"Aruba {self._mode} {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=True,
            radius_authentication=True,
            radius_accounting=True,
            radius_coa=True,
            disconnect_message=True,
            mac_auth_bypass=True,
            active_session_query=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            if self._mode == "central":
                data = await self._request("GET", "monitoring/v1/sites")
                sites = data.get("sites", [])
                return AdapterResult(
                    ok=True,
                    message=f"connected: Aruba Central ({len(sites)} site(s))",
                    data={"site_count": len(sites)},
                )
            else:
                data = await self._request("GET", "system/status")
                sys = data.get("system", data)
                model = (sys if isinstance(sys, dict) else {}).get("model", "?")
                return AdapterResult(
                    ok=True,
                    message=f"connected: Aruba {model}",
                    data={"model": model},
                )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        if self._mode == "central":
            data = await self._request("GET", "monitoring/v1/devices")
            devices = data.get("devices", [])
            if devices:
                d = devices[0]
                return {
                    "hostname": d.get("name", ""),
                    "model": d.get("model", ""),
                    "serial_number": d.get("serial", ""),
                    "firmware_version": d.get("firmware_version", ""),
                }
            return {}
        data = await self._request("GET", "system/status")
        sys = data.get("system", data) if isinstance(data, dict) else data
        return {
            "hostname": (sys if isinstance(sys, dict) else {}).get("hostname", ""),
            "model": (sys if isinstance(sys, dict) else {}).get("model", ""),
            "serial_number": (sys if isinstance(sys, dict) else {}).get("serial_number", ""),
            "firmware_version": (sys if isinstance(sys, dict) else {}).get("version", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "interfaces")
        raw = data.get("interfaces", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for iface in raw:
            results.append({
                "name": iface.get("name", ""),
                "ip": iface.get("ip_address", iface.get("ip", "")),
                "type": iface.get("type", ""),
                "status": "up" if iface.get("status") == "up" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            if self._mode == "central":
                data = await self._request("GET", "configuration/v1/captive_portal")
                cp = data.get("captive_portal", data)
                return {
                    "enabled": (cp if isinstance(cp, dict) else {}).get("enabled", False),
                    "redirect_url": (cp if isinstance(cp, dict) else {}).get("redirect_url", ""),
                }
            data = await self._request("GET", "captive-portal")
            cp = data.get("captive_portal", data)
            return {
                "enabled": (cp if isinstance(cp, dict) else {}).get("enabled", False),
                "redirect_url": (cp if isinstance(cp, dict) else {}).get("redirect_url", ""),
            }
        except AdapterError:
            return {"enabled": False}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "sessions")
        raw = data.get("sessions", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for s in raw:
            results.append({
                "ip": s.get("ip", ""),
                "user": s.get("user", ""),
                "mac": s.get("mac", ""),
                "ssid": s.get("ssid", ""),
                "state": s.get("state", ""),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "clients")
        raw = data.get("clients", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for c in raw:
            results.append({
                "ip": c.get("ip", ""),
                "mac": c.get("mac", ""),
                "interface": c.get("interface", ""),
                "vlan": c.get("vlan"),
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        policy = self._guest_policy(session)
        payload = {
            "ip": ip,
            "mac": mac,
            "duration_minutes": session.get("duration", 240),
            "username": session.get("username", f"guest_{mac}"),
            "comment": self._guest_comment(session),
        }
        try:
            if self._mode == "central":
                await self._request("POST", "configuration/v1/guest_accounts", json=payload)
            else:
                await self._request("POST", "guest-account", json=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={**payload, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "")
        try:
            if self._mode == "central":
                await self._request("DELETE", f"configuration/v1/guest_accounts/{mac}")
            else:
                await self._request("DELETE", f"guest-account/{mac}")
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "aruba", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("hostname")
        parsed["event_type"] = parsed.get("type") or parsed.get("category")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        parsed["ssid"] = parsed.get("ssid")
        parsed["bssid"] = parsed.get("bssid")
        return parsed
