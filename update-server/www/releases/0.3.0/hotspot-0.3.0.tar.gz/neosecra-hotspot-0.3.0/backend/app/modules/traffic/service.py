from datetime import datetime, timedelta, timezone

from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext
from app.modules.traffic.models import TrafficHourly, TrafficDaily, TopTalker


async def get_traffic_trend(
    db: AsyncSession, scope: ScopeContext, days: int = 30
) -> dict:
    cid = scope.customer_id
    now = datetime.now(timezone.utc)
    since = now - timedelta(days=days)

    # Hourly traffic
    q_hourly = select(
        TrafficHourly.hour,
        TrafficHourly.bytes_in,
        TrafficHourly.bytes_out,
        TrafficHourly.session_count,
        TrafficHourly.active_users,
    ).where(
        TrafficHourly.customer_id == cid,
        TrafficHourly.hour >= since,
    )
    if scope.location_id:
        q_hourly = q_hourly.where(TrafficHourly.location_id == scope.location_id)
    q_hourly = q_hourly.order_by(TrafficHourly.hour)
    r = await db.execute(q_hourly)
    hourly = [
        {"hour": h, "bytes_in": bi, "bytes_out": bo, "sessions": sc, "active": au}
        for h, bi, bo, sc, au in r.all()
    ]

    # Daily traffic
    q_daily = select(
        TrafficDaily.date,
        func.sum(TrafficDaily.bytes_in),
        func.sum(TrafficDaily.bytes_out),
        func.sum(TrafficDaily.session_count),
        func.max(TrafficDaily.peak_concurrent),
    ).where(
        TrafficDaily.customer_id == cid,
        TrafficDaily.date >= since,
    )
    if scope.location_id:
        q_daily = q_daily.where(TrafficDaily.location_id == scope.location_id)
    q_daily = q_daily.group_by(TrafficDaily.date).order_by(TrafficDaily.date)
    r = await db.execute(q_daily)
    daily = [
        {"date": d, "bytes_in": bi, "bytes_out": bo, "sessions": sc, "peak": pk}
        for d, bi, bo, sc, pk in r.all()
    ]

    # Top talkers
    q_top = select(TopTalker).where(
        TopTalker.customer_id == cid,
        TopTalker.period_start >= since,
    )
    if scope.location_id:
        q_top = q_top.where(TopTalker.location_id == scope.location_id)
    q_top = q_top.order_by(TopTalker.rank).limit(20)
    r = await db.execute(q_top)
    top_talkers = list(r.scalars().all())

    # Summary
    q_summary = select(
        func.coalesce(func.sum(TrafficDaily.bytes_in), 0),
        func.coalesce(func.sum(TrafficDaily.bytes_out), 0),
        func.coalesce(func.sum(TrafficDaily.session_count), 0),
        func.coalesce(func.max(TrafficDaily.peak_concurrent), 0),
        func.avg(TrafficDaily.avg_session_duration_min),
        func.coalesce(func.sum(TrafficDaily.unique_macs), 0),
    ).where(
        TrafficDaily.customer_id == cid,
        TrafficDaily.date >= since,
    )
    if scope.location_id:
        q_summary = q_summary.where(TrafficDaily.location_id == scope.location_id)
    r = await db.execute(q_summary)
    row = r.one()
    summary = {
        "total_bytes_in": int(row[0]),
        "total_bytes_out": int(row[1]),
        "total_sessions": int(row[2]),
        "peak_concurrent": int(row[3]),
        "avg_session_duration_min": float(row[4]) if row[4] else None,
        "unique_macs": int(row[5]),
    }

    return {
        "daily": daily,
        "hourly": hourly,
        "top_talkers": [{
            "mac": t.mac,
            "phone": t.phone,
            "bytes_in": t.bytes_in,
            "bytes_out": t.bytes_out,
            "session_count": t.session_count,
            "rank": t.rank,
        } for t in top_talkers],
        "summary": summary,
    }


async def get_traffic_dashboard(db: AsyncSession, scope: ScopeContext) -> dict:
    cid = scope.customer_id
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    # Current throughput (last hour)
    q_throughput = select(
        func.coalesce(func.sum(TrafficHourly.bytes_in + TrafficHourly.bytes_out), 0),
    ).where(
        TrafficHourly.customer_id == cid,
        TrafficHourly.hour >= (now - timedelta(hours=1)),
    )
    if scope.location_id:
        q_throughput = q_throughput.where(TrafficHourly.location_id == scope.location_id)
    r = await db.execute(q_throughput)
    current_throughput = r.scalar() or 0

    # Total bandwidth today
    q_today = select(
        func.coalesce(func.sum(TrafficDaily.bytes_in + TrafficDaily.bytes_out), 0),
    ).where(
        TrafficDaily.customer_id == cid,
        TrafficDaily.date >= today_start,
    )
    if scope.location_id:
        q_today = q_today.where(TrafficDaily.location_id == scope.location_id)
    r = await db.execute(q_today)
    total_bw = r.scalar() or 0

    # Daily usage last 7 days
    q_daily = select(
        TrafficDaily.date,
        func.sum(TrafficDaily.bytes_in),
        func.sum(TrafficDaily.bytes_out),
    ).where(
        TrafficDaily.customer_id == cid,
        TrafficDaily.date >= (today_start - timedelta(days=6)),
    )
    if scope.location_id:
        q_daily = q_daily.where(TrafficDaily.location_id == scope.location_id)
    q_daily = q_daily.group_by(TrafficDaily.date).order_by(TrafficDaily.date)
    r = await db.execute(q_daily)
    daily_usage = [
        {"date": d.isoformat(), "bytes_in": bi, "bytes_out": bo}
        for d, bi, bo in r.all()
    ]

    # Top locations by traffic
    q_loc = select(
        TrafficDaily.location_id,
        func.sum(TrafficDaily.bytes_in + TrafficDaily.bytes_out),
    ).where(
        TrafficDaily.customer_id == cid,
        TrafficDaily.date >= (today_start - timedelta(days=30)),
    )
    if scope.location_id:
        q_loc = q_loc.where(TrafficDaily.location_id == scope.location_id)
    q_loc = q_loc.group_by(TrafficDaily.location_id).order_by(desc(func.sum(TrafficDaily.bytes_in + TrafficDaily.bytes_out))).limit(10)
    r = await db.execute(q_loc)
    top_locations = [{"location_id": str(loc), "total_bytes": int(b)} for loc, b in r.all()]

    # Top talkers
    q_top = select(TopTalker).where(
        TopTalker.customer_id == cid,
        TopTalker.period_start >= (now - timedelta(days=7)),
    )
    if scope.location_id:
        q_top = q_top.where(TopTalker.location_id == scope.location_id)
    q_top = q_top.order_by(TopTalker.rank).limit(10)
    r = await db.execute(q_top)
    top_talkers = list(r.scalars().all())

    return {
        "total_bandwidth": total_bw,
        "current_throughput": current_throughput,
        "daily_usage": daily_usage,
        "top_locations": top_locations,
        "top_talkers": [{
            "mac": t.mac,
            "phone": t.phone,
            "bytes_in": t.bytes_in,
            "bytes_out": t.bytes_out,
            "session_count": t.session_count,
            "rank": t.rank,
        } for t in top_talkers],
        "auth_method_distribution": {},
    }
