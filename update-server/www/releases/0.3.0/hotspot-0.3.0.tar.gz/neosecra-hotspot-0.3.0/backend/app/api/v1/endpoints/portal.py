from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, Field
import uuid
from typing import Optional, List
from datetime import datetime, timezone

from app.core.config import settings
from app.core.database import get_db
from app.core.tenant import TenantLevel, scope_for
from app.modules.auth.deps import get_current_user
from app.modules.portal import flow
from app.modules.identity import service as identity_service
from app.modules.portal.i18n_data import SUPPORTED_LANGUAGES, LANGUAGE_NAMES
from app.modules.customers.models import Customer
from app.modules.portal.models import PortalTemplate
from app.modules.locations.models import Location
from app.modules.sessions.models import GuestSession
from app.modules.devices.models import Device
from app.modules.licensing.models import CustomerLicense
from app.modules.tenants.models import Tenant
from app.modules.sms.service import normalize_tr_phone, send_otp, verify_otp
from app.modules.identity.tc_validation import is_valid_turkish_identity_number
from app.modules.vouchers.service import redeem
from app.modules.whatsapp import service as whatsapp_service
from app.modules.meeting.service import create_meeting_code, verify_code as meeting_verify_code, list_codes as meeting_list_codes
from app.modules.meeting.models import MeetingCode
from app.modules.foreigner.service import validate_passport
from app.modules.local_auth.service import create_user as local_create_user, update_user as local_update_user, deactivate_user as local_deactivate_user, authenticate as local_authenticate, list_users as local_list_users

router = APIRouter()

# --- Request / Response schemas ---

class PortalConfigResponse(BaseModel):
    locationId: uuid.UUID
    tenantName: str
    locationName: str
    logoText: str
    welcomeTitle: str
    welcomeDescription: str
    primaryColor: str
    termsText: str
    supportText: str
    internetPolicyText: str
    internetPolicyUrl: Optional[str] = None
    kvkkText: str
    kvkkUrl: Optional[str] = None
    enabledMethods: List[str]
    availableLanguages: Optional[dict] = None
    isDemoMode: bool = False
    demoFallbackReason: Optional[str] = None

class SmsRequestIn(BaseModel):
    phone: str
    location_id: uuid.UUID

class SmsVerifyIn(BaseModel):
    phone: str
    code: str
    location_id: uuid.UUID

class TcSmsRequestIn(BaseModel):
    tc_number: str = Field(..., min_length=11, max_length=11)
    first_name: Optional[str] = Field(None, max_length=100)
    last_name: Optional[str] = Field(None, max_length=100)
    birth_year: Optional[int] = Field(None, ge=1900, le=2100)
    phone: str
    location_id: uuid.UUID

class VoucherVerifyIn(BaseModel):
    voucher_code: str
    location_id: uuid.UUID

class WhatsAppVerifyIn(BaseModel):
    phone: str
    code: str
    location_id: uuid.UUID

class WhatsAppRequestIn(BaseModel):
    phone: str
    location_id: uuid.UUID

class PmsVerifyIn(BaseModel):
    room_number: str
    surname_or_birth: str
    location_id: uuid.UUID

class MeetingVerifyIn(BaseModel):
    code: str
    location_id: uuid.UUID

class MeetingCodeCreateIn(BaseModel):
    location_id: Optional[uuid.UUID] = None
    event_name: str = Field(..., min_length=1, max_length=255)
    max_uses: int = Field(default=100, ge=1, le=10000)
    duration_minutes: int = Field(default=120, ge=1, le=1440)
    expires_at: datetime

class MeetingCodeOut(BaseModel):
    id: uuid.UUID
    code: str
    event_name: str
    max_uses: int
    current_uses: int
    duration_minutes: int
    expires_at: datetime
    is_active: bool
    created_at: datetime

class ForeignerVerifyIn(BaseModel):
    passport_number: str = Field(..., min_length=1, max_length=20)
    full_name: str = Field(..., min_length=1, max_length=200)
    country: str = Field(..., min_length=2, max_length=100)
    location_id: uuid.UUID

class LocalVerifyIn(BaseModel):
    username: str
    password: str
    location_id: uuid.UUID

class LdapVerifyIn(BaseModel):
    username: str = Field(..., min_length=1, max_length=100)
    password: str = Field(..., min_length=1, max_length=255)
    location_id: uuid.UUID

class LocalUserCreateIn(BaseModel):
    location_id: Optional[uuid.UUID] = None
    username: str = Field(..., min_length=3, max_length=100)
    password: str = Field(..., min_length=6, max_length=255)
    display_name: str = Field(..., min_length=1, max_length=200)
    email: Optional[str] = Field(None, max_length=200)
    phone: Optional[str] = Field(None, max_length=20)

class LocalUserUpdateIn(BaseModel):
    display_name: Optional[str] = Field(None, max_length=200)
    email: Optional[str] = Field(None, max_length=200)
    phone: Optional[str] = Field(None, max_length=20)
    password: Optional[str] = Field(None, min_length=6, max_length=255)

class LocalUserOut(BaseModel):
    id: uuid.UUID
    username: str
    display_name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    is_active: bool
    created_at: datetime

class DashboardSummaryResponse(BaseModel):
    active_guests: int
    total_locations: int
    total_devices: int
    license_status: str
    license_expires_at: Optional[datetime] = None

# --- Endpoints ---

@router.get("/config", response_model=PortalConfigResponse, summary="Get captive portal configuration for rendering", description="Returns the full portal configuration including branding, supported authentication methods, and available languages for the specified location. Falls back to the first active location if none specified. Publicly accessible for captive portal rendering.")
async def get_portal_config(
    location_id: Optional[uuid.UUID] = None,
    db: AsyncSession = Depends(get_db)
):
    if not location_id:
        # Fetch the first active location
        q_loc = select(Location).where(Location.is_active).limit(1)
        loc = (await db.execute(q_loc)).scalars().first()
        if not loc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Sistemde aktif lokasyon bulunamadi."
            )
    else:
        # Fetch location to find customer context
        loc = await db.get(Location, location_id)
        if not loc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Lokasyon bulunamadi."
            )

    customer = await db.get(Customer, loc.customer_id)
    tenant = await db.get(Tenant, customer.tenant_id) if customer else None
    demo_mode = False
    demo_reason: Optional[str] = None
    if customer:
        demo_mode, demo_reason = await flow.resolve_demo_state(
            db,
            customer,
            tenant=tenant,
        )

    # Fetch default template or specific location template
    q = select(PortalTemplate).where(
        PortalTemplate.customer_id == loc.customer_id
    ).order_by(PortalTemplate.is_default.desc())
    
    template = (await db.execute(q)).scalars().first()

    tenant_name = "Hotspot Operator"
    location_name = loc.name
    logo_text = "HOTSPOT"
    welcome_title = "Ucretsiz Wi-Fi Agina Hos Geldiniz"
    welcome_description = "Lutfen kimliginizi dogrulayarak internete baglanin."
    primary_color = "indigo"
    terms_text = "Kullanim sartlarini ve KVKK metnini okudum, onayliyorum."
    support_text = "Sorun durumunda danisma masasindan yardim isteyin."
    internet_policy_text = "İnternet kullanım politikasını okudum, kabul ediyorum."
    internet_policy_url: Optional[str] = None
    kvkk_text = "KVKK aydınlatma metnini okudum, kişisel verilerimin işlenmesini kabul ediyorum."
    kvkk_url: Optional[str] = None
    enabled_methods = ["sms", "tc_sms", "voucher", "whatsapp", "meeting", "foreigner", "local", "ldap"]

    if template:
        logo_text = template.name
        primary_color = template.theme.get("primaryColor", primary_color)
        welcome_title = template.theme.get("welcomeTitle", welcome_title)
        welcome_description = template.theme.get("welcomeDescription", welcome_description)
        terms_text = template.theme.get("termsText", template.theme.get("terms_text", terms_text))
        support_text = template.theme.get("supportText", template.theme.get("support_text", support_text))
        internet_policy_text = template.theme.get("internetPolicyText", template.theme.get("internet_policy_text", terms_text))
        internet_policy_url = template.theme.get("internetPolicyUrl", template.theme.get("internet_policy_url"))
        kvkk_text = template.theme.get("kvkkText", template.theme.get("kvkk_text", kvkk_text))
        kvkk_url = template.theme.get("kvkkUrl", template.theme.get("kvkk_url"))
        enabled_methods = [template.method] if template.method in ["sms", "tc", "voucher", "pms", "whatsapp", "meeting", "foreigner", "local", "ldap"] else ["sms", "tc_sms", "voucher", "pms", "whatsapp", "meeting", "foreigner", "local", "ldap"]
        if "tc" in enabled_methods:
            enabled_methods = [m if m != "tc" else "tc_sms" for m in enabled_methods]
        for m in ("whatsapp", "meeting", "foreigner", "local", "ldap"):
            if m not in enabled_methods:
                enabled_methods.append(m)

    if tenant:
        tenant_name = tenant.name

    return PortalConfigResponse(
        locationId=loc.id,
        tenantName=tenant_name,
        locationName=location_name,
        logoText=logo_text,
        welcomeTitle=welcome_title,
        welcomeDescription=welcome_description,
        primaryColor=primary_color,
        termsText=terms_text,
        supportText=support_text,
        internetPolicyText=internet_policy_text,
        internetPolicyUrl=internet_policy_url,
        kvkkText=kvkk_text,
        kvkkUrl=kvkk_url,
        enabledMethods=enabled_methods,
        availableLanguages={code: LANGUAGE_NAMES[code] for code in SUPPORTED_LANGUAGES},
        isDemoMode=demo_mode,
        demoFallbackReason=demo_reason,
    )

@router.post("/auth/sms/request", summary="Request SMS OTP code for portal authentication", description="Sends a one-time SMS verification code to the provided phone number for captive portal authentication. The phone number is normalized to Turkish format. Publicly accessible endpoint.")
async def portal_sms_request(
    body: SmsRequestIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    try:
        phone_normalized = normalize_tr_phone(body.phone)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    # Trigger sending SMS OTP
    res = await send_otp(
        db,
        phone=phone_normalized,
        customer_id=loc.customer_id,
        location_id=loc.id
    )
    return {
        "status": "success",
        "message": "SMS doğrulama kodu başarıyla gönderildi.",
        "details": res
    }

@router.post("/auth/sms/verify", summary="Verify SMS OTP code and grant network access", description="Validates the SMS verification code and issues a portal session token for network access. Supports a demo mode bypass with code 123456. Returns session ID and portal token on success.")
async def portal_sms_verify(
    body: SmsVerifyIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    if body.code == "123456" and settings.DEMO_MODE:
        return {
            "status": "success",
            "message": "Erişim başarıyla sağlandı.",
            "session_id": str(uuid.uuid4())
        }

    try:
        phone_normalized = normalize_tr_phone(body.phone)
        otp = await verify_otp(
            db,
            phone=phone_normalized,
            code=body.code,
            customer_id=loc.customer_id,
            location_id=loc.id
        )
    except HTTPException as exc:
        raise exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    iv = await identity_service.issue_for_sms(
        db,
        otp=otp,
        customer_id=loc.customer_id,
        location_id=loc.id,
        device_id=None,
        request=None,
    )

    return {
        "status": "success",
        "message": "Erişim başarıyla sağlandı.",
        "session_id": str(iv.id),
        "portal_token": iv.portal_token,
    }


@router.post("/auth/tc-sms/request", summary="Request SMS OTP with TC Kimlik No verification", description="Validates the Turkish National ID number (algorithmic check plus optional NVI verification) before sending an SMS OTP code. Used for regulatory-compliant guest authentication in Turkey.")
async def portal_tc_sms_request(
    body: TcSmsRequestIn,
    db: AsyncSession = Depends(get_db)
):
    # Algorithmic check on TC Identification number
    if not is_valid_turkish_identity_number(body.tc_number):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Geçersiz TC Kimlik Numarası algoritma kontrolü başarısız."
        )

    # NVI verification if personal info provided
    if body.first_name and body.last_name and body.birth_year:
        from app.modules.identity.tc_validation import verify_with_nvi_fallback
        nvi_ok = await verify_with_nvi_fallback(
            body.tc_number,
            first_name=body.first_name,
            last_name=body.last_name,
            birth_year=body.birth_year,
        )
        if not nvi_ok:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="TC Kimlik No ve kisisel bilgiler eslesmedi (NVI dogrulama basarisiz)."
            )

    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    try:
        phone_normalized = normalize_tr_phone(body.phone)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    # Send SMS OTP
    res = await send_otp(
        db,
        phone=phone_normalized,
        customer_id=loc.customer_id,
        location_id=loc.id
    )
    return {
        "status": "success",
        "message": "Kimlik doğrulandı, SMS kodu gönderildi.",
        "details": res
    }

@router.post("/auth/voucher/verify", summary="Verify a voucher code for network access", description="Validates the provided voucher code and issues a portal session token upon success. The voucher is consumed after successful verification. Publicly accessible for captive portal flow.")
async def portal_voucher_verify(
    body: VoucherVerifyIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    try:
        res = await redeem(
            db,
            code=body.voucher_code,
            customer_id=loc.customer_id,
            location_id=loc.id
        )
    except HTTPException as exc:
        raise exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    iv = await identity_service.issue_for_voucher(
        db,
        voucher=res,
        customer_id=loc.customer_id,
        location_id=loc.id,
        device_id=None,
        request=None,
    )

    return {
        "status": "success",
        "message": "Bilet kodu doğrulandı, internet erişimi verildi.",
        "voucher_id": str(res.id),
        "session_id": str(iv.id),
        "portal_token": iv.portal_token,
    }


@router.post("/auth/whatsapp/request", summary="Request WhatsApp verification code for portal auth", description="Sends a one-time verification code via WhatsApp to the provided phone number. The phone is normalized to Turkish format. Publicly accessible endpoint.")
async def portal_whatsapp_request(
    body: WhatsAppRequestIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    try:
        phone_normalized = normalize_tr_phone(body.phone)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    res = await whatsapp_service.send_whatsapp_code(
        db,
        phone=phone_normalized,
        customer_id=loc.customer_id,
        location_id=loc.id,
    )
    return {
        "status": "success",
        "message": "WhatsApp dogrulama kodu basariyla gonderildi.",
        "details": res
    }


@router.post("/auth/whatsapp/verify", summary="Verify WhatsApp code and grant portal access", description="Validates the WhatsApp verification code and issues a portal session token. Supports demo mode bypass with code 000000. Returns session ID and portal token on success.")
async def portal_whatsapp_verify(
    body: WhatsAppVerifyIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    if body.code == "000000" and settings.DEMO_MODE:
        return {
            "status": "success",
            "message": "Erisim basariyla saglandi.",
            "session_id": str(uuid.uuid4())
        }

    try:
        phone_normalized = normalize_tr_phone(body.phone)
        wa = await whatsapp_service.verify_whatsapp_code(
            db,
            phone=phone_normalized,
            code=body.code,
            customer_id=loc.customer_id,
            location_id=loc.id,
        )
    except HTTPException as exc:
        raise exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    iv = await identity_service.issue_for_whatsapp(
        db,
        wa=wa,
        customer_id=loc.customer_id,
        location_id=loc.id,
        device_id=None,
        request=None,
    )

    return {
        "status": "success",
        "message": "Erisim basariyla saglandi.",
        "session_id": str(iv.id),
        "portal_token": iv.portal_token,
    }


@router.post("/auth/pms/verify", summary="Verify guest via PMS hotel system integration", description="Validates the guest's room number and surname against the configured Property Management System. Issues a portal session token when the guest stay is confirmed. Supports mock mode for demos.")
async def portal_pms_verify(
    body: PmsVerifyIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")
    
    from app.modules.pms.models import PmsConfig
    from app.modules.pms.service import verify_guest_stay
    from app.core.crypto import decrypt

    result = await db.execute(
        select(PmsConfig).where(
            PmsConfig.customer_id == loc.customer_id,
            PmsConfig.is_active
        )
    )
    pms_cfg = result.scalar_one_or_none()

    if pms_cfg and pms_cfg.is_active:  # type: ignore[union-attr]
        pms_config = {
            "pms_type": pms_cfg.pms_type,  # type: ignore[union-attr]
            "host": pms_cfg.host,  # type: ignore[union-attr]
            "port": pms_cfg.port,  # type: ignore[union-attr]
            "username": pms_cfg.username,  # type: ignore[union-attr]
            "api_key": decrypt(pms_cfg.api_key_enc) if pms_cfg.api_key_enc else None,  # type: ignore[union-attr,arg-type]
            "password": decrypt(pms_cfg.password_enc) if pms_cfg.password_enc else None,  # type: ignore[union-attr,arg-type]
            "db_host": pms_cfg.db_host,  # type: ignore[union-attr]
            "db_port": pms_cfg.db_port,  # type: ignore[union-attr]
            "db_name": pms_cfg.db_name,  # type: ignore[union-attr]
            "db_user": pms_cfg.db_user,  # type: ignore[union-attr]
            "db_password": decrypt(pms_cfg.db_password_enc) if pms_cfg.db_password_enc else None,  # type: ignore[union-attr,arg-type]
            "custom_source_id": pms_cfg.extra.get("custom_source_id") if pms_cfg.extra else None,
            "extra": pms_cfg.extra or {},
        }
    else:
        if settings.DEMO_MODE:
            pms_config = {"pms_type": "mock"}
        else:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="PMS yapılandırması bulunamadı. Doğrulama için etkin bir PMS kaydı gerekli.",
            )
    
    pms_result = await verify_guest_stay(
        room_number=body.room_number,
        surname_or_birth=body.surname_or_birth,
        pms_config=pms_config
    )
    
    if not pms_result.verified:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=pms_result.message or "Otel konaklama bilgileri eşleşmedi veya oda check-out yapıldı."
        )

    iv = await identity_service.issue_for_pms(
        db,
        room_number=body.room_number,
        customer_id=loc.customer_id,
        location_id=loc.id,
        device_id=None,
        request=None,
    )

    return {
        "status": "success",
        "message": "Erişim başarıyla sağlandı.",
        "session_id": str(iv.id),
        "portal_token": iv.portal_token,
    }


@router.post("/auth/meeting/verify", summary="Verify a meeting/event code for portal access", description="Validates the meeting event code and issues a portal session token. Meeting codes are used for event-based guest authentication and can have limited uses and expiration. Publicly accessible.")
async def portal_meeting_verify(
    body: MeetingVerifyIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    mc = await meeting_verify_code(
        db,
        code=body.code,
        customer_id=loc.customer_id,
        location_id=loc.id,
    )

    iv = await identity_service.issue_for_meeting(
        db,
        meeting_code=mc.code,
        customer_id=loc.customer_id,
        location_id=loc.id,
        device_id=None,
        request=None,
    )

    return {
        "status": "success",
        "message": "Toplanti kodu dogrulandi, internet erisimi verildi.",
        "session_id": str(iv.id),
        "portal_token": iv.portal_token,
        "code": mc.code,
        "event_name": mc.event_name,
    }


@router.post("/auth/foreigner/verify", summary="Verify foreign passport for portal access", description="Validates the foreign guest's passport number, full name, and country of origin. Issues a portal session token upon successful passport verification. Publicly accessible.")
async def portal_foreigner_verify(
    body: ForeignerVerifyIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    is_valid = await validate_passport(
        passport_number=body.passport_number,
        country=body.country,
        full_name=body.full_name,
    )
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Pasaport bilgileri dogrulanamadi",
        )

    iv = await identity_service.issue_for_foreigner(
        db,
        passport_number=body.passport_number,
        full_name=body.full_name,
        country=body.country,
        customer_id=loc.customer_id,
        location_id=loc.id,
        device_id=None,
        request=None,
    )

    return {
        "status": "success",
        "message": "Pasaport bilgileri dogrulandi, internet erisimi verildi.",
        "session_id": str(iv.id),
        "portal_token": iv.portal_token,
    }


@router.post("/auth/local/verify", summary="Verify local database user account for portal access", description="Authenticates the user against the local user database and issues a portal session token. Local users are managed through the admin interface. Publicly accessible endpoint.")
async def portal_local_verify(
    body: LocalVerifyIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    user = await local_authenticate(
        db,
        username=body.username,
        password=body.password,
        customer_id=loc.customer_id,
    )
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Kullanici adi veya sifre hatali",
        )

    iv = await identity_service.issue_for_local(
        db,
        username=user.username,
        display_name=user.display_name,
        customer_id=loc.customer_id,
        location_id=loc.id,
        device_id=None,
        request=None,
    )

    return {
        "status": "success",
        "message": "Kullanici dogrulandi, internet erisimi verildi.",
        "session_id": str(iv.id),
        "portal_token": iv.portal_token,
        "display_name": user.display_name,
    }


@router.post("/auth/ldap/verify", summary="Verify corporate LDAP credentials for portal access", description="Authenticates the user against the corporate LDAP directory and issues a portal session token upon success. Requires the ldap3 library to be installed. Publicly accessible endpoint.")
async def portal_ldap_verify(
    body: LdapVerifyIn,
    db: AsyncSession = Depends(get_db)
):
    loc = await db.get(Location, body.location_id)
    if not loc:
        raise HTTPException(status_code=404, detail="Lokasyon bulunamadi.")

    from app.modules.ldap.service import authenticate as ldap_authenticate

    try:
        user_info = await ldap_authenticate(body.username, body.password)
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="LDAP modulu yuklu degil (ldap3 kutuphanesi gerekli).",
        )

    if not user_info:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Kullanici adi veya sifre hatali.",
        )

    await identity_service.issue_for_ldap(
        db,
        username=body.username,
        display_name=user_info.get("display_name", body.username),
        customer_id=loc.customer_id,
        location_id=loc.id,
    )

    return {
        "status": "success",
        "message": "Kurumsal giris basarili.",
        "session_id": str(uuid.uuid4()),
    }


# --- Meeting Code CRUD (admin) ---

@router.get("/meeting-codes", response_model=List[MeetingCodeOut], summary="List meeting codes for a customer (admin)", description="Returns all meeting/event codes configured for the specified customer. Requires authentication and proper scope access to the customer.")
async def list_meeting_codes(
    customer_id: uuid.UUID,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    scope = scope_for(user)
    if scope.level == "customer" and str(scope.customer_id) != str(customer_id):
        raise HTTPException(status_code=403, detail="Bu musteri icin erisim yetkiniz yok")
    codes = await meeting_list_codes(db, customer_id=customer_id)
    return [
        MeetingCodeOut(
            id=mc.id,
            code=mc.code,
            event_name=mc.event_name,
            max_uses=mc.max_uses,
            current_uses=mc.current_uses,
            duration_minutes=mc.duration_minutes,
            expires_at=mc.expires_at,
            is_active=mc.is_active,
            created_at=mc.created_at,
        )
        for mc in codes
    ]


@router.post("/meeting-codes", summary="Create a meeting code for event authentication (admin)", description="Creates a new meeting/event code for guest authentication during events. Requires authentication and proper scope access to the specified customer.")
async def create_meeting_code_endpoint(
    body: MeetingCodeCreateIn,
    customer_id: uuid.UUID,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    scope = scope_for(user)
    if scope.level == "customer" and str(scope.customer_id) != str(customer_id):
        raise HTTPException(status_code=403, detail="Bu musteri icin erisim yetkiniz yok")
    mc = await create_meeting_code(
        db,
        customer_id=customer_id,
        location_id=body.location_id,
        event_name=body.event_name,
        max_uses=body.max_uses,
        duration_minutes=body.duration_minutes,
        expires_at=body.expires_at,
        created_by=user.id,
    )
    return {
        "status": "success",
        "message": "Toplanti kodu basariyla olusturuldu.",
        "id": str(mc.id),
        "code": mc.code,
        "event_name": mc.event_name,
        "expires_at": mc.expires_at.isoformat(),
    }


@router.delete("/meeting-codes/{code_id}", status_code=204, summary="Deactivate a meeting code (admin)")
async def deactivate_meeting_code(
    code_id: uuid.UUID,
    customer_id: uuid.UUID,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    scope = scope_for(user)
    if scope.level == "customer" and str(scope.customer_id) != str(customer_id):
        raise HTTPException(status_code=403, detail="Bu musteri icin erisim yetkiniz yok")
    mc = await db.get(MeetingCode, code_id)
    if not mc or mc.customer_id != customer_id:
        raise HTTPException(status_code=404, detail="Toplanti kodu bulunamadi")
    mc.is_active = False
    await db.commit()


# --- Local User CRUD (admin) ---

@router.get("/local-users", response_model=List[LocalUserOut], summary="List local database users for a customer (admin)", description="Returns all locally managed user accounts for the specified customer. Local users can authenticate via the captive portal for network access. Requires authentication.")
async def list_local_users(
    customer_id: uuid.UUID,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    scope = scope_for(user)
    if scope.level == "customer" and str(scope.customer_id) != str(customer_id):
        raise HTTPException(status_code=403, detail="Bu musteri icin erisim yetkiniz yok")
    users = await local_list_users(db, customer_id=customer_id)
    return [
        LocalUserOut(
            id=u.id,
            username=u.username,
            display_name=u.display_name,
            email=u.email,
            phone=u.phone,
            is_active=u.is_active,
            created_at=u.created_at,
        )
        for u in users
    ]


@router.post("/local-users", summary="Create a local database user for portal authentication (admin)", description="Creates a new local user account that can authenticate via the captive portal. Requires a username, password, and display name. Requires authentication and customer scope.")
async def create_local_user(
    body: LocalUserCreateIn,
    customer_id: uuid.UUID,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    scope = scope_for(user)
    if scope.level == "customer" and str(scope.customer_id) != str(customer_id):
        raise HTTPException(status_code=403, detail="Bu musteri icin erisim yetkiniz yok")
    u = await local_create_user(
        db,
        customer_id=customer_id,
        location_id=body.location_id,
        username=body.username,
        password=body.password,
        display_name=body.display_name,
        email=body.email,
        phone=body.phone,
    )
    return {
        "status": "success",
        "message": "Kullanici basariyla olusturuldu.",
        "id": str(u.id),
        "username": u.username,
        "display_name": u.display_name,
    }


@router.put("/local-users/{user_id}", summary="Update a local user account (admin)", description="Updates the profile fields and optionally the password of a local user account. Only provided fields are modified. Requires authentication and customer scope.")
async def update_local_user(
    user_id: uuid.UUID,
    body: LocalUserUpdateIn,
    customer_id: uuid.UUID,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    scope = scope_for(user)
    if scope.level == "customer" and str(scope.customer_id) != str(customer_id):
        raise HTTPException(status_code=403, detail="Bu musteri icin erisim yetkiniz yok")
    u = await local_update_user(
        db,
        user_id=user_id,
        customer_id=customer_id,
        display_name=body.display_name,
        email=body.email,
        phone=body.phone,
        password=body.password,
    )
    return {
        "status": "success",
        "message": "Kullanici basariyla guncellendi.",
        "id": str(u.id),
        "username": u.username,
        "display_name": u.display_name,
    }


@router.delete("/local-users/{user_id}", status_code=204, summary="Deactivate a local user account (admin)", description="Disables the specified local user account, preventing it from authenticating via the captive portal. The account record is preserved for auditing purposes.")
async def deactivate_local_user(
    user_id: uuid.UUID,
    customer_id: uuid.UUID,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await local_deactivate_user(db, user_id=user_id, customer_id=customer_id)


@router.get("/dashboard/summary", response_model=DashboardSummaryResponse, summary="Get portal dashboard summary counts", description="Returns a dashboard summary including active guest count, total locations, total devices, and license status. Useful for the portal admin landing page. Requires authentication.")
async def get_dashboard_summary(
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user),
):
    scope = scope_for(user)
    customer_ids: list[uuid.UUID] | None = None
    location_ids: list[uuid.UUID] | None = None
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        customer_ids = [scope.customer_id]
    elif scope.level == TenantLevel.PARTNER and scope.partner_id:
        customer_ids = list((await db.execute(
            select(Customer.id).where(Customer.partner_id == scope.partner_id)
        )).scalars().all())
    elif scope.level == TenantLevel.LOCATION and scope.location_id:
        location_ids = [scope.location_id]
        loc_customer = await db.scalar(select(Location.customer_id).where(Location.id == scope.location_id))
        customer_ids = [loc_customer] if loc_customer else []
    elif scope.level != TenantLevel.GLOBAL:
        customer_ids = []

    session_q = select(GuestSession).where(GuestSession.status == "active")
    location_q = select(Location).where(Location.is_active)
    # Devices are scoped through their location (the Device model intentionally
    # stores no denormalized customer_id).  Always join Location so customer /
    # partner users cannot count devices belonging to another customer.
    device_q = select(Device).join(Location, Device.location_id == Location.id).where(Device.is_active)
    license_q = select(CustomerLicense)
    if customer_ids is not None:
        session_q = session_q.where(GuestSession.customer_id.in_(customer_ids))
        location_q = location_q.where(Location.customer_id.in_(customer_ids))
        license_q = license_q.where(CustomerLicense.customer_id.in_(customer_ids))
        device_q = device_q.where(Location.customer_id.in_(customer_ids))
    if location_ids is not None:
        session_q = session_q.where(GuestSession.location_id.in_(location_ids))
        location_q = location_q.where(Location.id.in_(location_ids))
        device_q = device_q.where(Device.location_id.in_(location_ids))

    active_guests = (await db.execute(session_q)).scalars().all()
    total_locations = (await db.execute(location_q)).scalars().all()
    total_devices = (await db.execute(device_q)).scalars().all()

    # Find license info
    license_row = (await db.execute(license_q.limit(1))).scalar_one_or_none()

    license_status = "active"
    license_expires_at = None
    if license_row:
        license_expires_at = license_row.expires_at
        if license_row.expires_at and license_row.expires_at < datetime.now(timezone.utc):
            license_status = "expired"
        elif not license_row.is_active:
            license_status = "inactive"

    return DashboardSummaryResponse(
        active_guests=len(active_guests),
        total_locations=len(total_locations),
        total_devices=len(total_devices),
        license_status=license_status,
        license_expires_at=license_expires_at
    )
