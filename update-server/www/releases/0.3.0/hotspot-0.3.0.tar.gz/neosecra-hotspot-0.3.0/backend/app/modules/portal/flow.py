"""Portal captive flow — PUBLIC (no admin JWT).

The guest is NOT a platform user, so there is no JWT and no User to build a
scope from. The trust anchor is `device_id`: the captive firewall redirects the
guest to the portal embedding the device it detected the client behind. From
that device we resolve the full site context (device -> location -> customer ->
portal template) and bind every downstream object (OTP / voucher / identity /
session) to the resolved customer_id + location_id, so a guest cannot replay a
credential across sites.

  Mutlak Kural #1/#2 — tenant isolation extends to the guest auth path: the
    guest may only touch the customer/location the device belongs to.
  Mutlak Kural #6 — the flow never starts without user/location/device/
    portal-template context (resolve_context raises before any work).
  Mutlak Kural #3 — the portal token is returned once (PortalTokenOut) and
    secrets never leak.

For the firewall authorize call there is no user scope, so we synthesize a
CUSTOMER-level ScopeContext from the resolved customer. get_device then
re-validates device.location_id -> location.customer_id == scope.customer, i.e.
the device must belong to the very customer we resolved. There is NO GLOBAL
bypass — the synthetic scope is a real, filtered scope.
"""
from __future__ import annotations

import logging
import re
import hashlib
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.ban import service as ban_service
from app.modules.customers.models import Customer
from app.modules.devices.models import Device
from app.modules.firewall_adapters.service import authorize_guest_service
from app.modules.identity import service as identity_service
from app.modules.identity.tc_validation import is_valid_turkish_identity_number
from app.modules.licensing import service as licensing_service
from app.modules.locations.models import Location
from app.modules.portal.models import (
    METHOD_FREE,
    METHOD_RADIUS,
    METHOD_SMS,
    METHOD_TC,
    METHOD_VOUCHER,
    METHOD_PMS,
    METHOD_WHATSAPP,
    METHOD_MEETING,
    METHOD_FOREIGNER,
    METHOD_LOCAL,
    METHOD_LDAP,
    PortalTemplate,
)
from app.modules.portal.field_schema import enabled_fields, normalize_fields
from app.modules.portal.schemas import (
    PortalContextOut,
    PortalTokenOut,
    StartSessionOut,
)
from app.modules.tenants.models import Tenant
from app.modules.sessions import service as sessions_service
from app.modules.sessions.models import AUTH_STATUS_AUTHORIZED, AUTH_STATUS_FAILED, STATUS_ACTIVE, STATUS_PENDING
from app.modules.sms import service as sms_service
from app.modules.sms.schemas import OtpResultOut
from app.modules.mfa.models import VpnMfaConfig
from app.core.crypto import decrypt
from app.modules.user_groups import service as user_groups_service
from app.modules.vouchers import service as voucher_service
from app.modules.whatsapp import service as whatsapp_service

log = logging.getLogger(__name__)


def _client_ip(request: Request | None) -> str | None:
    return request.client.host if request and request.client else None


async def _ensure_guest_not_banned(
    db: AsyncSession,
    *,
    customer_id,
    location_id=None,
    mac: str | None = None,
    phone: str | None = None,
    ip: str | None = None,
) -> None:
    """Fail closed if the guest is banned and not explicitly whitelisted."""
    if await ban_service.check_whitelisted(
        db,
        customer_id=customer_id,
        location_id=location_id,
        mac=mac,
        phone=phone,
    ):
        return
    banned = await ban_service.check_banned(
        db,
        customer_id=customer_id,
        location_id=location_id,
        mac=mac,
        phone=phone,
        ip=ip,
    )
    if banned:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu kullanici veya cihaz yasakli",
        )


def _build_group_session_payload(
    *,
    group,
    session_id: str | None,
    duration_minutes: int,
    mac: str,
    ip: str | None,
    phone: str | None,
) -> dict:
    policy = user_groups_service.build_group_policy(group)
    return {
        "session_id": session_id,
        "mac": mac,
        "ip": ip,
        "phone": phone,
        "username": phone or mac or "guest",
        "duration": duration_minutes,
        "duration_minutes": duration_minutes,
        "vlan": policy["vlan_id"],
        "vlan_id": policy["vlan_id"],
        "bandwidth_up": policy["bandwidth_up"],
        "bandwidth_down": policy["bandwidth_down"],
        "session_timeout": policy["session_timeout"],
        "idle_timeout": policy["idle_timeout"],
        "group_id": policy["group_id"],
        "group_name": policy["group_name"],
        "radius_avps": policy["radius_avps"],
        "policy": policy,
    }


_SAFE_FORM_KEYS = {
    "first_name", "last_name", "full_name", "email", "company", "department",
    "country", "consent", "marketing_consent",
}


def _safe_form_data(data: dict[str, object]) -> dict[str, object]:
    """Keep only bounded, non-secret values for 5651/session evidence.

    OTP codes and passwords are intentionally never persisted. T.C. numbers are
    also excluded from the evidence payload; the identity service stores only a
    salted hash for that field.
    """
    safe: dict[str, object] = {}
    for key, value in data.items():
        if key not in _SAFE_FORM_KEYS or key in {"tc_number", "passport_number"}:
            continue
        if value is None:
            continue
        text = str(value).strip()
        if text:
            safe[key] = text[:500]
    return safe


# ---- context resolution (device -> location -> customer -> template) --------
async def _select_template(
    db: AsyncSession, customer_id, location_id
) -> PortalTemplate | None:
    """Pick the portal template for a site: location-specific default first,
    then customer-wide default, then any active template for the location,
    then any active template for the customer."""
    loc_default = (
        await db.execute(
            select(PortalTemplate).where(
                PortalTemplate.customer_id == customer_id,
                PortalTemplate.location_id == location_id,
                PortalTemplate.is_default.is_(True),
                PortalTemplate.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    if loc_default:
        return loc_default

    cust_default = (
        await db.execute(
            select(PortalTemplate).where(
                PortalTemplate.customer_id == customer_id,
                PortalTemplate.location_id.is_(None),
                PortalTemplate.is_default.is_(True),
                PortalTemplate.is_active.is_(True),
            )
        )
    ).scalar_one_or_none()
    if cust_default:
        return cust_default

    loc_any = (
        await db.execute(
            select(PortalTemplate)
            .where(
                PortalTemplate.customer_id == customer_id,
                PortalTemplate.location_id == location_id,
                PortalTemplate.is_active.is_(True),
            )
            .order_by(PortalTemplate.created_at.desc())
        )
    ).scalars().first()
    if loc_any:
        return loc_any

    return (
        await db.execute(
            select(PortalTemplate)
            .where(
                PortalTemplate.customer_id == customer_id,
                PortalTemplate.location_id.is_(None),
                PortalTemplate.is_active.is_(True),
            )
            .order_by(PortalTemplate.created_at.desc())
        )
    ).scalars().first()


async def resolve_context(
    db: AsyncSession, *, device_id
) -> tuple[Device, Location, Customer, PortalTemplate]:
    """Resolve device -> location -> customer -> portal template.

    Raises 404 for any missing/inactive link so the flow never proceeds
    without full context (Mutlak Kural #6)."""
    device = await db.get(Device, device_id)
    if not device or not device.is_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cihaz bulunamadi veya pasif",
        )
    if not device.location_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cihaza lokasyon bagli degil",
        )
    location = await db.get(Location, device.location_id)
    if not location:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Lokasyon bulunamadi"
        )
    customer = await db.get(Customer, location.customer_id)
    if not customer or not getattr(customer, "is_active", True):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Musteri bulunamadi veya pasif",
        )
    template = await _select_template(db, customer.id, location.id)
    if not template or not template.is_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bu site icin portal sablonu bulunamadi",
        )
    return device, location, customer, template


def build_context_out(
    template: PortalTemplate,
    customer: Customer,
    *,
    is_demo_mode: bool = False,
    demo_fallback_reason: str | None = None,
) -> PortalContextOut:
    approval_cfg = (template.meta or {}).get("approval") if getattr(template, "meta", None) else None
    approval_cfg = approval_cfg if isinstance(approval_cfg, dict) else {}
    return PortalContextOut(
        method=template.method,
        theme=template.theme or {},
        fields=normalize_fields(template.fields, template.method),  # type: ignore[arg-type]
        terms_url=template.terms_url,
        success_message=template.success_message,
        customer_display_name=(
            getattr(customer, "display_name", None)
            or getattr(customer, "name", None)
            or getattr(customer, "legal_name", None)
        ),
        is_demo_mode=is_demo_mode,
        demo_fallback_reason=demo_fallback_reason,
        approval_required=bool(approval_cfg.get("required")),
        approval_message=str(approval_cfg.get("message") or "Yönetici onayından sonra internet erişiminiz açılacaktır.") if approval_cfg.get("required") else None,
    )


async def resolve_demo_state(
    db: AsyncSession, customer: Customer, tenant: Tenant | None = None
) -> tuple[bool, str | None]:
    """Return whether the resolved site should be treated as demo/sandbox."""
    if tenant is None:
        tenant = await db.get(Tenant, customer.tenant_id)
    if tenant and getattr(tenant, "is_demo", False):
        return True, f"Demo tenant aktif: {tenant.name}"
    if settings.DEMO_MODE:
        return True, "DEMO_MODE etkin"
    return False, None


# ---- send OTP (SMS and TC+SMS sites) ---------------------------------------
async def send_code(
    db: AsyncSession,
    *,
    device_id,
    phone: str,
    tc_number: str | None = None,
    request: Request | None,
) -> OtpResultOut:
    _, location, customer, template = await resolve_context(db, device_id=device_id)
    await _ensure_guest_not_banned(
        db,
        customer_id=customer.id,
        location_id=location.id,
        phone=phone,
    )
    if template.method not in (METHOD_SMS, METHOD_TC):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Bu site SMS/TC-SMS ile calismiyor",
        )
    if template.method == METHOD_TC:
        if not tc_number or not is_valid_turkish_identity_number(tc_number):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Gecersiz TC Kimlik No",
            )
    otp = await sms_service.send_otp(
        db,
        phone=phone,
        customer_id=customer.id,
        location_id=location.id,
        purpose="portal_login",
        request=request,
    )
    attempts_left = max(0, (getattr(otp, "max_attempts", 0) or 0) - (getattr(otp, "attempts", 0) or 0))
    return OtpResultOut(
        state="sent",
        ttl_seconds=settings.SMS_OTP_TTL_SECONDS,
        attempts_left=attempts_left,
    )


# ---- verify -> issue portal token ------------------------------------------
async def verify(
    db: AsyncSession,
    *,
    device_id,
    phone: str | None = None,
    code: str | None = None,
    tc_number: str | None = None,
    voucher_code: str | None = None,
    room_number: str | None = None,
    surname_or_birth: str | None = None,
    username: str | None = None,
    password: str | None = None,
    form_data: dict | None = None,
    request: Request | None = None,
) -> PortalTokenOut:
    """Dispatch on the template's method and issue a bound portal token.

    method is taken from the resolved template (NOT the client), so a guest
    cannot downgrade to a weaker auth path. Every issuer is bound to the
    resolved customer/location/device."""
    device, location, customer, template = await resolve_context(
        db, device_id=device_id
    )
    method = template.method
    # The template is the source of truth for required/optional fields.  Keep
    # the explicit legacy arguments below, while accepting editor-defined
    # values in form_data for collection and 5651 correlation.
    submitted = {str(k): v for k, v in (form_data or {}).items() if v is not None}
    submitted.update({
        key: value for key, value in {
            "phone": phone,
            "code": code,
            "tc_number": tc_number,
            "voucher_code": voucher_code,
            "room_number": room_number,
            "surname_or_birth": surname_or_birth,
            "username": username,
            "password": password,
        }.items() if value is not None and key not in submitted
    })
    for field in enabled_fields(template.fields, method):
        key = field["key"]
        value = submitted.get(key)
        if field.get("required") and (value is None or not str(value).strip()):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field.get('label') or key} gerekli",
            )
        if value is not None and field.get("validation") == "email":
            if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", str(value)):
                raise HTTPException(status_code=400, detail=f"{field.get('label') or key} geçerli değil")
        if value is not None and field.get("validation") == "tr_phone":
            digits = re.sub(r"\D", "", str(value))
            if len(digits) not in (10, 11):
                raise HTTPException(status_code=400, detail=f"{field.get('label') or key} geçerli değil")
    safe_form_data = _safe_form_data(submitted)
    if phone and method in (METHOD_SMS, METHOD_TC, METHOD_WHATSAPP):
        await _ensure_guest_not_banned(
            db,
            customer_id=customer.id,
            location_id=location.id,
            phone=phone,
        )

    if method == METHOD_SMS:
        if not phone or not code:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Telefon ve dogrulama kodu gerekli",
            )
        otp = await sms_service.verify_otp(
            db,
            phone=phone,
            code=code,
            customer_id=customer.id,
            location_id=location.id,
        )
        iv = await identity_service.issue_for_sms(
            db,
            otp=otp,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_TC and phone and code:
        if not tc_number:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="TC Kimlik No gerekli",
            )
        otp = await sms_service.verify_otp(
            db,
            phone=phone,
            code=code,
            customer_id=customer.id,
            location_id=location.id,
        )
        # Do not create a TC identity until the SMS challenge has actually
        # been verified.  This keeps the combined TC+SMS path fail-closed.
        if not otp.verified:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SMS dogrulamasi tamamlanmamis.",
            )
        iv = await identity_service.issue_for_tc(
            db,
            tc_number=tc_number,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_TC:
        if not tc_number:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="TC Kimlik No gerekli",
            )
        iv = await identity_service.issue_for_tc(
            db,
            tc_number=tc_number,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_VOUCHER:
        if not voucher_code:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Voucher kod gerekli",
            )
        voucher = await voucher_service.redeem(
            db,
            code=voucher_code,
            customer_id=customer.id,
            location_id=location.id,
        )
        iv = await identity_service.issue_for_voucher(
            db,
            voucher=voucher,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_FREE:
        iv = await identity_service.issue_free(
            db,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_PMS:
        if not room_number or not surname_or_birth:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Oda numarasi ve Soyad / Dogum Yili gereklidir",
            )
        from app.modules.pms.schemas import PmsVerifyResult
        from app.modules.pms.service import verify_guest_stay
        pms_settings = template.meta.get("pms_settings") if getattr(template, "meta", None) else None
        if not pms_settings:
            if settings.DEMO_MODE:
                pms_config = {"pms_type": "mock"}
            else:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="PMS yapılandırması bulunamadı. Doğrulama için etkin bir PMS kaydı gerekli.",
                )
        else:
            pms_config = pms_settings
        result: PmsVerifyResult = await verify_guest_stay(room_number, surname_or_birth, pms_config)
        if not result.verified:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Otel konaklama bilgileri eslesmedi veya oda check-out yapilmis.",
            )
        iv = await identity_service.issue_for_pms(
            db,
            room_number=room_number,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_WHATSAPP:
        if not phone or not code:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Telefon ve dogrulama kodu gerekli",
            )
        wa = await whatsapp_service.verify_whatsapp_code(
            db,
            phone=phone,
            code=code,
            customer_id=customer.id,
            location_id=location.id,
        )
        iv = await identity_service.issue_for_whatsapp(
            db,
            wa=wa,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_MEETING:
        if not voucher_code:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Toplanti kodu gerekli",
            )
        from app.modules.meeting import service as meeting_service
        mc = await meeting_service.verify_code(
            db,
            code=voucher_code,
            customer_id=customer.id,
            location_id=location.id,
        )
        iv = await identity_service.issue_for_meeting(
            db,
            meeting_code=mc.code,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_FOREIGNER:
        if not tc_number or not phone or not voucher_code:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Pasaport no, ad soyad ve ulke gerekli",
            )
        from app.modules.foreigner import service as foreigner_service
        is_valid = await foreigner_service.validate_passport(
            passport_number=tc_number,
            country=voucher_code,
            full_name=phone,
        )
        if not is_valid:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Pasaport bilgileri dogrulanamadi",
            )
        iv = await identity_service.issue_for_foreigner(
            db,
            passport_number=tc_number,
            full_name=phone,
            country=voucher_code,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_LOCAL:
        if not phone or not code:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kullanici adi ve sifre gerekli",
            )
        from app.modules.local_auth import service as local_auth_service
        local_user = await local_auth_service.authenticate(
            db,
            username=phone,
            password=code,
            customer_id=customer.id,
        )
        if not local_user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Kullanici adi veya sifre hatali",
            )
        iv = await identity_service.issue_for_local(
            db,
            username=local_user.username,
            display_name=local_user.display_name,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_LDAP:
        if not username or not password:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kullanici adi ve sifre gerekli",
            )
        from app.modules.ldap.service import authenticate as ldap_auth

        try:
            user_info = await ldap_auth(username, password)
        except ImportError:
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail="LDAP modulu yuklu degil (ldap3 kutuphanesi gerekli)",
            )
        if not user_info:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Kullanici adi veya sifre hatali",
            )
        iv = await identity_service.issue_for_ldap(
            db,
            username=username,
            display_name=user_info.get("display_name", username),
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    elif method == METHOD_RADIUS:
        if not username or not password:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="RADIUS kullanıcı adı ve şifre gerekli")
        # The customer-scoped VPN/RADIUS settings are also the captive-portal
        # RADIUS connection settings.  This keeps one source of truth for the
        # FortiGate shared secret while allowing the portal template to use a
        # real Access-Accept instead of the former 501 placeholder.
        radius_cfg = (await db.execute(select(VpnMfaConfig).where(VpnMfaConfig.customer_id == customer.id))).scalar_one_or_none()
        if not radius_cfg or not radius_cfg.gateway_host or not radius_cfg.radius_shared_secret_encrypted:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="RADIUS bağlantısı yapılandırılmamış")
        try:
            radius_secret = decrypt(radius_cfg.radius_shared_secret_encrypted)
        except Exception:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="RADIUS shared secret çözülemedi")
        from app.modules.radius.client import validate_access_request
        radius_result = await validate_access_request(
            radius_cfg.gateway_host,
            radius_secret,
            username=username,
            password=password,
            port=radius_cfg.gateway_port,
        )
        if not radius_result.get("ok"):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="RADIUS kullanıcı adı veya şifre hatalı")
        iv = await identity_service.issue_for_radius(
            db,
            username=username,
            customer_id=customer.id,
            location_id=location.id,
            device_id=device.id,
            request=request,
            **({"form_data": safe_form_data} if safe_form_data else {}),
        )
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Bilinmeyen portal yontemi",
        )

    return PortalTokenOut(
        portal_token=iv.portal_token,
        method=method,
        expires_at=iv.portal_token_expires_at,
    )


# ---- start-session (token exchange -> firewall authorize -> session row) ---
async def start_session(
    db: AsyncSession,
    *,
    device_id,
    portal_token: str,
    mac: str,
    ip: str | None = None,
    ssid: str | None = None,
    request: Request | None = None,
    # KVKK / Consent (HS-MVP-SLICE-01)
    terms_accepted: bool = False,
    privacy_accepted: bool = False,
    terms_version: str | None = None,
    privacy_version: str | None = None,
) -> StartSessionOut:
    """Exchange the bound portal token for an authorized guest session.

    1. resolve site context (re-validates device/site are live)
    2. validate the portal token is bound to THIS customer (fail-closed 401/410)
    3. authorize the guest IP on the firewall via a CUSTOMER-scoped adapter call
       (best-effort: a failed authorize still records the session for visibility)
    4. create the GuestSession bound to customer/location/device/identity
    5. consume the portal token (one-shot)

    The guest IP defaults to the request source IP so the firewall allowlist
    targets the real client even if the SPA did not pass it explicitly."""
    if not terms_accepted:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Kullanim kosullari kabul edilmemis.",
        )
    if not privacy_accepted:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="KVKK aydinlatma metni kabul edilmemis.",
        )
    device, location, customer, template = await resolve_context(
        db, device_id=device_id
    )
    iv = await identity_service.validate_portal_token(
        db, token=portal_token, customer_id=customer.id
    )
    await _ensure_guest_not_banned(
        db,
        customer_id=customer.id,
        location_id=location.id,
        mac=mac,
        phone=iv.phone,
        ip=ip,
    )

    approval_cfg = (template.meta or {}).get("approval") if getattr(template, "meta", None) else None
    approval_cfg = approval_cfg if isinstance(approval_cfg, dict) else {}
    approval_required = bool(approval_cfg.get("required"))
    approval_token = secrets.token_urlsafe(32) if approval_required else None

    # Quota gate (Mutlak Kural #12): enforce BEFORE authorize so an over-quota /
    # expired customer never gets a firewall allowlist entry. Missing license =
    # unlimited dev default; admin-set quotas raise 402 here. Done after token
    # validation so a consumed token is not wasted on a quota check.
    quota = await licensing_service.enforce_quota(db, customer.id)

    flow_scope = ScopeContext(
        level=TenantLevel.CUSTOMER, customer_id=customer.id
    )
    client_ip = ip or _client_ip(request)
    # License may override the default session length for this customer.
    duration = licensing_service.session_duration_minutes(
        quota, settings.GUEST_SESSION_DEFAULT_MINUTES
    )
    candidate_groups = await user_groups_service.list_session_groups(
        db,
        customer_id=customer.id,
        location_id=location.id,
    )
    group = user_groups_service.pick_session_group(candidate_groups)
    if candidate_groups and not group:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu saat araliginda aktif user group yok",
        )
    if group:
        active_count = await sessions_service.count_active_sessions_for_identity(
            db,
            customer_id=customer.id,
            phone=iv.phone,
            mac=mac,
        )
        if active_count >= group.max_sessions:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="User group eszamanli oturum limiti asildi",
            )
        if group.session_timeout:
            duration = min(duration, group.session_timeout)
    # Allocate the database identity before calling the firewall adapter. The
    # adapter uses this value to derive its idempotent address name; passing a
    # different/implicit id would make close-session unable to revoke it.
    session_id = uuid.uuid4()
    session_dict = {
        "session_id": str(session_id),
        "mac": (mac or "").strip().upper(),
        "ip": client_ip,
        "duration_minutes": duration,
        "username": iv.phone or (mac or "guest"),
    }
    if group:
        session_dict.update(
            _build_group_session_payload(
                group=group,
                session_id=str(session_id),
                duration_minutes=duration,
                mac=(mac or "").strip().upper(),
                ip=client_ip,
                phone=iv.phone,
            )
        )

    authorize_ok = not approval_required
    authorize_message: str | None = "Yönetici onayı bekleniyor" if approval_required else None
    if not approval_required:
        try:
            result = await authorize_guest_service(
                db, device.id, flow_scope, session_dict
            )
            authorize_ok = result.ok
            authorize_message = result.message
        except HTTPException as exc:
            # Misconfigured/unreachable device: record the session as authorize
            # failed so admins see the gap rather than silently dropping the guest.
            authorize_ok = False
            authorize_message = (
                exc.detail if isinstance(exc.detail, str) else "authorize hatasi"
            )
            log.warning(
                "portal authorize failed for device=%s customer=%s: %s",
                device.id, customer.id, authorize_message,
            )

    meta_payload = {"group_policy": user_groups_service.build_group_policy(group)} if group else {}
    meta_payload["terms_version"] = terms_version
    meta_payload["privacy_version"] = privacy_version
    if getattr(iv, "form_data", None):
        meta_payload["form_data"] = dict(iv.form_data or {})
    if approval_required and approval_token:
        meta_payload["approval"] = {
            "required": True,
            "status": "pending",
            "token_hash": hashlib.sha256(approval_token.encode("utf-8")).hexdigest(),
            "token_expires_at": (datetime.now(timezone.utc) + timedelta(minutes=settings.PORTAL_APPROVAL_TOKEN_TTL_MINUTES)).isoformat(),
            "manager_emails": approval_cfg.get("manager_emails") or [],
        }

    session = await sessions_service.create_session(
        db,
        session_id=session_id,
        customer_id=customer.id,
        mac=mac,
        auth_method=iv.method,
        location_id=location.id,
        device_id=device.id,
        identity_verification_id=iv.id,
        voucher_id=iv.voucher_id,
        group_id=group.id if group else None,
        phone=iv.phone,
        ip=client_ip,
        nas_ip=getattr(device, "mgmt_ip", None),
        ssid=ssid,
        duration_minutes=duration,
        authorize_ok=authorize_ok,
        authorize_message=authorize_message,
        meta=meta_payload,
        status=STATUS_PENDING if approval_required else STATUS_ACTIVE,
        terms_accepted=terms_accepted,
        privacy_accepted=privacy_accepted,
        terms_version=terms_version,
        privacy_version=privacy_version,
        consent_ip=client_ip,
        consent_user_agent=request.headers.get("user-agent") if request else None,
        request=request,
    )

    if authorize_ok and device_id:
        session.authorization_status = AUTH_STATUS_AUTHORIZED
        session.authorized_at = datetime.now(timezone.utc)
        session.authorization_attempts = 1
        session.external_session_id = str(session.id)
        await db.commit()
    elif not authorize_ok and approval_required:
        session.authorization_status = "pending"
        session.authorization_error_message = authorize_message
        session.authorization_attempts = 0
        await db.commit()
    elif not authorize_ok:
        session.authorization_status = AUTH_STATUS_FAILED
        session.authorization_error_message = authorize_message
        session.authorization_attempts = 1
        await db.commit()

    await identity_service.consume(db, iv_id=iv.id)

    if approval_required and approval_token:
        # Email delivery is best-effort; the manager can always approve from
        # the authenticated Sessions screen. Never expose the raw token in
        # logs or the API response.
        recipients = approval_cfg.get("manager_emails") or []
        if isinstance(recipients, str):
            recipients = [item.strip() for item in recipients.split(",") if item.strip()]
        if not recipients and getattr(customer, "contact_email", None):
            recipients = [customer.contact_email]
        if recipients:
            from app.modules.system.email_service import send_email
            base_url = (settings.PORTAL_PUBLIC_BASE_URL or (str(request.base_url).rstrip("/") if request else "")).rstrip("/")
            approve_url = f"{base_url}/portal/public/approval/{session.id}?token={approval_token}&decision=approve"
            reject_url = f"{base_url}/portal/public/approval/{session.id}?token={approval_token}&decision=reject"
            guest_label = (iv.form_data or {}).get("full_name") or (iv.form_data or {}).get("first_name") or iv.phone or "Misafir"
            html = (
                "<h2>Hotspot erişim onayı</h2>"
                f"<p><strong>{guest_label}</strong> erişim talebi yönetici onayı bekliyor.</p>"
                f"<p><a href=\"{approve_url}\">Erişimi onayla</a> &nbsp; "
                f"<a href=\"{reject_url}\">Reddet</a></p>"
                "<p>Bu bağlantı tek kullanımlıktır ve sınırlı süre geçerlidir.</p>"
            )
            for recipient in recipients[:20]:
                try:
                    await send_email(str(recipient), "Hotspot erişim onayı gerekiyor", html, customer_id=customer.id, db=db)
                except Exception:
                    log.warning("approval email could not be delivered", exc_info=True)

    return StartSessionOut(
        session_id=session.id,
        status=session.status,
        started_at=session.started_at,
        expires_at=session.expires_at,
        authorize_ok=authorize_ok,
        authorize_message=authorize_message,
        approval_required=approval_required,
        approval_status="pending" if approval_required else None,
        terms_accepted=session.terms_accepted,
        privacy_accepted=session.privacy_accepted,
        terms_version=session.terms_version,
        privacy_version=session.privacy_version,
    )
