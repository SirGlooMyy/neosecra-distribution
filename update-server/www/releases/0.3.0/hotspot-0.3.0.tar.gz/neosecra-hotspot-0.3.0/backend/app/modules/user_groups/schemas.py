import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class UserGroupCreate(BaseModel):
    # Single-installation deployments may omit the historical ownership key;
    # the API fills it from the active installation customer.
    customer_id: uuid.UUID | None = None
    location_id: uuid.UUID | None = None
    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    bandwidth_up: int | None = Field(None, ge=0)
    bandwidth_down: int | None = Field(None, ge=0)
    session_timeout: int | None = Field(None, ge=1)
    idle_timeout: int | None = Field(None, ge=1)
    daily_quota: int | None = Field(None, ge=0)
    weekly_quota: int | None = Field(None, ge=0)
    monthly_quota: int | None = Field(None, ge=0)
    hourly_quota: int | None = Field(None, ge=0)
    max_sessions: int = Field(1, ge=1, le=100)
    access_start: datetime | None = None
    access_end: datetime | None = None
    is_default: bool = False
    priority: int = Field(0, ge=0)


class UserGroupUpdate(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=255)
    description: str | None = None
    bandwidth_up: int | None = Field(None, ge=0)
    bandwidth_down: int | None = Field(None, ge=0)
    session_timeout: int | None = Field(None, ge=1)
    idle_timeout: int | None = Field(None, ge=1)
    daily_quota: int | None = Field(None, ge=0)
    weekly_quota: int | None = Field(None, ge=0)
    monthly_quota: int | None = Field(None, ge=0)
    hourly_quota: int | None = Field(None, ge=0)
    max_sessions: int | None = Field(None, ge=1, le=100)
    access_start: datetime | None = None
    access_end: datetime | None = None
    is_default: bool | None = None
    priority: int | None = Field(None, ge=0)


class UserGroupOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    name: str
    description: str | None = None
    bandwidth_up: int | None = None
    bandwidth_down: int | None = None
    session_timeout: int | None = None
    idle_timeout: int | None = None
    daily_quota: int | None = None
    weekly_quota: int | None = None
    monthly_quota: int | None = None
    hourly_quota: int | None = None
    max_sessions: int = 1
    access_start: datetime | None = None
    access_end: datetime | None = None
    is_default: bool = False
    priority: int = 0
    is_active: bool
    created_at: datetime
    updated_at: datetime


class UserGroupPolicyOut(BaseModel):
    group_id: uuid.UUID
    group_name: str
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    scope: Literal["customer", "location"]
    scope_label: str
    bandwidth_up: int | None = None
    bandwidth_down: int | None = None
    session_timeout: int | None = None
    idle_timeout: int | None = None
    daily_quota: int | None = None
    weekly_quota: int | None = None
    monthly_quota: int | None = None
    hourly_quota: int | None = None
    max_sessions: int = 1
    is_default: bool = False
    priority: int = 0
    access_start: str | None = None
    access_end: str | None = None
    access_window: dict[str, str | None] = Field(default_factory=dict)
    policy_summary: str
    enforcement_notes: list[str] = Field(default_factory=list)


class UserGroupPolicyPreviewOut(BaseModel):
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    eligible_group_count: int
    selected_group: UserGroupPolicyOut | None = None
    candidate_groups: list[UserGroupPolicyOut] = Field(default_factory=list)
    message: str
