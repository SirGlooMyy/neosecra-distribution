"""Shared licensing verification and enforcement for the Hotspot platform.

Ported from neosecra-pish with Hotspot-specific module map and role mapping.
"""
