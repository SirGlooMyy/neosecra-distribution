"""Single-installation ownership helpers.

The product is deployed for one organization, while that organization may
have many physical locations.  We keep the historical ``customers`` row as
the ownership anchor for existing records, but API callers no longer need to
send ``customer_id`` on every request.
"""
from __future__ import annotations

import uuid

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.customers.models import Customer


async def resolve_installation_customer(
    db: AsyncSession,
    requested: uuid.UUID | None = None,
) -> uuid.UUID:
    """Return the sole customer id for this installation.

    ``requested`` is accepted for backwards compatibility with old clients,
    but in single-tenant mode it must match the configured/selected customer.
    """
    configured: uuid.UUID | None = None
    if settings.SINGLE_TENANT_CUSTOMER_ID.strip():
        try:
            configured = uuid.UUID(settings.SINGLE_TENANT_CUSTOMER_ID.strip())
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="SINGLE_TENANT_CUSTOMER_ID gecersiz",
            ) from exc

    customer_id = configured or requested
    if customer_id is None:
        result = await db.execute(
            select(Customer.id)
            .where(Customer.is_active.is_(True))
            .order_by(Customer.created_at.asc())
            .limit(1)
        )
        customer_id = result.scalar_one_or_none()

    if customer_id is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Kurulum icin aktif bir musteri kaydi bulunamadi",
        )

    customer = await db.get(Customer, customer_id)
    if not customer or not customer.is_active:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Kurulum musteri kaydi bulunamadi veya pasif",
        )

    if configured and requested and requested != configured:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu kurulum tek musteri ile sinirlidir",
        )
    return customer_id
