"""Otel Plus PMS REST API integration."""
import logging
from datetime import date, datetime

import httpx

from app.modules.pms.demo import demo_or_fail
from app.modules.pms.schemas import PmsVerifyResult
from app.modules.pms.utils import normalize_turkish as _normalize_turkish

log = logging.getLogger(__name__)


async def _mock_verify(room_number: str, surname_or_birth: str) -> dict:
    is_valid = room_number.strip().isdigit() and len(_normalize_turkish(surname_or_birth)) >= 3
    return {
        "verified": is_valid,
        "guest_name": f"GUEST/{surname_or_birth.upper()}" if is_valid else None,
        "check_in": date.today() if is_valid else None,
        "check_out": date(2026, 12, 31) if is_valid else None,
        "stay_status": "checked_in" if is_valid else "unknown",
    }


async def verify_guest(
    room_number: str,
    surname_or_birth: str,
    pms_config: dict | None = None,
) -> PmsVerifyResult:
    pms_config = pms_config or {}
    room_clean = (room_number or "").strip()
    query_clean = _normalize_turkish(surname_or_birth or "")

    if not room_clean or not query_clean:
        log.warning("[OtelPlus] Oda numarasi veya sorgu bos")
        return PmsVerifyResult(verified=False, vendor="otelplus", message="Oda numarasi ve sorgu bilgisi gerekli")

    base_url = (pms_config.get("host") or "").rstrip("/")
    api_key = pms_config.get("api_key", "")

    if not base_url:
        log.info("[OtelPlus] API yapilandirilmamis")
        return await demo_or_fail(
            vendor="otelplus",
            room_number=room_clean,
            surname_or_birth=query_clean,
            mock_fn=_mock_verify,
            missing_config_message="OtelPlus API yapilandirilmamis",
        )

    endpoint = f"{base_url}/api/v1/guest/verify"

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    if api_key:
        headers["X-API-Key"] = api_key

    payload = {
        "oda_no": room_clean,
        "sorgu": query_clean,
    }

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(endpoint, json=payload, headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                verified = data.get("success", False) or data.get("found", False)
                guest = data.get("misafir", {}) or data.get("guest", {})
                if isinstance(guest, dict):
                    full_name = f"{guest.get('ad', '')} {guest.get('soyad', '')}".strip()
                    giris = guest.get("giris_tarihi") or guest.get("check_in")
                    cikis = guest.get("cikis_tarihi") or guest.get("check_out")
                    durum = guest.get("durum") or guest.get("status", "checked_in")
                else:
                    full_name = str(guest)
                    giris = None
                    cikis = None
                    durum = "checked_in"
                log.info("[OtelPlus] Room=%s verified=%s guest=%s", room_clean, verified, full_name)
                return PmsVerifyResult(
                    verified=bool(verified),
                    guest_name=full_name or None,
                    check_in=_parse_date(giris),
                    check_out=_parse_date(cikis),
                    stay_status=durum,
                    vendor="otelplus",
                )
            log.warning("[OtelPlus] HTTP %s: %s", resp.status_code, resp.text[:200])
            return PmsVerifyResult(
                verified=False,
                vendor="otelplus",
                message=f"OtelPlus API HTTP {resp.status_code}",
            )
    except httpx.TimeoutException:
        log.warning("[OtelPlus] Zaman asimi: %s", endpoint)
        return PmsVerifyResult(verified=False, vendor="otelplus", message="OtelPlus API zaman asimi")
    except httpx.HTTPStatusError as exc:
        log.warning("[OtelPlus] HTTP %s", exc.response.status_code)
        return PmsVerifyResult(verified=False, vendor="otelplus", message=f"OtelPlus API HTTP: {exc.response.status_code}")
    except Exception as exc:
        log.error("[OtelPlus] Baglanti hatasi: %s", exc)
        return PmsVerifyResult(verified=False, vendor="otelplus", message=f"OtelPlus API baglanti hatasi: {exc}")


def _parse_date(val) -> date | None:
    if val is None:
        return None
    if isinstance(val, date):
        return val
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d"):
        try:
            return datetime.strptime(str(val).strip(), fmt).date()
        except ValueError:
            continue
    return None
