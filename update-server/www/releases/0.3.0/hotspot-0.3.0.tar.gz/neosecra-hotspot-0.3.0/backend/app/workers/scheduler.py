from celery.schedules import crontab
from app.modules.workers.celery_app import celery_app

# Celery Beat schedule configuration
celery_app.conf.beat_schedule = {
    "expire-due-sessions-every-5-min": {
        "task": "app.modules.workers.tasks.expire_due_sessions",
        "schedule": 300.0,  # every 5 minutes
    },
    "archive-5651-daily-at-02-30-utc": {
        "task": "app.modules.workers.tasks.archive_5651_daily",
        "schedule": crontab(hour=2, minute=30),  # every day at 02:30 UTC
    },
}
