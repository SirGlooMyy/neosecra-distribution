"""SMTP / Email configuration service.

SMTP passwords are encrypted at rest via app.core.crypto (Mutlak Kural #3).
Email sending uses aiosmtplib (async) with smtplib fallback; prints in dev.
"""
from __future__ import annotations

import logging
import uuid

from sqlalchemy import Boolean, Integer, String, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from app.core.config import settings
from app.core.crypto import decrypt, encrypt
from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk

log = logging.getLogger(__name__)


class EmailConfig(Base, UUIDPK, TimestampMixin):
    __tablename__ = "email_configs"

    customer_id: Mapped[uuid.UUID | None] = fk("customers", ondelete="CASCADE", nullable=True)
    smtp_host: Mapped[str] = mapped_column(String(255), nullable=False)
    smtp_port: Mapped[int] = mapped_column(Integer, default=587, nullable=False)
    smtp_username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    smtp_password_encrypted: Mapped[str | None] = mapped_column(String(500), nullable=True)
    smtp_use_tls: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    smtp_use_ssl: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    from_address: Mapped[str] = mapped_column(String(255), nullable=False)
    from_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


async def get_config(db: AsyncSession, customer_id: uuid.UUID | None = None) -> EmailConfig | None:
    if customer_id:
        res = await db.execute(
            select(EmailConfig).where(EmailConfig.customer_id == customer_id)
        )
        cfg = res.scalar_one_or_none()
        if cfg:
            return cfg
    res = await db.execute(
        select(EmailConfig).where(EmailConfig.customer_id.is_(None))
    )
    return res.scalar_one_or_none()


async def upsert_config(
    db: AsyncSession,
    customer_id: uuid.UUID | None,
    data: dict,
) -> EmailConfig:
    res = await db.execute(
        select(EmailConfig).where(EmailConfig.customer_id == customer_id)
    )
    cfg = res.scalar_one_or_none()

    if not cfg:
        cfg = EmailConfig(customer_id=customer_id)

    for key in ("smtp_host", "smtp_port", "smtp_username", "smtp_use_tls",
                 "smtp_use_ssl", "from_address", "from_name", "is_verified"):
        if key in data:
            setattr(cfg, key, data[key])

    if "smtp_password" in data and data["smtp_password"]:
        cfg.smtp_password_encrypted = _encrypt_smtp_password(data["smtp_password"])

    db.add(cfg)
    await db.commit()
    await db.refresh(cfg)
    return cfg


async def test_connection(db: AsyncSession, config_id: uuid.UUID) -> dict:
    cfg = await db.get(EmailConfig, config_id)
    if not cfg:
        raise ValueError("E-posta yapilandirmasi bulunamadi")

    password = _decrypt_smtp_password(cfg.smtp_password_encrypted) if cfg.smtp_password_encrypted else ""

    try:
        import aiosmtplib  # type: ignore[import-not-found]
        if cfg.smtp_use_ssl:
            client = aiosmtplib.SMTP_SSL(cfg.smtp_host, cfg.smtp_port, timeout=10)
        else:
            client = aiosmtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=10)

        await client.connect()
        if cfg.smtp_use_tls:
            await client.starttls()
        if cfg.smtp_username and password:
            await client.login(cfg.smtp_username, password)
        await client.quit()

        cfg.is_verified = True
        await db.commit()

        return {
            "success": True,
            "message": "SMTP baglantisi basarili",
            "host": cfg.smtp_host,
            "port": cfg.smtp_port,
        }
    except ImportError:
        try:
            import smtplib
            if cfg.smtp_use_ssl:
                client = smtplib.SMTP_SSL(cfg.smtp_host, cfg.smtp_port, timeout=10)
            else:
                client = smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=10)
            if cfg.smtp_use_tls:
                client.starttls()
            if cfg.smtp_username and password:
                client.login(cfg.smtp_username, password)
            client.quit()

            cfg.is_verified = True
            await db.commit()

            return {
                "success": True,
                "message": "SMTP baglantisi basarili",
                "host": cfg.smtp_host,
                "port": cfg.smtp_port,
            }
        except Exception as exc:
            raise ValueError(f"SMTP baglantisi basarisiz: {exc}")
    except Exception as exc:
        raise ValueError(f"SMTP baglantisi basarisiz: {exc}")


def _encrypt_smtp_password(password: str) -> str:
    return encrypt(password)


def _decrypt_smtp_password(encrypted: str | None) -> str:
    if not encrypted:
        return ""
    return decrypt(encrypted)


async def send_email(
    to: str,
    subject: str,
    html_body: str,
    from_addr: str | None = None,
    customer_id: uuid.UUID | None = None,
    db: AsyncSession | None = None,
) -> bool:
    if not db:
        if settings.DEMO_MODE:
            log.info("[DEV EMAIL] To=%s | Subject=%s | Body=%s", to, subject, html_body[:200])
            return True
        log.error("E-posta verisi yok ve demo modu kapali: to=%s subject=%s", to, subject)
        return False

    cfg = await get_config(db, customer_id)
    if not cfg:
        if settings.DEMO_MODE:
            log.info("[DEV EMAIL - no config] To=%s | Subject=%s", to, subject)
            return True
        log.error("E-posta yapilandirmasi bulunamadi ve demo modu kapali: to=%s subject=%s", to, subject)
        return False

    password = _decrypt_smtp_password(cfg.smtp_password_encrypted) if cfg.smtp_password_encrypted else ""
    sender = from_addr or cfg.from_address
    name = cfg.from_name or ""

    try:
        import aiosmtplib  # type: ignore[import-not-found]
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"{name} <{sender}>" if name else sender
        msg["To"] = to
        msg.attach(MIMEText(html_body, "html"))

        if cfg.smtp_use_ssl:
            client = aiosmtplib.SMTP_SSL(cfg.smtp_host, cfg.smtp_port, timeout=10)
        else:
            client = aiosmtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=10)

        await client.connect()
        if cfg.smtp_use_tls:
            await client.starttls()
        if cfg.smtp_username and password:
            await client.login(cfg.smtp_username, password)
        await client.send_message(msg)
        await client.quit()
        log.info("E-posta gonderildi: to=%s subject=%s", to, subject)
        return True

    except ImportError:
        try:
            import smtplib
            from email.mime.text import MIMEText
            from email.mime.multipart import MIMEMultipart

            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = f"{name} <{sender}>" if name else sender
            msg["To"] = to
            msg.attach(MIMEText(html_body, "html"))

            if cfg.smtp_use_ssl:
                client = smtplib.SMTP_SSL(cfg.smtp_host, cfg.smtp_port, timeout=10)
            else:
                client = smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=10)
            if cfg.smtp_use_tls:
                client.starttls()
            if cfg.smtp_username and password:
                client.login(cfg.smtp_username, password)
            client.send_message(msg)
            client.quit()
            log.info("E-posta gonderildi (smtplib): to=%s", to)
            return True

        except Exception as exc:
            log.error("E-posta gonderilemedi: %s", exc)
            return False

    except Exception as exc:
        log.error("E-posta gonderilemedi: %s", exc)
        return False


async def send_template_email(
    to: str,
    template_name: str,
    template_data: dict,
    customer_id: uuid.UUID | None = None,
    db: AsyncSession | None = None,
) -> bool:
    try:
        from jinja2 import Environment, FileSystemLoader
        import os
        templates_dir = os.path.join(os.path.dirname(__file__), "templates")
        if not os.path.isdir(templates_dir):
            log.warning("E-posta template dizini bulunamadi: %s", templates_dir)
            html_body = f"<html><body><h1>{template_name}</h1><pre>{template_data}</pre></body></html>"
        else:
            env = Environment(loader=FileSystemLoader(templates_dir))
            tmpl = env.get_template(f"{template_name}.html")
            html_body = tmpl.render(**template_data)
    except ImportError:
        html_body = f"<html><body><h1>{template_name}</h1><pre>{template_data}</pre></body></html>"

    subject = template_data.get("subject", template_name.replace("_", " ").title())
    return await send_email(to, subject, html_body, customer_id=customer_id, db=db)
