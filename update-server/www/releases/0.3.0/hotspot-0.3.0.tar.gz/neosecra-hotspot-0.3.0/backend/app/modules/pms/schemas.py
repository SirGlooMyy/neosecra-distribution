"""Pydantic schemas for PMS module."""
import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


# --- PMS Config ---

class PmsConfigOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    pms_type: str
    host: str | None = None
    port: int | None = None
    username: str | None = None
    db_host: str | None = None
    db_port: int | None = None
    db_name: str | None = None
    db_user: str | None = None
    extra: dict = {}
    is_active: bool
    created_at: datetime
    updated_at: datetime


class PmsConfigUpdate(BaseModel):
    pms_type: str | None = Field(None, max_length=50)
    host: str | None = Field(None, max_length=255)
    port: int | None = None
    api_key: str | None = Field(None, max_length=2000)
    username: str | None = Field(None, max_length=255)
    password: str | None = Field(None, max_length=2000)
    db_host: str | None = Field(None, max_length=255)
    db_port: int | None = None
    db_name: str | None = Field(None, max_length=255)
    db_user: str | None = Field(None, max_length=255)
    db_password: str | None = Field(None, max_length=2000)
    extra: dict | None = None
    is_active: bool | None = None


# --- PMS Verification ---

class PmsVerifyResult(BaseModel):
    verified: bool
    guest_name: str | None = None
    check_in: date | None = None
    check_out: date | None = None
    stay_status: str | None = None
    vendor: str = "mock"
    message: str | None = None


# --- PMS Vendor Info ---

PMS_VENDOR_META = {
    "opera": "Oracle Opera XML/SOAP Web Service",
    "elektra": "Elektra PMS (Direct DB or REST)",
    "sispar": "Sispar PMS REST API",
    "fidelio": "Fidelio (Micros) XML Web Service",
    "otelplus": "Otel Plus PMS REST API",
    "setur": "Setur PMS API",
    "custom": "Custom / Generic Data Source",
    "mock": "Mock (Demo / Test) Mode",
}


# --- Custom Source ---

class CustomSourceCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    source_type: str = Field(..., pattern=r"^(json_api|excel|csv|database|sql_query)$")
    connection_config: dict = Field(default_factory=dict)
    field_mapping: dict = Field(default_factory=dict)
    is_active: bool = True


class CustomSourceUpdate(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=255)
    source_type: str | None = Field(None, pattern=r"^(json_api|excel|csv|database|sql_query)$")
    connection_config: dict | None = None
    field_mapping: dict | None = None
    is_active: bool | None = None


class CustomSourceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    name: str
    source_type: str
    field_mapping: dict = {}
    is_active: bool
    created_at: datetime
    updated_at: datetime
