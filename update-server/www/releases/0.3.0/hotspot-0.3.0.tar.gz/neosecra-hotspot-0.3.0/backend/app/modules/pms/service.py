"""PMS guest verification — vendor dispatch layer.

Each vendor module implements verify_guest(room, surname, pms_config)
and returns a PmsVerifyResult pydantic model.
"""
import logging
from datetime import date, datetime

from app.modules.pms import (
    custom_service,
    elektra_service,
    fidelio_service,
    opera_service,
    otelplus_service,
    setur_service,
    sispar_service,
)
from app.modules.pms.schemas import PmsVerifyResult
from app.modules.pms.utils import normalize_turkish as _normalize_turkish

log = logging.getLogger(__name__)

PMS_VENDORS = {
    "opera": opera_service.verify_guest,
    "elektra": elektra_service.verify_guest,
    "sispar": sispar_service.verify_guest,
    "fidelio": fidelio_service.verify_guest,
    "otelplus": otelplus_service.verify_guest,
    "setur": setur_service.verify_guest,
    "custom": custom_service.query_custom_source,
}





def _parse_date(val) -> date | None:
    if val is None:
        return None
    if isinstance(val, date):
        return val
    if isinstance(val, datetime):
        return val.date()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d"):
        try:
            return datetime.strptime(str(val).strip(), fmt).date()
        except ValueError:
            continue
    return None


async def _mock_verify_guest(
    room_number: str,
    surname_or_birth: str,
    pms_config: dict | None = None,
) -> PmsVerifyResult:
    room_clean = (room_number or "").strip()
    surname_clean = _normalize_turkish(surname_or_birth)

    if not room_clean or not surname_clean:
        return PmsVerifyResult(
            verified=False, vendor="mock", message="Oda numarasi ve soyad gerekli"
        )

    if not room_clean.isdigit():
        return PmsVerifyResult(
            verified=False, vendor="mock", message="Oda numarasi sayisal olmalidir"
        )

    is_year = len(surname_clean) == 4 and surname_clean.isdigit()
    is_alpha_name = surname_clean.isalpha() and len(surname_clean) >= 3

    if not (is_year or is_alpha_name):
        return PmsVerifyResult(
            verified=False,
            vendor="mock",
            message="Soyad en az 3 harf veya 4 haneli dogum yili olmalidir",
        )

    return PmsVerifyResult(
        verified=True,
        guest_name=f"GUEST/{surname_clean}",
        check_in=date.today(),
        check_out=date(2026, 12, 31),
        stay_status="checked_in",
        vendor="mock",
    )


PMS_VENDORS["mock"] = _mock_verify_guest


async def verify_guest_stay(
    room_number: str,
    surname_or_birth: str,
    pms_config: dict | None = None,
) -> PmsVerifyResult:
    """
    Verify guest stay details with the configured PMS vendor.

    pms_config format:
      {
        "pms_type": "opera" | "elektra" | "sispar" | "mock",
        "host": "192.168.10.50",
        "port": 5000,
        "api_key": "optional-key"
      }
    """
    pms_config = pms_config or {}
    vendor = str(pms_config.get("pms_type") or "").lower()
    if not vendor:
        log.warning("PMS vendor missing; fail-closed")
        return PmsVerifyResult(
            verified=False,
            vendor="unknown",
            message="PMS yapılandırması bulunamadı",
        )

    log.info(
        "PMS verification started. Vendor: %s, Room: %s, Query: %s",
        vendor, room_number, surname_or_birth,
    )

    if vendor in PMS_VENDORS:
        verify_fn = PMS_VENDORS[vendor]
        if vendor == "custom":
            custom_source_id = pms_config.get("custom_source_id")
            if custom_source_id:
                from app.core.database import AsyncSessionLocal
                async with AsyncSessionLocal() as db:
                    return await verify_fn(db, custom_source_id, room_number, surname_or_birth)
            return PmsVerifyResult(
                verified=False, vendor="custom", message="Custom kaynak ID belirtilmemis"
            )
        return await verify_fn(room_number, surname_or_birth, pms_config)

    log.warning("Bilinmeyen PMS vendor: %s, fail-closed", vendor)
    return PmsVerifyResult(
        verified=False,
        vendor=vendor,
        message=f"Desteklenmeyen PMS vendor: {vendor}",
    )
