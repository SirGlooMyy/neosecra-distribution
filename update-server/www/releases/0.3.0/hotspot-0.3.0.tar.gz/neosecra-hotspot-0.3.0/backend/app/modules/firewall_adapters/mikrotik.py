"""MikroTik RouterOS adapter — REST API / SSH.

Supports RouterOS REST API (v7+, /rest/) and legacy API (port 8728).
The REST API is preferred; SSH is used as fallback for older versions.
Operations use firewall address-lists for guest allowlisting.
"""
from __future__ import annotations

import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class MikroTikAdapter(FirewallAdapter):
    vendor = "mikrotik"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        token = config.api_token or ""
        username = config.api_username or "admin"
        rest_port = port if port else 443
        self._base_url = f"https://{host}:{rest_port}/rest"
        auth_str = f"{username}:{token}" if token else f"{username}:"
        import base64
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Basic {base64.b64encode(auth_str.encode()).decode()}",
        }

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> Any:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"MikroTik {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=True,
            radius_authentication=True,
            radius_accounting=True,
            radius_coa=True,
            disconnect_message=True,
            mac_auth_bypass=True,
            active_session_query=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            data = await self._request("GET", "system/identity")
            identity = ""
            version = ""
            if isinstance(data, list) and data:
                identity = data[0].get("name", "?")
            elif isinstance(data, dict):
                identity = data.get("name", "?")
            try:
                ver_data = await self._request("GET", "system/resource")
                if isinstance(ver_data, list) and ver_data:
                    version = ver_data[0].get("version", "?")
                elif isinstance(ver_data, dict):
                    version = ver_data.get("version", "?")
            except (AdapterError, httpx.HTTPError):
                version = "?"
            return AdapterResult(
                ok=True,
                message=f"connected: {identity} RouterOS {version}",
                data={"identity": identity, "version": version},
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        identity = "?"
        try:
            data = await self._request("GET", "system/identity")
            if isinstance(data, list) and data:
                identity = data[0].get("name", "?")
            elif isinstance(data, dict):
                identity = data.get("name", "?")
        except (AdapterError, httpx.HTTPError):
            pass
        resources = {}
        try:
            data = await self._request("GET", "system/resource")
            raw = data[0] if isinstance(data, list) else data
            resources = raw if isinstance(raw, dict) else {}
        except (AdapterError, httpx.HTTPError):
            pass
        return {
            "hostname": identity,
            "model": resources.get("board-name", ""),
            "serial_number": resources.get("serial-number", ""),
            "firmware_version": resources.get("version", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "interface")
        raw = data if isinstance(data, list) else data.get("data", [])
        results: list[dict[str, Any]] = []
        for iface in raw:
            results.append({
                "name": iface.get("name", ""),
                "type": iface.get("type", ""),
                "mac": iface.get("mac-address", ""),
                "status": "up" if iface.get("running") else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._request("GET", "ip/hotspot")
            raw = data if isinstance(data, list) else []
            profiles = []
            for hp in raw:
                profiles.append({
                    "name": hp.get("name", ""),
                    "address_pool": hp.get("address-pool", ""),
                    "enabled": hp.get("disabled") != "true",
                })
            return {"hotspot_profiles": profiles}
        except AdapterError:
            return {"hotspot_profiles": []}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "ip/hotspot/active")
        raw = data if isinstance(data, list) else []
        results: list[dict[str, Any]] = []
        for s in raw:
            results.append({
                "ip": s.get("address", ""),
                "user": s.get("user", ""),
                "mac": s.get("mac-address", ""),
                "uptime": s.get("uptime", ""),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "ip/arp")
        raw = data if isinstance(data, list) else []
        results: list[dict[str, Any]] = []
        for entry in raw:
            results.append({
                "ip": entry.get("address", ""),
                "mac": entry.get("mac-address", ""),
                "interface": entry.get("interface", ""),
                "status": "dynamic" if entry.get("dynamic") else "static",
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        address_list = self.config.extra.get("mikrotik_address_list", "hotspot_allowed")
        policy = self._guest_policy(session)
        payload = {
            "address": ip,
            "list": address_list,
            "comment": self._guest_comment(session),
        }
        try:
            await self._request("PUT", f"ip/firewall/address-list/{name}", json=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"entry": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            await self._request("DELETE", f"ip/firewall/address-list/{name}")
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "mikrotik", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("hostname")
        parsed["event_type"] = parsed.get("type") or parsed.get("topic")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src") or parsed.get("src-address")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst") or parsed.get("dst-address")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("src-port")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dst-port")
        parsed["action"] = parsed.get("action")
        return parsed
