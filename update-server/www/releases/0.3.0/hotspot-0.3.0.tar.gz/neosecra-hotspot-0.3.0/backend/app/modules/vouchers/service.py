"""Voucher batch generation, scoped admin CRUD and public redeem flow.

Admin operations are scope-filtered on the customer (-> partner) axis, exactly
like the portal module. The redeem path is invoked by the PUBLIC captive flow
(no admin JWT), so the (customer_id, location_id) site context is resolved
from the device the guest is behind and passed in explicitly — vouchers are
bound to a physical site to prevent cross-site replay (Mutlak Kural #1/#2).

Codes:
  * plaintext is shown ONLY once at generation (BatchCreateResult.codes);
  * at rest we keep an unsalted sha256 so redeem can do a lookup by code;
  * VoucherOut/list/get NEVER expose the code (Mutlak Kural #3 / Yasak).
"""
from __future__ import annotations

import hashlib
import logging
import secrets
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import false, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.vouchers.models import (
    STATUS_EXPIRED,
    STATUS_PENDING,
    STATUS_USED,
    Voucher,
    VoucherBatch,
)
from app.modules.vouchers.schemas import (
    BatchCreateResult,
    VoucherBatchCreate,
    VoucherBatchOut,
    VoucherBatchUpdate,
)

log = logging.getLogger(__name__)


# ---- code helpers ------------------------------------------------------
def _hash_code(code: str) -> str:
    """Unsalted sha256 hex — needed so redeem can look up a voucher by code.
    See model docstring: codes are high-entropy random tokens, so the lack of a
    salt is acceptable (Mutlak Kural #3 spirit — never plaintext at rest)."""
    return hashlib.sha256(code.encode()).hexdigest()


def _gen_code(prefix: str) -> str:
    """Random high-entropy voucher code: <prefix>-<token>. token_urlsafe(6)
    yields ~8 base64url chars; strip separators and uppercase for readability."""
    token = secrets.token_urlsafe(6).upper().replace("_", "").replace("-", "")
    return f"{prefix}-{token}"


# ---- scoped query (customer -> partner axis, mirrors portal) -----------
async def _scoped_query_async(db: AsyncSession, scope: ScopeContext):
    """Scope query that may need a DB lookup (location -> customer)."""
    q = select(VoucherBatch)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = q.join(Customer, VoucherBatch.customer_id == Customer.id)
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(VoucherBatch.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        loc = (
            await db.execute(select(Location).where(Location.id == scope.location_id))
        ).scalar_one_or_none()
        if not loc:
            return q.where(false()), False
        return q.where(
            (VoucherBatch.location_id == scope.location_id)
            | ((VoucherBatch.customer_id == loc.customer_id) & (VoucherBatch.location_id.is_(None)))
        ), True
    return q.where(false()), False


async def _resolve_customer_for_create(
    db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext
) -> Customer:
    cq = select(Customer)
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        cq = cq.where(Customer.id == customer_id, Customer.partner_id == scope.partner_id)
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        cq = cq.where(Customer.id == customer_id, Customer.id == scope.customer_id)
    elif scope.level == TenantLevel.GLOBAL:
        cq = cq.where(Customer.id == customer_id)
    else:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Voucher olusturma yetkiniz yok")
    customer = (await db.execute(cq)).scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu musteriye voucher ekleyemezsiniz")
    return customer


async def _validate_location_owns_customer(
    db: AsyncSession, customer_id: uuid.UUID, location_id: uuid.UUID | None
) -> None:
    if location_id is None:
        return
    loc = (
        await db.execute(select(Location).where(Location.id == location_id))
    ).scalar_one_or_none()
    if not loc or loc.customer_id != customer_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Lokasyon bu musteriye ait degil")


# ---- admin operations --------------------------------------------------
async def generate_batch(
    db: AsyncSession,
    body: VoucherBatchCreate,
    scope: ScopeContext,
    actor_id: uuid.UUID,
    request: Request | None = None,
) -> BatchCreateResult:
    await _resolve_customer_for_create(db, body.customer_id, scope)
    await _validate_location_owns_customer(db, body.customer_id, body.location_id)

    now = datetime.now(timezone.utc)
    if body.expires_at and body.expires_at < now:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Gecmis son kullanma tarihi",
        )

    batch = VoucherBatch(
        customer_id=body.customer_id,
        location_id=body.location_id,
        name=body.name,
        prefix=body.prefix,
        count=body.count,
        duration_minutes=body.duration_minutes,
        expires_at=body.expires_at,
        created_by=actor_id,
    )
    db.add(batch)
    await db.flush()

    # Generate `count` unique codes; dedupe against existing code_hash and
    # within this batch by regenerating on collision.
    codes: list[str] = []
    seen_hashes: set[str] = set()
    for _ in range(body.count):
        attempts = 0
        while True:
            attempts += 1
            code = _gen_code(body.prefix)
            h = _hash_code(code)
            if h in seen_hashes:
                continue
            existing = (
                await db.execute(select(Voucher.id).where(Voucher.code_hash == h).limit(1))
            ).scalar_one_or_none()
            if existing is not None:
                if attempts > 50:
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail="Voucher kod uretimi cakisti, tekrar deneyin",
                    )
                continue
            seen_hashes.add(h)
            codes.append(code)
            db.add(
                Voucher(
                    batch_id=batch.id,
                    code_hash=h,
                    code_prefix=code[:6],
                    status=STATUS_PENDING,
                    expires_at=body.expires_at or batch.expires_at,
                )
            )
            break

    await log_audit(
        db, "voucher.batch_created", "voucher_batch", str(batch.id), str(actor_id), request,
        details={"name": body.name, "count": body.count, "customer_id": str(body.customer_id)},
    )
    await db.commit()
    await db.refresh(batch)
    return BatchCreateResult(batch=VoucherBatchOut.model_validate(batch), codes=codes)


async def list_batches(db: AsyncSession, scope: ScopeContext) -> list[VoucherBatch]:
    q, _ = await _scoped_query_async(db, scope)
    result = await db.execute(q.order_by(VoucherBatch.created_at.desc()))
    return list(result.scalars().all())


async def get_batch(
    db: AsyncSession, batch_id: uuid.UUID, scope: ScopeContext
) -> VoucherBatch:
    q, allowed = await _scoped_query_async(db, scope)
    result = await db.execute(q.where(VoucherBatch.id == batch_id))
    batch = result.scalar_one_or_none()
    if not batch:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Voucher batch bulunamadi")
    if not allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu batcha erisim yetkiniz yok")
    return batch


async def list_vouchers(
    db: AsyncSession, batch_id: uuid.UUID, scope: ScopeContext
) -> list[Voucher]:
    # Ensure the batch is in scope (raises 404/403 for out-of-scope callers).
    await get_batch(db, batch_id, scope)
    result = await db.execute(
        select(Voucher).where(Voucher.batch_id == batch_id).order_by(Voucher.created_at)
    )
    return list(result.scalars().all())


async def update_batch(
    db: AsyncSession,
    batch_id: uuid.UUID,
    body: VoucherBatchUpdate,
    scope: ScopeContext,
    actor_id: uuid.UUID,
    request: Request | None = None,
) -> VoucherBatch:
    batch = await get_batch(db, batch_id, scope)
    data = body.model_dump(exclude_unset=True)
    if data.get("expires_at") is not None and data["expires_at"] < datetime.now(timezone.utc):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Gecmis son kullanma tarihi",
        )
    for k, v in data.items():
        setattr(batch, k, v)
    await log_audit(
        db, "voucher.batch_updated", "voucher_batch", str(batch_id), str(actor_id), request,
        details=data,
    )
    await db.commit()
    await db.refresh(batch)
    return batch


async def deactivate_batch(
    db: AsyncSession,
    batch_id: uuid.UUID,
    scope: ScopeContext,
    actor_id: uuid.UUID,
    request: Request | None = None,
) -> None:
    batch = await get_batch(db, batch_id, scope)
    batch.is_active = False
    await log_audit(
        db, "voucher.batch_deactivated", "voucher_batch", str(batch_id), str(actor_id), request,
    )
    await db.commit()


# ---- public redeem flow (captive portal) -------------------------------
async def redeem(
    db: AsyncSession,
    *,
    code: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
) -> Voucher:
    """Public-flow redeem. Bind to the guest's site context; fail-closed for
    any mismatch. Session linkage is set later by the portal flow via a
    separate update."""
    code = code.strip().upper()
    h = _hash_code(code)
    now = datetime.now(timezone.utc)

    q = (
        select(Voucher)
        .join(VoucherBatch, Voucher.batch_id == VoucherBatch.id)
        .where(
            Voucher.code_hash == h,
            VoucherBatch.customer_id == customer_id,
        )
    )
    if location_id is not None:
        q = q.where(
            (VoucherBatch.location_id == location_id) | (VoucherBatch.location_id.is_(None))
        )
    # Use SELECT ... FOR UPDATE to prevent concurrent redemption (race condition)
    voucher = (
        await db.execute(q.with_for_update())
    ).scalar_one_or_none()
    if not voucher:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Voucher gecersiz.")

    if voucher.status == STATUS_USED:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Voucher daha once kullanildi.")

    if voucher.expires_at and voucher.expires_at < now:
        voucher.status = STATUS_EXPIRED
        await db.commit()
        raise HTTPException(status_code=status.HTTP_410_GONE, detail="Voucherun suresi dolmus.")

    voucher.status = STATUS_USED
    voucher.used_at = now
    await db.flush()
    await log_audit(
        db, "voucher.redeemed", "voucher", str(voucher.id), None, None,
        details={"code_prefix": code[:6]},
    )
    await db.commit()
    await db.refresh(voucher)
    return voucher