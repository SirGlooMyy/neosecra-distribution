"""Partner CRUD. Partner management = super_admin; partner_admin reads own."""
import uuid

from fastapi import HTTPException, Request, status
from sqlalchemy import false, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.partners.models import Partner
from app.modules.partners.schemas import PartnerCreate, PartnerUpdate


def _scoped_query(scope: ScopeContext):
    q = select(Partner)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        return q.where(Partner.id == scope.partner_id), True
    return q.where(false()), False  # customer/location/support -> deny


async def list_partners(db: AsyncSession, scope: ScopeContext) -> list[Partner]:
    q, _ = _scoped_query(scope)
    result = await db.execute(q.order_by(Partner.created_at.desc()))
    return list(result.scalars().all())


async def get_partner(db: AsyncSession, partner_id: uuid.UUID, scope: ScopeContext) -> Partner:
    q, allowed = _scoped_query(scope)
    result = await db.execute(q.where(Partner.id == partner_id))
    partner = result.scalar_one_or_none()
    if not partner:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Partner bulunamadi")
    if not allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu partner'a erisim yetkiniz yok")
    return partner


async def create_partner(
    db: AsyncSession, body: PartnerCreate, actor_id: uuid.UUID, request: Request | None = None
) -> Partner:
    partner = Partner(
        tenant_id=body.tenant_id,
        name=body.name,
        reseller_code=body.reseller_code,
        contact_email=body.contact_email,
        contact_phone=body.contact_phone,
    )
    db.add(partner)
    await log_audit(db, "partner.created", "partner", str(partner.id), str(actor_id), request,
                    details={"name": body.name, "tenant_id": str(body.tenant_id)})
    await db.commit()
    await db.refresh(partner)
    return partner


async def update_partner(
    db: AsyncSession, partner_id: uuid.UUID, body: PartnerUpdate,
    actor_id: uuid.UUID, request: Request | None = None,
) -> Partner:
    result = await db.execute(select(Partner).where(Partner.id == partner_id))
    partner = result.scalar_one_or_none()
    if not partner:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Partner bulunamadi")
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(partner, k, v)
    await log_audit(db, "partner.updated", "partner", str(partner_id), str(actor_id), request, details=data)
    await db.commit()
    await db.refresh(partner)
    return partner


async def deactivate_partner(
    db: AsyncSession, partner_id: uuid.UUID, actor_id: uuid.UUID, request: Request | None = None
) -> None:
    result = await db.execute(select(Partner).where(Partner.id == partner_id))
    partner = result.scalar_one_or_none()
    if not partner:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Partner bulunamadi")
    partner.is_active = False
    await log_audit(db, "partner.deactivated", "partner", str(partner_id), str(actor_id), request)
    await db.commit()
