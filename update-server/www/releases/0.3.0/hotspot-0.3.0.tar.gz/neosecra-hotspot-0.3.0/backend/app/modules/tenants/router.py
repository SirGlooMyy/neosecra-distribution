"""Tenant HTTP endpoints. Only super_admin may create/update; scoped users
can read their own tenant."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.tenants import service
from app.modules.tenants.schemas import TenantCreate, TenantOut, TenantUpdate

router = APIRouter()


def _require_super_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "super_admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Super admin gerekiyor")
    return user


@router.get("", response_model=list[TenantOut], summary="List all tenants accessible to the current user", description="Returns a list of tenants scoped to the authenticated user's permissions. Super admins see all tenants; scoped users see only their own tenant. Requires a valid access token.")
async def list_tenants(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.list_tenants(db, scope_for(user))


@router.get("/{tenant_id}", response_model=TenantOut, summary="Retrieve a single tenant by its unique identifier", description="Fetches detailed information for the specified tenant. Access is scoped to the authenticated user's permissions; non-super-admins can only access their own tenant. Requires a valid access token.")
async def get_tenant(
    tenant_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_tenant(db, tenant_id, scope_for(user))


@router.post("", response_model=TenantOut, status_code=status.HTTP_201_CREATED, summary="Create a new tenant organization", description="Creates a new tenant with the provided configuration. This endpoint is restricted to super_admin users only. Returns the created tenant details including its unique identifier.")
async def create_tenant(
    body: TenantCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_require_super_admin),
):
    return await service.create_tenant(db, body, user.id, request)


@router.put("/{tenant_id}", response_model=TenantOut, summary="Update an existing tenant configuration", description="Updates the specified tenant's settings such as name, status, or branding. Restricted to super_admin users only. Returns the updated tenant object.")
async def update_tenant(
    tenant_id: uuid.UUID,
    body: TenantUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_require_super_admin),
):
    return await service.update_tenant(db, tenant_id, body, scope_for(user), user.id, request)


@router.delete("/{tenant_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Deactivate and soft-delete a tenant", description="Deactivates the specified tenant, making it inaccessible. This is a soft delete that preserves data for auditing purposes. Restricted to super_admin users only.")
async def delete_tenant(
    tenant_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_require_super_admin),
):
    await service.deactivate_tenant(db, tenant_id, scope_for(user), user.id, request)
