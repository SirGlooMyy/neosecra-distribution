"""Auth HTTP endpoints."""
from fastapi import APIRouter, Depends, Request
from jose import JWTError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import decode_token
from app.modules.auth.deps import get_current_user, oauth2_scheme
from app.modules.auth.models import User
from app.modules.auth.schemas import (
    LoginRequest,
    LoginResponse,
    LogoutRequest,
    MfaVerifyIn,
    RefreshRequest,
    TokenResponse,
    UserMeUpdate,
    UserOut,
)
from app.modules.auth.service import authenticate, logout, refresh_tokens, update_current_user_profile, verify_mfa_and_login

router = APIRouter()


@router.post("/login", response_model=LoginResponse, summary="Authenticate user credentials and return access tokens", description="Validates the provided username and password against stored credentials. Returns access and refresh tokens upon successful authentication. Supports optional MFA challenge if enabled for the user.")
async def login(body: LoginRequest, request: Request, db: AsyncSession = Depends(get_db)):
    return await authenticate(db, body, request)


@router.post("/mfa/complete", response_model=TokenResponse, summary="Complete MFA verification and finalize login", description="Verifies the MFA code provided by the user during the login flow. Returns the final access and refresh tokens once MFA validation succeeds. Should be called after the initial login endpoint returns an MFA challenge.")
async def mfa_complete(
    body: MfaVerifyIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    return await verify_mfa_and_login(db, body, request)


@router.get("/me", response_model=UserOut, summary="Retrieve the currently authenticated user profile", description="Returns the profile information of the authenticated user making the request. Requires a valid access token in the Authorization header. Useful for frontend applications to verify session state and display user details.")
async def me(user: User = Depends(get_current_user)):
    return user


@router.patch("/me", response_model=UserOut, summary="Update the current user profile fields", description="Partially updates the authenticated user's profile such as email or full name. Only the provided fields are modified; omitted fields remain unchanged. Requires a valid access token.")
async def update_me(
    body: UserMeUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await update_current_user_profile(
        db,
        user,
        email=body.email,
        full_name=body.full_name,
        request=request,
    )


@router.post("/refresh", response_model=TokenResponse, summary="Refresh expired access token using refresh token", description="Accepts a valid refresh token and returns a new access and refresh token pair. Enables long-lived sessions without requiring the user to re-authenticate. The refresh token must not be expired or revoked.")
async def refresh(body: RefreshRequest, db: AsyncSession = Depends(get_db)):
    return await refresh_tokens(db, body.refresh_token)


@router.post("/logout", status_code=204, summary="Invalidate access and refresh tokens to end session", description="Blacklists the current access token and optionally a provided refresh token. Once invalidated, these tokens cannot be used for subsequent requests. Returns 204 No Content on success.")
async def logout_endpoint(
    token: str = Depends(oauth2_scheme),
    body: LogoutRequest | None = None,
):
    try:
        payload = decode_token(token)
    except JWTError:
        return None
    if payload.get("type") == "access":
        jti = payload.get("jti")
        exp = payload.get("exp")
        if jti is not None and exp is not None:
            await logout(jti, exp)
    if body and body.refresh_token:
        try:
            rp = decode_token(body.refresh_token)
        except JWTError:
            rp = None
        if rp and rp.get("type") == "refresh":
            rjti = rp.get("jti")
            rexp = rp.get("exp")
            if rjti is not None and rexp is not None:
                await logout(rjti, rexp)


@router.get("/permissions", response_model=list[str], summary="List all permissions assigned to the current user role", description="Returns the complete set of permission strings associated with the authenticated user's role. Useful for frontend applications to conditionally render UI elements based on user capabilities. Requires a valid access token.")
async def get_permissions(user: User = Depends(get_current_user)):
    from app.core.rbac import ROLE_PERMISSIONS
    perms = ROLE_PERMISSIONS.get(user.role, set())
    return list(perms)
