"""PMS domain models."""
import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship

from app.core.database import Base


class PmsConfig(Base):
    __tablename__ = "pms_configs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    customer_id = Column(UUID(as_uuid=True), ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, unique=True)
    pms_type = Column(String(50), nullable=False, default="mock")
    host = Column(String(255), nullable=True)
    port = Column(Integer, nullable=True)
    api_key_enc = Column(Text, nullable=True, comment="encrypted via app.core.crypto.encrypt")
    username = Column(String(255), nullable=True)
    password_enc = Column(Text, nullable=True)
    db_host = Column(String(255), nullable=True)
    db_port = Column(Integer, nullable=True)
    db_name = Column(String(255), nullable=True)
    db_user = Column(String(255), nullable=True)
    db_password_enc = Column(Text, nullable=True)
    extra = Column(JSONB, nullable=True, default=dict)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    customer = relationship("Customer", backref="pms_configs")


class CustomPmsSource(Base):
    __tablename__ = "custom_pms_sources"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    customer_id = Column(UUID(as_uuid=True), ForeignKey("customers.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(255), nullable=False)
    source_type = Column(String(50), nullable=False, comment="json_api|excel|csv|database|sql_query")
    connection_config_enc = Column(Text, nullable=True, comment="JSONB encrypted via app.core.crypto.encrypt")
    field_mapping = Column(JSONB, nullable=True, default=dict)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    customer = relationship("Customer", backref="custom_pms_sources")
