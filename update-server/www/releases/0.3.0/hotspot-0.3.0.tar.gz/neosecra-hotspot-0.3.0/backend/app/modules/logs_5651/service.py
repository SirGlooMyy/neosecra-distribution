"""5651 archive service — append-only build + hash-chain seal + verification.

This is the legally sensitive core (Mutlak Kural #4 — 5651 records are
immutable; append-only event approach; the archive hash is never updated).

Flow:
  build_session_archive gathers the GuestSessions for a (customer, period),
  serializes them deterministically (sorted, fixed key order, JSONL), gzips the
  payload (deterministic mtime=0 so the same input -> the same artifact -> the
  same content_hash), uploads it (archive_service) and seals an ArchiveRecord:

      content_hash = sha256(payload_bytes)
      prev_hash    = last.curr_hash in the chain (GENESIS_HASH for the first)
      curr_hash    = sha256(prev_hash | content_hash | period_key | record_type)

The chain is per (customer, record_type). verify_chain re-walks it: it recomputes
each curr_hash from the STORED (prev_hash, content_hash, period_key, record_type)
and checks the prev_hash linkage. A mismatch proves a row was retroactively
edited/deleted/reordered — tamper-evidence without trusting the object store.

Rows are never UPDATEd or DELETEd here (and the table has no soft-delete mixin).
"""
from __future__ import annotations

import gzip
import hashlib
import json
import logging
import uuid
from datetime import datetime

from fastapi import HTTPException, Request, status
from sqlalchemy import false, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.core.config import settings
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.logs_5651 import archive_service
from app.modules.logs_5651.models import (
    GENESIS_HASH,
    RECORD_SESSION_ARCHIVE,
    ArchiveRecord,
)
from app.modules.logs_5651.schemas import ArchiveVerifyResult
from app.modules.sessions.models import GuestSession

log = logging.getLogger(__name__)


# ---- hash chain primitives --------------------------------------------------
def _chain_hash(
    prev_hash: str, content_hash: str, period_key: str, record_type: str
) -> str:
    h = hashlib.sha256()
    for part in (prev_hash, content_hash, period_key, record_type):
        h.update(part.encode("utf-8"))
        h.update(b"|")
    return h.hexdigest()


def _period_key(period_start: datetime, period_end: datetime) -> str:
    ps = period_start.astimezone().isoformat() if period_start.tzinfo else period_start.isoformat()
    pe = period_end.astimezone().isoformat() if period_end.tzinfo else period_end.isoformat()
    return f"{ps}/{pe}"


async def _last_in_chain(
    db: AsyncSession, customer_id: uuid.UUID, record_type: str
) -> ArchiveRecord | None:
    res = await db.execute(
        select(ArchiveRecord)
        .where(
            ArchiveRecord.customer_id == customer_id,
            ArchiveRecord.record_type == record_type,
        )
        .order_by(ArchiveRecord.chain_seq.desc())
        .limit(1)
    )
    return res.scalar_one_or_none()


# ---- canonical serialization of a period's sessions ------------------------
def _serialize_sessions(sessions: list[GuestSession]) -> bytes:
    """Deterministic JSONL of the 5651-relevant session fields, gzipped.

    Identity (phone) + IP/MAC are exactly what 5651/YYİH retention needs for
    IP<->kimlik correlation. Sorted by (started_at, id) and emitted with
    sort_keys so the same input always yields the same artifact/content_hash."""
    rows = []
    for s in sorted(sessions, key=lambda x: (x.started_at, str(x.id))):
        rows.append(
            {
                "session_id": str(s.id),
                "customer_id": str(s.customer_id),
                "location_id": str(s.location_id) if s.location_id else None,
                "device_id": str(s.device_id) if s.device_id else None,
                "mac": s.mac,
                "ip": s.ip,
                "nas_ip": s.nas_ip,
                "ssid": s.ssid,
                "phone": s.phone,
                "auth_method": s.auth_method,
                "identity_verification_id": str(s.identity_verification_id)
                if s.identity_verification_id
                else None,
                "voucher_id": str(s.voucher_id) if s.voucher_id else None,
                "status": s.status,
                "started_at": s.started_at.isoformat() if s.started_at else None,
                "ended_at": s.ended_at.isoformat() if s.ended_at else None,
                "expires_at": s.expires_at.isoformat() if s.expires_at else None,
            }
        )
    payload = ("\n".join(json.dumps(r, sort_keys=True) for r in rows)).encode("utf-8")
    if not rows:
        payload = b""  # empty-period archive still seals a (content_hash) record
    return gzip.compress(payload, mtime=0)


# ---- append-only build ------------------------------------------------------
async def build_session_archive(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    period_start: datetime,
    period_end: datetime,
    request: Request | None = None,
) -> ArchiveRecord:
    """Build + seal one archive record for a customer/period. APPEND-ONLY.

    Gathers sessions whose started_at falls in [period_start, period_end).
    Idempotent at the data level (deterministic payload) but ALWAYS appends a
    new chain record — re-running for the same period produces a new sealed
    record (chain_seq + 1) rather than mutating an existing one (Kural #4)."""
    if period_end <= period_start:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="period_end period_start'tan sonra olmali",
        )

    res = await db.execute(
        select(GuestSession).where(
            GuestSession.customer_id == customer_id,
            GuestSession.started_at >= period_start,
            GuestSession.started_at < period_end,
        )
    )
    sessions = list(res.scalars().all())

    payload = _serialize_sessions(sessions)
    content_hash = archive_service.content_hash(payload)
    content_ref = archive_service.upload(
        payload, customer_id=customer_id, period_start=period_start
    )

    last = await _last_in_chain(db, customer_id, RECORD_SESSION_ARCHIVE)
    prev_hash = last.curr_hash if last else GENESIS_HASH
    chain_seq = (last.chain_seq + 1) if last else 1
    pkey = _period_key(period_start, period_end)
    curr_hash = _chain_hash(prev_hash, content_hash, pkey, RECORD_SESSION_ARCHIVE)

    record = ArchiveRecord(
        customer_id=customer_id,
        period_start=period_start,
        period_end=period_end,
        record_type=RECORD_SESSION_ARCHIVE,
        chain_seq=chain_seq,
        item_count=len(sessions),
        content_hash=content_hash,
        content_ref=content_ref,
        content_size=len(payload),
        prev_hash=prev_hash,
        curr_hash=curr_hash,
        meta={"gzip": True, "format": "jsonl"},
    )
    db.add(record)
    await db.flush()
    await log_audit(
        db,
        "5651.archive_created",
        "archive_record_5651",
        str(record.id),
        None,
        request,
        details={
            "customer_id": str(customer_id),
            "record_type": RECORD_SESSION_ARCHIVE,
            "chain_seq": chain_seq,
            "item_count": len(sessions),
            "curr_hash": curr_hash,
        },
    )
    await db.commit()
    await db.refresh(record)

    # Trigger digital signing in background if configured
    if settings.TUBITAK_KAMUSM_ENABLED:
        try:
            from app.modules.logs_5651.signing_service import sign_archive_record

            await sign_archive_record(db, record)
            await db.commit()
            await db.refresh(record)
            log.info(
                "Arsiv seq=%d imzalandi (customer=%s)",
                chain_seq, customer_id,
            )
        except Exception as exc:
            log.warning(
                "Arsiv seq=%d imzalanamadi (devam ediliyor): %s",
                chain_seq, exc,
            )

    return record


async def build_raw_log_archive(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    record_type: str,
    period_start: datetime,
    period_end: datetime,
    records: list[dict] | None = None,
    request: Request | None = None,
) -> ArchiveRecord:
    """Build + seal an archive record for raw traffic/syslog/radius logs into the hash chain. APPEND-ONLY."""
    if period_end <= period_start:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="period_end period_start'tan sonra olmali",
        )

    log_records = records or []
    if not log_records:
        from app.modules.syslog.models import FirewallLog
        res = await db.execute(
            select(FirewallLog).where(
                or_(FirewallLog.customer_id == customer_id, FirewallLog.tenant_id == customer_id),
                FirewallLog.event_time >= period_start,
                FirewallLog.event_time < period_end,
            )
        )
        fw_rows = res.scalars().all()
        log_records = [
            {
                "id": str(r.id),
                "customer_id": str(r.customer_id or r.tenant_id),
                "event_time": r.event_time.isoformat() if r.event_time else None,
                "vendor": r.vendor,
                "log_type": r.log_type,
                "severity": r.severity,
                "action": r.action,
                "src_ip": r.src_ip,
                "dst_ip": r.dst_ip,
                "src_port": r.src_port,
                "dst_port": r.dst_port,
                "user": r.user,
                "raw_syslog": r.raw_syslog,
            }
            for r in fw_rows
        ]

    payload = archive_service.serialize_raw_logs(log_records)
    content_hash = archive_service.content_hash(payload)
    content_ref = archive_service.upload(
        payload, customer_id=customer_id, period_start=period_start
    )

    searchable = archive_service.extract_searchable_fields(log_records)

    last = await _last_in_chain(db, customer_id, record_type)
    prev_hash = last.curr_hash if last else GENESIS_HASH
    chain_seq = (last.chain_seq + 1) if last else 1
    pkey = _period_key(period_start, period_end)
    curr_hash = _chain_hash(prev_hash, content_hash, pkey, record_type)

    record = ArchiveRecord(
        customer_id=customer_id,
        period_start=period_start,
        period_end=period_end,
        record_type=record_type,
        chain_seq=chain_seq,
        item_count=len(log_records),
        content_hash=content_hash,
        content_ref=content_ref,
        content_size=len(payload),
        prev_hash=prev_hash,
        curr_hash=curr_hash,
        meta={"zstd": True, "format": "jsonl", "record_type": record_type},
    )
    db.add(record)

    from app.modules.logs_5651.models import ArchiveIndex
    archive_index = ArchiveIndex(
        customer_id=customer_id,
        period_start=period_start,
        period_end=period_end,
        record_count=len(log_records),
        file_ref=content_ref,
        file_size=len(payload),
        compression="zstd",
        content_hash=content_hash,
        prev_hash=prev_hash,
        searchable_fields=searchable,
    )
    db.add(archive_index)

    await db.flush()
    await log_audit(
        db,
        "5651.archive_created",
        "archive_record_5651",
        str(record.id),
        None,
        request,
        details={
            "customer_id": str(customer_id),
            "record_type": record_type,
            "chain_seq": chain_seq,
            "item_count": len(log_records),
            "curr_hash": curr_hash,
        },
    )
    await db.commit()
    await db.refresh(record)

    return record


# ---- scoped admin views -----------------------------------------------------
async def _scoped_query(db: AsyncSession, scope: ScopeContext):
    q = select(ArchiveRecord)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = q.join(Customer, ArchiveRecord.customer_id == Customer.id)
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(ArchiveRecord.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        loc = (
            await db.execute(select(Location).where(Location.id == scope.location_id))
        ).scalar_one_or_none()
        if not loc:
            return q.where(false()), False
        return q.where(ArchiveRecord.customer_id == loc.customer_id), True
    return q.where(false()), False


async def list_archives(
    db: AsyncSession, scope: ScopeContext, record_type: str | None = None
) -> list[dict]:
    q, allowed = await _scoped_query(db, scope)
    if not allowed:
        return []
    if record_type:
        q = q.where(ArchiveRecord.record_type == record_type)
    
    q = q.add_columns(Customer.name.label("customer_name"))
    if scope.level != TenantLevel.PARTNER:
        q = q.join(Customer, ArchiveRecord.customer_id == Customer.id)

    res = await db.execute(q.order_by(ArchiveRecord.created_at.desc()))
    out = []
    for row in res.all():
        rec = row[0]
        name = row[1]
        out.append({
            "id": rec.id,
            "customer_id": rec.customer_id,
            "customer_name": name,
            "location_id": rec.location_id,
            "period_start": rec.period_start,
            "period_end": rec.period_end,
            "record_type": rec.record_type,
            "chain_seq": rec.chain_seq,
            "item_count": rec.item_count,
            "content_hash": rec.content_hash,
            "content_ref": rec.content_ref,
            "content_size": rec.content_size,
            "prev_hash": rec.prev_hash,
            "curr_hash": rec.curr_hash,
            "created_at": rec.created_at,
            "signature_value": rec.signature_value,
            "signature_time": rec.signature_time,
            "certificate_serial": rec.certificate_serial,
            "sign_method": rec.sign_method,
            "signature_origin": (rec.meta or {}).get("signature_origin"),
        })
    return out


async def get_archive(
    db: AsyncSession, record_id: uuid.UUID, scope: ScopeContext
) -> dict:
    q, allowed = await _scoped_query(db, scope)
    q = q.where(ArchiveRecord.id == record_id).add_columns(Customer.name.label("customer_name"))
    if scope.level != TenantLevel.PARTNER:
        q = q.join(Customer, ArchiveRecord.customer_id == Customer.id)
    res = await db.execute(q)
    row = res.one_or_none()
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Arsiv kaydi bulunamadi"
        )
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu arsive erisim yetkiniz yok",
        )
    rec = row[0]
    name = row[1]
    return {
        "id": rec.id,
        "customer_id": rec.customer_id,
        "customer_name": name,
        "location_id": rec.location_id,
        "period_start": rec.period_start,
        "period_end": rec.period_end,
        "record_type": rec.record_type,
        "chain_seq": rec.chain_seq,
        "item_count": rec.item_count,
        "content_hash": rec.content_hash,
        "content_ref": rec.content_ref,
        "content_size": rec.content_size,
        "prev_hash": rec.prev_hash,
        "curr_hash": rec.curr_hash,
        "created_at": rec.created_at,
        "signature_value": rec.signature_value,
        "signature_time": rec.signature_time,
        "certificate_serial": rec.certificate_serial,
        "sign_method": rec.sign_method,
        "signature_origin": (rec.meta or {}).get("signature_origin"),
    }


# ---- chain verification (tamper-evidence) -----------------------------------
async def verify_chain(
    db: AsyncSession,
    *,
    customer_id: uuid.UUID,
    record_type: str = RECORD_SESSION_ARCHIVE,
) -> ArchiveVerifyResult:
    """Re-walk the chain for (customer, record_type). Detects any row whose
    stored curr_hash does not match the recomputed value, or whose prev_hash
    linkage is broken. No object-store fetch — this validates the ledger."""
    res = await db.execute(
        select(ArchiveRecord)
        .where(
            ArchiveRecord.customer_id == customer_id,
            ArchiveRecord.record_type == record_type,
        )
        .order_by(ArchiveRecord.chain_seq.asc())
    )
    records = list(res.scalars().all())
    if not records:
        return ArchiveVerifyResult(
            customer_id=customer_id,
            record_type=record_type,
            ok=True,
            checked=0,
            message="Zincir bos (kayit yok).",
        )

    expected_prev = GENESIS_HASH
    for rec in records:
        if rec.prev_hash != expected_prev:
            return ArchiveVerifyResult(
                customer_id=customer_id,
                record_type=record_type,
                ok=False,
                checked=rec.chain_seq,
                broken_seq=rec.chain_seq,
                broken_id=rec.id,
                message=f"prev_hash kopuklugu seq={rec.chain_seq} (ekleme/silme sansi)",
            )
        recomputed = _chain_hash(
            rec.prev_hash, rec.content_hash, _period_key(rec.period_start, rec.period_end), rec.record_type
        )
        if recomputed != rec.curr_hash:
            return ArchiveVerifyResult(
                customer_id=customer_id,
                record_type=record_type,
                ok=False,
                checked=rec.chain_seq,
                broken_seq=rec.chain_seq,
                broken_id=rec.id,
                message=f"curr_hash uyusmazligi seq={rec.chain_seq} (degistirilmis satir)",
            )
        expected_prev = rec.curr_hash

    return ArchiveVerifyResult(
        customer_id=customer_id,
        record_type=record_type,
        ok=True,
        checked=len(records),
        message=f"Zincir saglam ({len(records)} kayit dogrulandi).",
    )
