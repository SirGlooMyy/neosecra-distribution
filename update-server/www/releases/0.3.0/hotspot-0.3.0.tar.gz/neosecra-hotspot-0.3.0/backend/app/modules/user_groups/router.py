import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import TenantLevel, scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.user_groups import service
from app.modules.user_groups.schemas import (
    UserGroupCreate,
    UserGroupOut,
    UserGroupPolicyPreviewOut,
    UserGroupUpdate,
)

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


async def _authorize_customer_access(db: AsyncSession, scope, customer_id: uuid.UUID) -> None:
    if scope.level == TenantLevel.GLOBAL:
        return
    if scope.level == TenantLevel.PARTNER:
        cust = await db.get(Customer, customer_id)
        if not cust or str(cust.partner_id) != str(scope.partner_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Bu musteri sizin kapsaminizda degil",
            )
        return
    if scope.level == TenantLevel.CUSTOMER:
        if str(scope.customer_id) != str(customer_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Baska musteri politikasini goruntuleyemezsiniz",
            )
        return
    if scope.level == TenantLevel.LOCATION:
        if not scope.location_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Lokasyon kapsami bulunamadi",
            )
        location = await db.get(Location, scope.location_id)
        if not location or str(location.customer_id) != str(customer_id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Bu musteri sizin lokasyon kapsaminizda degil",
            )
        return
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Erisim yetkiniz yok")


@router.get("/policy-preview", response_model=UserGroupPolicyPreviewOut, summary="Preview captive portal policy for a customer", description="Returns a preview of the combined captive portal policy for a customer and optionally a specific location. Shows effective bandwidth, session limits, and access rules. Requires the customer.read permission.")
async def preview_policy(
    customer_id: uuid.UUID | None = None,
    location_id: uuid.UUID | None = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.read")
    scope = scope_for(user)
    if customer_id is None:
        customer_id = scope.customer_id or await resolve_installation_customer(db)
    await _authorize_customer_access(db, scope, customer_id)
    return await service.preview_captive_policy(db, customer_id, location_id)


@router.get("/groups", response_model=list[UserGroupOut], summary="List all user groups accessible to the current user", description="Returns a list of user groups scoped to the authenticated user's tenant. Each group defines bandwidth limits, session duration, and access policies. Requires a valid access token.")
async def list_groups(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    scope = scope_for(user)
    if scope.customer_id is None and scope.level == TenantLevel.GLOBAL:
        scope.customer_id = await resolve_installation_customer(db)
    return await service.list_groups(db, scope)


@router.post("/groups", response_model=UserGroupOut, status_code=status.HTTP_201_CREATED, summary="Create a new user group with access policies", description="Creates a new user group defining bandwidth limits, session duration, and captive portal policy. The group can be assigned to guests for differentiated access. Requires the customer.write permission.")
async def create_group(
    body: UserGroupCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    scope = scope_for(user)
    if body.customer_id is None:
        body.customer_id = scope.customer_id or await resolve_installation_customer(db)
    return await service.create_group(db, body, scope, user, request)


@router.get("/groups/{group_id}", response_model=UserGroupOut, summary="Retrieve a single user group by ID", description="Fetches the details of a specific user group including its name, bandwidth limits, session policies, and assigned locations. Access is scoped to the user's tenant.")
async def get_group(
    group_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    scope = scope_for(user)
    if scope.customer_id is None and scope.level == TenantLevel.GLOBAL:
        scope.customer_id = await resolve_installation_customer(db)
    return await service.get_group(db, group_id, scope)


@router.put("/groups/{group_id}", response_model=UserGroupOut, summary="Update a user group configuration", description="Updates the specified user group's policies including bandwidth, session duration, and location assignments. Only provided fields are modified. Requires the customer.write permission.")
async def update_group(
    group_id: uuid.UUID,
    body: UserGroupUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    scope = scope_for(user)
    if scope.customer_id is None and scope.level == TenantLevel.GLOBAL:
        scope.customer_id = await resolve_installation_customer(db)
    return await service.update_group(db, group_id, body, scope, user, request)


@router.delete("/groups/{group_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete a user group", description="Permanently removes the specified user group. Guests currently assigned to this group will fall back to the default policy. Requires the customer.write permission.")
async def delete_group(
    group_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customer.write")
    scope = scope_for(user)
    if scope.customer_id is None and scope.level == TenantLevel.GLOBAL:
        scope.customer_id = await resolve_installation_customer(db)
    await service.delete_group(db, group_id, scope, user, request)
