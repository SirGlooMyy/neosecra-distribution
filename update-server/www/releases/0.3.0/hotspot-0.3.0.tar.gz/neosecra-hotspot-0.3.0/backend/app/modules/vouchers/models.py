"""Voucher = a one-time redeem code granting a timed guest session.

A VoucherBatch groups N codes generated for a customer/optional location.
Codes are random high-entropy tokens; only an unsalted sha256 of the code is
stored so they can be looked up by code at redeem (Mutlak Kural #3 spirit —
never store secrets plaintext at rest). The plaintext code is shown to the
admin exactly ONCE at generation time and never returned again.

Scope binding: every batch is tied to a customer (+ optional location) and
the public redeem flow is bound to the guest's site context, preventing
cross-site replay (Mutlak Kural #1/#2 — tenant isolation extends to the
guest auth path).
"""
import uuid
from datetime import datetime

from sqlalchemy import DateTime, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk

STATUS_PENDING = "pending"
STATUS_USED = "used"
STATUS_EXPIRED = "expired"
STATUSES = (STATUS_PENDING, STATUS_USED, STATUS_EXPIRED)


class VoucherBatch(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    """Batch of one-time voucher codes for a customer/location. Codes are random
    high-entropy tokens; stored as unsalted sha256 so they can be looked up by
    code at redeem (Mutlak Kural #3 spirit — never plaintext at rest)."""

    __tablename__ = "voucher_batches"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    prefix: Mapped[str] = mapped_column(String(16), default="V", nullable=False)
    count: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    # Guest session duration granted on redeem (minutes).
    duration_minutes: Mapped[int | None] = mapped_column(nullable=True)
    # Batch-wide expiry.
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)


class Voucher(Base, UUIDPK, TimestampMixin):
    """Single voucher. The plaintext code is shown ONLY once at generation time
    and is never stored/returned again."""

    __tablename__ = "vouchers"

    batch_id: Mapped[uuid.UUID] = fk("voucher_batches", ondelete="CASCADE")
    # sha256(code) hex — unsalted so redeem can do a lookup by code.
    code_hash: Mapped[str] = mapped_column(String(128), nullable=False, unique=True, index=True)
    # Non-secret first chars for support search.
    code_prefix: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(20), default=STATUS_PENDING, nullable=False, index=True)
    used_by_session_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    # Masked optional for audit.
    used_phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    # Inherits batch expiry if set (no own column-level override at MVP).
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)