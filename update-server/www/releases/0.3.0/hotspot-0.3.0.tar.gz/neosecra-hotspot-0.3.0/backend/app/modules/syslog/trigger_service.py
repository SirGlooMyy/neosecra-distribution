"""Syslog Trigger/Alert engine — evaluate, fire, acknowledge.
"""
from __future__ import annotations

import logging
import re
import uuid
from datetime import datetime, timezone

import httpx
from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.syslog.models import SyslogRecord, SyslogTrigger, TriggerEvent

log = logging.getLogger(__name__)

MATCH_TYPE_KEYWORD = "keyword"
MATCH_TYPE_REGEX = "regex"
MATCH_TYPE_SEVERITY = "severity"
MATCH_TYPE_VENDOR = "vendor"
MATCH_TYPES = (MATCH_TYPE_KEYWORD, MATCH_TYPE_REGEX, MATCH_TYPE_SEVERITY, MATCH_TYPE_VENDOR)

CHANNEL_EMAIL = "email"
CHANNEL_SMS = "sms"
CHANNEL_WEBHOOK = "webhook"
CHANNELS = (CHANNEL_EMAIL, CHANNEL_SMS, CHANNEL_WEBHOOK)


async def create_trigger(db: AsyncSession, data: dict) -> SyslogTrigger:
    if data.get("match_type") not in MATCH_TYPES:
        raise HTTPException(status_code=400, detail=f"match_type {data['match_type']} gecersiz. Secenekler: {', '.join(MATCH_TYPES)}")
    if data.get("channel") not in CHANNELS:
        raise HTTPException(status_code=400, detail=f"channel {data['channel']} gecersiz. Secenekler: {', '.join(CHANNELS)}")
    trigger = SyslogTrigger(**data)
    db.add(trigger)
    await db.commit()
    await db.refresh(trigger)
    return trigger


async def update_trigger(db: AsyncSession, trigger_id: uuid.UUID, data: dict) -> SyslogTrigger:
    trigger = await db.get(SyslogTrigger, trigger_id)
    if not trigger:
        raise HTTPException(status_code=404, detail="Tetikleyici bulunamadi")
    for k, v in data.items():
        if k in ("match_type", "channel") and v not in (MATCH_TYPES if k == "match_type" else CHANNELS):
            raise HTTPException(status_code=400, detail=f"Gecersiz {k} degeri")
        setattr(trigger, k, v)
    await db.commit()
    await db.refresh(trigger)
    return trigger


async def delete_trigger(db: AsyncSession, trigger_id: uuid.UUID) -> None:
    trigger = await db.get(SyslogTrigger, trigger_id)
    if not trigger:
        raise HTTPException(status_code=404, detail="Tetikleyici bulunamadi")
    await db.delete(trigger)
    await db.commit()


async def list_triggers(
    db: AsyncSession, customer_id: uuid.UUID | None = None
) -> list[SyslogTrigger]:
    q = select(SyslogTrigger)
    if customer_id:
        q = q.where(SyslogTrigger.customer_id == customer_id)
    q = q.order_by(SyslogTrigger.created_at.desc())
    res = await db.execute(q)
    return list(res.scalars().all())


async def evaluate_syslog(
    db: AsyncSession, record: SyslogRecord
) -> list[tuple[SyslogTrigger, str]]:
    """Evaluate a syslog record against all active triggers.
    Returns list of (trigger, matched_value) tuples."""
    res = await db.execute(
        select(SyslogTrigger).where(SyslogTrigger.is_active.is_(True))
    )
    triggers = list(res.scalars().all())
    now = datetime.now(timezone.utc)
    matched: list[tuple[SyslogTrigger, str]] = []

    for t in triggers:
        # Cooldown check
        if t.last_triggered_at:
            elapsed = (now - t.last_triggered_at).total_seconds() / 60
            if elapsed < t.cooldown_minutes:
                continue

        match_val = _match_trigger(t, record)
        if match_val is not None:
            matched.append((t, match_val))

    return matched


def _match_trigger(trigger: SyslogTrigger, record: SyslogRecord) -> str | None:
    if trigger.match_type == MATCH_TYPE_KEYWORD:
        pattern = trigger.match_pattern.lower()
        msg = (record.message or "").lower()
        if pattern in msg:
            return trigger.match_pattern

    if trigger.match_type == MATCH_TYPE_REGEX:
        try:
            m = re.search(trigger.match_pattern, record.message or "")
            if m:
                return m.group(0)
        except re.error:
            log.warning("Gecersiz regex pattern: %s", trigger.match_pattern)
            return None

    if trigger.match_type == MATCH_TYPE_SEVERITY:
        if record.severity is not None and trigger.severity_threshold is not None:
            if record.severity <= trigger.severity_threshold:
                return f"severity={record.severity} <= threshold={trigger.severity_threshold}"

    if trigger.match_type == MATCH_TYPE_VENDOR:
        vendor_pat = trigger.match_pattern.lower()
        app = (record.app_name or "").lower()
        msg = (record.message or "").lower()
        if vendor_pat in app or vendor_pat in msg:
            return vendor_pat

    return None


async def fire_triggers(
    db: AsyncSession, record: SyslogRecord
) -> list[TriggerEvent]:
    """Evaluate + fire + persist all matched triggers for a record."""
    matched = await evaluate_syslog(db, record)
    events: list[TriggerEvent] = []
    now = datetime.now(timezone.utc)

    for trigger, match_val in matched:
        event = await trigger_log(db, trigger.id, record.id, match_val)
        events.append(event)
        delivery = await _send_alert_async(trigger, record, match_val)
        event.delivery_channel = delivery.get("channel")
        event.delivery_status = delivery.get("status")
        event.delivery_target = delivery.get("target")
        event.delivery_detail = delivery.get("detail")
        event.delivered_at = delivery.get("delivered_at")
        trigger.last_triggered_at = now
        db.add(trigger)
        await db.flush()
        await _create_alarm_from_trigger(db, trigger, record, match_val)

    await db.commit()
    return events


def _alarm_severity_from_record(record: SyslogRecord) -> str:
    severity = int(record.severity or 5)
    if severity <= 2:
        return "critical"
    if severity <= 4:
        return "warning"
    return "info"


async def _create_alarm_from_trigger(
    db: AsyncSession,
    trigger: SyslogTrigger,
    record: SyslogRecord,
    match_val: str | None,
) -> None:
    from app.modules.alarm import service as alarm_service

    source = f"syslog-trigger:{trigger.id}"
    message = " | ".join(
        part for part in (
            match_val or trigger.match_pattern,
            record.hostname or None,
            record.app_name or None,
            record.message or None,
        )
        if part
    )
    await alarm_service.create_alarm(
        db,
        customer_id=trigger.customer_id,
        location_id=None,
        severity=_alarm_severity_from_record(record),
        title=trigger.name,
        message=message or trigger.name,
        source=source,
        trigger_id=trigger.id,
        commit=False,
    )


async def _send_alert_async(
    trigger: SyslogTrigger, record: SyslogRecord, match_val: str
) -> dict:
    """Fire-and-forget alert delivery."""
    try:
        if trigger.channel == CHANNEL_EMAIL:
            return await _send_email_alert(trigger, record, match_val)
        elif trigger.channel == CHANNEL_SMS:
            return await _send_sms_alert(trigger, record, match_val)
        elif trigger.channel == CHANNEL_WEBHOOK:
            return await _send_webhook_alert(trigger, record, match_val)
        return {
            "channel": trigger.channel,
            "status": "skipped",
            "target": None,
            "detail": "Desteklenmeyen kanal",
            "delivered_at": datetime.now(timezone.utc),
        }
    except Exception as exc:
        log.exception("Alert gonderilemedi trigger=%s channel=%s: %s", trigger.id, trigger.channel, exc)
        return {
            "channel": trigger.channel,
            "status": "failed",
            "target": _alert_target(trigger),
            "detail": str(exc),
            "delivered_at": datetime.now(timezone.utc),
        }


async def _send_email_alert(
    trigger: SyslogTrigger, record: SyslogRecord, match_val: str
) -> dict:
    cfg = trigger.channel_config or {}
    to_list = cfg.get("to", [])
    if not to_list:
        log.warning("Email alert icin alici (to) belirtilmemis trigger=%s", trigger.id)
        return {
            "channel": CHANNEL_EMAIL,
            "status": "skipped",
            "target": None,
            "detail": "Alici listesi bos",
            "delivered_at": datetime.now(timezone.utc),
        }

    subject = f"[Hotspot Alert] {trigger.name}"
    html = f"""<html><body>
<h2>{trigger.name}</h2>
<p><strong>Aciklama:</strong> {trigger.description or '-'}</p>
<p><strong>Eslesen Deger:</strong> {match_val}</p>
<p><strong>Hostname:</strong> {record.hostname or '-'}</p>
<p><strong>Severity:</strong> {record.severity or '-'}</p>
<p><strong>App:</strong> {record.app_name or '-'}</p>
<p><strong>Mesaj:</strong> {record.message}</p>
<hr><p><small>Hotspot Platform - Tetikleyici Sistemi</small></p>
</body></html>"""

    try:
        import smtplib
        from email.mime.text import MIMEText

        msg = MIMEText(html, "html")
        msg["Subject"] = subject
        msg["From"] = cfg.get("from", getattr(settings, "SMTP_FROM", None)) if hasattr(settings, "SMTP_FROM") else "alerts@hotspot.local"  # type: ignore[attr-defined]
        msg["To"] = ", ".join(to_list)

        host = cfg.get("host", getattr(settings, "SMTP_HOST", None)) if hasattr(settings, "SMTP_HOST") else "localhost"  # type: ignore[attr-defined]
        port = cfg.get("port", getattr(settings, "SMTP_PORT", None)) if hasattr(settings, "SMTP_PORT") else 25  # type: ignore[attr-defined]
        use_tls = cfg.get("use_tls", True)
        username = cfg.get("username", getattr(settings, "SMTP_USER", None)) if hasattr(settings, "SMTP_USER") else ""  # type: ignore[attr-defined]
        password = cfg.get("password", getattr(settings, "SMTP_PASS", None)) if hasattr(settings, "SMTP_PASS") else ""  # type: ignore[attr-defined]

        with smtplib.SMTP(str(host), int(port or 25), timeout=10) as server:
            if use_tls:
                server.starttls()
                if username:
                    server.login(str(username), str(password))
            server.sendmail(msg["From"], to_list, msg.as_string())
        return {
            "channel": CHANNEL_EMAIL,
            "status": "sent",
            "target": ", ".join(to_list),
            "detail": subject,
            "delivered_at": datetime.now(timezone.utc),
        }
    except Exception as exc:
        log.error("Email alert gonderilemedi: %s", exc)
        return {
            "channel": CHANNEL_EMAIL,
            "status": "failed",
            "target": ", ".join(to_list),
            "detail": str(exc),
            "delivered_at": datetime.now(timezone.utc),
        }


async def _send_sms_alert(
    trigger: SyslogTrigger, record: SyslogRecord, match_val: str
) -> dict:
    cfg = trigger.channel_config or {}
    to_phone = cfg.get("phone", "")
    if not to_phone:
        log.warning("SMS alert icin telefon numarasi belirtilmemis trigger=%s", trigger.id)
        return {
            "channel": CHANNEL_SMS,
            "status": "skipped",
            "target": None,
            "detail": "Telefon numarasi bos",
            "delivered_at": datetime.now(timezone.utc),
        }
    message = f"[Hotspot] {trigger.name}: {match_val[:100]}"

    provider = settings.SMS_PROVIDER if hasattr(settings, "SMS_PROVIDER") else "console"
    if provider in ("", "console", "log"):
        log.warning("SMS alert: %s -> %s", message, to_phone)
        return {
            "channel": CHANNEL_SMS,
            "status": "sent",
            "target": to_phone,
            "detail": "Console provider",
            "delivered_at": datetime.now(timezone.utc),
        }

    if provider == "http":
        url = settings.SMS_HTTP_URL if hasattr(settings, "SMS_HTTP_URL") else ""
        token = settings.SMS_HTTP_TOKEN if hasattr(settings, "SMS_HTTP_TOKEN") else ""
        if not url:
            return {
                "channel": CHANNEL_SMS,
                "status": "skipped",
                "target": to_phone,
                "detail": "SMS HTTP URL bos",
                "delivered_at": datetime.now(timezone.utc),
            }
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                await client.post(
                    url,
                    json={"sender": "HOTSPOT", "to": to_phone, "message": message},
                    headers={"Authorization": f"Bearer {token}"} if token else {},
                )
            return {
                "channel": CHANNEL_SMS,
                "status": "sent",
                "target": to_phone,
                "detail": "HTTP provider",
                "delivered_at": datetime.now(timezone.utc),
            }
        except Exception as exc:
            log.error("SMS alert gonderilemedi: %s", exc)
            return {
                "channel": CHANNEL_SMS,
                "status": "failed",
                "target": to_phone,
                "detail": str(exc),
                "delivered_at": datetime.now(timezone.utc),
            }

    return {
        "channel": CHANNEL_SMS,
        "status": "skipped",
        "target": to_phone,
        "detail": f"Desteklenmeyen SMS provider: {provider}",
        "delivered_at": datetime.now(timezone.utc),
    }


async def _send_webhook_alert(
    trigger: SyslogTrigger, record: SyslogRecord, match_val: str
) -> dict:
    cfg = trigger.channel_config or {}
    url = cfg.get("url", "")
    if not url:
        log.warning("Webhook alert icin URL belirtilmemis trigger=%s", trigger.id)
        return {
            "channel": CHANNEL_WEBHOOK,
            "status": "skipped",
            "target": None,
            "detail": "Webhook URL bos",
            "delivered_at": datetime.now(timezone.utc),
        }

    payload = {
        "trigger_id": str(trigger.id),
        "trigger_name": trigger.name,
        "trigger_description": trigger.description,
        "matched_value": match_val,
        "syslog_record_id": str(record.id),
        "hostname": record.hostname,
        "severity": record.severity,
        "app_name": record.app_name,
        "message": record.message,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    headers = cfg.get("headers", {})
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            await client.post(url, json=payload, headers=headers)
        return {
            "channel": CHANNEL_WEBHOOK,
            "status": "sent",
            "target": url,
            "detail": "Webhook delivered",
            "delivered_at": datetime.now(timezone.utc),
        }
    except Exception as exc:
        log.error("Webhook alert gonderilemedi: %s", exc)
        return {
            "channel": CHANNEL_WEBHOOK,
            "status": "failed",
            "target": url,
            "detail": str(exc),
            "delivered_at": datetime.now(timezone.utc),
        }


def _alert_target(trigger: SyslogTrigger) -> str | None:
    cfg = trigger.channel_config or {}
    if trigger.channel == CHANNEL_EMAIL:
        to_list = cfg.get("to", [])
        return ", ".join(to_list) if to_list else None
    if trigger.channel == CHANNEL_SMS:
        return cfg.get("phone")
    if trigger.channel == CHANNEL_WEBHOOK:
        return cfg.get("url")
    return None


async def trigger_log(
    db: AsyncSession,
    trigger_id: uuid.UUID,
    syslog_record_id: uuid.UUID,
    matched_value: str | None = None,
) -> TriggerEvent:
    event = TriggerEvent(
        trigger_id=trigger_id,
        syslog_record_id=syslog_record_id,
        matched_value=matched_value,
        triggered_at=datetime.now(timezone.utc),
    )
    db.add(event)
    await db.flush()
    return event


async def acknowledge_trigger(
    db: AsyncSession, event_id: uuid.UUID, user_id: uuid.UUID
) -> TriggerEvent:
    event = await db.get(TriggerEvent, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Tetikleyici olayi bulunamadi")
    if event.acknowledged_at:
        raise HTTPException(status_code=400, detail="Olay zaten onaylanmis")
    event.acknowledged_at = datetime.now(timezone.utc)
    event.acknowledged_by = user_id
    await db.commit()
    await db.refresh(event)
    return event


async def get_trigger_stats(
    db: AsyncSession, customer_id: uuid.UUID | None = None
) -> dict:
    q = select(
        SyslogTrigger.id,
        SyslogTrigger.name,
        func.count(TriggerEvent.id).label("event_count"),
        func.max(TriggerEvent.triggered_at).label("last_event"),
    ).outerjoin(
        TriggerEvent, SyslogTrigger.id == TriggerEvent.trigger_id
    )
    if customer_id:
        q = q.where(SyslogTrigger.customer_id == customer_id)
    q = q.group_by(SyslogTrigger.id, SyslogTrigger.name)

    res = await db.execute(q)
    rows = res.all()
    total_triggers = len(rows)
    total_events = sum(r.event_count or 0 for r in rows)
    active_triggers = sum(
        1 for r in rows if r.event_count and r.event_count > 0
    )

    return {
        "total_triggers": total_triggers,
        "active_triggers": active_triggers,
        "total_events": total_events,
        "triggers": [
            {
                "id": str(r.id),
                "name": r.name,
                "event_count": r.event_count or 0,
                "last_event": r.last_event.isoformat() if r.last_event else None,
            }
            for r in rows
        ],
    }
