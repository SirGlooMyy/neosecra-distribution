import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.site_bridge import service
from app.modules.site_bridge.schemas import (
    BridgeAgentOut,
    BridgeAgentRegisterIn,
    BridgeCommandIn,
    BridgeCommandOut,
    BridgeCommandResultIn,
    BridgeEventIn,
    BridgeHeartbeatIn,
)

router = APIRouter()
log = __import__("logging").getLogger(__name__)


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


# ---- Agent lifecycle (admin) --------------------------------------------------


@router.get("/agents", response_model=list[BridgeAgentOut], summary="List all registered site bridge agents", description="Returns all registered bridge agents that connect remote sites to the platform. Includes agent status, version, and last heartbeat timestamp. Requires the bridge.read permission.")
async def list_agents(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "bridge.read")
    return await service.list_agents(db, scope_for(user))


@router.post("/agents/register", response_model=BridgeAgentOut, status_code=status.HTTP_201_CREATED, summary="Register a new site bridge agent", description="Registers a new bridge agent for a tenant and optional location. The agent receives credentials for authenticating subsequent heartbeats and events. Requires the bridge.write permission.")
async def register_agent(
    body: BridgeAgentRegisterIn,
    request: Request,
    tenant_id: uuid.UUID | None = None,
    location_id: uuid.UUID | None = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "bridge.write")
    scope = scope_for(user)
    tid = tenant_id or scope.tenant_id
    if not tid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="tenant_id gerekli")
    return await service.register_agent(
        db, tid, location_id, body.model_dump(), client_ip=getattr(request.client, "host", None),
    )


# ---- Agent API (called by bridge agent, no JWT) ------------------------------
# These use X-Agent-Key or agent_id in body for auth


@router.post("/agents/heartbeat", summary="Send heartbeat from a bridge agent", description="Receives a heartbeat from a registered bridge agent to confirm it is online and operational. Updates the agent's last seen timestamp and version. Authenticated via agent_id, no JWT required.")
async def agent_heartbeat(
    body: BridgeHeartbeatIn,
    db: AsyncSession = Depends(get_db),
):
    return await service.heartbeat(db, body.agent_id, body.version)


@router.post("/agents/events", status_code=status.HTTP_201_CREATED, summary="Ingest an event from a bridge agent", description="Receives and processes events reported by a bridge agent. Events can include site status changes, network events, or configuration updates. Authenticated via agent_id, no JWT required.")
async def agent_event(
    body: BridgeEventIn,
    db: AsyncSession = Depends(get_db),
):
    return await service.ingest_event(db, body.agent_id, body.event_type, body.payload)


@router.post("/agents/commands/acknowledge", summary="Acknowledge a command result from a bridge agent", description="Receives the execution result of a previously dispatched command from a bridge agent. Updates the command status and stores the result payload. Authenticated via agent_id, no JWT required.")
async def agent_acknowledge(
    body: BridgeCommandResultIn,
    db: AsyncSession = Depends(get_db),
):
    return await service.acknowledge_command(db, body.command_id, body.status, body.result)


# ---- Command dispatch (admin) --------------------------------------------------


@router.post("/commands", response_model=BridgeCommandOut, status_code=status.HTTP_201_CREATED, summary="Dispatch a command to a bridge agent", description="Sends a command to a specific bridge agent for execution. Commands can instruct the agent to perform actions such as configuration sync or site status changes. Requires the bridge.write permission.")
async def dispatch_command(
    body: BridgeCommandIn,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "bridge.write")
    return await service.dispatch_command(db, body.agent_id, body.command_type, body.payload)


@router.get("/commands/{agent_id}", response_model=list[BridgeCommandOut], summary="List commands for a specific bridge agent", description="Returns all commands dispatched to the specified bridge agent including their status and execution results. Useful for monitoring command delivery. Requires the bridge.read permission.")
async def list_commands(
    agent_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "bridge.read")
    return await service.list_commands(db, agent_id)
