import logging

log = logging.getLogger(__name__)

# ISO 3166-1 alpha-2 country codes (common set)
VALID_COUNTRIES = {
    "US", "GB", "DE", "FR", "IT", "ES", "PT", "NL", "BE", "CH", "AT",
    "GR", "TR", "RU", "UA", "PL", "CZ", "SK", "HU", "RO", "BG", "RS",
    "HR", "BA", "SI", "AL", "MK", "ME", "XK",
    "SE", "NO", "DK", "FI", "IS",
    "CA", "MX", "BR", "AR", "CL", "CO", "PE",
    "AU", "NZ",
    "JP", "KR", "CN", "IN", "SG", "MY", "TH", "VN", "ID", "PH",
    "SA", "AE", "QA", "KW", "OM", "BH", "JO", "LB", "IL",
    "EG", "ZA", "NG", "KE", "MA", "TN", "DZ", "GH", "ET", "TZ",
    "IR", "IQ", "AF", "PK", "BD", "LK", "NP",
    "OTHER",
}


async def validate_passport(
    passport_number: str,
    country: str,
    full_name: str,
) -> bool:
    country_upper = country.strip().upper()
    if country_upper not in VALID_COUNTRIES:
        log.warning("Passport validation failed: unknown country %s", country)
        return False
    passport_clean = passport_number.strip()
    if len(passport_clean) < 5:
        log.warning("Passport validation failed: number too short (%s)", passport_clean)
        return False
    if not full_name.strip():
        log.warning("Passport validation failed: empty full name")
        return False
    log.info("Passport validation SUCCESS: %s / %s / %s", passport_clean, country_upper, full_name.strip())
    return True


async def send_email_verification(email: str, code: str) -> bool:
    log.info("Email verification code %s sent to %s (mock)", code, email)
    return True


def verify_email_code(code: str, stored: str) -> bool:
    return code.strip() == stored.strip()
