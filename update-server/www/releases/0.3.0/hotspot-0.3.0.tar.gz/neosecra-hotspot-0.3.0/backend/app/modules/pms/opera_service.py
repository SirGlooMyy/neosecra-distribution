"""Oracle Opera PMS integration via XML/SOAP Web Service."""
import logging
from datetime import date, datetime

import httpx

from app.modules.pms.demo import demo_or_fail
from app.modules.pms.schemas import PmsVerifyResult
from app.modules.pms.utils import normalize_turkish as _normalize_turkish

log = logging.getLogger(__name__)

SOAP_TEMPLATE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:op="http://opera.com/webservices/">
  <soap:Body>
    <op:GetReservation>
      <op:RoomNumber>{room}</op:RoomNumber>
      <op:LastName>{surname}</op:LastName>
      <op:HotelCode>{hotel_code}</op:HotelCode>
    </op:GetReservation>
  </soap:Body>
</soap:Envelope>"""


def _build_soap_envelope(room: str, surname: str, hotel_code: str) -> str:
    return SOAP_TEMPLATE.format(
        room=_escape_xml(room),
        surname=_escape_xml(surname),
        hotel_code=_escape_xml(hotel_code or ""),
    )


def _escape_xml(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def _parse_opera_response(xml_response: str) -> dict:
    import xml.etree.ElementTree as ET

    try:
        root = ET.fromstring(xml_response)
    except ET.ParseError as exc:
        log.warning("Opera XML parse error: %s", exc)
        return {}

    ns = {
        "soap": "http://schemas.xmlsoap.org/soap/envelope/",
        "op": "http://opera.com/webservices/",
    }

    res = root.find(".//op:GetReservationResponse", ns)
    if res is None:
        res = root.find(".//GetReservationResponse")
    if res is None:
        return {}

    guest_name = _find_text(res, "GuestName", ns)
    check_in_str = _find_text(res, "CheckInDate", ns)
    check_out_str = _find_text(res, "CheckOutDate", ns)
    status = _find_text(res, "Status", ns) or "checked_in"

    def _parse_date(val: str) -> date | None:
        if not val:
            return None
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d"):
            try:
                return datetime.strptime(val.strip(), fmt).date()
            except ValueError:
                continue
        return None

    return {
        "verified": (status or "").lower() in ("checked_in", "in_house", "reserved"),
        "guest_name": guest_name or "",
        "check_in": _parse_date(check_in_str or ""),
        "check_out": _parse_date(check_out_str or ""),
        "stay_status": status.lower() if status else "unknown",
    }


def _find_text(element, tag: str, ns: dict) -> str | None:
    found = element.find(f".//op:{tag}", ns)
    if found is not None:
        return found.text
    found = element.find(f".//{tag}")
    return found.text if found is not None else None


async def _mock_verify(room_number: str, surname: str) -> dict:
    is_valid = room_number.strip().isdigit() and len(_normalize_turkish(surname)) >= 3
    return {
        "verified": is_valid,
        "guest_name": f"GUEST/{surname.upper()}" if is_valid else None,
        "check_in": date.today() if is_valid else None,
        "check_out": date(2026, 12, 31) if is_valid else None,
        "stay_status": "checked_in" if is_valid else "unknown",
    }


async def verify_guest(
    room_number: str,
    surname: str,
    hotel_code: str = "",
    pms_config: dict | None = None,
) -> PmsVerifyResult:
    pms_config = pms_config or {}
    room_clean = (room_number or "").strip()
    surname_clean = _normalize_turkish(surname or "")

    if not room_clean or not surname_clean:
        log.warning("[Opera] Oda numarasi veya soyad bos")
        return PmsVerifyResult(verified=False, vendor="opera", message="Oda numarasi ve soyad gerekli")

    soap_url = pms_config.get("host") or pms_config.get("soap_url", "")
    soap_port = pms_config.get("port", 80)
    hotel_code_val = hotel_code or pms_config.get("hotel_code", "")

    if not soap_url:
        log.info("[Opera] WS endpoint yapilandirilmamis")
        return await demo_or_fail(
            vendor="opera",
            room_number=room_clean,
            surname_or_birth=surname_clean,
            mock_fn=_mock_verify,
            missing_config_message="Opera WS endpoint yapilandirilmamis",
        )

    endpoint = f"{soap_url.rstrip('/')}:{soap_port}/opera/ws" if soap_port else f"{soap_url.rstrip('/')}/opera/ws"
    soap_action = "urn:GetReservation"
    envelope = _build_soap_envelope(room_clean, surname_clean, hotel_code_val)

    try:
        async with httpx.AsyncClient(timeout=15.0, verify=False) as client:
            resp = await client.post(
                endpoint,
                content=envelope,
                headers={
                    "Content-Type": "text/xml; charset=utf-8",
                    "SOAPAction": soap_action,
                },
            )
            resp.raise_for_status()
            data = _parse_opera_response(resp.text)
            log.info("[Opera] Room=%s guest=%s verified=%s", room_clean, data.get("guest_name"), data.get("verified"))
            return PmsVerifyResult(
                verified=data.get("verified", False),
                guest_name=data.get("guest_name"),
                check_in=data.get("check_in"),
                check_out=data.get("check_out"),
                stay_status=data.get("stay_status", "unknown"),
                vendor="opera",
            )
    except httpx.TimeoutException:
        log.warning("[Opera] Timeout: %s", endpoint)
        return PmsVerifyResult(verified=False, vendor="opera", message="Opera WS zaman asimi")
    except httpx.HTTPStatusError as exc:
        log.warning("[Opera] HTTP %s: %s", exc.response.status_code, exc.response.text[:200])
        return PmsVerifyResult(verified=False, vendor="opera", message=f"Opera WS HTTP hatasi: {exc.response.status_code}")
    except Exception as exc:
        log.error("[Opera] Baglanti hatasi: %s", exc)
        return PmsVerifyResult(verified=False, vendor="opera", message=f"Opera WS baglanti hatasi: {exc}")
