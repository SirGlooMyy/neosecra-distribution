"""Elektra PMS integration — direct DB (SQLAlchemy) or REST API."""
import logging
from datetime import date, datetime

import httpx
from sqlalchemy import text

from app.modules.pms.demo import demo_or_fail
from app.modules.pms.schemas import PmsVerifyResult
from app.modules.pms.utils import normalize_turkish as _normalize_turkish

log = logging.getLogger(__name__)


async def _db_verify(room_number: str, surname: str, config: dict) -> dict:
    db_host = config.get("db_host", "localhost")
    db_port = config.get("db_port", 5432)
    db_name = config.get("db_name", "elektra")
    db_user = config.get("db_user", "postgres")
    db_password = config.get("db_password", "")

    db_url = f"postgresql+asyncpg://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"

    try:
        from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

        engine = create_async_engine(db_url, echo=False, pool_pre_ping=True, pool_size=1)
        async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

        async with async_session() as session:
            query = text(
                "SELECT * FROM reservations "
                "WHERE room_no = :room AND (last_name = :surname OR birth_year = :surname)"
            )
            result = await session.execute(query, {"room": room_number, "surname": surname})
            row = result.mappings().one_or_none()

        await engine.dispose()

        if row:
            return {
                "verified": True,
                "guest_name": f"{row.get('first_name', '')} {row.get('last_name', '')}".strip(),
                "check_in": row.get("check_in_date") or row.get("check_in"),
                "check_out": row.get("check_out_date") or row.get("check_out"),
                "stay_status": row.get("status", "checked_in"),
            }
        return {"verified": False}
    except Exception as exc:
        log.warning("[Elektra] DB baglanti hatasi: %s", exc)
        return {"verified": False, "error": str(exc)}


async def _rest_verify(room_number: str, surname: str, config: dict) -> dict:
    api_url = config.get("host", "").rstrip("/")
    api_key = config.get("api_key", "")

    if not api_url:
        return {"verified": False, "error": "REST API URL yapilandirilmamis"}

    endpoint = f"{api_url}/api/reservations/search"
    headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                endpoint,
                json={"room_no": room_number, "last_name": surname},
                headers=headers,
            )
            if resp.status_code == 200:
                data = resp.json()
                return {
                    "verified": data.get("found", False),
                    "guest_name": data.get("guest_name", ""),
                    "check_in": data.get("check_in"),
                    "check_out": data.get("check_out"),
                    "stay_status": data.get("status", ""),
                }
            log.warning("[Elektra] REST HTTP %s", resp.status_code)
            return {"verified": False, "error": f"HTTP {resp.status_code}"}
    except httpx.TimeoutException:
        return {"verified": False, "error": "Zaman asimi"}
    except Exception as exc:
        log.warning("[Elektra] REST baglanti hatasi: %s", exc)
        return {"verified": False, "error": str(exc)}


async def _mock_verify(room_number: str, surname: str) -> dict:
    is_valid = room_number.strip().isdigit() and len(_normalize_turkish(surname)) >= 3
    return {
        "verified": is_valid,
        "guest_name": f"GUEST/{surname.upper()}" if is_valid else None,
        "check_in": date.today() if is_valid else None,
        "check_out": date(2026, 12, 31) if is_valid else None,
        "stay_status": "checked_in" if is_valid else "unknown",
    }


async def verify_guest(
    room_number: str,
    surname: str,
    pms_config: dict | None = None,
) -> PmsVerifyResult:
    pms_config = pms_config or {}
    room_clean = (room_number or "").strip()
    surname_clean = _normalize_turkish(surname or "")

    if not room_clean or not surname_clean:
        log.warning("[Elektra] Oda numarasi veya soyad bos")
        return PmsVerifyResult(verified=False, vendor="elektra", message="Oda numarasi ve soyad gerekli")

    host = pms_config.get("host", "")
    db_host = pms_config.get("db_host", "")

    if not host and not db_host:
        log.info("[Elektra] Baglanti yapilandirilmamis")
        return await demo_or_fail(
            vendor="elektra",
            room_number=room_clean,
            surname_or_birth=surname_clean,
            mock_fn=_mock_verify,
            missing_config_message="Elektra baglanti yapilandirilmamis",
        )

    if db_host:
        data = await _db_verify(room_clean, surname_clean, pms_config)
    else:
        data = await _rest_verify(room_clean, surname_clean, pms_config)

    return PmsVerifyResult(
        verified=data.get("verified", False),
        guest_name=data.get("guest_name"),
        check_in=_parse_date(data.get("check_in")),
        check_out=_parse_date(data.get("check_out")),
        stay_status=data.get("stay_status", "unknown"),
        vendor="elektra",
        message=data.get("error"),
    )


def _parse_date(val) -> date | None:
    if val is None:
        return None
    if isinstance(val, date):
        return val
    if isinstance(val, datetime):
        return val.date()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d"):
        try:
            return datetime.strptime(str(val).strip(), fmt).date()
        except ValueError:
            continue
    return None
