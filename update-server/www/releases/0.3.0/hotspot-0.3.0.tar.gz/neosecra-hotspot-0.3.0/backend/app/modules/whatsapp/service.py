"""WhatsApp OTP send/verify for the captive portal guest auth path.

Two operations:
  * send_whatsapp_code — generate a short code, hash it, persist, deliver via
                         WhatsApp Business Cloud API, rate-limited per phone.
  * verify_whatsapp_code — constant-time check against the latest unconsumed
                           code bound to the guest's (customer, location) site
                           context.

This module is invoked by the PUBLIC captive flow (no admin JWT), so the scope
(customer_id/location_id) is resolved from the device the guest is behind and
passed in explicitly — OTPs are bound to a physical site to prevent cross-site
replay (Mutlak Kural #1/#2).
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import os
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import rate_limit
from app.modules.audit.service import log_audit
from app.modules.sms.service import normalize_tr_phone
from app.modules.sms.schemas import OtpResultOut
from app.modules.whatsapp.models import WhatsAppVerification

log = logging.getLogger(__name__)

_GSM_RE = re.compile(r"\D")


def _mask_phone(phone: str) -> str:
    return phone[:6] + "***" + phone[-2:] if len(phone) >= 8 else "***"


def _client_ip(request: Request | None) -> str | None:
    return request.client.host if request and request.client else None


def _hash_code(code: str) -> str:
    salt = secrets.token_hex(8)
    digest = hashlib.sha256(f"{salt}:{code}".encode()).hexdigest()
    return f"{salt}${digest}"


def _verify_code(code: str, stored: str) -> bool:
    try:
        salt, digest = stored.split("$", 1)
    except ValueError:
        return False
    candidate = hashlib.sha256(f"{salt}:{code}".encode()).hexdigest()
    return hmac.compare_digest(candidate, digest)


def _gen_code() -> str:
    n = settings.SMS_OTP_LENGTH
    return f"{secrets.randbelow(10 ** n):0{n}d}"


async def _deliver_whatsapp(phone: str, code: str) -> tuple[bool, str | None]:
    """Deliver via WhatsApp Business Cloud API. Returns (ok, error)."""
    token = os.environ.get("WHATSAPP_TOKEN", "")
    phone_id = os.environ.get("WHATSAPP_PHONE_ID", "")

    if not token or not phone_id:
        if settings.DEMO_MODE:
            log.warning(
                "WhatsApp OTP code=%s -> %s (WHATSAPP_TOKEN/PHONE_ID not configured, demo mode)",
                code,
                phone,
            )
            return True, None
        return False, "whatsapp-not-configured"

    try:
        import httpx
    except ImportError:
        return False, "httpx-not-installed"

    url = f"https://graph.facebook.com/v18.0/{phone_id}/messages"
    payload = {
        "messaging_product": "whatsapp",
        "to": phone,
        "type": "template",
        "template": {
            "name": "otp_verification",
            "language": {"code": "tr"},
            "components": [
                {
                    "type": "body",
                    "parameters": [
                        {"type": "text", "text": code}
                    ],
                }
            ],
        },
    }
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, json=payload, headers=headers)
        if 200 <= resp.status_code < 300:
            return True, None
        return False, f"wa-http-{resp.status_code}"
    except Exception as exc:
        return False, f"wa-deliver-error:{type(exc).__name__}"


async def send_whatsapp_code(
    db: AsyncSession,
    *,
    phone: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
    request: Request | None = None,
) -> OtpResultOut:
    phone = normalize_tr_phone(phone)

    blocked, _ = await rate_limit(
        f"whatsapp_send:{phone}",
        settings.SMS_SEND_MAX_PER_WINDOW,
        settings.SMS_SEND_WINDOW_MINUTES * 60,
    )
    if blocked:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Cok fazla kod istendi. Lutfen bir sure sonra tekrar deneyin.",
        )

    code = _gen_code()
    session_info_id = secrets.token_urlsafe(16)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=settings.SMS_OTP_TTL_SECONDS)
    delivered, err = await _deliver_whatsapp(phone, code)
    if not delivered and not settings.DEMO_MODE:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="WhatsApp dogrulama servisi yapilandirilmamis veya ulasilamiyor.",
        )

    wa = WhatsAppVerification(
        customer_id=customer_id,
        location_id=location_id,
        phone=phone,
        code_hash=_hash_code(code),
        session_info_id=session_info_id,
        expires_at=expires_at,
        max_attempts=settings.SMS_OTP_MAX_ATTEMPTS,
        request_ip=_client_ip(request),
        delivered=delivered,
        deliver_error=err,
    )

    db.add(wa)
    await db.flush()
    await log_audit(
        db, "whatsapp.code_sent", "whatsapp_verification", str(wa.id), None, request,
        details={"phone": _mask_phone(phone), "delivered": delivered},
    )
    await db.commit()

    return OtpResultOut(
        state="sent",
        ttl_seconds=settings.SMS_OTP_TTL_SECONDS,
        attempts_left=settings.SMS_OTP_MAX_ATTEMPTS,
    )


async def verify_whatsapp_code(
    db: AsyncSession,
    *,
    phone: str,
    code: str,
    customer_id: uuid.UUID,
    location_id: uuid.UUID | None = None,
) -> WhatsAppVerification:
    phone = normalize_tr_phone(phone)
    now = datetime.now(timezone.utc)

    q = (
        select(WhatsAppVerification)
        .where(
            WhatsAppVerification.phone == phone,
            WhatsAppVerification.customer_id == customer_id,
            WhatsAppVerification.verified.is_(False),
            WhatsAppVerification.consumed_at.is_(None),
        )
        .order_by(WhatsAppVerification.created_at.desc())
    )
    if location_id is not None:
        q = q.where(WhatsAppVerification.location_id == location_id)

    wa = (await db.execute(q.limit(1))).scalar_one_or_none()
    if not wa:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kod bulunamadi. Once kod isteyin.",
        )
    if wa.expires_at < now:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="Kodun suresi doldu. Yeni kod isteyin.",
        )

    wa.attempts += 1
    if wa.attempts > wa.max_attempts:
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Cok fazla hatali deneme. Yeni kod isteyin.",
        )
    if not _verify_code(code, wa.code_hash):
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Hatali kod.",
        )

    wa.verified = True
    await db.commit()
    await db.refresh(wa)
    return wa


async def consume(db: AsyncSession, wa_id: uuid.UUID) -> None:
    """Mark a verified WhatsApp verification consumed once exchanged for a session."""
    wa = await db.get(WhatsAppVerification, wa_id)
    if wa and not wa.consumed_at:
        wa.consumed_at = datetime.now(timezone.utc)
        await db.commit()


async def send_whatsapp_otp(phone: str, code: str) -> tuple[bool, str | None]:
    """Deliver a custom WhatsApp message template via Meta Graph API."""
    try:
        phone = normalize_tr_phone(phone)
    except Exception:
        pass
    return await _deliver_whatsapp(phone, code)
