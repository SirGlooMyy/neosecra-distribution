"""9-language i18n service for the captive portal.

Provides translation lookups for all 100+ portal strings. Turkish is the base
language; English and Arabic are fully translated; the rest are real translations
that may need native-speaker review.
"""
from __future__ import annotations

from app.modules.portal.i18n_data import (
    get_translation_map,
)


def get_translations(lang: str | None = None) -> dict[str, str]:
    """Return all translations for *lang*.

    Falls back to Turkish when the language is unsupported. Every key that
    exists in the Turkish map is guaranteed to be present.
    """
    return get_translation_map(lang)


def get_text(key: str, lang: str | None = None, **kwargs: str) -> str:
    """Get a single translated string with optional :py:func:`str.format` substitution.

    Example::

        >>> get_text("session_remaining_time", "en")
        "Remaining Time"
        >>> get_text("btn_send_code", "tr")
        "Kod Gönder"
    """
    translations = get_translation_map(lang)
    text = translations.get(key, key)
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, ValueError):
            pass
    return text
