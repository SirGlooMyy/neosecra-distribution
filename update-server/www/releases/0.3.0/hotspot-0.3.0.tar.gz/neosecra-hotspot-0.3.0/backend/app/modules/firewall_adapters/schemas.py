# Pydantic schemas for firewall_adapters
