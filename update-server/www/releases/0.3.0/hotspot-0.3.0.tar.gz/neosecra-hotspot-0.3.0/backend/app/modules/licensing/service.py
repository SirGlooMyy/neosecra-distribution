"""Business logic for licensing + quota enforcement (Mutlak Kural #12).

Quota enforcement is the captive-flow gate: before a guest session is created
the portal calls enforce_quota(customer_id). A license is OPTIONAL — a missing
row means the dev default (unlimited) so the captive flow works out of the box.
Admins tighten quotas per customer via the licensing router.

Daily counters are computed from GuestSession rows in the live DB (no separate
counter table to drift out of sync); this is a read check, it never mutates
5651/session data (Mutlak Kural #4/#5 — append-only / no purge).
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.licensing import repository
from app.modules.licensing.models import UNLIMITED, CustomerLicense
from app.modules.licensing.schemas import LicenseUpsert, QuotaStatus
from app.modules.sessions.models import GuestSession, STATUS_ACTIVE

log = logging.getLogger(__name__)


async def get_for_customer(db: AsyncSession, customer_id: uuid.UUID) -> CustomerLicense | None:
    return await repository.get_for_customer(db, customer_id)


async def _day_start_utc(now: datetime | None = None) -> datetime:
    """00:00 of today in UTC — the daily-cap window."""
    n = now or datetime.now(timezone.utc)
    return n.replace(hour=0, minute=0, second=0, microsecond=0)


async def quota_status(
    db: AsyncSession, customer_id: uuid.UUID, *, now: datetime | None = None
) -> QuotaStatus:
    """Snapshot the customer's live quota. Missing license = unlimited default."""
    lic = await repository.get_for_customer(db, customer_id)
    n = now or datetime.now(timezone.utc)
    day_start = await _day_start_utc(n)

    active_count = (
        await db.execute(
            select(func.count())
            .select_from(GuestSession)
            .where(
                GuestSession.customer_id == customer_id,
                GuestSession.status == STATUS_ACTIVE,
            )
        )
    ).scalar_one()

    daily_used = (
        await db.execute(
            select(func.count())
            .select_from(GuestSession)
            .where(
                GuestSession.customer_id == customer_id,
                GuestSession.started_at >= day_start,
            )
        )
    ).scalar_one()

    if lic is None:
        return QuotaStatus(
            customer_id=customer_id,
            active_guests_quota=UNLIMITED,
            active_count=int(active_count or 0),
            active_remaining=UNLIMITED,
            max_sessions_per_day=None,
            daily_used=int(daily_used or 0),
            daily_remaining=None,
            session_minutes_default=None,
            expired=False,
            active=True,
            within_quota=True,
        )

    quota = lic.active_guests_quota
    remaining = UNLIMITED if quota == UNLIMITED else max(0, quota - int(active_count or 0))
    daily_quota = lic.max_sessions_per_day
    daily_remaining = (
        None
        if daily_quota is None or daily_quota == UNLIMITED
        else max(0, daily_quota - int(daily_used or 0))
    )
    expired = bool(lic.expires_at and lic.expires_at <= n)
    active = bool(lic.is_active and not expired)

    over_active = quota != UNLIMITED and int(active_count or 0) >= quota
    over_daily = (
        daily_quota is not None
        and daily_quota != UNLIMITED
        and int(daily_used or 0) >= daily_quota
    )
    within_quota = active and not (over_active or over_daily)

    return QuotaStatus(
        customer_id=customer_id,
        active_guests_quota=quota,
        active_count=int(active_count or 0),
        active_remaining=remaining,
        max_sessions_per_day=daily_quota,
        daily_used=int(daily_used or 0),
        daily_remaining=daily_remaining,
        session_minutes_default=lic.session_minutes_default,
        expired=expired,
        active=active,
        within_quota=within_quota,
    )


async def enforce_quota(db: AsyncSession, customer_id: uuid.UUID) -> QuotaStatus:
    """Raise 402 if the customer is over quota / expired / deactivated. Called
    by the captive flow before create_session. Returns the status on success."""
    qs = await quota_status(db, customer_id)
    if not qs.active:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Lisans gecerli degil (suresi dolmus veya pasif)",
        )
    if not qs.within_quota:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Musteri kota limitini asti (es zamanli gunluk veya aktif oturum)",
        )
    return qs


def session_duration_minutes(qs: QuotaStatus, default_minutes: int) -> int:
    """License override wins, else the caller default (settings)."""
    return qs.session_minutes_default if qs.session_minutes_default else default_minutes


# ---- admin upsert + scoped views -------------------------------------------
async def _authorize_customer(
    db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext
) -> Customer:
    """Load + IDOR-check the customer against the caller scope."""
    cust = (
        await db.execute(select(Customer).where(Customer.id == customer_id))
    ).scalar_one_or_none()
    if not cust:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Musteri bulunamadi"
        )
    if scope.level == TenantLevel.GLOBAL:
        return cust
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        if cust.partner_id != scope.partner_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Bu musteri sizin partner kapsaminizda degil",
            )
        return cust
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        if cust.id != scope.customer_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Yalnizca kendi musteri lisansinizi yonetebilirsiniz",
            )
        return cust
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN, detail="Lisans yonetimi yetkisiz"
    )


async def upsert_license(
    db: AsyncSession,
    customer_id: uuid.UUID,
    body: LicenseUpsert,
    scope: ScopeContext,
    actor_id: uuid.UUID,
    request: Request | None = None,
) -> CustomerLicense:
    """Create or PATCH the 1:1 license row for a customer (IDOR-guarded)."""
    await _authorize_customer(db, customer_id, scope)
    lic = await repository.get_for_customer(db, customer_id)

    if lic is None:
        lic = CustomerLicense(customer_id=customer_id)
        created = True
    else:
        created = False

    data = body.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(lic, key, value)
    db.add(lic)
    await db.flush()
    await log_audit(
        db,
        "license.upserted" if not created else "license.created",
        "customer_license",
        str(lic.id),
        str(actor_id) if actor_id else None,  # type: ignore[arg-type]
        request,
        details={"customer_id": str(customer_id), "created": created, "changed": list(data.keys())},
    )
    await db.commit()
    await db.refresh(lic)
    return lic


async def _scoped_customer_ids(db: AsyncSession, scope: ScopeContext) -> list[uuid.UUID] | None:
    """Customer ids visible to the scope. None = GLOBAL (no filter)."""
    if scope.level == TenantLevel.GLOBAL:
        return None
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        res = await db.execute(
            select(Customer.id).where(Customer.partner_id == scope.partner_id)
        )
        return list(res.scalars().all())
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return [scope.customer_id]
    return []


async def list_licenses(db: AsyncSession, scope: ScopeContext) -> list[dict]:
    ids = await _scoped_customer_ids(db, scope)
    stmt = select(CustomerLicense, Customer.name.label("customer_name")).join(
        Customer, Customer.id == CustomerLicense.customer_id
    )
    if ids is not None:
        stmt = stmt.where(CustomerLicense.customer_id.in_(ids))
    stmt = stmt.order_by(CustomerLicense.created_at.desc())
    res = await db.execute(stmt)
    out = []
    for lic, name in res.all():
        out.append({
            "id": lic.id,
            "customer_id": lic.customer_id,
            "customer_name": name,
            "active_guests_quota": lic.active_guests_quota,
            "max_sessions_per_day": lic.max_sessions_per_day,
            "session_minutes_default": lic.session_minutes_default,
            "expires_at": lic.expires_at,
            "is_trial": lic.is_trial,
            "is_active": lic.is_active,
            "plan": lic.plan,
            "meta": lic.meta,
            "created_at": lic.created_at,
            "updated_at": lic.updated_at,
        })
    return out


async def get_license(
    db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext
) -> dict:
    await _authorize_customer(db, customer_id, scope)
    stmt = select(CustomerLicense, Customer.name.label("customer_name")).join(
        Customer, Customer.id == CustomerLicense.customer_id
    ).where(CustomerLicense.customer_id == customer_id)
    res = await db.execute(stmt)
    row = res.one_or_none()
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bu musteri icin lisans kaydi yok (unlimited dev default)",
        )
    lic, name = row
    return {
        "id": lic.id,
        "customer_id": lic.customer_id,
        "customer_name": name,
        "active_guests_quota": lic.active_guests_quota,
        "max_sessions_per_day": lic.max_sessions_per_day,
        "session_minutes_default": lic.session_minutes_default,
        "expires_at": lic.expires_at,
        "is_trial": lic.is_trial,
        "is_active": lic.is_active,
        "plan": lic.plan,
        "meta": lic.meta,
        "created_at": lic.created_at,
        "updated_at": lic.updated_at,
    }


async def check_radius_enterprise_enabled(db: AsyncSession, customer_id: uuid.UUID) -> bool:
    """Musterinin RADIUS Enterprise (802.1X) ozelliginin aktif olup
    olmadigini kontrol et. Lisans kaydi yoksa config'deki genel
    RADIUS_ENTERPRISE_ENABLED ayarina bakar.

    Args:
        db: Veritabani oturumu.
        customer_id: Musteri ID.

    Returns:
        True ozellik aktif, False kapali.
    """
    from app.core.config import settings

    if not settings.RADIUS_ENTERPRISE_ENABLED:
        return False
    lic = await repository.get_for_customer(db, customer_id)
    if lic is None:
        return settings.RADIUS_ENTERPRISE_ENABLED
    return bool(lic.is_active and lic.is_radius_enterprise)
