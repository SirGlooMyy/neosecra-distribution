"""Async TCP syslog listener (RFC 5424 receiver).

Listens on SYSLOG_LISTEN_HOST:SYSLOG_LISTEN_PORT (default 0.0.0.0:514).
Each connection is read line-by-line, parsed, enriched with tenant scope,
and batch-inserted into firewall_logs.

Graceful shutdown via SIGTERM/SIGINT.

Usage:
    from app.modules.syslog.listener import start_syslog_server
    server = await start_syslog_server(db_session_factory)
    # ... later
    server.close()
    await server.wait_closed()
"""
from __future__ import annotations

import asyncio
import logging
import os
import signal
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import async_sessionmaker

from app.modules.firewall_adapters.fortigate import parse_syslog_event
from app.modules.syslog.models import FirewallLog
from app.modules.syslog.rfc5424 import parse_rfc5424
from app.modules.syslog.repository import (
    insert_firewall_log_batch,
    resolve_tenant_for_hostname,
)
from app.modules.syslog.service import process_firewall_log_batch

log = logging.getLogger(__name__)

# Config from environment with defaults
SYSLOG_HOST = os.getenv("SYSLOG_LISTEN_HOST", "0.0.0.0")
SYSLOG_PORT = int(os.getenv("SYSLOG_LISTEN_PORT", "514"))
BATCH_SIZE = 100
FLUSH_INTERVAL = 1.0  # seconds


async def start_syslog_server(
    db_session_factory: async_sessionmaker,
    host: str = SYSLOG_HOST,
    port: int = SYSLOG_PORT,
) -> asyncio.AbstractServer:
    """Start the async TCP syslog server.

    Returns the asyncio server object. Call server.close() to shut down.
    """
    if port < 1024 and os.geteuid() != 0:
        log.warning(
            "Port %d requires root; try port >1024 or run as root. "
            "Continuing anyway (will likely fail with EACCES).",
            port,
        )

    server = await asyncio.start_server(
        _make_handler(db_session_factory),
        host=host,
        port=port,
        reuse_address=True,
        reuse_port=False,
    )

    log.info("Syslog TCP server listening on %s:%d", host, port)
    return server


def _make_handler(
    db_session_factory: async_sessionmaker,
):
    """Factory for per-connection handlers with closure over factory."""

    async def _handle_connection(
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        peername = writer.get_extra_info("peername")
        log.info("Syslog connection from %s", peername)
        try:
            await _process_stream(reader, writer, db_session_factory)
        except asyncio.CancelledError:
            log.debug("Syslog connection cancelled: %s", peername)
        except Exception:
            log.exception("Syslog connection error: %s", peername)
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    return _handle_connection


async def _process_stream(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    db_session_factory: async_sessionmaker,
) -> None:
    """Read lines from the TCP stream, parse, batch insert."""
    batch: list[FirewallLog] = []
    last_flush = datetime.now(timezone.utc)

    while True:
        try:
            raw_bytes = await asyncio.wait_for(reader.readline(), timeout=300.0)
        except asyncio.TimeoutError:
            # Flush partial batch on idle timeout
            if batch:
                await _flush_batch(db_session_factory, batch)
                batch.clear()
                last_flush = datetime.now(timezone.utc)
            continue

        if not raw_bytes:
            # EOF
            break

        raw_line = raw_bytes.decode("utf-8", errors="replace").strip()
        if not raw_line:
            continue

        # Parse RFC 5424 to get hostname
        parsed = parse_rfc5424(raw_line)
        if parsed is None:
            log.debug("Unparseable syslog line, storing raw only")
            hostname = None
        else:
            hostname = parsed.get("hostname")

        # Enrich with FortiGate key=value parsing
        fortigate_data = parse_syslog_event(raw_line)

        # Determine event_time from FortiGate date= + time= fields
        event_time = _parse_fortigate_timestamp(fortigate_data.get("parsed_fields", {}))

        # Build FirewallLog
        log_entry = FirewallLog(
            tenant_id=fortigate_data.get("tenant_id", None),
            customer_id=fortigate_data.get("customer_id", None),
            device_id=fortigate_data.get("device_id", None),
            received_at=datetime.now(timezone.utc),
            event_time=event_time,
            vendor="fortigate",
            log_type=fortigate_data.get("log_type", "unknown"),
            log_subtype=fortigate_data.get("log_subtype"),
            severity=fortigate_data.get("severity", "info"),
            action=fortigate_data.get("action"),
            src_ip=fortigate_data.get("src_ip"),
            dst_ip=fortigate_data.get("dst_ip"),
            src_port=fortigate_data.get("src_port"),
            dst_port=fortigate_data.get("dst_port"),
            proto=fortigate_data.get("proto"),
            service=fortigate_data.get("service"),
            user=fortigate_data.get("user"),
            policyid=fortigate_data.get("policyid"),
            duration=fortigate_data.get("duration"),
            sentbyte=fortigate_data.get("sentbyte"),
            rcvdbyte=fortigate_data.get("rcvdbyte"),
            session_id=fortigate_data.get("session_id"),
            raw_syslog=raw_line,
            parsed_fields=fortigate_data.get("parsed_fields", {}),
        )

        # Enrich with tenant/customer if hostname resolved
        if hostname and (log_entry.tenant_id is None or log_entry.customer_id is None):
            async with db_session_factory() as db:
                resolved = await resolve_tenant_for_hostname(db, hostname)
                if resolved:
                    log_entry.tenant_id, log_entry.customer_id = resolved

        batch.append(log_entry)

        # Flush batch on size or time
        now = datetime.now(timezone.utc)
        time_since_flush = (now - last_flush).total_seconds()
        if len(batch) >= BATCH_SIZE or time_since_flush >= FLUSH_INTERVAL:
            await _flush_batch(db_session_factory, batch)
            batch.clear()
            last_flush = now

    # Flush remaining
    if batch:
        await _flush_batch(db_session_factory, batch)


async def _flush_batch(
    db_session_factory: async_sessionmaker,
    batch: list[FirewallLog],
) -> None:
    """Insert a batch into DB and call post-process service."""
    if not batch:
        return

    async with db_session_factory() as db:
        try:
            count = await insert_firewall_log_batch(db, batch)
            await db.commit()
            log.debug("Inserted %d firewall_logs", count)

            # Post-process records already persisted. Do not call the raw-line
            # ingestion function here; that would duplicate rows and pass an
            # ORM object to a string parser.
            await process_firewall_log_batch(db, batch)

        except Exception:
            await db.rollback()
            log.exception("Batch insert failed for %d logs", len(batch))


def _parse_fortigate_timestamp(fields: dict) -> datetime | None:
    """Parse FortiGate date= + time= into a datetime."""
    date_str = fields.get("date")
    time_str = fields.get("time")
    if date_str and time_str:
        try:
            dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M:%S")
            return dt.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    return None


async def run_forever(
    db_session_factory: async_sessionmaker,
    host: str = SYSLOG_HOST,
    port: int = SYSLOG_PORT,
) -> None:
    """Start syslog server and run until cancelled.

    Registers signal handlers for graceful shutdown.
    """
    server = await start_syslog_server(db_session_factory, host=host, port=port)

    stop_event = asyncio.Event()

    def _signal_handler():
        log.info("Signal received, shutting down syslog server...")
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _signal_handler)
        except NotImplementedError:
            pass

    await stop_event.wait()
    server.close()
    await server.wait_closed()
    log.info("Syslog server stopped.")


async def serve_forever(
    db_session_factory: async_sessionmaker,
    host: str = SYSLOG_HOST,
    port: int = SYSLOG_PORT,
) -> None:
    """Alias for run_forever — kept for compatibility."""
    await run_forever(db_session_factory, host=host, port=port)
