"""Palo Alto Networks adapter — PAN-OS XML / REST API.

Implements the FirewallAdapter ABC for PAN-OS 9.0+. Uses the XML API for
operational (op) commands and the REST API for configuration operations.
Auth is via the API key derived from /api/?type=keygen or provided directly.
"""
from __future__ import annotations

import shlex
import xml.etree.ElementTree as ET
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class PaloAltoAdapter(FirewallAdapter):
    vendor = "paloalto"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        self._base_api = f"https://{host}:{port}/api"
        self._base_rest = f"https://{host}:{port}/restapi/v10.1"
        self._api_key = config.api_token or ""
        self._headers = {"Authorization": f"Bearer {self._api_key}"}

    async def _xml_request(
        self,
        *,
        params: dict[str, str],
        timeout: float = 30.0,
    ) -> ET.Element:
        """Execute an XML API call.  Always includes the api_key in params."""
        p = dict(params)
        if self._api_key:
            p["key"] = self._api_key
        url = self._base_api
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.get(url, params=p)
        if resp.status_code >= 400:
            raise AdapterError(
                f"PAN-OS XML API HTTP {resp.status_code}: {resp.text[:300]}"
            )
        root = ET.fromstring(resp.text)
        status = root.get("status", "")
        if status != "success":
            msg = root.findtext(".//msg") or root.findtext(".//line") or resp.text[:200]
            raise AdapterError(f"PAN-OS XML API error: {msg}")
        return root

    async def _rest_request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_rest}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"PAN-OS REST {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    async def _op(self, cmd: str, timeout: float = 30.0) -> ET.Element:
        """Shortcut for 'op' type XML commands."""
        return await self._xml_request(params={"type": "op", "cmd": cmd}, timeout=timeout)

    async def _show(self, xpath: str, timeout: float = 30.0) -> ET.Element:
        return await self._xml_request(
            params={"type": "config", "action": "get", "xpath": xpath},
            timeout=timeout,
        )

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=False,
            radius_authentication=True,
            radius_accounting=True,
            radius_coa=True,
            disconnect_message=True,
            mac_auth_bypass=True,
            active_session_query=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            root = await self._op("<show><system><info></info></system></show>")
            hostname = root.findtext(".//hostname", "?")
            sw_version = root.findtext(".//sw-version", "?")
            return AdapterResult(
                ok=True,
                message=f"connected: {hostname} PAN-OS {sw_version}",
                data={"hostname": hostname, "version": sw_version},
            )
        except (AdapterError, httpx.HTTPError, ET.ParseError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        root = await self._op("<show><system><info></info></system></show>")
        return {
            "hostname": root.findtext(".//hostname", ""),
            "model": root.findtext(".//model", ""),
            "serial_number": root.findtext(".//serial", ""),
            "firmware_version": root.findtext(".//sw-version", ""),
            "uptime": root.findtext(".//uptime", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        root = await self._op("<show><interface>all</interface></show>")
        results: list[dict[str, Any]] = []
        for entry in root.findall(".//entry"):
            results.append({
                "name": entry.get("name", ""),
                "ip": entry.findtext("ip", ""),
                "zone": entry.findtext("zone", ""),
                "vsys": entry.findtext("vsys", ""),
                "status": "up" if entry.findtext("link-state", "down") == "up" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            root = await self._show("/config/shared/profiles/captive-portal")
            profiles = []
            for entry in root.findall(".//entry"):
                profiles.append({
                    "name": entry.get("name", ""),
                    "redirect_url": entry.findtext("redirect-url", ""),
                    "timeout": entry.findtext("timeout", ""),
                })
            return {"captive_portal_profiles": profiles}
        except AdapterError:
            return {"captive_portal_profiles": []}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        root = await self._op("<show><session><all></all></session></show>")
        results: list[dict[str, Any]] = []
        for entry in root.findall(".//entry"):
            results.append({
                "ip": entry.findtext("x-source", ""),
                "user": entry.findtext("user", ""),
                "from": entry.findtext("from", ""),
                "to": entry.findtext("to", ""),
                "source": entry.findtext("source", ""),
                "destination": entry.findtext("destination", ""),
                "state": entry.findtext("state", ""),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        root = await self._op("<show><arp><entry></entry></show></arp>")
        results: list[dict[str, Any]] = []
        for entry in root.findall(".//entry"):
            results.append({
                "ip": entry.get("ip", ""),
                "mac": entry.findtext("mac", ""),
                "interface": entry.findtext("interface", ""),
                "status": entry.findtext("status", ""),
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        session.get("mac", "00:00:00:00:00:00")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        tag_name = f"hsess-tag-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        addr_xpath = f"/config/devices/entry/vsys/entry/address/entry[@name='{name}']"
        tag_xpath = f"/config/devices/entry/vsys/entry/tag/entry[@name='{tag_name}']"
        addr_xml = (
            f'<entry name="{name}"><ip-netmask>{ip}/32</ip-netmask>'
            f'<tag><member>{tag_name}</member></tag>'
            f'<description>{self._guest_comment(session)}</description></entry>'
        )
        tag_xml = (
            f'<entry name="{tag_name}"><color>color7</color>'
            f'<comments>hotspot guest</comments></entry>'
        )
        try:
            await self._xml_request(
                params={
                    "type": "config",
                    "action": "set",
                    "xpath": tag_xpath,
                    "element": tag_xml,
                }
            )
            await self._xml_request(
                params={
                    "type": "config",
                    "action": "set",
                    "xpath": addr_xpath,
                    "element": addr_xml,
                }
            )
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"address": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        xpath = f"/config/devices/entry/vsys/entry/address/entry[@name='{name}']"
        try:
            await self._xml_request(
                params={"type": "config", "action": "delete", "xpath": xpath}
            )
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "paloalto", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname")
        parsed["event_type"] = parsed.get("type")
        parsed["event_subtype"] = parsed.get("subtype")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        parsed["rule"] = parsed.get("rule")
        parsed["app"] = parsed.get("app")
        return parsed
