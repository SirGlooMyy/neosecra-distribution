"""NVI (National Identity Verification) integration.

SOAP call to https://tckimlik.nvi.gov.tr/Service/KPSPublic.asmx
Method: TCKimlikNoDogrula
Parameters: TCKimlikNo (int64), Ad (string), Soyad (string), DogumYili (int)

If NVI unreachable: fall back to algorithmic validation.
Cache result in Redis for NVI_CACHE_TTL to avoid hitting NVI repeatedly.
"""
import logging
import xml.sax.saxutils as saxutils

from app.core.config import settings
from app.modules.identity.tc_validation import is_valid_turkish_identity_number

log = logging.getLogger(__name__)

_SOAP_ENVELOPE = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <TCKimlikNoDogrula xmlns="http://tckimlik.nvi.gov.tr/WS">
      <TCKimlikNo>{tcno}</TCKimlikNo>
      <Ad>{ad}</Ad>
      <Soyad>{soyad}</Soyad>
      <DogumYili>{yil}</DogumYili>
    </TCKimlikNoDogrula>
  </soap:Body>
</soap:Envelope>"""


def _get_redis():
    """Lazy-import redis client to avoid circular deps at module load."""
    from app.core.security import get_redis
    return get_redis()


async def verify_tc_kimlik(
    tc_number: str,
    first_name: str,
    last_name: str,
    birth_year: int,
) -> bool:
    """SOAP call to NVI. Returns True if identity matches.

    Falls back to algorithmic validation if NVI is unreachable.
    Caches result in Redis for NVI_CACHE_TTL seconds.
    """
    if not settings.NVI_ENABLED:
        log.info("NVI disabled, falling back to algorithmic check")
        return is_valid_turkish_identity_number(tc_number)

    try:
        import httpx
    except ImportError:
        log.warning("httpx not installed, cannot call NVI")
        return is_valid_turkish_identity_number(tc_number)

    # Clean TC number
    tc_digits = "".join(c for c in tc_number if c.isdigit())
    if len(tc_digits) != 11:
        return False

    cache_key = f"nvi:{tc_digits}"
    try:
        r = _get_redis()
        cached = await r.get(cache_key)
        if cached is not None:
            return cached == "1"
    except Exception:
        pass

    body = _SOAP_ENVELOPE.format(
        tcno=tc_digits,
        ad=saxutils.escape(first_name.upper()),
        soyad=saxutils.escape(last_name.upper()),
        yil=birth_year,
    )

    url = "https://tckimlik.nvi.gov.tr/Service/KPSPublic.asmx"
    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://tckimlik.nvi.gov.tr/WS/TCKimlikNoDogrula",
    }

    try:
        async with httpx.AsyncClient(
            timeout=10.0,
            verify=settings.NVI_VERIFY_TLS,
        ) as client:
            resp = await client.post(url, content=body, headers=headers)
        result = (
            resp.status_code == 200
            and "<TCKimlikNoDogrulaResult>true</TCKimlikNoDogrulaResult>" in resp.text
        )
        log.info("NVI verification for TC %s: %s", tc_digits[:6] + "*****", "basarili" if result else "basarisiz")
    except Exception as exc:
        log.warning("NVI unreachable, falling back to algorithmic check: %s", exc)
        result = is_valid_turkish_identity_number(tc_digits)

    try:
        if settings.NVI_CACHE_TTL > 0:
            r = _get_redis()
            await r.set(
                cache_key,
                "1" if result else "0",
                ex=settings.NVI_CACHE_TTL,
            )
    except Exception:
        pass

    return result


async def verify_tc_with_nvi(
    db,
    tc_number: str,
    first_name: str,
    last_name: str,
    birth_year: int,
) -> dict:
    """Calls NVI, logs to audit, returns result dict."""
    result = await verify_tc_kimlik(tc_number, first_name, last_name, birth_year)

    from app.modules.audit.service import log_audit
    await log_audit(
        db, "nvi.verification", "identity", f"TC-{tc_number[:3]}*****",
        None, None,
        details={
            "verified": result,
            "method": "nvi_soap",
        },
    )
    await db.commit()

    return {
        "verified": result,
        "method": "nvi_soap",
    }
