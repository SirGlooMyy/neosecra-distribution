"""Fernet encryption layer for firewall API tokens and other secrets.

Per Mutlak Kural #3: firewall API tokens never stored plaintext.
Production MUST set CRYPTO_KEY to a stable Fernet key; otherwise tokens
become unreadable across restarts.
"""
import logging

from cryptography.fernet import Fernet

from app.core.config import ProductionSettingsError, settings

log = logging.getLogger(__name__)
_fernet: Fernet | None = None


def _get_fernet() -> Fernet:
    global _fernet
    if _fernet is None:
        key = settings.CRYPTO_KEY
        if not key:
            if settings.ENVIRONMENT == "production":
                raise ProductionSettingsError(
                    "CRYPTO_KEY must be set in production — encrypted secrets "
                    "would be unreadable after restart."
                )
            log.warning(
                "CRYPTO_KEY not set - generated an ephemeral key. "
                "Encrypted secrets will be unreadable after restart. "
                "Set CRYPTO_KEY in production."
            )
            key = Fernet.generate_key()
        _fernet = Fernet(key)
    return _fernet


def encrypt(plaintext: str) -> str:
    return _get_fernet().encrypt(plaintext.encode()).decode()


def decrypt(ciphertext: str) -> str:
    return _get_fernet().decrypt(ciphertext.encode()).decode()
