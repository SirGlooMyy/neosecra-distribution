from pydantic import BaseModel
from datetime import datetime
from typing import Optional
import uuid


class SyslogRecordBase(BaseModel):
    facility: Optional[int] = None
    severity: Optional[int] = None
    hostname: Optional[str] = None
    app_name: Optional[str] = None
    message: str


class SyslogRecordCreate(SyslogRecordBase):
    tenant_id: Optional[uuid.UUID] = None


class SyslogRecordOut(SyslogRecordBase):
    id: uuid.UUID
    tenant_id: Optional[uuid.UUID] = None
    created_at: datetime

    model_config = {"from_attributes": True}
