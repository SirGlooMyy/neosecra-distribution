import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


CHUNK_STATUS_PENDING = "pending"
CHUNK_STATUS_SIGNED = "signed"
CHUNK_STATUS_UPLOADED = "uploaded"
CHUNK_STATUS_VERIFIED = "verified"
CHUNK_STATUS_FAILED = "failed"
CHUNK_STATUSES = (
    CHUNK_STATUS_PENDING,
    CHUNK_STATUS_SIGNED,
    CHUNK_STATUS_UPLOADED,
    CHUNK_STATUS_VERIFIED,
    CHUNK_STATUS_FAILED,
)


class ArchiveChunk(Base, UUIDPK, TimestampMixin):
    __tablename__ = "archive_chunks"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    period_start: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    period_end: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    log_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    content_hash: Mapped[str] = mapped_column(
        String(64), nullable=False, index=True
    )
    curr_hash: Mapped[str] = mapped_column(
        String(64), nullable=False, index=True
    )
    prev_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    intermediate_hashes: Mapped[dict] = mapped_column(
        JSONB, default=list, nullable=False
    )
    signature_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    signature_time: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    certificate_serial: Mapped[str | None] = mapped_column(
        String(100), nullable=True
    )
    sign_method: Mapped[str | None] = mapped_column(String(20), nullable=True)
    status: Mapped[str] = mapped_column(
        String(20), default=CHUNK_STATUS_PENDING, nullable=False, index=True
    )
    minio_object_key: Mapped[str | None] = mapped_column(
        String(500), nullable=True
    )
    content_size: Mapped[int] = mapped_column(
        BigInteger, default=0, nullable=False
    )
    meta: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
