"""Tenant CRUD business logic. Tenants are the global root resource:
super_admin manages all; everyone else is scoped to their own tenant row.
"""
import uuid

from fastapi import HTTPException, Request, status
from sqlalchemy import false, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.tenants.models import Tenant
from app.modules.tenants.schemas import TenantCreate, TenantUpdate


def _scoped_query(scope: ScopeContext):
    q = select(Tenant)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.allowed and scope.tenant_id:
        return q.where(Tenant.id == scope.tenant_id), True
    return q.where(false()), False  # deny all (fail-closed)


async def list_tenants(db: AsyncSession, scope: ScopeContext) -> list[Tenant]:
    q, _ = _scoped_query(scope)
    result = await db.execute(q.order_by(Tenant.created_at.desc()))
    return list(result.scalars().all())


async def get_tenant(db: AsyncSession, tenant_id: uuid.UUID, scope: ScopeContext) -> Tenant:
    q, allowed = _scoped_query(scope)
    result = await db.execute(q.where(Tenant.id == tenant_id))
    tenant = result.scalar_one_or_none()
    if not tenant:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tenant bulunamadi")
    if not allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu tenant'a erisim yetkiniz yok")
    return tenant


async def create_tenant(
    db: AsyncSession, body: TenantCreate, actor_id: uuid.UUID, request: Request | None = None
) -> Tenant:
    tenant = Tenant(
        name=body.name,
        slug=body.slug,
        domain=body.domain,
        is_root=body.is_root,
        is_demo=body.is_demo,
    )
    db.add(tenant)
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Bu slug zaten kullaniliyor")
    await log_audit(
        db,
        "tenant.created",
        "tenant",
        str(tenant.id),
        str(actor_id),
        request,
        details={"name": body.name, "slug": body.slug, "is_demo": body.is_demo},
    )
    await db.commit()
    await db.refresh(tenant)
    return tenant


async def update_tenant(
    db: AsyncSession, tenant_id: uuid.UUID, body: TenantUpdate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> Tenant:
    tenant = await get_tenant(db, tenant_id, scope)
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(tenant, k, v)
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Bu slug zaten kullaniliyor")
    await log_audit(db, "tenant.updated", "tenant", str(tenant_id), str(actor_id), request, details=data)
    await db.commit()
    await db.refresh(tenant)
    return tenant


async def deactivate_tenant(
    db: AsyncSession, tenant_id: uuid.UUID, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> None:
    tenant = await get_tenant(db, tenant_id, scope)
    tenant.is_active = False
    await log_audit(db, "tenant.deactivated", "tenant", str(tenant_id), str(actor_id), request)
    await db.commit()
