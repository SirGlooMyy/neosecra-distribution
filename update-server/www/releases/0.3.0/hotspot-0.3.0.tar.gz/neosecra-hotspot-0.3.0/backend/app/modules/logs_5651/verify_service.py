"""Archive integrity verification — hash chain, content hash, digital signature.

Three verification levels:
  1. Single archive verify   — recompute content_hash, verify prev_hash link,
                               verify digital signature if present
  2. Full chain verify       — walk the entire chain for a (customer, record_type),
                               detect broken links or tampered records
  3. Export package verify   — verify downloaded evidence package ZIP integrity

The chain verification reuses the same _chain_hash / _period_key primitives
from service.py so the tamper-evidence check is always consistent with the
append-only build pipeline (Mutlak Kural #4 — hash never updated).
"""
from __future__ import annotations

import hashlib
import json
import logging
import uuid
import zipfile
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.logs_5651.models import GENESIS_HASH, ArchiveRecord
from app.modules.logs_5651.schemas import ChainVerifyResult, SingleVerifyResult
from app.modules.logs_5651.service import _chain_hash, _period_key

log = logging.getLogger(__name__)


async def verify_chain_integrity(
    db: AsyncSession,
    customer_id: uuid.UUID,
    record_type: str = "session_archive",
) -> ChainVerifyResult:
    """Walk the full chain for a (customer, record_type) and verify integrity.

    Recomputes every curr_hash from stored fields and checks prev_hash linkage.
    Returns ChainVerifyResult with detailed break information.
    """
    res = await db.execute(
        select(ArchiveRecord)
        .where(
            ArchiveRecord.customer_id == customer_id,
            ArchiveRecord.record_type == record_type,
        )
        .order_by(ArchiveRecord.chain_seq.asc())
    )
    records = list(res.scalars().all())

    if not records:
        return ChainVerifyResult(
            customer_id=customer_id,
            record_type=record_type,
            ok=True,
            total_records=0,
            broken_at=None,
            broken_id=None,
            verified_at=datetime.now(timezone.utc),
            message="Zincir bos (kayit yok).",
        )

    expected_prev = GENESIS_HASH
    for rec in records:
        if rec.prev_hash != expected_prev:
            return ChainVerifyResult(
                customer_id=customer_id,
                record_type=record_type,
                ok=False,
                total_records=len(records),
                broken_at=rec.chain_seq,
                broken_id=rec.id,
                verified_at=datetime.now(timezone.utc),
                message=(
                    f"Zincir kopuk! seq={rec.chain_seq} — prev_hash eslesmiyor. "
                    f"Beklenen: {expected_prev[:16]}..., "
                    f"Kayit: {rec.prev_hash[:16]}... "
                    "(ekleme/silme/degisiklik tespit edildi)"
                ),
            )

        recomputed = _chain_hash(
            rec.prev_hash,
            rec.content_hash,
            _period_key(rec.period_start, rec.period_end),
            rec.record_type,
        )
        if recomputed != rec.curr_hash:
            return ChainVerifyResult(
                customer_id=customer_id,
                record_type=record_type,
                ok=False,
                total_records=len(records),
                broken_at=rec.chain_seq,
                broken_id=rec.id,
                verified_at=datetime.now(timezone.utc),
                message=(
                    f"curr_hash uyusmazligi seq={rec.chain_seq}! "
                    f"Beklenen: {recomputed[:16]}..., "
                    f"Kayit: {rec.curr_hash[:16]}... "
                    "(veri degistirilmis olabilir)"
                ),
            )

        expected_prev = rec.curr_hash

    return ChainVerifyResult(
        customer_id=customer_id,
        record_type=record_type,
        ok=True,
        total_records=len(records),
        broken_at=None,
        broken_id=None,
        verified_at=datetime.now(timezone.utc),
        message=f"Zincir saglam. {len(records)} kayit basariyla dogrulandi.",
    )


async def verify_single_archive(
    db: AsyncSession,
    archive_id: uuid.UUID,
) -> SingleVerifyResult:
    """Verify a single archive record in detail.

    Checks:
      1. content_hash integrity (re-hash stored payload if accessible)
      2. prev_hash linkage (verify against previous record in chain)
      3. Digital signature validity (if signature_value is present)

    Note: content_hash verification without fetching from object store is a
    trust check. For full verification, the original payload must be re-hashed.
    """
    archive = await db.get(ArchiveRecord, archive_id)
    if not archive:
        raise ValueError(f"Arsiv kaydi bulunamadi: {archive_id}")

    issues = []
    content_hash_valid = True
    prev_hash_link_valid = None
    signature_valid = None

    # 1. content_hash — stored hash is the anchor; we can only verify if
    #    we have local access to the payload file
    try:
        content_bytes = _fetch_archive_content(archive)
        if content_bytes is not None:
            computed = hashlib.sha256(content_bytes).hexdigest()
            content_hash_valid = computed == archive.content_hash
            if not content_hash_valid:
                issues.append(f"content_hash uyusmazligi: beklenen={archive.content_hash[:16]}..., hesaplanan={computed[:16]}...")
        else:
            content_hash_valid = True  # skip if payload not accessible
    except Exception as exc:
        log.warning("Arsiv icerigi okunamadi, content_hash atlaniyor: %s", exc)

    # 2. prev_hash linkage
    if archive.chain_seq > 1:
        prev_res = await db.execute(
            select(ArchiveRecord).where(
                ArchiveRecord.customer_id == archive.customer_id,
                ArchiveRecord.record_type == archive.record_type,
                ArchiveRecord.chain_seq == archive.chain_seq - 1,
            )
        )
        prev_rec = prev_res.scalar_one_or_none()
        if prev_rec:
            prev_hash_link_valid = archive.prev_hash == prev_rec.curr_hash
            if not prev_hash_link_valid:
                issues.append(
                    f"prev_hash kopuk: onceki kaydin curr_hash={prev_rec.curr_hash[:16]}..., "
                    f"bu kaydin prev_hash={archive.prev_hash[:16]}..."
                )
        else:
            prev_hash_link_valid = False
            issues.append(f"Onceki zincir kaydi bulunamadi (seq={archive.chain_seq - 1})")
    else:
        prev_hash_link_valid = archive.prev_hash == GENESIS_HASH
        if not prev_hash_link_valid:
            issues.append(f"Ilk kaydin prev_hash'i GENESIS_HASH olmali, mevcut: {archive.prev_hash[:16]}...")

    # 3. Digital signature verification
    signature_valid = None
    if archive.signature_value and archive.certificate_serial:
        try:
            from app.modules.logs_5651.signing_service import verify_signature

            content_to_verify = f"{archive.curr_hash}:{archive.content_hash}:{archive.period_start.isoformat()}:{archive.period_end.isoformat()}"
            content_hash_for_sig = hashlib.sha256(content_to_verify.encode()).hexdigest()

            signature_valid = verify_signature(
                content_hash=content_hash_for_sig,
                signature_value=archive.signature_value,
                certificate_pem=archive.certificate_serial,
            )
            if not signature_valid:
                issues.append("Dijital imza dogrulamasi basarisiz!")
        except Exception as exc:
            log.warning("Imza dogrulama hatasi: %s", exc)
            signature_valid = False
            issues.append(f"Imza dogrulama hatasi: {exc}")
    elif archive.signature_value:
        signature_valid = None
        issues.append("Imza mevcut ancak sertifika bilgisi eksik, dogrulama yapilamadi")

    overall_ok = content_hash_valid and (prev_hash_link_valid is not False) and (signature_valid is not False)

    message = "Dogrulama basarili." if overall_ok else "; ".join(issues) if issues else "Dogrulama basarisiz."

    return SingleVerifyResult(
        archive_id=archive.id,
        chain_seq=archive.chain_seq,
        content_hash_valid=content_hash_valid,
        prev_hash_link_valid=prev_hash_link_valid,
        signature_valid=signature_valid,
        overall_ok=overall_ok,
        message=message,
        verified_at=datetime.now(timezone.utc),
    )


def _fetch_archive_content(archive: ArchiveRecord) -> bytes | None:
    """Read the canonical archive payload bytes from any supported provider."""
    from app.modules.logs_5651.archive_service import read_archive_payload

    return read_archive_payload(archive.content_ref or "")


def verify_export_package(package_path: str) -> dict:
    """Verify a downloaded ZIP evidence package.

    Checks:
      - ZIP structure is valid
      - Required files exist
      - evidence_manifest.json is parsable
      - Package hash integrity (if stored)

    Returns dict with verification result.
    """
    required_files = {
        "session.json",
        "syslog_records.jsonl",
        "radius_events.jsonl",
        "archive_chain.json",
        "evidence_manifest.json",
    }

    try:
        with zipfile.ZipFile(package_path, "r") as zf:
            bad = zf.testzip()
            if bad:
                return {
                    "valid": False,
                    "error": f"ZIP bozuk: {bad}",
                    "checked_at": datetime.now(timezone.utc).isoformat(),
                }

            names = set(zf.namelist())
            missing = required_files - names
            if missing:
                return {
                    "valid": False,
                    "error": f"Eksik dosyalar: {', '.join(sorted(missing))}",
                    "checked_at": datetime.now(timezone.utc).isoformat(),
                }

            with zf.open("evidence_manifest.json") as mf:
                manifest = json.loads(mf.read())
    except zipfile.BadZipFile:
        return {
            "valid": False,
            "error": "Gecersiz ZIP dosyasi",
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }
    except (json.JSONDecodeError, KeyError) as exc:
        return {
            "valid": False,
            "error": f"Manifest okuma hatasi: {exc}",
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }
    except FileNotFoundError:
        return {
            "valid": False,
            "error": f"Dosya bulunamadi: {package_path}",
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }

    return {
        "valid": True,
        "error": None,
        "package_type": manifest.get("package_type"),
        "session_id": manifest.get("session_id"),
        "customer_id": manifest.get("customer_id"),
        "generated_at": manifest.get("generated_at"),
        "files_found": sorted(names),
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }
