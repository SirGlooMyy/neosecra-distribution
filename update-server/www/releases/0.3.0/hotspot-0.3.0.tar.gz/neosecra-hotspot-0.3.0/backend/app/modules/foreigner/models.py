"""Models for foreigner/passport module."""
