"""Report endpoints. Read = report.read (summary + CSV/PDF export).
Scheduler + OLAP endpoints also live here.

All output is scope-filtered to the caller (Mutlak Kural #2). CSV is always
available (stdlib); PDF requires reportlab and returns 501 if missing.
"""
import io
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import FileResponse, StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.reports import service
from app.modules.reports.models import ReportArchive, ReportJob
from app.modules.reports.olap_service import OlapQuery, get_report_templates, parse_dimension, query_olap
from app.modules.reports.scheduler_service import (
    create_job,
    delete_job,
    generate_report,
    get_job,
    list_jobs,
    send_report_email,
    update_job,
)

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


async def _resolve_scope_customer_id(db: AsyncSession, scope: ScopeContext, customer_id: uuid.UUID | None) -> uuid.UUID | None:
    """If customer_id is given, verify scope access. Otherwise return scope's default."""
    if customer_id:
        if scope.level == TenantLevel.GLOBAL:
            return customer_id
        if scope.level == TenantLevel.PARTNER and scope.partner_id:
            cust = await db.get(Customer, customer_id)
            if not cust or str(cust.partner_id) != str(scope.partner_id):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu musteri sizin kapsaminizda degil")
            return customer_id
        if scope.level == TenantLevel.CUSTOMER:
            if str(scope.customer_id) != str(customer_id):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Baska musteri verisine erisemezsiniz")
            return customer_id
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Erisim yetkiniz yok")
    if scope.customer_id:
        return scope.customer_id
    if scope.level == TenantLevel.GLOBAL:
        return await resolve_installation_customer(db)
    return None


# --- Summary & Export (existing) ---

@router.get("", summary="Get report summary statistics for a date range", description="Returns aggregated summary data including session counts, active guests, and usage metrics within the specified date range. Data is scoped to the caller's tenant permissions. Requires the report.read permission.")
async def report_summary(
    date_from: datetime | None = Query(None),
    date_to: datetime | None = Query(None),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    return await service.summary(db, scope_for(user), date_from, date_to)


@router.get("/sessions/export", summary="Export guest sessions data in CSV or PDF format", description="Exports guest session records within the specified date range. Supports CSV and PDF output formats selected via the format query parameter. Returns a downloadable file. Requires the report.read permission.")
async def export_sessions(
    format: str = Query("csv"),
    date_from: datetime | None = Query(None),
    date_to: datetime | None = Query(None),
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    fmt = (format or "csv").lower()

    if fmt == "csv":
        text = await service.build_sessions_csv(db, scope, date_from, date_to)
        return StreamingResponse(
            io.BytesIO(text.encode("utf-8-sig")),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="sessions.csv"'},
        )
    if fmt == "pdf":
        data = await service.build_sessions_pdf(db, scope, date_from, date_to)
        return StreamingResponse(
            io.BytesIO(data),
            media_type="application/pdf",
            headers={"Content-Disposition": 'attachment; filename="sessions.pdf"'},
        )
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="format csv veya pdf olmali",
    )


@router.get("/differentiator/export", summary="Export differentiator report (5651 evidence, IP-identity, venue density, operator audit, quota/license)", description="Exports specialized differentiator reports in CSV or PDF format. Requires the report.read permission.")
async def export_differentiator_report(
    report_type: str = Query(..., description="5651_evidence | ip_identity_matrix | venue_density | operator_audit | quota_license_usage"),
    format: str = Query("csv"),
    date_from: datetime | None = Query(None),
    date_to: datetime | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    fmt = (format or "csv").lower()

    if fmt == "csv":
        text = await service.build_differentiator_csv(db, scope, report_type, date_from, date_to)
        return StreamingResponse(
            io.BytesIO(text.encode("utf-8-sig")),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{report_type}_report.csv"'},
        )
    if fmt == "pdf":
        data = await service.build_differentiator_pdf(db, scope, report_type, date_from, date_to)
        return StreamingResponse(
            io.BytesIO(data),
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{report_type}_report.pdf"'},
        )
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="format csv veya pdf olmali",
    )


@router.get(
    "/quick/export",
    summary="Export an operator quick report",
    description="One-click Analyzer presets such as 30-day VPN activity, top bandwidth users and firewall security summary.",
)
async def export_quick_report(
    report_type: str = Query(..., description="vpn_activity_30d | top_bandwidth_users_30d | firewall_security_30d | captive_portal_usage_30d"),
    format: str = Query("pdf"),
    days: int = Query(30, ge=1, le=366),
    date_from: datetime | None = Query(None),
    date_to: datetime | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Generate a ready-to-share report from the same scoped data as Analyzer.

    The preset is computed once and then rendered to CSV/PDF, so users never
    see different numbers depending on the selected download format.
    """
    _require(user, "report.read")
    report = await service.build_quick_report(
        db,
        scope_for(user),
        report_type,
        days=days,
        date_from=date_from,
        date_to=date_to,
    )
    fmt = (format or "pdf").lower()
    safe_name = report_type.replace("_", "-")
    if fmt == "csv":
        text = service.build_quick_csv(report)
        return StreamingResponse(
            io.BytesIO(text.encode("utf-8-sig")),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{safe_name}.csv"'},
        )
    if fmt == "pdf":
        data = service.build_quick_pdf(report)
        return StreamingResponse(
            io.BytesIO(data),
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{safe_name}.pdf"'},
        )
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="format csv veya pdf olmali")



# --- Report Job Scheduler ---

@router.get("/jobs", summary="List scheduled report jobs", description="Returns all configured report generation jobs for the specified customer. Includes schedule, format, and last-run information. Requires the report.read permission.")
async def list_report_jobs(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    resolved_cid = await _resolve_scope_customer_id(db, scope, customer_id)
    return await list_jobs(db, resolved_cid)


@router.post("/jobs", status_code=201, summary="Create a new scheduled report job", description="Creates a report generation job with schedule, format, and recipient configuration. The job will automatically generate reports according to its schedule. Requires the report.write permission.")
async def create_report_job(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.write")
    scope = scope_for(user)
    cid = body.get("customer_id", scope.customer_id)
    body["customer_id"] = await _resolve_scope_customer_id(db, scope, cid)
    body["created_by"] = user.id
    return await create_job(db, body)


async def _verify_job_scope(db: AsyncSession, scope: ScopeContext, job_id: uuid.UUID) -> ReportJob:
    job = await get_job(db, job_id)
    await _resolve_scope_customer_id(db, scope, job.customer_id)
    return job


@router.put("/jobs/{job_id}", summary="Update a scheduled report job configuration", description="Modifies the settings of an existing report job including schedule, format, and email recipients. Requires the report.write permission.")
async def update_report_job(
    job_id: uuid.UUID,
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.write")
    scope = scope_for(user)
    await _verify_job_scope(db, scope, job_id)
    return await update_job(db, job_id, body)


@router.delete("/jobs/{job_id}", status_code=204, summary="Delete a scheduled report job", description="Removes the specified report job and its schedule. Previously generated report archives are preserved. Requires the report.write permission.")
async def delete_report_job(
    job_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.write")
    scope = scope_for(user)
    await _verify_job_scope(db, scope, job_id)
    await delete_job(db, job_id)


@router.post("/jobs/{job_id}/run-now", summary="Trigger immediate execution of a scheduled report job", description="Manually triggers the specified report job to run immediately instead of waiting for its scheduled time. The generated report is emailed to configured recipients upon completion. Requires the report.write permission.")
async def run_job_now(
    job_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.write")
    scope = scope_for(user)
    await _verify_job_scope(db, scope, job_id)
    archive = await generate_report(db, job_id)
    if archive.status == "ready":
        await send_report_email(archive)
    return {
        "status": archive.status,
        "archive_id": str(archive.id),
        "error": archive.error_message,
    }


# --- Archives ---

@router.get("/archives", summary="List generated report archives", description="Returns previously generated report archives with optional filters by job and customer. Each archive entry includes format, generation timestamp, and download availability. Requires the report.read permission.")
async def list_report_archives(
    job_id: uuid.UUID | None = Query(None),
    customer_id: uuid.UUID | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    resolved_cid = await _resolve_scope_customer_id(db, scope, customer_id)
    q = select(ReportArchive).order_by(ReportArchive.generated_at.desc()).limit(limit)
    if resolved_cid:
        q = q.where(ReportArchive.customer_id == resolved_cid)
    elif scope.level == TenantLevel.LOCATION and scope.location_id:
        loc = await db.get(Location, scope.location_id)
        if not loc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Lokasyon bulunamadi")
        q = q.where(ReportArchive.customer_id == loc.customer_id)
    if job_id:
        q = q.where(ReportArchive.job_id == job_id)
    res = await db.execute(q)
    return list(res.scalars().all())


@router.get("/archives/{archive_id}/download", summary="Download a generated report archive file", description="Downloads the specified report archive as a file. Supports both CSV and PDF formats depending on the original generation settings. Requires the report.read permission.")
async def download_archive(
    archive_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    archive = await db.get(ReportArchive, archive_id)
    if not archive:
        raise HTTPException(status_code=404, detail="Arsiv bulunamadi")
    await _resolve_scope_customer_id(db, scope, archive.customer_id)
    if archive.status != "ready":
        raise HTTPException(status_code=400, detail="Rapor henuz hazir degil")

    ref = archive.file_ref
    if ref.startswith("local:"):
        path = ref[6:]
        media = "application/pdf" if archive.format == "pdf" else "text/csv"
        return FileResponse(path, media_type=media, filename=f"report_{archive.id}.{archive.format}")
    if ref.startswith("none:"):
        raise HTTPException(status_code=501, detail="Dosya saklanmamis (dev modu)")
    if ref.startswith("minio:"):
        raise HTTPException(status_code=501, detail="MinIO indirme henuz implemente edilmedi")

    raise HTTPException(status_code=501, detail="Dosya kaynagi bilinmiyor")


# --- Templates ---

@router.get("/templates", summary="List available report template definitions", description="Returns all available report templates that can be used for generating reports. Optionally filtered by data source type. Requires the report.read permission.")
async def list_report_templates(
    source: str | None = Query(None),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    templates = get_report_templates(include_presets=True)
    if source:
        templates = [t for t in templates if t.get("source") == source]
    return templates


# --- OLAP ---

@router.post("/olap/query", summary="Execute an OLAP query against session data", description="Runs a multi-dimensional OLAP query with specified dimensions, measures, filters, and granularity. Supports session data analysis for reporting and dashboards. Requires the report.read permission.")
async def olap_query(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "report.read")
    scope = scope_for(user)
    cid = body.get("customer_id")
    resolved_cid = await _resolve_scope_customer_id(db, scope, cid)
    q = OlapQuery(
        dimensions=[parse_dimension(d) for d in body.get("dimensions", [])],
        measures=body.get("measures", ["count"]),
        filters=body.get("filters", {}),
        date_from=body.get("date_from"),
        date_to=body.get("date_to"),
        granularity=body.get("granularity", "day"),
        source=body.get("source", "sessions"),
        customer_id=resolved_cid,
    )
    return await query_olap(db, q)
