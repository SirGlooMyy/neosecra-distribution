"""Sophos XG / UTM / Central API adapter.

Supports Sophos XG (SFOS) REST API at /webapi/ and Sophos Central API.
Uses API key or Basic auth depending on the device type.
"""
from __future__ import annotations

import hashlib
import shlex
import time
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class SophosAdapter(FirewallAdapter):
    vendor = "sophos"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 4444
        host = config.api_host
        self._base_url = f"https://{host}:{port}"
        self._api_key = config.api_token or ""
        self._headers = {"Accept": "application/json"}
        self._xg_api_base = f"{self._base_url}/webapi"

    async def _xg_request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._xg_api_base}/{endpoint.lstrip('/')}"
        p = dict(params or {})
        ts = str(int(time.time()))
        raw = f"{self._api_key}{ts}"
        p["t"] = ts
        p["keyid"] = hashlib.sha256(raw.encode()).hexdigest()
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=p, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"Sophos XG {method} {endpoint} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        data = resp.json()
        if isinstance(data, dict) and data.get("Status", {}).get("Code") != "200":
            msg = data.get("Status", {}).get("Message", "sophos error")
            raise AdapterError(f"Sophos XG {endpoint}: {msg}")
        return data

    async def _central_request(
        self,
        method: str,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"https://api.central.sophos.com/{endpoint.lstrip('/')}"
        headers = {
            **self._headers,
            "Authorization": f"Bearer {self._api_key}",
        }
        async with httpx.AsyncClient(verify=True, timeout=timeout) as client:
            resp = await client.request(method, url, headers=headers, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"Sophos Central {method} {endpoint} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            radius_authentication=True,
            radius_accounting=True,
            mac_auth_bypass=True,
            active_session_query=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            data = await self._xg_request("GET", "status")
            return AdapterResult(
                ok=True,
                message="connected: Sophos XG",
                data=data,
            )
        except (AdapterError, httpx.HTTPError):
            pass
        try:
            data = await self._central_request("GET", "v1/tenants")
            return AdapterResult(
                ok=True,
                message="connected: Sophos Central",
                data=data,
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        data = await self._xg_request("GET", "status")
        info = data.get("Status", {})
        return {
            "hostname": info.get("Hostname", ""),
            "model": info.get("Model", ""),
            "serial_number": info.get("Serial", ""),
            "firmware_version": info.get("FirmwareVersion", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._xg_request("GET", "interfaces")
        results: list[dict[str, Any]] = []
        for iface in data.get("Interfaces", []):
            results.append({
                "name": iface.get("Name", ""),
                "ip": iface.get("IPAddress", ""),
                "type": iface.get("Type", ""),
                "status": "up" if iface.get("Status") == "UP" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._xg_request("GET", "captiveportal/status")
            cp = data.get("CaptivePortal", {})
            return {
                "enabled": cp.get("Enabled", False),
                "redirect_url": cp.get("RedirectURL", ""),
                "auth_method": cp.get("AuthMethod", ""),
            }
        except AdapterError:
            return {"enabled": False}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._xg_request("GET", "firewall/sessions")
        results: list[dict[str, Any]] = []
        for s in data.get("Sessions", []):
            results.append({
                "ip": s.get("SourceIP", ""),
                "user": s.get("Username", ""),
                "protocol": s.get("Protocol", ""),
                "src_port": s.get("SourcePort"),
                "dst_port": s.get("DestinationPort"),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._xg_request("GET", "network/arp")
        results: list[dict[str, Any]] = []
        for entry in data.get("ARPEntries", []):
            results.append({
                "ip": entry.get("IPAddress", ""),
                "mac": entry.get("MACAddress", ""),
                "interface": entry.get("Interface", ""),
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        payload = {
            "Name": name,
            "SourceIP": ip,
            "DestinationIP": "any",
            "Service": "any",
            "Action": "ACCEPT",
            "Comment": self._guest_comment(session),
        }
        try:
            await self._xg_request("POST", "firewall/rule", json=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"rule": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            await self._xg_request("DELETE", f"firewall/rule/{name}")
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "sophos", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("host")
        parsed["event_type"] = parsed.get("type") or parsed.get("log_type")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        return parsed
