"""SmsOtp = a one-time code sent to a guest phone during captive portal auth.

Scope binding: every OTP is tied to a customer (+ optional location) derived
from the device the guest is behind. This binds a code to a physical site and
prevents cross-site replay (Mutlak Kural #1/#2 — tenant isolation extends to
the guest auth path).

Security:
  * the code itself is NEVER stored plaintext — only a salted hash (see
    service._hash_code). The plaintext exists only in-memory and in the
    delivery channel (Mutlak Kural #3 spirit: secrets not at rest).
  * attempts are capped (SMS_OTP_MAX_ATTEMPTS) and send-frequency is rate
    limited per phone via Redis (core.security.rate_limit_check).
"""
import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Integer, JSON, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk

PURPOSE_PORTAL = "portal"


class SmsOtp(Base, UUIDPK, TimestampMixin):
    __tablename__ = "sms_otps"

    # Scope axis: site the guest is physically at (resolved from the device).
    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)

    # Normalized E.164 phone (e.g. +905xxxxxxxxx). Stored for lookup; masked in
    # audit/logs to limit PII exposure.
    phone: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    # "salt$sha256hex" — never the plaintext code.
    code_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    purpose: Mapped[str] = mapped_column(String(20), default=PURPOSE_PORTAL, nullable=False, index=True)

    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3, nullable=False)

    verified: Mapped[bool] = mapped_column(default=False, nullable=False)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    request_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    delivered: Mapped[bool] = mapped_column(default=False, nullable=False)
    deliver_error: Mapped[str | None] = mapped_column(String(500), nullable=True)
    # Best-effort delivery count for abuse analytics (number of SMS sent).
    send_count: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)


class SmsConfig(Base, UUIDPK, TimestampMixin):
    __tablename__ = "sms_configs"

    customer_id: Mapped[uuid.UUID | None] = fk("customers", ondelete="CASCADE", nullable=True)
    provider: Mapped[str] = mapped_column(String(50), default="console", nullable=False) # netgsm, vatansms, twilio, muttl, relateddigital, http, console
    
    # Credentials (encrypted)
    username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    password_encrypted: Mapped[str | None] = mapped_column(String(500), nullable=True)
    api_key_encrypted: Mapped[str | None] = mapped_column(String(500), nullable=True)
    # Some gateways (for example Ileti Merkezi and Vonage) use a second
    # credential such as an API hash/secret.  Keep it encrypted just like the
    # primary key instead of forcing operators to put it in a generic body.
    api_secret_encrypted: Mapped[str | None] = mapped_column(String(500), nullable=True)
    sender: Mapped[str | None] = mapped_column(String(100), nullable=True)
    
    # Custom HTTP gateway settings
    http_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    http_token_encrypted: Mapped[str | None] = mapped_column(String(500), nullable=True)
    http_template: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    # Non-secret provider options and generic HTTP field mappings.  Examples:
    # {"encoding":"TR","iysfilter":"0","appname":"Hotspot",
    #  "auth_type":"bearer","payload_format":"json"}
    provider_options: Mapped[dict | None] = mapped_column(JSON, nullable=True)
