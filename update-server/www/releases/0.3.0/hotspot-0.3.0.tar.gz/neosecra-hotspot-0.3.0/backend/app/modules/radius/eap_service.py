"""EAP-PEAP / EAP-TTLS sertifika yonetimi.

Kendi kendine imzalanan CA ile sunucu sertifikasi olusturur.
FreeRADIUS EAP modulunde kullanilmak uzere cert deposuna yazar.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from app.core.config import settings

log = logging.getLogger(__name__)

CA_CN = "Hotspot EAP Root CA"
SERVER_CN_PREFIX = "Hotspot EAP Server"
KEY_SIZE = 2048
CA_VALID_DAYS = 365 * 10
SERVER_VALID_DAYS = 365 * 2


def _ensure_cert_dir() -> str:
    """Sertifika dizinini yoksa olustur, don."""
    d = settings.EAP_CERT_DIR
    os.makedirs(d, exist_ok=True)
    return d


def _generate_ca() -> tuple[x509.Certificate, rsa.RSAPrivateKey]:
    """Kok CA olustur — kendi kendine imzali."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=KEY_SIZE)
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, CA_CN),
    ])
    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + timedelta(days=CA_VALID_DAYS))
        .add_extension(
            x509.BasicConstraints(ca=True, path_length=None), critical=True,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                key_cert_sign=True,
                key_encipherment=False,  # type: ignore[call-arg]
                content_commitment=False,
                data_encipherment=False,
                crl_sign=True,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .sign(key, hashes.SHA256())
    )
    return cert, key


def _generate_server_cert(
    ca_cert: x509.Certificate,
    ca_key: rsa.RSAPrivateKey,
    san_dns: list[str] | None = None,
) -> tuple[x509.Certificate, rsa.RSAPrivateKey]:
    """CA tarafindan imzalanmis EAP sunucu sertifikasi."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=KEY_SIZE)
    subject = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, SERVER_CN_PREFIX),
    ])
    now = datetime.now(timezone.utc)
    sans = [x509.DNSName(s) for s in (san_dns or ["eap.hotspot.local"])]
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + timedelta(days=SERVER_VALID_DAYS))
        .add_extension(
            x509.BasicConstraints(ca=False, path_length=None), critical=True,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                key_cert_sign=False,
                key_encipherment=True,  # type: ignore[call-arg]
                content_commitment=False,
                data_encipherment=False,
                crl_sign=False,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.ExtendedKeyUsage([x509.OID_SERVER_AUTH]), critical=True,
        )
        .add_extension(
            x509.SubjectAlternativeName(sans), critical=False,
        )
        .sign(ca_key, hashes.SHA256())
    )
    return cert, key


def _write_pem(path: str, data: bytes) -> None:
    with open(path, "wb") as f:
        f.write(data)
    os.chmod(path, 0o600)
    log.info("Yazildi: %s", path)


def generate_eap_certs(san_dns: list[str] | None = None) -> dict[str, str]:
    """CA + sunucu sertifika zincirini olustur ve dosyaya yaz.

    Donus:
        {
            "ca_cert_path": "...",
            "ca_key_path": "...",
            "server_cert_path": "...",
            "server_key_path": "...",
        }
    """
    cert_dir = _ensure_cert_dir()
    ca_cert, ca_key = _generate_ca()
    srv_cert, srv_key = _generate_server_cert(ca_cert, ca_key, san_dns)

    ca_cert_path = os.path.join(cert_dir, "eap-ca.pem")
    ca_key_path = os.path.join(cert_dir, "eap-ca-key.pem")
    srv_cert_path = os.path.join(cert_dir, "eap-server.pem")
    srv_key_path = os.path.join(cert_dir, "eap-server-key.pem")

    _write_pem(ca_cert_path, ca_cert.public_bytes(serialization.Encoding.PEM))
    _write_pem(ca_key_path, ca_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    ))
    _write_pem(srv_cert_path, srv_cert.public_bytes(serialization.Encoding.PEM))
    _write_pem(srv_key_path, srv_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    ))

    return {
        "ca_cert_path": ca_cert_path,
        "ca_key_path": ca_key_path,
        "server_cert_path": srv_cert_path,
        "server_key_path": srv_key_path,
    }


def get_cert_status() -> dict:
    """Sertifika dosyalarinin varlik ve gecerlilik bilgisi."""
    cert_dir = settings.EAP_CERT_DIR
    paths = {
        "ca_cert": os.path.join(cert_dir, "eap-ca.pem"),
        "ca_key": os.path.join(cert_dir, "eap-ca-key.pem"),
        "server_cert": os.path.join(cert_dir, "eap-server.pem"),
        "server_key": os.path.join(cert_dir, "eap-server-key.pem"),
    }
    result: dict[str, object] = {}
    for name, path in paths.items():
        if not os.path.isfile(path):
            result[name] = {"exists": False}
            continue
        st = os.stat(path)
        info: dict[str, object] = {
            "exists": True,
            "size": st.st_size,
            "modified": datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat(),
        }
        if name.endswith("_cert"):
            try:
                with open(path, "rb") as f:
                    crt = x509.load_pem_x509_certificate(f.read())
                info["subject"] = crt.subject.rfc4514_string()
                info["issuer"] = crt.issuer.rfc4514_string()
                info["not_valid_before"] = crt.not_valid_before.isoformat()
                info["not_valid_after"] = crt.not_valid_after.isoformat()
                info["expired"] = crt.not_valid_after < datetime.now(timezone.utc)
            except Exception as exc:
                info["parse_error"] = str(exc)
        result[name] = info
    return result
