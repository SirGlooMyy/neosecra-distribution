"""Public marketing content service.

The public site is versioned data, not static HTML. Release notes, downloadable
bundles, knowledge base items and partner/trial inquiry captures all live here.
"""
from __future__ import annotations

import hashlib
import io
import json
import secrets
import re
import unicodedata
import uuid
import zipfile
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy import update as sql_update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.devices.models import Device
from app.modules.licensing.models import CustomerLicense
from app.modules.locations.models import Location
from app.modules.portal.models import METHOD_VOUCHER, PortalTemplate
from app.modules.public_content.models import PublicAsset, PublicInquiry
from app.modules.public_content.schemas import (
    PublicAssetOut,
    PublicBrandOut,
    PublicInquiryCreate,
    PublicInquiryOut,
    PublicAssetUpsert,
    PublicMarketplaceOut,
    PublicStatsOut,
    PublicTrialProvisionOut,
)
from app.modules.tenants.models import Tenant
from app.modules.vouchers.models import STATUS_EXPIRED, STATUS_PENDING, Voucher, VoucherBatch

PUBLIC_SECTIONS = ("release_notes", "downloads", "docs", "kb", "partner")

DEFAULT_BRAND = PublicBrandOut(
    name="Hotspot Logging Suite",
    tagline="SignLogger ve Subgate sınıfı public yüzey, versioned içerik ve trial akışı.",
    summary="Yasal loglama, captive portal, RADIUS ve partner onboarding tek platformda.",
    support_email="support@hotspot.io",
    sales_email="partner@hotspot.io",
    portal_url="/login",
    version=settings.VERSION,
)

_DEFAULT_TS = datetime(2026, 7, 13, 0, 0, tzinfo=timezone.utc)

_TRIAL_LICENSE_DAYS = 14
_TRIAL_LICENSE_PLAN = "trial"
_TRIAL_VOUCHER_PREFIX = "TRIAL"
_TRIAL_THEME = {
    "primary_color": "#1e293b",
    "secondary_color": "#2563eb",
    "bg_color": "#f8fafc",
    "text_color": "#0f172a",
    "font_family": "'Inter', 'Segoe UI', sans-serif",
    "logo_style": "square",
    "button_style": "rounded",
    "layout": "centered",
    "bg_image_url": "",
}


def _slugify(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value or "")
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", ascii_text.lower()).strip("-")
    return slug or "trial"


def _generate_voucher_code(prefix: str = _TRIAL_VOUCHER_PREFIX) -> str:
    token = secrets.token_urlsafe(6).upper().replace("_", "").replace("-", "")
    return f"{prefix}-{token}"


def _hash_voucher_code(code: str) -> str:
    return hashlib.sha256(code.encode()).hexdigest()


def _parse_optional_iso_datetime(value: object | None) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        parsed = value
    else:
        try:
            parsed = datetime.fromisoformat(str(value))
        except ValueError:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


_DEFAULT_ASSET_DEFS: list[dict] = [
    {
        "section": "release_notes",
        "slug": "hotspot-platform",
        "version": settings.VERSION,
        "title": f"Hotspot Platform {settings.VERSION}",
        "summary": "Public content API, versioned downloads ve trial onboarding ilk sürümü.",
        "body": "Bu sürümde public içerikler backend verisine bağlandı, demo/trial talep formu ve versioned download paketi eklendi.",
        "category": "Release Notes",
        "sort_order": 100,
        "checksum": f"release-{settings.VERSION}",
        "file_size_kb": 0,
        "meta": {
            "audience": "all",
            "release_type": "feature",
            "channel": "stable",
            "status": "published",
            "minimum_version": "0.1.0",
            "is_mandatory": False,
            "upgrade_steps": [
                "Backend servisini yeni build ile yeniden başlatın.",
                "Public marketplace ve update center sayfalarını doğrulayın.",
            ],
        },
    },
    {
        "section": "downloads",
        "slug": "site-bridge-connector-linux-x64",
        "version": "2.4.1",
        "title": "Site Bridge Connector (Linux / x64)",
        "category": "Agent",
        "summary": "Yerel ağ ile Hotspot arasındaki güvenli köprü ajanı.",
        "body": "Firewall ve syslog kaynaklarını buluta güvenli şekilde bağlayan site bridge paketi.",
        "asset_url": None,
        "checksum": "d2a4b89e5f0c1",
        "file_size_kb": 18200,
        "sort_order": 90,
        "meta": {"bundle": "site-bridge", "platform": "linux-x64"},
    },
    {
        "section": "downloads",
        "slug": "5651-verification-tool",
        "version": "1.1.0",
        "title": "5651 XML Damga Doğrulayıcı",
        "category": "CLI Tool",
        "summary": "İmzalı log paketlerini çevrimdışı doğrulayan yardımcı araç.",
        "body": "KamuSM zaman damgalı 5651 arşiv paketlerini doğrulamak için kullanılan masaüstü/CLI bundle.",
        "asset_url": None,
        "checksum": "a1c3f90b8d2e4",
        "file_size_kb": 8500,
        "sort_order": 80,
        "meta": {"bundle": "verify-tool", "platform": "desktop"},
    },
    {
        "section": "docs",
        "slug": "quick-start",
        "version": "1.0.0",
        "title": "Hotspot Hızlı Başlangıç Kılavuzu",
        "category": "Başlangıç & Kurulum",
        "summary": "Sistemin genel mimarisi, gereksinimler ve ilk kurulum adımları.",
        "body": "Hotspot platformu misafir erişimini, 5651 uyumlu loglamayı ve captive portal akışlarını tek operasyonda toplar.",
        "sort_order": 100,
        "meta": {"doc_type": "guide"},
    },
    {
        "section": "docs",
        "slug": "site-bridge-setup",
        "version": "1.0.0",
        "title": "Site Bridge Ajan Kurulumu",
        "category": "Başlangıç & Kurulum",
        "summary": "SaaS platformu ile yerel cihazlar arasında güvenli köprü bağlantısı.",
        "body": "Site Bridge ajanı firewall, syslog ve correlation kaynaklarını güvenli bir tünel üzerinden bağlar.",
        "sort_order": 90,
        "meta": {"doc_type": "guide"},
    },
    {
        "section": "docs",
        "slug": "5651-signing-rules",
        "version": "1.0.0",
        "title": "5651 Log İmzalama Kuralları",
        "category": "5651 Sayılı Kanun & Yasal Uyum",
        "summary": "TÜBİTAK KamuSM zaman damgası entegrasyonu.",
        "body": "Yasal log paketleri imzalanır, hash zinciri korunur ve doğrulama servisleri ile bütünlük kontrolü yapılır.",
        "sort_order": 80,
        "meta": {"doc_type": "compliance"},
    },
    {
        "section": "docs",
        "slug": "fortigate-integration",
        "version": "1.0.0",
        "title": "FortiGate Entegrasyon Kılavuzu",
        "category": "Cihaz Entegrasyonları",
        "summary": "FortiGate Captive Portal ve Syslog ayarları.",
        "body": "FortiGate, Palo Alto ve benzeri firewall yüzeyleriyle entegrasyon akışları bu modülde standartlaştırılır.",
        "sort_order": 70,
        "meta": {"doc_type": "integration"},
    },
    {
        "section": "kb",
        "slug": "faq-network-onboarding",
        "version": "1.0.0",
        "title": "Ağda İlk Kurulum Sorunları",
        "category": "Sık Sorulan Sorular",
        "summary": "Cihaz görünmüyor, portal açılmıyor ve login akışı çalışmıyor soruları.",
        "body": "Önce cihazın aktif ve lokasyona bağlı olduğunu doğrulayın. Ardından portal template ve firewall redirect ayarlarını kontrol edin.",
        "sort_order": 100,
        "meta": {"kb_type": "faq"},
    },
    {
        "section": "kb",
        "slug": "faq-5651-signing",
        "version": "1.0.0",
        "title": "5651 İmzalama Hatası Nasıl Çözülür",
        "category": "5651 & Yasal Uyum",
        "summary": "İmza zinciri, zaman damgası ve arşiv doğrulama hataları.",
        "body": "İmzalı paketlerde zincir bozuluyorsa önce worker loglarını, certificate serial kayıtlarını ve verify servisini kontrol edin.",
        "sort_order": 90,
        "meta": {"kb_type": "troubleshooting"},
    },
    {
        "section": "kb",
        "slug": "faq-support-contact",
        "version": "1.0.0",
        "title": "Destek Talebi Açma ve Eskalasyon",
        "category": "Destek Süreçleri",
        "summary": "Sorun bildirimi, önceliklendirme ve iletişim kanalları.",
        "body": "Teknik sorunlarda support@hotspot.io adresine, satış ve iş ortaklığı taleplerinde partner@hotspot.io adresine ulaşabilirsiniz.",
        "sort_order": 80,
        "meta": {"kb_type": "contact"},
    },
    {
        "section": "partner",
        "slug": "partner-program",
        "version": "2026.1",
        "title": "İş Ortaklığı Programı",
        "category": "Partner",
        "summary": "White-label, teknik destek ve demo/trial onboarding paketi.",
        "body": "Bayi portali, özel domain, satış desteği ve trial ortamı ile iş ortaklarına hazır paket.",
        "sort_order": 100,
        "meta": {"audience": "partner"},
    },
]


def _default_assets() -> list[PublicAssetOut]:
    out: list[PublicAssetOut] = []
    now = _DEFAULT_TS
    for item in _DEFAULT_ASSET_DEFS:
        asset_id = uuid.uuid5(uuid.NAMESPACE_URL, f"hotspot-public:{item['section']}:{item['slug']}:{item['version']}")
        asset_url = item.get("asset_url") or _asset_url_for_section(
            item["section"],
            item["slug"],
            item["version"],
            workflow_status="published",
        )
        meta = dict(item.get("meta", {}))
        meta.setdefault("workflow_status", "published")
        out.append(
            PublicAssetOut(
                id=asset_id,
                section=item["section"],
                slug=item["slug"],
                version=item["version"],
                title=item["title"],
                category=item.get("category"),
                summary=item.get("summary"),
                body=item["body"],
                asset_url=asset_url,
                checksum=item.get("checksum"),
                file_size_kb=item.get("file_size_kb"),
                is_current=True,
                sort_order=item.get("sort_order", 0),
                workflow_status=meta.get("workflow_status"),
                meta=meta,
                created_at=now,
                updated_at=now,
            )
        )
    return out


def _download_path(slug: str, version: str) -> str:
    return f"/api/v1/public-content/downloads/{slug}/download?version={version}"


def release_download_path(slug: str, version: str) -> str:
    return f"/api/v1/public-content/releases/{slug}/download?version={version}"


def _asset_url_for_section(
    section: str,
    slug: str,
    version: str,
    *,
    workflow_status: str | None = None,
) -> str | None:
    if section == "downloads":
        return _download_path(slug, version)
    if section == "release_notes" and workflow_status in {"published", "archived"}:
        return release_download_path(slug, version)
    return None


def _workflow_status_for(asset) -> str:
    meta = getattr(asset, "meta", None) or {}
    raw = meta.get("workflow_status")
    if raw:
        return str(raw)
    return "published" if getattr(asset, "is_current", False) else "draft"


def _group_assets(assets: list[PublicAssetOut]) -> dict[str, list[PublicAssetOut]]:
    grouped: dict[str, list[PublicAssetOut]] = {section: [] for section in PUBLIC_SECTIONS}
    for asset in assets:
        workflow_status = _workflow_status_for(asset)
        grouped.setdefault(asset.section, []).append(
            asset.model_copy(
                update={
                    "asset_url": asset.asset_url
                    or _asset_url_for_section(
                        asset.section,
                        asset.slug,
                        asset.version,
                        workflow_status=workflow_status,
                    ),
                }
            )
        )

    for section, rows in grouped.items():
        rows.sort(key=lambda a: (a.sort_order, a.created_at), reverse=True)
        grouped[section] = rows
    return grouped


async def list_public_assets(db: AsyncSession) -> list[PublicAssetOut]:
    stmt = (
        select(PublicAsset)
        .where(PublicAsset.is_current.is_(True))
        .order_by(PublicAsset.section, PublicAsset.sort_order.desc(), PublicAsset.created_at.desc())
    )
    result = await db.execute(stmt)
    rows = list(result.scalars().all())
    if not rows:
        return _default_assets()

    assets = [PublicAssetOut.model_validate(row) for row in rows]
    return [
        asset.model_copy(
            update={
                "asset_url": asset.asset_url
                or _asset_url_for_section(
                    asset.section,
                    asset.slug,
                    asset.version,
                    workflow_status=_workflow_status_for(asset),
                ),
                "workflow_status": _workflow_status_for(asset),
                "meta": {
                    **(asset.meta or {}),
                    "workflow_status": _workflow_status_for(asset),
                },
            }
        )
        for asset in assets
    ]


async def get_marketplace_snapshot(db: AsyncSession) -> PublicMarketplaceOut:
    assets = await list_public_assets(db)
    grouped = _group_assets(assets)

    release_notes = grouped.get("release_notes", [])
    downloads = grouped.get("downloads", [])
    docs = grouped.get("docs", [])
    kb = grouped.get("kb", [])
    partner = grouped.get("partner", [])
    featured_release = release_notes[0] if release_notes else None

    highlights = [
        featured_release.summary if featured_release and featured_release.summary else (
            featured_release.body if featured_release else "Versioned public içerikler backend üzerinden yayınlanıyor."
        ),
        f"{len(downloads)} versioned indirme paketi hazır.",
        f"{len(docs)} knowledge base makalesi ve entegrasyon rehberi yayınlı.",
        f"{len(kb)} destek makalesi ve contact kartı hazır.",
    ]

    stats = PublicStatsOut(
        release_count=len(release_notes),
        download_count=len(downloads),
        doc_count=len(docs),
        kb_count=len(kb),
        partner_count=len(partner),
        latest_release_version=featured_release.version if featured_release else None,
        latest_download_version=downloads[0].version if downloads else None,
    )

    return PublicMarketplaceOut(
        brand=DEFAULT_BRAND,
        stats=stats,
        highlights=highlights,
        featured_release=featured_release,
        sections=grouped,
    )


def _normalize_str(value: str) -> str:
    return " ".join(value.split()).strip()


def _serialize_inquiry(inquiry: PublicInquiry, *, reference_code: str | None = None) -> PublicInquiryOut:
    now = datetime.now(timezone.utc)
    return PublicInquiryOut(
        id=inquiry.id,
        reference_code=reference_code or _reference_code(inquiry.id),
        inquiry_type=inquiry.inquiry_type,
        source_tab=inquiry.source_tab,
        status=inquiry.status,
        name=inquiry.name,
        email=inquiry.email,
        phone=inquiry.phone,
        company=inquiry.company,
        role=inquiry.role,
        message=inquiry.message,
        meta=inquiry.meta or {},
        created_at=inquiry.created_at or now,
        updated_at=inquiry.updated_at or now,
    )


async def submit_public_inquiry(db: AsyncSession, body: PublicInquiryCreate) -> PublicInquiryOut:
    now = datetime.now(timezone.utc)
    inquiry_id = uuid.uuid4()
    inquiry = PublicInquiry(
        id=inquiry_id,
        inquiry_type=body.inquiry_type,
        source_tab=body.source_tab,
        name=_normalize_str(body.name),
        email=_normalize_str(str(body.email)).lower(),
        phone=_normalize_str(body.phone) if body.phone else None,
        company=_normalize_str(body.company),
        role=_normalize_str(body.role) if body.role else None,
        message=_normalize_str(body.message),
        status="new",
        meta=body.meta or {},
        created_at=now,
        updated_at=now,
    )
    db.add(inquiry)
    await db.flush()
    await db.commit()
    await db.refresh(inquiry)
    return _serialize_inquiry(inquiry, reference_code=_reference_code(inquiry.id))


async def list_public_inquiries(
    db: AsyncSession,
    *,
    inquiry_type: str | None = None,
    status: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> list[PublicInquiryOut]:
    stmt = select(PublicInquiry).order_by(PublicInquiry.created_at.desc())
    if inquiry_type:
        stmt = stmt.where(PublicInquiry.inquiry_type == inquiry_type)
    if status:
        stmt = stmt.where(PublicInquiry.status == status)
    stmt = stmt.offset(offset).limit(limit)
    result = await db.execute(stmt)
    rows = list(result.scalars().all())
    return [_serialize_inquiry(row) for row in rows]


async def list_public_assets_admin(
    db: AsyncSession,
    *,
    section: str | None = None,
    include_inactive: bool = True,
) -> list[PublicAssetOut]:
    stmt = select(PublicAsset)
    if section:
        stmt = stmt.where(PublicAsset.section == section)
    if not include_inactive:
        stmt = stmt.where(PublicAsset.is_current.is_(True))
    stmt = stmt.order_by(PublicAsset.section, PublicAsset.sort_order.desc(), PublicAsset.created_at.desc())
    result = await db.execute(stmt)
    rows = list(result.scalars().all())
    return [
        PublicAssetOut.model_validate(row).model_copy(
            update={
                "asset_url": row.asset_url
                or _asset_url_for_section(
                    row.section,
                    row.slug,
                    row.version,
                    workflow_status=_workflow_status_for(row),
                ),
                "workflow_status": _workflow_status_for(row),
                "meta": {
                    **(row.meta or {}),
                    "workflow_status": _workflow_status_for(row),
                },
            }
        )
        for row in rows
    ]


async def search_public_assets(
    db: AsyncSession,
    *,
    query: str | None = None,
    section: str | None = "kb",
    include_inactive: bool = True,
    kb_type: str | None = None,
    workflow_status: str | None = None,
    limit: int = 100,
) -> list[PublicAssetOut]:
    stmt = select(PublicAsset)
    if section:
        stmt = stmt.where(PublicAsset.section == section)
    if not include_inactive:
        stmt = stmt.where(PublicAsset.is_current.is_(True))
    stmt = stmt.order_by(PublicAsset.sort_order.desc(), PublicAsset.created_at.desc())
    result = await db.execute(stmt)
    rows = list(result.scalars().all())
    assets = [
        PublicAssetOut.model_validate(row).model_copy(
            update={
                "asset_url": row.asset_url
                or _asset_url_for_section(
                    row.section,
                    row.slug,
                    row.version,
                    workflow_status=_workflow_status_for(row),
                ),
                "workflow_status": _workflow_status_for(row),
                "meta": {
                    **(row.meta or {}),
                    "workflow_status": _workflow_status_for(row),
                },
            }
        )
        for row in rows
    ]

    if kb_type:
        normalized_kb_type = kb_type.strip().lower()
        assets = [
            asset
            for asset in assets
            if str((asset.meta or {}).get("kb_type") or "").lower() == normalized_kb_type
        ]
    if workflow_status:
        normalized_status = workflow_status.strip().lower()
        assets = [
            asset
            for asset in assets
            if (asset.workflow_status or str((asset.meta or {}).get("workflow_status") or "")).lower() == normalized_status
        ]

    terms = _normalize_search_terms(query)
    phrase = " ".join(terms) if terms else None
    ranked: list[tuple[int, int, datetime, PublicAssetOut]] = []
    for asset in assets:
        score = _search_score(asset, terms, phrase)
        if terms and score <= 0:
            continue
        ranked.append((score, _status_rank(asset), asset.updated_at, asset))

    if not terms:
        ranked = [(_status_rank(asset) * 5 + (3 if asset.is_current else 0), _status_rank(asset), asset.updated_at, asset) for asset in assets]

    ranked.sort(key=lambda item: (item[0], item[1], item[2], item[3].sort_order, item[3].title), reverse=True)
    return [item[3] for item in ranked[:limit]]


async def suggest_public_kb_assets(
    db: AsyncSession,
    *,
    asset_id: uuid.UUID,
    include_inactive: bool = True,
    limit: int = 5,
) -> list[PublicAssetOut]:
    selected = await db.get(PublicAsset, asset_id)
    if not selected or selected.section != "kb":
        return []

    stmt = select(PublicAsset).where(
        PublicAsset.section == "kb",
        PublicAsset.id != asset_id,
    )
    if not include_inactive:
        stmt = stmt.where(PublicAsset.is_current.is_(True))
    stmt = stmt.order_by(PublicAsset.sort_order.desc(), PublicAsset.created_at.desc())
    result = await db.execute(stmt)
    rows = list(result.scalars().all())
    selected_asset = _serialize_public_asset(selected)

    ranked: list[tuple[int, int, datetime, PublicAssetOut]] = []
    for row in rows:
        asset = _serialize_public_asset(row)
        score = _suggestion_score(asset, selected_asset)
        if score < 0:
            continue
        ranked.append((score, _status_rank(asset), asset.updated_at, asset))

    ranked.sort(key=lambda item: (item[0], item[1], item[2], item[3].sort_order, item[3].title), reverse=True)
    return [item[3] for item in ranked[:limit]]


async def upsert_public_asset(
    db: AsyncSession,
    body: PublicAssetUpsert,
    *,
    asset_id: uuid.UUID | None = None,
) -> PublicAssetOut:
    now = datetime.now(timezone.utc)
    asset: PublicAsset | None = None

    if asset_id:
        asset = await db.get(PublicAsset, asset_id)
        if not asset:
            raise ValueError("Icerik bulunamadi")
        conflict = await db.execute(
            select(PublicAsset).where(
                PublicAsset.section == body.section,
                PublicAsset.slug == body.slug,
                PublicAsset.version == body.version,
                PublicAsset.id != asset_id,
            )
        )
        if conflict.scalar_one_or_none():
            raise ValueError("Ayni slug ve surum zaten kullaniliyor")
    else:
        result = await db.execute(
            select(PublicAsset).where(
                PublicAsset.section == body.section,
                PublicAsset.slug == body.slug,
                PublicAsset.version == body.version,
            )
        )
        asset = result.scalar_one_or_none()

    if asset is None:
        workflow_status = body.workflow_status or (body.meta or {}).get("workflow_status")
        if not workflow_status:
            workflow_status = "published" if body.is_current else "draft"
        meta = dict(body.meta or {})
        meta["workflow_status"] = workflow_status
        asset = PublicAsset(
            id=uuid.uuid4(),
            section=body.section,
            slug=body.slug,
            version=body.version,
            title=body.title,
            category=body.category,
            summary=body.summary,
            body=body.body,
            asset_url=body.asset_url,
            checksum=body.checksum,
            file_size_kb=body.file_size_kb,
            is_current=body.is_current,
            sort_order=body.sort_order,
            meta=meta,
            created_at=now,
            updated_at=now,
        )
        db.add(asset)
    else:
        workflow_status = body.workflow_status or (body.meta or {}).get("workflow_status")
        if not workflow_status:
            workflow_status = "published" if body.is_current else "draft"
        asset.section = body.section
        asset.slug = body.slug
        asset.version = body.version
        asset.title = body.title
        asset.category = body.category
        asset.summary = body.summary
        asset.body = body.body
        asset.asset_url = body.asset_url
        asset.checksum = body.checksum
        asset.file_size_kb = body.file_size_kb
        asset.is_current = body.is_current
        asset.sort_order = body.sort_order
        asset.meta = {**(body.meta or {}), "workflow_status": workflow_status}
        asset.updated_at = now

    if body.is_current:
        await db.execute(
            sql_update(PublicAsset)
            .where(
                PublicAsset.section == body.section,
                PublicAsset.slug == body.slug,
                PublicAsset.id != asset.id,
            )
            .values(is_current=False, updated_at=now)
        )

    await db.commit()
    await db.refresh(asset)
    return PublicAssetOut.model_validate(asset).model_copy(
        update={
            "workflow_status": _workflow_status_for(asset),
            "meta": {
                **(asset.meta or {}),
                "workflow_status": _workflow_status_for(asset),
            },
        }
    )


async def archive_public_asset(db: AsyncSession, asset_id: uuid.UUID) -> PublicAssetOut:
    asset = await db.get(PublicAsset, asset_id)
    if not asset:
        raise ValueError("Icerik bulunamadi")
    asset.is_current = False
    asset.meta = {**(asset.meta or {}), "workflow_status": "archived"}
    asset.updated_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(asset)
    return PublicAssetOut.model_validate(asset).model_copy(
        update={
            "workflow_status": "archived",
            "meta": {**(asset.meta or {}), "workflow_status": "archived"},
        }
    )


async def update_public_inquiry_status(
    db: AsyncSession,
    inquiry_id: uuid.UUID,
    *,
    status: str,
) -> PublicInquiryOut:
    inquiry = await db.get(PublicInquiry, inquiry_id)
    if not inquiry:
        raise ValueError("Talep bulunamadi")
    inquiry.status = status
    inquiry.updated_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(inquiry)
    return _serialize_inquiry(inquiry)


def _trial_provision_out(
    inquiry: PublicInquiry,
    sandbox: dict,
    *,
    voucher_code: str | None = None,
    provisioned_at: datetime | None = None,
) -> PublicTrialProvisionOut:
    provisioned_at = (
        provisioned_at
        or _parse_optional_iso_datetime(sandbox.get("provisioned_at"))
        or datetime.now(timezone.utc)
    )
    return PublicTrialProvisionOut(
        inquiry_id=inquiry.id,
        reference_code=_reference_code(inquiry.id),
        inquiry_status=inquiry.status,
        lifecycle_action=str(sandbox.get("lifecycle_action") or "provisioned"),
        renewal_count=int(sandbox.get("renewal_count") or 0),
        renewed_at=_parse_optional_iso_datetime(sandbox.get("renewed_at")),
        previous_license_expires_at=_parse_optional_iso_datetime(
            sandbox.get("previous_license_expires_at")
        ),
        cleaned_at=_parse_optional_iso_datetime(sandbox.get("cleaned_at")),
        cleanup_reason=sandbox.get("cleanup_reason"),
        tenant_id=uuid.UUID(str(sandbox["tenant_id"])),
        tenant_slug=str(sandbox["tenant_slug"]),
        tenant_name=str(sandbox["tenant_name"]),
        tenant_is_demo=bool(sandbox.get("tenant_is_demo", True)),
        customer_id=uuid.UUID(str(sandbox["customer_id"])),
        customer_name=str(sandbox["customer_name"]),
        location_id=uuid.UUID(str(sandbox["location_id"])),
        location_name=str(sandbox["location_name"]),
        device_id=uuid.UUID(str(sandbox["device_id"])),
        device_name=str(sandbox["device_name"]),
        portal_template_id=uuid.UUID(str(sandbox["portal_template_id"])),
        portal_template_name=str(sandbox["portal_template_name"]),
        portal_method=str(sandbox["portal_method"]),
        license_id=uuid.UUID(str(sandbox["license_id"])),
        license_plan=str(sandbox["license_plan"]),
        license_is_trial=bool(sandbox.get("license_is_trial", True)),
        license_expires_at=_parse_optional_iso_datetime(sandbox.get("license_expires_at")),
        voucher_batch_id=uuid.UUID(str(sandbox["voucher_batch_id"])),
        voucher_prefix=str(sandbox["voucher_prefix"]),
        voucher_code=voucher_code,
        provisioned_at=provisioned_at,
        message=str(sandbox["message"]),
    )


async def provision_trial_environment(
    db: AsyncSession,
    inquiry_id: uuid.UUID,
    *,
    actor_id: uuid.UUID,
    request=None,
) -> PublicTrialProvisionOut:
    now = datetime.now(timezone.utc)
    inquiry = await db.get(PublicInquiry, inquiry_id)
    if not inquiry:
        raise ValueError("Talep bulunamadi")
    if inquiry.inquiry_type != "trial":
        raise ValueError("Yalnizca trial talepleri icin sandbox olusturulabilir")

    meta = dict(inquiry.meta or {})
    sandbox = meta.get("sandbox_provisioning")
    if isinstance(sandbox, dict) and sandbox.get("status") == "provisioned":
        provisioned_at = _parse_optional_iso_datetime(sandbox.get("provisioned_at")) or now
        return _trial_provision_out(inquiry, sandbox, provisioned_at=provisioned_at)

    reference_code = _reference_code(inquiry.id)
    company_slug = _slugify(inquiry.company)
    tenant_slug = _slugify(f"{company_slug}-{reference_code}")
    tenant_name = f"{inquiry.company} Trial"
    customer_name = inquiry.company
    location_name = f"{inquiry.company} Demo Site"
    device_name = f"{inquiry.company} Gateway"
    portal_template_name = f"{inquiry.company} Trial Portal"
    code = _generate_voucher_code()
    license_expires_at = now + timedelta(days=_TRIAL_LICENSE_DAYS)

    tenant = Tenant(
        id=uuid.uuid4(),
        name=tenant_name,
        slug=tenant_slug,
        domain=None,
        is_root=False,
        is_demo=True,
        is_active=True,
    )
    customer = Customer(
        id=uuid.uuid4(),
        tenant_id=tenant.id,
        partner_id=None,
        name=customer_name,
        contact_name=inquiry.name,
        contact_email=inquiry.email,
        contact_phone=inquiry.phone,
        is_active=True,
    )
    location = Location(
        id=uuid.uuid4(),
        customer_id=customer.id,
        name=location_name,
        address=None,
        city=None,
        default_ssid=f"{company_slug[:20] or 'trial'}-guest",
        timezone="Europe/Istanbul",
        is_active=True,
    )
    device = Device(
        id=uuid.uuid4(),
        location_id=location.id,
        name=device_name,
        vendor="fortigate",
        model="trial-gateway",
        mgmt_ip=None,
        api_host=None,
        api_port=None,
        status="unknown",
        meta={
            "sandbox": True,
            "source_inquiry_id": str(inquiry.id),
            "trial": True,
            "demo_tenant": True,
        },
    )
    portal_template = PortalTemplate(
        id=uuid.uuid4(),
        customer_id=customer.id,
        location_id=location.id,
        name=portal_template_name,
        method=METHOD_VOUCHER,
        is_default=True,
        theme=dict(_TRIAL_THEME),
        fields=[],
        success_message="Trial ortamınız hazır. Voucher kodunuzla giriş yapın.",
        terms_url="https://hotspot.io/terms",
        meta={
            "sandbox": True,
            "source_inquiry_id": str(inquiry.id),
            "trial": True,
            "method": METHOD_VOUCHER,
        },
        is_active=True,
    )
    license_row = CustomerLicense(
        id=uuid.uuid4(),
        customer_id=customer.id,
        active_guests_quota=25,
        max_sessions_per_day=100,
        session_minutes_default=60,
        expires_at=license_expires_at,
        is_trial=True,
        is_radius_enterprise=False,
        is_active=True,
        plan=_TRIAL_LICENSE_PLAN,
        meta={
            "sandbox": True,
            "source_inquiry_id": str(inquiry.id),
            "reference_code": reference_code,
        },
    )
    voucher_batch = VoucherBatch(
        id=uuid.uuid4(),
        customer_id=customer.id,
        location_id=location.id,
        name=f"{inquiry.company} Trial Voucher Batch",
        prefix=_TRIAL_VOUCHER_PREFIX,
        count=1,
        duration_minutes=60,
        expires_at=license_expires_at,
        created_by=actor_id,
    )
    voucher = Voucher(
        id=uuid.uuid4(),
        batch_id=voucher_batch.id,
        code_hash=_hash_voucher_code(code),
        code_prefix=code[:6],
        status=STATUS_PENDING,
        expires_at=license_expires_at,
    )

    db.add_all([tenant, customer, location, device, portal_template, license_row, voucher_batch, voucher])

    inquiry.status = "qualified" if inquiry.status in {"new", "contacted"} else inquiry.status
    inquiry.meta = {
        **meta,
        "sandbox_provisioning": {
            "status": "provisioned",
            "lifecycle_action": "provisioned",
            "renewal_count": 0,
            "renewed_at": None,
            "previous_license_expires_at": None,
            "cleaned_at": None,
            "cleanup_reason": None,
            "provisioned_at": now.isoformat(),
            "tenant_id": str(tenant.id),
            "tenant_slug": tenant.slug,
            "tenant_name": tenant.name,
            "tenant_is_demo": tenant.is_demo,
            "customer_id": str(customer.id),
            "customer_name": customer.name,
            "location_id": str(location.id),
            "location_name": location.name,
            "device_id": str(device.id),
            "device_name": device.name,
            "portal_template_id": str(portal_template.id),
            "portal_template_name": portal_template.name,
            "portal_method": portal_template.method,
            "license_id": str(license_row.id),
            "license_plan": license_row.plan,
            "license_is_trial": license_row.is_trial,
            "license_expires_at": license_row.expires_at.isoformat() if license_row.expires_at else None,
            "voucher_batch_id": str(voucher_batch.id),
            "voucher_prefix": voucher_batch.prefix,
            "voucher_code_prefix": voucher.code_prefix,
            "message": "Sandbox ortamı oluşturuldu.",
        },
    }
    inquiry.updated_at = now

    await log_audit(
        db,
        "public_inquiry.trial_provisioned",
        "public_inquiry",
        str(inquiry.id),
        str(actor_id),
        request,
        details={
            "reference_code": reference_code,
            "tenant_id": str(tenant.id),
            "customer_id": str(customer.id),
            "location_id": str(location.id),
            "device_id": str(device.id),
            "portal_template_id": str(portal_template.id),
            "voucher_batch_id": str(voucher_batch.id),
        },
    )
    await db.commit()
    return _trial_provision_out(
        inquiry,
        inquiry.meta["sandbox_provisioning"],
        voucher_code=code,
        provisioned_at=now,
    )


async def renew_trial_environment(
    db: AsyncSession,
    inquiry_id: uuid.UUID,
    *,
    actor_id: uuid.UUID,
    extra_days: int = _TRIAL_LICENSE_DAYS,
    request=None,
) -> PublicTrialProvisionOut:
    now = datetime.now(timezone.utc)
    inquiry = await db.get(PublicInquiry, inquiry_id)
    if not inquiry:
        raise ValueError("Talep bulunamadi")
    if inquiry.inquiry_type != "trial":
        raise ValueError("Yalnizca trial talepleri yenilenebilir")

    meta = dict(inquiry.meta or {})
    sandbox = meta.get("sandbox_provisioning")
    if not isinstance(sandbox, dict):
        raise ValueError("Sandbox bilgisi bulunamadi")

    sandbox_status = str(sandbox.get("status") or "")
    if sandbox_status not in {"provisioned", "cleaned_up"}:
        raise ValueError("Sandbox durumu yenileme icin uygun degil")

    try:
        tenant = await db.get(Tenant, uuid.UUID(str(sandbox["tenant_id"])))
        customer = await db.get(Customer, uuid.UUID(str(sandbox["customer_id"])))
        location = await db.get(Location, uuid.UUID(str(sandbox["location_id"])))
        device = await db.get(Device, uuid.UUID(str(sandbox["device_id"])))
        template = await db.get(PortalTemplate, uuid.UUID(str(sandbox["portal_template_id"])))
        license_row = await db.get(CustomerLicense, uuid.UUID(str(sandbox["license_id"])))
    except (KeyError, ValueError) as exc:
        raise ValueError("Sandbox kaynaklari bulunamadi") from exc

    if not all([tenant, customer, location, device, template, license_row]):
        raise ValueError("Sandbox kaynaklari bulunamadi")
    assert tenant and customer and location and device and template and license_row

    old_batch = None
    old_batch_id_raw = sandbox.get("voucher_batch_id")
    if old_batch_id_raw:
        try:
            old_batch = await db.get(VoucherBatch, uuid.UUID(str(old_batch_id_raw)))
        except ValueError:
            old_batch = None

    previous_license_expires_at = (
        _parse_optional_iso_datetime(sandbox.get("license_expires_at"))
        or license_row.expires_at
        or now
    )
    if previous_license_expires_at.tzinfo is None:
        previous_license_expires_at = previous_license_expires_at.replace(tzinfo=timezone.utc)

    base_expiry = previous_license_expires_at if previous_license_expires_at > now else now
    license_expires_at = base_expiry + timedelta(days=extra_days)

    for row in (tenant, customer, location, device, template, license_row):
        if hasattr(row, "is_active"):
            row.is_active = True
    if device is not None:
        device.status = "unknown"
    if license_row is not None:
        license_row.is_trial = True
        license_row.plan = _TRIAL_LICENSE_PLAN
        license_row.expires_at = license_expires_at
        license_row.meta = {
            **(license_row.meta or {}),
            "sandbox": True,
            "source_inquiry_id": str(inquiry.id),
            "reference_code": _reference_code(inquiry.id),
            "lifecycle_action": "renewed",
            "renewed_at": now.isoformat(),
            "renewal_count": int(sandbox.get("renewal_count") or 0) + 1,
        }

    if old_batch is not None:
        old_batch.is_active = False
        old_vouchers = await db.execute(select(Voucher).where(Voucher.batch_id == old_batch.id))
        for voucher in old_vouchers.scalars().all():
            if voucher.status == STATUS_PENDING:
                voucher.status = STATUS_EXPIRED

    renewal_count = int(sandbox.get("renewal_count") or 0) + 1
    voucher_code = _generate_voucher_code()
    voucher_batch = VoucherBatch(
        id=uuid.uuid4(),
        customer_id=customer.id,
        location_id=location.id,
        name=f"{inquiry.company} Trial Voucher Batch Renewal {renewal_count}",
        prefix=_TRIAL_VOUCHER_PREFIX,
        count=1,
        duration_minutes=old_batch.duration_minutes if old_batch and old_batch.duration_minutes is not None else 60,
        expires_at=license_expires_at,
        created_by=actor_id,
    )
    voucher = Voucher(
        id=uuid.uuid4(),
        batch_id=voucher_batch.id,
        code_hash=_hash_voucher_code(voucher_code),
        code_prefix=voucher_code[:6],
        status=STATUS_PENDING,
        expires_at=license_expires_at,
    )

    db.add_all([voucher_batch, voucher])

    sandbox.update(
        {
            "status": "provisioned",
            "lifecycle_action": "renewed",
            "renewal_count": renewal_count,
            "renewed_at": now.isoformat(),
            "previous_license_expires_at": previous_license_expires_at.isoformat(),
            "license_expires_at": license_expires_at.isoformat(),
            "provisioned_at": now.isoformat(),
            "tenant_id": str(tenant.id),
            "tenant_slug": tenant.slug,
            "tenant_name": tenant.name,
            "tenant_is_demo": tenant.is_demo,
            "customer_id": str(customer.id),
            "customer_name": customer.name,
            "location_id": str(location.id),
            "location_name": location.name,
            "device_id": str(device.id),
            "device_name": device.name,
            "portal_template_id": str(template.id),
            "portal_template_name": template.name,
            "portal_method": template.method,
            "license_id": str(license_row.id),
            "license_plan": license_row.plan,
            "license_is_trial": license_row.is_trial,
            "voucher_batch_id": str(voucher_batch.id),
            "voucher_prefix": voucher_batch.prefix,
            "voucher_code_prefix": voucher.code_prefix,
            "message": "Trial ortamı yenilendi.",
        }
    )
    inquiry.status = "qualified"
    inquiry.meta = {
        **meta,
        "sandbox_provisioning": sandbox,
    }
    inquiry.updated_at = now

    await log_audit(
        db,
        "public_inquiry.trial_renewed",
        "public_inquiry",
        str(inquiry.id),
        str(actor_id),
        request,
        details={
            "reference_code": _reference_code(inquiry.id),
            "previous_license_expires_at": previous_license_expires_at.isoformat(),
            "license_expires_at": license_expires_at.isoformat(),
            "tenant_id": str(tenant.id),
            "customer_id": str(customer.id),
            "location_id": str(location.id),
            "device_id": str(device.id),
            "portal_template_id": str(template.id),
            "voucher_batch_id": str(voucher_batch.id),
        },
    )
    await db.commit()
    return _trial_provision_out(
        inquiry,
        inquiry.meta["sandbox_provisioning"],
        voucher_code=voucher_code,
        provisioned_at=now,
    )


async def cleanup_expired_trial_sandboxes(
    db: AsyncSession,
    *,
    now: datetime | None = None,
    actor_id: uuid.UUID | None = None,
    request=None,
) -> dict[str, int]:
    """Deactivate sandbox resources for expired trial inquiries.

    The cleanup is intentionally soft-delete friendly: records are marked
    inactive/expired and the inquiry metadata records the lifecycle transition.
    """
    current_time = now or datetime.now(timezone.utc)
    result = await db.execute(
        select(PublicInquiry).where(PublicInquiry.inquiry_type == "trial")
    )
    inquiries = list(result.scalars().all())

    cleaned = 0
    skipped = 0
    for inquiry in inquiries:
        meta = dict(inquiry.meta or {})
        sandbox = meta.get("sandbox_provisioning")
        if not isinstance(sandbox, dict):
            skipped += 1
            continue
        if sandbox.get("status") != "provisioned":
            skipped += 1
            continue

        expires_raw = sandbox.get("license_expires_at")
        if not expires_raw:
            skipped += 1
            continue
        try:
            expires_at = datetime.fromisoformat(str(expires_raw))
        except ValueError:
            skipped += 1
            continue
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        if expires_at > current_time:
            continue

        tenant = await db.get(Tenant, uuid.UUID(str(sandbox["tenant_id"])))
        customer = await db.get(Customer, uuid.UUID(str(sandbox["customer_id"])))
        location = await db.get(Location, uuid.UUID(str(sandbox["location_id"])))
        device = await db.get(Device, uuid.UUID(str(sandbox["device_id"])))
        template = await db.get(PortalTemplate, uuid.UUID(str(sandbox["portal_template_id"])))
        license_row = await db.get(CustomerLicense, uuid.UUID(str(sandbox["license_id"])))
        voucher_batch = await db.get(VoucherBatch, uuid.UUID(str(sandbox["voucher_batch_id"])))

        voucher_rows = []
        if voucher_batch:
            voucher_result = await db.execute(
                select(Voucher).where(Voucher.batch_id == voucher_batch.id)
            )
            voucher_rows = list(voucher_result.scalars().all())

        for row in (tenant, customer, location, device, template, license_row, voucher_batch):
            if row is not None and hasattr(row, "is_active"):
                row.is_active = False
        if device is not None:
            device.status = "offline"
        if license_row is not None:
            license_row.is_trial = True
        for voucher in voucher_rows:
            if voucher.status == STATUS_PENDING:
                voucher.status = STATUS_EXPIRED

        sandbox.update(
            {
                "status": "cleaned_up",
                "lifecycle_action": "cleaned_up",
                "cleaned_at": current_time.isoformat(),
                "cleanup_reason": "license_expired",
            }
        )
        inquiry.status = "archived"
        inquiry.meta = {
            **meta,
            "sandbox_provisioning": sandbox,
        }
        inquiry.updated_at = current_time

        await log_audit(
            db,
            "public_inquiry.trial_cleaned_up",
            "public_inquiry",
            str(inquiry.id),
            str(actor_id) if actor_id else None,
            request,
            details={
                "reference_code": _reference_code(inquiry.id),
                "tenant_id": str(tenant.id) if tenant else None,
                "customer_id": str(customer.id) if customer else None,
                "location_id": str(location.id) if location else None,
                "device_id": str(device.id) if device else None,
                "portal_template_id": str(template.id) if template else None,
                "voucher_batch_id": str(voucher_batch.id) if voucher_batch else None,
            },
        )
        cleaned += 1

    if cleaned:
        await db.commit()

    return {"due": len(inquiries), "cleaned": cleaned, "skipped": skipped}


def _reference_code(identifier: uuid.UUID) -> str:
    return f"PQ-{identifier.hex[:8].upper()}"


def _serialize_public_asset(row: PublicAsset) -> PublicAssetOut:
    asset = PublicAssetOut.model_validate(row)
    workflow_status = _workflow_status_for(row)
    return asset.model_copy(
        update={
            "asset_url": asset.asset_url
            or _asset_url_for_section(asset.section, asset.slug, asset.version, workflow_status=workflow_status),
            "workflow_status": workflow_status,
            "meta": {**(asset.meta or {}), "workflow_status": workflow_status},
        }
    )


_SEARCH_SPLIT_RE = re.compile(r"[^0-9A-Za-zçğıöşüÇĞİÖŞÜ]+", re.UNICODE)


def _meta_list_value(meta: dict | None, key: str) -> list[str]:
    if not meta:
        return []
    raw = meta.get(key)
    if isinstance(raw, str):
        return [part.strip() for part in _SEARCH_SPLIT_RE.split(raw) if part.strip()]
    if isinstance(raw, (list, tuple, set)):
        out: list[str] = []
        for item in raw:
            value = str(item).strip()
            if value:
                out.append(value)
        return out
    return []


def _normalize_search_terms(value: str | None) -> list[str]:
    if not value:
        return []
    seen: set[str] = set()
    terms: list[str] = []
    for token in _SEARCH_SPLIT_RE.split(value.lower()):
        token = token.strip()
        if len(token) < 2 or token in seen:
            continue
        seen.add(token)
        terms.append(token)
    return terms


def _status_rank(asset: PublicAssetOut) -> int:
    status = (asset.workflow_status or "").lower()
    if status == "published":
        return 4
    if status == "review":
        return 3
    if status == "archived":
        return 2
    if status == "draft":
        return 1
    return 0


def _asset_search_blob(asset: PublicAssetOut) -> dict[str, str]:
    meta = asset.meta or {}
    tags = " ".join(_meta_list_value(meta, "tags"))
    related = " ".join(_meta_list_value(meta, "related_slugs"))
    return {
        "section": (asset.section or "").lower(),
        "slug": (asset.slug or "").lower(),
        "title": (asset.title or "").lower(),
        "category": (asset.category or "").lower(),
        "summary": (asset.summary or "").lower(),
        "body": (asset.body or "").lower(),
        "kb_type": str(meta.get("kb_type") or "").lower(),
        "workflow_status": (asset.workflow_status or str(meta.get("workflow_status") or "")).lower(),
        "tags": tags.lower(),
        "related_slugs": related.lower(),
    }


def _score_text(blob: str, term: str, *, exact_bonus: int, contains_bonus: int) -> int:
    if not blob or not term:
        return 0
    if blob == term:
        return exact_bonus
    if term in blob:
        return contains_bonus
    return 0


def _search_score(asset: PublicAssetOut, terms: list[str], phrase: str | None = None) -> int:
    blob = _asset_search_blob(asset)
    score = _status_rank(asset) * 5 + (3 if asset.is_current else 0)

    if phrase:
        score += _score_text(blob["slug"], phrase, exact_bonus=80, contains_bonus=42)
        score += _score_text(blob["title"], phrase, exact_bonus=60, contains_bonus=30)
        score += _score_text(blob["category"], phrase, exact_bonus=28, contains_bonus=14)
        score += _score_text(blob["summary"], phrase, exact_bonus=24, contains_bonus=12)
        score += _score_text(blob["body"], phrase, exact_bonus=12, contains_bonus=6)

    for term in terms:
        score += _score_text(blob["slug"], term, exact_bonus=60, contains_bonus=28)
        score += _score_text(blob["title"], term, exact_bonus=32, contains_bonus=16)
        score += _score_text(blob["category"], term, exact_bonus=18, contains_bonus=9)
        score += _score_text(blob["summary"], term, exact_bonus=14, contains_bonus=7)
        score += _score_text(blob["body"], term, exact_bonus=6, contains_bonus=3)
        score += _score_text(blob["kb_type"], term, exact_bonus=20, contains_bonus=10)
        score += _score_text(blob["workflow_status"], term, exact_bonus=8, contains_bonus=4)
        score += _score_text(blob["tags"], term, exact_bonus=22, contains_bonus=11)
        score += _score_text(blob["related_slugs"], term, exact_bonus=10, contains_bonus=5)

    if phrase and phrase in blob["tags"]:
        score += 10
    if phrase and phrase in blob["related_slugs"]:
        score += 8
    return score


def _suggestion_score(asset: PublicAssetOut, selected: PublicAssetOut) -> int:
    if asset.id == selected.id:
        return -1

    selected_meta = selected.meta or {}
    asset_meta = asset.meta or {}
    selected_tags = set(_meta_list_value(selected_meta, "tags"))
    asset_tags = set(_meta_list_value(asset_meta, "tags"))
    selected_related = set(_meta_list_value(selected_meta, "related_slugs"))
    asset_related = set(_meta_list_value(asset_meta, "related_slugs"))
    selected_terms = set(
        _normalize_search_terms(
            " ".join(
                [
                    selected.slug,
                    selected.title,
                    selected.category or "",
                    selected.summary or "",
                    selected.body or "",
                    str(selected_meta.get("kb_type") or ""),
                    " ".join(selected_tags),
                ]
            )
        )
    )
    asset_terms = set(
        _normalize_search_terms(
            " ".join(
                [
                    asset.slug,
                    asset.title,
                    asset.category or "",
                    asset.summary or "",
                    asset.body or "",
                    str(asset_meta.get("kb_type") or ""),
                    " ".join(asset_tags),
                ]
            )
        )
    )

    score = _status_rank(asset) * 8 + (4 if asset.is_current else 0)
    if asset.slug in selected_related:
        score += 150
    if selected.slug in asset_related:
        score += 120
    score += len(selected_tags & asset_tags) * 28
    score += len(selected_terms & asset_terms) * 4

    selected_kb_type = str(selected_meta.get("kb_type") or "").lower()
    asset_kb_type = str(asset_meta.get("kb_type") or "").lower()
    if selected_kb_type and selected_kb_type == asset_kb_type:
        score += 18

    selected_category = (selected.category or "").lower()
    asset_category = (asset.category or "").lower()
    if selected_category and selected_category == asset_category:
        score += 10

    if selected.summary and asset.summary and selected.summary.lower() == asset.summary.lower():
        score += 8

    return score


async def get_download_asset(
    db: AsyncSession,
    *,
    slug: str,
    version: str | None = None,
) -> PublicAssetOut | None:
    stmt = select(PublicAsset).where(
        PublicAsset.section == "downloads",
        PublicAsset.slug == slug,
    )
    if version is None:
        stmt = stmt.where(PublicAsset.is_current.is_(True))
    if version:
        stmt = stmt.where(PublicAsset.version == version)
    stmt = stmt.order_by(PublicAsset.version.desc(), PublicAsset.created_at.desc()).limit(1)
    result = await db.execute(stmt)
    row = result.scalar_one_or_none()
    if not row:
        return None
    asset = _serialize_public_asset(row)
    if version and asset.workflow_status == "draft":
        return None
    return asset


async def get_release_asset(
    db: AsyncSession,
    *,
    slug: str,
    version: str | None = None,
) -> PublicAssetOut | None:
    stmt = select(PublicAsset).where(
        PublicAsset.section == "release_notes",
        PublicAsset.slug == slug,
    )
    if version is None:
        stmt = stmt.where(PublicAsset.is_current.is_(True))
    if version:
        stmt = stmt.where(PublicAsset.version == version)
    stmt = stmt.order_by(PublicAsset.version.desc(), PublicAsset.created_at.desc()).limit(1)
    result = await db.execute(stmt)
    row = result.scalar_one_or_none()
    if not row:
        return None
    asset = _serialize_public_asset(row)
    if version and asset.workflow_status == "draft":
        return None
    return asset


async def list_public_release_history(
    db: AsyncSession,
    *,
    slug: str,
    include_drafts: bool = False,
) -> list[PublicAssetOut]:
    stmt = (
        select(PublicAsset)
        .where(
            PublicAsset.section == "release_notes",
            PublicAsset.slug == slug,
        )
        .order_by(PublicAsset.is_current.desc(), PublicAsset.created_at.desc())
    )
    result = await db.execute(stmt)
    rows = list(result.scalars().all())
    assets = [_serialize_public_asset(row) for row in rows]
    if not include_drafts:
        assets = [asset for asset in assets if asset.workflow_status != "draft"]
    return assets


def build_download_bundle(asset: PublicAssetOut) -> tuple[bytes, str]:
    """Build a small distributable bundle for a public download.

    The bundle is intentionally deterministic enough to act as a versioned
    artifact in demos and pre-sales, even before a real release pipeline exists.
    """
    manifest = {
        "id": str(asset.id),
        "section": asset.section,
        "slug": asset.slug,
        "version": asset.version,
        "title": asset.title,
        "category": asset.category,
        "summary": asset.summary,
        "checksum": asset.checksum,
        "file_size_kb": asset.file_size_kb,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "asset_url": asset.asset_url,
        "meta": asset.meta,
    }
    readme = "\n".join(
        [
            asset.title,
            f"Sürüm: {asset.version}",
            f"Kategori: {asset.category or '-'}",
            "",
            asset.summary or "",
            "",
            asset.body,
        ]
    )
    filename = f"{asset.slug}-{asset.version}.zip"
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
        archive.writestr("README.txt", readme.encode("utf-8"))
    return buffer.getvalue(), filename
