import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import select, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext
from app.modules.ban.models import BanRule, WhitelistEntry
from app.modules.ban.schemas import BanRuleCreate, BanRuleUpdate, WhitelistEntryCreate
from app.modules.auth.models import User


# ---- Ban Rules ----


async def list_bans(db: AsyncSession, scope: ScopeContext) -> list[BanRule]:
    q = select(BanRule).where(
        BanRule.customer_id == scope.customer_id,
        BanRule.is_active,
    )
    if scope.location_id:
        q = q.where(
            (BanRule.location_id == scope.location_id) | (BanRule.location_id.is_(None))
        )
    q = q.order_by(BanRule.created_at.desc())
    r = await db.execute(q)
    return list(r.scalars().all())


async def get_ban(db: AsyncSession, ban_id: uuid.UUID, scope: ScopeContext) -> BanRule:
    q = select(BanRule).where(
        BanRule.id == ban_id,
        BanRule.customer_id == scope.customer_id,
    )
    r = await db.execute(q)
    b = r.scalar_one_or_none()
    if not b:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ban kurali bulunamadi")
    return b


async def create_ban(db: AsyncSession, body: BanRuleCreate, scope: ScopeContext, user: User) -> BanRule:
    if not any([body.mac_address, body.phone, body.ip_address]):
        raise HTTPException(status_code=400, detail="En az bir hedef (MAC, telefon veya IP) belirtilmelidir")
    b = BanRule(
        customer_id=body.customer_id,
        location_id=body.location_id,
        mac_address=body.mac_address,
        phone=body.phone,
        ip_address=body.ip_address,
        reason=body.reason,
        banned_by=user.id,
        expires_at=body.expires_at,
    )
    db.add(b)
    await db.commit()
    await db.refresh(b)
    return b


async def update_ban(db: AsyncSession, ban_id: uuid.UUID, body: BanRuleUpdate, scope: ScopeContext) -> BanRule:
    b = await get_ban(db, ban_id, scope)
    upd = body.model_dump(exclude_unset=True)
    for k, v in upd.items():
        setattr(b, k, v)
    await db.commit()
    await db.refresh(b)
    return b


async def delete_ban(db: AsyncSession, ban_id: uuid.UUID, scope: ScopeContext) -> None:
    b = await get_ban(db, ban_id, scope)
    b.is_active = False
    await db.commit()


async def check_banned(
    db: AsyncSession,
    customer_id: uuid.UUID,
    mac: str | None = None,
    phone: str | None = None,
    ip: str | None = None,
    location_id: uuid.UUID | None = None,
) -> BanRule | None:
    """Check if a guest is banned. Returns the matching BanRule or None."""
    filters = [BanRule.customer_id == customer_id, BanRule.is_active]
    if location_id:
        filters.append(
            or_(BanRule.location_id == location_id, BanRule.location_id.is_(None))
        )
    or_filters = []
    if mac:
        or_filters.append(BanRule.mac_address == mac)
    if phone:
        or_filters.append(BanRule.phone == phone)
    if ip:
        or_filters.append(BanRule.ip_address == ip)

    if not or_filters:
        return None

    filters.append(or_(*or_filters))
    filters.append(
        or_(BanRule.expires_at.is_(None), BanRule.expires_at > datetime.now(timezone.utc))
    )

    q = select(BanRule).where(and_(*filters))
    r = await db.execute(q)
    return r.scalar_one_or_none()


async def check_whitelisted(
    db: AsyncSession,
    customer_id: uuid.UUID,
    mac: str | None = None,
    phone: str | None = None,
    location_id: uuid.UUID | None = None,
) -> WhitelistEntry | None:
    """Check if a guest is whitelisted (bypasses ban)."""
    filters = [WhitelistEntry.customer_id == customer_id, WhitelistEntry.is_active]
    if location_id:
        filters.append(
            or_(WhitelistEntry.location_id == location_id, WhitelistEntry.location_id.is_(None))
        )
    or_filters = []
    if mac:
        or_filters.append(WhitelistEntry.mac_address == mac)
    if phone:
        or_filters.append(WhitelistEntry.phone == phone)

    if not or_filters:
        return None

    filters.append(or_(*or_filters))
    q = select(WhitelistEntry).where(and_(*filters))
    r = await db.execute(q)
    return r.scalar_one_or_none()


# ---- Whitelist ----


async def list_whitelist(db: AsyncSession, scope: ScopeContext) -> list[WhitelistEntry]:
    q = select(WhitelistEntry).where(
        WhitelistEntry.customer_id == scope.customer_id,
        WhitelistEntry.is_active,
    )
    if scope.location_id:
        q = q.where(
            (WhitelistEntry.location_id == scope.location_id) | (WhitelistEntry.location_id.is_(None))
        )
    q = q.order_by(WhitelistEntry.created_at.desc())
    r = await db.execute(q)
    return list(r.scalars().all())


async def create_whitelist_entry(db: AsyncSession, body: WhitelistEntryCreate, scope: ScopeContext) -> WhitelistEntry:
    if not any([body.mac_address, body.phone]):
        raise HTTPException(status_code=400, detail="En az bir hedef (MAC veya telefon) belirtilmelidir")
    w = WhitelistEntry(
        customer_id=body.customer_id,
        location_id=body.location_id,
        mac_address=body.mac_address,
        phone=body.phone,
        description=body.description,
    )
    db.add(w)
    await db.commit()
    await db.refresh(w)
    return w


async def delete_whitelist_entry(db: AsyncSession, entry_id: uuid.UUID, scope: ScopeContext) -> None:
    q = select(WhitelistEntry).where(
        WhitelistEntry.id == entry_id,
        WhitelistEntry.customer_id == scope.customer_id,
    )
    r = await db.execute(q)
    w = r.scalar_one_or_none()
    if not w:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Beyaz liste kaydi bulunamadi")
    w.is_active = False
    await db.commit()
