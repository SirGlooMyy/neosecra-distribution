"""LDAP/AD auth is stateless — no DB model needed."""
