"""White-Label / Branding configuration service.

Resolution order: customer override > tenant default > platform default.
Configs are scoped so each tenant/customer sees its own branding.
"""
from __future__ import annotations

import logging
import uuid

from sqlalchemy import Boolean, String, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from app.core.config import settings
from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk

log = logging.getLogger(__name__)


class WhiteLabelConfig(Base, UUIDPK, TimestampMixin):
    __tablename__ = "whitelabel_configs"

    tenant_id: Mapped[uuid.UUID | None] = fk("tenants", ondelete="CASCADE", nullable=True)
    customer_id: Mapped[uuid.UUID | None] = fk("customers", ondelete="CASCADE", nullable=True)
    brand_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    brand_logo_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    primary_color: Mapped[str | None] = mapped_column(String(20), nullable=True)
    secondary_color: Mapped[str | None] = mapped_column(String(20), nullable=True)
    accent_color: Mapped[str | None] = mapped_column(String(20), nullable=True)
    custom_domain: Mapped[str | None] = mapped_column(String(255), nullable=True)
    custom_favicon_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    support_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    support_phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    footer_text: Mapped[str | None] = mapped_column(String(500), nullable=True)
    terms_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    privacy_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


async def get_config(
    db: AsyncSession,
    tenant_id: uuid.UUID | None = None,
    customer_id: uuid.UUID | None = None,
) -> WhiteLabelConfig | None:
    """Resolve branding: customer override > tenant default > platform default."""
    if customer_id:
        res = await db.execute(
            select(WhiteLabelConfig).where(
                WhiteLabelConfig.customer_id == customer_id,
                WhiteLabelConfig.is_active.is_(True),
            )
        )
        cfg = res.scalar_one_or_none()
        if cfg:
            return cfg

    if tenant_id:
        res = await db.execute(
            select(WhiteLabelConfig).where(
                WhiteLabelConfig.tenant_id == tenant_id,
                WhiteLabelConfig.customer_id.is_(None),
                WhiteLabelConfig.is_active.is_(True),
            )
        )
        cfg = res.scalar_one_or_none()
        if cfg:
            return cfg

    res = await db.execute(
        select(WhiteLabelConfig).where(
            WhiteLabelConfig.tenant_id.is_(None),
            WhiteLabelConfig.customer_id.is_(None),
            WhiteLabelConfig.is_active.is_(True),
        )
    )
    return res.scalar_one_or_none()


async def upsert_config(
    db: AsyncSession,
    scope_type: str,
    scope_id: uuid.UUID | None,
    data: dict,
) -> WhiteLabelConfig:
    """scope_type: 'platform' | 'tenant' | 'customer'"""
    if scope_type == "platform":
        tenant_id = None
        customer_id = None
    elif scope_type == "tenant":
        tenant_id = scope_id
        customer_id = None
    elif scope_type == "customer":
        tenant_id = None
        customer_id = scope_id
    else:
        raise ValueError("scope_type platform, tenant veya customer olmali")

    res = await db.execute(
        select(WhiteLabelConfig).where(
            WhiteLabelConfig.tenant_id == tenant_id,
            WhiteLabelConfig.customer_id == customer_id,
        )
    )
    cfg = res.scalar_one_or_none()

    if not cfg:
        cfg = WhiteLabelConfig(tenant_id=tenant_id, customer_id=customer_id)

    for key in (
        "brand_name", "brand_logo_url", "primary_color", "secondary_color",
        "accent_color", "custom_domain", "custom_favicon_url", "support_email",
        "support_phone", "footer_text", "terms_url", "privacy_url", "is_active",
    ):
        if key in data:
            setattr(cfg, key, data[key])

    db.add(cfg)
    await db.commit()
    await db.refresh(cfg)
    return cfg


async def upload_brand_asset(
    db: AsyncSession,
    scope_type: str,
    scope_id: uuid.UUID | None,
    file_bytes: bytes,
    asset_type: str,
    filename: str,
) -> str:
    """Upload logo/favicon to MinIO and return URL."""
    if asset_type not in ("logo", "favicon"):
        raise ValueError("asset_type logo veya favicon olmali")

    try:
        from minio import Minio  # type: ignore[import-not-found]
        client = Minio(
            settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=settings.MINIO_SECURE,
        )
        bucket = "hotspot-branding"
        if not client.bucket_exists(bucket):
            client.make_bucket(bucket)

        ext = filename.rsplit(".", 1)[-1] if "." in filename else "png"
        key = f"{scope_type}/{scope_id or 'platform'}/{asset_type}_{uuid.uuid4().hex}.{ext}"
        import io
        client.put_object(bucket, key, io.BytesIO(file_bytes), length=len(file_bytes))
        url = f"minio:{bucket}/{key}"

        if asset_type == "logo":
            await upsert_config(db, scope_type, scope_id, {"brand_logo_url": url})
        else:
            await upsert_config(db, scope_type, scope_id, {"custom_favicon_url": url})

        return url
    except ImportError:
        log.warning("minio kutuphanesi yuklu degil, dosya kaydedilemiyor")
        raise


async def delete_config(
    db: AsyncSession,
    scope_type: str,
    scope_id: uuid.UUID | None,
) -> None:
    if scope_type == "platform":
        tenant_id = None
        customer_id = None
    elif scope_type == "tenant":
        tenant_id = scope_id
        customer_id = None
    elif scope_type == "customer":
        tenant_id = None
        customer_id = scope_id
    else:
        raise ValueError("scope_type platform, tenant veya customer olmali")

    res = await db.execute(
        select(WhiteLabelConfig).where(
            WhiteLabelConfig.tenant_id == tenant_id,
            WhiteLabelConfig.customer_id == customer_id,
        )
    )
    cfg = res.scalar_one_or_none()
    if cfg:
        await db.delete(cfg)
        await db.commit()


def apply_branding_to_portal(portal_theme: dict, brand_config: WhiteLabelConfig | None) -> dict:
    """Merge brand colors/logo into portal theme dict."""
    if not brand_config:
        return portal_theme

    theme = dict(portal_theme) if portal_theme else {}
    if brand_config.primary_color:
        theme["primary_color"] = brand_config.primary_color
    if brand_config.secondary_color:
        theme["secondary_color"] = brand_config.secondary_color
    if brand_config.accent_color:
        theme["accent_color"] = brand_config.accent_color
    if brand_config.brand_logo_url:
        theme["logo_url"] = brand_config.brand_logo_url
    if brand_config.footer_text:
        theme["footer_text"] = brand_config.footer_text
    if brand_config.terms_url:
        theme["terms_url"] = brand_config.terms_url
    if brand_config.privacy_url:
        theme["privacy_url"] = brand_config.privacy_url
    return theme
