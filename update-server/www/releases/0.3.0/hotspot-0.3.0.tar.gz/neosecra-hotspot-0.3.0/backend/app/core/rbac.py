"""Role-Based Access Control matrix.

Dependency helpers (require_permission/get_current_user) live in
app.modules.auth.deps because they depend on the User model.

Roles follow docs/09_SECURITY_RBAC.md:
  super_admin, partner_admin, customer_admin, location_manager, support
"""
from enum import Enum


class Role(str, Enum):
    SUPER_ADMIN = "super_admin"
    PARTNER_ADMIN = "partner_admin"
    CUSTOMER_ADMIN = "customer_admin"
    LOCATION_MANAGER = "location_manager"
    SUPPORT = "support"


# "*" grants every permission (super_admin only).
ROLE_PERMISSIONS: dict[str, set[str]] = {
    Role.SUPER_ADMIN.value: {"*"},
    Role.PARTNER_ADMIN.value: {
        "customer.read", "customer.write",
        "location.read", "location.write",
        "device.read", "device.write",
        "portal.read", "portal.write",
        "voucher.read", "voucher.write",
        "session.read", "session.write",
        "identity.read",
        "archive.read", "archive.write",
        "report.read", "report.write",
        "user.read", "license.read", "license.write",
        "syslog.read", "syslog.write",
        "log.read",
        "system.read", "system.write",
    },
    # Customer admin can VIEW its own license/quota but NOT write it — quotas are
    # set upstream (partner/super) so a customer cannot self-serve unlimited.
    Role.CUSTOMER_ADMIN.value: {
        "location.read", "location.write",
        "device.read", "device.write",
        "portal.read", "portal.write",
        "voucher.read", "voucher.write",
        "session.read", "session.write",
        "identity.read",
        "archive.read", "archive.write",
        "report.read", "report.write",
        "user.read", "license.read",
        "syslog.read", "syslog.write",
        "log.read",
        "system.read",
    },
    Role.LOCATION_MANAGER.value: {
        "device.read", "session.read", "report.read",
        "voucher.read", "portal.read", "identity.read", "archive.read",
    },
    Role.SUPPORT.value: {
        "session.read", "report.read", "device.read", "log.read", "identity.read", "archive.read",
        "system.read",
    },
}


def has_permission(role: str, permission: str) -> bool:
    perms = ROLE_PERMISSIONS.get(role, set())
    return "*" in perms or permission in perms


def can_manage_role(actor_role: str, target_role: str) -> bool:
    """A higher role may manage equal-or-lower roles, never above."""
    hierarchy = [
        Role.SUPER_ADMIN.value,
        Role.PARTNER_ADMIN.value,
        Role.CUSTOMER_ADMIN.value,
        Role.LOCATION_MANAGER.value,
        Role.SUPPORT.value,
    ]
    try:
        return hierarchy.index(actor_role) <= hierarchy.index(target_role)
    except ValueError:
        return False
