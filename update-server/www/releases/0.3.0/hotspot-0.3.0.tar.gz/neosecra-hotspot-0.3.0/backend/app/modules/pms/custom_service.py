"""Custom / Generic PMS data source integration.

Supports:
- json_api: HTTP GET/POST to a configurable endpoint
- excel: parse uploaded Excel file from object store
- csv: parse uploaded CSV file from object store
- database: connect to external DB via SQLAlchemy
- sql_query: execute a raw SQL on the platform's own DB (scoped)
"""
import csv
import io
import json
import logging
from datetime import date, datetime, timezone

import httpx
from sqlalchemy import text

from app.core.crypto import decrypt, encrypt
from app.core.database import AsyncSessionLocal
from app.modules.pms.models import CustomPmsSource
from app.modules.pms.schemas import PmsVerifyResult
from app.modules.pms.utils import normalize_turkish as _normalize_turkish


log = logging.getLogger(__name__)


# ---- CRUD -------------------------------------------------------------------

async def create_source(db, data: dict) -> CustomPmsSource:
    connection_config = data.get("connection_config", {})
    config_encrypted = encrypt(json.dumps(connection_config, default=str)) if connection_config else None

    source = CustomPmsSource(
        customer_id=data["customer_id"],
        name=data["name"],
        source_type=data["source_type"],
        connection_config_enc=config_encrypted,
        field_mapping=data.get("field_mapping", {}),
        is_active=data.get("is_active", True),
    )
    db.add(source)
    await db.flush()
    await db.refresh(source)
    log.info("[CustomPMS] Source created id=%s name=%s", source.id, source.name)
    return source


async def update_source(db, source_id, data: dict) -> CustomPmsSource | None:
    source = await db.get(CustomPmsSource, source_id)
    if not source:
        return None

    if "name" in data:
        source.name = data["name"]
    if "source_type" in data:
        source.source_type = data["source_type"]
    if "connection_config" in data:
        source.connection_config_enc = encrypt(json.dumps(data["connection_config"], default=str))
    if "field_mapping" in data:
        source.field_mapping = data["field_mapping"]
    if "is_active" in data:
        source.is_active = data["is_active"]

    source.updated_at = datetime.now(timezone.utc)
    await db.flush()
    await db.refresh(source)
    return source


async def delete_source(db, source_id) -> bool:
    source = await db.get(CustomPmsSource, source_id)
    if not source:
        return False
    await db.delete(source)
    await db.flush()
    return True


async def list_sources(db, customer_id) -> list[CustomPmsSource]:
    from sqlalchemy import select

    result = await db.execute(
        select(CustomPmsSource)
        .where(CustomPmsSource.customer_id == customer_id)
        .order_by(CustomPmsSource.created_at.desc())
    )
    return list(result.scalars().all())


async def get_source(db, source_id) -> CustomPmsSource | None:
    return await db.get(CustomPmsSource, source_id)


def _decrypt_config(source: CustomPmsSource) -> dict:
    if not source.connection_config_enc:  # type: ignore[union-attr]
        return {}
    try:
        raw = decrypt(source.connection_config_enc)  # type: ignore[arg-type]
        return json.loads(raw) if raw else {}
    except Exception as exc:
        log.error("[CustomPMS] Config decrypt error for %s: %s", source.id, exc)
        return {}


# ---- Query Executor ---------------------------------------------------------

async def query_custom_source(
    db,
    source_id,
    room_number: str,
    surname: str,
) -> PmsVerifyResult:
    source = await db.get(CustomPmsSource, source_id)
    if not source or not source.is_active:
        return PmsVerifyResult(verified=False, vendor="custom", message="Kaynak bulunamadi veya pasif")

    config = _decrypt_config(source)
    field_mapping = source.field_mapping or {}
    room_clean = (room_number or "").strip()
    surname_clean = _normalize_turkish(surname or "")

    if not room_clean or not surname_clean:
        return PmsVerifyResult(verified=False, vendor="custom", message="Oda numarasi ve soyad gerekli")

    try:
        if source.source_type == "json_api":
            return await _query_json_api(config, field_mapping, room_clean, surname_clean)
        elif source.source_type in ("excel", "csv"):
            return await _query_file(config, field_mapping, room_clean, surname_clean, source.source_type)
        elif source.source_type == "database":
            return await _query_database(config, field_mapping, room_clean, surname_clean)
        elif source.source_type == "sql_query":
            return await _query_sql(config, field_mapping, room_clean, surname_clean)
        else:
            return PmsVerifyResult(verified=False, vendor="custom", message=f"Desteklenmeyen kaynak tipi: {source.source_type}")
    except Exception as exc:
        log.error("[CustomPMS] Sorgu hatasi source=%s: %s", source.id, exc)
        return PmsVerifyResult(verified=False, vendor="custom", message=f"Sorgu hatasi: {exc}")


async def _query_json_api(config, mapping, room, surname) -> PmsVerifyResult:
    url = config.get("url", "")
    method = config.get("method", "GET").upper()
    headers = config.get("headers", {})
    timeout = config.get("timeout", 10)

    room_field = mapping.get("room_field", "room")
    surname_field = mapping.get("surname_field", "surname")
    result_path = mapping.get("result_path", "")
    verified_field = mapping.get("verified_field", "verified")
    guest_name_field = mapping.get("guest_name_field", "guest_name")
    check_in_field = mapping.get("check_in_field", "check_in")
    check_out_field = mapping.get("check_out_field", "check_out")
    status_field = mapping.get("status_field", "status")

    if not url:
        return PmsVerifyResult(verified=False, vendor="custom", message="JSON API URL yapilandirilmamis")

    params = {room_field: room, surname_field: surname}
    payload = {room_field: room, surname_field: surname}

    async with httpx.AsyncClient(timeout=timeout) as client:
        if method == "GET":
            resp = await client.get(url, params=params, headers=headers)
        else:
            resp = await client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()

    if result_path:
        for part in result_path.split("."):
            if isinstance(data, dict):
                data = data.get(part, {})
            else:
                data = {}
                break

    if isinstance(data, dict):
        verified = data.get(verified_field, False)
        if isinstance(verified, str):
            verified = verified.lower() in ("true", "1", "yes", "evet")
        guest_name = data.get(guest_name_field)
        ci = data.get(check_in_field)
        co = data.get(check_out_field)
        status = data.get(status_field, "checked_in")
    else:
        verified = bool(data)
        guest_name = str(data) if data else None
        ci = co = None
        status = "checked_in"

    return PmsVerifyResult(
        verified=bool(verified),
        guest_name=guest_name,
        check_in=_parse_date(ci),
        check_out=_parse_date(co),
        stay_status=status,
        vendor="custom",
    )


async def _query_file(config, mapping, room, surname, ftype) -> PmsVerifyResult:
    file_path = config.get("file_path", "")
    delimiter = config.get("delimiter", ",") if ftype == "csv" else None

    if not file_path:
        return PmsVerifyResult(verified=False, vendor="custom", message="Dosya yolu yapilandirilmamis")

    room_col = mapping.get("room_column", "room_no")
    surname_col = mapping.get("surname_column", "last_name")
    guest_name_col = mapping.get("guest_name_column", "guest_name")
    check_in_col = mapping.get("check_in_column", "check_in")
    check_out_col = mapping.get("check_out_column", "check_out")
    status_col = mapping.get("status_column", "status")

    try:
        if file_path.startswith("s3://") or file_path.startswith("minio://"):
            content = await _read_from_object_store(file_path)
        else:
            import aiofiles
            async with aiofiles.open(file_path, mode="r", encoding="utf-8") as f:
                content = await f.read()
    except ImportError:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as exc:
            log.warning("[CustomPMS] Dosya okuma hatasi %s: %s", file_path, exc)
            return PmsVerifyResult(verified=False, vendor="custom", message=f"Dosya okunamadi: {exc}")
    except Exception as exc:
        log.warning("[CustomPMS] Dosya okuma hatasi %s: %s", file_path, exc)
        return PmsVerifyResult(verified=False, vendor="custom", message=f"Dosya okunamadi: {exc}")

    if ftype == "csv":
        reader = csv.DictReader(io.StringIO(content), delimiter=delimiter or ",")
        rows = list(reader)
    else:
        try:
            import openpyxl  # type: ignore[import-not-found]
        except ImportError:
            return PmsVerifyResult(verified=False, vendor="custom", message="Excel okuma icin openpyxl kutuphanesi gerekli (pip install openpyxl)")
        wb = openpyxl.load_workbook(io.BytesIO(content.encode() if isinstance(content, str) else content), read_only=True)
        ws = wb.active
        if ws is None:
            return PmsVerifyResult(verified=False, vendor="custom", message="Excel sayfasi bulunamadi")
        headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
        rows = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            rows.append(dict(zip(headers, [str(v) if v is not None else "" for v in row])))

    for row in rows:
        rn = _normalize_turkish(row.get(room_col, ""))
        sn = _normalize_turkish(row.get(surname_col, ""))
        if rn == room and (sn == surname or sn == "ALL"):
            return PmsVerifyResult(
                verified=True,
                guest_name=row.get(guest_name_col),
                check_in=_parse_date(row.get(check_in_col)),
                check_out=_parse_date(row.get(check_out_col)),
                stay_status=row.get(status_col, "checked_in"),
                vendor="custom",
            )

    return PmsVerifyResult(verified=False, vendor="custom", message="Eslesen kayit bulunamadi")


async def _query_database(config, mapping, room, surname) -> PmsVerifyResult:
    db_url = config.get("database_url", "")
    query_text = config.get("query", "")
    table = config.get("table", "reservations")
    if not query_text:
        room_col = mapping.get("room_column", "room_no")
        surname_col = mapping.get("surname_column", "last_name")
        query_text = f"SELECT * FROM {table} WHERE {room_col} = :room AND {surname_col} = :surname"

    room_field_p = mapping.get("room_field_param", "room")
    surname_field_p = mapping.get("surname_field_param", "surname")

    if not db_url:
        return PmsVerifyResult(verified=False, vendor="custom", message="Veritabani URL yapilandirilmamis")

    try:
        from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

        engine = create_async_engine(db_url, echo=False, pool_pre_ping=True, pool_size=1)
        async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

        async with async_session() as session:
            result = await session.execute(
                text(query_text),
                {room_field_p: room, surname_field_p: surname},
            )
            row = result.mappings().one_or_none()

        await engine.dispose()

        if row:
            guest_name_col = mapping.get("guest_name_column", "guest_name")
            ci_col = mapping.get("check_in_column", "check_in")
            co_col = mapping.get("check_out_column", "check_out")
            status_col = mapping.get("status_column", "status")
            return PmsVerifyResult(
                verified=True,
                guest_name=row.get(guest_name_col) or f"{row.get('first_name', '')} {row.get('last_name', '')}".strip(),
                check_in=_parse_date(row.get(ci_col)),
                check_out=_parse_date(row.get(co_col)),
                stay_status=row.get(status_col, "checked_in"),
                vendor="custom",
            )
        return PmsVerifyResult(verified=False, vendor="custom", message="Eslesen kayit bulunamadi")
    except Exception as exc:
        log.warning("[CustomPMS] DB sorgu hatasi: %s", exc)
        return PmsVerifyResult(verified=False, vendor="custom", message=f"DB sorgu hatasi: {exc}")


async def _query_sql(config, mapping, room, surname) -> PmsVerifyResult:
    query_text = config.get("query", "")
    if not query_text:
        room_col = mapping.get("room_column", "room_no")
        surname_col = mapping.get("surname_column", "last_name")
        query_text = f"SELECT * FROM reservations WHERE {room_col} = :room AND {surname_col} = :surname"

    room_field_p = mapping.get("room_field_param", "room")
    surname_field_p = mapping.get("surname_field_param", "surname")

    async with AsyncSessionLocal() as session:
        try:
            result = await session.execute(
                text(query_text),
                {room_field_p: room, surname_field_p: surname},
            )
            row = result.mappings().one_or_none()
        except Exception as exc:
            log.warning("[CustomPMS] SQL sorgu hatasi: %s", exc)
            return PmsVerifyResult(verified=False, vendor="custom", message=f"SQL sorgu hatasi: {exc}")

        if row:
            guest_name_col = mapping.get("guest_name_column", "guest_name")
            ci_col = mapping.get("check_in_column", "check_in")
            co_col = mapping.get("check_out_column", "check_out")
            status_col = mapping.get("status_column", "status")
            return PmsVerifyResult(
                verified=True,
                guest_name=row.get(guest_name_col) or f"{row.get('first_name', '')} {row.get('last_name', '')}".strip(),
                check_in=_parse_date(row.get(ci_col)),
                check_out=_parse_date(row.get(co_col)),
                stay_status=row.get(status_col, "checked_in"),
                vendor="custom",
            )
        return PmsVerifyResult(verified=False, vendor="custom", message="Eslesen kayit bulunamadi")


async def _read_from_object_store(path: str) -> str:
    from urllib.parse import urlparse

    from app.core.config import settings

    parsed = urlparse(path)
    bucket = parsed.hostname or "hotspot-pms"
    key = parsed.path.lstrip("/")

    if path.startswith("minio://") or parsed.scheme in ("s3", "minio"):
        from minio import Minio  # type: ignore[import-not-found]

        client = Minio(
            settings.MINIO_ENDPOINT.replace("http://", "").replace("https://", ""),
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=settings.MINIO_SECURE,
        )
        resp = client.get_object(bucket, key)
        content = resp.read().decode("utf-8")
        resp.close()
        return content

    async with httpx.AsyncClient() as client:
        resp = await client.get(path)
        resp.raise_for_status()
        return resp.text


def _parse_date(val) -> date | None:
    if val is None:
        return None
    if isinstance(val, date):
        return val
    if isinstance(val, datetime):
        return val.date()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(str(val).strip(), fmt).date()
        except ValueError:
            continue
    return None
