"""Audit logging helper. Append-only; flushes so the row exists within the
caller's transaction (commit is the caller's responsibility)."""
from typing import Any

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.audit.models import AuditLog


async def log_audit(
    db: AsyncSession,
    action: str,
    resource_type: str,
    resource_id: str | None,
    actor_id: str | None,
    request: Request | None = None,
    details: dict[str, Any] | None = None,
    tenant_id: str | None = None,
) -> None:
    entry = AuditLog(
        action=action,
        resource_type=resource_type,
        resource_id=str(resource_id) if resource_id else None,
        actor_id=actor_id,
        tenant_id=tenant_id,
        ip_address=request.client.host if request and request.client else None,
        user_agent=request.headers.get("user-agent") if request else None,
        details=details or {},
    )
    db.add(entry)
    await db.flush()
