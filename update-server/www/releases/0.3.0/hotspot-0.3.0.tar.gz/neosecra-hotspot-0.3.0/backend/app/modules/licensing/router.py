"""Licensing / quota admin endpoints.

Read = license.read (partner full, customer own via IDOR). Write = license.write
(partner/super only — customers cannot self-serve quotas). The captive flow uses
the service.enforce_quota gate directly, not this router.
"""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import customer_in_scope, scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.licensing import service
from app.modules.licensing.schemas import LicenseOut, LicenseUpsert, QuotaStatus, LicenseCreate, LicenseUsageOut

router = APIRouter()


def _require(role: str, perm: str) -> None:
    if not has_permission(role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


@router.get("", response_model=list[LicenseOut], summary="List all customer licenses and their status", description="Returns a list of all licenses scoped to the authenticated user's tenant. Includes plan details, quota limits, and expiration dates. Requires the license.read permission.")
async def list_licenses(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user.role, "license.read")
    return await service.list_licenses(db, scope_for(user))


@router.get("/{customer_id}", response_model=LicenseOut, summary="Retrieve license details for a specific customer", description="Fetches the license information for the specified customer including quota limits, plan type, and expiration. Access is scoped to the user's tenant permissions. Requires the license.read permission.")
async def get_license(
    customer_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "license.read")
    return await service.get_license(db, customer_id, scope_for(user))


@router.get("/{customer_id}/quota", response_model=QuotaStatus, summary="Get live quota usage snapshot for a customer", description="Returns real-time quota usage data including active guest count, daily session count, and remaining capacity. Access is IDOR-checked against the customer scope. Requires the license.read permission.")
async def get_quota(
    customer_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "license.read")
    await service.get_license(db, customer_id, scope_for(user))  # IDOR guard
    return await service.quota_status(db, customer_id)


@router.put("/{customer_id}", response_model=LicenseOut, summary="Create or update a license for a customer", description="Creates a new license or updates an existing one for the specified customer. Supports modification of quota limits, plan type, and expiration. Requires the license.write permission.")
async def upsert_license(
    customer_id: uuid.UUID,
    body: LicenseUpsert,
    request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "license.write")
    return await service.upsert_license(
        db, customer_id, body, scope_for(user), user.id, request
    )


@router.post("", response_model=LicenseOut, summary="Create a new license assignment for a customer", description="Creates a new license entry for the specified customer with quota limits and plan settings. The customer_id is provided in the request body. Requires the license.write permission.")
async def create_license(
    body: LicenseCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user.role, "license.write")
    upsert_body = LicenseUpsert(
        active_guests_quota=body.active_guests_quota,
        max_sessions_per_day=body.max_sessions_per_day,
        session_minutes_default=body.session_minutes_default,
        expires_at=body.expires_at,
        is_trial=body.is_trial,
        is_active=body.is_active,
        plan=body.plan,
    )
    await service.upsert_license(db, body.customer_id, upsert_body, scope_for(user), user.id)
    return await service.get_license(db, body.customer_id, scope_for(user))


@router.post("/{license_id}/toggle", response_model=LicenseOut, summary="Toggle a license active or inactive status", description="Flips the is_active flag on the specified license. Can be used to temporarily suspend or re-enable a customer's service. Requires the license.write permission.")
async def toggle_license(
    license_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user.role, "license.write")
    from sqlalchemy import select
    from app.modules.licensing.models import CustomerLicense
    res = await db.execute(select(CustomerLicense).where(CustomerLicense.id == license_id))
    lic = res.scalar_one_or_none()
    if not lic:
        raise HTTPException(status_code=404, detail="Lisans bulunamadi")
    if not await customer_in_scope(db, scope_for(user), lic.customer_id):
        raise HTTPException(status_code=403, detail="Lisans scope disinda")
    
    lic.is_active = not lic.is_active
    db.add(lic)
    await db.commit()
    return await service.get_license(db, lic.customer_id, scope_for(user))


@router.get("/usage", response_model=list[LicenseUsageOut], summary="Get license usage statistics across all customers", description="Returns aggregated usage data for all licenses including active guest counts compared against configured quotas. Useful for monitoring capacity utilization. Requires the license.read permission.")
async def get_licenses_usage(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user.role, "license.read")
    from sqlalchemy import select, func
    from app.modules.licensing.models import CustomerLicense
    from app.modules.sessions.models import GuestSession
    
    q = select(CustomerLicense)
    res = await db.execute(q)
    licenses = res.scalars().all()

    out = []
    scope = scope_for(user)
    for lic in licenses:
        if not await customer_in_scope(db, scope, lic.customer_id):
            continue
        active_cnt_q = select(func.count()).select_from(GuestSession).where(
            GuestSession.customer_id == lic.customer_id,
            GuestSession.status == "active"
        )
        active_cnt = (await db.execute(active_cnt_q)).scalar_one() or 0

        out.append(LicenseUsageOut(
            customer_id=lic.customer_id,
            plan=lic.plan,
            is_active=lic.is_active,
            active_guests=active_cnt,
            active_guests_quota=lic.active_guests_quota,
            expires_at=lic.expires_at
        ))

    return out
