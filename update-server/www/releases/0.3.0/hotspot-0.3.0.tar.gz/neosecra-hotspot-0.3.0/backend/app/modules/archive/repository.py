import uuid
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.archive.models import ArchiveChunk


async def create_chunk(db: AsyncSession, chunk: ArchiveChunk) -> ArchiveChunk:
    db.add(chunk)
    await db.flush()
    await db.refresh(chunk)
    return chunk


async def get_chunk(
    db: AsyncSession, chunk_id: uuid.UUID
) -> ArchiveChunk | None:
    return await db.get(ArchiveChunk, chunk_id)


async def list_chunks(
    db: AsyncSession,
    customer_id: uuid.UUID,
    from_ts: datetime | None = None,
    to_ts: datetime | None = None,
) -> list[ArchiveChunk]:
    q = (
        select(ArchiveChunk)
        .where(ArchiveChunk.customer_id == customer_id)
        .order_by(ArchiveChunk.period_start.desc())
    )
    if from_ts:
        q = q.where(ArchiveChunk.period_start >= from_ts)
    if to_ts:
        q = q.where(ArchiveChunk.period_end <= to_ts)
    res = await db.execute(q)
    return list(res.scalars().all())


async def get_latest_chunk(
    db: AsyncSession, customer_id: uuid.UUID
) -> ArchiveChunk | None:
    res = await db.execute(
        select(ArchiveChunk)
        .where(ArchiveChunk.customer_id == customer_id)
        .order_by(ArchiveChunk.period_start.desc())
        .limit(1)
    )
    return res.scalar_one_or_none()
