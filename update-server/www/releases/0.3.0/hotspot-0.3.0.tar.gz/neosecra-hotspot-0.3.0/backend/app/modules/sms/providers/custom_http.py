"""Configurable HTTP SMS gateway adapter.

The generic adapter follows real gateway conventions: JSON or form payloads,
bearer/basic/header auth, dotted field paths, custom headers and response
success/job-id paths. Credentials stay in encrypted top-level config fields.
"""
from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

import httpx

from app.core.config import settings
from .base import SmsProvider


def _path_set(target: dict[str, Any], path: str, value: Any) -> None:
    parts = [p for p in str(path or "").split(".") if p]
    if not parts:
        return
    def assign(container: Any, remaining: list[str]) -> None:
        part = remaining[0]
        is_index = part.isdigit()
        if isinstance(container, list):
            index = int(part) if is_index else len(container)
            while len(container) <= index:
                container.append({})
            if len(remaining) == 1:
                container[index] = value
                return
            child = container[index]
            if not isinstance(child, (dict, list)):
                child = [] if remaining[1].isdigit() else {}
                container[index] = child
            assign(child, remaining[1:])
            return
        if len(remaining) == 1:
            container[part] = value
            return
        child = container.get(part)
        if not isinstance(child, (dict, list)):
            child = [] if remaining[1].isdigit() else {}
            container[part] = child
        assign(child, remaining[1:])

    assign(target, parts)


def _format_value(value: Any, values: Mapping[str, Any]) -> Any:
    if isinstance(value, str):
        for key, replacement in values.items():
            value = value.replace("{" + key + "}", str(replacement))
        return value
    if isinstance(value, list):
        return [_format_value(item, values) for item in value]
    if isinstance(value, dict):
        return {key: _format_value(item, values) for key, item in value.items()}
    return value


def _json_path(data: Any, path: str) -> Any:
    value = data
    for part in [p for p in str(path or "").split(".") if p]:
        if isinstance(value, dict):
            value = value.get(part)
        elif isinstance(value, list) and part.isdigit():
            index = int(part)
            value = value[index] if index < len(value) else None
        else:
            return None
    return value


class CustomHttpProvider(SmsProvider):
    async def send(self, phone: str, message: str) -> tuple[bool, str | None]:
        url = str(self.value("http_url", settings.SMS_HTTP_URL) or "").strip()
        if not url:
            return False, "http-url-missing"
        options = self.config.get("provider_options") or {}
        method = str(options.get("method") or "POST").upper()
        if method not in {"POST", "PUT", "PATCH", "GET"}:
            return False, "http-method-unsupported"
        payload_format = str(options.get("payload_format") or "json").lower()
        if payload_format not in {"json", "form"}:
            return False, "http-payload-format-unsupported"

        sender = self.value("sender", settings.SMS_SENDER)
        values = {"phone": phone, "to": phone, "message": message, "sender": sender}
        template = str(options.get("body_template") or self.value("http_template", "") or "").strip()
        body: dict[str, Any] = {}
        if template:
            try:
                parsed = json.loads(template)
            except json.JSONDecodeError:
                message = _format_value(template, values)
                values["message"] = message
                parsed = None
            if isinstance(parsed, dict):
                rendered = _format_value(parsed, values)
                body = rendered if isinstance(rendered, dict) else {}
            elif parsed is not None:
                return False, "http-body-template-must-be-object"
        if not body:
            _path_set(body, str(options.get("sender_field") or "sender"), sender)
            _path_set(body, str(options.get("recipient_field") or "to"), phone)
            _path_set(body, str(options.get("message_field") or "message"), values["message"])

        auth_type = str(options.get("auth_type") or "bearer").lower()
        if auth_type == "body":
            if self.value("api_key", "") and options.get("api_key_field"):
                _path_set(body, str(options["api_key_field"]), self.value("api_key"))
            if self.value("api_secret", "") and options.get("api_secret_field"):
                _path_set(body, str(options["api_secret_field"]), self.value("api_secret"))

        headers: dict[str, str] = {"Accept": "application/json"}
        custom_headers = options.get("headers")
        if isinstance(custom_headers, dict):
            headers.update({str(k): str(v) for k, v in custom_headers.items()})
        token = self.value("http_token", "") or self.value("api_key", "")
        if auth_type == "bearer" and token:
            headers["Authorization"] = f"Bearer {token}"
        elif auth_type == "basic":
            username = self.value("username", "")
            password = self.value("password", "")
            if not username or not password:
                return False, "http-basic-missing-credentials"
        elif auth_type == "header" and token:
            headers[str(options.get("auth_header") or "X-API-Key")] = token
        elif auth_type not in {"none", "body", "bearer", "basic", "header"}:
            return False, "http-auth-type-unsupported"

        kwargs: dict[str, Any] = {"timeout": 10.0, "headers": headers}
        if auth_type == "basic":
            kwargs["auth"] = (self.value("username"), self.value("password"))
        if method == "GET":
            kwargs["params"] = body
        elif payload_format == "form":
            headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
            kwargs["data"] = body
        else:
            headers.setdefault("Content-Type", "application/json")
            kwargs["json"] = body
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.request(method, url, **kwargs)
        except httpx.TimeoutException:
            return False, "http-timeout"
        except httpx.RequestError as exc:
            return False, f"http-request-error:{type(exc).__name__}"

        success_codes = options.get("success_codes")
        if isinstance(success_codes, list):
            accepted = {int(code) for code in success_codes if str(code).isdigit()}
            ok = resp.status_code in accepted
        else:
            ok = 200 <= resp.status_code < 300
        try:
            response_data = resp.json()
        except (ValueError, json.JSONDecodeError):
            response_data = {}
        success_path = options.get("success_path")
        if ok and success_path:
            success_value = _json_path(response_data, str(success_path))
            allowed_values = options.get("success_values") or [True, "true", "ok", "success", "sent", 1]
            ok = success_value in allowed_values
        if not ok:
            detail = _json_path(response_data, str(options.get("error_path") or "error")) if response_data else None
            return False, f"http-{resp.status_code}" + (f":{str(detail)[:120]}" if detail else "")
        job_id = _json_path(response_data, str(options.get("job_id_path") or "job_id")) if response_data else None
        return True, str(job_id) if job_id not in (None, "") else None
