"""Pydantic schemas for SMS OTP. The plaintext code is NEVER present in any
outbound schema — it travels only in-memory and through the delivery channel."""
from pydantic import BaseModel, Field


class SendCodeIn(BaseModel):
    phone: str = Field(..., min_length=10, max_length=20)


class VerifyCodeIn(BaseModel):
    phone: str = Field(..., min_length=10, max_length=20)
    code: str = Field(..., min_length=4, max_length=10)


class OtpResultOut(BaseModel):
    """Returned to the portal flow. No code, no internal id leaked."""
    state: str  # "sent" | "rate_limited"
    ttl_seconds: int
    attempts_left: int
