def is_valid_turkish_identity_number(value: str) -> bool:
    """Algorithmic TC Kimlik No validation. This is not an official NVI verification."""
    if not value or len(value) != 11 or not value.isdigit() or value[0] == "0":
        return False
    digits = [int(x) for x in value]
    odd_sum = sum(digits[0:9:2])
    even_sum = sum(digits[1:8:2])
    tenth = ((odd_sum * 7) - even_sum) % 10
    eleventh = sum(digits[:10]) % 10
    return digits[9] == tenth and digits[10] == eleventh


async def verify_with_nvi_fallback(
    tc_number: str,
    first_name: str | None = None,
    last_name: str | None = None,
    birth_year: int | None = None,
) -> bool:
    """Try NVI SOAP verification first, fall back to algorithmic validation."""
    if not is_valid_turkish_identity_number(tc_number):
        return False
    if first_name and last_name and birth_year:
        try:
            from app.modules.identity.nvi_service import verify_tc_kimlik
            return await verify_tc_kimlik(tc_number, first_name, last_name, birth_year)
        except Exception:
            pass
    return is_valid_turkish_identity_number(tc_number)
