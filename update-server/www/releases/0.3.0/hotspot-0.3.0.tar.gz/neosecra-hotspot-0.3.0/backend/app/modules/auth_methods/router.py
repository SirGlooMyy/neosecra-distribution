"""Compatibility API for the admin authentication-methods screen.

The portal flow stores its per-customer method configuration separately. This
platform-level API backs the admin UI's SMS, WhatsApp and LDAP connection
settings without exposing credentials in responses.
"""
from __future__ import annotations

import json
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.crypto import decrypt, encrypt
from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.config import settings
from app.core.rbac import has_permission
from app.core.tenant import ScopeContext, TenantLevel, customer_in_scope, scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.customers.models import Customer
from app.modules.local_auth import service as local_auth_service
from app.modules.local_auth.models import LocalUser
from app.modules.sms.models import SmsConfig
from app.modules.sms.service import get_runtime_config, normalize_tr_phone, send_custom_sms
from app.modules.system.models import PlatformSetting

router = APIRouter()

_SETTING_KEY = "auth_methods_config"
_DEFAULT_CONFIG = {
    "whatsapp": {
        "api_token": "",
        "phone_number_id": "",
        "business_account_id": "",
        "is_configured": False,
    },
    "ldap": {
        "server_url": "",
        "bind_dn": "",
        "bind_password": "",
        "base_dn": "",
        "search_filter": "(objectClass=person)",
        "is_configured": False,
    },
}

_SECRET_FIELDS = (("whatsapp", "api_token"), ("ldap", "bind_password"))
_ENCRYPTED_PREFIX = "enc:"
_SMS_SECRET_MASK = "********"
_SMS_PROVIDERS = {"console", "netgsm", "vatansms", "twilio", "iletimerkezi", "muttl", "relateddigital", "http"}
_SMS_PROVIDER_CATALOG = [
    {
        "id": "console",
        "name": "Console (demo)",
        "auth": "none",
        "fields": [],
        "docs": "Kod sunucu loguna yazılır; gerçek SMS göndermez.",
    },
    {
        "id": "netgsm",
        "name": "NetGSM (REST v2)",
        "auth": "basic",
        "endpoint": "https://api.netgsm.com.tr/sms/rest/v2/send",
        "fields": ["username", "password", "sender", "encoding", "iysfilter", "appname"],
        "docs": "JSON messages[] gövdesi ve HTTP Basic Auth.",
    },
    {
        "id": "iletimerkezi",
        "name": "İleti Merkezi",
        "auth": "body",
        "endpoint": "https://api.iletimerkezi.com/v1/send-sms",
        "fields": ["api_key", "api_secret", "sender"],
        "docs": "Nested JSON authentication.key/hash ve receipents.number.",
    },
    {
        "id": "vatansms",
        "name": "VatanSMS",
        "auth": "body",
        "endpoint": "https://api.vatansms.net/api/v1/1toN",
        "fields": ["username", "api_key", "sender", "message_type", "message_content_type"],
        "docs": "REST JSON api_id + api_key + phones[] gövdesi.",
    },
    {
        "id": "twilio",
        "name": "Twilio",
        "auth": "basic",
        "endpoint": "https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json",
        "fields": ["username", "password", "sender", "messaging_service_sid", "status_callback"],
        "docs": "Form-urlencoded; From veya Messaging Service SID.",
    },
    {
        "id": "http",
        "name": "Özel HTTP gateway",
        "auth": "configurable",
        "fields": ["http_url", "http_token", "username", "password", "api_key", "api_secret"],
        "docs": "JSON/form, field mapping, custom headers ve response paths.",
    },
]


async def _sms_customer_id(db: AsyncSession, user: User) -> uuid.UUID:
    return await resolve_installation_customer(db, user.customer_id)


async def _sms_row(db: AsyncSession, customer_id: uuid.UUID) -> SmsConfig | None:
    return (
        await db.scalar(
            select(SmsConfig)
            .where(SmsConfig.customer_id == customer_id)
            .order_by(SmsConfig.updated_at.desc())
            .limit(1)
        )
    )


@router.get("/sms/providers")
async def list_sms_providers(
    user: User = Depends(get_current_user),
):
    """Return provider contracts used to render the SMS form.

    This metadata contains no credentials and keeps the browser in sync with
    the adapter contracts instead of hard-coding stale field names.
    """
    _require(user, "system.read")
    return {"providers": _SMS_PROVIDER_CATALOG}


def _sms_secret_configured(row: SmsConfig | None, field: str, runtime: dict[str, str]) -> bool:
    encrypted_field = {
        "password": "password_encrypted",
        "api_key": "api_key_encrypted",
        "api_secret": "api_secret_encrypted",
        "http_token": "http_token_encrypted",
    }[field]
    # A row may intentionally override only provider/sender while retaining
    # legacy env credentials as a fallback. Reflect the effective runtime.
    return bool(getattr(row, encrypted_field, None)) or bool(runtime.get(field))


def _serialize_sms_config(
    row: SmsConfig | None,
    runtime: dict[str, str],
    customer_id: uuid.UUID,
    source: str,
) -> dict:
    options = row.provider_options if row and isinstance(row.provider_options, dict) else runtime.get("provider_options") or {}
    safe_options = dict(options)
    if isinstance(safe_options.get("headers"), dict):
        safe_headers = {}
        for key, value in safe_options["headers"].items():
            key_text = str(key).lower()
            safe_headers[key] = _SMS_SECRET_MASK if any(token in key_text for token in ("authorization", "token", "secret", "api-key", "apikey")) else value
        safe_options["headers"] = safe_headers
    result = {
        "customer_id": str(customer_id),
        "provider": runtime.get("provider") or "console",
        "username": (row.username if row and row.username else runtime.get("username")) or "",
        "sender": (row.sender if row and row.sender else runtime.get("sender")) or "",
        "http_url": row.http_url if row and row.http_url else (runtime.get("http_url") if runtime.get("provider") in {"http", "iletimerkezi", "muttl", "relateddigital"} else ""),
        "http_template": row.http_template if row else "",
        "provider_options": safe_options,
        "source": source,
        "configured": (runtime.get("provider") or "console") not in ("", "console", "log"),
    }
    for field in ("password", "api_key", "api_secret", "http_token"):
        result[field] = _SMS_SECRET_MASK if _sms_secret_configured(row, field, runtime) else ""
        result[f"{field}_configured"] = _sms_secret_configured(row, field, runtime)
    return result


@router.get("/sms")
async def get_sms_auth_status(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Expose the effective SMS/OTP runtime configuration without secrets."""
    _require(user, "system.read")
    customer_id = await _sms_customer_id(db, user)
    runtime, from_db = await get_runtime_config(db, customer_id)
    provider = (runtime.get("provider") or "console").strip().lower()
    return {
        "provider": provider,
        "configured": provider not in ("", "console", "log"),
        "source": "database" if from_db else "environment",
        "otp_length": settings.SMS_OTP_LENGTH,
        "otp_ttl_seconds": settings.SMS_OTP_TTL_SECONDS,
        "max_attempts": settings.SMS_OTP_MAX_ATTEMPTS,
        "sender": runtime.get("sender") or settings.SMS_SENDER,
    }


@router.get("/sms/config")
async def get_sms_config(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Return editable SMS settings; credential values are always masked."""
    _require(user, "system.read")
    customer_id = await _sms_customer_id(db, user)
    row = await _sms_row(db, customer_id)
    runtime, from_db = await get_runtime_config(db, customer_id)
    return _serialize_sms_config(row, runtime, customer_id, "database" if from_db else "environment")


@router.put("/sms/config")
async def update_sms_config(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Persist provider credentials encrypted at rest for this installation."""
    _require(user, "system.write")
    customer_id = await _sms_customer_id(db, user)
    provider = str(body.get("provider") or "console").strip().lower()
    if provider not in _SMS_PROVIDERS:
        raise HTTPException(status_code=422, detail=f"Desteklenmeyen SMS sağlayıcısı: {provider}")

    row = await _sms_row(db, customer_id)
    if row is None:
        row = SmsConfig(customer_id=customer_id, provider=provider)
        db.add(row)
    row.provider = provider
    for field in ("username", "sender", "http_url", "http_template"):
        if field in body:
            value = body.get(field)
            setattr(row, field, str(value).strip() if value not in (None, "") else None)
    for field, attr in (("password", "password_encrypted"), ("api_key", "api_key_encrypted"), ("api_secret", "api_secret_encrypted"), ("http_token", "http_token_encrypted")):
        if field not in body or body.get(field) == _SMS_SECRET_MASK:
            continue
        value = body.get(field)
        setattr(row, attr, encrypt(str(value)) if value not in (None, "") else None)

    # Provider options are deliberately non-secret (endpoint/mapping choices,
    # encoding, IYS filter, Twilio Messaging Service SID, etc.).  Only accept
    # an object so malformed browser input cannot poison the JSON column.
    if "provider_options" in body:
        options = body.get("provider_options")
        if options is not None and not isinstance(options, dict):
            raise HTTPException(status_code=422, detail="provider_options bir JSON nesnesi olmalı")
        row.provider_options = dict(options or {})
    # Accept first-class option fields as well as the nested object. This
    # keeps API integrations ergonomic while the database remains normalized
    # to one JSON options column.
    option_keys = (
        "endpoint", "encoding", "iysfilter", "appname", "startdate", "stopdate",
        "messaging_service_sid", "status_callback", "method", "payload_format",
        "auth_type", "auth_header", "recipient_field", "message_field",
        "sender_field", "body_template", "success_path", "success_values",
        "error_path", "job_id_path", "headers", "api_key_field", "api_secret_field",
    )
    if any(key in body for key in option_keys):
        merged_options = dict(row.provider_options or {})
        for key in option_keys:
            if key in body:
                merged_options[key] = body[key]
        row.provider_options = merged_options

    if provider == "http" and not row.http_url:
        raise HTTPException(status_code=422, detail="HTTP sağlayıcısı için gateway URL gerekli")
    if provider == "netgsm" and (not row.username or not row.password_encrypted):
        raise HTTPException(status_code=422, detail="NetGSM için kullanıcı kodu ve şifre gerekli")
    if provider in {"vatansms", "muttl", "relateddigital"} and not row.api_key_encrypted:
        raise HTTPException(status_code=422, detail="Seçilen sağlayıcı için API anahtarı gerekli")
    if provider == "vatansms" and not row.username:
        raise HTTPException(status_code=422, detail="VatanSMS için API ID gerekli")
    if provider == "iletimerkezi" and (not row.api_key_encrypted or not row.api_secret_encrypted or not row.sender):
        raise HTTPException(status_code=422, detail="İleti Merkezi için API anahtarı, API hash ve başlık gerekli")
    if provider == "twilio":
        twilio_options = row.provider_options or {}
        sender_configured = bool(row.sender and row.sender.strip() and row.sender.strip() != settings.SMS_SENDER)
        if not row.username or not row.password_encrypted or not (sender_configured or twilio_options.get("messaging_service_sid")):
            raise HTTPException(status_code=422, detail="Twilio için Account SID, Auth Token ve From numarası veya Messaging Service SID gerekli")

    await db.commit()
    runtime, _ = await get_runtime_config(db, customer_id)
    return _serialize_sms_config(row, runtime, customer_id, "database")


@router.post("/sms/test")
async def test_sms_config(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    phone = body.get("phone")
    if not phone:
        raise HTTPException(status_code=400, detail="Telefon numarası gerekli")
    try:
        phone = normalize_tr_phone(str(phone))
    except HTTPException:
        raise
    customer_id = await _sms_customer_id(db, user)
    message = str(body.get("message") or "Hotspot SMS test mesajı")[:160]
    delivered, error = await send_custom_sms(phone, message, db=db, customer_id=customer_id)
    runtime, _ = await get_runtime_config(db, customer_id)
    return {
        "success": delivered,
        "provider": runtime.get("provider") or "console",
        "message": "Test SMS gönderildi." if delivered else f"SMS gönderilemedi: {error or 'bilinmeyen hata'}",
        "job_id": error if delivered else None,
    }


def _require(user: User, permission: str) -> None:
    if not has_permission(user.role, permission):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


def _masked_config(config: dict) -> dict:
    """Never return provider secrets to the browser after they are saved."""
    result = json.loads(json.dumps(config))
    for section, key in (("whatsapp", "api_token"), ("ldap", "bind_password")):
        value = result.get(section, {}).get(key)
        if value:
            result[section][key] = "********"
    return result


async def _load_config(db: AsyncSession) -> tuple[PlatformSetting | None, dict]:
    row = await db.scalar(select(PlatformSetting).where(PlatformSetting.key == _SETTING_KEY))
    if not row or not row.value:
        return row, json.loads(json.dumps(_DEFAULT_CONFIG))
    try:
        stored = json.loads(row.value) if isinstance(row.value, str) else dict(row.value)
    except (TypeError, ValueError):
        stored = {}
    config = json.loads(json.dumps(_DEFAULT_CONFIG))
    for section in ("whatsapp", "ldap"):
        if isinstance(stored.get(section), dict):
            config[section].update(stored[section])
    # Settings created by older builds may be plaintext.  Decrypt only values
    # explicitly marked by this module; keep legacy values readable so they can
    # be re-encrypted on the next save.
    for section, key in _SECRET_FIELDS:
        value = config.get(section, {}).get(key)
        if isinstance(value, str) and value.startswith(_ENCRYPTED_PREFIX):
            try:
                config[section][key] = decrypt(value[len(_ENCRYPTED_PREFIX):])
            except Exception:
                config[section][key] = ""
    return row, config


async def _save_config(db: AsyncSession, config: dict, row: PlatformSetting | None) -> dict:
    if row is None:
        row = PlatformSetting(key=_SETTING_KEY, category="auth", is_secret=True)
        db.add(row)
    stored = json.loads(json.dumps(config))
    for section, key in _SECRET_FIELDS:
        value = stored.get(section, {}).get(key)
        if value and value != "********" and not str(value).startswith(_ENCRYPTED_PREFIX):
            stored[section][key] = _ENCRYPTED_PREFIX + encrypt(str(value))
    row.value = json.dumps(stored)
    await db.commit()
    return _masked_config(config)


@router.get("/config")
async def get_auth_methods_config(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    _, config = await _load_config(db)
    return _masked_config(config)


@router.put("/whatsapp")
async def update_whatsapp_config(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    row, config = await _load_config(db)
    # A masked value means the browser did not change the existing secret.
    if body.get("api_token") == "********":
        body = {key: value for key, value in body.items() if key != "api_token"}
    config["whatsapp"].update(body)
    config["whatsapp"]["is_configured"] = bool(
        config["whatsapp"].get("phone_number_id") and config["whatsapp"].get("api_token")
    )
    return await _save_config(db, config, row)


@router.put("/ldap")
async def update_ldap_config(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    row, config = await _load_config(db)
    if body.get("bind_password") == "********":
        body = {key: value for key, value in body.items() if key != "bind_password"}
    config["ldap"].update(body)
    config["ldap"]["is_configured"] = bool(
        config["ldap"].get("server_url") and config["ldap"].get("base_dn")
    )
    return await _save_config(db, config, row)


@router.post("/whatsapp/test")
async def test_whatsapp_config(
    body: dict,
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    if not body.get("phone_number"):
        raise HTTPException(status_code=400, detail="phone_number gerekli")
    return {"success": False, "message": "WhatsApp sağlayıcısı yapılandırılmamış"}


@router.post("/ldap/test")
async def test_ldap_config(user: User = Depends(get_current_user)):
    _require(user, "system.write")
    return {"success": False, "message": "LDAP bağlantısı henüz yapılandırılmamış"}


# ---- Local portal users compatibility API ---------------------------------

def _serialize_local_user(row: LocalUser) -> dict:
    return {
        "id": str(row.id),
        "customer_id": str(row.customer_id),
        "location_id": str(row.location_id) if row.location_id else None,
        "username": row.username,
        "display_name": row.display_name,
        "email": row.email,
        "phone": row.phone,
        "is_active": row.is_active,
        "created_at": row.created_at,
    }


async def _local_user_for_scope(
    db: AsyncSession, scope: ScopeContext, user_id: uuid.UUID
) -> LocalUser:
    row = await db.get(LocalUser, user_id)
    if not row:
        raise HTTPException(status_code=404, detail="Kullanici bulunamadi")
    if not await customer_in_scope(db, scope, row.customer_id):
        raise HTTPException(status_code=403, detail="Bu kullaniciya erisim yetkiniz yok")
    return row


@router.get("/local-users")
async def list_local_users(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customers.read")
    scope = scope_for(user)
    if customer_id is None and scope.level == TenantLevel.GLOBAL:
        customer_id = await resolve_installation_customer(db)
    if customer_id and not await customer_in_scope(db, scope, customer_id):
        raise HTTPException(status_code=403, detail="Bu musteriye erisim yetkiniz yok")
    query = select(LocalUser).order_by(LocalUser.created_at.desc())
    if customer_id:
        query = query.where(LocalUser.customer_id == customer_id)
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        query = query.where(LocalUser.customer_id == scope.customer_id)
    elif scope.level == TenantLevel.PARTNER and scope.partner_id:
        query = query.join(Customer, LocalUser.customer_id == Customer.id).where(Customer.partner_id == scope.partner_id)
    elif scope.level == TenantLevel.LOCATION and scope.location_id:
        query = query.where(LocalUser.location_id == scope.location_id)
    elif scope.level != TenantLevel.GLOBAL:
        return []
    rows = (await db.execute(query)).scalars().all()
    return [_serialize_local_user(row) for row in rows]


@router.post("/local-users", status_code=201)
async def create_local_user(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customers.write")
    scope = scope_for(user)
    raw_customer_id = body.get("customer_id") or scope.customer_id
    if not raw_customer_id and scope.level == TenantLevel.GLOBAL:
        raw_customer_id = await resolve_installation_customer(db)
    if not raw_customer_id:
        raise HTTPException(status_code=400, detail="customer_id gerekli")
    try:
        customer_id = uuid.UUID(str(raw_customer_id))
    except ValueError:
        raise HTTPException(status_code=400, detail="Geçersiz customer_id")
    if not await customer_in_scope(db, scope, customer_id):
        raise HTTPException(status_code=403, detail="Bu musteriye erisim yetkiniz yok")
    try:
        row = await local_auth_service.create_user(
            db,
            customer_id=customer_id,
            location_id=uuid.UUID(str(body["location_id"])) if body.get("location_id") else None,
            username=body["username"],
            password=body["password"],
            display_name=body.get("display_name") or body["username"],
            email=body.get("email"),
            phone=body.get("phone"),
        )
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=f"{exc.args[0]} gerekli")
    return _serialize_local_user(row)


@router.put("/local-users/{user_id}")
async def update_local_user(
    user_id: uuid.UUID,
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customers.write")
    scope = scope_for(user)
    existing = await _local_user_for_scope(db, scope, user_id)
    row = await local_auth_service.update_user(
        db,
        user_id=user_id,
        customer_id=existing.customer_id,
        display_name=body.get("display_name"),
        email=body.get("email"),
        phone=body.get("phone"),
        password=body.get("password") or None,
    )
    return _serialize_local_user(row)


@router.delete("/local-users/{user_id}", status_code=204)
async def delete_local_user(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customers.write")
    scope = scope_for(user)
    existing = await _local_user_for_scope(db, scope, user_id)
    await local_auth_service.deactivate_user(db, user_id=user_id, customer_id=existing.customer_id)
