"""Meeting codes admin CRUD endpoints."""
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.meeting import service as meeting_service

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=403, detail="Yetkisiz islem")


@router.get("", summary="List all meeting codes for a customer", description="Returns the list of meeting/event codes configured for the specified customer. These codes are used as an authentication method for guest access during events. Requires the customers.read permission.")
async def list_meeting_codes(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customers.read")
    scope = scope_for(user)
    cid = customer_id or scope.customer_id
    if cid is None and scope.level.value == "global":
        cid = await resolve_installation_customer(db)
    if cid:
        if not await _customer_allowed(db, scope, cid):
            raise HTTPException(status_code=403, detail="Bu musteriye erisim yetkiniz yok")
        return await meeting_service.list_codes(db, customer_id=cid)
    # A global operator has a legitimate platform-wide view. Returning an
    # empty list here used to turn every initial page load into a 400 error.
    if scope.level.value == "global":
        result = await db.execute(select(meeting_service.MeetingCode).order_by(meeting_service.MeetingCode.created_at.desc()))
        return list(result.scalars().all())
    return []


@router.post("", status_code=201, summary="Create a new meeting/event code", description="Creates a new meeting code for event-based guest authentication. Configure the event name, duration, max uses, and expiration. Guests can use this code to access the network. Requires the customers.write permission.")
async def create_meeting_code(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customers.write")
    scope = scope_for(user)
    cid = body.get("customer_id") or scope.customer_id
    if not cid and scope.level.value == "global":
        cid = await resolve_installation_customer(db)
    if not cid:
        raise HTTPException(status_code=400, detail="customer_id gerekli")
    try:
        cid = uuid.UUID(str(cid))
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="Geçersiz customer_id")
    if not await _customer_allowed(db, scope, cid):
        raise HTTPException(status_code=403, detail="Bu musteriye erisim yetkiniz yok")
    code = await meeting_service.create_meeting_code(
        db,
        customer_id=cid,
        location_id=body.get("location_id"),
        event_name=body["event_name"],
        max_uses=body.get("max_uses", 100),
        duration_minutes=body.get("duration_minutes", 120),
        expires_at=datetime.fromisoformat(body["expires_at"]),
        created_by=user.id,
    )
    return code


@router.delete("/{code_id}", status_code=204, summary="Delete a meeting code", description="Permanently removes the specified meeting code. Guests will no longer be able to use this code for network access. Requires the customers.write permission.")
async def delete_meeting_code(
    code_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "customers.write")
    code = await db.get(meeting_service.MeetingCode, code_id)
    if not code:
        raise HTTPException(status_code=404, detail="Kod bulunamadi")
    if not await _customer_allowed(db, scope_for(user), code.customer_id):
        raise HTTPException(status_code=403, detail="Bu koda erisim yetkiniz yok")
    await db.delete(code)
    await db.commit()


async def _customer_allowed(db: AsyncSession, scope, customer_id: uuid.UUID) -> bool:
    """Check customer scope without weakening the global operator case."""
    from app.core.tenant import customer_in_scope

    return await customer_in_scope(db, scope, customer_id)
