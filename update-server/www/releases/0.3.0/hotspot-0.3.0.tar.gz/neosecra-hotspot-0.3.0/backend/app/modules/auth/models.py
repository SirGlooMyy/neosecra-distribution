"""User model. Carries role + tenant-scope fields used by RBAC filtering.

Scope fields (tenant/partner/customer/location) are nullable: super_admin
has them all null (global scope); every other role is scoped to its own
slice of the tenant tree (Mutlak Kural #1, #2).
"""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin


class User(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    full_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(50), nullable=False, index=True)

    # --- Tenant scope (all nullable; super_admin = all null = global) ---
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    partner_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    customer_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    location_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)

    # --- 2FA (TOTP). Secret stored encrypted via app.core.crypto. ---
    is_2fa_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    totp_secret_encrypted: Mapped[str | None] = mapped_column(String(512), nullable=True)

    # --- MFA (Multi-Factor Authentication) ---
    mfa_required: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    mfa_methods: Mapped[list | None] = mapped_column(JSONB, nullable=True, default=[])

    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
