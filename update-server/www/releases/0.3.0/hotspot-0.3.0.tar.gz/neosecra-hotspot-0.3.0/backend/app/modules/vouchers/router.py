"""Voucher batch admin endpoints. Read = voucher.read; write = voucher.write.

Plaintext codes are returned ONLY in the batch-create response
(BatchCreateResult.codes); VoucherOut exposes code_prefix only (Mutlak Kural #3).
Public redeem is NOT here — it is reached through the captive portal flow
(portal.flow -> vouchers.service.redeem), bound to the device's site.
"""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.vouchers import service
from app.modules.vouchers.schemas import (
    BatchCreateResult,
    VoucherBatchCreate,
    VoucherBatchOut,
    VoucherBatchUpdate,
    VoucherOut,
)
from app.shared.licensing.license_service import require_licensed_module

router = APIRouter()


def _require(role: str, perm: str) -> None:
    if not has_permission(role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


@router.get("/batches", response_model=list[VoucherBatchOut], summary="List all voucher batches for the current tenant", description="Returns a list of voucher batches scoped to the authenticated user's tenant. Each batch contains metadata such as count, validity period, and usage statistics. Requires the voucher.read permission.")
async def list_batches(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_batches(db, scope_for(user))


@router.post("/batches", response_model=BatchCreateResult, status_code=status.HTTP_201_CREATED, summary="Generate a new batch of voucher codes", description="Creates a new batch of vouchers with the specified quantity, duration, and settings. Plaintext codes are returned only in this response for secure distribution. Requires the voucher.write permission.")
async def create_batch(
    body: VoucherBatchCreate, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "voucher.write")
    await require_licensed_module(db, user, "vouchers")
    return await service.generate_batch(db, body, scope_for(user), user.id, request)


@router.get("/batches/{batch_id}", response_model=VoucherBatchOut, summary="Retrieve a voucher batch by its unique identifier", description="Fetches details for the specified voucher batch including usage count, validity dates, and status. Access is scoped to the user's tenant. Requires the voucher.read permission.")
async def get_batch(
    batch_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    return await service.get_batch(db, batch_id, scope_for(user))


@router.put("/batches/{batch_id}", response_model=VoucherBatchOut, summary="Update a voucher batch configuration", description="Updates the specified voucher batch's settings such as validity dates or status. Individual voucher codes within the batch cannot be modified. Requires the voucher.write permission.")
async def update_batch(
    batch_id: uuid.UUID, body: VoucherBatchUpdate, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "voucher.write")
    await require_licensed_module(db, user, "vouchers")
    return await service.update_batch(db, batch_id, body, scope_for(user), user.id, request)


@router.post("/batches/{batch_id}/deactivate", status_code=status.HTTP_204_NO_CONTENT, summary="Deactivate an entire voucher batch", description="Deactivates the specified voucher batch, rendering all codes within it invalid for redemption. This action cannot be undone. Requires the voucher.write permission.")
async def deactivate_batch(
    batch_id: uuid.UUID, request: Request,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    _require(user.role, "voucher.write")
    await require_licensed_module(db, user, "vouchers")
    await service.deactivate_batch(db, batch_id, scope_for(user), user.id, request)


@router.get("/batches/{batch_id}/vouchers", response_model=list[VoucherOut], summary="List individual vouchers within a batch", description="Returns all individual voucher codes and their status within the specified batch. Each voucher shows redemption status and usage without exposing plaintext codes. Requires the voucher.read permission.")
async def list_vouchers(
    batch_id: uuid.UUID,
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user),
):
    return await service.list_vouchers(db, batch_id, scope_for(user))
