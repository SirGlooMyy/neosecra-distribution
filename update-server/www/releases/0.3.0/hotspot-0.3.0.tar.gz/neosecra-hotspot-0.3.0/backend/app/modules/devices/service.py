"""Device CRUD with tenant-tree scope filtering + encrypted credential handling.

Scope (device attaches to location -> customer -> partner):
  - super_admin: all devices
  - partner_admin: devices under locations whose customer.partner_id == scope.partner_id
  - customer_admin: devices under locations whose customer_id == scope.customer_id
  - location_manager: devices at scope.location_id
  - others: deny (fail-closed)

Credentials: plaintext is encrypted here before storage and never decrypted on
read paths going to the API (Mutlak Kural #3).
"""
import uuid

from fastapi import HTTPException, Request, status
from sqlalchemy import false, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.crypto import encrypt
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.devices.models import Device, DeviceCredential
from app.modules.devices.schemas import (
    CredentialOut,
    CredentialSet,
    DeviceCreate,
    DeviceUpdate,
)
from app.modules.firewall_adapters.registry import supported_vendors
from app.modules.locations.models import Location


def _scoped_query(scope: ScopeContext):
    q = select(Device)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = (
            q.join(Location, Device.location_id == Location.id)
            .join(Customer, Location.customer_id == Customer.id)
        )
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        q = q.join(Location, Device.location_id == Location.id)
        return q.where(Location.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        return q.where(Device.location_id == scope.location_id), True
    return q.where(false()), False


async def _resolve_location_for_create(
    db: AsyncSession, location_id: uuid.UUID, scope: ScopeContext
) -> Location:
    """Caller may attach a device to this location?"""
    lq = select(Location)
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        lq = (
            lq.join(Customer, Location.customer_id == Customer.id)
            .where(Location.id == location_id, Customer.partner_id == scope.partner_id)
        )
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        lq = lq.where(Location.id == location_id, Location.customer_id == scope.customer_id)
    elif scope.level == TenantLevel.LOCATION and scope.location_id:
        lq = lq.where(Location.id == location_id, Location.id == scope.location_id)
    elif scope.level == TenantLevel.GLOBAL:
        lq = lq.where(Location.id == location_id)
    else:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Cihaz olusturma yetkiniz yok")
    location = (await db.execute(lq)).scalar_one_or_none()
    if not location:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu lokasyona cihaz ekleyemezsiniz")
    return location


async def list_devices(db: AsyncSession, scope: ScopeContext) -> list[Device]:
    q, _ = _scoped_query(scope)
    # Soft-deleted devices remain available for audit/history but must not be
    # presented as actionable integrations in the operational device list.
    # The registry is also the source of truth for the Hotspot device surface;
    # legacy switch/AP/controller rows are retained for audit but hidden here.
    q = q.where(Device.vendor.in_(supported_vendors()))
    result = await db.execute(q.where(Device.is_active.is_(True)).order_by(Device.created_at.desc()))
    return list(result.scalars().all())


async def get_device(db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext) -> Device:
    q, allowed = _scoped_query(scope)
    result = await db.execute(q.where(Device.id == device_id))
    device = result.scalar_one_or_none()
    if not device:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Cihaz bulunamadi")
    if not allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu cihaza erisim yetkiniz yok")
    return device


async def create_device(
    db: AsyncSession, body: DeviceCreate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> Device:
    if body.vendor.strip().lower() not in supported_vendors():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Desteklenmeyen vendor. Desteklenenler: {supported_vendors()}",
        )
    await _resolve_location_for_create(db, body.location_id, scope)
    device = Device(
        location_id=body.location_id, name=body.name, vendor=body.vendor.strip().lower(),
        model=body.model, mgmt_ip=body.mgmt_ip, api_host=body.api_host,
        api_port=body.api_port, meta=body.meta,
    )
    db.add(device)
    await db.flush()
    await log_audit(db, "device.created", "device", str(device.id), str(actor_id), request,
                    details={"name": body.name, "vendor": device.vendor, "location_id": str(body.location_id)})
    await db.commit()
    await db.refresh(device)
    return device


async def update_device(
    db: AsyncSession, device_id: uuid.UUID, body: DeviceUpdate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> Device:
    device = await get_device(db, device_id, scope)
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(device, k, v)
    await log_audit(db, "device.updated", "device", str(device_id), str(actor_id), request, details=data)
    await db.commit()
    await db.refresh(device)
    return device


async def deactivate_device(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> None:
    device = await get_device(db, device_id, scope)
    device.is_active = False
    await log_audit(db, "device.deactivated", "device", str(device_id), str(actor_id), request)
    await db.commit()


# ---- credentials --------------------------------------------------------
async def set_credential(
    db: AsyncSession, device_id: uuid.UUID, body: CredentialSet, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> CredentialOut:
    device = await get_device(db, device_id, scope)
    cred = (
        await db.execute(select(DeviceCredential).where(DeviceCredential.device_id == device.id))
    ).scalar_one_or_none()
    if not cred:
        cred = DeviceCredential(device_id=device.id, verify_tls=body.verify_tls)
        db.add(cred)
    else:
        cred.verify_tls = body.verify_tls
    if body.api_token is not None:
        cred.api_token_encrypted = encrypt(body.api_token)
    if body.api_username is not None:
        cred.api_username = body.api_username
    if body.api_vdom is not None:
        cred.api_vdom = body.api_vdom
    if body.ssh_key is not None:
        cred.ssh_key_encrypted = encrypt(body.ssh_key)
    await db.flush()
    await log_audit(db, "device.credential_set", "device", str(device.id), str(actor_id), request,
                    details={"token_changed": body.api_token is not None,
                              "ssh_changed": body.ssh_key is not None})
    await db.commit()
    await db.refresh(cred)
    return _credential_out(cred)


async def get_credential_masked(
    db: AsyncSession, device_id: uuid.UUID, scope: ScopeContext
) -> CredentialOut:
    device = await get_device(db, device_id, scope)
    cred = (
        await db.execute(select(DeviceCredential).where(DeviceCredential.device_id == device.id))
    ).scalar_one_or_none()
    if not cred:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kimlik bilgisi tanimli degil")
    return _credential_out(cred)


def _credential_out(cred: DeviceCredential) -> CredentialOut:
    return CredentialOut(
        device_id=cred.device_id,
        api_username=cred.api_username,
        api_vdom=cred.api_vdom,
        verify_tls=cred.verify_tls,
        has_token=bool(cred.api_token_encrypted),
        has_ssh_key=bool(cred.ssh_key_encrypted),
        last_check_ok=cred.last_check_ok,
        last_check_at=cred.last_check_at,
    )
