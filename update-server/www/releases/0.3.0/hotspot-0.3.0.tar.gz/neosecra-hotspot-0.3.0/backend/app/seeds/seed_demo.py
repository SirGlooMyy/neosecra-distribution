"""Demo Seeding Script for Hotspot Platform.

Creates demo tenant, partner, customer, location, FortiGate device, portal config,
license, voucher batch, specific vouchers (DEMO2026, HOTSPOT, GUEST), and users
for all roles (super_admin, partner_admin, customer_admin, support, location_manager).
"""
import asyncio
import hashlib
import sys
from datetime import datetime, timezone

from sqlalchemy import select
from app.core.config import settings
from app.core.database import AsyncSessionLocal
from app.core.security import hash_password
from app.modules.tenants.models import Tenant
from app.modules.partners.models import Partner
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.devices.models import Device
from app.modules.portal.models import PortalTemplate, METHOD_SMS, METHOD_FREE, METHOD_VOUCHER
from app.modules.portal.template_service import PREDEFINED_TEMPLATES
from app.modules.licensing.models import CustomerLicense
from app.modules.vouchers.models import VoucherBatch, Voucher, STATUS_PENDING
from app.modules.auth.models import User
from app.modules.mfa.models import VpnMfaUser
from app.modules.public_content.models import PublicAsset
from app.core.crypto import encrypt

ADMIN_ROLES = {"super_admin", "partner_admin", "customer_admin"}


def get_sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


async def run_seed() -> None:
    print("Starting database seeding...")
    try:
        async with AsyncSessionLocal() as db:
            # 1. Tenant
            tenant = (await db.execute(select(Tenant).where(Tenant.slug == "vdatalab"))).scalar_one_or_none()
            if not tenant:
                tenant = Tenant(
                    name="VDataLab Operator",
                    slug="vdatalab",
                    is_root=True,
                    is_demo=True,
                    is_active=True
                )
                db.add(tenant)
                await db.flush()
                print(f"Created Tenant: {tenant.name} ({tenant.id})")
            else:
                print(f"Found Existing Tenant: {tenant.name} ({tenant.id})")
                if not tenant.is_demo:
                    tenant.is_demo = True
                    print(f"Marked Existing Tenant as demo: {tenant.name} ({tenant.id})")

            # 2. Partner
            partner = (await db.execute(select(Partner).where(Partner.tenant_id == tenant.id))).scalar_one_or_none()
            if not partner:
                partner = Partner(
                    tenant_id=tenant.id,
                    name="Demo Partner",
                    reseller_code="DEMO001",
                    contact_email="partner@demo.io",
                    contact_phone="+905555555555",
                    is_active=True
                )
                db.add(partner)
                await db.flush()
                print(f"Created Partner: {partner.name} ({partner.id})")
            else:
                print(f"Found Existing Partner: {partner.name} ({partner.id})")

            # 3. Customer
            customer = (await db.execute(select(Customer).where(Customer.tenant_id == tenant.id))).scalar_one_or_none()
            if not customer:
                customer = Customer(
                    tenant_id=tenant.id,
                    partner_id=partner.id,
                    name="Acme Cafe",
                    contact_name="Ahmet Yilmaz",
                    contact_email="it@acme.io",
                    contact_phone="+905554443322",
                    is_active=True
                )
                db.add(customer)
                await db.flush()
                print(f"Created Customer: {customer.name} ({customer.id})")
            else:
                print(f"Found Existing Customer: {customer.name} ({customer.id})")

            # 4. Location
            location = (await db.execute(select(Location).where(Location.customer_id == customer.id))).scalar_one_or_none()
            if not location:
                location = Location(
                    customer_id=customer.id,
                    name="Acme Merkez Subesi",
                    address="Karakoy, Beyoglu",
                    city="Istanbul",
                    default_ssid="Acme-Guest",
                    timezone="Europe/Istanbul",
                    is_active=True
                )
                db.add(location)
                await db.flush()
                print(f"Created Location: {location.name} ({location.id})")
            else:
                print(f"Found Existing Location: {location.name} ({location.id})")

            # 5. Device (FortiGate)
            device = (await db.execute(select(Device).where(Device.location_id == location.id))).scalar_one_or_none()
            if not device:
                device = Device(
                    location_id=location.id,
                    name="Demo FortiGate 60F",
                    vendor="fortigate",
                    model="FG-60F",
                    mgmt_ip="192.168.1.99",
                    api_host="192.168.1.99",
                    api_port=443,
                    status="online",
                    is_active=True,
                    meta={"interfaces": ["wan", "lan", "guest-wifi"]}
                )
                db.add(device)
                await db.flush()
                print(f"Created Device: {device.name} ({device.id})")
            else:
                print(f"Found Existing Device: {device.name} ({device.id})")

            # 6. Portal Configuration — create demo templates for different categories
            demo_templates_data = [
                ("Acme Portal (SMS)", METHOD_SMS, True, "hotel_classic"),
                ("Acme Free WiFi", METHOD_FREE, False, "cafe_cozy"),
                ("Acme Voucher Access", METHOD_VOUCHER, False, "business_cowork"),
            ]

            existing_portals = (await db.execute(
                select(PortalTemplate).where(PortalTemplate.customer_id == customer.id)
            )).scalars().all()
            existing_portal_names = {p.name for p in existing_portals}

            for p_name, p_method, p_default, p_predef_id in demo_templates_data:
                if p_name in existing_portal_names:
                    print(f"  Portal template '{p_name}' already exists, skipping")
                    continue
                predef = None
                for t in PREDEFINED_TEMPLATES:
                    if t["id"] == p_predef_id:
                        predef = t
                        break
                theme = dict(predef["default_theme"]) if predef else {}
                portal = PortalTemplate(
                    customer_id=customer.id,
                    location_id=location.id if p_default else None,
                    name=p_name,
                    method=p_method,
                    is_default=p_default,
                    theme=theme,
                    fields=[],
                    success_message="Basariyla giris yaptiniz.",
                    terms_url="https://acme.io/terms",
                    is_active=True,
                )
                db.add(portal)
                print(f"Created Portal Template: {portal.name} ({portal.id})")

            portal = (await db.execute(
                select(PortalTemplate).where(
                    PortalTemplate.customer_id == customer.id,
                    PortalTemplate.is_default,
                )
            )).scalars().first()
            if not portal:
                portal = PortalTemplate(
                    customer_id=customer.id,
                    location_id=location.id,
                    name="Acme Portal Template",
                    method=METHOD_SMS,
                    is_default=True,
                    theme={"primary_color": "#3b82f6", "bg_color": "#f3f4f6", "logo_url": ""},
                    fields=[
                        {"name": "phone", "type": "tel", "required": True},
                        {"name": "tc", "type": "text", "required": False}
                    ],
                    success_message="Basariyla giris yaptiniz.",
                    terms_url="https://acme.io/terms",
                    is_active=True
                )
                db.add(portal)
                await db.flush()
                print(f"Created Portal Template: {portal.name} ({portal.id})")
            else:
                print(f"Found Existing Portal Template: {portal.name} ({portal.id})")

            # 7. Public content / versioned downloads / KB
            public_assets_data = [
                {
                    "section": "release_notes",
                    "slug": "hotspot-platform",
                    "version": settings.VERSION,
                    "title": f"Hotspot Platform {settings.VERSION}",
                    "category": "Release Notes",
                    "summary": "Public content API, versioned downloads ve trial onboarding ilk sürümü.",
                    "body": "Public içerikler backend verisine bağlandı, demo/trial talep formu ve versioned download paketi eklendi.",
                    "sort_order": 100,
                    "checksum": f"release-{settings.VERSION}",
                    "file_size_kb": 0,
                    "meta": {
                        "audience": "all",
                        "release_type": "feature",
                        "channel": "stable",
                        "status": "published",
                        "minimum_version": settings.VERSION,
                        "is_mandatory": False,
                        "upgrade_steps": [
                            "Backend servisini yeni build ile yeniden başlatın.",
                            "Public marketplace ve update center sayfalarını doğrulayın.",
                        ],
                    },
                },
                {
                    "section": "downloads",
                    "slug": "site-bridge-connector-linux-x64",
                    "version": "2.4.1",
                    "title": "Site Bridge Connector (Linux / x64)",
                    "category": "Agent",
                    "summary": "Yerel ağ ile Hotspot arasındaki güvenli köprü ajanı.",
                    "body": "Firewall ve syslog kaynaklarını buluta güvenli şekilde bağlayan site bridge paketi.",
                    "sort_order": 90,
                    "checksum": "d2a4b89e5f0c1",
                    "file_size_kb": 18200,
                    "meta": {"bundle": "site-bridge", "platform": "linux-x64"},
                },
                {
                    "section": "downloads",
                    "slug": "5651-verification-tool",
                    "version": "1.1.0",
                    "title": "5651 XML Damga Doğrulayıcı",
                    "category": "CLI Tool",
                    "summary": "İmzalı log paketlerini çevrimdışı doğrulayan yardımcı araç.",
                    "body": "KamuSM zaman damgalı 5651 arşiv paketlerini doğrulamak için kullanılan bundle.",
                    "sort_order": 80,
                    "checksum": "a1c3f90b8d2e4",
                    "file_size_kb": 8500,
                    "meta": {"bundle": "verify-tool", "platform": "desktop"},
                },
                {
                    "section": "docs",
                    "slug": "quick-start",
                    "version": "1.0.0",
                    "title": "Hotspot Hızlı Başlangıç Kılavuzu",
                    "category": "Başlangıç & Kurulum",
                    "summary": "Sistemin genel mimarisi, gereksinimler ve ilk kurulum adımları.",
                    "body": "Hotspot platformu misafir erişimini, 5651 uyumlu loglamayı ve captive portal akışlarını tek operasyonda toplar.",
                    "sort_order": 100,
                    "meta": {"doc_type": "guide"},
                },
                {
                    "section": "docs",
                    "slug": "site-bridge-setup",
                    "version": "1.0.0",
                    "title": "Site Bridge Ajan Kurulumu",
                    "category": "Başlangıç & Kurulum",
                    "summary": "SaaS platformu ile yerel cihazlar arasında güvenli köprü bağlantısı.",
                    "body": "Site Bridge ajanı firewall, syslog ve correlation kaynaklarını güvenli bir tünel üzerinden bağlar.",
                    "sort_order": 90,
                    "meta": {"doc_type": "guide"},
                },
                {
                    "section": "docs",
                    "slug": "5651-signing-rules",
                    "version": "1.0.0",
                    "title": "5651 Log İmzalama Kuralları",
                    "category": "5651 Sayılı Kanun & Yasal Uyum",
                    "summary": "TÜBİTAK KamuSM zaman damgası entegrasyonu.",
                    "body": "Yasal log paketleri imzalanır, hash zinciri korunur ve doğrulama servisleri ile bütünlük kontrolü yapılır.",
                    "sort_order": 80,
                    "meta": {"doc_type": "compliance"},
                },
                {
                    "section": "docs",
                    "slug": "fortigate-integration",
                    "version": "1.0.0",
                    "title": "FortiGate Entegrasyon Kılavuzu",
                    "category": "Cihaz Entegrasyonları",
                    "summary": "FortiGate Captive Portal ve Syslog ayarları.",
                    "body": "FortiGate, Palo Alto ve benzeri firewall yüzeyleriyle entegrasyon akışları bu modülde standartlaştırılır.",
                    "sort_order": 70,
                    "meta": {"doc_type": "integration"},
                },
                {
                    "section": "kb",
                    "slug": "faq-network-onboarding",
                    "version": "1.0.0",
                    "title": "Ağda İlk Kurulum Sorunları",
                    "category": "Sık Sorulan Sorular",
                    "summary": "Cihaz görünmüyor, portal açılmıyor ve login akışı çalışmıyor soruları.",
                    "body": "Önce cihazın aktif ve lokasyona bağlı olduğunu doğrulayın. Ardından portal template ve firewall redirect ayarlarını kontrol edin.",
                    "sort_order": 100,
                    "meta": {"kb_type": "faq"},
                },
                {
                    "section": "kb",
                    "slug": "faq-5651-signing",
                    "version": "1.0.0",
                    "title": "5651 İmzalama Hatası Nasıl Çözülür",
                    "category": "5651 & Yasal Uyum",
                    "summary": "İmza zinciri, zaman damgası ve arşiv doğrulama hataları.",
                    "body": "İmzalı paketlerde zincir bozuluyorsa önce worker loglarını, certificate serial kayıtlarını ve verify servisini kontrol edin.",
                    "sort_order": 90,
                    "meta": {"kb_type": "troubleshooting"},
                },
                {
                    "section": "kb",
                    "slug": "faq-support-contact",
                    "version": "1.0.0",
                    "title": "Destek Talebi Açma ve Eskalasyon",
                    "category": "Destek Süreçleri",
                    "summary": "Sorun bildirimi, önceliklendirme ve iletişim kanalları.",
                    "body": "Teknik sorunlarda support@hotspot.io adresine, satış ve iş ortaklığı taleplerinde partner@hotspot.io adresine ulaşabilirsiniz.",
                    "sort_order": 80,
                    "meta": {"kb_type": "contact"},
                },
                {
                    "section": "partner",
                    "slug": "partner-program",
                    "version": "2026.1",
                    "title": "İş Ortaklığı Programı",
                    "category": "Partner",
                    "summary": "White-label, teknik destek ve demo/trial onboarding paketi.",
                    "body": "Bayi portali, özel domain, satış desteği ve trial ortamı ile iş ortaklarına hazır paket.",
                    "sort_order": 100,
                    "meta": {"audience": "partner"},
                },
            ]

            existing_public_assets = (
                await db.execute(select(PublicAsset))
            ).scalars().all()
            existing_public_keys = {
                (item.section, item.slug, item.version)
                for item in existing_public_assets
            }

            now = datetime.now(timezone.utc)
            for asset_data in public_assets_data:
                key = (asset_data["section"], asset_data["slug"], asset_data["version"])
                if key in existing_public_keys:
                    print(f"  Public asset '{asset_data['slug']}' already exists, skipping")
                    continue
                asset = PublicAsset(
                    section=asset_data["section"],
                    slug=asset_data["slug"],
                    version=asset_data["version"],
                    title=asset_data["title"],
                    category=asset_data.get("category"),
                    summary=asset_data.get("summary"),
                    body=asset_data["body"],
                    asset_url=None,
                    checksum=asset_data.get("checksum"),
                    file_size_kb=asset_data.get("file_size_kb"),
                    is_current=True,
                    sort_order=asset_data.get("sort_order", 0),
                    meta=asset_data.get("meta", {}),
                    created_at=now,
                    updated_at=now,
                )
                db.add(asset)
                print(f"Created Public Asset: {asset.title} ({asset.section} {asset.version})")

            # 8. Customer License
            license_row = (await db.execute(select(CustomerLicense).where(CustomerLicense.customer_id == customer.id))).scalar_one_or_none()
            if not license_row:
                license_row = CustomerLicense(
                    customer_id=customer.id,
                    active_guests_quota=100,
                    expires_at=datetime(2027, 12, 31, tzinfo=timezone.utc),
                    is_trial=True,
                    is_active=True,
                    plan="enterprise",
                    meta={}
                )
                db.add(license_row)
                await db.flush()
                print(f"Created Customer License for Acme Cafe ({license_row.id})")
            else:
                print(f"Found Existing Customer License ({license_row.id})")

            # 9. Voucher Batch
            batch = (await db.execute(select(VoucherBatch).where(VoucherBatch.customer_id == customer.id))).scalar_one_or_none()
            if not batch:
                batch = VoucherBatch(
                    customer_id=customer.id,
                    location_id=location.id,
                    name="Demo Voucher Batch",
                    prefix="DEMO",
                    count=3,
                    duration_minutes=120,
                    expires_at=datetime(2027, 12, 31, tzinfo=timezone.utc),
                    is_active=True
                )
                db.add(batch)
                await db.flush()
                print(f"Created Voucher Batch: {batch.name} ({batch.id})")
            else:
                print(f"Found Existing Voucher Batch: {batch.name} ({batch.id})")

            # 10. Vouchers: DEMO2026, HOTSPOT, GUEST
            specific_vouchers = ["DEMO2026", "HOTSPOT", "GUEST"]
            for code in specific_vouchers:
                h = get_sha256(code)
                existing_voucher = (await db.execute(select(Voucher).where(Voucher.code_hash == h))).scalar_one_or_none()
                if not existing_voucher:
                    voucher = Voucher(
                        batch_id=batch.id,
                        code_hash=h,
                        code_prefix=code[:6],
                        status=STATUS_PENDING,
                        expires_at=batch.expires_at
                    )
                    db.add(voucher)
                    print(f"Created Demo Voucher: {code}")
                else:
                    print(f"Demo Voucher {code} already exists.")

            # 11. Demo Users: super_admin, partner_admin, customer_admin, support, location_manager
            demo_users = [
                {
                    "email": "admin@hotspot.com",
                    "password": "Admin123!",
                    "full_name": "Demo Super Admin",
                    "role": "super_admin",
                    "tenant_id": None,
                    "partner_id": None,
                    "customer_id": None,
                    "location_id": None
                },
                {
                    "email": "superadmin@hotspot.io",
                    "password": "SuperAdmin123!",
                    "full_name": "Super Admin",
                    "role": "super_admin",
                    "tenant_id": None,
                    "partner_id": None,
                    "customer_id": None,
                    "location_id": None
                },
                {
                    "email": "partneradmin@hotspot.io",
                    "password": "PartnerAdmin123!",
                    "full_name": "Partner Admin",
                    "role": "partner_admin",
                    "tenant_id": tenant.id,
                    "partner_id": partner.id,
                    "customer_id": None,
                    "location_id": None
                },
                {
                    "email": "customeradmin@hotspot.io",
                    "password": "CustomerAdmin123!",
                    "full_name": "Customer Admin",
                    "role": "customer_admin",
                    "tenant_id": tenant.id,
                    "partner_id": partner.id,
                    "customer_id": customer.id,
                    "location_id": None
                },
                {
                    "email": "support@hotspot.io",
                    "password": "Support123!",
                    "full_name": "Support User",
                    "role": "support",
                    "tenant_id": tenant.id,
                    "partner_id": partner.id,
                    "customer_id": customer.id,
                    "location_id": None
                },
                {
                    "email": "manager@hotspot.io",
                    "password": "Manager123!",
                    "full_name": "Location Manager",
                    "role": "location_manager",
                    "tenant_id": tenant.id,
                    "partner_id": partner.id,
                    "customer_id": customer.id,
                    "location_id": location.id
                }
            ]

            for u_data in demo_users:
                existing_user = (await db.execute(select(User).where(User.email == u_data["email"]))).scalar_one_or_none()
                if not existing_user:
                    is_admin = u_data["role"] in ADMIN_ROLES
                    user = User(
                        email=u_data["email"],
                        hashed_password=hash_password(u_data["password"]),
                        full_name=u_data["full_name"],
                        role=u_data["role"],
                        tenant_id=u_data["tenant_id"],
                        partner_id=u_data["partner_id"],
                        customer_id=u_data["customer_id"],
                        location_id=u_data["location_id"],
                        is_active=True,
                        is_2fa_enabled=is_admin,
                        mfa_required=is_admin,
                    )
                    db.add(user)
                    print(f"Created Demo User: {u_data['email']} ({u_data['role']})")
                else:
                    print(f"Demo User {u_data['email']} already exists.")

            # 12. VPN MFA Users
            import pyotp

            vpn_users = [
                {
                    "username": "vpnuser",
                    "password": "VpnUser123!",
                    "mfa_method": "totp",
                    "phone": "+905551234567",
                    "email": "vpnuser@acme.io",
                },
                {
                    "username": "vpnadmin",
                    "password": "VpnAdmin123!",
                    "mfa_method": "totp",
                    "phone": "+905557654321",
                    "email": "vpnadmin@acme.io",
                },
            ]

            for vu in vpn_users:
                existing_vpn = (
                    await db.execute(
                        select(VpnMfaUser).where(
                            VpnMfaUser.username == vu["username"],
                            VpnMfaUser.customer_id == customer.id,
                        )
                    )
                ).scalar_one_or_none()
                if not existing_vpn:
                    totp_secret = pyotp.random_base32()
                    secret_enc = encrypt(totp_secret)
                    vpn_user = VpnMfaUser(
                        customer_id=customer.id,
                        username=vu["username"],
                        mfa_method=vu["mfa_method"],
                        secret_encrypted=secret_enc,
                        phone=vu["phone"],
                        email=vu["email"],
                        is_active=True,
                    )
                    db.add(vpn_user)
                    print(
                        f"Created VPN MFA User: {vu['username']} "
                        f"(secret={totp_secret[:8]}..., phone={vu['phone']})"
                    )
                else:
                    print(f"VPN MFA User {vu['username']} already exists.")

            await db.commit()
            print("Database seeding completed successfully.")

    except Exception as e:
        print("\n[ERROR] Database seeding failed!", file=sys.stderr)
        print(f"[ERROR] Detailed info: {e}", file=sys.stderr)
        print("[ERROR] Please verify that your PostgreSQL server is running and accessible.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    if "--yes" not in sys.argv:
        print("This script will seed the database. To run, use: python -m app.seeds.seed_demo --yes")
        sys.exit(0)
    asyncio.run(run_seed())
