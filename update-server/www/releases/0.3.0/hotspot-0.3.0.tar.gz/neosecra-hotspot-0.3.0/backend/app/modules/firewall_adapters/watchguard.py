"""WatchGuard Firebox adapter — WatchGuard Cloud API / Dimension API.

Supports WatchGuard Firebox via the WatchGuard Cloud API (api.watchguard.com)
and local Dimension API. Auth via API key (Bearer token).
"""
from __future__ import annotations

import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class WatchGuardAdapter(FirewallAdapter):
    vendor = "watchguard"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        token = config.api_token or ""
        self._use_cloud = "cloud" in (config.extra or {}).get("mode", "local")
        if self._use_cloud:
            self._base_url = "https://api.watchguard.com/v1"
        else:
            self._base_url = f"https://{host}:{port}/api/v1"
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {token}",
        }

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"WatchGuard {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            radius_authentication=True,
            radius_accounting=True,
            active_session_query=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            data = await self._request("GET", "devices")
            devices = data.get("data", []) if isinstance(data, dict) else []
            count = len(devices)
            return AdapterResult(
                ok=True,
                message=f"connected: {count} device(s) found",
                data={"device_count": count},
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        data = await self._request("GET", "devices")
        devices = data.get("data", []) if isinstance(data, dict) else data
        if devices:
            d = devices[0] if isinstance(devices, list) else devices
            return {
                "hostname": d.get("name", "") if isinstance(d, dict) else "",
                "model": d.get("model", "") if isinstance(d, dict) else "",
                "serial_number": d.get("serial", "") if isinstance(d, dict) else "",
                "firmware_version": d.get("firmware_version", "") if isinstance(d, dict) else "",
            }
        return {}

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "devices/interfaces")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for iface in raw:
            results.append({
                "name": iface.get("name", ""),
                "ip": iface.get("ip", ""),
                "type": iface.get("type", ""),
                "status": "up" if iface.get("status") == "up" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._request("GET", "captive-portal")
            raw = data.get("data", {}) if isinstance(data, dict) else data
            if isinstance(raw, dict):
                return {
                    "enabled": raw.get("enabled", False),
                    "redirect_url": raw.get("redirect_url", ""),
                }
            return {"enabled": False}
        except AdapterError:
            return {"enabled": False}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "sessions")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for s in raw:
            results.append({
                "ip": s.get("ip", ""),
                "user": s.get("user", ""),
                "mac": s.get("mac", ""),
                "state": s.get("state", ""),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "arp")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for entry in raw:
            results.append({
                "ip": entry.get("ip", ""),
                "mac": entry.get("mac", ""),
                "interface": entry.get("interface", ""),
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "00:00:00:00:00:00")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        payload = {
            "name": name,
            "ip": ip,
            "mac": mac,
            "comment": self._guest_comment(session),
        }
        try:
            await self._request("POST", "allowed-hosts", json=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"host": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            await self._request("DELETE", f"allowed-hosts/{name}")
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "watchguard", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("hostname")
        parsed["event_type"] = parsed.get("type") or parsed.get("msg_type")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        return parsed
