# Repository/data access layer for devices
