# Pydantic schemas for reports
