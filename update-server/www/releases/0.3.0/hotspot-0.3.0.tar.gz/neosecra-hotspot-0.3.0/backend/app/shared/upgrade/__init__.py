"""Shared upgrade verification and orchestrator for the Hotspot platform.

Ported from neosecra-pish with Hotspot-specific adaptations:
- Uses PlatformSetting from app.modules.system.models for persistence
- Default channel URL points to hotspot-stable
- PRODUCT_VERSION env var for current version
"""
