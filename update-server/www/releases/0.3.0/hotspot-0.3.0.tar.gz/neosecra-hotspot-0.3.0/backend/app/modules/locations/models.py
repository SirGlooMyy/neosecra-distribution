"""Location = a physical site / branch of a customer. Devices and SSIDs
attach here; licensing is counted per location."""
import uuid

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk


class Location(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "locations"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    address: Mapped[str | None] = mapped_column(String(500), nullable=True)
    city: Mapped[str | None] = mapped_column(String(100), nullable=True)
    default_ssid: Mapped[str | None] = mapped_column(String(100), nullable=True)
    timezone: Mapped[str | None] = mapped_column(String(50), nullable=True)
