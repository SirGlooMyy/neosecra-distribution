"""Pydantic schemas for customers."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class CustomerBase(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    contact_name: str | None = None
    contact_email: EmailStr | None = None
    contact_phone: str | None = None


class CustomerCreate(CustomerBase):
    partner_id: uuid.UUID | None = None  # required for super_admin; inferred for partner_admin


class CustomerUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    contact_name: str | None = None
    contact_email: EmailStr | None = None
    contact_phone: str | None = None
    is_active: bool | None = None


class CustomerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    tenant_id: uuid.UUID
    partner_id: uuid.UUID | None
    name: str
    contact_name: str | None
    contact_email: str | None
    contact_phone: str | None
    is_active: bool
    created_at: datetime
    updated_at: datetime
