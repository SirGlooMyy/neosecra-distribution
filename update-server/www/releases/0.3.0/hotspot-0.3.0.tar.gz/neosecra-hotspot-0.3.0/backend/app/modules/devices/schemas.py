"""Pydantic schemas for devices. Credential write schemas accept plaintext
secrets only at the boundary; outbound models NEVER expose decrypted tokens
(Mutlak Kural #3 / Yasak)."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.modules.firewall_adapters.registry import supported_vendors


class DeviceBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    vendor: str = Field(..., max_length=50)
    model: str | None = None
    mgmt_ip: str | None = Field(None, max_length=64)
    api_host: str | None = Field(None, max_length=255)
    api_port: int | None = Field(None, ge=1, le=65535)
    meta: dict = Field(default_factory=dict)


class DeviceCreate(DeviceBase):
    location_id: uuid.UUID

    def supported(self) -> bool:
        return self.vendor.strip().lower() in supported_vendors()


class DeviceUpdate(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=255)
    model: str | None = None
    mgmt_ip: str | None = None
    api_host: str | None = None
    api_port: int | None = Field(None, ge=1, le=65535)
    meta: dict | None = None


class DeviceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    location_id: uuid.UUID
    name: str
    vendor: str
    model: str | None = None
    mgmt_ip: str | None = None
    api_host: str | None = None
    api_port: int | None = None
    serial_number: str | None = None
    firmware_version: str | None = None
    status: str
    last_seen_at: datetime | None = None
    meta: dict
    is_active: bool


# ---- credentials ---------------------------------------------------------
class CredentialSet(BaseModel):
    """Plaintext secrets accepted only here, encrypted before storage."""
    api_token: str | None = Field(None, min_length=1, max_length=1000)
    api_username: str | None = Field(None, max_length=255)
    api_vdom: str | None = Field(None, max_length=100)
    ssh_key: str | None = Field(None, max_length=4000)
    verify_tls: bool = True


class CredentialOut(BaseModel):
    """Never includes the token. `has_token` lets the UI show a 'configured'
    badge without leaking the secret."""
    model_config = ConfigDict(from_attributes=True)

    device_id: uuid.UUID
    api_username: str | None = None
    api_vdom: str | None = None
    verify_tls: bool
    has_token: bool = False
    has_ssh_key: bool = False
    last_check_ok: bool | None = None
    last_check_at: datetime | None = None
