"""Archive chunk module — hash chain + local cert CAdES signing + MinIO WORM."""
