import uuid

from sqlalchemy import Boolean, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


class LocalUser(Base, UUIDPK, TimestampMixin):
    __tablename__ = "local_users"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    username: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    email: Mapped[str | None] = mapped_column(String(200), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
