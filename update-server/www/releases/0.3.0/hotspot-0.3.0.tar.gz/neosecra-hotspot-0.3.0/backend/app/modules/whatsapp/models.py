"""WhatsAppVerification = a one-time code sent to a guest phone via WhatsApp
during captive portal auth.

Scope binding: every verification is tied to a customer (+ optional location)
derived from the device the guest is behind. This binds a code to a physical
site and prevents cross-site replay (Mutlak Kural #1/#2).

Security:
  * the code itself is NEVER stored plaintext — only a salted hash (see
    service._hash_code). The plaintext exists only in-memory and in the
    delivery channel.
  * attempts are capped and send-frequency is rate limited per phone via Redis.
"""
import uuid
from datetime import datetime

from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


class WhatsAppVerification(Base, UUIDPK, TimestampMixin):
    __tablename__ = "whatsapp_verifications"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)

    phone: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    code_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    session_info_id: Mapped[str] = mapped_column(String(255), nullable=False)

    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3, nullable=False)

    verified: Mapped[bool] = mapped_column(default=False, nullable=False)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    request_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    delivered: Mapped[bool] = mapped_column(default=False, nullable=False)
    deliver_error: Mapped[str | None] = mapped_column(String(500), nullable=True)
