import httpx
from app.core.config import settings
from .base import SmsProvider


class MuttlProvider(SmsProvider):
    async def send(self, phone: str, message: str) -> tuple[bool, str]:
        url = self.value("http_url", settings.MUTTL_API_URL) or "https://api.muttl.com/v1/send"
        api_key = self.value("api_key", settings.MUTTL_API_KEY)
        if not api_key:
            return False, "muttl-missing-api-key"
        headers = {"Authorization": f"Bearer {api_key}"}
        payload = {"to": phone, "text": message, "from": self.value("sender", settings.SMS_SENDER)}
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json=payload, headers=headers)
            if 200 <= resp.status_code < 300:
                return True, ""
            return False, f"muttl-{resp.status_code}"
        except Exception as exc:
            return False, f"muttl-error:{type(exc).__name__}"
