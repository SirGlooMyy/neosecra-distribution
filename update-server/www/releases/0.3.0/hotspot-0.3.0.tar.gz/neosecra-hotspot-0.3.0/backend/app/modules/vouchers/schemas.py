"""Pydantic schemas for vouchers. Outbound models NEVER include the plaintext
code — it is returned ONLY in BatchCreateResult.codes at generation time
(Mutlak Kural #3 / Yasak)."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class VoucherBatchCreate(BaseModel):
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    name: str = Field(..., min_length=1, max_length=255)
    prefix: str = Field("V", max_length=16)
    count: int = Field(10, ge=1, le=500)
    duration_minutes: int | None = Field(None, ge=1)
    expires_at: datetime | None = None


class VoucherBatchUpdate(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=255)
    duration_minutes: int | None = Field(None, ge=1)
    expires_at: datetime | None = None


class VoucherBatchOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    name: str
    prefix: str
    count: int
    duration_minutes: int | None = None
    expires_at: datetime | None = None
    is_active: bool
    created_at: datetime


class VoucherOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    batch_id: uuid.UUID
    code_prefix: str
    status: str
    used_at: datetime | None = None
    duration_minutes: int | None = None
    expires_at: datetime | None = None


class BatchCreateResult(BaseModel):
    batch: VoucherBatchOut
    codes: list[str]


class RedeemIn(BaseModel):
    code: str = Field(..., min_length=6, max_length=64)


class RedeemOut(BaseModel):
    ok: bool
    duration_minutes: int | None = None
    message: str = ""