"""Zyxel USG / ATP / Nebula adapter.

Supports Zyxel ATP/USG series via REST API and Zyxel Nebula Control Center API.
Nebula mode uses cloud API; local mode uses the device's built-in API.
"""
from __future__ import annotations

import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class ZyxelAdapter(FirewallAdapter):
    vendor = "zyxel"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        token = config.api_token or ""
        self._use_nebula = config.extra.get("nebula", "false").lower() == "true"
        if self._use_nebula:
            self._base_url = "https://api.nebula.zyxel.com/v1"
        else:
            self._base_url = f"https://{host}:{port}/api"
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if token:
            self._headers["Authorization"] = f"Bearer {token}"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"Zyxel {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        data = resp.json()
        if isinstance(data, dict) and data.get("error") is not None:
            raise AdapterError(f"Zyxel {path}: {data.get('message', data)}")
        return data

    async def _nebula_request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=True, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"Zyxel Nebula {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=True,
            radius_authentication=True,
            radius_accounting=True,
            mac_auth_bypass=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        if self._use_nebula:
            try:
                data = await self._nebula_request("GET", "organizations")
                orgs = data.get("organizations", [])
                return AdapterResult(
                    ok=True,
                    message=f"connected: Nebula ({len(orgs)} org(s))",
                    data={"org_count": len(orgs)},
                )
            except (AdapterError, httpx.HTTPError) as exc:
                return AdapterResult(ok=False, message=str(exc))
        try:
            data = await self._request("GET", "system/status")
            sys = data.get("system", {})
            return AdapterResult(
                ok=True,
                message=f"connected: {sys.get('model', '?')}",
                data=sys,
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        if self._use_nebula:
            data = await self._nebula_request("GET", "devices")
            devices = data.get("devices", [])
            if devices:
                d = devices[0]
                return {
                    "hostname": d.get("name", ""),
                    "model": d.get("model", ""),
                    "serial_number": d.get("serial_number", ""),
                    "firmware_version": d.get("firmware_version", ""),
                }
            return {}
        data = await self._request("GET", "system/status")
        sys = data.get("system", {})
        return {
            "hostname": sys.get("hostname", ""),
            "model": sys.get("model", ""),
            "serial_number": sys.get("serial_number", ""),
            "firmware_version": sys.get("firmware_version", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "interface")
        results: list[dict[str, Any]] = []
        for iface in data.get("interfaces", []):
            results.append({
                "name": iface.get("name", ""),
                "ip": iface.get("ip_address", ""),
                "type": iface.get("type", ""),
                "status": "up" if iface.get("status") == "up" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._request("GET", "captive-portal")
            cp = data.get("captive_portal", data)
            return {
                "enabled": cp.get("enabled", False),
                "redirect_url": cp.get("redirect_url", ""),
                "auth_mode": cp.get("auth_mode", ""),
            }
        except AdapterError:
            return {"enabled": False}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "sessions")
        results: list[dict[str, Any]] = []
        for s in data.get("sessions", []):
            results.append({
                "ip": s.get("src_ip", ""),
                "user": s.get("user", ""),
                "mac": s.get("mac", ""),
                "protocol": s.get("protocol", ""),
                "state": s.get("state", ""),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "arp-table")
        results: list[dict[str, Any]] = []
        for entry in data.get("arp", []):
            results.append({
                "ip": entry.get("ip", ""),
                "mac": entry.get("mac", ""),
                "interface": entry.get("interface", ""),
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "00:00:00:00:00:00")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        payload = {
            "name": name,
            "ip_address": ip,
            "mac_address": mac,
            "description": self._guest_comment(session),
        }
        try:
            await self._request("POST", "firewall/allow-list", json=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"entry": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            await self._request("DELETE", f"firewall/allow-list/{name}")
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "zyxel", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("host")
        parsed["event_type"] = parsed.get("type") or parsed.get("category")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        return parsed
