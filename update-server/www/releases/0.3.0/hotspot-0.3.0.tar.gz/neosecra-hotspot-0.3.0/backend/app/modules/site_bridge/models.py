import json
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, String, Text
from sqlalchemy import TypeDecorator
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk


class JSONField(TypeDecorator):
    impl = String
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return json.dumps(value) if value is not None else None

    def process_result_value(self, value, dialect):
        return json.loads(value) if value else {}


class BridgeAgent(Base, UUIDPK, TimestampMixin):
    __tablename__ = "bridge_agents"

    tenant_id: Mapped[uuid.UUID] = fk("tenants", ondelete="CASCADE")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="SET NULL")
    agent_id: Mapped[str] = mapped_column(String(128), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    version: Mapped[str] = mapped_column(String(20), nullable=True)
    public_key: Mapped[str] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    last_heartbeat_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)


class BridgeCommand(Base, UUIDPK, TimestampMixin):
    __tablename__ = "bridge_commands"

    agent_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    command_type: Mapped[str] = mapped_column(String(50), nullable=False)
    payload: Mapped[dict] = mapped_column(JSONField, default={})
    signature: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    executed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    result: Mapped[dict | None] = mapped_column(JSONField, nullable=True)


class BridgeEvent(Base, UUIDPK, TimestampMixin):
    __tablename__ = "bridge_events"

    agent_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    event_type: Mapped[str] = mapped_column(String(50), nullable=False)
    payload: Mapped[dict] = mapped_column(JSONField, default={})
    status: Mapped[str] = mapped_column(String(20), default="received")
