"""RADIUS accounting, authentication event, and challenge models.
"""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, fk

class RadiusEvent(Base, UUIDPK, TimestampMixin):
    """Event schema representing incoming RADIUS accounting / auth packets."""
    __tablename__ = "radius_events"

    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True, index=True)
    username: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    nas_ip: Mapped[str] = mapped_column(String(64), nullable=True)
    nas_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    acct_status_type: Mapped[str | None] = mapped_column(String(20), nullable=True)  # Start, Stop, Interim-Update
    acct_session_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    calling_station_id: Mapped[str | None] = mapped_column(String(64), nullable=True)  # Guest MAC
    framed_ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True)   # Guest IP


class MdbWhitelist(Base, UUIDPK, TimestampMixin):
    """MAC Bypass (MAB) whitelist — yetkili cihaz MAC adresleri."""
    __tablename__ = "mab_whitelist"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    mac_address: Mapped[str] = mapped_column(String(17), unique=True, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class VlanProfile(Base, UUIDPK, TimestampMixin):
    """Dinamik VLAN atama profili — kullanici grubuna gore VLAN ID."""
    __tablename__ = "vlan_profiles"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    vlan_id: Mapped[int] = mapped_column(Integer, nullable=False)
    user_group: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)


class RadiusChallenge(Base, UUIDPK, TimestampMixin):
    """RADIUS Access-Challenge state tracking for VPN MFA flow."""
    __tablename__ = "radius_challenges"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="CASCADE")
    username: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    nas_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    state: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    mfa_method: Mapped[str] = mapped_column(String(20), nullable=False)
    code_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    session_token: Mapped[str | None] = mapped_column(String(255), nullable=True)
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
