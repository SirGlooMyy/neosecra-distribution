"""Authentication guard for machine-to-machine log/event ingestion."""
from __future__ import annotations

import hmac

from fastapi import HTTPException, Request, status

from app.core.config import settings


def require_ingest_api_key(request: Request, *, expected_key: str, service: str) -> None:
    """Fail closed unless a configured key matches the request header.

    In explicit demo mode a loopback request is accepted so the local simulator
    can be started without provisioning a secret. Any non-loopback or production
    deployment must configure a key (preferably via a secret manager).
    """
    supplied = request.headers.get("X-API-Key", "")
    if expected_key:
        if not hmac.compare_digest(supplied, expected_key):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")
        return

    client_host = request.client.host if request.client else ""
    if settings.DEMO_MODE and client_host in {"127.0.0.1", "::1", "testclient"}:
        return
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail=f"{service} ingestion key is not configured",
    )
