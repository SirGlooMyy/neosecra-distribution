"""Schemas for public content and public inquiries."""
import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class PublicBrandOut(BaseModel):
    name: str
    tagline: str
    summary: str
    support_email: str
    sales_email: str
    portal_url: str
    version: str


class PublicStatsOut(BaseModel):
    release_count: int
    download_count: int
    doc_count: int
    kb_count: int
    partner_count: int
    latest_release_version: str | None = None
    latest_download_version: str | None = None


class PublicAssetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    section: str
    slug: str
    version: str
    title: str
    category: str | None = None
    summary: str | None = None
    body: str
    asset_url: str | None = None
    checksum: str | None = None
    file_size_kb: int | None = None
    is_current: bool = True
    sort_order: int = 0
    workflow_status: str | None = None
    meta: dict = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class PublicMarketplaceOut(BaseModel):
    brand: PublicBrandOut
    stats: PublicStatsOut
    highlights: list[str] = Field(default_factory=list)
    featured_release: PublicAssetOut | None = None
    sections: dict[str, list[PublicAssetOut]] = Field(default_factory=dict)


class PublicInquiryCreate(BaseModel):
    inquiry_type: Literal["partner", "trial", "contact"] = "contact"
    source_tab: str | None = None
    name: str = Field(..., min_length=2, max_length=255)
    email: EmailStr
    phone: str | None = Field(None, max_length=40)
    company: str = Field(..., min_length=2, max_length=255)
    role: str | None = Field(None, max_length=100)
    message: str = Field(..., min_length=5, max_length=4000)
    meta: dict = Field(default_factory=dict)


class PublicInquiryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    reference_code: str
    inquiry_type: str
    source_tab: str | None = None
    status: str
    name: str
    email: str
    phone: str | None = None
    company: str
    role: str | None = None
    message: str
    meta: dict = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime


class PublicInquiryStatusUpdate(BaseModel):
    status: Literal["new", "contacted", "qualified", "won", "lost", "archived"] = "contacted"


class PublicTrialProvisionOut(BaseModel):
    inquiry_id: uuid.UUID
    reference_code: str
    inquiry_status: str
    lifecycle_action: str = "provisioned"
    renewal_count: int = 0
    renewed_at: datetime | None = None
    previous_license_expires_at: datetime | None = None
    cleaned_at: datetime | None = None
    cleanup_reason: str | None = None
    tenant_id: uuid.UUID
    tenant_slug: str
    tenant_name: str
    tenant_is_demo: bool
    customer_id: uuid.UUID
    customer_name: str
    location_id: uuid.UUID
    location_name: str
    device_id: uuid.UUID
    device_name: str
    portal_template_id: uuid.UUID
    portal_template_name: str
    portal_method: str
    license_id: uuid.UUID
    license_plan: str
    license_is_trial: bool
    license_expires_at: datetime | None = None
    voucher_batch_id: uuid.UUID
    voucher_prefix: str
    voucher_code: str | None = None
    provisioned_at: datetime
    message: str


PublicSection = Literal["release_notes", "downloads", "docs", "kb", "partner"]


class PublicAssetUpsert(BaseModel):
    section: PublicSection
    slug: str = Field(..., min_length=2, max_length=120)
    version: str = Field(..., min_length=1, max_length=50)
    title: str = Field(..., min_length=2, max_length=255)
    category: str | None = Field(default=None, max_length=120)
    summary: str | None = Field(default=None, max_length=500)
    body: str = Field(..., min_length=5)
    asset_url: str | None = Field(default=None, max_length=500)
    checksum: str | None = Field(default=None, max_length=64)
    file_size_kb: int | None = Field(default=None, ge=0)
    is_current: bool = True
    sort_order: int = 0
    workflow_status: str | None = Field(default=None, max_length=30)
    meta: dict = Field(default_factory=dict)
