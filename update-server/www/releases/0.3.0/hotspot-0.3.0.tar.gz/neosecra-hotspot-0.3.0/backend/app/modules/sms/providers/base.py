from abc import ABC, abstractmethod
from collections.abc import Mapping

from typing import Any


class SmsProvider(ABC):
    """Common provider interface.

    ``config`` is the decrypted, short-lived runtime configuration loaded by
    the SMS service.  Environment settings remain the fallback for backwards
    compatibility, but credentials entered in the admin panel never need to
    be copied into ``settings`` (or process-wide globals).
    """

    def __init__(self, config: Mapping[str, Any] | None = None):
        self.config = dict(config or {})

    def value(self, key: str, fallback: Any = "") -> Any:
        value = self.config.get(key)
        return fallback if value in (None, "") else value

    @abstractmethod
    async def send(self, phone: str, message: str) -> tuple[bool, str]:
        ...
