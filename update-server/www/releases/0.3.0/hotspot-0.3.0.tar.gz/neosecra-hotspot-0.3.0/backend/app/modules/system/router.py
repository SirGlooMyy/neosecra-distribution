"""System Management endpoints.

Covers Backup/Restore, White-Label branding, SMTP email config,
update/release management, and advanced dashboard stats.

All endpoints require super_admin or system.* permission (Mutlak Kural #12).
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile, status
from fastapi.responses import Response, StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import customer_in_scope, scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.system import (
    backup_service,
    dashboard_service,
    email_service,
    update_service,
    whitelabel_service,
)
from app.modules.system.schemas import SystemUpdateOut, SystemUpdateSnapshotOut, SystemUpdateUpsertIn
from app.shared.licensing.license_service import (
    delete_platform_license,
    get_platform_license,
    get_platform_usage,
    save_platform_license,
)
from app.shared.upgrade.upgrade_service import (
    UpgradeConflict,
    UpgradeError,
    UpgradeNotEnabled,
    check_available_updates,
    get_current_system_info,
    get_upgrade_history,
    orchestrator,
    provider as upgrade_provider,
    run_preflight_checks,
)

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


def _require_super_admin(user: User) -> None:
    if user.role != "super_admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu islem sadece super_admin icin")


async def _resolve_customer_id(
    db: AsyncSession, user: User, requested: uuid.UUID | None
) -> uuid.UUID | None:
    """Resolve an optional customer filter for dashboard queries.

    A super admin has global scope, so an omitted customer_id means the
    platform-wide aggregate rather than an invalid request. Scoped users must
    still resolve to their assigned customer and cannot broaden the query.
    """
    scope = scope_for(user)
    customer_id = requested or scope.customer_id
    # This is a single-installation product.  A super-admin has no legacy
    # customer assignment in the token, so resolve the one ownership anchor
    # automatically instead of forcing every dashboard request to carry a
    # customer_id query parameter.
    if not customer_id and scope.level.value == "global":
        customer_id = await resolve_installation_customer(db)
    if not customer_id:
        raise HTTPException(status_code=400, detail="Musteri ID gerekli")
    if not await customer_in_scope(db, scope, customer_id):
        raise HTTPException(status_code=403, detail="Musteri scope disinda")
    return customer_id


# ---- Health -------------------------------------------------------------------

@router.get("/health", summary="Check overall system health status", description="Returns the current health status of system components including database connectivity, queue backlogs, and service availability. Requires the system.read permission.")
async def system_health(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    return await dashboard_service.get_system_health(db)


# ---- Backups ------------------------------------------------------------------

@router.get("/backups", summary="List all system backups", description="Returns a list of all backup archives created in the system including type, size, and creation timestamp. Requires the system.read permission.")
async def list_backups(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    _require_super_admin(user)
    return await backup_service.list_backups(db)


@router.post("/backups", status_code=201, summary="Create a new system backup of specified type", description="Initiates a backup process for the specified type: full, db, or config. Returns job tracking information for monitoring progress. Requires the system.write permission.")
async def create_backup(
    type: str = Query("full", description="full|db|config|archives"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    _require_super_admin(user)
    if type == "full":
        return await backup_service.start_full_backup(db, user.id)
    elif type == "db":
        return await backup_service.start_db_backup(db, user.id)
    elif type == "config":
        return await backup_service.start_config_backup(db, user.id)
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Gecersiz yedekleme tipi: full, db, config veya archives olmali",
        )


@router.post("/backups/{backup_id}/restore", summary="Restore system from a backup archive", description="Restores system data from the specified backup. This operation will overwrite current data. Only available for super_admin users. Requires the system.write permission.")
async def restore_backup(
    backup_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    _require_super_admin(user)
    try:
        return await backup_service.restore_from_backup(db, backup_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


@router.delete("/backups/{backup_id}", status_code=204, summary="Delete a system backup archive", description="Permanently removes the specified backup archive from storage. This action cannot be undone. Requires the system.write permission.")
async def delete_backup(
    backup_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    _require_super_admin(user)
    await backup_service.delete_backup(db, backup_id)


# ---- White-Label Branding -----------------------------------------------------

@router.get("/whitelabel", summary="Get white-label branding configuration", description="Returns the white-label branding settings for the specified tenant or customer including logo, colors, and custom domain. Requires the system.read permission.")
async def get_whitelabel(
    tenant_id: uuid.UUID | None = Query(None),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    if customer_id is None and tenant_id is None:
        customer_id = await resolve_installation_customer(db)
    cfg = await whitelabel_service.get_config(db, tenant_id, customer_id)
    if not cfg:
        # The settings page is also the onboarding surface.  A missing
        # override is a valid default state and should not be rendered as a
        # failed API request.
        return {
            "brand_name": "Hotspot",
            "brand_logo_url": None,
            "primary_color": "#4F46E5",
            "secondary_color": "#7C3AED",
            "accent_color": "#10B981",
            "custom_domain": None,
            "custom_favicon_url": None,
            "support_email": None,
            "support_phone": None,
            "footer_text": None,
            "terms_url": None,
            "privacy_url": None,
            "is_active": True,
        }
    return cfg


@router.put("/whitelabel", summary="Update white-label branding configuration", description="Creates or updates branding settings including logos, color scheme, and custom domain for a scope (platform, tenant, or customer). Requires the system.write permission.")
async def update_whitelabel(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    scope_type = body.get("scope_type", "platform")
    scope_id = body.get("scope_id")
    if scope_type == "customer" and not scope_id:
        scope_id = await resolve_installation_customer(db)
    return await whitelabel_service.upsert_config(db, scope_type, scope_id, body)


@router.post("/whitelabel/upload", summary="Upload a brand asset file for white-labeling", description="Uploads a brand asset such as a logo or favicon for white-label customization. Supports various image formats. Returns the URL of the uploaded asset. Requires the system.write permission.")
async def upload_brand_asset(
    scope_type: str = Query("platform"),
    scope_id: uuid.UUID | None = Query(None),
    asset_type: str = Query("logo"),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    data = await file.read()
    url = await whitelabel_service.upload_brand_asset(
        db, scope_type, scope_id, data, asset_type, file.filename or "asset.png"
    )
    return {"url": url, "asset_type": asset_type}


# ---- Email / SMTP Config ------------------------------------------------------

@router.get("/email/config", summary="Get SMTP email configuration", description="Returns the SMTP email configuration for the specified customer including server, port, and sender details. Secrets such as passwords are masked. Requires the system.read permission.")
async def get_email_config(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    if customer_id is None:
        customer_id = await resolve_installation_customer(db)
    cfg = await email_service.get_config(db, customer_id)
    if not cfg:
        return {
            "id": None,
            "customer_id": customer_id,
            "smtp_host": "",
            "smtp_port": 587,
            "smtp_username": "",
            "smtp_password": "",
            "smtp_use_tls": True,
            "smtp_use_ssl": False,
            "from_address": "",
            "from_name": "",
            "is_verified": False,
        }
    return cfg


@router.put("/email/config", summary="Update SMTP email configuration", description="Creates or updates the SMTP email settings including server, credentials, and sender address. Sensitive fields are encrypted before storage. Requires the system.write permission.")
async def update_email_config(
    body: dict,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    customer_id = body.get("customer_id")
    if not customer_id:
        customer_id = str(await resolve_installation_customer(db))
        body = {**body, "customer_id": customer_id}
    return await email_service.upsert_config(db, customer_id, body)


@router.post("/email/test", summary="Test SMTP email connection and deliverability", description="Sends a test email to verify the SMTP configuration is working correctly. Returns success or failure details. Requires the system.write permission.")
async def test_email(
    config_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await email_service.test_connection(db, config_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


# ---- Platform license + host update-agent -----------------------------------

@router.get("/license", summary="Get the installed signed platform license")
async def get_platform_license_endpoint(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    _require(user, "system.read")
    license_data = await get_platform_license(db)
    return license_data or {"status": "NOT_ACTIVATED", "enabled_modules": []}


@router.get("/license/usage", summary="Get platform usage against license limits")
async def get_platform_license_usage(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    _require(user, "system.read")
    return await get_platform_usage(db)


@router.post("/license/activate", summary="Install a signed license envelope")
async def activate_platform_license(body: dict, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.write")
    envelope = str(body.get("license_key") or body.get("license_envelope") or "").strip()
    if not envelope or not await save_platform_license(db, envelope, user_id=str(user.id)):
        raise HTTPException(status_code=400, detail="LICENSE_SIGNATURE_INVALID")
    return await get_platform_license(db)


@router.post("/license/upload", summary="Install a signed .lic file")
async def upload_platform_license(file: UploadFile = File(...), db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.write")
    content = await file.read()
    try:
        envelope = content.decode("utf-8").strip()
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="LICENSE_FORMAT_INVALID")
    if not await save_platform_license(db, envelope, user_id=str(user.id)):
        raise HTTPException(status_code=400, detail="LICENSE_SIGNATURE_INVALID")
    return await get_platform_license(db)


@router.post("/license/validate", summary="Revalidate installed license")
async def validate_platform_license(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    license_data = await get_platform_license(db)
    if not license_data:
        raise HTTPException(status_code=404, detail="LICENSE_NOT_INSTALLED")
    return license_data


@router.delete("/license", status_code=204, summary="Remove installed platform license")
async def remove_platform_license(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.write")
    await delete_platform_license(db)


@router.get("/version", summary="Get running platform version")
async def platform_version(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return await get_current_system_info(db)


@router.get("/updates/capability", summary="Get truthful update-agent capability")
async def update_capability(user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return upgrade_provider.get_capabilities()


@router.post("/updates/check", summary="Check signed distribution channel")
async def check_updates(request: Request, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return await check_available_updates(db)


@router.post("/updates/preflight", summary="Run update preflight checks")
async def update_preflight(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return {"checks": await run_preflight_checks(db)}


@router.post("/updates/start", summary="Start a one-click host update")
async def start_update(body: dict, request: Request, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.write")
    target = str(body.get("target_version") or "").strip()
    try:
        session = await orchestrator.start_upgrade(db, target, str(user.id))
    except UpgradeNotEnabled:
        raise HTTPException(status_code=501, detail="UPGRADE_EXECUTION_NOT_SUPPORTED")
    except UpgradeConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except UpgradeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"session": session}


@router.get("/updates/session", summary="Get live update-agent session")
async def update_session(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return {"session": await orchestrator.get_session(db)}


@router.get("/updates/history", summary="Get update history")
async def update_history(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return {"history": await get_upgrade_history(db)}


@router.post("/updates/jobs/{job_id}/rollback", summary="Request host rollback")
async def rollback_update(job_id: str, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.write")
    try:
        session = await orchestrator.rollback(db, job_id, str(user.id))
    except UpgradeNotEnabled:
        raise HTTPException(status_code=501, detail="ROLLBACK_NOT_SUPPORTED")
    except UpgradeConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except UpgradeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"session": session}


# Compatibility aliases kept for older Hotspot admin bundles. New clients use
# /system/version and /system/updates/*, but existing installations may still
# request the original platform-upgrade URLs during a rolling frontend update.
@router.get("/platform-upgrade/info", include_in_schema=False)
async def legacy_upgrade_info(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return await get_current_system_info(db)


@router.get("/platform-upgrade/status", include_in_schema=False)
async def legacy_upgrade_status(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return {"status": (await get_current_system_info(db)).get("upgrade_status", "IDLE")}


@router.get("/platform-upgrade/check", include_in_schema=False)
async def legacy_upgrade_check(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return await check_available_updates(db)


@router.get("/platform-upgrade/history", include_in_schema=False)
async def legacy_upgrade_history(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return {"history": await get_upgrade_history(db)}


@router.post("/platform-upgrade/preflight", include_in_schema=False)
async def legacy_upgrade_preflight(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.read")
    return {"checks": await run_preflight_checks(db)}


@router.post("/platform-upgrade/start", include_in_schema=False)
async def legacy_upgrade_start(body: dict, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    _require(user, "system.write")
    try:
        return {"session": await orchestrator.start_upgrade(db, str(body.get("target_version") or ""), str(user.id))}
    except UpgradeNotEnabled as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except UpgradeConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except UpgradeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ---- Updates / Release Notes --------------------------------------------------

@router.get("/updates", response_model=SystemUpdateSnapshotOut, summary="List system updates and release history", description="Returns a snapshot of all system updates including versions, release dates, and current activation status. Requires the system.read permission.")
async def list_updates(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    return await update_service.get_update_snapshot(db)


@router.post("/updates", response_model=SystemUpdateOut, status_code=status.HTTP_201_CREATED, summary="Create a new system update release", description="Creates a new update release with version metadata and artifact references. The release is initially saved as a draft and can be published later. Requires the system.write permission.")
async def create_update(
    body: SystemUpdateUpsertIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await update_service.create_update_release(
            db,
            body,
            publish=False,
            published_by=str(user.id),
            request=request,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.put("/updates/{release_id}", response_model=SystemUpdateOut, summary="Update a system release metadata", description="Modifies the metadata and artifacts of an existing system update release. Only unpublished releases can be edited. Requires the system.write permission.")
async def update_release(
    release_id: uuid.UUID,
    body: SystemUpdateUpsertIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await update_service.update_update_release(
            db,
            release_id,
            body,
            publish=False,
            published_by=str(user.id),
            request=request,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.post("/updates/{release_id}/publish", summary="Publish a system update release for distribution", description="Marks the specified release as published, making it available for distribution to target systems. A published release cannot be edited. Requires the system.write permission.")
async def publish_release(
    release_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await update_service.publish_update_release(
            db,
            release_id,
            published_by=str(user.id),
            request=request,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.post("/updates/{release_id}/activate", summary="Activate a system update release", description="Activates the specified release, making it the currently running version. This may trigger system restart or migration procedures. Requires the system.write permission.")
async def activate_release(
    release_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await update_service.activate_update_release(
            db,
            release_id,
            activated_by=str(user.id),
            request=request,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.post("/updates/{release_id}/archive", summary="Archive a system update release", description="Archives the specified release, removing it from active distribution while preserving records. Archived releases can be restored if needed. Requires the system.write permission.")
async def archive_release(
    release_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.write")
    try:
        return await update_service.archive_update_release(
            db,
            release_id,
            archived_by=str(user.id),
            request=request,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.get("/updates/{release_id}/bundle", summary="Download the update bundle ZIP for a release", description="Downloads the complete update distribution bundle for the specified release as a ZIP file. Includes all artifacts and migration scripts. Requires the system.read permission.")
async def download_update_bundle(
    release_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    try:
        release = await update_service._fetch_release(db, release_id)
        bundle, filename = update_service.get_release_bundle_payload(release)
        await update_service.log_audit(
            db,
            "system.update_release.bundle_downloaded",
            "system_update_release",
            str(release_id),
            str(user.id),
            request,
            details={
                "version": release.version,
                "slug": release.slug,
                "filename": filename,
            },
        )
        await db.commit()
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return StreamingResponse(iter([bundle]), media_type="application/zip", headers=headers)


@router.get("/updates/{release_id}/manifest", summary="Download the distribution manifest JSON for a release", description="Downloads the distribution manifest as a JSON file containing metadata about the release including checksums, dependencies, and deployment instructions. Requires the system.read permission.")
async def download_update_manifest(
    release_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    try:
        release = await update_service._fetch_release(db, release_id)
        meta = dict(getattr(release, "meta", None) or {})
        generated_at = (
            update_service._parse_datetime(meta.get("distribution_manifest_generated_at"))
            or update_service._parse_datetime(meta.get("artifact_generated_at"))
            or update_service._parse_datetime(meta.get("published_at"))
            or release.updated_at
        )
        payload, filename, manifest = update_service.build_update_distribution_manifest(
            release,
            generated_at=generated_at,
        )
        await update_service.log_audit(
            db,
            "system.update_release.distribution_manifest_downloaded",
            "system_update_release",
            str(release_id),
            str(user.id),
            request,
            details={
                "version": release.version,
                "slug": release.slug,
                "filename": filename,
                "distribution_status": manifest.get("distribution_status"),
            },
        )
        await db.commit()
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=payload, media_type="application/json", headers=headers)


# ---- Dashboard Stats ----------------------------------------------------------

@router.get(
    "/dashboard/overview",
    summary="Get the complete multi-location dashboard snapshot",
    description="Returns the single-installation dashboard payload: realtime sessions, traffic, authentication, trends, heatmap, top users, and top locations.",
)
async def dashboard_overview(
    days: int = Query(30, ge=1, le=365),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    cid = await _resolve_customer_id(db, user, customer_id)
    return await dashboard_service.get_dashboard_overview(db, cid, trend_days=days)

@router.get("/dashboard/realtime", summary="Get real-time dashboard statistics for a customer", description="Returns live dashboard data including active sessions, current guest count, and system metrics. Useful for real-time monitoring dashboards. Requires the system.read permission.")
@router.get("/dashboard/extended-stats", summary="Get extended real-time dashboard statistics", description="Returns extended real-time statistics for a customer including additional metrics beyond the standard realtime endpoint. Both routes share the same handler. Requires the system.read permission.")
async def dashboard_realtime(
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    cid = await _resolve_customer_id(db, user, customer_id)
    return await dashboard_service.get_realtime_stats(db, cid)


@router.get("/dashboard/trends", summary="Get daily trend data for dashboard charts", description="Returns daily trend data over the specified number of days including session counts, new users, and activity patterns. Requires the system.read permission.")
@router.get("/dashboard/daily-trend", summary="Get daily trend data (alternate route)", description="Alias route for daily trend data. Returns the same data as the /dashboard/trends endpoint. Requires the system.read permission.")
async def dashboard_trends(
    days: int = Query(30, ge=1, le=365),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    cid = await _resolve_customer_id(db, user, customer_id)
    return await dashboard_service.get_trend_data(db, cid, days)


@router.get("/dashboard/os-browser", summary="Get OS and browser distribution statistics", description="Returns the distribution of operating systems and browsers used by guests within the specified period. Useful for understanding client diversity. Requires the system.read permission.")
@router.get("/dashboard/os-browser-dist", summary="Get OS and browser distribution (alternate route)", description="Alias route for OS and browser distribution data. Returns the same data as /dashboard/os-browser. Requires the system.read permission.")
async def dashboard_os_browser(
    period_days: int = Query(7, ge=1, le=90),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    cid = await _resolve_customer_id(db, user, customer_id)
    return await dashboard_service.get_os_browser_stats(db, cid, period_days)


@router.get("/dashboard/auth-methods", summary="Get authentication method distribution statistics", description="Returns the distribution of authentication methods used by guests (voucher, SMS, social login, etc.) within the specified period. Requires the system.read permission.")
@router.get("/dashboard/auth-method-dist", summary="Get auth method distribution (alternate route)", description="Alias route for authentication method distribution data. Returns the same data as /dashboard/auth-methods. Requires the system.read permission.")
async def dashboard_auth_methods(
    period_days: int = Query(30, ge=1, le=365),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    cid = await _resolve_customer_id(db, user, customer_id)
    return await dashboard_service.get_auth_method_distribution(db, cid, period_days)


@router.get("/dashboard/heatmap", summary="Get hourly heatmap data for guest activity", description="Returns hourly activity heatmap data over the specified number of days showing peak usage patterns. Useful for capacity planning and trend analysis. Requires the system.read permission.")
@router.get("/dashboard/hourly-heatmap", summary="Get hourly heatmap data (alternate route)", description="Alias route for hourly heatmap data. Returns the same data as /dashboard/heatmap. Requires the system.read permission.")
async def dashboard_heatmap(
    days: int = Query(7, ge=1, le=90),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    cid = await _resolve_customer_id(db, user, customer_id)
    return await dashboard_service.get_hourly_heatmap(db, cid, days)


@router.get("/dashboard/top-locations", summary="Get top locations by guest activity", description="Returns the most active locations ranked by guest session count within the specified period. Useful for identifying high-traffic venues. Requires the system.read permission.")
async def dashboard_top_locations(
    limit: int = Query(10, ge=1, le=100),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    cid = await _resolve_customer_id(db, user, customer_id)
    return await dashboard_service.get_top_locations(db, cid, limit)


@router.get("/dashboard/top-users", summary="Get top users by session frequency", description="Returns the most frequent guest users ranked by session count within the specified period. Useful for identifying power users and loyalty trends. Requires the system.read permission.")
async def dashboard_top_users(
    limit: int = Query(10, ge=1, le=100),
    customer_id: uuid.UUID | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "system.read")
    cid = await _resolve_customer_id(db, user, customer_id)
    return await dashboard_service.get_top_users(db, cid, limit)
