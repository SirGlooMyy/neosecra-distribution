from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class BridgeAgentRegisterIn(BaseModel):
    agent_id: str
    name: str
    version: str | None = None
    public_key: str | None = None


class BridgeAgentOut(BaseModel):
    id: UUID
    agent_id: str
    name: str
    version: str | None = None
    is_active: bool
    last_heartbeat_at: datetime | None = None
    last_ip: str | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class BridgeHeartbeatIn(BaseModel):
    agent_id: str
    version: str | None = None


class BridgeCommandIn(BaseModel):
    agent_id: str
    command_type: str
    payload: dict = {}


class BridgeCommandOut(BaseModel):
    id: UUID
    agent_id: str
    command_type: str
    payload: dict
    status: str
    executed_at: datetime | None = None
    result: dict | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class BridgeCommandResultIn(BaseModel):
    command_id: UUID
    status: str
    result: dict = {}


class BridgeEventIn(BaseModel):
    agent_id: str
    event_type: str
    payload: dict = {}
