"""Location HTTP endpoints. Read scoped; create/update/delete = location.write."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.locations import service
from app.modules.locations.schemas import LocationCreate, LocationOut, LocationUpdate

router = APIRouter()


@router.get("", response_model=list[LocationOut], summary="List all locations accessible to the current user", description="Returns a list of locations scoped to the authenticated user's tenant. Non-super-admin users only see locations within their own scope. Requires a valid access token.")
async def list_locations(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await service.list_locations(db, scope_for(user))


@router.get("/{location_id}", response_model=LocationOut, summary="Retrieve a single location by unique identifier", description="Fetches detailed information for the specified location. Access is scoped to the user's tenant permissions. Requires a valid access token.")
async def get_location(
    location_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await service.get_location(db, location_id, scope_for(user))


@router.post("", response_model=LocationOut, status_code=status.HTTP_201_CREATED, summary="Create a new location record", description="Creates a new location within the user's tenant scope. Requires the location.write permission. Returns the created location details including its unique identifier.")
async def create_location(
    body: LocationCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not has_permission(user.role, "location.write"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Lokasyon olusturma yetkiniz yok")
    scope = scope_for(user)
    if body.customer_id is None:
        body.customer_id = scope.customer_id or await resolve_installation_customer(db)
    return await service.create_location(db, body, scope, user.id, request)


@router.put("/{location_id}", response_model=LocationOut, summary="Update an existing location record", description="Updates the specified location's information such as name, address, or configuration. Requires the location.write permission. Returns the updated location object.")
async def update_location(
    location_id: uuid.UUID,
    body: LocationUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not has_permission(user.role, "location.write"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Lokasyon guncelleme yetkiniz yok")
    return await service.update_location(db, location_id, body, scope_for(user), user.id, request)


@router.delete("/{location_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Deactivate a location record (soft delete)", description="Deactivates the specified location, making it inactive while preserving data for auditing. Requires the location.write permission. Returns 204 No Content on success.")
async def delete_location(
    location_id: uuid.UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not has_permission(user.role, "location.write"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Lokasyon silme yetkiniz yok")
    await service.deactivate_location(db, location_id, scope_for(user), user.id, request)
