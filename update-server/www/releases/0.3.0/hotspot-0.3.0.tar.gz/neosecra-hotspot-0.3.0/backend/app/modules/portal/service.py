"""PortalTemplate CRUD with scope filtering + single-default enforcement.

Scope axis = customer (-> partner), matching the customers module:
  - super_admin: all templates
  - partner_admin: templates of customers whose partner_id == scope.partner_id
  - customer_admin: templates where customer_id == scope.customer_id
  - location_manager: templates at scope.location_id (or its customer default)
  - others: deny (fail-closed)

At most one template per (customer, location|None) is the default; setting a
new default clears the previous one within that bucket.
"""
from copy import deepcopy
from datetime import datetime, timezone
import uuid

from fastapi import HTTPException, Request, status
from sqlalchemy import false, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.audit.service import log_audit
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.portal.models import PortalTemplate
from app.modules.portal.schemas import (
    PortalTemplateCreate,
    PortalTemplateHistoryOut,
    PortalTemplateRevisionOut,
    PortalTemplateUpdate,
)

_MAX_TEMPLATE_REVISIONS = 20


async def _scoped_query_async(db: AsyncSession, scope: ScopeContext):
    """Scope query that may need a DB lookup (location -> customer)."""
    q = select(PortalTemplate)
    if scope.level == TenantLevel.GLOBAL:
        return q, True
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        q = q.join(Customer, PortalTemplate.customer_id == Customer.id)
        return q.where(Customer.partner_id == scope.partner_id), True
    if scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        return q.where(PortalTemplate.customer_id == scope.customer_id), True
    if scope.level == TenantLevel.LOCATION and scope.location_id:
        loc = (
            await db.execute(select(Location).where(Location.id == scope.location_id))
        ).scalar_one_or_none()
        if not loc:
            return q.where(false()), False
        return q.where(
            (PortalTemplate.location_id == scope.location_id)
            | ((PortalTemplate.customer_id == loc.customer_id) & (PortalTemplate.location_id.is_(None)))
        ), True
    return q.where(false()), False


async def _resolve_customer_for_create(
    db: AsyncSession, customer_id: uuid.UUID, scope: ScopeContext
) -> Customer:
    cq = select(Customer)
    if scope.level == TenantLevel.PARTNER and scope.partner_id:
        cq = cq.where(Customer.id == customer_id, Customer.partner_id == scope.partner_id)
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        cq = cq.where(Customer.id == customer_id, Customer.id == scope.customer_id)
    elif scope.level == TenantLevel.GLOBAL:
        cq = cq.where(Customer.id == customer_id)
    else:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Portal sablonu olusturma yetkiniz yok")
    customer = (await db.execute(cq)).scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu musteriye sablon ekleyemezsiniz")
    return customer


async def _validate_location_owns_customer(
    db: AsyncSession, customer_id: uuid.UUID, location_id: uuid.UUID | None
) -> None:
    if location_id is None:
        return
    loc = (
        await db.execute(select(Location).where(Location.id == location_id))
    ).scalar_one_or_none()
    if not loc or loc.customer_id != customer_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Lokasyon bu musteriye ait degil")


async def _enforce_single_default(
    db: AsyncSession, customer_id: uuid.UUID, location_id: uuid.UUID | None
) -> None:
    """Clear any prior default within the same (customer, location) bucket."""
    cond = [PortalTemplate.customer_id == customer_id, PortalTemplate.is_default.is_(True)]
    if location_id is None:
        cond.append(PortalTemplate.location_id.is_(None))
    else:
        cond.append(PortalTemplate.location_id == location_id)
    await db.execute(update(PortalTemplate).where(*cond).values(is_default=False))


def _template_meta(template: PortalTemplate) -> dict:
    return dict(template.meta or {})


def _normalize_revision(value: object) -> int:
    try:
        parsed = int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 1
    return parsed if parsed > 0 else 1


def _clean_revision_meta(meta: dict) -> dict:
    return {
        key: deepcopy(value)
        for key, value in meta.items()
        if key
        not in {
            "revision",
            "revision_history",
            "revision_action",
            "revision_updated_at",
            "revision_updated_by",
            "restored_from_revision",
        }
    }


def _serialize_revision_snapshot(
    template: PortalTemplate,
    *,
    revision: int,
    action: str,
    actor_id: uuid.UUID | str | None,
    saved_at: datetime | None = None,
) -> dict:
    meta = _clean_revision_meta(_template_meta(template))
    return {
        "revision": revision,
        "action": action,
        "saved_at": (saved_at or datetime.now(timezone.utc)).isoformat(),
        "saved_by": str(actor_id) if actor_id is not None else None,
        "is_active": template.is_active,
        "name": template.name,
        "method": template.method,
        "is_default": template.is_default,
        "theme": deepcopy(template.theme or {}),
        "fields": deepcopy(template.fields or []),
        "success_message": template.success_message,
        "terms_url": template.terms_url,
        "meta": meta,
    }


def _revision_history_from_meta(meta: dict) -> list[dict]:
    history = meta.get("revision_history") or []
    if not isinstance(history, list):
        return []
    return [item for item in history if isinstance(item, dict)]


def _revision_number_from_meta(meta: dict) -> int:
    return _normalize_revision(meta.get("revision"))


def _parse_revision_timestamp(value: object, *, fallback_now: bool = False) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            return datetime.now(timezone.utc) if fallback_now else None
    return datetime.now(timezone.utc) if fallback_now else None


def _revision_snapshot_to_model(snapshot: dict) -> PortalTemplateRevisionOut:
    return PortalTemplateRevisionOut(
        revision=_normalize_revision(snapshot.get("revision")),
        action=str(snapshot.get("action") or "updated"),
        saved_at=_parse_revision_timestamp(snapshot.get("saved_at"), fallback_now=True)
        or datetime.now(timezone.utc),
        saved_by=str(snapshot.get("saved_by")) if snapshot.get("saved_by") is not None else None,
        is_active=bool(snapshot.get("is_active", True)),
        name=str(snapshot.get("name") or ""),
        method=str(snapshot.get("method") or "free"),
        is_default=bool(snapshot.get("is_default")),
        theme=deepcopy(snapshot.get("theme") or {}),
        fields=deepcopy(snapshot.get("fields") or []),
        success_message=snapshot.get("success_message"),
        terms_url=snapshot.get("terms_url"),
        meta=deepcopy(snapshot.get("meta") or {}),
    )


def _current_revision_snapshot(template: PortalTemplate) -> dict:
    meta = _template_meta(template)
    saved_at = (
        _parse_revision_timestamp(meta.get("revision_updated_at"))
        or getattr(template, "updated_at", None)
        or getattr(template, "created_at", None)
    )
    return _serialize_revision_snapshot(
        template,
        revision=_revision_number_from_meta(meta),
        action=str(meta.get("revision_action") or "current"),
        actor_id=meta.get("revision_updated_by"),
        saved_at=saved_at if isinstance(saved_at, datetime) else datetime.now(timezone.utc),
    )


def _decorate_template(template: PortalTemplate) -> PortalTemplate:
    meta = _template_meta(template)
    revision = _revision_number_from_meta(meta)
    template.revision = revision  # type: ignore[attr-defined]
    template.revision_action = str(meta.get("revision_action")) if meta.get("revision_action") else None  # type: ignore[attr-defined]
    template.revision_updated_at = (  # type: ignore[attr-defined]
        _parse_revision_timestamp(meta.get("revision_updated_at"))
        or getattr(template, "updated_at", None)
        or getattr(template, "created_at", None)
    )
    template.revision_updated_by = meta.get("revision_updated_by")  # type: ignore[attr-defined]
    return template


def _replace_template_state(template: PortalTemplate, snapshot: dict) -> None:
    template.is_active = bool(snapshot.get("is_active", True))
    template.name = snapshot["name"]
    template.method = snapshot["method"]
    template.is_default = bool(snapshot["is_default"])
    template.theme = deepcopy(snapshot.get("theme") or {})  # type: ignore[arg-type]
    template.fields = deepcopy(snapshot.get("fields") or [])  # type: ignore[arg-type]
    template.success_message = snapshot.get("success_message")
    template.terms_url = snapshot.get("terms_url")
    template.meta = deepcopy(snapshot.get("meta") or {})


def _build_created_meta(
    body_meta: dict | None = None,
    actor_id: uuid.UUID | str | None = None,
) -> dict:
    meta = _clean_revision_meta(deepcopy(body_meta or {}))
    meta["revision"] = 1
    meta["revision_history"] = []
    meta["revision_action"] = "created"
    meta["revision_updated_at"] = datetime.now(timezone.utc).isoformat()
    if actor_id is not None:
        meta["revision_updated_by"] = str(actor_id)
    return meta


def _build_next_revision_meta(
    previous_meta: dict,
    previous_snapshot: dict,
    *,
    body_meta: dict | None = None,
    actor_id: uuid.UUID | str | None = None,
    action: str,
    target_snapshot: dict | None = None,
    replace_body_meta: bool = False,
) -> dict:
    current_revision = _revision_number_from_meta(previous_meta)
    history = _revision_history_from_meta(previous_meta)
    history.append(previous_snapshot)
    history = history[-_MAX_TEMPLATE_REVISIONS :]

    meta = _clean_revision_meta(previous_meta)
    if body_meta is not None:
        body_meta_clean = _clean_revision_meta(deepcopy(body_meta))
        if replace_body_meta:
            meta = body_meta_clean
        else:
            meta.update(body_meta_clean)
    meta["revision"] = current_revision + 1
    meta["revision_history"] = history
    meta["revision_action"] = action
    meta["revision_updated_at"] = datetime.now(timezone.utc).isoformat()
    if actor_id is not None:
        meta["revision_updated_by"] = str(actor_id)
    else:
        meta.pop("revision_updated_by", None)
    if target_snapshot is not None:
        meta["restored_from_revision"] = _normalize_revision(target_snapshot["revision"])
    else:
        meta.pop("restored_from_revision", None)
    return meta


async def list_templates(db: AsyncSession, scope: ScopeContext) -> list[PortalTemplate]:
    q, _ = await _scoped_query_async(db, scope)
    result = await db.execute(q.order_by(PortalTemplate.created_at.desc()))
    return [_decorate_template(template) for template in result.scalars().all()]


async def get_template(db: AsyncSession, template_id: uuid.UUID, scope: ScopeContext) -> PortalTemplate:
    q, allowed = await _scoped_query_async(db, scope)
    result = await db.execute(q.where(PortalTemplate.id == template_id))
    template = result.scalar_one_or_none()
    if not template:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Portal sablonu bulunamadi")
    if not allowed:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu sablona erisim yetkiniz yok")
    return _decorate_template(template)


async def create_template(
    db: AsyncSession, body: PortalTemplateCreate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> PortalTemplate:
    await _resolve_customer_for_create(db, body.customer_id, scope)
    await _validate_location_owns_customer(db, body.customer_id, body.location_id)
    if body.is_default:
        await _enforce_single_default(db, body.customer_id, body.location_id)
    template = PortalTemplate(
        customer_id=body.customer_id, location_id=body.location_id, name=body.name,
        method=body.method, is_default=body.is_default, theme=body.theme.model_dump(exclude_none=True),
        fields=body.fields, success_message=body.success_message,
        terms_url=body.terms_url, meta=_build_created_meta(body.meta, actor_id),
    )
    db.add(template)
    await db.flush()
    await log_audit(db, "portal.template_created", "portal_template", str(template.id), str(actor_id), request,
                    details={"name": body.name, "method": body.method, "customer_id": str(body.customer_id)})
    await db.commit()
    await db.refresh(template)
    return _decorate_template(template)


async def update_template(
    db: AsyncSession, template_id: uuid.UUID, body: PortalTemplateUpdate, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None, revision_action: str = "updated",
) -> PortalTemplate:
    template = await get_template(db, template_id, scope)
    previous_meta = _template_meta(template)
    previous_revision = _revision_number_from_meta(previous_meta)
    previous_snapshot = _serialize_revision_snapshot(
        template,
        revision=previous_revision,
        action=revision_action,
        actor_id=actor_id,
    )
    data = body.model_dump(exclude_unset=True)
    body_meta = data.pop("meta", None)
    if data.get("is_default"):
        await _enforce_single_default(db, template.customer_id, template.location_id)
    theme = data.pop("theme", None)
    if theme is not None:
        if hasattr(theme, "model_dump"):
            template.theme = theme.model_dump(exclude_none=True)
        elif isinstance(theme, dict):
            template.theme = {k: v for k, v in theme.items() if v is not None}
        else:
            template.theme = theme
    for k, v in data.items():
        setattr(template, k, v)
    template.meta = _build_next_revision_meta(
        previous_meta,
        previous_snapshot,
        body_meta=body_meta,
        actor_id=actor_id,
        action=revision_action,
    )
    audit_details = dict(data)
    if theme is not None:
        audit_details["theme"] = template.theme
    if body_meta is not None:
        audit_details["meta"] = deepcopy(body_meta)
    await log_audit(
        db,
        "portal.template_updated",
        "portal_template",
        str(template_id),
        str(actor_id),
        request,
        details=audit_details,
    )
    await db.commit()
    await db.refresh(template)
    return _decorate_template(template)


async def deactivate_template(
    db: AsyncSession, template_id: uuid.UUID, scope: ScopeContext,
    actor_id: uuid.UUID, request: Request | None = None,
) -> None:
    template = await get_template(db, template_id, scope)
    previous_meta = _template_meta(template)
    previous_revision = _revision_number_from_meta(previous_meta)
    previous_snapshot = _serialize_revision_snapshot(
        template,
        revision=previous_revision,
        action="deactivated",
        actor_id=actor_id,
    )
    template.is_active = False
    template.meta = _build_next_revision_meta(
        previous_meta,
        previous_snapshot,
        actor_id=actor_id,
        action="deactivated",
    )
    await log_audit(
        db,
        "portal.template_deactivated",
        "portal_template",
        str(template_id),
        str(actor_id),
        request,
        details={"is_active": False},
    )
    await db.commit()


async def list_template_history(
    db: AsyncSession,
    template_id: uuid.UUID,
    scope: ScopeContext,
) -> PortalTemplateHistoryOut:
    template = await get_template(db, template_id, scope)
    meta = _template_meta(template)
    history = sorted(
        (_revision_snapshot_to_model(item) for item in _revision_history_from_meta(meta)),
        key=lambda item: item.revision,
    )
    current = _revision_snapshot_to_model(_current_revision_snapshot(template))
    return PortalTemplateHistoryOut(
        template_id=template.id,
        current_revision=current.revision,
        history_count=len(history),
        current=current,
        history=history,
    )


async def restore_template_revision(
    db: AsyncSession,
    template_id: uuid.UUID,
    revision: int,
    scope: ScopeContext,
    actor_id: uuid.UUID,
    request: Request | None = None,
) -> PortalTemplate:
    template = await get_template(db, template_id, scope)
    current_meta = _template_meta(template)
    current_revision = _revision_number_from_meta(current_meta)
    if revision == current_revision:
        return _decorate_template(template)

    target_snapshot = next(
        (
            item
            for item in _revision_history_from_meta(current_meta)
            if _normalize_revision(item.get("revision")) == revision
        ),
        None,
    )
    if not target_snapshot:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Revizyon bulunamadi")

    previous_snapshot = _serialize_revision_snapshot(
        template,
        revision=current_revision,
        action="restored",
        actor_id=actor_id,
    )
    _replace_template_state(template, target_snapshot)
    if template.is_default:
        await _enforce_single_default(db, template.customer_id, template.location_id)
    template.meta = _build_next_revision_meta(
        current_meta,
        previous_snapshot,
        body_meta=target_snapshot.get("meta"),
        actor_id=actor_id,
        action="restored",
        target_snapshot=target_snapshot,
        replace_body_meta=True,
    )
    await log_audit(
        db,
        "portal.template_revision_restored",
        "portal_template",
        str(template_id),
        str(actor_id),
        request,
        details={"restored_from_revision": revision, "revision": current_revision},
    )
    await db.commit()
    await db.refresh(template)
    return _decorate_template(template)
