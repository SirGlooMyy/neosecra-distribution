# SQLAlchemy models for workers
