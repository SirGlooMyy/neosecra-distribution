# Pydantic schemas for audit
