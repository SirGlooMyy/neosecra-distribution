"""Redis cache adapter for frequent queries and dashboard counters.

- Sık kullanılan arama sorguları (15dk TTL)
- Dashboard sayaçları (5dk TTL)
- Arşiv indeks önbelleği (1 saat TTL)
"""
import json
import logging
import socket
import threading
from typing import Any
from urllib.parse import urlparse

import redis.asyncio as aioredis

from app.core.config import settings

log = logging.getLogger(__name__)

_redis: aioredis.Redis | None = None
_redis_host_status: bool | None = None


def _redis_host_available(timeout: float = 0.25) -> bool:
    """Resolve Redis without blocking asyncio's default executor.

    A Docker-only hostname may be absent during local unit tests.  A normal
    redis call can then leave a DNS worker behind and hang ``asyncio.run``
    shutdown; this bounded daemon resolver turns that situation into a cache
    miss while preserving normal behavior when Redis is reachable.
    """
    global _redis_host_status
    # Cache a positive resolution; a negative result is retried on the next
    # call so Redis can be started after application boot (common in Compose).
    if _redis_host_status is True:
        return True

    parsed = urlparse(settings.REDIS_URL)
    host = parsed.hostname or ""
    port = parsed.port or 6379
    for family in (socket.AF_INET, socket.AF_INET6):
        try:
            socket.inet_pton(family, host)
            _redis_host_status = True
            return True
        except OSError:
            pass

    done = threading.Event()
    resolved = {"ok": False}

    def _resolve() -> None:
        try:
            socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            resolved["ok"] = True
        except OSError:
            pass
        finally:
            done.set()

    threading.Thread(target=_resolve, name="redis-cache-resolve", daemon=True).start()
    _redis_host_status = resolved["ok"] if done.wait(timeout) else False
    return bool(_redis_host_status)


def _get_client() -> aioredis.Redis:
    global _redis
    if _redis is None:
        _redis = aioredis.from_url(
            settings.REDIS_URL,
            decode_responses=True,
            socket_connect_timeout=1.0,
            socket_timeout=1.0,
        )
    return _redis


async def cache_get(key: str) -> Any | None:
    try:
        if not _redis_host_available():
            return None
        r = _get_client()
        val = await r.get(key)
        if val:
            return json.loads(val)
    except Exception as e:
        log.warning("Cache get failed: %s", e)
    return None


async def cache_set(key: str, value: Any, ttl_seconds: int = 900) -> None:
    try:
        if not _redis_host_available():
            return
        r = _get_client()
        await r.setex(key, ttl_seconds, json.dumps(value, default=str))
    except Exception as e:
        log.warning("Cache set failed: %s", e)


async def cache_delete(key: str) -> None:
    try:
        if not _redis_host_available():
            return
        r = _get_client()
        await r.delete(key)
    except Exception as e:
        log.warning("Cache delete failed: %s", e)


async def cache_incr(key: str, amount: int = 1, ttl_seconds: int = 300) -> None:
    """Increment a counter with optional expiry."""
    try:
        if not _redis_host_available():
            return
        r = _get_client()
        val = await r.incr(key, amount)
        if val == amount:
            await r.expire(key, ttl_seconds)
    except Exception as e:
        log.warning("Cache incr failed: %s", e)


async def dashboard_counter(customer_id: str, metric: str, ttl: int = 300) -> int:
    """Get a dashboard counter from cache or return 0."""
    key = f"dash:{customer_id}:{metric}"
    val = await cache_get(key)
    return val if isinstance(val, int) else 0


async def set_dashboard_counter(customer_id: str, metric: str, value: int, ttl: int = 300) -> None:
    key = f"dash:{customer_id}:{metric}"
    await cache_set(key, value, ttl)


async def search_cache_key(query_hash: str) -> str | None:
    key = f"search:{query_hash}"
    return await cache_get(key)


async def set_search_cache(query_hash: str, result: Any, ttl: int = 900) -> None:
    key = f"search:{query_hash}"
    await cache_set(key, result, ttl)


async def archive_index_cache_key(customer_id: str, period: str) -> str | None:
    key = f"archive_idx:{customer_id}:{period}"
    return await cache_get(key)


async def set_archive_index_cache(customer_id: str, period: str, data: Any, ttl: int = 3600) -> None:
    key = f"archive_idx:{customer_id}:{period}"
    await cache_set(key, data, ttl)


async def close() -> None:
    global _redis
    global _redis_host_status
    if _redis:
        await _redis.close()
        _redis = None
    _redis_host_status = None
