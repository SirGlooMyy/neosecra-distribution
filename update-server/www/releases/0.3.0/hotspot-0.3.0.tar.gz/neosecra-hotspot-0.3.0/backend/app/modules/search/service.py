"""Search service: ClickHouse hot data plus archive index and archive payloads."""

from __future__ import annotations

import csv
from collections import defaultdict
import io
import hashlib
import json
import logging
import re
import time
import uuid
from datetime import datetime, timedelta, timezone
import zipfile

from fastapi import HTTPException, status
from sqlalchemy import and_, false, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.adapters import cache
from app.adapters import clickhouse as ch
from app.core.tenant import ScopeContext, TenantLevel, customer_in_scope, scope_for
from app.modules.logs_5651 import archive_service
from app.modules.customers.models import Customer
from app.modules.devices.models import Device
from app.modules.search.models import SearchView
from app.modules.search.schemas import (
    CorrelateResponse,
    CorrelateSessionInfo,
    CorrelateTimelineItem,
    FacetResult,
    FacetValue,
    LogSearchItem,
    LogSearchParams,
    LogSearchResponse,
    SearchCorrelationSummary,
    SearchHit,
    SearchQuery,
    SearchResult,
    SearchViewCreate,
    SearchViewOut,
    SearchViewUpdate,
)
from app.modules.sessions import service as sessions_service
from app.modules.syslog.models import FirewallLog

log = logging.getLogger(__name__)


def _view_out(view: SearchView) -> SearchViewOut:
    return SearchViewOut.model_validate(view)


_DEFAULT_CORRELATION_WINDOW_MINUTES = 15

_VENDOR_DISPLAY_NAMES = {
    "fortinet": "Fortinet",
    "paloalto": "PaloAlto",
    "sophos": "Sophos",
    "sonicwall": "SonicWall",
    "watchguard": "WatchGuard",
    "zyxel": "Zyxel",
    "mikrotik": "MikroTik",
    "draytek": "DrayTek",
    "pfsense": "pfSense",
    "tplink": "TP-Link",
    "aruba": "Aruba",
    "ruijie": "Ruijie",
}

_VENDOR_PATTERNS = {
    "fortinet": ("fortinet", "fortigate", "forti", "fgt"),
    "paloalto": ("paloalto", "panos", "panw", "pan-os"),
    "sophos": ("sophos",),
    "sonicwall": ("sonicwall",),
    "watchguard": ("watchguard",),
    "zyxel": ("zyxel",),
    "mikrotik": ("mikrotik", "routeros"),
    "draytek": ("draytek", "vigor"),
    "pfsense": ("pfsense", "pfsense"),
    "tplink": ("tplink", "tp-link", "omada"),
    "aruba": ("aruba", "clearpass"),
    "ruijie": ("ruijie", "reyee"),
}


def _parse_hit_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _correlation_bucket(ts: datetime | None, window_minutes: int) -> datetime | None:
    if ts is None:
        return None
    window = max(1, min(120, int(window_minutes or _DEFAULT_CORRELATION_WINDOW_MINUTES)))
    minute = (ts.minute // window) * window
    return ts.replace(minute=minute, second=0, microsecond=0)


def _normalize_vendor_key(value: str | None) -> str | None:
    if not value:
        return None
    normalized = re.sub(r"[^a-z0-9]+", "", value.lower())
    return normalized or None


def _vendor_search_haystack(hit: SearchHit) -> str:
    return " ".join(
        str(value)
        for value in (
            hit.hostname,
            hit.application,
            hit.message,
            hit.action,
            hit.domain,
        )
        if value
    ).lower()


def _pattern_in_haystack(haystack: str, pattern: str) -> bool:
    normalized_pattern = _normalize_vendor_key(pattern)
    return bool(normalized_pattern and normalized_pattern in haystack)


def infer_vendor_slug(hit: SearchHit) -> str | None:
    haystack = _normalize_vendor_key(_vendor_search_haystack(hit))
    if not haystack:
        return None
    for slug, aliases in _VENDOR_PATTERNS.items():
        if any(_pattern_in_haystack(haystack, alias) for alias in aliases):
            return slug
    return None


def infer_vendor_display_name(hit: SearchHit, fallback: str | None = None) -> str:
    vendor_slug = infer_vendor_slug(hit)
    if vendor_slug:
        return _VENDOR_DISPLAY_NAMES.get(vendor_slug, vendor_slug.title())
    normalized_fallback = _normalize_vendor_key(fallback)
    if normalized_fallback:
        return _VENDOR_DISPLAY_NAMES.get(normalized_fallback, fallback or "Bilinmiyor")
    return "Bilinmiyor"


def hit_matches_vendor(hit: SearchHit, vendor: str | None) -> bool:
    normalized_vendor = _normalize_vendor_key(vendor)
    if not normalized_vendor:
        return True

    haystack = _normalize_vendor_key(_vendor_search_haystack(hit))
    if not haystack:
        return False

    aliases = _VENDOR_PATTERNS.get(normalized_vendor, (normalized_vendor,))
    if any(_pattern_in_haystack(haystack, alias) for alias in aliases):
        return True
    return infer_vendor_slug(hit) == normalized_vendor


def _build_correlation_metadata(
    hit: SearchHit,
    *,
    correlation_window_minutes: int = _DEFAULT_CORRELATION_WINDOW_MINUTES,
) -> dict[str, str | int | None]:
    ts = _parse_hit_timestamp(hit.timestamp)
    bucket = _correlation_bucket(ts, correlation_window_minutes)
    bucket_key = bucket.isoformat() if bucket else "no-ts"

    if hit.session_id:
        reason = "aynı session_id"
        correlation_id = f"session:{hit.customer_id}:{hit.session_id}"
        correlation_type = "session"
    else:
        key_parts: list[str] = [f"customer:{hit.customer_id}"]
        reason_parts: list[str] = []

        if hit.location_id:
            key_parts.append(f"location:{hit.location_id}")
        if hit.device_id:
            key_parts.append(f"device:{hit.device_id}")
        if hit.username:
            key_parts.append(f"user:{hit.username.lower()}")
            reason_parts.append("username")
        if hit.mac:
            key_parts.append(f"mac:{hit.mac.upper()}")
            reason_parts.append("MAC")
        if hit.source_ip and hit.source_ip != "::":
            key_parts.append(f"ip:{hit.source_ip}")
            reason_parts.append("source IP")
        if hit.hostname:
            key_parts.append(f"host:{hit.hostname.lower()}")
            reason_parts.append("hostname")
        if hit.application:
            key_parts.append(f"app:{hit.application.lower()}")
        if not reason_parts:
            digest = hashlib.sha1(hit.message.encode("utf-8")).hexdigest()[:12]
            key_parts.append(f"message:{digest}")
            reason_parts.append("mesaj içeriği")

        correlation_type = (
            "principal"
            if hit.username
            else "device"
            if hit.mac or hit.device_id
            else "host"
            if hit.hostname
            else "ip"
            if hit.source_ip and hit.source_ip != "::"
            else "message"
        )
        reason = f"{', '.join(reason_parts)} eşleşmesi"
        if bucket:
            reason = f"{reason} ({correlation_window_minutes} dakikalık pencere)"
        correlation_id = f"{correlation_type}:{'|'.join(key_parts)}:{bucket_key}"

    return {
        "correlation_id": correlation_id,
        "correlation_type": correlation_type,
        "correlation_reason": reason,
    }


def enrich_search_hits_with_correlations(
    hits: list[SearchHit],
    *,
    correlation_window_minutes: int = _DEFAULT_CORRELATION_WINDOW_MINUTES,
) -> tuple[list[SearchHit], list[SearchCorrelationSummary]]:
    """Attach correlation metadata to hits and summarize related groups."""
    grouped: dict[str, list[SearchHit]] = defaultdict(list)
    grouped_sources: dict[str, set[str]] = defaultdict(set)
    enriched_hits: list[SearchHit] = []

    for hit in hits:
        metadata = _build_correlation_metadata(hit, correlation_window_minutes=correlation_window_minutes)
        enriched_hit = hit.model_copy(update=metadata)
        grouped[str(metadata["correlation_id"])].append(enriched_hit)
        grouped_sources[str(metadata["correlation_id"])].add(str(hit.source or "unknown"))
        enriched_hits.append(enriched_hit)

    summaries: list[SearchCorrelationSummary] = []
    group_sizes: dict[str, int] = {}
    for correlation_id, members in grouped.items():
        ordered = sorted(members, key=_hit_sort_key, reverse=True)
        first_ts = ordered[-1].timestamp if ordered else ""
        last_ts = ordered[0].timestamp if ordered else ""
        exemplar = ordered[0] if ordered else members[0]
        group_size = len(members)
        sources = sorted(grouped_sources.get(correlation_id, set()))
        group_sizes[correlation_id] = group_size
        summaries.append(
            SearchCorrelationSummary(
                correlation_id=correlation_id,
                correlation_type=exemplar.correlation_type or "unknown",
                reason=exemplar.correlation_reason or "Correlated log activity",
                hit_count=group_size,
                source_count=len(sources),
                sources=sources,
                first_timestamp=first_ts,
                last_timestamp=last_ts,
                sample_hostname=exemplar.hostname or None,
                sample_source_ip=exemplar.source_ip or None,
                sample_session_id=exemplar.session_id,
            )
        )

    summaries.sort(
        key=lambda item: (
            -item.hit_count,
            -(
                _parse_hit_timestamp(item.last_timestamp) or datetime.min.replace(tzinfo=timezone.utc)
            ).timestamp(),
            ),
        )
    sized_hits = [
        hit.model_copy(update={"correlation_group_size": group_sizes.get(hit.correlation_id or "", 1)})
        for hit in enriched_hits
    ]
    return sized_hits, summaries


async def unified_search(
    db: AsyncSession,
    scope: ScopeContext,
    query: SearchQuery,
) -> SearchResult:
    """Unified search service across ClickHouse hot data, archive index/payloads, and Postgres fallback.
    Enforces multi-tenant isolation through ScopeContext.
    """
    if not scope.allowed:
        return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")
    return await search_syslog(db, scope, query)


async def search_syslog(
    db: AsyncSession,
    scope: ScopeContext,
    query: SearchQuery,
) -> SearchResult:
    """Full-text search across ClickHouse hot data and archived cold data."""
    if not scope.allowed:
        return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")

    customer_uuid = _parse_uuid(query.customer_id)
    # Service callers may bypass the HTTP router, so enforce the same tenant
    # boundary here as a defense-in-depth check.  Customer scope is pinned to
    # its own id; partner/location scopes must prove the requested customer is
    # assigned to them.  A few legacy unit callers pass a light-weight mock
    # instead of ScopeContext; retain their explicit customer_id behavior.
    if isinstance(scope, ScopeContext):
        if scope.level == TenantLevel.CUSTOMER and scope.customer_id != customer_uuid:
            return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")
        if scope.level != TenantLevel.GLOBAL and not await customer_in_scope(db, scope, customer_uuid):
            return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")
        if scope.level == TenantLevel.LOCATION:
            if query.location_id and str(query.location_id) != str(scope.location_id):
                return SearchResult(hits=[], total=0, limit=query.limit, offset=query.offset, source="none")
            if not query.location_id:
                query = query.model_copy(update={"location_id": str(scope.location_id)})
    customer_id = str(customer_uuid)

    cache_key = f"search:{customer_id}:{query.model_dump_json()}"
    cached = await cache.search_cache_key(cache_key)
    if cached:
        return SearchResult(**cached)  # type: ignore[call-arg]

    ch_hits = await _search_clickhouse(customer_id, query)
    archive_hits = await _search_archive(db, customer_uuid, query)
    pg_hits: list[SearchHit] = []
    if not ch_hits:
        pg_hits = await _search_postgres(db, customer_uuid, query)

    all_hits = sorted(ch_hits + archive_hits + pg_hits, key=_sort_timestamp, reverse=True)
    all_hits = [hit for hit in all_hits if hit_matches_vendor(hit, query.vendor)]
    all_hits, correlation_summary = enrich_search_hits_with_correlations(
        all_hits,
        correlation_window_minutes=query.correlation_window_minutes,
    )
    total = len(all_hits)
    paged = all_hits[query.offset : query.offset + query.limit]

    if ch_hits and (archive_hits or pg_hits):
        source = "mixed"
    elif archive_hits:
        source = "archive"
    elif pg_hits:
        source = "postgres"
    else:
        source = "clickhouse"

    result = SearchResult(
        hits=paged,
        total=total,
        limit=query.limit,
        offset=query.offset,
        source=source,
        correlation_summary=correlation_summary,
    )

    await cache.set_search_cache(cache_key, result.model_dump(), 900)
    return result


def _build_where_clauses(filters: LogSearchParams, scope_or_user) -> list:
    """Build WHERE clause fragments for firewall_logs search scoped by ScopeContext."""
    scope = scope_or_user if isinstance(scope_or_user, ScopeContext) else scope_for(scope_or_user)

    clauses = []
    if not scope.allowed:
        clauses.append(false())
    elif scope.level == TenantLevel.CUSTOMER and scope.customer_id:
        clauses.append(FirewallLog.customer_id == scope.customer_id)
    elif scope.level == TenantLevel.PARTNER and scope.partner_id:
        clauses.append(
            FirewallLog.customer_id.in_(
                select(Customer.id).where(Customer.partner_id == scope.partner_id)
            )
        )
    elif scope.level == TenantLevel.TENANT and scope.tenant_id:
        clauses.append(
            FirewallLog.customer_id.in_(
                select(Customer.id).where(Customer.tenant_id == scope.tenant_id)
            )
        )
    elif scope.level == TenantLevel.LOCATION and scope.location_id:
        # FirewallLog has no denormalized location_id; resolve it through the
        # device relation that produced the log.
        clauses.append(
            FirewallLog.device_id.in_(
                select(Device.id).where(Device.location_id == scope.location_id)
            )
        )
    elif scope.level != TenantLevel.GLOBAL:
        clauses.append(false())

    if filters.vendor:
        vendors = [v.strip() for v in filters.vendor.split(",") if v.strip()]
        if vendors:
            clauses.append(FirewallLog.vendor.in_(vendors))

    if filters.log_type:
        log_types = [lt.strip() for lt in filters.log_type.split(",") if lt.strip()]
        if log_types:
            clauses.append(FirewallLog.log_type.in_(log_types))

    if filters.severity:
        severities = [s.strip() for s in filters.severity.split(",") if s.strip()]
        if severities:
            clauses.append(FirewallLog.severity.in_(severities))

    if filters.action:
        actions = [a.strip() for a in filters.action.split(",") if a.strip()]
        if actions:
            clauses.append(FirewallLog.action.in_(actions))

    if filters.src_ip:
        if filters.src_ip.endswith("%") or filters.src_ip.endswith("."):
            clauses.append(FirewallLog.src_ip.like(filters.src_ip))
        else:
            clauses.append(FirewallLog.src_ip == filters.src_ip)

    if filters.dst_ip:
        if filters.dst_ip.endswith("%") or filters.dst_ip.endswith("."):
            clauses.append(FirewallLog.dst_ip.like(filters.dst_ip))
        else:
            clauses.append(FirewallLog.dst_ip == filters.dst_ip)

    if filters.src_port is not None:
        clauses.append(FirewallLog.src_port == filters.src_port)

    if filters.dst_port is not None:
        clauses.append(FirewallLog.dst_port == filters.dst_port)

    if filters.user:
        clauses.append(FirewallLog.user.ilike(f"%{filters.user}%"))

    if filters.device_id:
        clauses.append(FirewallLog.device_id == filters.device_id)

    if filters.location_id:
        clauses.append(
            FirewallLog.device_id.in_(
                select(Device.id).where(Device.location_id == filters.location_id)
            )
        )

    if filters.policyid is not None:
        clauses.append(FirewallLog.policyid == filters.policyid)

    if filters.service:
        clauses.append(FirewallLog.service.ilike(f"%{filters.service}%"))

    if filters.proto:
        clauses.append(FirewallLog.proto == filters.proto)

    from_time, to_time = _resolve_time_window(filters)
    if from_time:
        clauses.append(FirewallLog.event_time >= from_time)
    if to_time:
        clauses.append(FirewallLog.event_time <= to_time)

    return clauses


def _row_to_log_item(row) -> LogSearchItem:
    return LogSearchItem(
        id=str(row.id),
        tenant_id=str(row.tenant_id),
        event_time=row.event_time.isoformat() if row.event_time else None,
        received_at=row.received_at.isoformat() if row.received_at else None,
        vendor=row.vendor,
        log_type=row.log_type,
        log_subtype=row.log_subtype,
        severity=row.severity,
        action=row.action,
        src_ip=row.src_ip,
        dst_ip=row.dst_ip,
        src_port=row.src_port,
        dst_port=row.dst_port,
        proto=row.proto,
        service=row.service,
        user=row.user,
        policyid=row.policyid,
        duration=row.duration,
        sentbyte=row.sentbyte,
        rcvdbyte=row.rcvdbyte,
        session_id=row.session_id,
        raw_syslog=row.raw_syslog,
        parsed_fields=row.parsed_fields if hasattr(row, "parsed_fields") else {},
        rank=getattr(row, "rank", None),
    )


async def search_firewall_logs(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
) -> LogSearchResponse:
    """Search firewall_logs with filters + optional fulltext (q) + tsvector ranking."""
    start = time.monotonic()
    scope = user if isinstance(user, ScopeContext) else scope_for(user)
    if not scope.allowed:
        return LogSearchResponse(total=0, items=[], took_ms=0)

    clauses = _build_where_clauses(filters, scope)

    if filters.q:
        # Pass the query text as a regular SQLAlchemy bound parameter. Calling
        # .bindparams() on a FunctionElement's comparator raises AttributeError
        # and turned every free-text analyzer search into a 500.
        tsquery = func.plainto_tsquery("english", filters.q)
        clauses.append(
            FirewallLog.search_vector.op("@@")(tsquery)
        )

    base = select(FirewallLog)
    if clauses:
        base = base.where(*clauses)

    count_q = select(func.count(FirewallLog.id))
    if clauses:
        count_q = count_q.where(*clauses)
    total_result = await db.execute(count_q)
    total = total_result.scalar() or 0

    if filters.q:
        rank = func.ts_rank(FirewallLog.search_vector, tsquery).label("rank")
        q = base.add_columns(rank).order_by(rank.desc(), FirewallLog.event_time.desc())
    else:
        q = base.order_by(FirewallLog.event_time.desc())

    q = q.offset(filters.offset).limit(filters.limit)

    result = await db.execute(q)
    rows = result.scalars().all()

    items = [_row_to_log_item(r) for r in rows]

    took_ms = int((time.monotonic() - start) * 1000)
    return LogSearchResponse(total=total, items=items, took_ms=took_ms)


async def get_facets(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
) -> FacetResult:
    """Compute rich facets (histogram + top-N for vendor, log_type, severity, action, src_ip, dst_ip, user, domain, application)."""
    import asyncio
    from app.modules.search.schemas import HistogramBucket
    start = time.monotonic()
    scope = user if isinstance(user, ScopeContext) else scope_for(user)
    if not scope.allowed:
        return FacetResult()

    clauses = _build_where_clauses(filters, scope)

    async def _facet(column) -> list[FacetValue]:
        q = select(column, func.count(FirewallLog.id).label("cnt"))
        if clauses:
            q = q.where(*clauses)
        q = q.where(column.isnot(None)).group_by(column).order_by(text("cnt DESC")).limit(10)
        res = await db.execute(q)
        return [FacetValue(value=str(row[0]), count=row[1]) for row in res if row[0] is not None]

    async def _histogram() -> list[HistogramBucket]:
        bucket_col = func.date_trunc('hour', FirewallLog.event_time).label("bucket")
        q = select(bucket_col, func.count(FirewallLog.id).label("cnt"))
        if clauses:
            q = q.where(*clauses)
        q = q.where(FirewallLog.event_time.isnot(None)).group_by(bucket_col).order_by(bucket_col.asc()).limit(100)
        res = await db.execute(q)
        buckets = []
        for row in res:
            if row[0]:
                ts_str = row[0].isoformat() if hasattr(row[0], "isoformat") else str(row[0])
                buckets.append(HistogramBucket(timestamp=ts_str, count=row[1]))
        return buckets

    vendor, log_type, severity, action, src_ip, dst_ip, user_f, domain_f, app_f, histogram = await asyncio.gather(
        _facet(FirewallLog.vendor),
        _facet(FirewallLog.log_type),
        _facet(FirewallLog.severity),
        _facet(FirewallLog.action),
        _facet(FirewallLog.src_ip),
        _facet(FirewallLog.dst_ip),
        _facet(FirewallLog.user),
        _facet(FirewallLog.service),
        _facet(FirewallLog.proto),
        _histogram(),
    )

    log.debug("Facets computed in %d ms", int((time.monotonic() - start) * 1000))
    return FacetResult(
        vendor=vendor,
        log_type=log_type,
        severity=severity,
        action=action,
        src_ip=src_ip,
        dst_ip=dst_ip,
        user=user_f,
        domain=domain_f,
        application=app_f,
        histogram=histogram,
    )


def build_firewall_logs_export_bundle(
    result: SearchResult,
    query: SearchQuery,
    *,
    context: dict[str, str | int | None] | None = None,
    generated_at: datetime | None = None,
) -> tuple[bytes, str]:
    """Build a portable evidence bundle for firewall log searches."""
    generated_at = generated_at or datetime.now(timezone.utc)
    enriched_hits, correlation_summary = enrich_search_hits_with_correlations(
        result.hits,
        correlation_window_minutes=query.correlation_window_minutes,
    )

    columns = [
        "timestamp",
        "customer_id",
        "location_id",
        "device_id",
        "facility",
        "severity",
        "hostname",
        "source_ip",
        "dest_ip",
        "mac",
        "username",
        "domain",
        "application",
        "action",
        "message",
        "session_id",
        "source",
    ]

    csv_buffer = io.StringIO()
    writer = csv.DictWriter(csv_buffer, fieldnames=columns)
    writer.writeheader()
    for hit in enriched_hits:
        row = hit.model_dump(mode="json")
        writer.writerow({column: row.get(column, "") for column in columns})

    manifest = {
        "title": "Firewall Logs Evidence Bundle",
        "generated_at": generated_at.isoformat(),
        "row_count": len(enriched_hits),
        "total_hits": result.total,
        "source": result.source,
        "query": query.model_dump(mode="json"),
        "context": context or {},
        "correlation_rule": {
            "window_minutes": query.correlation_window_minutes,
            "description": (
                f"MAC, IP, kullanıcı ve hostname için "
                f"{query.correlation_window_minutes} dakikalık korelasyon penceresi"
            ),
        },
        "correlation_summary": [item.model_dump(mode="json") for item in correlation_summary],
    }

    readme_lines = [
        "Firewall Logs Evidence Bundle",
        "============================",
        "",
        f"Generated at: {generated_at.isoformat()}",
        f"Rows exported: {len(enriched_hits)}",
        f"Total hits: {result.total}",
        f"Source: {result.source}",
        f"Correlation window: {query.correlation_window_minutes} minutes",
        f"Correlation groups: {len(correlation_summary)}",
    ]
    if context:
        readme_lines.extend(["", "Context:"])
        readme_lines.extend(f"- {key}: {value}" for key, value in context.items())
    if correlation_summary:
        readme_lines.extend(["", "Top correlated groups:"])
        for group in correlation_summary[:5]:
            readme_lines.append(
                f"- {group.correlation_type} · {group.hit_count} kayıt · "
                f"{', '.join(group.sources) if group.sources else 'tek kaynak'} · {group.reason}"
            )
    readme_lines.extend(
        [
            "",
            "Contents:",
            "- manifest.json",
            "- results.csv",
            "- README.txt",
        ]
    )
    readme = "\n".join(readme_lines) + "\n"

    bundle = io.BytesIO()
    with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True))
        archive.writestr("results.csv", csv_buffer.getvalue().encode("utf-8-sig"))
        archive.writestr("README.txt", readme)

    filename = f"firewall-logs-export-{generated_at.strftime('%Y%m%d-%H%M%S')}.zip"
    return bundle.getvalue(), filename


async def list_search_views(
    db: AsyncSession,
    *,
    user_id: uuid.UUID,
    surface: str = "firewall_logs",
) -> list[SearchViewOut]:
    q = select(SearchView).where(SearchView.surface == surface).where(
        (SearchView.created_by_user_id == user_id) | (SearchView.is_shared.is_(True))
    ).order_by(SearchView.updated_at.desc())
    res = await db.execute(q)
    return [_view_out(view) for view in res.scalars().all()]


async def get_search_view(db: AsyncSession, *, view_id: uuid.UUID) -> SearchView:
    view = await db.get(SearchView, view_id)
    if not view:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Saved view bulunamadi")
    return view


async def create_search_view(
    db: AsyncSession,
    *,
    body: SearchViewCreate,
    user_id: uuid.UUID,
) -> SearchViewOut:
    now = datetime.now(timezone.utc)
    view = SearchView(
        id=uuid.uuid4(),
        created_by_user_id=user_id,
        surface=body.surface,
        title=body.title,
        description=body.description,
        filters=body.filters or {},
        is_shared=body.is_shared,
        created_at=now,
        updated_at=now,
    )
    db.add(view)
    await db.commit()
    await db.refresh(view)
    return _view_out(view)


async def update_search_view(
    db: AsyncSession,
    *,
    view_id: uuid.UUID,
    body: SearchViewUpdate,
    user_id: uuid.UUID,
) -> SearchViewOut:
    view = await get_search_view(db, view_id=view_id)
    if str(view.created_by_user_id) != str(user_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu saved view size ait degil")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(view, field, value)
    view.updated_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(view)
    return _view_out(view)


async def delete_search_view(
    db: AsyncSession,
    *,
    view_id: uuid.UUID,
    user_id: uuid.UUID,
) -> None:
    view = await get_search_view(db, view_id=view_id)
    if str(view.created_by_user_id) != str(user_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Bu saved view size ait degil")
    await db.delete(view)
    await db.commit()


async def _search_clickhouse(customer_id: str, query: SearchQuery) -> list[SearchHit]:
    try:
        rows = await ch.query_syslog(
            customer_id,
            from_time=query.from_time,
            to_time=query.to_time,
            source_ip=query.source_ip,
            dest_ip=query.dest_ip,
            mac=query.mac,
            username=query.username,
            domain=query.domain,
            application=query.application,
            action=query.action,
            severity_min=query.severity_min,
            severity_max=query.severity_max,
            hostname=query.hostname,
            location_id=query.location_id,
            device_id=query.device_id,
            q=query.q,
            limit=query.limit,
            offset=query.offset,
        )
    except Exception as exc:
        log.warning("ClickHouse search failed (CH may be offline): %s", exc)
        return []

    hits: list[SearchHit] = []
    for row in rows:
        if not _row_matches_query(row, query):
            continue
        hits.append(_row_to_hit(row, customer_id, "clickhouse"))
    return hits


async def _search_archive(
    db: AsyncSession,
    customer_id: uuid.UUID,
    query: SearchQuery,
) -> list[SearchHit]:
    """Search archived syslog payloads via PostgreSQL catalog and local files."""
    from app.modules.logs_5651.models import ArchiveIndex

    conditions = [ArchiveIndex.customer_id == customer_id]
    if query.from_time:
        conditions.append(ArchiveIndex.period_end >= query.from_time)
    if query.to_time:
        conditions.append(ArchiveIndex.period_start <= query.to_time)
    if query.location_id:
        conditions.append(ArchiveIndex.location_id == query.location_id)

    stmt = select(ArchiveIndex).where(and_(*conditions)).order_by(ArchiveIndex.period_start.desc())
    result = await db.execute(stmt)
    indices = result.scalars().all()

    hits: list[SearchHit] = []
    for idx in indices:
        if not _archive_index_matches_query(idx, query):
            continue

        rows = await _load_archive_rows(idx)
        if rows is None:
            continue

        for row in rows:
            if not _row_matches_query(row, query):
                continue
            hits.append(_row_to_hit(row, customer_id, "archive", idx))  # type: ignore[arg-type]

    return hits


async def _search_postgres(
    db: AsyncSession,
    customer_id: uuid.UUID,
    query: SearchQuery,
) -> list[SearchHit]:
    """Fallback search against PostgreSQL syslog rows when ClickHouse is unavailable."""
    from app.modules.syslog.models import SyslogRecord

    conditions = [SyslogRecord.tenant_id == customer_id]
    if query.from_time:
        conditions.append(SyslogRecord.created_at >= query.from_time)
    if query.to_time:
        conditions.append(SyslogRecord.created_at <= query.to_time)
    if query.hostname:
        conditions.append(SyslogRecord.hostname == query.hostname)
    if query.application:
        conditions.append(SyslogRecord.app_name == query.application)
    if query.severity_min is not None:
        conditions.append(SyslogRecord.severity >= query.severity_min)
    if query.severity_max is not None:
        conditions.append(SyslogRecord.severity <= query.severity_max)
    if query.q:
        needle = f"%{query.q}%"
        conditions.append(
            (SyslogRecord.message.ilike(needle))
            | (SyslogRecord.hostname.ilike(needle))
            | (SyslogRecord.app_name.ilike(needle))
        )

    stmt = select(SyslogRecord).where(and_(*conditions)).order_by(SyslogRecord.created_at.desc()).limit(query.limit + query.offset)
    result = await db.execute(stmt)
    rows = list(result.scalars().all())

    hits: list[SearchHit] = []
    for row in rows:
        if not _postgres_row_matches_query(row, query):
            continue
        hits.append(
            SearchHit(
                timestamp=_row_timestamp({"timestamp": row.created_at}, None),
                customer_id=str(row.tenant_id or customer_id),
                location_id=None,
                device_id=None,
                facility=str(row.facility if row.facility is not None else "unknown"),
                severity=int(row.severity if row.severity is not None else 5),
                hostname=str(row.hostname or ""),
                source_ip="::",
                dest_ip="::",
                mac="",
                username="",
                domain="",
                application=str(row.app_name or ""),
                action="",
                message=str(row.message or ""),
                session_id=None,
                source="postgres",
            )
        )
    return hits


def _archive_index_matches_query(idx, query: SearchQuery) -> bool:
    searchable = idx.searchable_fields or {}

    if query.source_ip and query.source_ip not in searchable.get("ips", []):
        return False
    if query.dest_ip and query.dest_ip not in searchable.get("ips", []):
        return False
    if query.mac and query.mac.upper() not in searchable.get("macs", []):
        return False
    if query.username and query.username not in searchable.get("users", []):
        return False
    if query.domain and query.domain not in searchable.get("domains", []):
        return False
    if query.device_id and query.device_id not in searchable.get("devices", []):
        return False
    if query.location_id and str(getattr(idx, "location_id", "") or "") != str(query.location_id):
        return False

    return True


def _row_matches_query(row: dict, query: SearchQuery) -> bool:
    if query.source_ip and str(row.get("source_ip", "")) != query.source_ip:
        return False
    if query.dest_ip and str(row.get("dest_ip", "")) != query.dest_ip:
        return False
    if query.mac and str(row.get("mac", "")).upper() != query.mac.upper():
        return False
    if query.username and str(row.get("username", "")) != query.username:
        return False
    if query.domain and str(row.get("domain", "")) != query.domain:
        return False
    if query.application and str(row.get("application", "")) != query.application:
        return False
    if query.action and str(row.get("action", "")) != query.action:
        return False
    if query.device_id and str(row.get("device_id", "")) != str(query.device_id):
        return False
    if query.location_id and str(row.get("location_id", "")) != str(query.location_id):
        return False
    if query.hostname and str(row.get("hostname", "")) != query.hostname:
        return False
    if query.severity_min is not None and int(row.get("severity", 5) or 5) < query.severity_min:
        return False
    if query.severity_max is not None and int(row.get("severity", 5) or 5) > query.severity_max:
        return False
    if query.q:
        needle = query.q.lower()
        haystack = " ".join(
            str(row.get(field, "") or "")
            for field in (
                "message",
                "hostname",
                "app_name",
                "username",
                "domain",
                "source_ip",
                "dest_ip",
                "mac",
                "application",
                "action",
            )
        ).lower()
        if needle not in haystack:
            return False
    return True


def _postgres_row_matches_query(row, query: SearchQuery) -> bool:
    if query.hostname and str(row.hostname or "") != query.hostname:
        return False
    if query.application and str(row.app_name or "") != query.application:
        return False
    if query.severity_min is not None and int(row.severity or 5) < query.severity_min:
        return False
    if query.severity_max is not None and int(row.severity or 5) > query.severity_max:
        return False
    if query.q:
        haystack = " ".join(
            str(value or "")
            for value in (row.message, row.hostname, row.app_name)
        ).lower()
        if query.q.lower() not in haystack:
            return False
    return True


async def _load_archive_rows(idx) -> list[dict] | None:
    payload = archive_service.read_archive_payload(str(getattr(idx, "file_ref", "") or ""))
    if payload is None:
        return None
    raw = payload
    rows: list[dict] = []
    for line in raw.splitlines():
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def _row_to_hit(
    row: dict,
    fallback_customer_id: str,
    source: str,
    idx=None,
) -> SearchHit:
    return SearchHit(
        timestamp=_row_timestamp(row, idx),
        customer_id=str(row.get("customer_id", fallback_customer_id)),
        location_id=str(row.get("location_id", "")) or None,
        device_id=str(row.get("device_id", "")) or None,
        facility=str(row.get("facility", "unknown")),
        severity=int(row.get("severity", 5) or 5),
        hostname=str(row.get("hostname", "")),
        source_ip=str(row.get("source_ip", "::")),
        dest_ip=str(row.get("dest_ip", "::")),
        mac=str(row.get("mac", "")),
        username=str(row.get("username", "")),
        domain=str(row.get("domain", "")),
        application=str(row.get("application") or row.get("app_name") or ""),
        action=str(row.get("action", "")),
        message=str(row.get("message", "")),
        session_id=str(row.get("session_id", "")) or None,
        source=source,
    )


def _row_timestamp(row: dict, idx=None) -> str:
    ts = row.get("timestamp")
    if hasattr(ts, "isoformat"):
        return ts.isoformat()  # type: ignore[union-attr]
    if ts:
        return str(ts)
    if idx is not None:
        return idx.period_end.isoformat()
    return datetime.now(timezone.utc).isoformat()


def _parse_uuid(value: str) -> uuid.UUID:
    try:
        return uuid.UUID(str(value))
    except (TypeError, ValueError):
        raise ValueError("Gecersiz customer_id")


def _sort_timestamp(hit: SearchHit) -> str:
    return hit.timestamp


def _hit_sort_key(hit: SearchHit) -> datetime:
    return _parse_hit_timestamp(hit.timestamp) or datetime.min.replace(tzinfo=timezone.utc)


async def get_traffic_data(
    scope: ScopeContext,
    days: int = 30,
) -> dict:
    """Get traffic aggregation from ClickHouse with PostgreSQL fallback."""
    customer_id = str(scope.customer_id)
    location_id = str(scope.location_id) if scope.location_id else None

    try:
        return await ch.get_traffic_aggregation(customer_id, days=days, location_id=location_id)
    except Exception as exc:
        log.warning("ClickHouse traffic query failed, falling back: %s", exc)
        from app.modules.traffic.service import get_traffic_trend

        return await get_traffic_trend(None, scope, days)  # type: ignore[arg-type]


# ──────────────────────────────────────────────
# Sprint 07b — Detaylı Hızlı Log Arama
# ──────────────────────────────────────────────


def _resolve_time_window(filters: LogSearchParams) -> tuple[datetime | None, datetime | None]:
    """Resolve from_time/to_time from explicit range or time_window preset."""
    if filters.from_time and filters.to_time:
        return filters.from_time, filters.to_time
    if filters.from_time:
        return filters.from_time, None
    if filters.to_time:
        return None, filters.to_time
    if filters.time_window:
        now = datetime.now(timezone.utc)
        mapping = {
            "15m": timedelta(minutes=15),
            "1h": timedelta(hours=1),
            "24h": timedelta(hours=24),
            "7d": timedelta(days=7),
        }
        delta = mapping.get(filters.time_window)
        if delta:
            return now - delta, now
    return None, None


def _legacy_build_where_clauses(filters: LogSearchParams, tenant_id: uuid.UUID) -> list:
    """Build WHERE clause fragments for firewall_logs search."""
    clauses = [FirewallLog.tenant_id == tenant_id]

    if filters.vendor:
        vendors = [v.strip() for v in filters.vendor.split(",") if v.strip()]
        if vendors:
            clauses.append(FirewallLog.vendor.in_(vendors))

    if filters.log_type:
        log_types = [lt.strip() for lt in filters.log_type.split(",") if lt.strip()]
        if log_types:
            clauses.append(FirewallLog.log_type.in_(log_types))

    if filters.severity:
        severities = [s.strip() for s in filters.severity.split(",") if s.strip()]
        if severities:
            clauses.append(FirewallLog.severity.in_(severities))

    if filters.action:
        actions = [a.strip() for a in filters.action.split(",") if a.strip()]
        if actions:
            clauses.append(FirewallLog.action.in_(actions))

    if filters.src_ip:
        if filters.src_ip.endswith("%") or filters.src_ip.endswith("."):
            clauses.append(FirewallLog.src_ip.like(filters.src_ip))
        else:
            clauses.append(FirewallLog.src_ip == filters.src_ip)

    if filters.dst_ip:
        if filters.dst_ip.endswith("%") or filters.dst_ip.endswith("."):
            clauses.append(FirewallLog.dst_ip.like(filters.dst_ip))
        else:
            clauses.append(FirewallLog.dst_ip == filters.dst_ip)

    if filters.src_port is not None:
        clauses.append(FirewallLog.src_port == filters.src_port)

    if filters.dst_port is not None:
        clauses.append(FirewallLog.dst_port == filters.dst_port)

    if filters.user:
        clauses.append(FirewallLog.user.ilike(f"%{filters.user}%"))

    if filters.device_id:
        clauses.append(FirewallLog.device_id == filters.device_id)

    if filters.location_id:
        clauses.append(
            FirewallLog.device_id.in_(
                select(Device.id).where(Device.location_id == filters.location_id)
            )
        )

    if filters.policyid is not None:
        clauses.append(FirewallLog.policyid == filters.policyid)

    if filters.service:
        clauses.append(FirewallLog.service.ilike(f"%{filters.service}%"))

    if filters.proto:
        clauses.append(FirewallLog.proto == filters.proto)

    from_time, to_time = _resolve_time_window(filters)
    if from_time:
        clauses.append(FirewallLog.event_time >= from_time)
    if to_time:
        clauses.append(FirewallLog.event_time <= to_time)

    return clauses


def _row_to_log_item(row) -> LogSearchItem:
    return LogSearchItem(
        id=str(row.id),
        tenant_id=str(row.tenant_id),
        event_time=row.event_time.isoformat() if row.event_time else None,
        received_at=row.received_at.isoformat() if row.received_at else None,
        vendor=row.vendor,
        log_type=row.log_type,
        log_subtype=row.log_subtype,
        severity=row.severity,
        action=row.action,
        src_ip=row.src_ip,
        dst_ip=row.dst_ip,
        src_port=row.src_port,
        dst_port=row.dst_port,
        proto=row.proto,
        service=row.service,
        user=row.user,
        policyid=row.policyid,
        duration=row.duration,
        sentbyte=row.sentbyte,
        rcvdbyte=row.rcvdbyte,
        session_id=row.session_id,
        raw_syslog=row.raw_syslog,
        parsed_fields=row.parsed_fields if hasattr(row, "parsed_fields") else {},
        rank=getattr(row, "rank", None),
    )


async def _legacy_search_firewall_logs(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
) -> LogSearchResponse:
    """Search firewall_logs with filters + optional fulltext (q) + tsvector ranking."""
    start = time.monotonic()
    tenant_id = user.tenant_id
    clauses = _legacy_build_where_clauses(filters, tenant_id)

    if filters.q:
        tsquery = func.plainto_tsquery("english", filters.q)
        clauses.append(
            FirewallLog.search_vector.op("@@")(tsquery)
        )

    base = select(FirewallLog).where(*clauses)

    count_q = select(func.count(FirewallLog.id)).where(*clauses)
    total_result = await db.execute(count_q)
    total = total_result.scalar() or 0

    if filters.q:
        rank = func.ts_rank(FirewallLog.search_vector, tsquery).label("rank")
        q = base.add_columns(rank).order_by(rank.desc(), FirewallLog.event_time.desc())
    else:
        q = base.order_by(FirewallLog.event_time.desc())

    q = q.offset(filters.offset).limit(filters.limit)

    log.debug("EXPLAIN ANALYZE equivalent: SELECT ... FROM firewall_logs WHERE ...")

    result = await db.execute(q)
    rows = result.scalars().all()

    items = [_row_to_log_item(r) for r in rows]

    took_ms = int((time.monotonic() - start) * 1000)
    return LogSearchResponse(total=total, items=items, took_ms=took_ms)


async def _legacy_get_facets(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
) -> FacetResult:
    """Compute 4 facets (vendor, log_type, severity, action) with active filters applied."""
    start = time.monotonic()
    tenant_id = user.tenant_id
    clauses = _legacy_build_where_clauses(filters, tenant_id)

    async def _facet(column) -> list[FacetValue]:
        q = (
            select(column, func.count(FirewallLog.id).label("cnt"))
            .where(*clauses)
            .group_by(column)
            .order_by(text("cnt DESC"))
            .limit(10)
        )
        res = await db.execute(q)
        return [FacetValue(value=str(row[0]), count=row[1]) for row in res]

    import asyncio

    vendor, log_type, severity, action = await asyncio.gather(
        _facet(FirewallLog.vendor),
        _facet(FirewallLog.log_type),
        _facet(FirewallLog.severity),
        _facet(FirewallLog.action),
    )

    log.debug("Facets computed in %d ms", int((time.monotonic() - start) * 1000))
    return FacetResult(vendor=vendor, log_type=log_type, severity=severity, action=action)


async def correlate_session(
    db: AsyncSession,
    user,
    session_id: str,
) -> CorrelateResponse:
    """Correlate a session_id across GuestSession + FirewallLog traffic + FirewallLog auth events."""
    scope = user if isinstance(user, ScopeContext) else scope_for(user)
    if not scope.allowed:
        return CorrelateResponse()

    session_row = None
    try:
        sid_uuid = uuid.UUID(session_id)
        try:
            session_row = await sessions_service.get_session(db, sid_uuid, scope)
        except HTTPException:
            # Do not reveal whether a session exists outside the caller's
            # tenant/location scope.
            session_row = None
    except (ValueError, AttributeError):
        pass

    # Correlation is only meaningful for a session visible in the caller's
    # scope. Do not fall back to a raw session_id search: that would allow a
    # caller to probe logs belonging to another tenant when the session row is
    # hidden.
    if session_row is None:
        return CorrelateResponse()

    session_info = None
    if session_row:
        session_info = CorrelateSessionInfo(
            id=str(session_row.id),
            mac=session_row.mac,
            ip=session_row.ip,
            auth_method=session_row.auth_method,
            status=session_row.status,
            started_at=session_row.started_at.isoformat() if session_row.started_at else None,
            ended_at=session_row.ended_at.isoformat() if session_row.ended_at else None,
            bytes_in=session_row.bytes_in or 0,
            bytes_out=session_row.bytes_out or 0,
        )

    customer_id = getattr(session_row, "customer_id", None)
    if not customer_id:
        return CorrelateResponse(session=session_info)
    traffic_clauses = [
        FirewallLog.session_id == session_id,
        FirewallLog.log_type == "traffic",
        FirewallLog.customer_id == customer_id,
    ]
    auth_clauses = [
        FirewallLog.session_id == session_id,
        FirewallLog.log_type.in_(["event", "utm"]),
        FirewallLog.customer_id == customer_id,
    ]

    traffic_q = (
        select(FirewallLog)
        .where(*traffic_clauses)
        .order_by(FirewallLog.event_time.desc())
        .limit(500)
    )
    traffic_result = await db.execute(traffic_q)
    traffic_logs = [_row_to_log_item(r) for r in traffic_result.scalars().all()]

    auth_q = (
        select(FirewallLog)
        .where(*auth_clauses)
        .order_by(FirewallLog.event_time.desc())
        .limit(500)
    )
    auth_result = await db.execute(auth_q)
    auth_logs = [_row_to_log_item(r) for r in auth_result.scalars().all()]

    timeline_raw: list[tuple] = []
    for item in traffic_logs:
        ts = item.event_time or ""
        timeline_raw.append((ts, "traffic", item.log_type, item.severity, item.action, item.raw_syslog))
    for item in auth_logs:
        ts = item.event_time or ""
        timeline_raw.append((ts, "auth", item.log_type, item.severity, item.action, item.raw_syslog))
    if session_info:
        timeline_raw.append((session_info.started_at or "", "session", None, None, None, None))
        if session_info.ended_at:
            timeline_raw.append((session_info.ended_at, "session", None, None, None, None))

    timeline_raw.sort(key=lambda x: x[0] or "")
    timeline = [
        CorrelateTimelineItem(
            event_time=t[0],
            source=t[1],
            log_type=t[2],
            severity=t[3],
            action=t[4],
            message=t[5][:200] if t[5] else None,
        )
        for t in timeline_raw
    ]

    return CorrelateResponse(
        session=session_info,
        traffic_logs=traffic_logs,
        auth_logs=auth_logs,
        timeline=timeline,
    )


_CSV_BTK_COLUMNS = [
    "event_time", "received_at", "vendor", "log_type", "severity",
    "action", "src_ip", "dst_ip", "src_port", "dst_port",
    "proto", "service", "user", "policyid", "duration",
    "sentbyte", "rcvdbyte", "session_id",
]


async def export_firewall_logs(
    db: AsyncSession,
    user,
    filters: LogSearchParams,
    fmt: str = "csv",
    max_rows: int = 100_000,
):
    """Streaming export of firewall_logs matching filters."""
    scope = user if isinstance(user, ScopeContext) else scope_for(user)
    clauses = _build_where_clauses(filters, scope)

    q = select(FirewallLog)
    if clauses:
        q = q.where(*clauses)
    q = q.order_by(FirewallLog.event_time.desc()).limit(max_rows)
    result = await db.execute(q)
    rows = result.scalars().all()

    if fmt == "csv":
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=_CSV_BTK_COLUMNS)
        writer.writeheader()
        for r in rows:
            writer.writerow({
                "event_time": r.event_time.isoformat() if r.event_time else "",
                "received_at": r.received_at.isoformat() if r.received_at else "",
                "vendor": r.vendor,
                "log_type": r.log_type,
                "severity": r.severity,
                "action": r.action or "",
                "src_ip": r.src_ip or "",
                "dst_ip": r.dst_ip or "",
                "src_port": r.src_port or "",
                "dst_port": r.dst_port or "",
                "proto": r.proto or "",
                "service": r.service or "",
                "user": r.user or "",
                "policyid": r.policyid or "",
                "duration": r.duration or "",
                "sentbyte": r.sentbyte or "",
                "rcvdbyte": r.rcvdbyte or "",
                "session_id": r.session_id or "",
            })
        csv_content = buf.getvalue()

        async def _stream():
            yield csv_content.encode("utf-8")

        return _stream(), f"firewall-logs-export-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}.csv"

    buf = io.StringIO()
    for r in rows:
        item = _row_to_log_item(r)
        buf.write(item.model_dump_json(exclude_none=True) + "\n")
    jsonl_content = buf.getvalue()

    async def _stream():
        yield jsonl_content.encode("utf-8")

    return _stream(), f"firewall-logs-export-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}.jsonl"
