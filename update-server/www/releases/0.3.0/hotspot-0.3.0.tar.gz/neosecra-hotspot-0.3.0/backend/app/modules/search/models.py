"""Saved search view model."""
import uuid

from sqlalchemy import Boolean, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import TimestampMixin, UUIDPK, fk


class SearchView(Base, UUIDPK, TimestampMixin):
    """Saved search/filter view for log surfaces."""

    __tablename__ = "search_views"

    created_by_user_id: Mapped[uuid.UUID] = fk("users", ondelete="CASCADE")
    surface: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    filters: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    is_shared: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)

