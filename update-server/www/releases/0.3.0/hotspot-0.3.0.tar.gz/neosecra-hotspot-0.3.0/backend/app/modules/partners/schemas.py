"""Pydantic schemas for partners."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class PartnerBase(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    reseller_code: str | None = None
    contact_email: EmailStr | None = None
    contact_phone: str | None = None


class PartnerCreate(PartnerBase):
    tenant_id: uuid.UUID


class PartnerUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    reseller_code: str | None = None
    contact_email: EmailStr | None = None
    contact_phone: str | None = None
    is_active: bool | None = None


class PartnerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    tenant_id: uuid.UUID
    name: str
    reseller_code: str | None
    contact_email: str | None
    contact_phone: str | None
    is_active: bool
    created_at: datetime
    updated_at: datetime
