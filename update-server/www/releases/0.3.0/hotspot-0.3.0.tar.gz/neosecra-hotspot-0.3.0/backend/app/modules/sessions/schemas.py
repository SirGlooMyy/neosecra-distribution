"""Pydantic schemas for guest sessions. Outbound models expose the 5651
correlation keys (MAC/IP) and accounting counters; no secrets are stored on
this table."""
import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from app.modules.search.schemas import SearchCorrelationSummary


class GuestSessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    device_id: uuid.UUID | None = None
    identity_verification_id: uuid.UUID | None = None
    voucher_id: uuid.UUID | None = None
    group_id: uuid.UUID | None = None
    phone: str | None = None
    mac: str
    ip: str | None = None
    nas_ip: str | None = None
    ssid: str | None = None
    auth_method: str
    status: str
    started_at: datetime
    expires_at: datetime | None = None
    ended_at: datetime | None = None
    authorize_ok: bool
    authorize_message: str | None = None
    authorization_status: str = "pending"
    authorization_attempts: int = 0
    authorization_error_message: str | None = None
    external_session_id: str | None = None
    authorized_at: datetime | None = None
    revoked_at: datetime | None = None
    radius_session_id: str | None = None
    bytes_in: int
    bytes_out: int
    is_active: bool
    meta: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    # KVKK / Consent (HS-MVP-SLICE-01)
    terms_accepted: bool = False
    terms_accepted_at: datetime | None = None
    privacy_accepted: bool = False
    privacy_accepted_at: datetime | None = None
    terms_version: str | None = None
    privacy_version: str | None = None
    consent_ip: str | None = None
    consent_user_agent: str | None = None


class SessionCorrelationTimelineItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    source: str
    label: str
    matched: bool
    timestamp: datetime | None = None
    details: str | None = None


class SessionCorrelationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    guest_session_id: uuid.UUID
    customer_id: uuid.UUID
    location_id: uuid.UUID | None = None
    device_id: uuid.UUID | None = None
    mac: str
    ip: str | None = None
    phone: str | None = None
    nas_ip: str | None = None
    auth_method: str
    identity_verification_id: uuid.UUID | None = None
    voucher_id: uuid.UUID | None = None
    radius_session_id: str | None = None
    started_at: datetime | None = None
    ended_at: datetime | None = None
    expires_at: datetime | None = None
    status: str
    bytes_in: int
    bytes_out: int
    sources_matched: dict[str, bool]
    evidence_timeline: list[SessionCorrelationTimelineItem] = Field(default_factory=list)
    missing_sources: list[str] = Field(default_factory=list)
    stitching_summary: str = ""
    case_window_minutes: int = 15
    investigation_filters: dict[str, Any] = Field(default_factory=dict)
    related_log_count: int = 0
    related_log_groups: list[SearchCorrelationSummary] = Field(default_factory=list)
    case_summary: str = ""
    complete: bool


class SessionCloseIn(BaseModel):
    reason: str | None = Field(None, max_length=255)


class SessionListOut(BaseModel):
    items: list[GuestSessionOut]
    total: int = 0
