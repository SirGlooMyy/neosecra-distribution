# Repository/data access layer for firewall_adapters
