# Repository queries live in service.py for now.
# Migrate here when query complexity grows.
