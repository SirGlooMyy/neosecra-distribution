"""Ruijie / Reyee adapter — Ruijie Cloud API / local API.

Supports Ruijie RG-WALL and Ruijie Reyee (Cloud-Managed) series.
Uses Ruijie Cloud API (open.ruijiecloud.com) for cloud-managed devices,
or local HTTPS API for on-prem devices.
"""
from __future__ import annotations

import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class RuijieAdapter(FirewallAdapter):
    vendor = "ruijie"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        token = config.api_token or ""
        username = config.api_username or "admin"
        mode = (config.extra or {}).get("mode", "local")
        self._mode = mode
        if mode == "cloud":
            self._base_url = "https://open.ruijiecloud.com/api/open/v1"
        else:
            self._base_url = f"https://{host}:{port}/api/v1"
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if mode == "cloud":
            self._headers["Authorization"] = f"Bearer {token}"
            self._headers["X-Open-Id"] = config.extra.get("open_id", "")
        else:
            import base64
            auth_str = f"{username}:{token or 'ruijie'}"
            self._headers["Authorization"] = f"Basic {base64.b64encode(auth_str.encode()).decode()}"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"Ruijie {self._mode} {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        data = resp.json()
        if isinstance(data, dict) and data.get("code") not in (None, 0, "0", 200):
            msg = data.get("message", data.get("msg", "ruijie error"))
            raise AdapterError(f"Ruijie {path}: {msg}")
        return data

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=True,
            radius_authentication=True,
            radius_accounting=True,
            mac_auth_bypass=True,
            active_session_query=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            if self._mode == "cloud":
                data = await self._request("GET", "devices")
                devices = data.get("data", data)
                count = len(devices) if isinstance(devices, list) else 0
                return AdapterResult(
                    ok=True,
                    message=f"connected: Ruijie Cloud ({count} device(s))",
                    data={"device_count": count},
                )
            data = await self._request("GET", "system/status")
            sys = data.get("data", data)
            model = (sys if isinstance(sys, dict) else {}).get("model", "?")
            return AdapterResult(
                ok=True,
                message=f"connected: Ruijie {model}",
                data={"model": model},
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        if self._mode == "cloud":
            data = await self._request("GET", "devices")
            devices = data.get("data", data)
            if isinstance(devices, list) and devices:
                d = devices[0]
                return {
                    "hostname": d.get("name", ""),
                    "model": d.get("model", ""),
                    "serial_number": d.get("serialNumber", ""),
                    "firmware_version": d.get("firmwareVersion", ""),
                }
            return {}
        data = await self._request("GET", "system/status")
        sys = data.get("data", data) if isinstance(data, dict) else data
        return {
            "hostname": (sys if isinstance(sys, dict) else {}).get("hostname", ""),
            "model": (sys if isinstance(sys, dict) else {}).get("model", ""),
            "serial_number": (sys if isinstance(sys, dict) else {}).get("serialNumber", ""),
            "firmware_version": (sys if isinstance(sys, dict) else {}).get("firmwareVersion", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "interfaces")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for iface in raw:
            results.append({
                "name": iface.get("name", "") if isinstance(iface, dict) else "",
                "ip": iface.get("ip", "") if isinstance(iface, dict) else "",
                "type": iface.get("type", "") if isinstance(iface, dict) else "",
                "status": "up" if (iface if isinstance(iface, dict) else {}).get("status") == "up" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._request("GET", "captive-portal")
            r = data.get("data", data)
            return {
                "enabled": (r if isinstance(r, dict) else {}).get("enabled", False),
                "redirect_url": (r if isinstance(r, dict) else {}).get("redirectUrl", ""),
                "auth_mode": (r if isinstance(r, dict) else {}).get("authMode", ""),
            }
        except AdapterError:
            return {"enabled": False}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "sessions")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for s in raw:
            results.append({
                "ip": s.get("ip", ""),
                "user": s.get("user", ""),
                "mac": s.get("mac", ""),
                "state": s.get("state", ""),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "arp")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for entry in raw:
            results.append({
                "ip": entry.get("ip", "") if isinstance(entry, dict) else "",
                "mac": entry.get("mac", "") if isinstance(entry, dict) else "",
                "interface": entry.get("interface", "") if isinstance(entry, dict) else "",
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        policy = self._guest_policy(session)
        payload = {
            "ip": ip,
            "mac": mac,
            "description": self._guest_comment(session),
        }
        try:
            await self._request("POST", "mac-auth/allow", json=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={**payload, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "")
        try:
            await self._request("DELETE", "mac-auth/allow", json={"ip": ip, "mac": mac})
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "ruijie", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("host")
        parsed["event_type"] = parsed.get("type") or parsed.get("log_type")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        return parsed
