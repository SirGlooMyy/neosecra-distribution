import uuid

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import settings
from app.core.ingest_auth import require_ingest_api_key
from app.modules.radius.models import RadiusEvent
from app.modules.radius.schemas import RadiusEventCreate, RadiusEventOut
from app.modules.radius import challenge_service

router = APIRouter()


class VpnChallengeInitIn(BaseModel):
    """FreeRADIUS REST payload for the first Access-Request."""

    username: str = Field(..., min_length=1, max_length=255)
    customer_id: uuid.UUID | None = None
    nas_ip: str | None = None


class VpnChallengeVerifyIn(BaseModel):
    """FreeRADIUS REST payload for the Access-Challenge response."""

    state: str = Field(..., min_length=8, max_length=255)
    code: str = Field(..., min_length=4, max_length=32)


@router.post("/events", response_model=RadiusEventOut, summary="Ingest a RADIUS accounting event", description="Creates a new RADIUS accounting event record from a NAS device. Typically called by the RADIUS server or a syslog forwarder. Accepts standard RADIUS attributes such as username, NAS IP, and session identifiers.")
async def create_radius_event(
    body: RadiusEventCreate,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS")
    event = RadiusEvent(
        tenant_id=body.tenant_id,
        username=body.username,
        nas_ip=body.nas_ip,
        nas_port=body.nas_port,
        acct_status_type=body.acct_status_type,
        acct_session_id=body.acct_session_id,
        calling_station_id=body.calling_station_id,
        framed_ip_address=body.framed_ip_address
    )
    db.add(event)
    await db.commit()
    await db.refresh(event)
    return event


@router.post(
    "/vpn/challenge/init",
    summary="Start a VPN MFA RADIUS Access-Challenge",
    description="Called by the FreeRADIUS REST module for a FortiGate VPN login. The response contains the State and Reply-Message used for the second Access-Request.",
)
async def init_vpn_challenge(
    body: VpnChallengeInitIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    return await challenge_service.init_challenge(
        db,
        customer_id=body.customer_id,
        username=body.username,
        nas_ip=body.nas_ip,
    )


@router.post(
    "/vpn/challenge/verify",
    summary="Verify a VPN MFA RADIUS Access-Challenge",
    description="Called by FreeRADIUS when FortiGate returns the one-time SMS, email or authenticator code.",
)
async def verify_vpn_challenge(
    body: VpnChallengeVerifyIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    require_ingest_api_key(request, expected_key=settings.RADIUS_API_KEY, service="RADIUS VPN MFA")
    return await challenge_service.verify_challenge(db, state=body.state, code=body.code)
