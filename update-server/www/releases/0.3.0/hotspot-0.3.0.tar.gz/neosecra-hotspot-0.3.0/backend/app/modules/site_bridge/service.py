import hashlib
import hmac
import json
import logging
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.site_bridge.models import BridgeAgent, BridgeCommand, BridgeEvent

log = logging.getLogger(__name__)

BRIDGE_HMAC_KEY = settings.SECRET_KEY


def _sign(payload: dict, key: str = BRIDGE_HMAC_KEY) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hmac.new(key.encode(), raw.encode(), hashlib.sha256).hexdigest()


def _verify(payload: dict, signature: str, key: str = BRIDGE_HMAC_KEY) -> bool:
    expected = _sign(payload, key)
    return hmac.compare_digest(expected, signature)


# ---- Agent lifecycle ---------------------------------------------------------


async def register_agent(
    db: AsyncSession,
    tenant_id: uuid.UUID,
    location_id: uuid.UUID | None,
    body: dict,
    client_ip: str | None = None,
) -> BridgeAgent:
    existing = (
        await db.execute(select(BridgeAgent).where(BridgeAgent.agent_id == body["agent_id"]))
    ).scalar_one_or_none()
    if existing:
        existing.name = body.get("name", existing.name)
        existing.version = body.get("version", existing.version)
        existing.public_key = body.get("public_key", existing.public_key)
        existing.last_ip = client_ip or existing.last_ip
        existing.is_active = True
    else:
        existing = BridgeAgent(
            tenant_id=tenant_id,
            location_id=location_id,
            agent_id=body["agent_id"],
            name=body.get("name", body["agent_id"]),
            version=body.get("version"),
            public_key=body.get("public_key"),
            last_ip=client_ip,
        )
        db.add(existing)
    await db.commit()
    await db.refresh(existing)
    return existing


async def heartbeat(db: AsyncSession, agent_id: str, version: str | None = None) -> dict:
    agent = (
        await db.execute(select(BridgeAgent).where(BridgeAgent.agent_id == agent_id))
    ).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Agent bulunamadi")
    agent.last_heartbeat_at = datetime.now(timezone.utc)
    if version:
        agent.version = version
    await db.commit()

    pending_commands = (
        await db.execute(
            select(BridgeCommand).where(
                BridgeCommand.agent_id == agent_id,
                BridgeCommand.status == "pending",
            )
        )
    ).scalars().all()

    return {
        "ok": True,
        "pending_commands": [
            {"id": str(c.id), "type": c.command_type, "payload": c.payload, "signature": c.signature}
            for c in pending_commands
        ],
    }


async def list_agents(db: AsyncSession, scope: ScopeContext) -> list[BridgeAgent]:
    q = select(BridgeAgent)
    if scope.level == TenantLevel.TENANT and scope.tenant_id:
        q = q.where(BridgeAgent.tenant_id == scope.tenant_id)
    elif scope.level == TenantLevel.LOCATION and scope.location_id:
        q = q.where(BridgeAgent.location_id == scope.location_id)
    result = await db.execute(q.order_by(BridgeAgent.created_at.desc()))
    return list(result.scalars().all())


# ---- Command dispatch --------------------------------------------------------


async def dispatch_command(
    db: AsyncSession, agent_id: str, command_type: str, payload: dict
) -> BridgeCommand:
    agent = (
        await db.execute(select(BridgeAgent).where(BridgeAgent.agent_id == agent_id))
    ).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Agent bulunamadi")

    cmd = BridgeCommand(
        agent_id=agent_id,
        command_type=command_type,
        payload=payload,
        signature=_sign({"type": command_type, "payload": payload}),
        status="pending",
    )
    db.add(cmd)
    await db.commit()
    await db.refresh(cmd)
    return cmd


async def acknowledge_command(db: AsyncSession, command_id: uuid.UUID, status_: str, result: dict) -> BridgeCommand:
    cmd = await db.get(BridgeCommand, command_id)
    if not cmd:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Komut bulunamadi")
    cmd.status = status_
    cmd.executed_at = datetime.now(timezone.utc)
    cmd.result = result
    await db.commit()
    await db.refresh(cmd)
    return cmd


async def list_commands(db: AsyncSession, agent_id: str, limit: int = 50) -> list[BridgeCommand]:
    result = await db.execute(
        select(BridgeCommand)
        .where(BridgeCommand.agent_id == agent_id)
        .order_by(BridgeCommand.created_at.desc())
        .limit(limit)
    )
    return list(result.scalars().all())


# ---- Event ingest ------------------------------------------------------------


async def ingest_event(db: AsyncSession, agent_id: str, event_type: str, payload: dict) -> BridgeEvent:
    event = BridgeEvent(agent_id=agent_id, event_type=event_type, payload=payload)
    db.add(event)
    await db.commit()
    await db.refresh(event)
    return event
