import httpx
from app.core.config import settings
from .base import SmsProvider


class RelatedDigitalProvider(SmsProvider):
    async def send(self, phone: str, message: str) -> tuple[bool, str]:
        url = self.value("http_url", settings.RELATEDDIGITAL_API_URL) or "https://api.relateddigital.com/sms/send"
        api_key = self.value("api_key", settings.RELATEDDIGITAL_API_KEY)
        if not api_key:
            return False, "relateddigital-missing-api-key"
        headers = {"Authorization": f"Bearer {api_key}"}
        payload = {
            "recipient": phone,
            "message": {"text": message},
            "sender": self.value("sender", settings.SMS_SENDER),
        }
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json=payload, headers=headers)
            if 200 <= resp.status_code < 300:
                return True, ""
            return False, f"relateddigital-{resp.status_code}"
        except Exception as exc:
            return False, f"relateddigital-error:{type(exc).__name__}"
