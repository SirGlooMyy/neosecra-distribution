"""Pydantic schemas for tenants."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class TenantBase(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    slug: str = Field(min_length=1, max_length=100)
    domain: str | None = None
    is_demo: bool = False


class TenantCreate(TenantBase):
    is_root: bool = False


class TenantUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    slug: str | None = Field(default=None, min_length=1, max_length=100)
    domain: str | None = None
    is_active: bool | None = None
    is_demo: bool | None = None


class TenantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    name: str
    slug: str
    domain: str | None
    is_root: bool
    is_demo: bool
    is_active: bool
    created_at: datetime
    updated_at: datetime
