"""Pydantic schemas for auth."""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1)


class RefreshRequest(BaseModel):
    refresh_token: str


class LogoutRequest(BaseModel):
    refresh_token: str | None = None


class UserMeUpdate(BaseModel):
    email: EmailStr | None = Field(None)
    full_name: str | None = Field(None, max_length=255)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    email: EmailStr
    full_name: str | None
    role: str
    tenant_id: uuid.UUID | None
    partner_id: uuid.UUID | None
    customer_id: uuid.UUID | None
    location_id: uuid.UUID | None
    is_2fa_enabled: bool
    mfa_required: bool = False
    mfa_methods: list[str] = []
    last_login_at: datetime | None


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: UserOut


class LoginResponse(BaseModel):
    access_token: str | None = None
    refresh_token: str | None = None
    token_type: str = "bearer"
    user: UserOut | None = None
    mfa_required: bool = False
    mfa_session_token: str | None = None


class MfaVerifyIn(BaseModel):
    session_token: str
    code: str = Field(..., min_length=1, max_length=10)
