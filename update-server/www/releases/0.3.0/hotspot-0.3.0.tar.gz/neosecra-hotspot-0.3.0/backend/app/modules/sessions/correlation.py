"""Session correlation engine (Mutlak Kural #5).

Links a GuestSession to every related evidence source so that NO event
(RADIUS accounting, syslog, firewall-API session) is purged before its
correlation to a guest identity is recorded.

Today the platform sources we can join in-process are the portal session itself
and its IdentityVerification. The RADIUS-accounting, syslog and live firewall
feeds arrive via workers (M6); until they do, those sources report `matched=False`
and the session is therefore NOT `complete` — which is exactly the gate Kural #5
demands: incomplete correlations may not be purged/retention-deleted.

The correlation key is (mac, ip, phone, time-window): NAT'd environments share
public IPs, so MAC is the primary physical key and phone the identity key, with
the session's started_at..ended_at window bounding which events belong to it.
On top of the gate we also stitch related firewall/syslog evidence into the
admin view so investigators can see the surrounding log groups without marking
those external sources as fully complete yet.
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.identity.models import IdentityVerification
from app.modules.radius.models import RadiusEvent
from app.modules.search import service as search_service
from app.modules.syslog.models import FirewallLog
from app.modules.search.schemas import SearchQuery
from app.modules.sessions.models import GuestSession
from app.modules.sessions.schemas import (
    SessionCorrelationOut,
    SessionCorrelationTimelineItem,
)

log = logging.getLogger(__name__)

SOURCE_LABELS = {
    "portal": "Portal oturumu",
    "identity": "Kimlik doğrulama",
    "radius": "RADIUS",
    "syslog": "Syslog",
    "firewall_api": "Firewall API",
}

_CASE_WINDOW_MINUTES = 15
_CASE_RESULT_LIMIT = 5000


def _timeline_timestamp(value: datetime | None) -> datetime:
    return value or datetime.min.replace(tzinfo=timezone.utc)


def _append_timeline(
    timeline: list[tuple[datetime | None, int, SessionCorrelationTimelineItem]],
    *,
    order: int,
    source: str,
    label: str,
    matched: bool,
    timestamp: datetime | None,
    details: str | None = None,
) -> None:
    timeline.append(
        (
            timestamp,
            order,
            SessionCorrelationTimelineItem(
                source=source,
                label=label,
                matched=matched,
                timestamp=timestamp,
                details=details,
            ),
        )
    )


def _build_summary(sources: dict[str, bool]) -> tuple[list[str], list[str], str]:
    matched = [SOURCE_LABELS[key] for key, value in sources.items() if value]
    missing = [SOURCE_LABELS[key] for key, value in sources.items() if not value]
    if missing:
        summary = f"{', '.join(matched)} eşleşti; {', '.join(missing)} bekliyor."
    else:
        summary = f"{', '.join(matched)} tamamlandı."
    return matched, missing, summary


def _case_window(session: GuestSession, iv: IdentityVerification | None) -> tuple[datetime, datetime]:
    start_anchor = session.started_at or (iv.created_at if iv else None) or getattr(session, "created_at", None) or datetime.now(timezone.utc)
    end_anchor = session.ended_at or session.expires_at or (iv.consumed_at if iv and iv.consumed_at else None) or datetime.now(timezone.utc)
    start_window = start_anchor - timedelta(minutes=_CASE_WINDOW_MINUTES)
    end_window = end_anchor + timedelta(minutes=_CASE_WINDOW_MINUTES)
    return start_window, end_window


def _build_case_summary(session: GuestSession, related_log_count: int, related_log_group_count: int) -> str:
    label = session.phone or session.mac
    if related_log_count:
        return (
            f"{label} için {_CASE_WINDOW_MINUTES} dakikalık pencerede "
            f"{related_log_count} firewall kaydı ve {related_log_group_count} korelasyon grubu bulundu."
        )
    return (
        f"{label} için {_CASE_WINDOW_MINUTES} dakikalık pencerede "
        "ilişkilendirilmiş firewall kaydı bulunamadı."
    )


def _build_timeline(
    session: GuestSession,
    iv: IdentityVerification | None,
    *,
    syslog_matched: bool,
    related_log_count: int,
    firewall_api_matched: bool,
) -> list[SessionCorrelationTimelineItem]:
    timeline: list[tuple[datetime | None, int, SessionCorrelationTimelineItem]] = []

    if iv:
        phone_value = iv.phone_masked or session.phone
        identity_details = [f"yöntem={iv.method}"]
        if phone_value:
            identity_details.append(f"telefon={phone_value}")
        if iv.verified is not None:
            identity_details.append(f"verified={str(iv.verified).lower()}")
        _append_timeline(
            timeline,
            order=10,
            source="identity",
            label="Kimlik doğrulama kaydı oluşturuldu",
            matched=True,
            timestamp=iv.created_at,
            details=" · ".join(identity_details),
        )
        if iv.consumed_at:
            _append_timeline(
                timeline,
                order=20,
                source="identity",
                label="Portal token tüketildi",
                matched=True,
                timestamp=iv.consumed_at,
                details="Portal token başarıyla tüketildi ve oturuma bağlandı.",
            )

    portal_timestamp = session.started_at or getattr(session, "created_at", None)
    portal_details = [f"mac={session.mac}"]
    if session.ip:
        portal_details.append(f"ip={session.ip}")
    if session.phone:
        portal_details.append(f"telefon={session.phone}")
    _append_timeline(
        timeline,
        order=30,
        source="portal",
        label="Portal oturumu başlatıldı",
        matched=True,
        timestamp=portal_timestamp,
        details=" · ".join(portal_details),
    )

    if session.radius_session_id:
        radius_details = [f"radius_session_id={session.radius_session_id}"]
        radius_details.append(f"bytes_in={session.bytes_in}")
        radius_details.append(f"bytes_out={session.bytes_out}")
        _append_timeline(
            timeline,
            order=40,
            source="radius",
            label="RADIUS kaydı eşleşti",
            matched=True,
            timestamp=portal_timestamp,
            details=" · ".join(radius_details),
        )

    if syslog_matched:
        _append_timeline(
            timeline,
            order=90,
            source="syslog",
            label="Syslog kayitlari eslesti",
            matched=True,
            timestamp=portal_timestamp,
            details=f"{related_log_count} iliskilendirilmis log kaydi bulundu.",
        )
    else:
        _append_timeline(
            timeline,
            order=90,
            source="syslog",
            label="Syslog entegrasyonu bekleniyor",
            matched=False,
            timestamp=None,
            details="M6 worker entegrasyonu bekleniyor.",
        )

    if firewall_api_matched:
        firewall_details = [f"authorize_ok={str(bool(getattr(session, 'authorize_ok', False))).lower()}"]
        authorize_message = getattr(session, "authorize_message", None)
        if authorize_message:
            firewall_details.append(f"message={authorize_message}")
        _append_timeline(
            timeline,
            order=100,
            source="firewall_api",
            label="Firewall API cagrisi kaydedildi",
            matched=True,
            timestamp=portal_timestamp,
            details=" · ".join(firewall_details),
        )
    else:
        _append_timeline(
            timeline,
            order=100,
            source="firewall_api",
            label="Firewall API entegrasyonu bekleniyor",
            matched=False,
            timestamp=None,
            details="M6 worker entegrasyonu bekleniyor.",
        )

    return [
        item
        for _, __, item in sorted(
            timeline,
            key=lambda item: (
                item[0] is None,
                _timeline_timestamp(item[0]),
                item[1],
            ),
        )
    ]


async def correlate(db: AsyncSession, *, guest_session_id: uuid.UUID) -> SessionCorrelationOut:
    """Build the correlation record for a guest session.

    Loads the session + its identity verification and reports which evidence
    sources are currently matched. The portal flow itself records the firewall
    API authorization attempt on the session row; M6 workers extend this with
    RADIUS and syslog lookups."""
    session = await db.get(GuestSession, guest_session_id)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Oturum bulunamadi"
        )

    iv: IdentityVerification | None = None
    if session.identity_verification_id:
        iv = await db.get(IdentityVerification, session.identity_verification_id)

    start_window, end_window = _case_window(session, iv)
    investigation_filters = {
        "customer_id": str(session.customer_id),
        "location_id": str(session.location_id) if session.location_id else None,
        "device_id": str(session.device_id) if session.device_id else None,
        "mac": session.mac,
        "source_ip": session.ip,
        "username": session.phone,
        "q": session.phone or session.mac,
        "from_time": start_window.isoformat(),
        "to_time": end_window.isoformat(),
        "correlation_window_minutes": _CASE_WINDOW_MINUTES,
    }
    related_log_groups = []
    related_log_count = 0
    case_summary = _build_case_summary(session, 0, 0)

    try:
        search_scope = ScopeContext(
            level=TenantLevel.CUSTOMER,
            customer_id=session.customer_id,
            allowed=True,
        )
        case_query = SearchQuery(
            customer_id=str(session.customer_id),
            q=session.phone or session.mac,
            mac=session.mac,
            source_ip=session.ip if session.ip and session.ip != "::" else None,
            username=session.phone,
            location_id=str(session.location_id) if session.location_id else None,
            device_id=str(session.device_id) if session.device_id else None,
            from_time=start_window,
            to_time=end_window,
            correlation_window_minutes=_CASE_WINDOW_MINUTES,
            limit=_CASE_RESULT_LIMIT,
            offset=0,
        )
        related_result = await search_service.search_syslog(db, search_scope, case_query)
        related_log_count = related_result.total
        related_log_groups = list(related_result.correlation_summary[:5])
        case_summary = _build_case_summary(session, related_log_count, len(related_log_groups))
    except Exception as exc:  # pragma: no cover - defensive fallback for log stitching
        log.warning("Session case stitching failed for %s: %s", session.id, exc)

    radius_matched = bool(session.radius_session_id)
    if not radius_matched and session.mac:
        radius_hits = await db.execute(
            select(RadiusEvent).where(
                RadiusEvent.calling_station_id == session.mac,
                RadiusEvent.created_at >= start_window,
                RadiusEvent.created_at <= end_window,
            ).limit(1)
        )
        radius_matched = radius_hits.scalar_one_or_none() is not None

    sources = {
        "portal": True,
        "identity": iv is not None,
        "radius": radius_matched,
        "syslog": related_log_count > 0,
        "firewall_api": True,
    }

    _, missing_sources, stitching_summary = _build_summary(sources)
    evidence_timeline = _build_timeline(
        session,
        iv,
        syslog_matched=related_log_count > 0,
        related_log_count=related_log_count,
        firewall_api_matched=True,
    )

    return SessionCorrelationOut(
        guest_session_id=session.id,
        customer_id=session.customer_id,
        location_id=session.location_id,
        device_id=session.device_id,
        # 5651 correlation key (mac primary, ip/phone secondary under NAT).
        mac=session.mac,
        ip=session.ip,
        phone=session.phone,
        nas_ip=session.nas_ip,
        auth_method=session.auth_method,
        identity_verification_id=iv.id if iv else None,
        voucher_id=session.voucher_id,
        radius_session_id=session.radius_session_id,
        started_at=session.started_at,
        ended_at=session.ended_at,
        expires_at=session.expires_at,
        status=session.status,
        bytes_in=session.bytes_in,
        bytes_out=session.bytes_out,
        sources_matched=sources,
        evidence_timeline=evidence_timeline,
        missing_sources=missing_sources,
        stitching_summary=stitching_summary,
        case_window_minutes=_CASE_WINDOW_MINUTES,
        investigation_filters=investigation_filters,
        related_log_count=related_log_count,
        related_log_groups=related_log_groups,
        case_summary=case_summary,
        # Kural #5 purge gate: True only when every evidence source is matched.
        complete=all(sources.values()),
    )


async def correlate_session_with_firewall_logs(
    db: AsyncSession, session_id: uuid.UUID
) -> dict:
    """Correlate a GuestSession with its matching FirewallLog rows.

    Looks up FirewallLog records whose src_ip matches the session's IP
    (or session_id / mac) within the session time window. Returns a 5651
    view dict with: session info, traffic logs, total bytes, duration.
    """
    session = await db.get(GuestSession, session_id)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Oturum bulunamadi"
        )

    start_anchor = session.started_at or datetime.now(timezone.utc)
    end_anchor = session.ended_at or session.expires_at or datetime.now(timezone.utc)
    start_window = start_anchor - timedelta(minutes=_CASE_WINDOW_MINUTES)
    end_window = end_anchor + timedelta(minutes=_CASE_WINDOW_MINUTES)

    traffic_logs: list[dict] = []
    total_bytes_in = 0
    total_bytes_out = 0
    total_duration_sec = 0

    try:
        conditions = [
            FirewallLog.customer_id == session.customer_id,
            FirewallLog.received_at >= start_window,
            FirewallLog.received_at <= end_window,
        ]
        if session.ip and session.ip not in ("::", "0.0.0.0"):
            conditions.append(FirewallLog.src_ip == session.ip)

        fw_logs = await db.execute(
            select(FirewallLog).where(and_(*conditions))
            .order_by(FirewallLog.received_at.asc())
        )
        for row in fw_logs.scalars().all():
            traffic_logs.append({
                "id": str(row.id),
                "log_type": row.log_type,
                "action": row.action,
                "src_ip": row.src_ip,
                "dst_ip": row.dst_ip,
                "src_port": row.src_port,
                "dst_port": row.dst_port,
                "proto": row.proto,
                "service": row.service,
                "session_id": row.session_id,
                "sentbyte": row.sentbyte,
                "rcvdbyte": row.rcvdbyte,
                "duration": row.duration,
                "received_at": row.received_at.isoformat() if row.received_at else None,
            })
            if row.sentbyte:
                total_bytes_in += row.sentbyte
            if row.rcvdbyte:
                total_bytes_out += row.rcvdbyte
            if row.duration:
                total_duration_sec = max(total_duration_sec, row.duration)
    except Exception as exc:
        log.warning("firewall_log correlation failed for session=%s: %s", session.id, exc)

    if not total_duration_sec and session.started_at and session.ended_at:
        total_duration_sec = int((session.ended_at - session.started_at).total_seconds())

    return {
        "session": {
            "id": str(session.id),
            "customer_id": str(session.customer_id),
            "location_id": str(session.location_id) if session.location_id else None,
            "mac": session.mac,
            "ip": session.ip,
            "phone": session.phone,
            "auth_method": session.auth_method,
            "status": session.status,
            "started_at": session.started_at.isoformat() if session.started_at else None,
            "ended_at": session.ended_at.isoformat() if session.ended_at else None,
            "duration_sec": total_duration_sec,
            "bytes_in": session.bytes_in,
            "bytes_out": session.bytes_out,
            "authorize_ok": session.authorize_ok,
        },
        "traffic_logs": traffic_logs,
        "total_bytes_in": total_bytes_in,
        "total_bytes_out": total_bytes_out,
        "total_duration_sec": total_duration_sec,
        "log_count": len(traffic_logs),
    }
