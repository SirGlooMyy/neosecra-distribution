"""Captive portal form-field schema helpers.

The editor stores field definitions as JSON on :class:`PortalTemplate`.  This
module is deliberately dependency-light so both the public renderer and the
verification flow apply the same defaults/validation rules.  Unknown fields
are allowed (customers often collect a company or department), while keys are
kept deliberately boring and bounded to prevent HTML/SQL surprises.
"""
from __future__ import annotations

import re
from typing import Any

FIELD_TYPES = {
    "text", "tel", "email", "number", "date", "password", "url", "textarea",
    "select", "checkbox",
}

_KEY_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_.-]{0,63}$")

# These are the fields understood by the captive flow.  Custom fields are
# still rendered and persisted, but do not change the selected auth method.
METHOD_DEFAULT_FIELDS: dict[str, list[dict[str, Any]]] = {
    "sms": [{"key": "phone", "name": "phone", "label": "Telefon numarası", "type": "tel", "required": True, "enabled": True, "validation": "tr_phone", "placeholder": "05xx xxx xx xx", "order": 1}],
    "tc": [{"key": "tc_number", "name": "tc_number", "label": "T.C. kimlik numarası", "type": "text", "required": True, "enabled": True, "validation": "tr_tc", "placeholder": "11 haneli T.C. kimlik numaranız", "order": 1}],
    "voucher": [{"key": "voucher_code", "name": "voucher_code", "label": "Bilet / voucher kodu", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Kodunuzu girin", "order": 1}],
    "whatsapp": [{"key": "phone", "name": "phone", "label": "Telefon numarası", "type": "tel", "required": True, "enabled": True, "validation": "tr_phone", "placeholder": "05xx xxx xx xx", "order": 1}],
    "meeting": [{"key": "voucher_code", "name": "voucher_code", "label": "Toplantı kodu", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Toplantı kodu", "order": 1}],
    "pms": [
        {"key": "room_number", "name": "room_number", "label": "Oda numarası", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Oda no", "order": 1},
        {"key": "surname_or_birth", "name": "surname_or_birth", "label": "Soyad / doğum yılı", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Soyad veya doğum yılı", "order": 2},
    ],
    "foreigner": [
        {"key": "passport_number", "name": "passport_number", "label": "Pasaport numarası", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Pasaport no", "order": 1},
        {"key": "full_name", "name": "full_name", "label": "Ad soyad", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Adınız ve soyadınız", "order": 2},
        {"key": "country", "name": "country", "label": "Ülke", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Ülkeniz", "order": 3},
    ],
    "local": [
        {"key": "username", "name": "username", "label": "Kullanıcı adı", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Kullanıcı adınız", "order": 1},
        {"key": "password", "name": "password", "label": "Şifre", "type": "password", "required": True, "enabled": True, "validation": "none", "placeholder": "Şifreniz", "order": 2},
    ],
    "ldap": [
        {"key": "username", "name": "username", "label": "Kullanıcı adı", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Kullanıcı adınız", "order": 1},
        {"key": "password", "name": "password", "label": "Şifre", "type": "password", "required": True, "enabled": True, "validation": "none", "placeholder": "Şifreniz", "order": 2},
    ],
    "radius": [
        {"key": "username", "name": "username", "label": "RADIUS kullanıcı adı", "type": "text", "required": True, "enabled": True, "validation": "none", "placeholder": "Kullanıcı adı", "order": 1},
        {"key": "password", "name": "password", "label": "RADIUS şifresi", "type": "password", "required": True, "enabled": True, "validation": "none", "placeholder": "Şifre", "order": 2},
    ],
}


def normalize_field(raw: Any, index: int, *, fallback: dict[str, Any] | None = None) -> dict[str, Any]:
    fallback = fallback or {}
    raw = raw if isinstance(raw, dict) else {}
    key = str(raw.get("key") or raw.get("name") or fallback.get("key") or f"field_{index + 1}").strip()
    if not _KEY_RE.fullmatch(key):
        raise ValueError(f"Geçersiz form alanı anahtarı: {key}")
    field_type = str(raw.get("type") or fallback.get("type") or "text").lower()
    if field_type not in FIELD_TYPES:
        raise ValueError(f"Geçersiz form alanı tipi: {field_type}")
    label = str(raw.get("label") or fallback.get("label") or key).strip()[:120]
    placeholder = str(raw.get("placeholder") or fallback.get("placeholder") or "").strip()[:200]
    validation = str(raw.get("validation") or fallback.get("validation") or "none").strip().lower()[:40]
    try:
        order = int(raw.get("order", fallback.get("order", index + 1)))
    except (TypeError, ValueError):
        order = index + 1
    return {
        "key": key,
        "name": key,  # legacy renderer/editor compatibility
        "label": label,
        "type": field_type,
        "enabled": bool(raw.get("enabled", True)),
        "required": bool(raw.get("required", fallback.get("required", False))),
        "placeholder": placeholder,
        "validation": validation,
        "order": max(1, min(order, 999)),
        **({"options": raw.get("options")} if isinstance(raw.get("options"), list) else {}),
    }


def normalize_fields(fields: Any, method: str | None = None) -> list[dict[str, Any]]:
    """Return a stable, sorted field list; empty legacy lists get method defaults."""
    source = fields if isinstance(fields, list) and fields else METHOD_DEFAULT_FIELDS.get(method or "", [])
    defaults = METHOD_DEFAULT_FIELDS.get(method or "", [])
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(source[:50]):
        fallback = defaults[index] if index < len(defaults) else None
        field = normalize_field(raw, index, fallback=fallback)
        if field["key"] in seen:
            continue
        seen.add(field["key"])
        normalized.append(field)
    return sorted(normalized, key=lambda item: (item["order"], item["key"]))


def enabled_fields(fields: Any, method: str | None = None) -> list[dict[str, Any]]:
    return [field for field in normalize_fields(fields, method) if field["enabled"]]
