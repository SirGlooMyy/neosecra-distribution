"""Celery tasks for the Hotspot platform.

Each task is SYNC (Celery requirement) and runs its async service logic through
asyncio.run with a NullPool worker session (see runtime.py). Internal platform
jobs use a GLOBAL scope — they are not user requests and must not expose the
tenant-filtered API surface.

Real implementations:
  * expire_due_sessions        — sessions.service.expire_due (beat */5 min)
  * archive_5651_daily         — logs_5651.service.build_session_archive per customer (beat 02:30)
  * archive_5651_for_customer  — manual single-customer/day archive
  * session_correlation_job    — sessions.correlation.correlate (read-only)
  * firewall_sync_job          — firewall_adapters.service.discover_device (metadata mirror)
  * syslog_parse_job           — firewall_adapters.service.parse_syslog (normalize raw line)
  * cleanup_expired_trial_sandboxes — public_content.service.cleanup_expired_trial_sandboxes

The worker now uses the persisted ReportJob flow from reports.scheduler_service.
The old stub note was stale and has been removed to avoid misleading ops.
"""
import asyncio
import os
import logging
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.core.config import settings
from app.core.tenant import ScopeContext, TenantLevel
from app.modules.logs_5651.models import ArchiveRecord
from app.modules.workers.celery_app import celery_app
from app.modules.workers.runtime import WorkerSession

log = logging.getLogger(__name__)


def _worker_scope() -> ScopeContext:
    """Internal jobs see GLOBAL scope (platform job, not a user request)."""
    return ScopeContext(level=TenantLevel.GLOBAL)


def _run(coro):
    """Run an async service call on a fresh loop (NullPool = cross-loop safe)."""
    return asyncio.run(coro)


# ---- expire overdue sessions (Kural #5: EXPIRE, never delete) ----------------
@celery_app.task(name="app.modules.workers.tasks.expire_due_sessions")
def expire_due_sessions() -> dict:
    async def _go():
        from app.modules.sessions import service as sessions_service
        async with WorkerSession() as db:
            return await sessions_service.expire_due(db)

    try:
        n = _run(_go())
        log.info("expire_due_sessions: %s oturum suresi doldu (EXPIRED)", n)
        return {"expired": n}
    except Exception as exc:  # noqa: BLE001 — beat must survive
        log.exception("expire_due_sessions failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@celery_app.task(name="app.modules.workers.tasks.revoke_expired_firewall_rules")
def revoke_expired_firewall_rules() -> dict:
    """Revoke firewall rules for sessions that were marked EXPIRED but still have
    active firewall address objects. Runs after expire_due_sessions."""
    async def _go():
        from app.modules.sessions.models import GuestSession, STATUS_EXPIRED
        from app.modules.firewall_adapters.service import revoke_guest_service
        scope = _worker_scope()
        async with WorkerSession() as db:
            res = await db.execute(
                select(GuestSession).where(
                    GuestSession.status == STATUS_EXPIRED,
                    GuestSession.device_id.is_not(None),
                )
            )
            expired = list(res.scalars().all())
            revoked, failed = 0, 0
            for s in expired:
                if s.device_id is None:
                    continue
                try:
                    await revoke_guest_service(
                        db, s.device_id, scope,
                        {"session_id": str(s.id), "ip": s.ip, "mac": s.mac},
                    )
                    revoked += 1
                except Exception as exc:
                    log.warning("revoke_expired_firewall_rules session=%s: %s", s.id, exc)
                    failed += 1
            return {"processed": len(expired), "revoked": revoked, "failed": failed}
    try:
        result = _run(_go())
        log.info("revoke_expired_firewall_rules: %s", result)
        return result
    except Exception as exc:
        log.exception("revoke_expired_firewall_rules failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---- daily 5651 archive (Kural #4: append-only per-customer chain) ----------
@celery_app.task(name="app.modules.workers.tasks.archive_5651_daily")
def archive_5651_daily() -> dict:
    """Seal yesterday's (UTC) 5651 session archive for every active customer.

    Each customer is built in its own session + try/except so one failure does
    not abort the batch; every success appends a new chain record (Kural #4 —
    never mutates an existing record)."""

    async def _list_customers():
        from app.modules.customers.models import Customer
        async with WorkerSession() as db:
            res = await db.execute(select(Customer.id))
            return [cid for cid in res.scalars().all()]

    async def _build_one(customer_id, start, end):
        from app.modules.logs_5651 import service as logs_service
        async with WorkerSession() as db:
            return await logs_service.build_session_archive(
                db, customer_id=customer_id, period_start=start, period_end=end
            )

    today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    start, end = today - timedelta(days=1), today

    try:
        cids = _run(_list_customers())
    except Exception as exc:  # noqa: BLE001
        log.exception("archive_5651_daily: customer list failed: %s", exc)
        return {"ok": False, "error": str(exc)}

    built, failed = 0, 0
    for cid in cids:
        try:
            _run(_build_one(cid, start, end))
            built += 1
        except Exception as exc:  # noqa: BLE001
            failed += 1
            log.warning("archive_5651_daily customer=%s failed: %s", cid, exc)

    log.info("archive_5651_daily %s..%s built=%d failed=%d", start.isoformat(), end.isoformat(), built, failed)
    return {
        "period_start": start.isoformat(),
        "customers": len(cids),
        "built": built,
        "failed": failed,
    }


# ---- trial sandbox cleanup (soft decommission, no hard delete) --------------
@celery_app.task(name="app.modules.workers.tasks.cleanup_expired_trial_sandboxes")
def cleanup_expired_trial_sandboxes() -> dict:
    """Deactivate trial sandbox resources whose license has expired."""

    async def _go():
        from app.modules.public_content import service as public_content_service
        async with WorkerSession() as db:
            return await public_content_service.cleanup_expired_trial_sandboxes(db)

    try:
        result = _run(_go())
        log.info(
            "cleanup_expired_trial_sandboxes: due=%s cleaned=%s skipped=%s",
            result.get("due"),
            result.get("cleaned"),
            result.get("skipped"),
        )
        return result
    except Exception as exc:  # noqa: BLE001
        log.exception("cleanup_expired_trial_sandboxes failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@celery_app.task(name="app.modules.workers.tasks.archive_5651_for_customer")
def archive_5651_for_customer(customer_id: str, date_iso: str | None = None) -> dict:
    """Manual trigger: archive a single customer for a given day (UTC).
    date_iso defaults to yesterday."""
    from app.modules.logs_5651 import service as logs_service

    if date_iso:
        day = datetime.fromisoformat(date_iso).replace(tzinfo=timezone.utc)
    else:
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        day = today - timedelta(days=1)
    start, end = day, day + timedelta(days=1)

    async def _go():
        async with WorkerSession() as db:
            rec = await logs_service.build_session_archive(
                db,
                customer_id=uuid.UUID(customer_id),
                period_start=start,
                period_end=end,
            )
            return {"record_id": str(rec.id), "chain_seq": rec.chain_seq, "curr_hash": rec.curr_hash}

    try:
        return _run(_go())
    except Exception as exc:  # noqa: BLE001
        log.exception("archive_5651_for_customer failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---- daily archive chunk sign (hash chain + local cert CAdES + MinIO WORM) ----
@celery_app.task(name="app.modules.workers.tasks.archive_daily_sign")
def archive_daily_sign() -> dict:
    """Build, sign (local cert), and upload to MinIO WORM the previous day's
    archive chunk for every active customer.

    Runs nightly at 23:00 UTC (02:00 Turkey). Each customer is isolated in its
    own session so one failure does not abort the batch.
    """

    async def _list_customers():
        from app.modules.customers.models import Customer
        async with WorkerSession() as db:
            res = await db.execute(select(Customer.id))
            return [cid for cid in res.scalars().all()]

    today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    period_start, period_end = today - timedelta(days=1), today
    built, signed, uploaded, failed = 0, 0, 0, 0

    try:
        cids = _run(_list_customers())
    except Exception as exc:
        log.exception("archive_daily_sign: customer list failed: %s", exc)
        return {"ok": False, "error": str(exc)}

    cert_path = settings.TUBITAK_CERTIFICATE_PATH
    cert_password = settings.TUBITAK_CERTIFICATE_PASSWORD

    for cid in cids:
        try:
            async def _process_one(customer_id):
                from app.modules.archive import service as archive_service
                from app.modules.archive.repository import (
                    get_chunk,
                )

                async with WorkerSession() as db:
                    result = await archive_service.build_chunk_for_period(
                        db,
                        customer_id=customer_id,
                        period_start=period_start,
                        period_end=period_end,
                    )
                    nonlocal built
                    built += 1

                    if cert_path:
                        chunk = await get_chunk(db, result.chunk_id)
                        if chunk:
                            await archive_service.sign_chunk_with_local_cert(
                                db, chunk, cert_path, cert_password
                            )
                            nonlocal signed
                            signed += 1

                            payload = (chunk.meta or {}).get("_chunk_json", "")
                            await archive_service.upload_to_minio_worm(
                                chunk, payload.encode("utf-8") if payload else None
                            )
                            nonlocal uploaded
                            uploaded += 1

            _run(_process_one(cid))
        except Exception as exc:
            failed += 1
            log.warning("archive_daily_sign customer=%s failed: %s", cid, exc)

    log.info(
        "archive_daily_sign %s..%s built=%d signed=%d uploaded=%d failed=%d",
        period_start.isoformat(),
        period_end.isoformat(),
        built,
        signed,
        uploaded,
        failed,
    )
    return {
        "period_start": period_start.isoformat(),
        "period_end": period_end.isoformat(),
        "customers": len(cids),
        "built": built,
        "signed": signed,
        "uploaded": uploaded,
        "failed": failed,
    }


# ---- session correlation (read-only, Mutlak Kural #5 evidence view) ---------
@celery_app.task(name="app.modules.workers.tasks.session_correlation_job")
def session_correlation_job(session_id: str) -> dict:
    from app.modules.sessions import correlation

    async def _go():
        async with WorkerSession() as db:
            return await correlation.correlate(db, guest_session_id=uuid.UUID(session_id))

    try:
        result = _run(_go())
        return result.model_dump(mode="json")
    except Exception as exc:  # noqa: BLE001
        log.exception("session_correlation_job failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---- firewall metadata sync (adapter pattern, Mutlak Kural #7) --------------
@celery_app.task(name="app.modules.workers.tasks.firewall_sync_job")
def firewall_sync_job(device_id: str) -> dict:
    """Mirror authoritative device info onto the Device row. Adapter-driven —
    no vendor logic lives here (Mutlak Kural #7)."""
    from app.modules.firewall_adapters import service as fw_service

    async def _go():
        async with WorkerSession() as db:
            return await fw_service.discover_device(
                db, uuid.UUID(device_id), _worker_scope()
            )

    try:
        return _run(_go())
    except Exception as exc:  # noqa: BLE001
        log.exception("firewall_sync_job device=%s failed: %s", device_id, exc)
        return {"ok": False, "error": str(exc)}


# ---- syslog normalization (stateless vendor parse, Mutlak Kural #7) ---------
@celery_app.task(name="app.modules.workers.tasks.syslog_parse_job")
def syslog_parse_job(vendor: str, raw_event: str) -> dict:
    """Normalize a raw syslog line through the vendor adapter. Stateless."""
    from app.modules.firewall_adapters import service as fw_service

    async def _go():
        return await fw_service.parse_syslog(vendor, raw_event)

    try:
        return _run(_go())
    except Exception as exc:  # noqa: BLE001
        log.exception("syslog_parse_job failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---- syslog trigger alerts (fire after record saved) -----------------------
@celery_app.task(name="app.modules.workers.tasks.trigger_syslog_alerts")
def trigger_syslog_alerts(record_id: str) -> dict:
    """Evaluate syslog triggers for a given record (async worker)."""
    async def _go():
        from app.modules.syslog.models import SyslogRecord
        async with WorkerSession() as db:
            record = await db.get(SyslogRecord, uuid.UUID(record_id))
            if not record:
                return {"ok": False, "error": "Kayit bulunamadi"}
            from app.modules.syslog.trigger_service import fire_triggers
            events = await fire_triggers(db, record)
            return {"record_id": record_id, "triggers_fired": len(events)}

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("trigger_syslog_alerts failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---- report generation (async worker) --------------------------------------
@celery_app.task(name="app.modules.workers.tasks.generate_report_sync")
def generate_report_sync(job_id: str) -> dict:
    """Generate a report for a ReportJob in the background."""
    async def _go():
        from app.modules.reports.scheduler_service import generate_report, send_report_email
        async with WorkerSession() as db:
            archive = await generate_report(db, uuid.UUID(job_id))
            if archive.status == "ready":
                await send_report_email(archive)
            return {
                "job_id": job_id,
                "archive_id": str(archive.id),
                "status": archive.status,
                "error": archive.error_message,
            }

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("generate_report_sync failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---- scheduled reports (beat task, hourly) ---------------------------------
@celery_app.task(name="app.modules.workers.tasks.send_scheduled_reports")
def send_scheduled_reports() -> dict:
    """Beat task: find all ReportJobs whose next_run_at <= now and run them."""
    async def _go():
        from datetime import timezone
        from app.modules.reports.models import ReportJob
        async with WorkerSession() as db:
            now = datetime.now(timezone.utc)
            res = await db.execute(
                select(ReportJob).where(
                    ReportJob.is_active.is_(True),
                    ReportJob.next_run_at <= now,
                )
            )
            jobs = list(res.scalars().all())
            results = []
            for job in jobs:
                try:
                    from app.modules.reports.scheduler_service import generate_report
                    archive = await generate_report(db, job.id)
                    if archive.status == "ready":
                        from app.modules.reports.scheduler_service import send_report_email
                        await send_report_email(archive)
                    results.append({"job_id": str(job.id), "status": archive.status})
                except Exception as exc:
                    log.warning("Scheduled report job=%s failed: %s", job.id, exc)
                    results.append({"job_id": str(job.id), "status": "failed", "error": str(exc)})
            return {"checked": len(jobs), "results": results}

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("send_scheduled_reports failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---- backup / restore tasks ----------------------------------------------------

@celery_app.task(name="app.modules.workers.tasks.run_full_backup")
def run_full_backup(backup_job_id: str) -> dict:
    """Full backup: DB + config + archives -> upload to MinIO."""
    async def _go():
        from app.modules.system.backup_service import (
            BackupJob, BS_COMPLETED, BS_FAILED,
            execute_db_backup, execute_config_backup, execute_archives_backup,
            upload_backup_file,
        )
        async with WorkerSession() as db:
            job = await db.get(BackupJob, uuid.UUID(backup_job_id))
            if not job:
                return {"ok": False, "error": "Yedek isi bulunamadi"}
            try:
                output_dir = settings.BACKUP_PATH
                backup_files = []
                db_path = execute_db_backup(output_dir, backup_job_id)
                backup_files.append(upload_backup_file(db_path, backup_job_id, "db"))
                cfg_path = execute_config_backup(output_dir)
                backup_files.append(upload_backup_file(cfg_path, backup_job_id, "config"))
                arch_path = execute_archives_backup(output_dir)
                backup_files.append(upload_backup_file(arch_path, backup_job_id, "archives"))
                job.status = BS_COMPLETED
                job.file_ref = ";".join(backup_files)
                job.completed_at = datetime.now(timezone.utc)
                await db.commit()
                return {"ok": True, "job_id": backup_job_id, "files": backup_files}
            except Exception as exc:
                job.status = BS_FAILED
                job.error_message = str(exc)
                job.completed_at = datetime.now(timezone.utc)
                await db.commit()
                log.exception("Full backup failed job=%s: %s", backup_job_id, exc)
                return {"ok": False, "error": str(exc)}

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("run_full_backup failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@celery_app.task(name="app.modules.workers.tasks.run_db_backup")
def run_db_backup(backup_job_id: str) -> dict:
    """Database-only backup."""
    async def _go():
        from app.modules.system.backup_service import (
            BackupJob, BS_COMPLETED, BS_FAILED,
            execute_db_backup, upload_backup_file,
        )
        async with WorkerSession() as db:
            job = await db.get(BackupJob, uuid.UUID(backup_job_id))
            if not job:
                return {"ok": False, "error": "Yedek isi bulunamadi"}
            try:
                output_dir = settings.BACKUP_PATH
                local_path = execute_db_backup(output_dir, backup_job_id)
                file_ref = upload_backup_file(local_path, backup_job_id, "db")
                job.status = BS_COMPLETED
                job.file_ref = file_ref
                job.completed_at = datetime.now(timezone.utc)
                await db.commit()
                return {"ok": True, "job_id": backup_job_id}
            except Exception as exc:
                job.status = BS_FAILED
                job.error_message = str(exc)
                job.completed_at = datetime.now(timezone.utc)
                await db.commit()
                return {"ok": False, "error": str(exc)}

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("run_db_backup failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@celery_app.task(name="app.modules.workers.tasks.run_config_backup")
def run_config_backup(backup_job_id: str) -> dict:
    """Configuration-only backup."""
    async def _go():
        from app.modules.system.backup_service import (
            BackupJob, BS_COMPLETED, BS_FAILED,
            execute_config_backup, upload_backup_file,
        )
        async with WorkerSession() as db:
            job = await db.get(BackupJob, uuid.UUID(backup_job_id))
            if not job:
                return {"ok": False, "error": "Yedek isi bulunamadi"}
            try:
                output_dir = settings.BACKUP_PATH
                local_path = execute_config_backup(output_dir)
                file_ref = upload_backup_file(local_path, backup_job_id, "config")
                job.status = BS_COMPLETED
                job.file_ref = file_ref
                job.completed_at = datetime.now(timezone.utc)
                await db.commit()
                return {"ok": True, "job_id": backup_job_id}
            except Exception as exc:
                job.status = BS_FAILED
                job.error_message = str(exc)
                job.completed_at = datetime.now(timezone.utc)
                await db.commit()
                log.exception("run_config_backup failed job=%s: %s", backup_job_id, exc)
                return {"ok": False, "error": str(exc)}

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("run_config_backup failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@celery_app.task(name="app.modules.workers.tasks.run_restore_backup")
def run_restore_backup(backup_job_id: str) -> dict:
    """Restore a completed DB/full backup back into PostgreSQL."""
    async def _go():
        from app.modules.system.backup_service import (
            BackupJob, BT_DB, BT_FULL,
            _download_from_minio, _run_pg_restore,
        )
        async with WorkerSession() as db:
            job = await db.get(BackupJob, uuid.UUID(backup_job_id))
            if not job:
                return {"ok": False, "error": "Yedek isi bulunamadi"}
            if job.type not in {BT_FULL, BT_DB}:
                return {"ok": False, "error": "Bu yedek tipi geri yukleme desteklemiyor"}
            if not job.file_ref:
                return {"ok": False, "error": "Bu yedegin dosyasi yok"}

            db_ref = job.file_ref.split(";", 1)[0].strip()
            if not db_ref:
                return {"ok": False, "error": "Yedek dosyasi bulunamadi"}

            restore_dir = settings.BACKUP_PATH
            os.makedirs(restore_dir, exist_ok=True)
            local_path = os.path.join(
                restore_dir,
                f"restore_{job.id}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.dump",
            )
            try:
                _download_from_minio(db_ref, local_path)
                _run_pg_restore(local_path)
                return {"ok": True, "job_id": backup_job_id, "restored_from": db_ref}
            except Exception as exc:
                log.exception("run_restore_backup failed job=%s: %s", backup_job_id, exc)
                return {"ok": False, "error": str(exc)}

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("run_restore_backup failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@celery_app.task(name="app.modules.workers.tasks.cleanup_old_backups")
def cleanup_old_backups(retention_days: int = 30) -> dict:
    """Remove backup records + files older than retention_days."""
    async def _go():
        from app.modules.system.backup_service import BackupJob
        async with WorkerSession() as db:
            cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
            res = await db.execute(
                select(BackupJob).where(
                    BackupJob.created_at < cutoff,
                    BackupJob.status.in_(["completed", "failed"]),
                )
            )
            jobs = list(res.scalars().all())
            count = len(jobs)
            for job in jobs:
                await db.delete(job)
            await db.commit()
            log.info("cleanup_old_backups: %d eski yedek temizlendi", count)
            return {"deleted": count}

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("cleanup_old_backups failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---- 5651 digital signing after archive build ---------------------------------


@celery_app.task(name="app.modules.workers.tasks.sign_archive_after_build")
def sign_archive_after_build(archive_id: str) -> dict:
    """Digitally sign an archive record after it has been built.

    Called by the archive build pipeline (or manually via admin trigger).
    Skips if KamuSM is not enabled in settings or config.
    """
    async def _go():
        from app.modules.logs_5651.signing_service import (
            get_kamusm_status,
            sign_archive_record,
        )

        async with WorkerSession() as db:
            archive = await db.get(ArchiveRecord, uuid.UUID(archive_id))
            if not archive:
                return {"ok": False, "error": "Arsiv kaydi bulunamadi"}

            cfg = await get_kamusm_status(db, archive.customer_id)
            if not cfg.is_configured and not settings.TUBITAK_KAMUSM_ENABLED:
                log.info(
                    "KamuSM yapilandirilmamis, imza atlaniyor archive=%s",
                    archive_id,
                )
                return {"ok": True, "signed": False, "reason": "KamuSM not configured"}

            if archive.signature_value:
                return {
                    "ok": True,
                    "signed": True,
                    "archive_id": archive_id,
                    "chain_seq": archive.chain_seq,
                    "note": "Zaten imzali",
                }

            result = await sign_archive_record(db, archive)
            await db.commit()
            return {
                "ok": True,
                "signed": True,
                "archive_id": archive_id,
                "chain_seq": result.chain_seq,
                "sign_method": result.sign_method,
                "certificate_serial": result.certificate_serial,
            }

    try:
        return _run(_go())
    except Exception as exc:
        log.exception("sign_archive_after_build archive=%s failed: %s", archive_id, exc)
        return {"ok": False, "error": str(exc)}


# ---- daily chain verification -------------------------------------------------


@celery_app.task(name="app.modules.workers.tasks.daily_chain_verification")
def daily_chain_verification() -> dict:
    """Daily verification of all customer hash chains.

    Runs every night (suggested beat schedule: 03:00 UTC).
    Verifies chain integrity for every customer that has archive records.
    Logs warnings for broken chains; notifies via audit log.

    This is the automated tamper-evidence sweep mandated by 5651 internal
    controls (Mutlak Kural #4 — regular chain audit).
    """
    from app.modules.logs_5651.verify_service import verify_chain_integrity

    async def _list_customers_with_archives():
        async with WorkerSession() as db:
            res = await db.execute(
                select(ArchiveRecord.customer_id).distinct()
            )
            return [cid for cid in res.scalars().all()]

    async def _verify_one(customer_id):
        async with WorkerSession() as db:
            return await verify_chain_integrity(db, customer_id)

    try:
        cids = _run(_list_customers_with_archives())
    except Exception as exc:
        log.exception("daily_chain_verification: customer list failed: %s", exc)
        return {"ok": False, "error": str(exc)}

    results = []
    for cid in cids:
        try:
            result = _run(_verify_one(cid))
            results.append({
                "customer_id": str(cid),
                "ok": result.ok,
                "total_records": result.total_records,
                "broken_at": result.broken_at,
            })
            if not result.ok:
                log.warning(
                    "Zincir dogrulama BASARISIZ customer=%s: %s",
                    cid, result.message,
                )
        except Exception as exc:
            log.exception("daily_chain_verification customer=%s failed: %s", cid, exc)
            results.append({"customer_id": str(cid), "ok": False, "error": str(exc)})

    broken = [r for r in results if not r.get("ok")]
    log.info(
        "daily_chain_verification: %d musteri kontrol edildi, "
        "%d zincir sorunlu",
        len(results),
        len(broken),
    )
    return {
        "checked_customers": len(results),
        "ok_count": len(results) - len(broken),
        "broken_count": len(broken),
        "results": results,
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }


# ---- ClickHouse Syslog Pipeline --------------------------------------------

@celery_app.task(bind=True, max_retries=3, default_retry_delay=30)
def syslog_flush_to_clickhouse(self) -> dict:
    """Ensure ClickHouse is reachable and schema exists for syslog search.

    The platform writes syslog records to ClickHouse at ingest time already;
    this periodic task is a readiness check plus schema bootstrap, not an
    outbox replay. If ClickHouse is offline, it skips cleanly and leaves the
    PostgreSQL catalog as the durable source of truth.
    """
    from app.adapters.clickhouse import ensure_schema

    try:
        asyncio.run(ensure_schema())
        return {"ok": True, "message": "ClickHouse schema ensured"}
    except Exception as exc:
        log.warning("ClickHouse flush skipped (CH may be offline): %s", exc)
        return {"ok": False, "message": str(exc)}


@celery_app.task(bind=True, max_retries=3, default_retry_delay=120)
def syslog_archive_daily(self) -> dict:
    """Create daily JSONL.zst archive from yesterday's ClickHouse data.

    1. ClickHouse'dan önceki günün verisini çek
    2. JSONL formatında serialize et
    3. zstd ile sıkıştır
    4. MinIO'ya yükle
    5. SHA-256 hash chain'e ekle
    6. Dijital imza at (KamuSM aktifse)
    7. PostgreSQL'de ArchiveIndex'e kaydet
    """
    from app.adapters.clickhouse import query_syslog
    from app.adapters.clickhouse import ensure_schema as ch_ensure
    from app.modules.logs_5651.archive_service import serialize_jsonl, content_hash, upload
    from app.modules.logs_5651.service import _chain_hash, _last_in_chain, GENESIS_HASH
    from app.modules.logs_5651.models import ArchiveRecord, ArchiveIndex, RECORD_SESSION_ARCHIVE
    from app.modules.logs_5651.signing_service import sign_archive_record
    from app.modules.workers.runtime import WorkerSession
    from app.core.config import settings

    yesterday = datetime.now(timezone.utc) - timedelta(days=1)
    day_start = yesterday.replace(hour=0, minute=0, second=0, microsecond=0)
    day_end = day_start + timedelta(days=1)

    try:
        asyncio.run(ch_ensure())
    except Exception:
        log.warning("ClickHouse unavailable, archive daily skipped")
        return {"ok": False, "message": "ClickHouse offline"}

    # Query active customers from PostgreSQL

    async def _run():
        async with WorkerSession() as db:
            from app.modules.customers.models import Customer
            stmt = select(Customer.id, Customer.name).where(Customer.is_active)
            r = await db.execute(stmt)
            customers = list(r.all())

        results = []
        for cid, cname in customers:
            try:
                # Step 1: ClickHouse'dan veriyi çek
                rows = await query_syslog(
                    str(cid),
                    from_time=day_start,
                    to_time=day_end,
                    limit=500000,
                )
                if not rows:
                    results.append({"customer_id": str(cid), "ok": True, "records": 0})
                    continue

                # Step 2: JSONL serialize + zstd compress
                jsonl_bytes = serialize_jsonl(rows)
                ch = content_hash(jsonl_bytes)

                # Step 3: MinIO'ya yükle
                async with WorkerSession() as db2:
                    ref = upload(jsonl_bytes, customer_id=cid, period_start=day_start)

                    # Step 4: Hash chain
                    last = await _last_in_chain(db2, cid, RECORD_SESSION_ARCHIVE)
                    prev_hash = last.curr_hash if last else GENESIS_HASH
                    period_key = f"{day_start.isoformat()}/{day_end.isoformat()}"
                    curr_hash = _chain_hash(prev_hash, ch, period_key, RECORD_SESSION_ARCHIVE)

                    # Step 5: ArchiveRecord (append-only)
                    record = ArchiveRecord(
                        customer_id=cid,
                        period_start=day_start,
                        period_end=day_end,
                        record_type=RECORD_SESSION_ARCHIVE,
                        chain_seq=(last.chain_seq + 1) if last else 1,
                        item_count=len(rows),
                        content_hash=ch,
                        content_ref=ref,
                        content_size=len(jsonl_bytes),
                        prev_hash=prev_hash,
                        curr_hash=curr_hash,
                        meta={"compression": "zstd", "source": "clickhouse_archive"},
                    )
                    db2.add(record)
                    await db2.flush()

                    # Step 6: ArchiveIndex (arama için)
                    ips = set()
                    macs = set()
                    users = set()
                    domains = set()
                    devices = set()
                    for row in rows:
                        if row.get("source_ip") and row["source_ip"] != "::":
                            ips.add(str(row["source_ip"]))
                        if row.get("dest_ip") and row["dest_ip"] != "::":
                            ips.add(str(row["dest_ip"]))
                        if row.get("mac"):
                            macs.add(str(row["mac"]))
                        if row.get("username"):
                            users.add(str(row["username"]))
                        if row.get("domain"):
                            domains.add(str(row["domain"]))
                        if row.get("device_id"):
                            devices.add(str(row["device_id"]))

                    idx = ArchiveIndex(
                        customer_id=cid,
                        period_start=day_start,
                        period_end=day_end,
                        record_count=len(rows),
                        file_ref=ref,
                        file_size=len(jsonl_bytes),
                        compression="zstd",
                        content_hash=ch,
                        prev_hash=prev_hash,
                        searchable_fields={
                            "ips": list(ips),
                            "macs": list(macs),
                            "users": list(users),
                            "domains": list(domains),
                            "devices": list(devices),
                        },
                    )
                    db2.add(idx)
                    await db2.commit()

                    # Step 7: Dijital imza (opsiyonel)
                    if settings.TUBITAK_KAMUSM_ENABLED:
                        try:
                            await sign_archive_record(db2, record)
                        except Exception as sign_err:
                            log.warning("Signing failed for %s: %s", cid, sign_err)

                    results.append({
                        "customer_id": str(cid),
                        "customer_name": str(cname),
                        "ok": True,
                        "records": len(rows),
                        "hash": ch,
                        "chain_seq": record.chain_seq,
                    })
            except Exception as exc:
                log.exception("Archive daily failed for customer %s: %s", cid, exc)
                results.append({"customer_id": str(cid), "ok": False, "error": str(exc)})

        return results

    res = asyncio.run(_run())
    ok_count = sum(1 for r in res if r.get("ok"))
    total_records = sum(r.get("records", 0) for r in res if r.get("ok"))
    log.info("syslog_archive_daily: %d/%d musteri, %d kayit", ok_count, len(res), total_records)
    return {"ok": ok_count > 0, "customers": ok_count, "total": len(res), "records": total_records, "results": res}


@celery_app.task(bind=True, max_retries=3, default_retry_delay=120)
def syslog_retention_enforce(self) -> dict:
    """Enforce 730-day retention on ClickHouse (TTL handles it automatically).

    ClickHouse TTL zaten 730 gün sonra otomatik siler. Bu task sadece
    loglama ve monitoring amaçlıdır.
    PostgreSQL'deki ArchiveIndex kayıtları silinmez (Mutlak Kural #4).
    """
    from app.adapters.clickhouse import _get_client

    try:
        c = _get_client()
        # ClickHouse TTL status
        result = c.query(
            "SELECT database, table, count() AS partitions, "
            "min(min_time) AS oldest, max(max_time) AS newest "
            "FROM system.parts WHERE active = 1 AND database = 'hotspot' "
            "GROUP BY database, table"
        )
        tables_status = [
            {
                "table": r[1],
                "partitions": r[2],
                "oldest": str(r[3]) if r[3] else None,
                "newest": str(r[4]) if r[4] else None,
            }
            for r in result.result_rows
        ] if result.result_rows else []

        log.info("syslog_retention_enforce: %d tablo, %d partition", len(tables_status), sum(t.get("partitions", 0) for t in tables_status))
        return {"ok": True, "tables": tables_status}
    except Exception as exc:
        log.warning("Retention enforce skipped (CH offline): %s", exc)
        return {"ok": False, "message": str(exc)}
