import hashlib
import json
import logging

log = logging.getLogger(__name__)

GENESIS_HASH = "0" * 64
RUN_ID = "RUN-20260727-001"


def _canonical_log(log: dict) -> str:
    return json.dumps(log, sort_keys=True, separators=(",", ":"))


def compute_chain_hash(
    logs: list[dict], prev_hash: str | None = None
) -> tuple[str, list[str]]:
    if not logs:
        return GENESIS_HASH, []

    prev = prev_hash or GENESIS_HASH
    intermediates: list[str] = []

    for log_entry in logs:
        canonical = _canonical_log(log_entry)
        h = hashlib.sha256()
        h.update(canonical.encode("utf-8"))
        h.update(prev.encode("utf-8"))
        curr = h.hexdigest()
        intermediates.append(curr)
        prev = curr

    return prev, intermediates


def verify_chain(
    logs: list[dict],
    intermediate_hashes: list[str],
    final_hash: str,
    prev_hash: str | None = None,
) -> bool:
    if not logs and not intermediate_hashes and final_hash == GENESIS_HASH:
        return True

    computed_final, computed_intermediates = compute_chain_hash(logs, prev_hash)

    if computed_final != final_hash:
        log.warning(
            "Chain verify: final_hash mismatch computed=%s expected=%s",
            computed_final[:16],
            final_hash[:16],
        )
        return False

    if len(computed_intermediates) != len(intermediate_hashes):
        log.warning(
            "Chain verify: length mismatch computed=%d expected=%d",
            len(computed_intermediates),
            len(intermediate_hashes),
        )
        return False

    for i, (c, e) in enumerate(zip(computed_intermediates, intermediate_hashes)):
        if c != e:
            log.warning(
                "Chain verify: hash mismatch at index %d computed=%s expected=%s",
                i,
                c[:16],
                e[:16],
            )
            return False

    return True
