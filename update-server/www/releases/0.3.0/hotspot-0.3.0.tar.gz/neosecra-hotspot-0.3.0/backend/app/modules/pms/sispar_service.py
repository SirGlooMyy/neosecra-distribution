"""Sispar PMS REST API integration."""
import logging
from datetime import date, datetime

import httpx

from app.modules.pms.demo import demo_or_fail
from app.modules.pms.schemas import PmsVerifyResult
from app.modules.pms.utils import normalize_turkish as _normalize_turkish

log = logging.getLogger(__name__)


async def _mock_verify(room_number: str, surname: str) -> dict:
    is_valid = room_number.strip().isdigit() and len(_normalize_turkish(surname)) >= 3
    return {
        "verified": is_valid,
        "guest_name": f"GUEST/{surname.upper()}" if is_valid else None,
        "check_in": date.today() if is_valid else None,
        "check_out": date(2026, 12, 31) if is_valid else None,
        "stay_status": "checked_in" if is_valid else "unknown",
    }


async def verify_guest(
    room_number: str,
    surname: str,
    pms_config: dict | None = None,
) -> PmsVerifyResult:
    pms_config = pms_config or {}
    room_clean = (room_number or "").strip()
    surname_clean = _normalize_turkish(surname or "")

    if not room_clean or not surname_clean:
        log.warning("[Sispar] Oda numarasi veya soyad bos")
        return PmsVerifyResult(verified=False, vendor="sispar", message="Oda numarasi ve soyad gerekli")

    base_url = (pms_config.get("host") or "").rstrip("/")
    api_key = pms_config.get("api_key", "")

    if not base_url:
        log.info("[Sispar] API yapilandirilmamis")
        return await demo_or_fail(
            vendor="sispar",
            room_number=room_clean,
            surname_or_birth=surname_clean,
            mock_fn=_mock_verify,
            missing_config_message="Sispar API yapilandirilmamis",
        )

    endpoint = f"{base_url}/api/misafir"
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    params = {"oda": room_clean, "soyad": surname_clean}

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(endpoint, params=params, headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                verified = data.get("basarili", False) or data.get("found", False)
                guest = data.get("ad") or data.get("guest_name", "")
                soyad = data.get("soyad") or data.get("surname", "")
                full_name = f"{guest} {soyad}".strip()
                log.info("[Sispar] Room=%s guest=%s verified=%s", room_clean, full_name, verified)
                return PmsVerifyResult(
                    verified=bool(verified),
                    guest_name=full_name or None,
                    check_in=_parse_date(data.get("giris_tarihi") or data.get("check_in")),
                    check_out=_parse_date(data.get("cikis_tarihi") or data.get("check_out")),
                    stay_status=data.get("durum") or data.get("status", "checked_in"),
                    vendor="sispar",
                )
            log.warning("[Sispar] HTTP %s: %s", resp.status_code, resp.text[:200])
            return PmsVerifyResult(
                verified=False,
                vendor="sispar",
                message=f"Sispar API HTTP {resp.status_code}",
            )
    except httpx.TimeoutException:
        log.warning("[Sispar] Zaman asimi: %s", endpoint)
        return PmsVerifyResult(verified=False, vendor="sispar", message="Sispar API zaman asimi")
    except httpx.HTTPStatusError as exc:
        log.warning("[Sispar] HTTP %s", exc.response.status_code)
        return PmsVerifyResult(verified=False, vendor="sispar", message=f"Sispar API HTTP hatasi: {exc.response.status_code}")
    except Exception as exc:
        log.error("[Sispar] Baglanti hatasi: %s", exc)
        return PmsVerifyResult(verified=False, vendor="sispar", message=f"Sispar API baglanti hatasi: {exc}")


def _parse_date(val) -> date | None:
    if val is None:
        return None
    if isinstance(val, date):
        return val
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y%m%d"):
        try:
            return datetime.strptime(str(val).strip(), fmt).date()
        except ValueError:
            continue
    return None
