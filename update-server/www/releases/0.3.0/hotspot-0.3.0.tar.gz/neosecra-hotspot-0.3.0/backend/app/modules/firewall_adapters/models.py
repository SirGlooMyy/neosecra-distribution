# SQLAlchemy models for firewall_adapters
