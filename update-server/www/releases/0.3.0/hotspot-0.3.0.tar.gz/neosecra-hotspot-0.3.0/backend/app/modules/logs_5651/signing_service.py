"""TUBITAK KamuSM digital signing service for 5651 archives.

Supports three signing methods:
  * kamusm    — remote API via TUBITAK KamuSM (https://kamusm.tubitak.gov.tr)
  * localfile — local certificate file (.p12/.pfx) via cryptography
  * pkcs11    — hardware token (PKCS#11) — stub, requires future integration

Per Mutlak Kural #3, signing passwords are encrypted at rest using
app.core.crypto (Fernet). The signing config lives in CustomerLicense.meta
under the "kamusm_config" key so each customer has independent signing
credentials. In explicit demo mode when no KamuSM is configured, a mock
signature is returned.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.crypto import decrypt, encrypt
from app.modules.audit.service import log_audit
from app.modules.licensing.models import CustomerLicense
from app.modules.logs_5651.models import (
    SIGN_METHOD_KAMUSM,
    SIGN_METHOD_LOCALFILE,
    SIGN_METHOD_PKCS11,
    ArchiveRecord,
)
from app.modules.logs_5651.schemas import KamuSmConfigOut, SignResult

log = logging.getLogger(__name__)

_CONFIG_KEY = "kamusm_config"
_SIGNATURE_ORIGIN_KAMUSM = "kamusm"
_SIGNATURE_ORIGIN_LOCALFILE = "localfile"
_SIGNATURE_ORIGIN_DEMO = "demo"


# ---- config helpers -----------------------------------------------------------


def _default_config() -> dict:
    return {
        "is_configured": False,
        "sign_method": SIGN_METHOD_KAMUSM,
        "kamusm_username": "",
        "kamusm_password_encrypted": "",
        "certificate_path": "",
        "certificate_password_encrypted": "",
        "certificate_serial": "",
        "certificate_issuer": "",
        "certificate_subject": "",
        "last_signed_at": None,
        "last_signed_archive_id": None,
        "last_signature_origin": None,
    }


async def _get_config(db: AsyncSession, customer_id: uuid.UUID) -> dict:
    res = await db.execute(
        select(CustomerLicense).where(CustomerLicense.customer_id == customer_id)
    )
    lic = res.scalar_one_or_none()
    if not lic:
        return _default_config()
    cfg = lic.meta.get(_CONFIG_KEY) or {}
    return {**_default_config(), **cfg}


async def _save_config(
    db: AsyncSession, customer_id: uuid.UUID, cfg: dict
) -> CustomerLicense:
    res = await db.execute(
        select(CustomerLicense).where(CustomerLicense.customer_id == customer_id)
    )
    lic = res.scalar_one_or_none()
    if lic is None:
        from app.modules.licensing.models import CustomerLicense as CL

        lic = CL(customer_id=customer_id, plan="default", meta={})
        db.add(lic)
        await db.flush()
    meta = dict(lic.meta or {})
    meta[_CONFIG_KEY] = cfg
    lic.meta = meta
    await db.flush()
    return lic


# ---- password encryption wrappers ---------------------------------------------


def _encrypt_signing_password(password: str) -> str:
    if not password:
        return ""
    return encrypt(password)


def _decrypt_signing_password(encrypted: str) -> str:
    if not encrypted:
        return ""
    return decrypt(encrypted)


# ---- mock signature for dev ---------------------------------------------------


def _mock_sign(content_hash: str) -> dict:
    """Dev-only: generate a mock signature when no KamuSM or cert is configured."""
    mock_sig_input = f"5651-mock-{content_hash}-{datetime.now(timezone.utc).isoformat()}"
    sig_bytes = hashlib.sha256(mock_sig_input.encode()).hexdigest().encode()
    return {
        "signature_value": base64.b64encode(sig_bytes).decode(),
        "signing_time": datetime.now(timezone.utc),
        "certificate_serial": "MOCK-DEV-SERTIFIKA-0001",
        "signature_origin": _SIGNATURE_ORIGIN_DEMO,
    }


def _demo_signature_or_raise(content_hash: str, reason: str) -> dict:
    """Return a demo signature only when explicit demo mode is enabled."""
    if settings.DEMO_MODE:
        log.info("%s; demo signature for hash=%s", reason, content_hash[:16])
        return _mock_sign(content_hash)
    raise RuntimeError(reason)


# ---- real KamuSM API call -----------------------------------------------------


async def _sign_kamusm_api(content_hash: str, username: str, password: str) -> dict:
    """POST to TUBITAK KamuSM signing API.

    In dev when the API URL is not reachable, falls back to mock.
    Production deployments MUST configure TUBITAK_KAMUSM_ENABLED=True and
    provide valid credentials.
    """
    if not settings.TUBITAK_KAMUSM_ENABLED:
        return _demo_signature_or_raise(
            content_hash,
            "KamuSM etkin değil ve demo modu kapalı",
        )

    import httpx  # lazy import — not a core dependency

    url = settings.TUBITAK_KAMUSM_API_URL
    payload = {
        "content_hash": content_hash,
        "username": username,
        "password": password,
        "algorithm": "SHA-256",
        "signature_format": "PKCS7",
    }
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return {
                "signature_value": data["signature_value"],
                "signing_time": datetime.fromisoformat(data["signing_time"]),
                "certificate_serial": data["certificate_serial"],
                "signature_origin": _SIGNATURE_ORIGIN_KAMUSM,
            }
    except Exception as exc:
        if settings.DEMO_MODE:
            log.warning("KamuSM API cagrisi basarisiz, demo fallback: %s", exc)
            return _mock_sign(content_hash)
        raise RuntimeError(f"KamuSM API cagrisi basarisiz: {exc}") from exc


# ---- local certificate signing ------------------------------------------------


def _sign_with_local_cert(
    content_hash: str, cert_path: str, key_password: str
) -> dict:
    """Sign content hash using a local PKCS#12 (.p12/.pfx) certificate file."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, rsa
        from cryptography.hazmat.primitives.serialization import pkcs12
    except ImportError:
        return _demo_signature_or_raise(
            content_hash,
            "cryptography kutuphanesi yok ve demo modu kapali",
        )

    with open(cert_path, "rb") as fh:
        p12_data = fh.read()

    private_key, certificate, additional_certs = pkcs12.load_key_and_certificates(
        p12_data, key_password.encode() if key_password else None
    )
    if private_key is None or certificate is None:
        raise ValueError("PKCS12 dosyasinda private key veya sertifika bulunamadi")

    if not isinstance(private_key, rsa.RSAPrivateKey):
        return _demo_signature_or_raise(
            content_hash,
            "Local cert RSA private key degil ve demo modu kapali",
        )

    signature = private_key.sign(
        content_hash.encode("utf-8"),
        padding.PKCS1v15(),
        hashes.SHA256(),
    )

    cert_serial = format(certificate.serial_number, "X")
    return {
        "signature_value": base64.b64encode(signature).decode(),
        "signing_time": datetime.now(timezone.utc),
        "certificate_serial": cert_serial,
        "signature_origin": _SIGNATURE_ORIGIN_LOCALFILE,
    }


# ---- verify signature ---------------------------------------------------------


def verify_signature(
    content_hash: str, signature_value: str, certificate_pem: str
) -> bool:
    """Verify a PKCS1v15 SHA-256 digital signature against the content hash.

    Args:
        content_hash: The sha256 hex string that was signed.
        signature_value: Base64-encoded signature bytes.
        certificate_pem: PEM-encoded X.509 certificate.

    Returns:
        True if signature is valid, False otherwise.
    """
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, rsa
        from cryptography.x509 import load_pem_x509_certificate
    except ImportError:
        log.error("cryptography kutuphanesi yok — imza dogrulama yapilamadi")
        return False

    try:
        cert = load_pem_x509_certificate(certificate_pem.encode())
        public_key = cert.public_key()
        if not isinstance(public_key, rsa.RSAPublicKey):
            log.warning("Sertifika RSA public key degil, imza dogrulanamadi")
            return False
        sig_bytes = base64.b64decode(signature_value)
        public_key.verify(
            sig_bytes,
            content_hash.encode("utf-8"),
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
        return True
    except Exception as exc:
        log.warning("Imza dogrulama basarisiz: %s", exc)
        return False


# ---- main API methods ---------------------------------------------------------


async def sign_with_kamusm(
    db: AsyncSession, content_hash: str, customer_id: uuid.UUID
) -> dict:
    """Sign a content hash using the customer's configured KamuSM settings.

    Reads signing config from CustomerLicense.meta.kamusm_config.
    Falls back to mock signature in dev.
    """
    cfg = await _get_config(db, customer_id)
    method = cfg.get("sign_method", SIGN_METHOD_KAMUSM)

    if method == SIGN_METHOD_LOCALFILE:
        cert_path = cfg.get("certificate_path") or settings.TUBITAK_CERTIFICATE_PATH
        cert_pass_enc = cfg.get("certificate_password_encrypted") or ""
        cert_pass = _decrypt_signing_password(cert_pass_enc) if cert_pass_enc else settings.TUBITAK_CERTIFICATE_PASSWORD
        if cert_path:
            return _sign_with_local_cert(content_hash, cert_path, cert_pass)
        return _demo_signature_or_raise(
            content_hash,
            "Local cert yolu yapilandirilmamis ve demo modu kapali",
        )

    if method == SIGN_METHOD_PKCS11:
        return _demo_signature_or_raise(
            content_hash,
            "PKCS#11 signing henuz desteklenmiyor ve demo modu kapali",
        )

    # default: kamusm
    username = cfg.get("kamusm_username") or settings.TUBITAK_KAMUSM_USERNAME
    pass_enc = cfg.get("kamusm_password_encrypted") or ""
    password = _decrypt_signing_password(pass_enc) if pass_enc else settings.TUBITAK_KAMUSM_PASSWORD
    return await _sign_kamusm_api(content_hash, username, password)


async def sign_archive_record(
    db: AsyncSession, archive: ArchiveRecord
) -> SignResult:
    """Digitally sign an ArchiveRecord using the customer's signing config.

    Updates the archive row with signature_value, signature_time,
    certificate_serial, and sign_method. Flushes but does not commit.
    Returns SignResult.
    """
    if archive.signature_value:
        log.warning("Arsiv %s zaten imzali, tekrar imzalanmiyor", archive.id)
        cfg = await _get_config(db, archive.customer_id)
        signature_origin = (archive.meta or {}).get("signature_origin")
        return SignResult(
            archive_id=archive.id,
            customer_id=archive.customer_id,
            sign_method=archive.sign_method or cfg.get("sign_method", SIGN_METHOD_KAMUSM),
            signature_value=archive.signature_value,
            signing_time=archive.signature_time or datetime.now(timezone.utc),
            certificate_serial=archive.certificate_serial or "",
            chain_seq=archive.chain_seq,
            signature_origin=signature_origin,
        )

    content_to_sign = f"{archive.curr_hash}:{archive.content_hash}:{archive.period_start.isoformat()}:{archive.period_end.isoformat()}"
    content_hash_for_sig = hashlib.sha256(content_to_sign.encode()).hexdigest()

    sig_result = await sign_with_kamusm(db, content_hash_for_sig, archive.customer_id)
    now = datetime.now(timezone.utc)

    archive.signature_value = sig_result["signature_value"]
    archive.signature_time = sig_result.get("signing_time") or now
    archive.certificate_serial = sig_result.get("certificate_serial", "")
    signature_origin = sig_result.get("signature_origin") or _SIGNATURE_ORIGIN_DEMO
    cfg = await _get_config(db, archive.customer_id)
    archive.sign_method = cfg.get("sign_method", SIGN_METHOD_KAMUSM)
    archive.meta = {**(archive.meta or {}), "signature_origin": signature_origin}
    await db.flush()

    cfg["last_signed_at"] = now.isoformat()
    cfg["last_signed_archive_id"] = str(archive.id)
    cfg["last_signature_origin"] = signature_origin
    await _save_config(db, archive.customer_id, cfg)

    await log_audit(
        db,
        "5651.archive_signed",
        "archive_record_5651",
        str(archive.id),
        None,
        details={
            "customer_id": str(archive.customer_id),
            "chain_seq": archive.chain_seq,
            "sign_method": archive.sign_method,
            "signature_origin": signature_origin,
            "certificate_serial": archive.certificate_serial,
        },
    )

    return SignResult(
        archive_id=archive.id,
        customer_id=archive.customer_id,
        sign_method=archive.sign_method or SIGN_METHOD_KAMUSM,
        signature_value=archive.signature_value,
        signing_time=archive.signature_time or now,
        certificate_serial=archive.certificate_serial or "",
        chain_seq=archive.chain_seq,
        signature_origin=signature_origin,
    )


async def update_kamusm_config(
    db: AsyncSession,
    customer_id: uuid.UUID,
    config_data: dict,
) -> KamuSmConfigOut:
    """Update the KamuSM signing configuration for a customer.

    Encrypts sensitive fields (password, certificate_password) before storage.
    """
    cfg = await _get_config(db, customer_id)

    cfg["sign_method"] = config_data.get("sign_method", cfg["sign_method"])
    cfg["certificate_serial"] = config_data.get("certificate_serial", cfg["certificate_serial"])
    cfg["certificate_issuer"] = config_data.get("certificate_issuer", cfg["certificate_issuer"])
    cfg["certificate_subject"] = config_data.get("certificate_subject", cfg["certificate_subject"])

    if config_data.get("kamusm_username"):
        cfg["kamusm_username"] = config_data["kamusm_username"]
    if config_data.get("kamusm_password"):
        cfg["kamusm_password_encrypted"] = _encrypt_signing_password(config_data["kamusm_password"])
    if config_data.get("certificate_path"):
        cfg["certificate_path"] = config_data["certificate_path"]
    if config_data.get("certificate_password"):
        cfg["certificate_password_encrypted"] = _encrypt_signing_password(config_data["certificate_password"])

    cfg["is_configured"] = bool(
        cfg.get("kamusm_username")
        or cfg.get("certificate_path")
        or settings.TUBITAK_KAMUSM_ENABLED
    )

    await _save_config(db, customer_id, cfg)
    await log_audit(
        db,
        "5651.sign_config_updated",
        "customer_license",
        str(customer_id),
        None,
        details={"sign_method": cfg["sign_method"], "is_configured": cfg["is_configured"]},
    )

    return await get_kamusm_status(db, customer_id)


async def get_kamusm_status(
    db: AsyncSession, customer_id: uuid.UUID
) -> KamuSmConfigOut:
    """Return masked KamuSM config status."""
    cfg = await _get_config(db, customer_id)
    last_signed = None
    if cfg.get("last_signed_at"):
        try:
            last_signed = datetime.fromisoformat(cfg["last_signed_at"])
        except (ValueError, TypeError):
            pass
    return KamuSmConfigOut(
        is_configured=cfg.get("is_configured", False),
        sign_method=cfg.get("sign_method"),
        certificate_serial=cfg.get("certificate_serial"),
        certificate_issuer=cfg.get("certificate_issuer"),
        certificate_subject=cfg.get("certificate_subject"),
        has_kamusm_username=bool(cfg.get("kamusm_username")),
        has_kamusm_password=bool(cfg.get("kamusm_password_encrypted")),
        has_certificate_path=bool(cfg.get("certificate_path")),
        last_signed_at=last_signed,
        last_signed_archive_id=cfg.get("last_signed_archive_id"),
        last_signature_origin=cfg.get("last_signature_origin"),
    )
