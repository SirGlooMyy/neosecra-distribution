"""pfSense / OPNsense adapter — pfSense REST API.

Supports the pfSense REST API (https://github.com/jaredhendrickson13/pfsense-api)
at /api/v1/. Auth via API key (X-API-Key header) or Basic auth.
OPNsense is supported via its own REST API at /api/.
"""
from __future__ import annotations

import re
import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class PfSenseAdapter(FirewallAdapter):
    vendor = "pfsense"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        token = config.api_token or ""
        username = config.api_username or "admin"
        self._is_opnsense = (config.extra or {}).get("opnsense", "false").lower() == "true"
        if self._is_opnsense:
            self._base_url = f"https://{host}:{port}/api"
        else:
            self._base_url = f"https://{host}:{port}/api/v1"
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if token:
            self._headers["X-API-Key"] = token
            self._headers["X-API-Secret"] = self.config.extra.get("pfsense_api_secret", "")
        else:
            import base64
            auth_str = base64.b64encode(f"{username}:{self.config.extra.get('password', 'pfsense')}".encode()).decode()
            self._headers["Authorization"] = f"Basic {auth_str}"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"pfSense {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    async def _opnsense_request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=self.config.verify_tls, timeout=timeout) as client:
            resp = await client.request(method, url, headers=self._headers, params=params, json=json)
        if resp.status_code >= 400:
            raise AdapterError(
                f"OPNsense {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        return resp.json()

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            external_captive_portal=True,
            radius_authentication=True,
            radius_accounting=True,
            active_session_query=True,
            authorize_guest_api=True,
            revoke_guest_api=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            data = await self._request("GET", "system/status")
            sys = data.get("data", data) if isinstance(data, dict) else data
            if isinstance(sys, dict):
                version = sys.get("version", sys.get("firmware", {}).get("version", "?"))
                return AdapterResult(
                    ok=True,
                    message=f"connected: pfSense {version}",
                    data={"version": version},
                )
            return AdapterResult(ok=True, message="connected", data=data)
        except (AdapterError, httpx.HTTPError):
            pass
        try:
            data = await self._opnsense_request("GET", "core/system/status")
            return AdapterResult(
                ok=True,
                message="connected: OPNsense",
                data=data,
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        data = await self._request("GET", "system/status")
        sys = data.get("data", data)
        return {
            "hostname": (sys if isinstance(sys, dict) else {}).get("hostname", ""),
            "model": (sys if isinstance(sys, dict) else {}).get("model", ""),
            "serial_number": (sys if isinstance(sys, dict) else {}).get("serial", ""),
            "firmware_version": (sys if isinstance(sys, dict) else {}).get("version", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "interface")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for iface in raw:
            results.append({
                "name": iface.get("name", "") if isinstance(iface, dict) else "",
                "ip": iface.get("ipaddr", "") if isinstance(iface, dict) else "",
                "type": iface.get("type", "") if isinstance(iface, dict) else "",
                "status": "up" if (iface if isinstance(iface, dict) else {}).get("status") == "up" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._request("GET", "services/captiveportal")
            raw = data.get("data", data)
            cp = raw if isinstance(raw, list) else [raw]
            zones = []
            for zone in cp:
                zones.append({
                    "name": zone.get("zone", "") if isinstance(zone, dict) else "",
                    "enabled": (zone if isinstance(zone, dict) else {}).get("enable", False),
                    "redirect_url": (zone if isinstance(zone, dict) else {}).get("redirecturl", ""),
                })
            return {"zones": zones}
        except AdapterError:
            return {"zones": []}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "diagnostics/tables")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for s in raw:
            results.append({
                "ip": s.get("ip", "") if isinstance(s, dict) else "",
                "user": s.get("user", "") if isinstance(s, dict) else "",
                "state": s.get("state", "") if isinstance(s, dict) else "",
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "diagnostics/arp_table")
        raw = data.get("data", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for entry in raw:
            results.append({
                "ip": entry.get("ip", "") if isinstance(entry, dict) else "",
                "mac": entry.get("mac", "") if isinstance(entry, dict) else "",
                "interface": entry.get("interface", "") if isinstance(entry, dict) else "",
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        alias_payload = {
            "alias": {
                "name": name,
                "type": "host",
                "address": ip,
                "detail": self._guest_comment(session),
            }
        }
        try:
            await self._request("POST", "firewall/alias", json=alias_payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"alias": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            await self._request("DELETE", f"firewall/alias/{name}")
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "pfsense", "raw": raw_event}
        m = re.search(r"filterlog\s+\d+,\d+,\d+,\d+,\d+,\d+,\d+,\d+,[^,]*,[^,]*,[^,]*,[^,]*,[^,]*,[^,]*,(?P<fields>.+)", line)
        if m:
            flds = m.group("fields").split(",")
            if len(flds) >= 9:
                parsed["action"] = flds[0]
                parsed["direction"] = flds[3]
                parsed["src_ip"] = flds[6]
                parsed["dst_ip"] = flds[7]
                parsed["src_port"] = flds[8] if len(flds) > 8 else ""
                parsed["dst_port"] = flds[9] if len(flds) > 9 else ""
                parsed["protocol"] = flds[4] if len(flds) > 4 else ""
                parsed["rule"] = flds[5] if len(flds) > 5 else ""
                return parsed
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("hostname")
        parsed["event_type"] = parsed.get("type") or parsed.get("facility")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        return parsed
