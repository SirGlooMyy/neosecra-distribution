"""DrayTek Vigor adapter — HTTP API / CGI interface.

Supports DrayTek Vigor series (VigorAP, VigorSwitch, VigorRouter) via
the built-in CGI-based API. Uses form-based auth with admin credentials.
"""
from __future__ import annotations

import shlex
from typing import Any

import httpx

from app.modules.firewall_adapters.base import (
    AdapterResult,
    ConnectionConfig,
    FirewallAdapter,
    FirewallCapabilities,
)


class AdapterError(RuntimeError):
    """TODO: implement vendor adapter methods."""


class DrayTekAdapter(FirewallAdapter):
    vendor = "draytek"

    def __init__(self, config: ConnectionConfig) -> None:
        super().__init__(config)
        port = config.api_port or 443
        host = config.api_host
        password = config.api_token or "admin"
        username = config.api_username or "admin"
        scheme = "https"
        self._base_url = f"{scheme}://{host}:{port}"
        self._session = httpx.AsyncClient(verify=config.verify_tls, timeout=30.0)
        self._auth = {"username": username, "password": password}

    async def _login(self) -> bool:
        try:
            resp = await self._session.post(
                f"{self._base_url}/cgi-bin/login",
                data=self._auth,
                follow_redirects=True,
            )
            return resp.status_code < 400 and len(resp.cookies) > 0
        except httpx.HTTPError:
            return False

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        url = f"{self._base_url}/{path.lstrip('/')}"
        try:
            resp = await self._session.request(method, url, params=params, data=data, timeout=timeout)
        except httpx.HTTPError as exc:
            raise AdapterError(f"DrayTek request failed: {exc}")
        if resp.status_code == 401:
            if await self._login():
                resp = await self._session.request(method, url, params=params, data=data, timeout=timeout)
            else:
                raise AdapterError("DrayTek login failed")
        if resp.status_code >= 400:
            raise AdapterError(
                f"DrayTek {method} {path} -> HTTP {resp.status_code}: {resp.text[:300]}"
            )
        try:
            return resp.json()
        except (ValueError, TypeError):
            return {"raw": resp.text}

    def get_capabilities(self) -> FirewallCapabilities:
        return FirewallCapabilities(
            radius_authentication=True,
            radius_accounting=True,
            mac_auth_bypass=True,
            syslog=True,
            api_health=True,
        )

    async def test_connection(self) -> AdapterResult:
        try:
            ok = await self._login()
            if not ok:
                return AdapterResult(ok=False, message="login failed")
            data = await self._request("GET", "cgi-bin/status")
            sys = data.get("system", data)
            model = sys.get("model", "?") if isinstance(sys, dict) else "?"
            return AdapterResult(
                ok=True,
                message=f"connected: DrayTek {model}",
                data={"model": model},
            )
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def get_device_info(self) -> dict[str, Any]:
        data = await self._request("GET", "cgi-bin/status")
        sys = data.get("system", data) if isinstance(data, dict) else data
        keys = ["hostname", "host_name", "name", "model"]
        hostname = ""
        for k in keys:
            v = (sys if isinstance(sys, dict) else {}).get(k)
            if v:
                hostname = v
                break
        return {
            "hostname": hostname,
            "model": (sys if isinstance(sys, dict) else {}).get("model", ""),
            "serial_number": (sys if isinstance(sys, dict) else {}).get("serial", ""),
            "firmware_version": (sys if isinstance(sys, dict) else {}).get("firmware", ""),
        }

    async def get_interfaces(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "cgi-bin/interface")
        raw = data.get("interfaces", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for iface in raw:
            results.append({
                "name": iface.get("name", ""),
                "ip": iface.get("ip", ""),
                "type": iface.get("type", ""),
                "status": "up" if iface.get("status") == "up" else "down",
            })
        return results

    async def get_captive_portal_config(self) -> dict[str, Any]:
        try:
            data = await self._request("GET", "cgi-bin/captive-portal")
            cp = data.get("captive_portal", data) if isinstance(data, dict) else data
            return {
                "enabled": (cp if isinstance(cp, dict) else {}).get("enabled", False),
                "redirect_url": (cp if isinstance(cp, dict) else {}).get("redirect_url", ""),
            }
        except AdapterError:
            return {"enabled": False}

    async def get_active_sessions(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "cgi-bin/sessions")
        raw = data.get("sessions", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for s in raw:
            results.append({
                "ip": s.get("ip", ""),
                "user": s.get("user", ""),
                "mac": s.get("mac", ""),
                "state": s.get("state", ""),
            })
        return results

    async def get_user_ip_mac_mapping(self) -> list[dict[str, Any]]:
        data = await self._request("GET", "cgi-bin/arp")
        raw = data.get("arp", []) if isinstance(data, dict) else data
        raw = raw if isinstance(raw, list) else []
        results: list[dict[str, Any]] = []
        for entry in raw:
            results.append({
                "ip": entry.get("ip", ""),
                "mac": entry.get("mac", ""),
                "interface": entry.get("interface", ""),
            })
        return results

    async def authorize_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        mac = session.get("mac", "")
        if not ip:
            return AdapterResult(ok=False, message="authorize_guest: ip required")
        name = f"hsess-{session.get('session_id', ip).split('-')[-1]}"
        policy = self._guest_policy(session)
        payload = {
            "name": name,
            "ip": ip,
            "mac": mac,
            "comment": self._guest_comment(session),
        }
        try:
            await self._request("POST", "cgi-bin/mac-filter/add", data=payload)
            return AdapterResult(ok=True, message=f"allowed {ip}", data={"entry": name, "policy": policy})
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def revoke_guest(self, session: dict[str, Any]) -> AdapterResult:
        ip = session.get("ip")
        name = f"hsess-{session.get('session_id', ip or '').split('-')[-1]}"
        try:
            await self._request("POST", "cgi-bin/mac-filter/delete", data={"name": name})
            return AdapterResult(ok=True, message=f"revoked {ip}")
        except (AdapterError, httpx.HTTPError) as exc:
            return AdapterResult(ok=False, message=str(exc))

    async def parse_syslog_event(self, raw_event: str) -> dict[str, Any]:
        line = raw_event.strip()
        if line.startswith("<"):
            gt = line.find(">")
            if gt != -1:
                line = line[gt + 1:]
        parsed: dict[str, Any] = {"vendor": "draytek", "raw": raw_event}
        try:
            for tok in shlex.split(line, posix=True):
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        except ValueError:
            for tok in line.split():
                if "=" in tok:
                    k, _, v = tok.partition("=")
                    parsed[k] = v
        parsed["device_name"] = parsed.get("devname") or parsed.get("host")
        parsed["event_type"] = parsed.get("type") or parsed.get("category")
        parsed["src_ip"] = parsed.get("srcip") or parsed.get("src")
        parsed["dst_ip"] = parsed.get("dstip") or parsed.get("dst")
        parsed["src_port"] = parsed.get("srcport") or parsed.get("sport")
        parsed["dst_port"] = parsed.get("dstport") or parsed.get("dport")
        parsed["action"] = parsed.get("action")
        return parsed
