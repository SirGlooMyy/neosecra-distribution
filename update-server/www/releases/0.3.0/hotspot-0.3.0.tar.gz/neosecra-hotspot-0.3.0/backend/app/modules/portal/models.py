"""PortalTemplate = the captive-portal landing page definition for a customer
(optionally overridden per location). Captive flow rendering lives in the
portal module's M4 flow layer; M3 stores the config + theme only.

Scope axis is customer (-> partner), matching the customers module. A template
with location_id == None is the customer-wide default.
"""
import uuid

from sqlalchemy import Boolean, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk

# Auth method the guest must complete before the session is authorized.
METHOD_SMS = "sms"
METHOD_TC = "tc"
METHOD_VOUCHER = "voucher"
METHOD_FREE = "free"
METHOD_RADIUS = "radius"
METHOD_PMS = "pms"
METHOD_WHATSAPP = "whatsapp"
METHOD_MEETING = "meeting"
METHOD_FOREIGNER = "foreigner"
METHOD_LOCAL = "local"
METHOD_LDAP = "ldap"
METHODS = (METHOD_SMS, METHOD_TC, METHOD_VOUCHER, METHOD_FREE, METHOD_RADIUS, METHOD_PMS, METHOD_WHATSAPP, METHOD_MEETING, METHOD_FOREIGNER, METHOD_LOCAL, METHOD_LDAP)


class PortalTemplate(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "portal_templates"

    customer_id: Mapped[uuid.UUID] = fk("customers", ondelete="RESTRICT")
    location_id: Mapped[uuid.UUID | None] = fk("locations", ondelete="RESTRICT", nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    method: Mapped[str] = mapped_column(String(20), default=METHOD_FREE, nullable=False, index=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # Visual config consumed by the renderer.
    theme: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    # Identity form field definitions ([{"name":"phone","type":"tel","required":true}, ...]).
    fields: Mapped[dict] = mapped_column(JSONB, default=list, nullable=False)
    success_message: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    terms_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    meta: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
