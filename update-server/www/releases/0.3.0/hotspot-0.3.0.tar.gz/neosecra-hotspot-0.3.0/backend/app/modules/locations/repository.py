# Repository/data access layer for locations
