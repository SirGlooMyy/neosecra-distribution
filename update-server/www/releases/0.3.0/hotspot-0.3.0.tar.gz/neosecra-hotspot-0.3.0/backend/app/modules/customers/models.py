"""Customer = the end organization buying the hotspot service.

partner_id is nullable: a customer may belong directly to the tenant
(operator's own sale) or under a partner/reseller.
"""
import uuid

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin, fk


class Customer(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "customers"

    tenant_id: Mapped[uuid.UUID] = fk("tenants", ondelete="RESTRICT")
    partner_id: Mapped[uuid.UUID | None] = fk("partners", ondelete="RESTRICT", nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    contact_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    contact_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    contact_phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
