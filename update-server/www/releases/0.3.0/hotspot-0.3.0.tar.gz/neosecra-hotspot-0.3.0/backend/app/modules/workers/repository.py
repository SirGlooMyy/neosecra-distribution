# Repository/data access layer for workers
