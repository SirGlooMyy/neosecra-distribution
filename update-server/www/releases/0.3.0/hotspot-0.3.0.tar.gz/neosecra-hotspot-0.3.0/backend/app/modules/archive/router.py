import logging
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.rbac import has_permission
from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.tenant import customer_in_scope, scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.archive.repository import get_chunk, list_chunks
from app.modules.archive.schemas import BuildResult, ChunkOut, VerifyResult
from app.modules.archive.service import (
    build_chunk_for_period,
    verify_chunk_integrity,
)

log = logging.getLogger(__name__)

router = APIRouter(prefix="/chunks", tags=["archive"])


def _require(user: User, permission: str) -> None:
    if not has_permission(user.role, permission):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


async def _require_customer_scope(
    db: AsyncSession, user: User, customer_id: uuid.UUID
) -> None:
    if not await customer_in_scope(db, scope_for(user), customer_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Musteri scope disinda")


async def _get_scoped_chunk(
    db: AsyncSession, user: User, chunk_id: uuid.UUID
):
    chunk = await get_chunk(db, chunk_id)
    if not chunk:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Chunk not found")
    await _require_customer_scope(db, user, chunk.customer_id)
    return chunk


@router.post("/build", response_model=BuildResult, status_code=status.HTTP_201_CREATED, summary="Build an archive chunk for a time period", description="Creates a new archive chunk covering the specified time period for the given customer. The chunk is built from session records and sealed with a hash chain link. Requires customer-level scope access.")
async def api_build_chunk(
    customer_id: uuid.UUID | None = Query(None),
    period_start: datetime = Query(...),
    period_end: datetime = Query(...),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "archive.write")
    if customer_id is None:
        customer_id = await resolve_installation_customer(db)
    await _require_customer_scope(db, user, customer_id)
    if period_end <= period_start:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="period_end must be after period_start",
        )
    result = await build_chunk_for_period(
        db, customer_id=customer_id, period_start=period_start, period_end=period_end
    )
    return result


@router.get("", response_model=list[ChunkOut], summary="List archive chunks for a customer", description="Returns all archive chunks for a given customer within the optional time range. Each chunk includes metadata, hash chain sequence, and storage location. Requires customer-level scope access.")
async def api_list_chunks(
    customer_id: uuid.UUID | None = Query(None),
    from_ts: datetime | None = Query(None),
    to_ts: datetime | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "archive.read")
    if customer_id is None:
        customer_id = await resolve_installation_customer(db)
    await _require_customer_scope(db, user, customer_id)
    chunks = await list_chunks(db, customer_id, from_ts, to_ts)
    return [ChunkOut.model_validate(c) for c in chunks]


@router.get("/{chunk_id}", response_model=ChunkOut, summary="Get a single archive chunk by ID", description="Fetches the metadata and hash chain information for a specific archive chunk. Includes sequence number, previous hash, and storage references.")
async def api_get_chunk(
    chunk_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "archive.read")
    chunk = await _get_scoped_chunk(db, user, chunk_id)
    return ChunkOut.model_validate(chunk)


@router.post("/{chunk_id}/verify", response_model=VerifyResult, summary="Verify the integrity of an archive chunk", description="Validates the cryptographic integrity of the specified archive chunk by checking its content hash and chain linkage. Returns verification status and any discrepancies found.")
async def api_verify_chunk(
    chunk_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "archive.read")
    await _get_scoped_chunk(db, user, chunk_id)
    result = await verify_chunk_integrity(db, chunk_id)
    return result


@router.get("/{chunk_id}/download", summary="Download an archive chunk payload", description="Downloads the payload of the specified archive chunk. Supports retrieval from MinIO storage, local filesystem, or inline JSON depending on the storage backend. Returns a redirect or direct file response.")
async def api_download_chunk(
    chunk_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "archive.read")
    chunk = await _get_scoped_chunk(db, user, chunk_id)

    if chunk.minio_object_key and chunk.minio_object_key.startswith("minio:"):
        from app.core.config import settings

        bucket_and_key = chunk.minio_object_key[len("minio:") :]
        bucket, _, key = bucket_and_key.partition("/")

        from minio import Minio

        client = Minio(
            settings.ARCHIVE_MINIO_ENDPOINT,
            access_key=settings.ARCHIVE_MINIO_ACCESS_KEY,
            secret_key=settings.ARCHIVE_MINIO_SECRET_KEY,
            secure=settings.ARCHIVE_MINIO_SECURE,
        )
        url = client.presigned_get_object(bucket, key, expires=3600)
        from fastapi.responses import RedirectResponse

        return RedirectResponse(url=url)

    if chunk.minio_object_key and chunk.minio_object_key.startswith("local:"):
        path = chunk.minio_object_key[len("local:") :]
        from fastapi.responses import FileResponse

        return FileResponse(
            path,
            media_type="application/json",
            filename=f"{chunk.id}.json",
        )

    chunk_json = (chunk.meta or {}).get("_chunk_json")
    if chunk_json:
        from fastapi.responses import PlainTextResponse

        return PlainTextResponse(
            chunk_json,
            media_type="application/json",
            headers={
                "Content-Disposition": f'attachment; filename="{chunk.id}.json"'
            },
        )

    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="Chunk payload not available",
    )
