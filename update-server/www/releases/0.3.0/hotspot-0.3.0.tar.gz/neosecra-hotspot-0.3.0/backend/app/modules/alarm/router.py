"""Alarm dashboard endpoints."""
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import get_db
from app.core.rbac import has_permission
from app.core.tenant import scope_for
from app.modules.alarm import service as alarm_service
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.alarm.models import AlarmEvent
from app.modules.syslog.models import SyslogTrigger

router = APIRouter()


def _require(user: User, perm: str) -> None:
    if not has_permission(user.role, perm):
        raise HTTPException(status_code=403, detail="Yetkisiz islem")


def _serialize_alarm_event(event: AlarmEvent, trigger_name: str | None = None) -> dict:
    return {
        "id": str(event.id),
        "customer_id": str(event.customer_id),
        "location_id": str(event.location_id) if event.location_id else None,
        "trigger_id": str(event.trigger_id) if event.trigger_id else None,
        "trigger_name": trigger_name or event.title,
        "severity": event.severity,
        "title": event.title,
        "message": event.message,
        "source": event.source,
        "acknowledged": bool(event.acknowledged),
        "acknowledged_at": event.acknowledged_at.isoformat() if event.acknowledged_at else None,
        "acknowledged_by": str(event.acknowledged_by) if event.acknowledged_by else None,
        "timestamp": event.event_time.isoformat(),
    }


@router.get("/events", summary="List alarm events with severity filter", description="Returns alarm events with optional severity filtering. Includes trigger name, severity, and acknowledgment status. Useful for monitoring and incident response. Requires the syslog.read permission.")
async def list_alarm_events(
    severity: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    q = (
        select(AlarmEvent, SyslogTrigger.name)
        .outerjoin(SyslogTrigger, AlarmEvent.trigger_id == SyslogTrigger.id)
        .order_by(AlarmEvent.event_time.desc())
        .offset(offset)
        .limit(limit)
    )
    if scope.customer_id:
        q = q.where(AlarmEvent.customer_id == scope.customer_id)
    if severity:
        q = q.where(AlarmEvent.severity == severity)
    res = await db.execute(q)
    return [_serialize_alarm_event(event, trigger_name) for event, trigger_name in res.all()]


@router.post("/events/{event_id}/acknowledge", summary="Acknowledge an alarm event", description="Marks the specified alarm event as acknowledged by the current user. Acknowledged alarms are considered reviewed and will be suppressed from active alerts. Requires the syslog.write permission.")
async def acknowledge_alarm(
    event_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.write")
    event = await alarm_service.acknowledge_alarm(db, event_id, user.id)
    return _serialize_alarm_event(event)


@router.get("/stats", summary="Get alarm event statistics", description="Returns aggregated statistics for alarm events including counts by severity, source, and acknowledgment status. Useful for dashboards and reporting. Requires the syslog.read permission.")
async def get_alarm_stats(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    return await alarm_service.get_alarm_stats(db, customer_id=scope.customer_id)


@router.get("/trend", summary="Get alarm event trend data over time", description="Returns alarm event trend data over the specified number of days showing frequency patterns. Useful for identifying recurring issues and seasonal patterns. Requires the syslog.read permission.")
async def get_alarm_trend(
    days: int = Query(7, ge=1, le=90),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user, "syslog.read")
    scope = scope_for(user)
    return await alarm_service.get_alarm_trend(db, customer_id=scope.customer_id, days=days)
