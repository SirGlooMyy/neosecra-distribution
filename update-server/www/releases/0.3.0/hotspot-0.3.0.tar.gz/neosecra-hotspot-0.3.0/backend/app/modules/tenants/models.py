"""Tenant = root organization (the MSSP/operator entity). Top of the
hierarchy: tenant -> partner -> customer -> location -> device.
"""
from sqlalchemy import Boolean, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.shared.types import UUIDPK, TimestampMixin, SoftDeleteMixin


class Tenant(Base, UUIDPK, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "tenants"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    slug: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    domain: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # is_root marks the platform operator itself (single root tenant in MVP).
    is_root: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # Demo tenants power sandbox/trial surfaces and should be explicitly labeled.
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
