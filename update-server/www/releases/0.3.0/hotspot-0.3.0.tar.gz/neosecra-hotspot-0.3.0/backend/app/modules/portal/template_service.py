"""Portal template definitions, preview rendering, and apply logic.

15 predefined templates across 7 categories, each with theme defaults.
"""
from __future__ import annotations

import uuid

from app.core.tenant import ScopeContext
from app.modules.portal.i18n_service import get_text
from app.modules.portal.models import PortalTemplate
from app.modules.portal.schemas import PortalTemplateUpdate, ThemeSpec
from app.modules.portal.service import update_template

# ── Predefined template definitions ──────────────────────────────────────────
PREDEFINED_TEMPLATES = [
    # 1. hotel_classic
    {
        "id": "hotel_classic",
        "name": "Hotel Classic",
        "category": "hotel",
        "description": "Elegant dark blue & gold design with serif typography",
        "default_theme": {
            "primary_color": "#1a237e",
            "secondary_color": "#d4af37",
            "bg_color": "#f5f0eb",
            "text_color": "#1a1a2e",
            "font_family": "'Playfair Display', 'Times New Roman', serif",
            "logo_style": "rounded",
            "button_style": "pill",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 2. hotel_modern
    {
        "id": "hotel_modern",
        "name": "Hotel Modern",
        "category": "hotel",
        "description": "Clean white & teal design with sans-serif font",
        "default_theme": {
            "primary_color": "#0d9488",
            "secondary_color": "#14b8a6",
            "bg_color": "#ffffff",
            "text_color": "#1e293b",
            "font_family": "'Inter', 'Segoe UI', sans-serif",
            "logo_style": "circle",
            "button_style": "rounded",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 3. hotel_resort
    {
        "id": "hotel_resort",
        "name": "Hotel Resort",
        "category": "hotel",
        "description": "Relaxed tropical green & beige palette",
        "default_theme": {
            "primary_color": "#2d6a4f",
            "secondary_color": "#95d5b2",
            "bg_color": "#fefae0",
            "text_color": "#1b4332",
            "font_family": "'Lato', 'Segoe UI', sans-serif",
            "logo_style": "rounded",
            "button_style": "rounded",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 4. residence_premium
    {
        "id": "residence_premium",
        "name": "Residence Premium",
        "category": "residence",
        "description": "Professional dark navy design",
        "default_theme": {
            "primary_color": "#111827",
            "secondary_color": "#374151",
            "bg_color": "#f8fafc",
            "text_color": "#0f172a",
            "font_family": "'Inter', 'Segoe UI', sans-serif",
            "logo_style": "square",
            "button_style": "sharp",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 5. residence_family
    {
        "id": "residence_family",
        "name": "Residence Family",
        "category": "residence",
        "description": "Warm orange & cream, friendly atmosphere",
        "default_theme": {
            "primary_color": "#ea580c",
            "secondary_color": "#f97316",
            "bg_color": "#fff7ed",
            "text_color": "#431407",
            "font_family": "'Nunito', 'Segoe UI', sans-serif",
            "logo_style": "circle",
            "button_style": "pill",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 6. school_campus
    {
        "id": "school_campus",
        "name": "School Campus",
        "category": "school",
        "description": "Academic blue & white design",
        "default_theme": {
            "primary_color": "#2563eb",
            "secondary_color": "#3b82f6",
            "bg_color": "#f0f9ff",
            "text_color": "#1e3a5f",
            "font_family": "'Source Sans Pro', 'Segoe UI', sans-serif",
            "logo_style": "square",
            "button_style": "rounded",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 7. school_library
    {
        "id": "school_library",
        "name": "School Library",
        "category": "school",
        "description": "Calm green & brown palette for quiet spaces",
        "default_theme": {
            "primary_color": "#4d7c0f",
            "secondary_color": "#65a30d",
            "bg_color": "#f7fee7",
            "text_color": "#1a2e05",
            "font_family": "'Merriweather', Georgia, serif",
            "logo_style": "rounded",
            "button_style": "rounded",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 8. cafe_cozy
    {
        "id": "cafe_cozy",
        "name": "Cafe Cozy",
        "category": "cafe",
        "description": "Warm brown coffee-themed design",
        "default_theme": {
            "primary_color": "#78350f",
            "secondary_color": "#92400e",
            "bg_color": "#fffbeb",
            "text_color": "#451a03",
            "font_family": "'Playfair Display', serif",
            "logo_style": "circle",
            "button_style": "pill",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 9. cafe_bistro
    {
        "id": "cafe_bistro",
        "name": "Cafe Bistro",
        "category": "cafe",
        "description": "Modern black, white & red bistro style",
        "default_theme": {
            "primary_color": "#dc2626",
            "secondary_color": "#1e293b",
            "bg_color": "#fafafa",
            "text_color": "#0f172a",
            "font_family": "'Montserrat', 'Segoe UI', sans-serif",
            "logo_style": "square",
            "button_style": "sharp",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 10. public_municipal
    {
        "id": "public_municipal",
        "name": "Public Municipal",
        "category": "public",
        "description": "Official blue & gray government design",
        "default_theme": {
            "primary_color": "#1e40af",
            "secondary_color": "#475569",
            "bg_color": "#f1f5f9",
            "text_color": "#0f172a",
            "font_family": "'Inter', 'Segoe UI', sans-serif",
            "logo_style": "square",
            "button_style": "sharp",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 11. public_library
    {
        "id": "public_library",
        "name": "Public Library",
        "category": "public",
        "description": "Nature-inspired green & beige",
        "default_theme": {
            "primary_color": "#15803d",
            "secondary_color": "#16a34a",
            "bg_color": "#f0fdf4",
            "text_color": "#052e16",
            "font_family": "'Merriweather', Georgia, serif",
            "logo_style": "rounded",
            "button_style": "rounded",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 12. mall_vibrant
    {
        "id": "mall_vibrant",
        "name": "Mall Vibrant",
        "category": "mall",
        "description": "Bright multi-color design for shopping centers",
        "default_theme": {
            "primary_color": "#7c3aed",
            "secondary_color": "#ec4899",
            "bg_color": "#faf5ff",
            "text_color": "#1e1b4b",
            "font_family": "'Poppins', 'Segoe UI', sans-serif",
            "logo_style": "circle",
            "button_style": "pill",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 13. mall_luxury
    {
        "id": "mall_luxury",
        "name": "Mall Luxury",
        "category": "mall",
        "description": "Premium gold & black design",
        "default_theme": {
            "primary_color": "#1a1a2e",
            "secondary_color": "#d4af37",
            "bg_color": "#0f0f1a",
            "text_color": "#f8f9fa",
            "font_family": "'Playfair Display', serif",
            "logo_style": "square",
            "button_style": "sharp",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 14. business_office
    {
        "id": "business_office",
        "name": "Business Office",
        "category": "business",
        "description": "Corporate gray & blue design",
        "default_theme": {
            "primary_color": "#334155",
            "secondary_color": "#3b82f6",
            "bg_color": "#f8fafc",
            "text_color": "#0f172a",
            "font_family": "'Inter', 'Segoe UI', sans-serif",
            "logo_style": "square",
            "button_style": "sharp",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
    # 15. business_cowork
    {
        "id": "business_cowork",
        "name": "Business Cowork",
        "category": "business",
        "description": "Modern white & purple startup style",
        "default_theme": {
            "primary_color": "#7c3aed",
            "secondary_color": "#a78bfa",
            "bg_color": "#ffffff",
            "text_color": "#1e1b4b",
            "font_family": "'Inter', 'Segoe UI', sans-serif",
            "logo_style": "circle",
            "button_style": "pill",
            "layout": "centered",
            "bg_image_url": "",
        },
    },
]

TEMPLATE_CATEGORIES = ["hotel", "residence", "school", "cafe", "public", "mall", "business"]

METHOD_FORM_FIELDS = {
    "sms": [{"name": "phone", "type": "tel", "required": True}],
    "tc": [{"name": "tc_number", "type": "text", "required": True}],
    "voucher": [{"name": "voucher_code", "type": "text", "required": True}],
    "free": [],
    "pms": [
        {"name": "room_number", "type": "text", "required": True},
        {"name": "surname", "type": "text", "required": True},
    ],
    "whatsapp": [{"name": "phone", "type": "tel", "required": True}],
    "meeting": [{"name": "voucher_code", "type": "text", "required": True}],
    "foreigner": [
        {"name": "passport_number", "type": "text", "required": True},
        {"name": "full_name", "type": "text", "required": True},
        {"name": "country", "type": "text", "required": True},
    ],
    "local": [
        {"name": "username", "type": "text", "required": True},
        {"name": "password", "type": "password", "required": True},
    ],
    "ldap": [
        {"name": "username", "type": "text", "required": True},
        {"name": "password", "type": "password", "required": True},
    ],
}


def get_available_templates() -> list[dict]:
    """Return all 15 predefined template definitions."""
    return list(PREDEFINED_TEMPLATES)


def get_template_by_id(template_id: str) -> dict | None:
    """Get a single predefined template by its id."""
    for t in PREDEFINED_TEMPLATES:
        if t["id"] == template_id:
            return t
    return None


def render_preview_html(template_id: str, method: str = "sms", lang: str = "tr") -> str:
    """Generate a complete HTML preview for a template and auth method.

    The returned HTML string can be rendered in an iframe.
    """
    tmpl = get_template_by_id(template_id)
    if not tmpl:
        return "<html><body><p>Template not found</p></body></html>"

    theme = tmpl["default_theme"]
    primary = theme["primary_color"]
    bg = theme["bg_color"]
    text_color = theme["text_color"]
    font = theme["font_family"]
    btn_style = theme["button_style"]

    radius = "9999px" if btn_style == "pill" else ("12px" if btn_style == "rounded" else "4px")

    def t(key):
        return get_text(key, lang)

    method_title = t(f"method_{method}") if method != "tc" else t("method_tc")

    fields_html = ""
    field_defs = METHOD_FORM_FIELDS.get(method, [])
    for fdef in field_defs:
        placeholder_key = f"placeholder_{fdef['name']}"
        ph = t(placeholder_key)
        fields_html += f"""
        <div class="field">
          <label for="{fdef['name']}">{ph}</label>
          <input type="{fdef['type']}" id="{fdef['name']}" placeholder="{ph}" />
        </div>"""

    logo_char = tmpl["name"][0].upper()

    return f"""<!DOCTYPE html>
<html lang="{lang}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{
      font-family: {font};
      background: {bg};
      color: {text_color};
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }}
    .card {{
      background: rgba(255,255,255,0.85);
      backdrop-filter: blur(12px);
      border-radius: 24px;
      padding: 32px 24px;
      max-width: 380px;
      width: 100%;
      box-shadow: 0 8px 32px rgba(0,0,0,0.08);
      text-align: center;
    }}
    .logo {{
      width: 48px; height: 48px;
      background: {primary};
      color: #fff;
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 22px; font-weight: 700;
      margin: 0 auto 12px;
    }}
    h1 {{ font-size: 18px; font-weight: 700; margin-bottom: 4px; }}
    p.sub {{ font-size: 13px; opacity: 0.7; margin-bottom: 20px; }}
    .field {{ margin-bottom: 12px; text-align: left; }}
    .field label {{ display: block; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; opacity: 0.6; margin-bottom: 4px; }}
    .field input {{
      width: 100%; padding: 10px 12px; font-size: 14px;
      border: 1.5px solid rgba(0,0,0,0.08); border-radius: 10px;
      background: rgba(255,255,255,0.9);
      outline: none; transition: border-color 0.2s;
      font-family: inherit;
    }}
    .field input:focus {{ border-color: {primary}; }}
    .btn {{
      width: 100%; padding: 12px;
      background: {primary}; color: #fff;
      border: none; border-radius: {radius};
      font-size: 15px; font-weight: 600;
      cursor: pointer; transition: opacity 0.2s;
      font-family: inherit;
    }}
    .btn:hover {{ opacity: 0.9; }}
    .terms {{ display: flex; align-items: flex-start; gap: 8px; margin: 16px 0; font-size: 11px; text-align: left; opacity: 0.6; }}
    .terms input {{ margin-top: 2px; }}
    .footer {{ font-size: 11px; opacity: 0.45; margin-top: 12px; }}
    .badge {{
      display: inline-block; font-size: 9px; font-weight: 700; letter-spacing: 1px;
      text-transform: uppercase; padding: 4px 10px; border-radius: 999px;
      background: {primary}14; color: {primary}; margin-bottom: 12px;
    }}
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">{logo_char}</div>
    <span class="badge">{tmpl['category']}</span>
    <h1>{t('welcome_title')}</h1>
    <p class="sub">{t('welcome_description')}</p>
    <div class="method-label" style="font-size:12px;font-weight:600;margin-bottom:12px;color:{primary}">{method_title}</div>
    {fields_html}
    <div class="terms">
      <input type="checkbox" checked />
      <span>{t('terms_text')}</span>
    </div>
    <button class="btn">{t('btn_connect')}</button>
    <p class="footer">{t('support_text')}</p>
  </div>
</body>
</html>"""


async def apply_template_to_portal(
    db,
    portal_template_id: uuid.UUID,
    predefined_template_id: str,
    scope: ScopeContext,
    actor_id: uuid.UUID,
    request=None,
) -> PortalTemplate:
    """Apply a predefined template's theme and fields to a PortalTemplate."""
    tmpl_def = get_template_by_id(predefined_template_id)
    if not tmpl_def:
        raise ValueError(f"Predefined template '{predefined_template_id}' not found")

    theme = dict(tmpl_def["default_theme"])
    theme["title"] = tmpl_def["name"]

    update_data = {
        "theme": ThemeSpec(**theme),
        "meta": {
            "applied_predefined_template_id": predefined_template_id,
            "applied_predefined_template_name": tmpl_def["name"],
        },
    }

    result = await update_template(
        db,
        portal_template_id,
        PortalTemplateUpdate(**update_data),
        scope,
        actor_id,
        request,
        revision_action="applied_template",
    )
    return result
