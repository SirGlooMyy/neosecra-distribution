import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.installation import resolve_installation_customer
from app.core.rbac import has_permission
from app.core.tenant import customer_in_scope, scope_for
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.modules.search import service
from app.modules.search.schemas import (
    CorrelateResponse,
    FacetResult,
    LogSearchParams,
    LogSearchResponse,
    SearchQuery,
    SearchResult,
    SearchViewCreate,
    SearchViewOut,
    SearchViewUpdate,
)

router = APIRouter()

_FIREWALL_SEVERITY_MAP = {
    "emergency": 0,
    "alert": 1,
    "critical": 2,
    "error": 3,
    "warning": 4,
    "notice": 5,
    "info": 6,
    "debug": 7,
}


def _require(role: str, perm: str) -> None:
    if not has_permission(role, perm):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Yetkisiz islem")


def _parse_iso_datetime(value: str | None):
    from datetime import datetime

    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _build_firewall_logs_query(
    *,
    customer_id: str,
    vendor: str | None,
    severity: str | None,
    search: str | None,
    from_time: str | None,
    to_time: str | None,
    correlation_window_minutes: int,
    page: int,
    page_size: int,
) -> SearchQuery:
    sev_num = _FIREWALL_SEVERITY_MAP.get((severity or "").lower())
    return SearchQuery(
        customer_id=customer_id,
        q=search,
        vendor=vendor,
        from_time=_parse_iso_datetime(from_time),
        to_time=_parse_iso_datetime(to_time),
        severity_min=sev_num,
        severity_max=sev_num,
        correlation_window_minutes=correlation_window_minutes,
        limit=page_size,
        offset=(page - 1) * page_size,
    )


@router.get("/search/syslog", response_model=SearchResult, summary="Search syslog records with multiple filters", description="Searches syslog records using a rich set of filters including source/destination IP, MAC address, username, vendor, severity range, and time window. Results are scoped to the user's tenant. Requires a valid access token.")
async def search_syslog(
    customer_id: uuid.UUID | None = Query(None),
    q: str | None = Query(None),
    vendor: str | None = Query(None),
    from_time: str | None = Query(None),
    to_time: str | None = Query(None),
    source_ip: str | None = Query(None),
    dest_ip: str | None = Query(None),
    mac: str | None = Query(None),
    username: str | None = Query(None),
    domain: str | None = Query(None),
    application: str | None = Query(None),
    action: str | None = Query(None),
    device_id: str | None = Query(None),
    location_id: str | None = Query(None),
    severity_min: int | None = Query(None, ge=0, le=8),
    severity_max: int | None = Query(None, ge=0, le=8),
    hostname: str | None = Query(None),
    correlation_window_minutes: int = Query(15, ge=1, le=120),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    scope = scope_for(user)
    requested = customer_id or scope.customer_id
    if requested is None and scope.level.value == "global":
        requested = await resolve_installation_customer(db)
    cid = str(requested) if requested else None
    if not cid:
        raise HTTPException(status_code=400, detail="customer_id gerekli")
    # A partner/customer/location user may only select a customer inside its
    # resolved tenant scope.  Without this check the ClickHouse/archive query
    # would trust an arbitrary query-string customer_id.
    try:
        requested_customer_id = uuid.UUID(cid)
    except ValueError:
        raise HTTPException(status_code=400, detail="Gecersiz customer_id")
    if not await customer_in_scope(db, scope, requested_customer_id):
        raise HTTPException(status_code=403, detail="Musteri scope disinda")

    query = SearchQuery(
        customer_id=cid, q=q, vendor=vendor, source_ip=source_ip, dest_ip=dest_ip,
        mac=mac, username=username, domain=domain, application=application,
        action=action, device_id=device_id, location_id=location_id,
        severity_min=severity_min, severity_max=severity_max,
        hostname=hostname, correlation_window_minutes=correlation_window_minutes,
        limit=limit, offset=offset,
    )
    return await service.search_syslog(db, scope, query)


@router.get("/search/views", response_model=list[SearchViewOut], summary="List saved search views for the current user", description="Returns all saved search views configured by the authenticated user. Views store filter presets for quick access to common searches. Requires the log.read permission.")
async def list_search_views(
    surface: str = Query("firewall_logs"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user.role, "log.read")
    return await service.list_search_views(db, user_id=user.id, surface=surface)


@router.post("/search/views", response_model=SearchViewOut, status_code=status.HTTP_201_CREATED, summary="Create a saved search view", description="Creates a new saved search view with filter configuration for the current user. Saved views allow quick recall of frequently used log search filters. Requires the log.read permission.")
async def create_search_view(
    body: SearchViewCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user.role, "log.read")
    return await service.create_search_view(db, body=body, user_id=user.id)


@router.put("/search/views/{view_id}", response_model=SearchViewOut, summary="Update a saved search view", description="Updates the filter configuration of an existing saved search view. Only the owning user can modify their views. Requires the log.read permission.")
async def update_search_view(
    view_id: uuid.UUID,
    body: SearchViewUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user.role, "log.read")
    return await service.update_search_view(db, view_id=view_id, body=body, user_id=user.id)


@router.delete("/search/views/{view_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete a saved search view", description="Permanently removes the specified saved search view. This action cannot be undone. Requires the log.read permission.")
async def delete_search_view(
    view_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require(user.role, "log.read")
    await service.delete_search_view(db, view_id=view_id, user_id=user.id)


# ──────────────────────────────────────────────
# Sprint 07b — Log Search API
# ──────────────────────────────────────────────


@router.get("/logs/search", response_model=LogSearchResponse, summary="Search firewall logs with advanced filters", description="Searches firewall log entries using comprehensive filters such as vendor, log type, severity, action, IP addresses, ports, and protocol. Supports time window and pagination. Requires a valid access token.")
async def logs_search(
    vendor: str | None = Query(None),
    log_type: str | None = Query(None),
    severity: str | None = Query(None),
    action: str | None = Query(None),
    src_ip: str | None = Query(None),
    dst_ip: str | None = Query(None),
    src_port: int | None = Query(None),
    dst_port: int | None = Query(None),
    user: str | None = Query(None),
    device_id: uuid.UUID | None = Query(None),
    location_id: uuid.UUID | None = Query(None),
    policyid: int | None = Query(None),
    service_name: str | None = Query(None, alias="service"),
    proto: str | None = Query(None),
    q: str | None = Query(None),
    from_time: str | None = Query(None, alias="from"),
    to_time: str | None = Query(None, alias="to"),
    time_window: str | None = Query(None),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    user_obj: User = Depends(get_current_user),
):
    filters = LogSearchParams(
        vendor=vendor,
        log_type=log_type,
        severity=severity,
        action=action,
        src_ip=src_ip,
        dst_ip=dst_ip,
        src_port=src_port,
        dst_port=dst_port,
        user=user,
        device_id=str(device_id) if device_id else None,
        location_id=str(location_id) if location_id else None,
        policyid=policyid,
        service=service_name,
        proto=proto,
        q=q,
        from_time=_parse_iso_datetime(from_time),
        to_time=_parse_iso_datetime(to_time),
        time_window=time_window,
        limit=limit,
        offset=offset,
    )
    return await service.search_firewall_logs(db, user_obj, filters)


@router.get("/logs/facets", response_model=FacetResult, summary="Get firewall log facet aggregations", description="Returns facet (aggregation) data for firewall logs based on the provided filters. Useful for building filter dropdowns and visualizations in the log analysis UI. Requires a valid access token.")
async def logs_facets(
    vendor: str | None = Query(None),
    log_type: str | None = Query(None),
    severity: str | None = Query(None),
    action: str | None = Query(None),
    src_ip: str | None = Query(None),
    dst_ip: str | None = Query(None),
    src_port: int | None = Query(None),
    dst_port: int | None = Query(None),
    user: str | None = Query(None),
    device_id: uuid.UUID | None = Query(None),
    location_id: uuid.UUID | None = Query(None),
    policyid: int | None = Query(None),
    service_name: str | None = Query(None, alias="service"),
    proto: str | None = Query(None),
    q: str | None = Query(None),
    from_time: str | None = Query(None, alias="from"),
    to_time: str | None = Query(None, alias="to"),
    time_window: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user_obj: User = Depends(get_current_user),
):
    filters = LogSearchParams(
        vendor=vendor,
        log_type=log_type,
        severity=severity,
        action=action,
        src_ip=src_ip,
        dst_ip=dst_ip,
        src_port=src_port,
        dst_port=dst_port,
        user=user,
        device_id=str(device_id) if device_id else None,
        location_id=str(location_id) if location_id else None,
        policyid=policyid,
        service=service_name,
        proto=proto,
        q=q,
        from_time=_parse_iso_datetime(from_time),
        to_time=_parse_iso_datetime(to_time),
        time_window=time_window,
    )
    return await service.get_facets(db, user_obj, filters)


@router.get("/logs/correlate", response_model=CorrelateResponse, summary="Correlate log data for a specific session", description="Returns correlated log entries across syslog, RADIUS, and firewall sources for the specified session ID. Useful for security investigations and audit compliance. Requires a valid access token.")
async def logs_correlate(
    session_id: str = Query(...),
    db: AsyncSession = Depends(get_db),
    user_obj: User = Depends(get_current_user),
):
    return await service.correlate_session(db, user_obj, session_id)


@router.get("/logs/export", summary="Export firewall logs in CSV or JSONL format", description="Exports firewall log entries matching the provided filters. Supports CSV and JSONL output formats for external analysis and reporting. Returns a downloadable file. Requires a valid access token.")
async def logs_export(
    fmt: str = Query("csv", alias="format"),
    vendor: str | None = Query(None),
    log_type: str | None = Query(None),
    severity: str | None = Query(None),
    action: str | None = Query(None),
    src_ip: str | None = Query(None),
    dst_ip: str | None = Query(None),
    src_port: int | None = Query(None),
    dst_port: int | None = Query(None),
    user: str | None = Query(None),
    device_id: uuid.UUID | None = Query(None),
    location_id: uuid.UUID | None = Query(None),
    policyid: int | None = Query(None),
    service_name: str | None = Query(None, alias="service"),
    proto: str | None = Query(None),
    q: str | None = Query(None),
    from_time: str | None = Query(None, alias="from"),
    to_time: str | None = Query(None, alias="to"),
    time_window: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user_obj: User = Depends(get_current_user),
):
    if fmt not in ("csv", "jsonl"):
        raise HTTPException(status_code=400, detail="format must be 'csv' or 'jsonl'")
    filters = LogSearchParams(
        vendor=vendor,
        log_type=log_type,
        severity=severity,
        action=action,
        src_ip=src_ip,
        dst_ip=dst_ip,
        src_port=src_port,
        dst_port=dst_port,
        user=user,
        device_id=str(device_id) if device_id else None,
        location_id=str(location_id) if location_id else None,
        policyid=policyid,
        service=service_name,
        proto=proto,
        q=q,
        from_time=_parse_iso_datetime(from_time),
        to_time=_parse_iso_datetime(to_time),
        time_window=time_window,
    )
    stream, filename = await service.export_firewall_logs(db, user_obj, filters, fmt=fmt)
    media = "text/csv" if fmt == "csv" else "application/x-ndjson"
    return StreamingResponse(
        stream,
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/firewall-logs", response_model=list, summary="Query firewall logs with pagination and correlation", description="Queries firewall log entries with vendor, severity, and time filters. Results include correlation grouping and severity display names. Supports pagination for large result sets.")
async def firewall_logs(
    vendor: str | None = Query(None),
    severity: str | None = Query(None),
    search: str | None = Query(None),
    from_time: str | None = Query(None, alias="from"),
    to_time: str | None = Query(None, alias="to"),
    correlation_window_minutes: int = Query(15, ge=1, le=120),
    page: int = Query(1, ge=1),
    page_size: int = Query(15, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    scope = scope_for(user)
    requested = scope.customer_id
    if requested is None and scope.level.value == "global":
        requested = await resolve_installation_customer(db)
    cid = str(requested) if requested else None
    if not cid:
        return []
    query = _build_firewall_logs_query(
        customer_id=cid,
        vendor=vendor,
        severity=severity,
        search=search,
        from_time=from_time,
        to_time=to_time,
        correlation_window_minutes=correlation_window_minutes,
        page=page,
        page_size=page_size,
    )

    res = await service.search_syslog(db, scope, query)
    correlation_lookup = {
        item.correlation_id: item for item in res.correlation_summary
    }

    severity_names = {value: key for key, value in _FIREWALL_SEVERITY_MAP.items()}

    formatted_hits = []
    for hit in res.hits:
        corr = correlation_lookup.get(hit.correlation_id or "")
        formatted_hits.append({
            "id": hit.session_id or str(uuid.uuid4()),
            "timestamp": hit.timestamp,
            "vendor": service.infer_vendor_display_name(hit, fallback=vendor),
            "severity": severity_names.get(hit.severity, "info"),
            "hostname": hit.hostname or "fortigate-fw",
            "message": hit.message,
            "source_ip": hit.source_ip or "0.0.0.0",
            "raw": hit.message,
            "source": hit.source,
            "correlation_id": hit.correlation_id,
            "correlation_type": hit.correlation_type,
            "correlation_reason": hit.correlation_reason,
            "correlation_group_size": hit.correlation_group_size or (corr.hit_count if corr else None),
        })
    return formatted_hits


@router.get("/firewall-logs/export", summary="Export firewall logs as a ZIP bundle", description="Exports matching firewall log entries packaged as a downloadable ZIP bundle with metadata. Suitable for offline analysis and audit evidence preservation. Supports the same filters as the firewall-logs query endpoint.")
async def export_firewall_logs(
    vendor: str | None = Query(None),
    severity: str | None = Query(None),
    search: str | None = Query(None),
    from_time: str | None = Query(None, alias="from"),
    to_time: str | None = Query(None, alias="to"),
    correlation_window_minutes: int = Query(15, ge=1, le=120),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    scope = scope_for(user)
    requested = scope.customer_id
    if requested is None and scope.level.value == "global":
        requested = await resolve_installation_customer(db)
    cid = str(requested) if requested else None
    if not cid:
        return StreamingResponse(iter([b""]), media_type="application/zip", headers={"Content-Disposition": 'attachment; filename="firewall-logs-export.zip"'})

    query = _build_firewall_logs_query(
        customer_id=cid,
        vendor=vendor,
        severity=severity,
        search=search,
        from_time=from_time,
        to_time=to_time,
        correlation_window_minutes=correlation_window_minutes,
        page=1,
        page_size=5000,
    )
    result = await service.search_syslog(db, scope, query)
    bundle, filename = service.build_firewall_logs_export_bundle(
        result,
        query,
        context={
            "vendor": vendor or "",
            "severity": severity or "",
            "search": search or "",
            "from": from_time or "",
            "to": to_time or "",
            "correlation_window_minutes": correlation_window_minutes,
            "page_size": 5000,
        },
    )
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return StreamingResponse(iter([bundle]), media_type="application/zip", headers=headers)
