"""Apple iOS/macOS Captive Portal Detection Endpoints.

Apple, Google, and Microsoft devices probe for captive portal presence by
fetching well-known URLs. If the device receives the expected response, it
assumes the network has internet access. If it receives a redirect or
different content, it opens the captive portal login page in a restricted
browser window.

This module serves the standard detection responses and implements the
captive detection logic: when no valid portal token is found, the device
is redirected to the captive portal configuration page.
"""
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse, Response

router = APIRouter(tags=["captive-portal"])

SUCCESS_HTML = """<HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML>"""
NCSI_TEXT = "Microsoft NCSI"


def _is_captive_active(request: Request) -> bool:
    token = request.cookies.get("portal_token") or request.headers.get("X-Portal-Token")
    return not token


@router.get("/hotspot-detect.html", response_class=HTMLResponse, summary="Apple captive portal detection endpoint", description="Serves the standard Apple iOS/macOS captive portal detection URL. Returns a Success HTML page if the client has a valid portal token, or redirects to the captive portal configuration page if not.")
async def hotspot_detect(request: Request):
    if _is_captive_active(request):
        return RedirectResponse(url="/portal/config")
    return HTMLResponse(content=SUCCESS_HTML)


@router.get("/generate_204", status_code=204, summary="Android captive portal detection endpoint", description="Serves the standard Android captive portal detection URL. Returns 204 No Content if the client has a valid portal token, or redirects to the captive portal configuration page if not.")
async def generate_204(request: Request):
    if _is_captive_active(request):
        return RedirectResponse(url="/portal/config")
    return Response(status_code=204)


@router.get("/ncsi.txt", response_class=PlainTextResponse, summary="Windows NCSI captive portal detection endpoint", description="Serves the standard Microsoft Windows NCSI captive portal detection URL. Returns Microsoft NCSI text if the client has a valid portal token, or redirects to the captive portal configuration page if not.")
async def ncsi_txt(request: Request):
    if _is_captive_active(request):
        return RedirectResponse(url="/portal/config")
    return PlainTextResponse(content=NCSI_TEXT)
