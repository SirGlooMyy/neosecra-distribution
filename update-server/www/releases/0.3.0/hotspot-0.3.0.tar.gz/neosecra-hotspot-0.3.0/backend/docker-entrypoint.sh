#!/bin/sh
# Dev-friendly entrypoint for api/worker/beat/migrate containers.
#
#   1. DEV_CREATE_TABLES=1  -> create tables from metadata (versions/ is empty,
#      no migrations yet; idempotent CREATE IF NOT EXISTS). PROD uses migrations.
#   2. alembic upgrade heads -> applies any real migrations (no-op today).
#   3. exec the container CMD (uvicorn / celery worker / celery beat).
set -e

if [ "${DEV_CREATE_TABLES:-0}" = "1" ]; then
  echo "[entrypoint] DEV_CREATE_TABLES=1 -> ensuring tables from metadata"
  python scripts/dev_create_tables.py || {
    echo "[entrypoint] dev_create_tables.py failed (continuing): $?"
  }
fi

if [ "${SKIP_MIGRATIONS:-0}" != "1" ]; then
  echo "[entrypoint] alembic upgrade heads"
  alembic upgrade heads || {
    echo "[entrypoint] alembic upgrade heads failed (continuing): $?"
  }
fi

exec "$@"
