"""Standalone FortiGate simulator entrypoint for Docker container."""
import os
import asyncio
import uvicorn
from tests.fake_fortigate_server import FakeFortiGateServer

async def main():
    host = os.environ.get("SIMULATOR_HOST", "0.0.0.0")
    port = int(os.environ.get("SIMULATOR_PORT", "40000"))
    server = FakeFortiGateServer(host=host, port=port)
    await server.start()
    print(f"FortiGate simulator running on {host}:{port}")
    # Keep running
    while True:
        await asyncio.sleep(3600)

if __name__ == "__main__":
    asyncio.run(main())
