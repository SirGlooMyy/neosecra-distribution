"""NVI integration tests."""
from __future__ import annotations

import sys
import types
from unittest import mock

import pytest

from app.core.config import settings
from app.modules.identity.nvi_service import verify_tc_kimlik


class _DummyResponse:
    status_code = 200
    text = "<TCKimlikNoDogrulaResult>true</TCKimlikNoDogrulaResult>"


class _DummyAsyncClient:
    last_kwargs: dict | None = None
    last_request: dict | None = None

    def __init__(self, *args, **kwargs):
        self.kwargs = kwargs
        _DummyAsyncClient.last_kwargs = kwargs

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def post(self, url, content=None, headers=None):
        _DummyAsyncClient.last_request = {
            "url": url,
            "content": content,
            "headers": headers,
        }
        return _DummyResponse()


@pytest.mark.asyncio
async def test_verify_tc_kimlik_honors_tls_setting(monkeypatch):
    monkeypatch.setattr(settings, "NVI_ENABLED", True)
    monkeypatch.setattr(settings, "NVI_VERIFY_TLS", False)

    # Mock Redis to avoid connection issues
    mock_redis = mock.MagicMock()
    mock_redis.get = mock.AsyncMock(return_value=None)
    monkeypatch.setattr(
        "app.modules.identity.nvi_service._get_redis",
        lambda: mock_redis,
    )

    fake_httpx = types.ModuleType("httpx")
    fake_httpx.AsyncClient = _DummyAsyncClient
    monkeypatch.setitem(sys.modules, "httpx", fake_httpx)

    result = await verify_tc_kimlik(
        "10000000146",
        "ALI",
        "YILMAZ",
        1990,
    )

    assert result is True
    assert _DummyAsyncClient.last_kwargs is not None
    assert _DummyAsyncClient.last_kwargs["verify"] is False
    assert _DummyAsyncClient.last_kwargs["timeout"] == 10.0
    assert _DummyAsyncClient.last_request is not None
    assert _DummyAsyncClient.last_request["url"] == (
        "https://tckimlik.nvi.gov.tr/Service/KPSPublic.asmx"
    )

