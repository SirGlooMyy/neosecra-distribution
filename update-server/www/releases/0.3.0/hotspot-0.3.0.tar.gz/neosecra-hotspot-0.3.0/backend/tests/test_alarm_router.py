"""Alarm router normalization tests."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from app.modules.alarm.models import AlarmEvent
from app.modules.alarm.router import _serialize_alarm_event


def test_serialize_alarm_event_exposes_frontend_fields():
    event = AlarmEvent(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        location_id=None,
        trigger_id=uuid.uuid4(),
        severity="critical",
        title="Port scan detected",
        message="Multiple failed connections",
        source="syslog-trigger:test",
        acknowledged=True,
        acknowledged_at=datetime(2026, 7, 13, 10, 15, tzinfo=timezone.utc),
        acknowledged_by=uuid.uuid4(),
        event_time=datetime(2026, 7, 13, 10, 10, tzinfo=timezone.utc),
    )

    payload = _serialize_alarm_event(event, trigger_name="Port scan trigger")

    assert payload["id"] == str(event.id)
    assert payload["trigger_name"] == "Port scan trigger"
    assert payload["timestamp"] == "2026-07-13T10:10:00+00:00"
    assert payload["acknowledged"] is True
    assert payload["acknowledged_at"] == "2026-07-13T10:15:00+00:00"
