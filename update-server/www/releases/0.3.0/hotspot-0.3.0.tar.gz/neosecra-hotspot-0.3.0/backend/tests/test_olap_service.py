"""olap_service.py tests — dimensions, measures, templates."""
import pytest

from app.modules.reports.olap_service import (
    OlapDimension,
    OlapQuery,
    parse_dimension,
    get_report_templates,
    _measure_label,
    _dim_label,
    GRANULARITIES,
)


class TestParseDimension:
    def test_valid(self):
        assert parse_dimension("time") == OlapDimension.TIME
        assert parse_dimension("location") == OlapDimension.LOCATION
        assert parse_dimension("auth_method") == OlapDimension.AUTH_METHOD
        assert parse_dimension("severity") == OlapDimension.SEVERITY
        assert parse_dimension("vendor") == OlapDimension.VENDOR

    def test_case_sensitive(self):
        with pytest.raises(ValueError):
            parse_dimension("TIME")

    def test_invalid(self):
        with pytest.raises(ValueError):
            parse_dimension("nonexistent_dimension")


class TestOlapDimensionEnum:
    def test_all_dimensions(self):
        expected = [
            "time", "location", "device", "auth_method", "vendor",
            "severity", "customer", "partner", "session_status",
            "hour_of_day", "day_of_week", "facility", "hostname",
        ]
        values = [d.value for d in OlapDimension]
        assert sorted(values) == sorted(expected)

    def test_has_time(self):
        assert OlapDimension("time") == OlapDimension.TIME


class TestOlapQuery:
    def test_defaults(self):
        q = OlapQuery()
        assert q.dimensions == []
        assert q.measures == ["count"]
        assert q.granularity == "day"
        assert q.source == "sessions"

    def test_with_dimensions(self):
        q = OlapQuery(dimensions=[OlapDimension.TIME, OlapDimension.LOCATION])
        assert len(q.dimensions) == 2

    def test_with_custom_measures(self):
        q = OlapQuery(measures=["count", "data_volume", "duration_avg"])
        assert len(q.measures) == 3


class TestMeasureLabel:
    def test_count(self):
        assert _measure_label("count") == "Session Count"

    def test_unique_users(self):
        assert _measure_label("unique_users") == "Unique Users"

    def test_data_volume(self):
        assert _measure_label("data_volume") == "Data Volume (MB)"

    def test_duration_avg(self):
        assert _measure_label("duration_avg") == "Avg Duration (sec)"

    def test_unknown(self):
        assert _measure_label("unknown") == "Unknown"

    def test_is_consistent(self):
        for m in ["count", "unique_users", "data_volume", "duration_avg", "duration_max"]:
            label = _measure_label(m)
            assert isinstance(label, str)
            assert len(label) > 0


class TestDimLabel:
    def test_location(self):
        assert _dim_label("location") == "Location"

    def test_auth_method(self):
        assert _dim_label("auth_method") == "Auth Method"

    def test_unknown(self):
        assert _dim_label("unknown") == "Unknown"

    def test_is_consistent(self):
        for d in ["location", "device", "auth_method", "session_status", "time"]:
            label = _dim_label(d)
            assert isinstance(label, str)
            assert len(label) > 0


class TestGetReportTemplates:
    def test_returns_list(self):
        templates = get_report_templates()
        assert isinstance(templates, list)
        assert len(templates) > 0

    def test_all_have_id(self):
        templates = get_report_templates()
        for t in templates:
            assert "id" in t
            assert t["id"].startswith("tmpl-")

    def test_all_have_name(self):
        templates = get_report_templates()
        for t in templates:
            assert "name" in t

    def test_all_have_source(self):
        templates = get_report_templates()
        for t in templates:
            assert "source" in t
            assert t["source"] in ("sessions", "syslog")

    def test_contains_session_templates(self):
        templates = get_report_templates()
        session_templates = [t for t in templates if t["source"] == "sessions"]
        assert len(session_templates) > 100

    def test_contains_syslog_templates(self):
        templates = get_report_templates()
        syslog_templates = [t for t in templates if t["source"] == "syslog"]
        assert len(syslog_templates) > 10

    def test_total_template_count(self):
        templates = get_report_templates()
        assert len(templates) >= 193


class TestGranularities:
    def test_all_granularities(self):
        assert "hour" in GRANULARITIES
        assert "day" in GRANULARITIES
        assert "week" in GRANULARITIES
        assert "month" in GRANULARITIES

    def test_no_duplicates(self):
        assert len(GRANULARITIES) == len(set(GRANULARITIES))
