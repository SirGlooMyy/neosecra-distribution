"""Partner service tests — CRUD, scoped queries, edge cases."""
import uuid
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.partners.models import Partner
from app.modules.partners.schemas import PartnerCreate, PartnerUpdate
from app.modules.partners import service as partner_service
from app.core.tenant import ScopeContext, TenantLevel


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


def _global_scope() -> ScopeContext:
    return ScopeContext(level=TenantLevel.GLOBAL)


def _partner_scope(pid: uuid.UUID) -> ScopeContext:
    return ScopeContext(level=TenantLevel.PARTNER, partner_id=pid)


class TestListPartners:
    @pytest.mark.asyncio
    async def test_list_empty(self):
        db = _mock_db()
        result = await partner_service.list_partners(db, _global_scope())
        assert result == []

    @pytest.mark.asyncio
    async def test_list_scoped_to_own(self):
        db = _mock_db()
        pid = uuid.uuid4()
        result = await partner_service.list_partners(db, _partner_scope(pid))
        assert result == []

    @pytest.mark.asyncio
    async def test_list_denied_for_customer_scope(self):
        db = _mock_db()
        scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=uuid.uuid4())
        result = await partner_service.list_partners(db, scope)
        assert result == []


class TestGetPartner:
    @pytest.mark.asyncio
    async def test_get_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await partner_service.get_partner(db, uuid.uuid4(), _global_scope())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_get_forbidden_for_customer_scope(self):
        db = _mock_db()
        pid = uuid.uuid4()
        partner = Partner(id=pid, tenant_id=uuid.uuid4(), name="Test Partner")
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = partner
        db.execute.return_value = r
        scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=uuid.uuid4())

        with pytest.raises(HTTPException) as exc:
            await partner_service.get_partner(db, pid, scope)
        assert exc.value.status_code == 403

    @pytest.mark.asyncio
    async def test_get_success_global(self):
        db = _mock_db()
        pid = uuid.uuid4()
        partner = Partner(id=pid, tenant_id=uuid.uuid4(), name="Global Partner")
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = partner
        db.execute.return_value = r

        result = await partner_service.get_partner(db, pid, _global_scope())
        assert result.name == "Global Partner"


class TestCreatePartner:
    @pytest.mark.asyncio
    async def test_create_success(self):
        db = _mock_db()
        tid = uuid.uuid4()
        body = PartnerCreate(
            tenant_id=tid,
            name="New Partner",
            reseller_code="RS001",
            contact_email="partner@example.com",
        )
        result = await partner_service.create_partner(db, body, uuid.uuid4())
        assert result is not None
        assert db.add.called
        db.commit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_create_minimal(self):
        db = _mock_db()
        body = PartnerCreate(tenant_id=uuid.uuid4(), name="Minimal")
        result = await partner_service.create_partner(db, body, uuid.uuid4())
        assert result is not None


class TestUpdatePartner:
    @pytest.mark.asyncio
    async def test_update_not_found(self):
        db = _mock_db()
        body = PartnerUpdate(name="Updated")
        with pytest.raises(HTTPException) as exc:
            await partner_service.update_partner(db, uuid.uuid4(), body, uuid.uuid4())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_update_success(self):
        db = _mock_db()
        pid = uuid.uuid4()
        partner = Partner(id=pid, tenant_id=uuid.uuid4(), name="Old Name")
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = partner
        db.execute.return_value = r

        body = PartnerUpdate(name="New Name", contact_phone="+905551234567")
        result = await partner_service.update_partner(db, pid, body, uuid.uuid4())
        assert result.name == "New Name"
        assert partner.name == "New Name"
        db.commit.assert_awaited_once()


class TestDeactivatePartner:
    @pytest.mark.asyncio
    async def test_deactivate_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await partner_service.deactivate_partner(db, uuid.uuid4(), uuid.uuid4())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_deactivate_success(self):
        db = _mock_db()
        pid = uuid.uuid4()
        partner = Partner(id=pid, tenant_id=uuid.uuid4(), name="Active Partner", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = partner
        db.execute.return_value = r

        await partner_service.deactivate_partner(db, pid, uuid.uuid4())
        assert partner.is_active is False
        db.commit.assert_awaited_once()
