"""Audit logging tests — append-only, edge cases, query helpers."""
import uuid
from unittest import mock

import pytest
from fastapi import Request

from app.modules.audit.models import AuditLog
from app.modules.audit.service import log_audit


class _FakeRequest:
    def __init__(self, host="127.0.0.1", user_agent="test-agent/1.0"):
        self.client = mock.MagicMock()
        self.client.host = host
        self.headers = {"user-agent": user_agent}


def _mock_db():
    db = mock.AsyncMock()
    db.add = mock.MagicMock()
    db.flush = mock.AsyncMock()
    return db


class TestAuditLog:
    @pytest.mark.asyncio
    async def test_log_audit_minimal(self):
        db = _mock_db()
        await log_audit(
            db,
            action="test_action",
            resource_type="test_resource",
            resource_id=None,
            actor_id=None,
        )
        db.add.assert_called_once()
        entry = db.add.call_args.args[0]
        assert isinstance(entry, AuditLog)
        assert entry.action == "test_action"
        assert entry.resource_id is None
        assert entry.actor_id is None

    @pytest.mark.asyncio
    async def test_log_audit_full(self):
        db = _mock_db()
        request = _FakeRequest(host="10.0.0.1", user_agent="curl/7.68")
        await log_audit(
            db,
            action="user.login",
            resource_type="user",
            resource_id=str(uuid.uuid4()),
            actor_id=str(uuid.uuid4()),
            request=request,
            details={"method": "password"},
            tenant_id=str(uuid.uuid4()),
        )
        entry = db.add.call_args.args[0]
        assert entry.action == "user.login"
        assert entry.ip_address == "10.0.0.1"
        assert entry.user_agent == "curl/7.68"
        assert entry.details == {"method": "password"}

    @pytest.mark.asyncio
    async def test_log_audit_without_request(self):
        db = _mock_db()
        await log_audit(
            db,
            action="system.startup",
            resource_type="system",
            resource_id=None,
            actor_id=None,
        )
        entry = db.add.call_args.args[0]
        assert entry.ip_address is None
        assert entry.user_agent is None

    @pytest.mark.asyncio
    async def test_log_audit_empty_details(self):
        db = _mock_db()
        await log_audit(
            db,
            action="read",
            resource_type="config",
            resource_id="1",
            actor_id="user1",
        )
        entry = db.add.call_args.args[0]
        assert entry.details == {}

    @pytest.mark.asyncio
    async def test_log_audit_flush_called(self):
        db = _mock_db()
        await log_audit(
            db,
            action="flush_check",
            resource_type="test",
            resource_id=None,
            actor_id=None,
        )
        db.flush.assert_awaited_once()


class TestAuditRepository:
    def test_repository_exists(self):
        from app.modules.audit import repository
        assert repository is not None

    def test_audit_log_model_has_expected_fields(self):
        entry = AuditLog(
            action="test",
            resource_type="test",
            resource_id="1",
            actor_id="user1",
        )
        assert entry.action == "test"
        assert entry.resource_type == "test"
