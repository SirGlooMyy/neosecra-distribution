"""Tests for ClickHouse adapter client and queries."""
import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime, timezone
import uuid


@pytest.fixture
def mock_ch_client():
    with patch("app.adapters.clickhouse.clickhouse_connect.get_client") as mock_get:
        mock_client = MagicMock()
        mock_get.return_value = mock_client
        from app.adapters import clickhouse as ch
        ch._client = None
        yield mock_client
        ch._client = None


def test_ensure_schema(mock_ch_client):
    import asyncio
    from app.adapters import clickhouse as ch
    asyncio.run(ch.ensure_schema())
    assert mock_ch_client.command.call_count == 2


def test_insert_syslog_batch(mock_ch_client):
    import asyncio
    from app.adapters import clickhouse as ch
    cid = uuid.uuid4()
    lid = uuid.uuid4()
    did = uuid.uuid4()
    sid = uuid.uuid4()
    records = [
        {
            "timestamp": datetime(2026, 7, 12, 12, 0, 0, tzinfo=timezone.utc),
            "customer_id": cid,
            "location_id": lid,
            "device_id": did,
            "facility": "auth",
            "severity": 6,
            "hostname": "fw-1",
            "app_name": "sshd",
            "source_ip": "192.168.1.5",
            "dest_ip": "8.8.8.8",
            "mac": "00:11:22:33:44:55",
            "username": "user1",
            "domain": "test.com",
            "application": "SSH",
            "action": "allow",
            "message": "connection accepted",
            "raw": "<166>Jul 12 12:00:00 fw-1 sshd[123]: connection accepted",
            "session_id": sid,
        }
    ]
    asyncio.run(ch.insert_syslog_batch(records))
    assert mock_ch_client.insert.call_count >= 1


def test_query_syslog(mock_ch_client):
    import asyncio
    from app.adapters import clickhouse as ch
    from datetime import datetime

    class MockQueryResult:
        column_names = ["timestamp", "severity", "hostname", "app_name", "message"]
        result_rows = [
            ("2026-07-12 12:00:00", 6, "fw-01", "auth", "login ok"),
        ]

    mock_ch_client.query.return_value = MockQueryResult()

    hits = asyncio.run(
        ch.query_syslog(
            customer_id=str(uuid.uuid4()),
            limit=10,
            offset=0,
        )
    )
    assert isinstance(hits, list)
    assert len(hits) > 0
