"""scheduler_service.py tests — next_run, CSV, size formatting."""
from datetime import datetime, timezone


from app.modules.reports.scheduler_service import (
    _calculate_next_run,
    _fmt_size,
    _build_csv,
)


class TestCalculateNextRun:
    def test_daily(self):
        result = _calculate_next_run("daily")
        assert result.hour == 2
        assert result.minute == 0

    def test_weekly(self):
        result = _calculate_next_run("weekly")
        assert result.hour == 2
        assert result.minute == 0

    def test_monthly(self):
        result = _calculate_next_run("monthly")
        assert result.day == 1
        assert result.hour == 2

    def test_hourly(self):
        result = _calculate_next_run("hourly")
        assert result.minute == 0

    def test_empty(self):
        now = datetime.now(timezone.utc)
        result = _calculate_next_run("")
        assert result > now

    def test_invalid_expression(self):
        now = datetime.now(timezone.utc)
        result = _calculate_next_run("not a cron")
        assert result > now

    def test_case_insensitive(self):
        result = _calculate_next_run("DAILY")
        assert result.hour == 2
        assert result.minute == 0

    def test_cron_minute_specific(self):
        result = _calculate_next_run("30 * * * *")
        assert result.minute == 30 or result.minute == 0

    def test_cron_specific_hour_minute(self):
        result = _calculate_next_run("0 6 * * *")
        assert 0 <= result.hour <= 23


class TestFmtSize:
    def test_bytes(self):
        assert _fmt_size(500) == "500 B"

    def test_kb(self):
        result = _fmt_size(2048)
        assert "KB" in result
        assert "2.0" in result

    def test_mb(self):
        result = _fmt_size(5 * 1024 * 1024)
        assert "MB" in result
        assert "5.0" in result

    def test_zero(self):
        assert _fmt_size(0) == "0 B"

    def test_large_mb(self):
        result = _fmt_size(15 * 1024 * 1024)
        assert "15.0" in result


class TestBuildCsv:
    def test_empty_data(self):
        result = _build_csv({"sessions_detail": []})
        assert result.replace("\r\n", "\n") == "id,mac,ip,phone,auth_method,status,started_at,ended_at,bytes_in,bytes_out\n"

    def test_single_session(self):
        data = {
            "sessions_detail": [
                {"id": "abc", "mac": "aa:bb:cc", "ip": "1.2.3.4", "phone": "555",
                 "auth_method": "sms", "status": "active", "started_at": "2026-01-01",
                 "ended_at": "2026-01-02", "bytes_in": 100, "bytes_out": 200}
            ]
        }
        result = _build_csv(data)
        assert "aa:bb:cc" in result
        assert "sms" in result
        assert "active" in result

    def test_multiple_sessions(self):
        data = {
            "sessions_detail": [
                {"id": "1", "mac": "aa:bb:cc", "ip": "1.2.3.4", "phone": "555",
                 "auth_method": "sms", "status": "active", "started_at": "", "ended_at": "",
                 "bytes_in": 0, "bytes_out": 0},
                {"id": "2", "mac": "dd:ee:ff", "ip": "5.6.7.8", "phone": "666",
                 "auth_method": "voucher", "status": "closed", "started_at": "", "ended_at": "",
                 "bytes_in": 50, "bytes_out": 75},
            ]
        }
        result = _build_csv(data)
        lines = result.strip().split("\n")
        assert len(lines) == 3  # header + 2 rows

    def test_handles_missing_keys(self):
        data = {"sessions_detail": [{"id": "1"}]}
        result = _build_csv(data)
        assert "1" in result
