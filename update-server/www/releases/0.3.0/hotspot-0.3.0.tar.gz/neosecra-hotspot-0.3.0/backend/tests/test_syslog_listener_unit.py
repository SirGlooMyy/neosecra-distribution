"""Unit and integration tests for syslog listener components.

Tests parsing, batch flushing, and TCP server/client flow.
Does not require a live DB — uses mocks and asyncio loopback.
"""
from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.modules.syslog.listener import _parse_fortigate_timestamp, _flush_batch, _make_handler


# ---------------------------------------------------------------------------
# _parse_fortigate_timestamp
# ---------------------------------------------------------------------------

class TestParseFortiGateTimestamp:
    def test_valid_date_time(self):
        fields = {"date": "2026-07-27", "time": "12:30:45"}
        dt = _parse_fortigate_timestamp(fields)
        assert dt is not None
        assert dt.year == 2026
        assert dt.month == 7
        assert dt.day == 27
        assert dt.hour == 12
        assert dt.minute == 30
        assert dt.second == 45
        assert dt.tzinfo is not None

    def test_missing_date(self):
        assert _parse_fortigate_timestamp({"time": "12:30:45"}) is None

    def test_missing_time(self):
        assert _parse_fortigate_timestamp({"date": "2026-07-27"}) is None

    def test_empty_fields(self):
        assert _parse_fortigate_timestamp({}) is None

    def test_invalid_format(self):
        assert _parse_fortigate_timestamp({"date": "invalid", "time": "bad"}) is None


# ---------------------------------------------------------------------------
# _flush_batch
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_flush_batch_empty():
    factory_mock = MagicMock()
    await _flush_batch(factory_mock, [])
    factory_mock.assert_not_called()


@pytest.mark.asyncio
async def test_flush_batch_calls_insert_and_commit():
    factory_mock = MagicMock()
    db_mock = AsyncMock()
    factory_mock.return_value.__aenter__.return_value = db_mock

    logs = [
        MagicMock(spec_set=["id", "tenant_id", "customer_id"]),
    ]
    logs[0].id = uuid.uuid4()
    logs[0].tenant_id = uuid.uuid4()
    logs[0].customer_id = uuid.uuid4()

    await _flush_batch(factory_mock, logs)
    db_mock.commit.assert_awaited_once()


# ---------------------------------------------------------------------------
# TCP server/client integration test
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_syslog_tcp_server_receives_and_parses():
    """Start a TCP listener using _make_handler, send a syslog line,
    and verify the handler processes it (with mocked DB)."""
    received_logs = []

    async def fake_db_insert(logs_batch):
        received_logs.extend(logs_batch)

    # Mock DB session factory
    db_mock = AsyncMock()
    db_mock.commit = AsyncMock()
    db_mock.rollback = AsyncMock()

    factory_mock = MagicMock()
    factory_mock.return_value.__aenter__.return_value = db_mock

    handler = _make_handler(factory_mock)

    # Start a small TCP server
    server = await asyncio.start_server(handler, host="127.0.0.1", port=0)
    addr = server.sockets[0].getsockname()

    async def client():
        reader, writer = await asyncio.open_connection("127.0.0.1", addr[1])
        # Send a FortiGate traffic log line
        line = (
            b"<14>date=2026-07-27 time=10:00:00 devname=\"FG-100F\" "
            b"devid=\"FGT-FAKE-1234\" type=\"traffic\" subtype=\"forward\" "
            b"level=\"notice\" srcip=10.0.0.1 dstip=8.8.8.8 "
            b"srcport=12345 dstport=80 proto=6 action=\"accept\" "
            b"policyid=1 sessionid=1001 duration=30 sentbyte=1024 rcvdbyte=2048\n"
        )
        writer.write(line)
        await writer.drain()
        writer.close()
        await writer.wait_closed()

    # Run client and wait a moment for processing
    await asyncio.wait_for(
        asyncio.gather(
            client(),
            asyncio.sleep(0.5),  # give time for processing
        ),
        timeout=5.0,
    )

    server.close()
    await server.wait_closed()

    # Verify the mocked DB was called
    assert db_mock.add.call_count > 0 or db_mock.commit.awaited


@pytest.mark.asyncio
async def test_syslog_tcp_multiple_lines():
    """Send multiple syslog lines, verify batch processing."""
    db_mock = AsyncMock()
    db_mock.commit = AsyncMock()
    db_mock.rollback = AsyncMock()

    factory_mock = MagicMock()
    factory_mock.return_value.__aenter__.return_value = db_mock

    handler = _make_handler(factory_mock)

    server = await asyncio.start_server(handler, host="127.0.0.1", port=0)
    addr = server.sockets[0].getsockname()

    async def client():
        reader, writer = await asyncio.open_connection("127.0.0.1", addr[1])
        lines = [
            b"<14>date=2026-07-27 time=10:00:00 type=\"traffic\" action=\"accept\" logid=\"1001\"\n",
            b"<14>date=2026-07-27 time=10:00:01 type=\"traffic\" action=\"deny\" logid=\"1002\"\n",
            b"<14>date=2026-07-27 time=10:00:02 type=\"event\" subtype=\"system\" level=\"info\"\n",
        ]
        for line in lines:
            writer.write(line)
            await writer.drain()
        writer.close()
        await writer.wait_closed()

    await asyncio.wait_for(
        asyncio.gather(client(), asyncio.sleep(0.5)),
        timeout=5.0,
    )

    server.close()
    await server.wait_closed()

    assert db_mock.add.call_count >= 3 or db_mock.commit.awaited
