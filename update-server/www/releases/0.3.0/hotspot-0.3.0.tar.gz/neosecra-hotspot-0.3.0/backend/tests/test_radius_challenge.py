"""Unit tests for RADIUS Access-Challenge service and dispatches."""
import pytest
import uuid
from datetime import datetime, timezone, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi import HTTPException

from app.modules.radius import challenge_service as cs
from app.modules.radius.models import RadiusChallenge
from app.modules.mfa.models import VpnMfaUser


@pytest.mark.asyncio
async def test_init_challenge_sms():
    customer_id = uuid.uuid4()
    mock_db = AsyncMock()

    # Mock user
    mock_user = VpnMfaUser(
        id=uuid.uuid4(),
        customer_id=customer_id,
        username="john_doe",
        phone="+905554443322",
        mfa_method="sms",
        is_active=True
    )

    mock_db.execute.return_value.scalar_one_or_none = MagicMock(return_value=mock_user)

    with patch(
        "app.modules.sms.service.send_custom_sms",
        new_callable=AsyncMock,
        return_value=(True, None),
    ) as mock_send_sms:
        result = await cs.init_challenge(mock_db, customer_id, "john_doe", "10.0.0.1")
        assert result["challenge_required"] is True
        assert result["reply_message"] == "Dogrulama kodu SMS ile gonderildi"
        assert result["mfa_method"] == "sms"
        mock_send_sms.assert_called_once()
        args, kwargs = mock_send_sms.call_args
        assert kwargs["phone"] == "+905554443322"
        assert "VPN Giris Dogrulama Kodunuz:" in kwargs["message"]


@pytest.mark.asyncio
async def test_init_challenge_email():
    customer_id = uuid.uuid4()
    mock_db = AsyncMock()

    # Mock user
    mock_user = VpnMfaUser(
        id=uuid.uuid4(),
        customer_id=customer_id,
        username="john_doe",
        email="john@example.com",
        mfa_method="email",
        is_active=True
    )

    mock_db.execute.return_value.scalar_one_or_none = MagicMock(return_value=mock_user)

    with patch(
        "app.modules.system.email_service.send_email",
        new_callable=AsyncMock,
        return_value=True,
    ) as mock_send_email:
        result = await cs.init_challenge(mock_db, customer_id, "john_doe", "10.0.0.1")
        assert result["challenge_required"] is True
        assert result["reply_message"] == "Dogrulama kodu EMAIL ile gonderildi"
        mock_send_email.assert_called_once()
        args, kwargs = mock_send_email.call_args
        assert kwargs["to"] == "john@example.com"
        assert "Giris dogrulama kodunuz:" in kwargs["html_body"]


@pytest.mark.asyncio
async def test_init_challenge_email_delivery_failure_fails_closed():
    customer_id = uuid.uuid4()
    mock_db = AsyncMock()

    mock_user = VpnMfaUser(
        id=uuid.uuid4(),
        customer_id=customer_id,
        username="john_doe",
        email="john@example.com",
        mfa_method="email",
        is_active=True,
    )

    mock_db.execute.return_value.scalar_one_or_none = MagicMock(return_value=mock_user)

    with patch("app.modules.system.email_service.send_email", new_callable=AsyncMock, return_value=False):
        with pytest.raises(HTTPException) as exc:
            await cs.init_challenge(mock_db, customer_id, "john_doe", "10.0.0.1")
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_init_challenge_whatsapp():
    customer_id = uuid.uuid4()
    mock_db = AsyncMock()

    # Mock user
    mock_user = VpnMfaUser(
        id=uuid.uuid4(),
        customer_id=customer_id,
        username="john_doe",
        phone="+905554443322",
        mfa_method="whatsapp",
        is_active=True
    )

    mock_db.execute.return_value.scalar_one_or_none = MagicMock(return_value=mock_user)

    with patch(
        "app.modules.whatsapp.service.send_whatsapp_otp",
        new_callable=AsyncMock,
        return_value=(True, None),
    ) as mock_send_wa:
        result = await cs.init_challenge(mock_db, customer_id, "john_doe", "10.0.0.1")
        assert result["challenge_required"] is True
        assert result["reply_message"] == "Dogrulama kodu WHATSAPP ile gonderildi"
        mock_send_wa.assert_called_once()
        args, kwargs = mock_send_wa.call_args
        assert kwargs["phone"] == "+905554443322"
        assert len(kwargs["code"]) == 6  # hex token of len 6


@pytest.mark.asyncio
async def test_verify_challenge_success():
    mock_db = AsyncMock()
    now = datetime.now(timezone.utc)

    # 1d7637 code sha256 hash
    # code = "1d7637"
    import hashlib
    code_hash = hashlib.sha256(b"1d7637").hexdigest()

    mock_challenge = RadiusChallenge(
        id=uuid.uuid4(),
        state="state123",
        code_hash=code_hash,
        mfa_method="sms",
        verified=False,
        attempt_count=0,
        expires_at=now + timedelta(minutes=5)
    )

    mock_db.execute.return_value.scalar_one_or_none = MagicMock(return_value=mock_challenge)

    result = await cs.verify_challenge(mock_db, "state123", "1d7637")
    assert result["verified"] is True
    assert mock_challenge.verified is True
    assert mock_challenge.consumed_at is not None
