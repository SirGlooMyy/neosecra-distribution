"""verify_service.py tests — chain integrity, single verify, export package."""
import hashlib
import io
import json
import os
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.modules.logs_5651.models import GENESIS_HASH, ArchiveRecord
from app.modules.logs_5651.service import _chain_hash, _period_key
from app.modules.logs_5651.verify_service import (
    _fetch_archive_content,
    verify_chain_integrity,
    verify_export_package,
)


def create_archive_record(chain_seq=1, prev_hash=None, customer_id=None):
    cid = customer_id or uuid.uuid4()
    prev = prev_hash or GENESIS_HASH
    content = f"test-content-{chain_seq}".encode()
    chash = hashlib.sha256(content).hexdigest()
    ps = datetime(2026, 6, 1, tzinfo=timezone.utc)
    pe = datetime(2026, 6, 2, tzinfo=timezone.utc)
    pkey = _period_key(ps, pe)
    curr = _chain_hash(prev, chash, pkey, "session_archive")
    return ArchiveRecord(
        id=uuid.uuid4(),
        customer_id=cid,
        period_start=ps,
        period_end=pe,
        record_type="session_archive",
        chain_seq=chain_seq,
        item_count=1,
        content_hash=chash,
        content_ref=f"none:{chash}",
        content_size=len(content),
        prev_hash=prev,
        curr_hash=curr,
        meta={},
        signature_value=None,
        signature_time=None,
        certificate_serial=None,
        sign_method=None,
    ), content


def test_fetch_archive_content_local():
    from app.modules.logs_5651.archive_service import compress
    data = b"test data"
    compressed = compress(data)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".bin") as f:
        f.write(compressed)
        f.flush()
        path = f.name

    archive = ArchiveRecord(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        period_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
        period_end=datetime(2026, 1, 2, tzinfo=timezone.utc),
        record_type="session_archive",
        chain_seq=1,
        item_count=1,
        content_hash="abc",
        content_ref=f"local:{path}",
        content_size=9,
        prev_hash=GENESIS_HASH,
        curr_hash="0" * 64,
        meta={},
    )
    result = _fetch_archive_content(archive)
    assert result == b"test data"
    os.unlink(path)


def test_fetch_archive_content_none_ref():
    archive = ArchiveRecord(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        period_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
        period_end=datetime(2026, 1, 2, tzinfo=timezone.utc),
        record_type="session_archive",
        chain_seq=1,
        item_count=1,
        content_hash="abc",
        content_ref="none:abc123",
        content_size=0,
        prev_hash=GENESIS_HASH,
        curr_hash="0" * 64,
        meta={},
    )
    assert _fetch_archive_content(archive) is None


def test_fetch_archive_content_missing_file():
    archive = ArchiveRecord(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        period_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
        period_end=datetime(2026, 1, 2, tzinfo=timezone.utc),
        record_type="session_archive",
        chain_seq=1,
        item_count=1,
        content_hash="abc",
        content_ref="local:/nonexistent/path/file.bin",
        content_size=0,
        prev_hash=GENESIS_HASH,
        curr_hash="0" * 64,
        meta={},
    )
    assert _fetch_archive_content(archive) is None


def test_fetch_archive_content_empty_ref():
    archive = ArchiveRecord(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        period_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
        period_end=datetime(2026, 1, 2, tzinfo=timezone.utc),
        record_type="session_archive",
        chain_seq=1,
        item_count=1,
        content_hash="abc",
        content_ref="",
        content_size=0,
        prev_hash=GENESIS_HASH,
        curr_hash="0" * 64,
        meta={},
    )
    assert _fetch_archive_content(archive) is None


def _mock_db_for_chain(records):
    db = AsyncMock()
    mock_scalars = MagicMock()
    mock_scalars.all.return_value = records
    mock_result = MagicMock()
    mock_result.scalars.return_value = mock_scalars
    db.execute = AsyncMock(return_value=mock_result)
    return db


@pytest.mark.asyncio
async def test_verify_chain_integrity_empty():
    db = _mock_db_for_chain([])
    cid = uuid.uuid4()
    result = await verify_chain_integrity(db, cid)
    assert result.ok is True
    assert result.total_records == 0


def build_chain_records(count=3, customer_id=None):
    cid = customer_id or uuid.uuid4()
    records = []
    prev = GENESIS_HASH
    for i in range(1, count + 1):
        rec, _ = create_archive_record(chain_seq=i, prev_hash=prev, customer_id=cid)
        records.append(rec)
        prev = rec.curr_hash
    return records, cid


@pytest.mark.asyncio
async def test_verify_chain_integrity_valid():
    records, cid = build_chain_records(3)
    db = _mock_db_for_chain(records)
    result = await verify_chain_integrity(db, cid)
    assert result.ok is True
    assert result.total_records == 3
    assert result.broken_at is None


@pytest.mark.asyncio
async def test_verify_chain_integrity_broken_prev_hash():
    records, cid = build_chain_records(3)
    records[1].prev_hash = "x" * 64
    db = _mock_db_for_chain(records)
    result = await verify_chain_integrity(db, cid)
    assert result.ok is False
    assert result.broken_at == 2


@pytest.mark.asyncio
async def test_verify_chain_integrity_tampered_curr_hash():
    records, cid = build_chain_records(3)
    records[1].curr_hash = "x" * 64
    db = _mock_db_for_chain(records)
    result = await verify_chain_integrity(db, cid)
    assert result.ok is False
    assert result.broken_at == 2


def test_verify_export_package_valid():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        manifest = {
            "package_type": "5651_court_evidence",
            "session_id": str(uuid.uuid4()),
            "customer_id": str(uuid.uuid4()),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        zf.writestr("session.json", json.dumps({"id": "s1"}))
        zf.writestr("syslog_records.jsonl", "{}")
        zf.writestr("radius_events.jsonl", "{}")
        zf.writestr("archive_chain.json", "[]")
        zf.writestr("evidence_manifest.json", json.dumps(manifest))
    buf.seek(0)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as f:
        f.write(buf.read())
        path = f.name

    try:
        result = verify_export_package(path)
        assert result["valid"] is True
        assert result["error"] is None
        assert "session.json" in result["files_found"]
    finally:
        os.unlink(path)


def test_verify_export_package_missing_files():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("session.json", "{}")
    buf.seek(0)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as f:
        f.write(buf.read())
        path = f.name

    try:
        result = verify_export_package(path)
        assert result["valid"] is False
        assert "Eksik" in result["error"]
    finally:
        os.unlink(path)


def test_verify_export_package_corrupt_zip():
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as f:
        f.write(b"not a zip file")
        path = f.name

    try:
        result = verify_export_package(path)
        assert result["valid"] is False
        assert "Gecersiz" in result["error"] or "bozuk" in result["error"]
    finally:
        os.unlink(path)


def test_verify_export_package_not_found():
    result = verify_export_package("/nonexistent/path/package.zip")
    assert result["valid"] is False
