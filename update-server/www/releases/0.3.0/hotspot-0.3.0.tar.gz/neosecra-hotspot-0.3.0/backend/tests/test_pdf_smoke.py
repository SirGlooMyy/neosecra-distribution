"""PDF smoke test — verify that at least one PDF engine is available."""

import pytest

_weasyprint = pytest.importorskip("weasyprint", reason="weasyprint not installed")

_has_reportlab = False
try:
    import reportlab  # noqa: F401
    _has_reportlab = True
except ImportError:
    pass


@pytest.mark.skipif(not _has_reportlab, reason="reportlab not installed")
def test_reportlab_available():
    assert True


def test_pdf_generation():
    from app.modules.logs_5651.report_service import _WEASYPRINT_AVAIL, _REPORTLAB_AVAIL
    assert _WEASYPRINT_AVAIL or _REPORTLAB_AVAIL, (
        "PDF generation requires weasyprint or reportlab"
    )
