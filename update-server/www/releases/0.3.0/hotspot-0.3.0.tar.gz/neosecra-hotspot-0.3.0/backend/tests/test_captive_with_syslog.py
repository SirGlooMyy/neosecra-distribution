"""Captive portal + syslog correlation tests.

Tests that:
  - Fake FortiGate syslog traffic log can be parsed
  - FirewallLog DB records can be stored and correlated with sessions
  - correlate_session_with_firewall_logs returns correct 5651 view
  - FortiGateAdapter.parse_syslog_event works with captive traffic
"""
from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from unittest import mock

import pytest

from app.modules.firewall_adapters.fortigate import parse_syslog_event
from app.modules.sessions.correlation import correlate_session_with_firewall_logs


# Sample FortiGate syslog traffic log for a captive portal session
SAMPLE_TRAFFIC_LOG = (
    '<134>date=2026-07-27 time=10:30:00 devname="FGT-TEST" devid="FGT-FAKE-1234" '
    'logid="0000000013" type="traffic" subtype="forward" level="notice" '
    'srcip=10.0.0.100 srcport=54321 srcintf="port2" '
    'dstip=93.184.216.34 dstport=80 dstintf="wan1" '
    'policyid=1 sessionid=TEST-SESS-001 proto=6 action="accept" '
    'duration=120 sentbyte=4096 rcvdbyte=8192 '
    'app="HTTP" service="http" user="guest@10.0.0.100" '
    'group="Guest-Group" '
)


def test_parse_captive_traffic_syslog():
    """FortiGate syslog traffic log for captive session is parsed correctly."""
    parsed = parse_syslog_event(SAMPLE_TRAFFIC_LOG)

    assert parsed["vendor"] == "fortigate"
    assert parsed["device_name"] == "FGT-TEST"
    assert parsed["src_ip"] == "10.0.0.100"
    assert parsed["dst_ip"] == "93.184.216.34"
    assert parsed["src_port"] == 54321
    assert parsed["dst_port"] == 80
    assert parsed["action"] == "accept"
    assert parsed["log_type"] == "traffic"
    assert parsed["session_id"] == "TEST-SESS-001"
    assert parsed["duration"] == 120
    assert parsed["sentbyte"] == 4096
    assert parsed["rcvdbyte"] == 8192
    assert parsed["proto"] == "6"
    assert parsed["service"] == "http"


def test_parse_captive_auth_syslog():
    """FortiGate syslog auth event for captive portal."""
    auth_log = (
        '<133>date=2026-07-27 time=10:29:55 devname="FGT-TEST" devid="FGT-FAKE-1234" '
        'logid="0100038202" type="event" subtype="user" level="notice" '
        'action="authorize" srcip=10.0.0.100 user="guest@10.0.0.100" '
        'group="Guest-Group" status="success" msg="User authorized successfully" '
        'sessionid=AUTH-SESS-001 '
    )
    parsed = parse_syslog_event(auth_log)

    assert parsed["vendor"] == "fortigate"
    assert parsed["src_ip"] == "10.0.0.100"
    assert parsed["action"] == "authorize"
    assert parsed["log_type"] == "event"
    assert parsed["session_id"] == "AUTH-SESS-001"
    assert parsed["user"] == "guest@10.0.0.100"


def test_correlate_session_with_firewall_logs():
    """correlate_session_with_firewall_logs returns correct 5651 view."""
    session_id = uuid.uuid4()
    customer_id = uuid.uuid4()
    started_at = datetime(2026, 7, 27, 10, 0, tzinfo=timezone.utc)
    ended_at = datetime(2026, 7, 27, 10, 5, tzinfo=timezone.utc)

    session = mock.MagicMock()
    session.id = session_id
    session.customer_id = customer_id
    session.location_id = uuid.uuid4()
    session.mac = "AA:BB:CC:DD:EE:FF"
    session.ip = "10.0.0.100"
    session.phone = "+905551112233"
    session.auth_method = "sms"
    session.status = "active"
    session.started_at = started_at
    session.ended_at = ended_at
    session.expires_at = None
    session.bytes_in = 999
    session.bytes_out = 888
    session.authorize_ok = True

    mock_log = mock.MagicMock()
    mock_log.id = uuid.uuid4()
    mock_log.log_type = "traffic"
    mock_log.action = "accept"
    mock_log.src_ip = "10.0.0.100"
    mock_log.dst_ip = "93.184.216.34"
    mock_log.src_port = 54321
    mock_log.dst_port = 80
    mock_log.proto = "6"
    mock_log.service = "http"
    mock_log.session_id = None
    mock_log.sentbyte = 4096
    mock_log.rcvdbyte = 8192
    mock_log.duration = 120
    mock_log.received_at = datetime(2026, 7, 27, 10, 1, tzinfo=timezone.utc)

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=session)

    scalar_result = mock.MagicMock()
    scalar_result.scalars.return_value.all.return_value = [mock_log]
    db.execute.return_value = scalar_result

    result = asyncio.run(correlate_session_with_firewall_logs(db, session_id))

    assert result["session"]["id"] == str(session_id)
    assert result["session"]["ip"] == "10.0.0.100"
    assert result["session"]["duration_sec"] == 120
    assert result["session"]["bytes_in"] == 999
    assert result["total_bytes_in"] == 4096
    assert result["total_bytes_out"] == 8192
    assert result["total_duration_sec"] == 120
    assert result["log_count"] == 1
    assert result["traffic_logs"][0]["src_ip"] == "10.0.0.100"
    assert result["traffic_logs"][0]["action"] == "accept"


def test_correlate_no_matching_logs():
    """correlate_session_with_firewall_logs with no matching FirewallLog."""
    session_id = uuid.uuid4()
    started_at = datetime(2026, 7, 27, 10, 0, tzinfo=timezone.utc)
    ended_at = datetime(2026, 7, 27, 10, 5, tzinfo=timezone.utc)

    session = mock.MagicMock()
    session.id = session_id
    session.customer_id = uuid.uuid4()
    session.location_id = uuid.uuid4()
    session.mac = "AA:BB:CC:DD:EE:FF"
    session.ip = "10.0.0.200"
    session.phone = None
    session.auth_method = "sms"
    session.status = "active"
    session.started_at = started_at
    session.ended_at = ended_at
    session.expires_at = None
    session.bytes_in = 0
    session.bytes_out = 0
    session.authorize_ok = True

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=session)

    scalar_result = mock.MagicMock()
    scalar_result.scalars.return_value.all.return_value = []
    db.execute.return_value = scalar_result

    result = asyncio.run(correlate_session_with_firewall_logs(db, session_id))

    assert result["log_count"] == 0
    assert result["total_bytes_in"] == 0
    assert result["total_bytes_out"] == 0
    assert result["total_duration_sec"] == 300
    assert result["traffic_logs"] == []


def test_correlate_session_not_found():
    """correlate_session_with_firewall_logs raises 404 for missing session."""
    from fastapi import HTTPException

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=None)

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(correlate_session_with_firewall_logs(db, uuid.uuid4()))
    assert exc_info.value.status_code == 404


def test_fortigate_syslog_rfc5424_parsing():
    """RFC 5424 syslog message from FortiGate parses correctly."""
    rfc5424_msg = (
        "<134>1 2026-07-27T10:30:00Z FGT-TEST FGT-FAKE-1234 traffic - - "
        '[logid="0000000013" type="traffic" subtype="forward" level="notice" '
        'srcip="10.0.0.100" dstip="93.184.216.34" srcport="54321" dstport="80" '
        'sessionid="SESS-RFC-001" action="accept" duration="60" '
        'sentbyte="2048" rcvdbyte="4096" proto="6" service="http"]'
    )
    parsed = parse_syslog_event(rfc5424_msg)

    assert parsed["vendor"] == "fortigate"
    assert parsed["src_ip"] == "10.0.0.100"
    assert parsed["session_id"] == "SESS-RFC-001"
    assert parsed["duration"] == 60
    assert parsed["sentbyte"] == 2048
    assert parsed["rcvdbyte"] == 4096
    assert parsed["action"] == "accept"


def test_captive_traffic_log_bytes_aggregation():
    """Multiple traffic logs for same session are aggregated correctly."""
    session_id = uuid.uuid4()
    customer_id = uuid.uuid4()
    started_at = datetime(2026, 7, 27, 10, 0, tzinfo=timezone.utc)
    ended_at = datetime(2026, 7, 27, 10, 5, tzinfo=timezone.utc)

    session = mock.MagicMock()
    session.id = session_id
    session.customer_id = customer_id
    session.location_id = uuid.uuid4()
    session.mac = "AA:BB:CC:DD:EE:FF"
    session.ip = "10.0.0.100"
    session.phone = None
    session.auth_method = "sms"
    session.status = "active"
    session.started_at = started_at
    session.ended_at = ended_at
    session.expires_at = None
    session.bytes_in = 0
    session.bytes_out = 0
    session.authorize_ok = True

    log1 = mock.MagicMock(
        id=uuid.uuid4(), log_type="traffic", action="accept",
        src_ip="10.0.0.100", dst_ip="93.184.216.34",
        src_port=80, dst_port=443, proto="6", service="https",
        session_id=None, sentbyte=1000, rcvdbyte=2000, duration=30,
        received_at=datetime(2026, 7, 27, 10, 1, tzinfo=timezone.utc),
    )
    log2 = mock.MagicMock(
        id=uuid.uuid4(), log_type="traffic", action="accept",
        src_ip="10.0.0.100", dst_ip="142.250.80.46",
        src_port=12345, dst_port=443, proto="6", service="https",
        session_id=None, sentbyte=3000, rcvdbyte=6000, duration=45,
        received_at=datetime(2026, 7, 27, 10, 2, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=session)

    scalar_result = mock.MagicMock()
    scalar_result.scalars.return_value.all.return_value = [log1, log2]
    db.execute.return_value = scalar_result

    result = asyncio.run(correlate_session_with_firewall_logs(db, session_id))

    assert result["log_count"] == 2
    assert result["total_bytes_in"] == 4000
    assert result["total_bytes_out"] == 8000
    assert result["total_duration_sec"] == 45
