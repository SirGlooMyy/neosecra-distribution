"""signing_service.py tests — mock sign, encrypt, verify."""
import base64
import hashlib
import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.modules.logs_5651.models import (
    GENESIS_HASH,
    SIGN_METHOD_KAMUSM,
    SIGN_METHOD_LOCALFILE,
    ArchiveRecord,
)
from app.modules.logs_5651.signing_service import (
    _decrypt_signing_password,
    _encrypt_signing_password,
    _mock_sign,
    get_kamusm_status,
    sign_with_kamusm,
    sign_archive_record,
    verify_signature,
)
from app.modules.logs_5651.schemas import SignResult


def test_mock_sign_returns_dict():
    content_hash_val = "a" * 64
    result = _mock_sign(content_hash_val)
    assert isinstance(result, dict)
    assert "signature_value" in result
    assert "signing_time" in result
    assert "certificate_serial" in result
    assert "signature_origin" in result
    assert result["certificate_serial"] == "MOCK-DEV-SERTIFIKA-0001"
    assert result["signature_origin"] == "demo"


def test_mock_sign_different_hashes():
    r1 = _mock_sign("a" * 64)
    r2 = _mock_sign("b" * 64)
    assert r1["signature_value"] != r2["signature_value"]


def test_mock_sign_base64_encoded():
    result = _mock_sign("a" * 64)
    decoded = base64.b64decode(result["signature_value"])
    assert len(decoded) == 64  # sha256 hex digest bytes


def test_mock_sign_includes_time():
    result = _mock_sign("a" * 64)
    assert isinstance(result["signing_time"], datetime)
    assert result["signing_time"].tzinfo is not None


def test_encrypt_decrypt_roundtrip():
    password = "test-password-123"
    encrypted = _encrypt_signing_password(password)
    assert encrypted != password
    assert encrypted != ""
    decrypted = _decrypt_signing_password(encrypted)
    assert decrypted == password


def test_encrypt_empty():
    assert _encrypt_signing_password("") == ""


def test_decrypt_empty():
    assert _decrypt_signing_password("") == ""


def test_encrypt_deterministic_different():
    p1 = _encrypt_signing_password("pass1")
    p2 = _encrypt_signing_password("pass2")
    assert p1 != p2


def test_verify_signature_valid():
    content = "verify-test-content"
    content_hash = hashlib.sha256(content.encode()).hexdigest()
    sig_result = _mock_sign(content_hash)
    sig_value = sig_result["signature_value"]

    # Mock signatures use SHA-256 digest, not PKCS1v15, so verify will fail
    # This tests the function runs without error and returns False gracefully
    result = verify_signature(content_hash, sig_value, "MOCK-CERT-PEM")
    assert result is False


def test_verify_signature_invalid_format():
    result = verify_signature("a" * 64, "invalid-base64!!!", "fake-cert")
    assert result is False


def test_verify_signature_empty_hash():
    result = verify_signature("", "", "")
    assert result is False


@pytest.mark.asyncio
async def test_sign_with_kamusm_mock_fallback(monkeypatch):
    monkeypatch.setattr("app.core.config.settings.TUBITAK_KAMUSM_ENABLED", False)
    monkeypatch.setattr("app.core.config.settings.DEMO_MODE", True)
    db = AsyncMock()
    mock_lic = MagicMock()
    mock_lic.meta = {}
    mock_result = MagicMock()
    mock_result.scalar_one_or_none.return_value = mock_lic
    db.execute = AsyncMock(return_value=mock_result)
    chash = "a" * 64
    cid = uuid.uuid4()
    result = await sign_with_kamusm(db, chash, cid)
    assert "signature_value" in result
    assert result["certificate_serial"] == "MOCK-DEV-SERTIFIKA-0001"
    assert result["signature_origin"] == "demo"


def create_mock_archive(chain_seq=1, prev_hash=None, customer_id=None):
    from app.modules.logs_5651.service import _chain_hash, _period_key

    cid = customer_id or uuid.uuid4()
    prev = prev_hash or GENESIS_HASH
    chash = hashlib.sha256(b"test").hexdigest()
    ps = datetime(2026, 6, 1, tzinfo=timezone.utc)
    pe = datetime(2026, 6, 2, tzinfo=timezone.utc)
    pkey = _period_key(ps, pe)
    curr = _chain_hash(prev, chash, pkey, "session_archive")
    return ArchiveRecord(
        id=uuid.uuid4(),
        customer_id=cid,
        period_start=ps,
        period_end=pe,
        record_type="session_archive",
        chain_seq=chain_seq,
        item_count=1,
        content_hash=chash,
        content_ref=f"none:{chash}",
        content_size=len(b"test"),
        prev_hash=prev,
        curr_hash=curr,
        meta={},
        signature_value=None,
        signature_time=None,
        certificate_serial=None,
        sign_method=None,
    )


def _mock_db_with_license(customer_id=None):
    db = AsyncMock()
    db.add = MagicMock()
    mock_lic = MagicMock()
    mock_lic.customer_id = customer_id or uuid.uuid4()
    mock_lic.plan = "default"
    mock_lic.meta = {}
    mock_result = MagicMock()
    mock_result.scalar_one_or_none.return_value = mock_lic
    db.execute = AsyncMock(return_value=mock_result)
    return db, mock_lic


@pytest.mark.asyncio
async def test_sign_archive_record_unsigned(monkeypatch):
    monkeypatch.setattr("app.core.config.settings.TUBITAK_KAMUSM_ENABLED", False)
    monkeypatch.setattr("app.core.config.settings.DEMO_MODE", True)
    db, _ = _mock_db_with_license()

    archive = create_mock_archive()
    result = await sign_archive_record(db, archive)
    assert isinstance(result, SignResult)
    assert result.archive_id == archive.id
    assert result.sign_method == SIGN_METHOD_KAMUSM
    assert result.signature_value is not None
    assert result.signature_origin == "demo"


@pytest.mark.asyncio
async def test_sign_archive_record_already_signed(monkeypatch):
    monkeypatch.setattr("app.core.config.settings.TUBITAK_KAMUSM_ENABLED", False)
    monkeypatch.setattr("app.core.config.settings.DEMO_MODE", True)
    db, mock_lic = _mock_db_with_license()

    archive = create_mock_archive()
    archive.signature_value = "existing-sig"
    archive.sign_method = SIGN_METHOD_LOCALFILE
    archive.signature_time = datetime.now(timezone.utc)
    archive.meta = {"signature_origin": "localfile"}

    result = await sign_archive_record(db, archive)
    assert result.signature_value == "existing-sig"
    assert result.sign_method == SIGN_METHOD_LOCALFILE
    assert result.signature_origin == "localfile"


@pytest.mark.asyncio
async def test_sign_archive_record_stores_audit(monkeypatch):
    monkeypatch.setattr("app.core.config.settings.TUBITAK_KAMUSM_ENABLED", False)
    monkeypatch.setattr("app.core.config.settings.DEMO_MODE", True)
    db, _ = _mock_db_with_license()

    archive = create_mock_archive()
    await sign_archive_record(db, archive)
    assert archive.signature_value is not None
    assert archive.sign_method == SIGN_METHOD_KAMUSM
    assert archive.meta["signature_origin"] == "demo"
    assert db.flush.called


@pytest.mark.asyncio
async def test_get_kamusm_status_includes_last_signature_origin(monkeypatch):
    monkeypatch.setattr("app.core.config.settings.TUBITAK_KAMUSM_ENABLED", False)
    db, mock_lic = _mock_db_with_license()
    mock_lic.meta = {
        "kamusm_config": {
            "is_configured": True,
            "sign_method": SIGN_METHOD_KAMUSM,
            "last_signed_at": "2026-07-01T10:20:30+00:00",
            "last_signed_archive_id": str(uuid.uuid4()),
            "last_signature_origin": "demo",
        }
    }

    status = await get_kamusm_status(db, mock_lic.customer_id)
    assert status.last_signature_origin == "demo"
    assert status.last_signed_archive_id is not None
