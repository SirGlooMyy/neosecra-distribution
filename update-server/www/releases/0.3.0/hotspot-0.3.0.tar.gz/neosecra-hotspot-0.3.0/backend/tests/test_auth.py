import pytest
import uuid
import unittest.mock as mock
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.core.security import hash_password, verify_password, create_access_token
from app.core.tenant import scope_for, TenantLevel
from app.modules.auth.models import User
from app.core.rbac import ROLE_PERMISSIONS

client = TestClient(app)


def test_password_hashing_and_verification():
    """Verify that password hashing and verification works correctly."""
    plain = "Secr3tP@ssword!"
    hashed = hash_password(plain)
    assert hashed != plain
    assert verify_password(plain, hashed) is True
    assert verify_password("wrong_password", hashed) is False


def test_tenant_isolation_scope_context():
    """Verify that tenant guard helper (scope_for) resolves scopes and fails closed."""
    # Global level (super_admin)
    admin_user = User(
        role="super_admin",
        tenant_id=None,
        partner_id=None,
        customer_id=None,
        location_id=None,
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )
    scope = scope_for(admin_user)
    assert scope.level == TenantLevel.GLOBAL
    assert scope.allowed is True

    # Partner level - Allowed
    partner_user = User(
        role="partner_admin",
        tenant_id=uuid.uuid4(),
        partner_id=uuid.uuid4(),
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )
    scope = scope_for(partner_user)
    assert scope.level == TenantLevel.PARTNER
    assert scope.allowed is True

    # Partner level - Denied (No partner ID assigned)
    partner_user_no_id = User(
        role="partner_admin",
        tenant_id=uuid.uuid4(),
        partner_id=None,
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )
    scope = scope_for(partner_user_no_id)
    assert scope.allowed is False

    # Customer level - Allowed
    customer_user = User(
        role="customer_admin",
        tenant_id=uuid.uuid4(),
        partner_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )
    scope = scope_for(customer_user)
    assert scope.level == TenantLevel.CUSTOMER
    assert scope.allowed is True

    # Customer level - Denied
    customer_user_no_id = User(
        role="customer_admin",
        tenant_id=uuid.uuid4(),
        customer_id=None,
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )
    scope = scope_for(customer_user_no_id)
    assert scope.allowed is False

    # Location level - Allowed
    location_user = User(
        role="location_manager",
        tenant_id=uuid.uuid4(),
        partner_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        location_id=uuid.uuid4(),
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )
    scope = scope_for(location_user)
    assert scope.level == TenantLevel.LOCATION
    assert scope.allowed is True

    # Location level - Denied
    location_user_no_id = User(
        role="location_manager",
        tenant_id=uuid.uuid4(),
        location_id=None,
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )
    scope = scope_for(location_user_no_id)
    assert scope.allowed is False


@pytest.mark.asyncio
async def test_login_endpoint_success():
    """Verify that successful login returns access and refresh tokens."""
    hashed = hash_password("SuperSecret123")
    mock_user = User(
        id=uuid.uuid4(),
        email="user@hotspot.io",
        hashed_password=hashed,
        role="super_admin",
        is_active=True,
        tenant_id=None,
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )

    mock_db = mock.AsyncMock()
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = mock_user
    mock_db.execute.return_value = mock_result

    app.dependency_overrides[get_db] = lambda: mock_db

    # Mock the rate limit check and reset
    with mock.patch("app.modules.auth.service.rate_limit_check", new_callable=mock.AsyncMock) as mock_rl, \
         mock.patch("app.modules.auth.service.rate_limit_reset", new_callable=mock.AsyncMock) as mock_rl_reset:
        mock_rl.return_value = (False, 1)
        mock_rl_reset.return_value = None

        response = client.post("/api/v1/auth/login", json={
            "email": "user@hotspot.io",
            "password": "SuperSecret123"
        })

        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["user"]["email"] == "user@hotspot.io"

    app.dependency_overrides.clear()


@pytest.mark.asyncio
async def test_login_endpoint_invalid_password():
    """Verify that login fails with 401 when given an invalid password."""
    hashed = hash_password("SuperSecret123")
    mock_user = User(
        id=uuid.uuid4(),
        email="user@hotspot.io",
        hashed_password=hashed,
        role="super_admin",
        is_active=True,
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )

    mock_db = mock.AsyncMock()
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = mock_user
    mock_db.execute.return_value = mock_result

    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.service.rate_limit_check", new_callable=mock.AsyncMock) as mock_rl:
        mock_rl.return_value = (False, 1)

        response = client.post("/api/v1/auth/login", json={
            "email": "user@hotspot.io",
            "password": "wrong_password"
        })

        assert response.status_code == 401
        assert response.json()["detail"] == "Gecersiz e-posta veya sifre"

    app.dependency_overrides.clear()


@pytest.mark.asyncio
async def test_me_endpoint_success():
    """Verify that GET /me returns the user profile when supplied with a valid token."""
    user_id = uuid.uuid4()
    mock_user = User(
        id=user_id,
        email="user@hotspot.io",
        hashed_password="hashed_placeholder",
        role="partner_admin",
        is_active=True,
        tenant_id=uuid.uuid4(),
        partner_id=uuid.uuid4(),
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )

    token = create_access_token(str(user_id), extra={"type": "access"})

    mock_db = mock.AsyncMock()
    mock_db.get.return_value = mock_user
    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as mock_blacklist:
        mock_blacklist.return_value = False

        response = client.get("/api/v1/auth/me", headers={
            "Authorization": f"Bearer {token}"
        })

        assert response.status_code == 200
        data = response.json()
        assert data["email"] == "user@hotspot.io"
        assert data["role"] == "partner_admin"

    app.dependency_overrides.clear()


@pytest.mark.asyncio
async def test_me_endpoint_update_profile_success():
    """Verify that PATCH /me updates the authenticated user's profile."""
    user_id = uuid.uuid4()
    mock_user = User(
        id=user_id,
        email="user@hotspot.io",
        full_name="Old Name",
        hashed_password="hashed_placeholder",
        role="partner_admin",
        is_active=True,
        tenant_id=uuid.uuid4(),
        partner_id=uuid.uuid4(),
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )

    token = create_access_token(str(user_id), extra={"type": "access"})

    mock_db = mock.AsyncMock()
    mock_db.get.return_value = mock_user
    mock_db.execute = mock.AsyncMock(return_value=mock.MagicMock(scalar_one_or_none=mock.MagicMock(return_value=None)))
    mock_db.add = mock.MagicMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()
    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as mock_blacklist:
        mock_blacklist.return_value = False

        response = client.patch(
            "/api/v1/auth/me",
            headers={"Authorization": f"Bearer {token}"},
            json={"email": "new-user@hotspot.io", "full_name": "Yeni Ad"},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["email"] == "new-user@hotspot.io"
        assert data["full_name"] == "Yeni Ad"

    app.dependency_overrides.clear()


def test_me_endpoint_invalid_token():
    """Verify that GET /me returns 401 unauthorized when given an invalid token."""
    response = client.get("/api/v1/auth/me", headers={
        "Authorization": "Bearer invalid_jwt_token_value"
    })
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_permissions_endpoint():
    """Verify that GET /permissions returns correct list of permissions for the role."""
    user_id = uuid.uuid4()
    mock_user = User(
        id=user_id,
        email="partner@hotspot.io",
        hashed_password="hashed_placeholder",
        role="partner_admin",
        is_active=True,
        tenant_id=uuid.uuid4(),
        partner_id=uuid.uuid4(),
        is_2fa_enabled=False, mfa_required=False, mfa_methods=[]
    )

    token = create_access_token(str(user_id), extra={"type": "access"})

    mock_db = mock.AsyncMock()
    mock_db.get.return_value = mock_user
    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as mock_blacklist:
        mock_blacklist.return_value = False

        response = client.get("/api/v1/auth/permissions", headers={
            "Authorization": f"Bearer {token}"
        })

        assert response.status_code == 200
        permissions = response.json()
        
        expected_permissions = list(ROLE_PERMISSIONS["partner_admin"])
        assert set(permissions) == set(expected_permissions)

    app.dependency_overrides.clear()
