"""Local authentication service tests — CRUD, authenticate, edge cases."""
import uuid
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.local_auth.models import LocalUser
from app.modules.local_auth import service as local_auth


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


class TestCreateUser:
    @pytest.mark.asyncio
    async def test_create_user_success(self):
        db = _mock_db()
        result = await local_auth.create_user(
            db,
            customer_id=uuid.uuid4(),
            location_id=uuid.uuid4(),
            username="testuser",
            password="StrongP@ss1",
            display_name="Test User",
            email="test@example.com",
            phone="+905551234567",
        )
        assert result is not None
        db.add.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_user_duplicate_username(self):
        db = _mock_db()
        existing = LocalUser(
            id=uuid.uuid4(),
            customer_id=uuid.uuid4(),
            username="testuser",
            display_name="Existing",
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = existing
        db.execute.return_value = r

        with pytest.raises(HTTPException) as exc:
            await local_auth.create_user(
                db,
                customer_id=existing.customer_id,
                location_id=None,
                username="testuser",
                password="StrongP@ss1",
                display_name="Test User",
            )
        assert exc.value.status_code == 409

    @pytest.mark.asyncio
    async def test_create_user_minimal(self):
        db = _mock_db()
        result = await local_auth.create_user(
            db,
            customer_id=uuid.uuid4(),
            location_id=None,
            username="minimal",
            password="P@ss1234",
            display_name="Minimal User",
        )
        assert result is not None


class TestAuthenticate:
    @pytest.mark.asyncio
    async def test_authenticate_success(self):
        db = _mock_db()
        user = LocalUser(
            id=uuid.uuid4(),
            customer_id=uuid.uuid4(),
            username="testuser",
            display_name="Test",
            is_active=True,
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = user
        db.execute.return_value = r

        with mock.patch("app.modules.local_auth.service.pwd_ctx.verify", return_value=True):
            result = await local_auth.authenticate(
                db,
                username="testuser",
                password="correct",
                customer_id=user.customer_id,
            )
        assert result is not None
        assert result.username == "testuser"

    @pytest.mark.asyncio
    async def test_authenticate_user_not_found(self):
        db = _mock_db()
        result = await local_auth.authenticate(
            db,
            username="nonexistent",
            password="any",
            customer_id=uuid.uuid4(),
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_authenticate_wrong_password(self):
        db = _mock_db()
        user = LocalUser(
            id=uuid.uuid4(),
            customer_id=uuid.uuid4(),
            username="testuser",
            display_name="Test",
            is_active=True,
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = user
        db.execute.return_value = r

        with mock.patch("app.modules.local_auth.service.pwd_ctx.verify", return_value=False):
            result = await local_auth.authenticate(
                db,
                username="testuser",
                password="wrong",
                customer_id=user.customer_id,
            )
        assert result is None


class TestUpdateUser:
    @pytest.mark.asyncio
    async def test_update_user_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await local_auth.update_user(
                db,
                user_id=uuid.uuid4(),
                customer_id=uuid.uuid4(),
                display_name="New Name",
            )
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_update_user_success(self):
        db = _mock_db()
        user = LocalUser(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            username="testuser", display_name="Old",
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = user
        db.execute.return_value = r

        result = await local_auth.update_user(
            db,
            user_id=user.id,
            customer_id=user.customer_id,
            display_name="New Name",
            email="new@example.com",
        )
        assert result.display_name == "New Name"


class TestDeactivateUser:
    @pytest.mark.asyncio
    async def test_deactivate_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await local_auth.deactivate_user(
                db,
                user_id=uuid.uuid4(),
                customer_id=uuid.uuid4(),
            )
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_deactivate_success(self):
        db = _mock_db()
        user = LocalUser(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            username="testuser", display_name="Test",
            is_active=True,
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = user
        db.execute.return_value = r

        await local_auth.deactivate_user(
            db,
            user_id=user.id,
            customer_id=user.customer_id,
        )
        assert user.is_active is False


class TestListUsers:
    @pytest.mark.asyncio
    async def test_list_users_empty(self):
        db = _mock_db()
        result = await local_auth.list_users(db, customer_id=uuid.uuid4())
        assert result == []

    @pytest.mark.asyncio
    async def test_list_users_orders_by_created_at_desc(self):
        db = _mock_db()
        result = await local_auth.list_users(db, customer_id=uuid.uuid4())
        db.execute.assert_awaited_once()
