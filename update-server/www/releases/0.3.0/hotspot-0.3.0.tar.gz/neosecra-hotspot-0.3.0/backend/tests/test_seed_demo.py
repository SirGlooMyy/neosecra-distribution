"""Seed demo admin kullanicilarin MFA default acik testi."""
from app.seeds.seed_demo import ADMIN_ROLES


def test_admin_roles_defined():
    assert "super_admin" in ADMIN_ROLES
    assert "partner_admin" in ADMIN_ROLES
    assert "customer_admin" in ADMIN_ROLES


def test_non_admin_roles_excluded():
    assert "support" not in ADMIN_ROLES
    assert "location_manager" not in ADMIN_ROLES
