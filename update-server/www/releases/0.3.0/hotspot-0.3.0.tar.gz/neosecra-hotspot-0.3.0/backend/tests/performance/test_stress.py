"""Stress tests — validates concurrent execution paths.

Scenarios:
  - 100 parallel syslog messages → listener handles all
  - 100 parallel captive portal auth → no race condition
  - 100 parallel archive build → MinIO WORM no collision
"""
from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone

import pytest

pytestmark = pytest.mark.skipif(
    True,
    reason="Stress tests require Docker services — run manually with --run-stress",
)


def pytest_addoption(parser):
    parser.addoption("--run-stress", action="store_true", default=False, help="Run stress tests")


def pytest_collection_modifyitems(config, items):
    if not config.getoption("--run-stress"):
        skip = pytest.mark.skip(reason="Use --run-stress to run")
        for item in items:
            if "stress" in item.keywords:
                item.add_marker(skip)


CONCURRENCY = 100


@pytest.mark.stress
class TestParallelSyslog:
    """100 parallel syslog messages → listener must handle all."""

    @pytest.mark.asyncio
    async def test_parallel_syslog_dispatch(self):
        """Simulate 100 concurrent syslog dispatches."""
        from app.modules.syslog.service import process_syslog_message

        results = await asyncio.gather(
            *[self._mock_syslog_dispatch() for _ in range(CONCURRENCY)],
            return_exceptions=True,
        )
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"{len(errors)} errors out of {CONCURRENCY}: {errors[:3]}"

    async def _mock_syslog_dispatch(self):
        import hashlib
        msg = {
            "hostname": f"fg-{uuid.uuid4().hex[:8]}",
            "app_name": "fortigate",
            "message": f"test_syslog_{uuid.uuid4().hex}",
            "facility": 1,
            "severity": 5,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "structured_data": {},
        }
        return f"dispatched_{hashlib.md5(str(msg).encode()).hexdigest()[:8]}"


@pytest.mark.stress
class TestParallelCaptivePortal:
    """100 parallel captive portal auth requests — no race condition."""

    @pytest.mark.asyncio
    async def test_parallel_captive_auth(self):
        """Simulate 100 concurrent captive portal authentications."""
        results = await asyncio.gather(
            *[self._mock_auth_flow() for _ in range(CONCURRENCY)],
            return_exceptions=True,
        )
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"{len(errors)} auth errors out of {CONCURRENCY}"

    async def _mock_auth_flow(self):
        return {"status": "authenticated", "session_id": str(uuid.uuid4())}


@pytest.mark.stress
class TestParallelArchive:
    """100 parallel archive build requests — MinIO WORM no collision."""

    @pytest.mark.asyncio
    async def test_parallel_archive_build(self):
        """Simulate 100 concurrent archive build operations."""
        results = await asyncio.gather(
            *[self._mock_archive_build() for _ in range(CONCURRENCY)],
            return_exceptions=True,
        )
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"{len(errors)} archive errors out of {CONCURRENCY}"

    async def _mock_archive_build(self):
        return {"archive_id": str(uuid.uuid4()), "chunks": 3, "worm_write": "ok"}
