"""Unit tests for RFC 5424 parser with RFC 3164 fallback."""
from __future__ import annotations

import pytest

from app.modules.syslog.rfc5424 import parse_rfc5424


class TestRFC5424WellFormed:
    def test_full_rfc5424_with_structured_data(self):
        raw = (
            "<134>1 2026-07-27T12:30:00.123Z myhost.example.com "
            "fortilog 1234 ID47 "
            "[exampleSDID@32473 iut=\"3\" eventSource=\"Application\"] "
            "traffic log message"
        )
        result = parse_rfc5424(raw)
        assert result is not None
        assert result["facility"] == 16  # 134 >> 3 = 16 (local0)
        assert result["severity"] == 6   # 134 & 7 = 6 (info)
        assert result["ts"] == "2026-07-27T12:30:00.123000+00:00"
        assert result["hostname"] == "myhost.example.com"
        assert result["app_name"] == "fortilog"
        assert result["procid"] == "1234"
        assert result["msgid"] == "ID47"
        assert result["structured_data"] == {
            "exampleSDID@32473": {"iut": "3", "eventSource": "Application"},
        }
        assert "traffic log message" in result["msg"]

    def test_rfc5424_no_structured_data(self):
        raw = "<14>1 2026-07-27T10:00:00Z hostname app 1234 - - MSG"
        result = parse_rfc5424(raw)
        assert result is not None
        assert result["facility"] == 1
        assert result["severity"] == 6
        assert result["hostname"] == "hostname"
        assert result["app_name"] == "app"
        assert result["procid"] == "1234"
        assert result["msgid"] is None
        assert result["structured_data"] == {}
        assert result["msg"] == "MSG"

    def test_rfc5424_nil_values(self):
        raw = "<1>1 - - - - - - nothing"
        result = parse_rfc5424(raw)
        assert result is not None
        assert result["ts"] is None
        assert result["hostname"] is None
        assert result["app_name"] is None
        assert result["procid"] is None
        assert result["msgid"] is None
        assert result["msg"] == "nothing"


class TestRFC3164Fallback:
    def test_rfc3164_bsd_format(self):
        raw = "<34>Oct  1 12:34:56 myhost sshd[123]: Accepted publickey"
        result = parse_rfc5424(raw)
        assert result is not None
        assert result["facility"] == 4    # 34 >> 3 = 4 (auth)
        assert result["severity"] == 2    # 34 & 7 = 2 (crit)
        assert result["hostname"] == "myhost"
        assert result["app_name"] is None
        assert "Accepted publickey" in result["msg"]
        # Timestamp should be parsed (year filled in with current year)
        assert result["ts"] is not None
        assert "T12:34:56" in result["ts"]


class TestEdgeCases:
    def test_malformed_line_no_pri(self):
        """Line with no PRI at all returns None."""
        raw = "just a random string without syslog format"
        result = parse_rfc5424(raw)
        assert result is None

    def test_malformed_line_empty(self):
        """Empty/blank input returns None."""
        assert parse_rfc5424("") is None
        assert parse_rfc5424("   ") is None
        assert parse_rfc5424(b"") is None

    def test_pri_edge_min_max(self):
        """PRI=0 and PRI=191 boundaries."""
        r0 = parse_rfc5424("<0>1 2026-01-01T00:00:00Z h a p m - - msg0")
        assert r0 is not None
        assert r0["facility"] == 0
        assert r0["severity"] == 0

        r191 = parse_rfc5424("<191>1 2026-01-01T00:00:00Z h a p m - - msg191")
        assert r191 is not None
        assert r191["facility"] == 23
        assert r191["severity"] == 7

    def test_pri_only_fallback(self):
        """Line with only PRI and text (no recognized format) returns basic parse."""
        raw = "<158>some random text without timestamp"
        result = parse_rfc5424(raw)
        assert result is not None
        assert result["facility"] == 19
        assert result["severity"] == 6
        assert result["ts"] is None
        assert result["msg"] == "some random text without timestamp"

    def test_bytes_input(self):
        """Accept bytes as input."""
        raw = b"<14>1 2026-07-27T10:00:00Z host app 1234 - - bytes test"
        result = parse_rfc5424(raw)
        assert result is not None
        assert result["hostname"] == "host"
        assert result["msg"] == "bytes test"

    def test_non_utf8_bytes(self):
        """Non-UTF-8 bytes should not crash."""
        raw = b"<14>\xff\xfe"
        result = parse_rfc5424(raw)  # does not crash
        assert result is None or isinstance(result, dict)

    def test_structured_data_empty_brackets(self):
        """Empty structured data brackets."""
        raw = "<14>1 2026-01-01T00:00:00Z h a p - [] msg"
        result = parse_rfc5424(raw)
        assert result is not None
        assert result["msgid"] is None
        assert result["structured_data"] == {}
        assert result["msg"] == "msg"
