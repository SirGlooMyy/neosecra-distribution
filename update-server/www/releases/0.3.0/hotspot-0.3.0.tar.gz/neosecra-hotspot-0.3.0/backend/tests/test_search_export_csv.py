"""Export format tests: CSV (BTK column order) and JSONL."""

import csv
import io
import json
import uuid
from datetime import datetime, timezone
from unittest import mock

import pytest

from app.modules.search.schemas import LogSearchParams
from app.modules.search.service import (
    _CSV_BTK_COLUMNS,
    export_firewall_logs,
)
from app.modules.syslog.models import FirewallLog


def _mock_firewall_log(**overrides) -> mock.MagicMock:
    now = datetime.now(timezone.utc)
    vals = dict(
        id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        received_at=now,
        event_time=now,
        vendor="fortigate",
        log_type="traffic",
        log_subtype=None,
        severity="info",
        action="accept",
        src_ip="10.0.0.1",
        dst_ip="8.8.8.8",
        src_port=12345,
        dst_port=443,
        proto="TCP",
        service="HTTPS",
        user="testuser",
        policyid=1,
        duration=100,
        sentbyte=1000,
        rcvdbyte=2000,
        session_id="sess-001",
        raw_syslog="<14>1 2026-07-27T10:00:00Z hostname ...",
        parsed_fields={},
    )
    vals.update(overrides)
    row = mock.MagicMock(spec=FirewallLog)
    for k, v in vals.items():
        setattr(row, k, v)
    return row


class _ScalarAll:
    def __init__(self, rows):
        self._rows = rows
    def scalars(self):
        return self
    def all(self):
        return self._rows


@pytest.mark.asyncio
async def test_export_csv_btk_column_order():
    """CSV export uses BTK-compatible column order."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.return_value = _ScalarAll([_mock_firewall_log()])

    filters = LogSearchParams()
    stream, filename = await export_firewall_logs(db, user, filters, fmt="csv")

    content = b"".join([chunk async for chunk in stream]).decode("utf-8")
    reader = csv.DictReader(io.StringIO(content))

    assert reader.fieldnames == _CSV_BTK_COLUMNS, (
        f"CSV columns should match BTK order, got {reader.fieldnames}"
    )

    rows = list(reader)
    assert len(rows) == 1
    assert rows[0]["vendor"] == "fortigate"
    assert rows[0]["src_ip"] == "10.0.0.1"
    assert rows[0]["action"] == "accept"


@pytest.mark.asyncio
async def test_export_csv_multiple_rows():
    """CSV export handles multiple rows."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.return_value = _ScalarAll([
        _mock_firewall_log(src_ip="10.0.0.1"),
        _mock_firewall_log(src_ip="10.0.0.2"),
        _mock_firewall_log(src_ip="10.0.0.3"),
    ])

    filters = LogSearchParams()
    stream, filename = await export_firewall_logs(db, user, filters, fmt="csv")

    content = b"".join([chunk async for chunk in stream]).decode("utf-8")
    lines = content.strip().split("\n")
    assert len(lines) == 4  # header + 3 data rows


@pytest.mark.asyncio
async def test_export_jsonl_format():
    """JSONL export returns one JSON object per line."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.return_value = _ScalarAll([
        _mock_firewall_log(src_ip="10.0.0.1"),
        _mock_firewall_log(src_ip="10.0.0.2"),
    ])

    filters = LogSearchParams()
    stream, filename = await export_firewall_logs(db, user, filters, fmt="jsonl")

    content = b"".join([chunk async for chunk in stream]).decode("utf-8")
    lines = [l for l in content.strip().split("\n") if l]
    assert len(lines) == 2

    obj = json.loads(lines[0])
    assert obj["vendor"] == "fortigate"
    assert "event_time" in obj


@pytest.mark.asyncio
async def test_export_filename_matches_format():
    """Filename includes format-appropriate extension."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.return_value = _ScalarAll([])

    filters = LogSearchParams()

    _, csv_name = await export_firewall_logs(db, user, filters, fmt="csv")
    assert csv_name.endswith(".csv")

    _, jsonl_name = await export_firewall_logs(db, user, filters, fmt="jsonl")
    assert jsonl_name.endswith(".jsonl")


@pytest.mark.asyncio
async def test_export_empty_result():
    """Export with no matching rows returns header-only CSV."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.return_value = _ScalarAll([])

    filters = LogSearchParams(vendor="nonexistent")
    stream, filename = await export_firewall_logs(db, user, filters, fmt="csv")

    content = b"".join([chunk async for chunk in stream]).decode("utf-8")
    assert content.strip() == ",".join(_CSV_BTK_COLUMNS)
