"""Site Bridge Agent testleri — OfflineQueue, HMAC signing, Agent lifecycle."""
from __future__ import annotations

import os
import tempfile
from unittest import mock

import httpx
import pytest

# Site bridge agent'i dogrudan import et (PATH ayari gerekebilir)
import sys

site_bridge_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "site-bridge"))
sys.path.insert(0, site_bridge_root)
sys.path.insert(0, os.path.join(site_bridge_root, "bridge"))

# Test icin OFFLINE_QUEUE_PATH'i tmp dizine yonlendir
_tmp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp_db.close()
os.environ["OFFLINE_QUEUE_PATH"] = _tmp_db.name

from bridge.queue import OfflineQueue
from bridge.main import SiteBridgeAgent, _sign  # noqa: E402

@pytest.fixture(autouse=True)
def _reset_queue_path():
    """Her test oncesi queue path'ini tmp dosyaya yonlendir."""
    old = os.environ.get("OFFLINE_QUEUE_PATH")
    os.environ["OFFLINE_QUEUE_PATH"] = _tmp_db.name
    yield
    if old:
        os.environ["OFFLINE_QUEUE_PATH"] = old
    else:
        os.environ.pop("OFFLINE_QUEUE_PATH", None)

# ── OfflineQueue Tests ────────────────────────────────────────────────


def test_queue_enqueue_dequeue():
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        q = OfflineQueue(path=f.name)
        q.enqueue("test_event", {"key": "value"})
        assert q.count_pending() == 1
        items = q.dequeue()
        assert len(items) == 1
        assert items[0]["event_type"] == "test_event"
        assert items[0]["payload"] == {"key": "value"}
        q.close()


def test_queue_mark_delivered():
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        q = OfflineQueue(path=f.name)
        q.enqueue("ev1", {"a": 1})
        q.enqueue("ev2", {"b": 2})
        assert q.count_pending() == 2
        items = q.dequeue()
        q.mark_delivered([items[0]["id"]])
        assert q.count_pending() == 1
        remaining = q.dequeue()
        assert remaining[0]["payload"] == {"b": 2}
        q.close()


def test_queue_empty_dequeue():
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        q = OfflineQueue(path=f.name)
        assert q.dequeue() == []
        assert q.count_pending() == 0
        q.close()


def test_queue_mark_delivered_empty():
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        q = OfflineQueue(path=f.name)
        q.mark_delivered([])  # should not raise
        q.close()


# ── HMAC Sign / Verify Tests ──────────────────────────────────────────


def test_sign_and_verify(monkeypatch):
    monkeypatch.setenv("BRIDGE_HMAC_KEY", "test-key")
    # reload module to pick up new env var
    import importlib

    import main as m

    importlib.reload(m)

    payload = {"type": "restart", "payload": {"version": "1.0.0"}}
    sig = m._sign(payload)
    assert m._verify(payload, sig)
    assert not m._verify(payload, "bad-signature")
    # tampered payload
    tampered = {**payload, "type": "upgrade"}
    assert not m._verify(tampered, sig)


# ── SiteBridgeAgent Tests ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_agent_enroll_success():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()

    with mock.patch.object(agent._http, "post") as mock_post:
        mock_post.return_value = httpx.Response(201, json={"ok": True})
        result = await agent.enroll()
        assert result is True
        mock_post.assert_called_once()
        assert "/agents/register" in str(mock_post.call_args[0][0])

    await agent.close()


@pytest.mark.asyncio
async def test_agent_enroll_failure():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()

    with mock.patch.object(agent._http, "post") as mock_post:
        mock_post.return_value = httpx.Response(401, json={"error": "unauthorized"})
        result = await agent.enroll()
        assert result is False

    await agent.close()


@pytest.mark.asyncio
async def test_agent_enroll_http_error():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()

    with mock.patch.object(agent._http, "post") as mock_post:
        mock_post.side_effect = httpx.ConnectError("connection refused")
        result = await agent.enroll()
        assert result is False

    await agent.close()


@pytest.mark.asyncio
async def test_agent_heartbeat_with_commands():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()
    agent._queue.count_pending.return_value = 0

    with mock.patch.object(agent._http, "post") as mock_post:
        mock_post.return_value = httpx.Response(
            200,
            json={
                "ok": True,
                "pending_commands": [
                    {"id": "cmd-1", "type": "sync_config", "payload": {}, "signature": _sign({"type": "sync_config", "payload": {}})}
                ],
            },
        )
        result = await agent.heartbeat()
        assert result.get("ok") is True
        assert len(result.get("pending_commands", [])) == 1

    await agent.close()


@pytest.mark.asyncio
async def test_agent_heartbeat_failure():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()

    with mock.patch.object(agent._http, "post") as mock_post:
        mock_post.side_effect = httpx.ConnectError("timeout")
        result = await agent.heartbeat()
        assert result.get("ok") is False
        assert result.get("pending_commands") == []

    await agent.close()


@pytest.mark.asyncio
async def test_agent_execute_command_unknown():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()

    with mock.patch.object(agent._http, "post") as mock_post:
        mock_post.return_value = httpx.Response(200, json={"ok": True})
        await agent.execute_command({
            "id": "cmd-1",
            "type": "unknown_type",
            "payload": {},
            "signature": _sign({"type": "unknown_type", "payload": {}}),
        })
        # should ack with failed status
        call_args = mock_post.call_args
        assert call_args is not None
        body = call_args[1]["json"]
        assert body["status"] == "failed"

    await agent.close()


@pytest.mark.asyncio
async def test_agent_execute_command_invalid_signature():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()

    with mock.patch.object(agent._http, "post") as mock_post:
        await agent.execute_command({
            "id": "cmd-1",
            "type": "restart",
            "payload": {},
            "signature": "invalid-signature",
        })
        mock_post.assert_not_called()

    await agent.close()


@pytest.mark.asyncio
async def test_agent_flush_offline_queue():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()
    agent._queue.dequeue.return_value = [
        {"id": 1, "event_type": "fw_rule", "payload": {"rule": "allow"}}
    ]

    with mock.patch.object(agent._http, "post") as mock_post:
        mock_post.return_value = httpx.Response(201, json={"ok": True})
        await agent.flush_offline_queue()
        agent._queue.mark_delivered.assert_called_once_with([1])

    await agent.close()


@pytest.mark.asyncio
async def test_agent_flush_empty_queue():
    agent = SiteBridgeAgent()
    agent._queue = mock.MagicMock()
    agent._queue.dequeue.return_value = []

    with mock.patch.object(agent._http, "post") as mock_post:
        await agent.flush_offline_queue()
        mock_post.assert_not_called()

    await agent.close()
