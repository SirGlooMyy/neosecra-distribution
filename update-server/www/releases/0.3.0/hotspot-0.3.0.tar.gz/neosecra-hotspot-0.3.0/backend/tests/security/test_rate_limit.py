"""Rate limiting / DoS koruma testleri.

Kapsam:
  - 100 hızlı login isteği (rate limit tetiklenmeli)
  - /search offset=99999999999 (resource exhaustion)
  - 10MB POST payload (body size limit)
"""
import asyncio
import uuid
import unittest.mock as mock

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.core.security import rate_limit, create_access_token

client = TestClient(app)


@pytest.fixture(autouse=True)
def _mock_redis():
    incr_store = {}

    async def incr_side_effect(key):
        incr_store[key] = incr_store.get(key, 0) + 1
        return incr_store[key]

    async def delete_side(key):
        incr_store.pop(key, None)
        return True

    r = mock.AsyncMock()
    r.get.return_value = None
    r.set.return_value = True
    r.delete.side_effect = delete_side
    r.incr.side_effect = incr_side_effect
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield


def _mock_user(**overrides):
    uid = overrides.pop("id", uuid.uuid4())
    return mock.MagicMock(
        id=uid,
        email=overrides.pop("email", "user@hotspot.io"),
        full_name=overrides.pop("full_name", "Test User"),
        hashed_password=overrides.pop("hashed_password", "hashed"),
        role=overrides.pop("role", "customer_admin"),
        is_active=overrides.pop("is_active", True),
        tenant_id=overrides.pop("tenant_id", uuid.uuid4()),
        customer_id=overrides.pop("customer_id", uuid.uuid4()),
        partner_id=overrides.pop("partner_id", None),
        location_id=overrides.pop("location_id", None),
        **overrides,
    )


def _build_mock_db(user):
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = user
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = user
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.first.return_value = user
    mock_scalar_result.all.return_value = []
    mock_result.scalars.return_value = mock_scalar_result
    mock_db.execute.return_value = mock_result
    mock_db.add = mock.AsyncMock()
    mock_db.flush = mock.AsyncMock()
    return mock_db


# =====================================================================
# Rate limit — brute force login
# =====================================================================

def test_rate_limit_fast_login_attempts():
    """100 rapid login attempts — rate limit should block after 5."""
    from app.core.config import settings

    key = f"test:login:{uuid.uuid4()}"
    blocked = False
    blocked_at = 0

    for i in range(100):
        is_blocked, attempts = asyncio.run(rate_limit(
            key,
            settings.LOGIN_MAX_ATTEMPTS,
            settings.LOGIN_WINDOW_MINUTES * 60,
        ))
        if is_blocked:
            blocked = True
            blocked_at = i + 1
            break

    assert blocked, (
        "Rate limit did not block after 100 attempts "
        f"(max={settings.LOGIN_MAX_ATTEMPTS})"
    )
    assert blocked_at <= settings.LOGIN_MAX_ATTEMPTS + 1, (
        f"Rate limit should block at attempt {settings.LOGIN_MAX_ATTEMPTS + 1}, "
        f"blocked at {blocked_at}"
    )


def test_rate_limit_reset():
    """Rate limit counter should reset after calling rate_limit_reset."""
    from app.core.config import settings
    from app.core.security import rate_limit_reset

    key = f"test:reset:{uuid.uuid4()}"

    for i in range(3):
        asyncio.run(rate_limit(
            key,
            settings.LOGIN_MAX_ATTEMPTS,
            settings.LOGIN_WINDOW_MINUTES * 60,
        ))

    asyncio.run(rate_limit_reset(key))

    is_blocked, attempts = asyncio.run(rate_limit(
        key,
        settings.LOGIN_MAX_ATTEMPTS,
        settings.LOGIN_WINDOW_MINUTES * 60,
    ))
    assert attempts <= 2, (
        f"After reset, attempts should be 1 or 2, got {attempts}"
    )


# =====================================================================
# Offset-based resource exhaustion
# =====================================================================

def test_large_offset_doesnt_crash():
    """Large offset parameters must not cause resource exhaustion."""
    mock_user = _mock_user()
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    token = create_access_token(str(mock_user.id), extra={"type": "access"})

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        for path in ["/api/v1/devices", "/api/v1/sessions", "/api/v1/vouchers"]:
            response = client.get(
                f"{path}?offset=99999999999&limit=9999999",
                headers={"Authorization": f"Bearer {token}"},
            )
            assert response.status_code not in (500,), (
                f"Large offset caused {response.status_code} on {path}"
            )

    app.dependency_overrides.clear()


# =====================================================================
# Large POST payload
# =====================================================================

def test_large_payload_rejected():
    """10MB POST payload should be rejected or limited."""
    large_body = "x" * (10 * 1024 * 1024)
    response = client.post(
        "/api/v1/auth/login",
        params={"email": "test@test.com", "password": "test"},
        content=large_body,
    )
    assert response.status_code in (400, 401, 413, 422), (
        f"Large payload should be rejected, got {response.status_code}"
    )


# =====================================================================
# Rapid concurrent requests
# =====================================================================

def test_rapid_concurrent_requests():
    """Multiple rapid GET requests should not degrade or crash."""
    mock_user = _mock_user()
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    token = create_access_token(str(mock_user.id), extra={"type": "access"})

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        for _ in range(25):
            response = client.get(
                "/api/v1/auth/me",
                headers={"Authorization": f"Bearer {token}"},
            )
            assert response.status_code in (200, 401), (
                f"Rapid request failed: {response.status_code}"
            )

    app.dependency_overrides.clear()
