from __future__ import annotations

from datetime import datetime, timezone
from unittest import mock
import uuid

import pytest

from app.core.tenant import ScopeContext, TenantLevel
from app.modules.portal.models import PortalTemplate
from app.modules.portal.schemas import PortalTemplateUpdate, ThemeSpec
from app.modules.portal import service
from app.modules.portal.template_service import apply_template_to_portal


def _base_theme(
    *,
    primary_color: str,
    secondary_color: str,
    title: str,
) -> dict:
    return {
        "primary_color": primary_color,
        "secondary_color": secondary_color,
        "bg_color": "#f8fafc",
        "text_color": "#0f172a",
        "font_family": "'Inter', 'Segoe UI', sans-serif",
        "logo_style": "circle",
        "button_style": "pill",
        "layout": "centered",
        "bg_image_url": "",
        "logo_url": "",
        "title": title,
        "subtitle": f"{title} subtitle",
        "footer": f"{title} footer",
        "terms_text": f"{title} terms",
        "support_text": f"{title} support",
    }


def _make_template() -> PortalTemplate:
    template = PortalTemplate(
        customer_id=uuid.uuid4(),
        location_id=None,
        name="Initial Template",
        method="sms",
        is_default=True,
        theme=_base_theme(primary_color="#111111", secondary_color="#222222", title="Initial"),
        fields=[{"name": "phone", "type": "tel", "required": True, "label": "Telefon"}],
        success_message="Welcome",
        terms_url="https://example.com/terms",
        meta={
            "revision": 1,
            "revision_history": [],
            "revision_action": "created",
            "revision_updated_at": "2026-07-13T10:00:00+00:00",
            "revision_updated_by": "creator-user",
            "applied_predefined_template_id": "hotel_classic",
        },
        is_active=True,
    )
    template.id = uuid.uuid4()
    template.created_at = datetime(2026, 7, 13, 10, 0, tzinfo=timezone.utc)
    template.updated_at = datetime(2026, 7, 13, 10, 0, tzinfo=timezone.utc)
    return template


@pytest.mark.asyncio
async def test_update_template_tracks_revision_history_and_theme_fields():
    template = _make_template()
    db = mock.AsyncMock()
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    request = mock.MagicMock()
    scope = ScopeContext(level=TenantLevel.GLOBAL)

    update_body = PortalTemplateUpdate(
        name="Updated Template",
        method="free",
        theme=ThemeSpec(
            primary_color="#0f172a",
            secondary_color="#1d4ed8",
            bg_color="#ffffff",
            text_color="#111827",
            font_family="'Poppins', 'Segoe UI', sans-serif",
            logo_style="square",
            button_style="rounded",
            layout="wide",
            bg_image_url="https://cdn.example.com/bg.png",
            logo_url="https://cdn.example.com/logo.png",
            title="Yeni Başlık",
            subtitle="Yeni alt başlık",
            footer="Yeni footer",
            terms_text="Yeni şartlar",
            support_text="Yeni destek",
        ),
        meta={"custom": "value"},
    )

    with mock.patch("app.modules.portal.service.get_template", new=mock.AsyncMock(return_value=template)), \
         mock.patch("app.modules.portal.service.log_audit", new=mock.AsyncMock()) as audit_mock:
        result = await service.update_template(db, template.id, update_body, scope, actor_id=uuid.uuid4(), request=request)

    assert result.revision == 2
    assert result.revision_action == "updated"
    assert result.theme["secondary_color"] == "#1d4ed8"
    assert result.theme["font_family"] == "'Poppins', 'Segoe UI', sans-serif"
    assert result.theme["logo_url"] == "https://cdn.example.com/logo.png"
    assert result.meta["custom"] == "value"
    assert result.meta["revision"] == 2
    assert result.meta["revision_action"] == "updated"
    assert len(result.meta["revision_history"]) == 1

    previous = result.meta["revision_history"][0]
    assert previous["revision"] == 1
    assert previous["action"] == "updated"
    assert previous["is_active"] is True
    assert previous["theme"]["primary_color"] == "#111111"
    assert previous["theme"]["title"] == "Initial"

    assert audit_mock.await_count == 1
    assert audit_mock.await_args.args[1] == "portal.template_updated"


@pytest.mark.asyncio
async def test_restore_template_revision_returns_previous_snapshot_and_updates_history():
    template = _make_template()
    db = mock.AsyncMock()
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    request = mock.MagicMock()
    scope = ScopeContext(level=TenantLevel.GLOBAL)

    update_body = PortalTemplateUpdate(
        theme=ThemeSpec(
            primary_color="#0f172a",
            secondary_color="#2563eb",
            bg_color="#f8fafc",
            text_color="#0f172a",
            font_family="'Montserrat', 'Segoe UI', sans-serif",
            logo_style="rounded",
            button_style="sharp",
            layout="split",
            bg_image_url="https://cdn.example.com/updated-bg.png",
            logo_url="https://cdn.example.com/updated-logo.png",
            title="Updated Title",
            subtitle="Updated Subtitle",
            footer="Updated Footer",
            terms_text="Updated Terms",
            support_text="Updated Support",
        ),
    )

    with mock.patch("app.modules.portal.service.get_template", new=mock.AsyncMock(return_value=template)), \
         mock.patch("app.modules.portal.service.log_audit", new=mock.AsyncMock()):
        await service.update_template(db, template.id, update_body, scope, actor_id=uuid.uuid4(), request=request)

    with mock.patch("app.modules.portal.service.get_template", new=mock.AsyncMock(return_value=template)):
        history = await service.list_template_history(db, template.id, scope)

    assert history.current_revision == 2
    assert history.history_count == 1
    assert history.current.action == "updated"
    assert history.history[0].revision == 1

    with mock.patch("app.modules.portal.service.get_template", new=mock.AsyncMock(return_value=template)), \
         mock.patch("app.modules.portal.service.log_audit", new=mock.AsyncMock()) as audit_mock:
        restored = await service.restore_template_revision(
            db,
            template.id,
            1,
            scope,
            actor_id=uuid.uuid4(),
            request=request,
        )

    assert restored.revision == 3
    assert restored.revision_action == "restored"
    assert restored.meta["restored_from_revision"] == 1
    assert restored.theme["primary_color"] == "#111111"
    assert restored.theme["title"] == "Initial"
    assert len(restored.meta["revision_history"]) == 2
    assert restored.meta["revision_history"][-1]["revision"] == 2
    assert restored.is_active is True
    assert audit_mock.await_count == 1
    assert audit_mock.await_args.args[1] == "portal.template_revision_restored"


@pytest.mark.asyncio
async def test_apply_template_to_portal_builds_full_update_payload():
    db = mock.AsyncMock()
    request = mock.MagicMock()
    scope = ScopeContext(level=TenantLevel.GLOBAL)
    portal_id = uuid.uuid4()
    actor_id = uuid.uuid4()
    expected_template = _make_template()

    with mock.patch("app.modules.portal.template_service.update_template", new=mock.AsyncMock(return_value=expected_template)) as update_mock:
        result = await apply_template_to_portal(
            db,
            portal_id,
            "hotel_modern",
            scope,
            actor_id,
            request,
        )

    assert result is expected_template
    assert update_mock.await_count == 1
    body = update_mock.await_args.args[2]
    assert isinstance(body, PortalTemplateUpdate)
    assert body.theme.primary_color == "#0d9488"
    assert body.theme.secondary_color == "#14b8a6"
    assert body.theme.logo_style == "circle"
    assert body.meta["applied_predefined_template_id"] == "hotel_modern"
    assert body.meta["applied_predefined_template_name"] == "Hotel Modern"
    assert update_mock.await_args.kwargs["revision_action"] == "applied_template"
