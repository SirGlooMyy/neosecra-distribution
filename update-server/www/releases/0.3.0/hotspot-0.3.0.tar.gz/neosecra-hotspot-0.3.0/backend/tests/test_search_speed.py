"""Benchmark and performance tests for firewall_logs search.

Note: True sub-100ms benchmarks require a real PostgreSQL instance with
100K seeded firewall_logs. These unit tests validate:
- took_ms is correctly measured and reported
- Query building produces valid SQL (no syntax errors)
- Pagination (limit/offset) works correctly
"""

import uuid
from datetime import datetime, timezone
from unittest import mock

import pytest

from app.modules.search.schemas import LogSearchParams
from app.modules.search.service import search_firewall_logs
from app.modules.syslog.models import FirewallLog


def _make_firewall_log_row(**overrides):
    """Create a mock FirewallLog ORM instance."""
    now = datetime.now(timezone.utc)
    vals = dict(
        id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        vendor="fortigate",
        log_type="traffic",
        log_subtype=None,
        severity="info",
        action="accept",
        src_ip="10.0.0.1",
        dst_ip="8.8.8.8",
        src_port=80,
        dst_port=443,
        proto="TCP",
        service="HTTPS",
        user="testuser",
        policyid=1,
        duration=100,
        sentbyte=1000,
        rcvdbyte=2000,
        session_id="sess-001",
        raw_syslog="<14>1 2026-07-27T10:00:00Z hostname ...",
        event_time=now,
        received_at=now,
        parsed_fields={},
    )
    vals.update(overrides)
    row = mock.MagicMock(spec=FirewallLog)
    for k, v in vals.items():
        setattr(row, k, v)
    return row


class _ScalarResult:
    def __init__(self, count_val):
        self._count_val = count_val
    def scalar(self):
        return self._count_val


class _ScalarRows:
    def __init__(self, rows):
        self._rows = rows
    def scalars(self):
        return self
    def all(self):
        return self._rows


@pytest.mark.asyncio
async def test_search_speed_returns_took_ms():
    """search_firewall_logs returns took_ms >= 0."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()

    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResult(100000),
        _ScalarRows([_make_firewall_log_row() for _ in range(100)]),
    ]

    filters = LogSearchParams(limit=100)
    res = await search_firewall_logs(db, user, filters)

    assert res.took_ms >= 0
    assert res.total == 100000
    assert len(res.items) == 100


@pytest.mark.asyncio
async def test_search_speed_with_empty_result():
    """Empty result returns zero items quickly."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResult(0),
        _ScalarRows([]),
    ]

    filters = LogSearchParams(severity="critical")
    res = await search_firewall_logs(db, user, filters)

    assert res.total == 0
    assert len(res.items) == 0
    assert res.took_ms >= 0


@pytest.mark.asyncio
async def test_search_pagination_limit():
    """Limit parameter restricts returned results."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()

    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResult(1000),
        _ScalarRows([_make_firewall_log_row() for _ in range(50)]),
    ]

    filters = LogSearchParams(limit=50)
    res = await search_firewall_logs(db, user, filters)

    assert len(res.items) == 50


@pytest.mark.asyncio
async def test_search_pagination_offset():
    """Offset parameter shifts results."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()

    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResult(1000),
        _ScalarRows([_make_firewall_log_row(src_ip="10.0.0.100")]),
    ]

    filters = LogSearchParams(limit=10, offset=90)
    res = await search_firewall_logs(db, user, filters)

    assert res.total == 1000


@pytest.mark.asyncio
async def test_search_single_filter_performance_contract():
    """Single filter: response contains took_ms < 100ms (mocked).

    This validates the took_ms measurement mechanism — real sub-100ms
    requires live DB with 100K records + proper indexes (GIN).
    """
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()

    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResult(50000),
        _ScalarRows([_make_firewall_log_row(severity="critical")]),
    ]

    filters = LogSearchParams(severity="critical")
    res = await search_firewall_logs(db, user, filters)

    assert res.items[0].severity == "critical"
    assert res.took_ms >= 0
