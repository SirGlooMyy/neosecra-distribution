"""Negatif senaryo testleri (SMS OTP) — gerçek Postgres ile.

Bunlar SMS OTP'nin hata durumlarında doğru HTTPException kodu fırlattığını
kanıtlar: süresi dolmuş kod, hatalı kod, farklı tenant izolasyonu.

NOT: conftest.py pytest-asyncio kullanmadan `asyncio.run` ile testleri çalıştırıyor,
bu yüzden async fixture'lar sorun çıkarıyor. Bu testlerde her test kendi engine'ini
ve session'ını oluşturur, sonunda rollback yapar.
"""
from __future__ import annotations

import asyncio
import os
import uuid
from datetime import datetime, timedelta, timezone

import pytest
from fastapi import HTTPException
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

# Ensure full SQLAlchemy metadata is loaded (all FKs must be resolvable).
from app.core.database import Base  # noqa: F401
import pkgutil
import app.modules as _modules_pkg
for _finder, _name, _ispkg in pkgutil.iter_modules(_modules_pkg.__path__):
    _mod = f"app.modules.{_name}.models"
    try:
        __import__(_mod)
    except Exception:
        pass

pytestmark = pytest.mark.skipif(
    not os.environ.get("DATABASE_URL"),
    reason="DATABASE_URL not set — gerçek DB yok, integration negatif test SKIP",
)


def _redis_stub():
    class R:
        async def get(self, *a, **k): return None
        async def set(self, *a, **k): return True
        async def incr(self, *a, **k): return 1
        async def expire(self, *a, **k): return True
        async def exists(self, *a, **k): return 0
        async def delete(self, *a, **k): return 1
    return R()


async def _run_test(coro):
    """Async test logic'i sync pytest'ten çalıştır."""
    from app.core import security as sec
    from app.modules.sms.models import SmsOtp
    from app.modules.customers.models import Customer
    from app.modules.tenants.models import Tenant

    sec._get_redis = lambda: _redis_stub()

    engine = create_async_engine(os.environ["DATABASE_URL"], echo=False)
    Session = async_sessionmaker(engine, expire_on_commit=False)
    tenant_id = uuid.uuid4()
    customer_id = uuid.uuid4()
    try:
        async with Session() as session:
            tenant = Tenant(
                id=tenant_id,
                name=f"Test Tenant {tenant_id.hex[:8]}",
                slug=f"test-{tenant_id.hex[:8]}",
                is_active=True,
            )
            session.add(tenant)
            await session.flush()
            customer = Customer(
                id=customer_id, tenant_id=tenant_id,
                name=f"Test Customer {customer_id.hex[:8]}", is_active=True,
            )
            session.add(customer)
            await session.flush()
            await coro(session, customer_id)
    finally:
        async with engine.begin() as conn:
            await conn.execute(
                SmsOtp.__table__.delete().where(SmsOtp.customer_id == customer_id)
            )
            await conn.execute(Customer.__table__.delete().where(Customer.id == customer_id))
            await conn.execute(Tenant.__table__.delete().where(Tenant.id == tenant_id))
        await engine.dispose()


def test_expired_otp_returns_410():
    """Süresi dolmuş OTP 410 Gone fırlatmalı."""
    from app.modules.sms.models import PURPOSE_PORTAL, SmsOtp
    from app.modules.sms.service import _hash_code, verify_otp

    async def body(session, customer_id):
        code = "123456"
        otp = SmsOtp(
            customer_id=customer_id,
            phone="+905551234567",
            code_hash=_hash_code(code),
            purpose=PURPOSE_PORTAL,
            expires_at=datetime.now(timezone.utc) - timedelta(minutes=1),
            max_attempts=3, delivered=True,
        )
        session.add(otp)
        await session.commit()
        with pytest.raises(HTTPException) as exc:
            await verify_otp(
                session, phone="+905551234567",
                customer_id=customer_id, code=code,
            )
        assert exc.value.status_code == 410

    asyncio.run(_run_test(body))


def test_wrong_code_returns_400():
    """Hatalı kod 400 Bad Request fırlatmalı."""
    from app.modules.sms.models import PURPOSE_PORTAL, SmsOtp
    from app.modules.sms.service import _hash_code, verify_otp

    async def body(session, customer_id):
        otp = SmsOtp(
            customer_id=customer_id,
            phone="+905551234568",
            code_hash=_hash_code("111111"),
            purpose=PURPOSE_PORTAL,
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
            max_attempts=3, delivered=True,
        )
        session.add(otp)
        await session.commit()
        with pytest.raises(HTTPException) as exc:
            await verify_otp(
                session, phone="+905551234568",
                customer_id=customer_id, code="000000",
            )
        assert exc.value.status_code == 400

    asyncio.run(_run_test(body))


def test_cross_tenant_returns_404():
    """Tenant A için OTP, tenant B ile sorgulanırsa 404."""
    from app.modules.sms.models import PURPOSE_PORTAL, SmsOtp
    from app.modules.sms.service import _hash_code, verify_otp

    async def body(session, customer_id):
        code = "222222"
        otp = SmsOtp(
            customer_id=customer_id,
            phone="+905551234569",
            code_hash=_hash_code(code),
            purpose=PURPOSE_PORTAL,
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
            max_attempts=3, delivered=True,
        )
        session.add(otp)
        await session.commit()
        with pytest.raises(HTTPException) as exc:
            await verify_otp(
                session, phone="+905551234569",
                customer_id=uuid.uuid4(), code=code,
            )
        assert exc.value.status_code == 404

    asyncio.run(_run_test(body))


def test_max_attempts_returns_429():
    """3 yanlış deneme sonrası 429."""
    from app.modules.sms.models import PURPOSE_PORTAL, SmsOtp
    from app.modules.sms.service import _hash_code, verify_otp

    async def body(session, customer_id):
        otp = SmsOtp(
            customer_id=customer_id,
            phone="+905551234570",
            code_hash=_hash_code("555555"),
            purpose=PURPOSE_PORTAL,
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
            max_attempts=3, attempts=3, delivered=True,
        )
        session.add(otp)
        await session.commit()
        with pytest.raises(HTTPException) as exc:
            await verify_otp(
                session, phone="+905551234570",
                customer_id=customer_id, code="000000",
            )
        assert exc.value.status_code == 429

    asyncio.run(_run_test(body))
