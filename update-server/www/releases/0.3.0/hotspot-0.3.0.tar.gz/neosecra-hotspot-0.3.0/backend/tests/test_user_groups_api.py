"""User groups service-layer tests — CRUD, scope isolation."""
import uuid

import pytest
import unittest.mock as mock
from datetime import datetime, timezone

from app.modules.user_groups.models import UserGroup


@pytest.fixture(autouse=True)
def _any_redis():
    with mock.patch("app.core.security._get_redis", return_value=mock.AsyncMock()):
        yield


# ---- Helpers ----


def _scope(customer_id=None, location_id=None):
    from app.core.tenant import ScopeContext, TenantLevel
    return ScopeContext(
        level=TenantLevel.CUSTOMER if customer_id else TenantLevel.GLOBAL,
        allowed=True, customer_id=customer_id, location_id=location_id,
    )


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    return db


# ---- Tests ----


class TestListGroups:
    async def _call(self, db, scope):
        from app.modules.user_groups.service import list_groups
        return await list_groups(db, scope)

    def test_empty(self):
        import asyncio
        result = asyncio.run(self._call(_mock_db(), _scope(customer_id=uuid.uuid4())))
        assert result == []


class TestCreateGroup:
    async def _call(self, db, scope, **kw):
        from app.modules.user_groups.service import create_group
        from app.modules.user_groups.schemas import UserGroupCreate
        data = {
            "customer_id": kw.pop("customer_id", uuid.uuid4()),
            "name": kw.pop("name", "Test"),
        }
        data.update(kw)
        body = UserGroupCreate(**data)
        user = mock.MagicMock()
        user.id = uuid.uuid4()
        return await create_group(db, body, scope, user, mock.MagicMock())

    def test_creates_group_and_syncs_vlan_profile(self):
        cid = uuid.uuid4()
        db = _mock_db()
        db_result = mock.MagicMock()
        db_result.scalar_one_or_none.return_value = None
        db_result.scalars.return_value.all.return_value = []
        db.execute.return_value = db_result

        import asyncio
        with mock.patch(
            "app.modules.user_groups.service.sync_profile_for_group",
            new=mock.AsyncMock(),
        ) as sync_mock:
            g = asyncio.run(
                self._call(
                    db,
                    _scope(customer_id=cid),
                    customer_id=cid,
                    name="Premium",
                    vlan_id=77,
                    description="Gold tier",
                )
            )
        assert g.name == "Premium"
        assert g.customer_id == cid
        sync_mock.assert_awaited_once()
        sync_args = sync_mock.await_args.kwargs
        assert sync_args["customer_id"] == cid
        assert sync_args["vlan_id"] == 77
        assert sync_args["group_name"] == "Premium"


class TestGetGroup:
    async def _call(self, db, group_id, scope):
        from app.modules.user_groups.service import get_group
        return await get_group(db, group_id, scope)

    def test_found(self):
        cid = uuid.uuid4()
        gid = uuid.uuid4()
        db = _mock_db()
        g = UserGroup(id=gid, customer_id=cid, name="Gold", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = g
        db.execute.return_value = r

        import asyncio
        result = asyncio.run(self._call(db, gid, _scope(customer_id=cid)))
        assert result.id == gid
        assert result.name == "Gold"

    def test_not_found(self):
        cid = uuid.uuid4()
        db = _mock_db()

        import asyncio
        with pytest.raises(Exception):
            asyncio.run(self._call(db, uuid.uuid4(), _scope(customer_id=cid)))


class TestUpdateGroup:
    async def _call(self, db, group_id, scope, **kw):
        from app.modules.user_groups.service import update_group
        from app.modules.user_groups.schemas import UserGroupUpdate
        body = UserGroupUpdate(**kw)
        user = mock.MagicMock()
        user.id = uuid.uuid4()
        return await update_group(db, group_id, body, scope, user, mock.MagicMock())

    def test_updates_name_and_resyncs_vlan_profile(self):
        cid = uuid.uuid4()
        gid = uuid.uuid4()
        db = _mock_db()
        g = UserGroup(id=gid, customer_id=cid, name="Old", is_active=True, vlan_id=33)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = g
        db.execute.return_value = r

        import asyncio
        with mock.patch(
            "app.modules.user_groups.service.sync_profile_for_group",
            new=mock.AsyncMock(),
        ) as sync_mock:
            asyncio.run(self._call(db, gid, _scope(customer_id=cid), name="Updated"))
        assert g.name == "Updated"
        sync_mock.assert_awaited_once()
        sync_args = sync_mock.await_args.kwargs
        assert sync_args["previous_group_name"] == "Old"
        assert sync_args["group_name"] == "Updated"
        assert sync_args["vlan_id"] == 33


class TestDeleteGroup:
    async def _call(self, db, group_id, scope):
        from app.modules.user_groups.service import delete_group
        user = mock.MagicMock()
        user.id = uuid.uuid4()
        return await delete_group(db, group_id, scope, user, mock.MagicMock())

    def test_soft_delete_and_remove_vlan_profile(self):
        cid = uuid.uuid4()
        gid = uuid.uuid4()
        db = _mock_db()
        g = UserGroup(id=gid, customer_id=cid, name="Temp", is_active=True, vlan_id=41)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = g
        db.execute.return_value = r

        import asyncio
        with mock.patch(
            "app.modules.user_groups.service.sync_profile_for_group",
            new=mock.AsyncMock(),
        ) as sync_mock:
            asyncio.run(self._call(db, gid, _scope(customer_id=cid)))
        assert g.is_active is False
        sync_mock.assert_awaited_once()
        sync_args = sync_mock.await_args.kwargs
        assert sync_args["group_name"] == "Temp"
        assert sync_args["vlan_id"] is None


class TestPolicyHelpers:
    def test_pick_session_group_prefers_accessible_group(self):
        from app.modules.user_groups.service import build_group_policy, pick_session_group, preview_captive_policy
        from app.modules.radius.vlan_service import build_user_group_key, build_vlan_avps

        now = datetime(2026, 7, 13, 12, 0, tzinfo=timezone.utc)
        cid = uuid.uuid4()
        g1 = UserGroup(
            id=uuid.uuid4(),
            customer_id=cid,
            name="Closed",
            is_active=True,
            access_start=datetime(2026, 7, 14, tzinfo=timezone.utc),
            access_end=datetime(2026, 7, 14, 23, 59, tzinfo=timezone.utc),
        )
        g2 = UserGroup(
            id=uuid.uuid4(),
            customer_id=cid,
            location_id=uuid.uuid4(),
            name="Open",
            is_active=True,
            vlan_id=45,
            access_start=datetime(2026, 7, 13, 10, 0, tzinfo=timezone.utc),
            access_end=datetime(2026, 7, 13, 18, 0, tzinfo=timezone.utc),
        )

        selected = pick_session_group([g1, g2], now=now)
        assert selected.id == g2.id

        policy = build_group_policy(g2)
        assert policy["group_id"] == str(g2.id)
        assert policy["customer_id"] == str(cid)
        assert policy["location_id"] == str(g2.location_id)
        assert policy["scope"] == "location"
        assert policy["radius_vlan_key"] == build_user_group_key(g2.name, g2.id)
        assert policy["radius_avps"] == build_vlan_avps(45)
        assert policy["access_start"] == g2.access_start.isoformat()
        assert policy["access_window"]["end"] == g2.access_end.isoformat()
        assert policy["vlan_id"] == 45
        assert "VLAN 45" in policy["policy_summary"]
        assert policy["enforcement_notes"]

        db = _mock_db()
        r = mock.MagicMock()
        r.scalars.return_value.all.return_value = [g1, g2]
        db.execute.return_value = r

        import asyncio
        preview = asyncio.run(preview_captive_policy(db, cid, location_id=g2.location_id, now=now))
        assert preview.eligible_group_count == 2
        assert preview.selected_group is not None
        assert preview.selected_group.group_id == g2.id
        assert preview.candidate_groups[0].group_id == g1.id
        assert "Etkin policy" in preview.message or "aktif user group" in preview.message
