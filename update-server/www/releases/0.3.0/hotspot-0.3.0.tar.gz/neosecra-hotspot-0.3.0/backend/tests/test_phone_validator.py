import pytest
from fastapi import HTTPException
from app.modules.sms.service import normalize_tr_phone

def test_phone_normalization_valid():
    assert normalize_tr_phone("5551234567") == "+905551234567"
    assert normalize_tr_phone("05551234567") == "+905551234567"
    assert normalize_tr_phone("905551234567") == "+905551234567"
    assert normalize_tr_phone("+905551234567") == "+905551234567"
    assert normalize_tr_phone("0 (555) 123 45 67") == "+905551234567"

def test_phone_normalization_invalid():
    with pytest.raises(HTTPException) as excinfo:
        normalize_tr_phone("12345")
    assert excinfo.value.status_code == 400

    with pytest.raises(HTTPException):
        normalize_tr_phone("4440333")
