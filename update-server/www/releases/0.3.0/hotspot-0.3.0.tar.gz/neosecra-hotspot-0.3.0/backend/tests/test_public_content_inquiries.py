from __future__ import annotations

from datetime import datetime, timedelta, timezone
from unittest import mock
import uuid

import pytest

from app.modules.public_content.models import PublicInquiry
from app.modules.public_content import service
from app.modules.portal.models import METHOD_VOUCHER, PortalTemplate
from app.modules.tenants.models import Tenant
from app.modules.customers.models import Customer
from app.modules.locations.models import Location
from app.modules.devices.models import Device
from app.modules.licensing.models import CustomerLicense
from app.modules.vouchers.models import STATUS_EXPIRED, STATUS_PENDING, STATUS_USED, VoucherBatch, Voucher


class _ScalarResult:
    def __init__(self, rows):
        self._rows = rows

    def scalars(self):
        return self

    def all(self):
        return self._rows


@pytest.mark.asyncio
async def test_list_public_inquiries_serializes_admin_fields():
    first = PublicInquiry(
        id=uuid.uuid4(),
        inquiry_type="partner",
        source_tab="partner",
        name="Ada Demo",
        email="ada@example.com",
        phone="+905551112233",
        company="AdaTech",
        role="dealer",
        message="Bayi portalı için demo istiyoruz.",
        status="new",
        meta={"source": "public_product_page"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    second = PublicInquiry(
        id=uuid.uuid4(),
        inquiry_type="trial",
        source_tab="partner",
        name="Mert Trial",
        email="mert@example.com",
        phone=None,
        company="MertSoft",
        role="client",
        message="Deneme ortamı talep ediyoruz.",
        status="contacted",
        meta={},
        created_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([first, second]))

    result = await service.list_public_inquiries(db, inquiry_type="partner")

    assert len(result) == 2
    assert result[0].reference_code.startswith("PQ-")
    assert result[0].company == "AdaTech"
    assert result[0].message == "Bayi portalı için demo istiyoruz."
    assert result[1].status == "contacted"


@pytest.mark.asyncio
async def test_update_public_inquiry_status_changes_status():
    inquiry = PublicInquiry(
        id=uuid.uuid4(),
        inquiry_type="contact",
        source_tab="docs",
        name="Selin",
        email="selin@example.com",
        phone=None,
        company="Selin Co",
        role="ops",
        message="Lütfen geri dönüş yapın.",
        status="new",
        meta={},
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=inquiry)
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()

    result = await service.update_public_inquiry_status(db, inquiry.id, status="contacted")

    assert inquiry.status == "contacted"
    assert result.status == "contacted"
    assert result.updated_at is not None


@pytest.mark.asyncio
async def test_provision_trial_inquiry_creates_sandbox_environment():
    inquiry = PublicInquiry(
        id=uuid.uuid4(),
        inquiry_type="trial",
        source_tab="partner",
        name="Deniz Trial",
        email="deniz@example.com",
        phone="+905551112233",
        company="Deniz Soft",
        role="client",
        message="Trial ortamı talep ediyoruz.",
        status="new",
        meta={},
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=inquiry)
    db.add = mock.Mock()
    db.add_all = mock.Mock()
    db.flush = mock.AsyncMock()
    db.commit = mock.AsyncMock()

    result = await service.provision_trial_environment(db, inquiry.id, actor_id=uuid.uuid4())

    assert result.inquiry_id == inquiry.id
    assert result.reference_code.startswith("PQ-")
    assert result.tenant_is_demo is True
    assert result.portal_method == METHOD_VOUCHER
    assert result.voucher_code is not None
    assert result.voucher_code.startswith("TRIAL-")
    assert result.lifecycle_action == "provisioned"
    assert result.renewal_count == 0
    assert result.cleaned_at is None
    assert result.cleanup_reason is None
    assert inquiry.status == "qualified"
    assert inquiry.meta["sandbox_provisioning"]["status"] == "provisioned"
    assert inquiry.meta["sandbox_provisioning"]["lifecycle_action"] == "provisioned"
    assert inquiry.meta["sandbox_provisioning"]["renewal_count"] == 0
    assert inquiry.meta["sandbox_provisioning"]["voucher_prefix"] == "TRIAL"
    assert inquiry.meta["sandbox_provisioning"]["tenant_slug"]
    created = db.add_all.call_args.args[0]
    assert any(isinstance(item, Tenant) for item in created)
    assert any(isinstance(item, Customer) for item in created)
    assert any(isinstance(item, Location) for item in created)
    assert any(isinstance(item, Device) for item in created)
    assert any(isinstance(item, PortalTemplate) for item in created)
    assert any(isinstance(item, CustomerLicense) for item in created)
    assert any(isinstance(item, VoucherBatch) for item in created)
    assert any(isinstance(item, Voucher) for item in created)


@pytest.mark.asyncio
async def test_provision_trial_inquiry_is_idempotent_when_already_provisioned():
    tenant_id = uuid.uuid4()
    customer_id = uuid.uuid4()
    location_id = uuid.uuid4()
    device_id = uuid.uuid4()
    template_id = uuid.uuid4()
    license_id = uuid.uuid4()
    voucher_batch_id = uuid.uuid4()
    provisioned_at = "2026-07-15T12:34:56+00:00"
    inquiry = PublicInquiry(
        id=uuid.uuid4(),
        inquiry_type="trial",
        source_tab="partner",
        name="Aylin Trial",
        email="aylin@example.com",
        phone="+905551112233",
        company="Aylin Soft",
        role="client",
        message="Trial ortamı zaten hazır.",
        status="qualified",
        meta={
            "sandbox_provisioning": {
                "status": "provisioned",
                "provisioned_at": provisioned_at,
                "tenant_id": str(tenant_id),
                "tenant_slug": "aylin-soft-trial",
                "tenant_name": "Aylin Soft Trial",
                "tenant_is_demo": True,
                "customer_id": str(customer_id),
                "customer_name": "Aylin Soft",
                "location_id": str(location_id),
                "location_name": "Aylin Soft Demo Site",
                "device_id": str(device_id),
                "device_name": "Aylin Soft Gateway",
                "portal_template_id": str(template_id),
                "portal_template_name": "Aylin Soft Trial Portal",
                "portal_method": METHOD_VOUCHER,
                "license_id": str(license_id),
                "license_plan": "trial",
                "license_is_trial": True,
                "license_expires_at": "2026-07-29T12:34:56+00:00",
                "voucher_batch_id": str(voucher_batch_id),
                "voucher_prefix": "TRIAL",
                "voucher_code_prefix": "TRIAL-",
                "message": "Sandbox ortamı oluşturuldu.",
            }
        },
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=inquiry)
    db.add = mock.Mock()
    db.add_all = mock.Mock()
    db.flush = mock.AsyncMock()
    db.commit = mock.AsyncMock()

    result = await service.provision_trial_environment(db, inquiry.id, actor_id=uuid.uuid4())

    assert result.voucher_code is None
    assert result.tenant_id == tenant_id
    assert result.customer_id == customer_id
    assert result.lifecycle_action == "provisioned"
    assert result.renewal_count == 0
    assert result.provisioned_at == datetime.fromisoformat(provisioned_at)
    db.add_all.assert_not_called()
    db.commit.assert_not_called()


@pytest.mark.asyncio
async def test_cleanup_expired_trial_sandboxes_deactivates_expired_environment():
    expired_tenant = Tenant(
        id=uuid.uuid4(),
        name="Expired Trial",
        slug="expired-trial",
        domain=None,
        is_root=False,
        is_demo=True,
        is_active=True,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    expired_customer = Customer(
        id=uuid.uuid4(),
        tenant_id=expired_tenant.id,
        partner_id=None,
        name="Expired Trial Co",
        contact_name="Deniz",
        contact_email="deniz@example.com",
        contact_phone="+905551112233",
        is_active=True,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    expired_location = Location(
        id=uuid.uuid4(),
        customer_id=expired_customer.id,
        name="Expired Site",
        address=None,
        city=None,
        default_ssid="expired-guest",
        timezone="Europe/Istanbul",
        is_active=True,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    expired_device = Device(
        id=uuid.uuid4(),
        location_id=expired_location.id,
        name="Expired Gateway",
        vendor="fortigate",
        model="trial-gateway",
        mgmt_ip=None,
        api_host=None,
        api_port=None,
        status="online",
        meta={"sandbox": True},
        is_active=True,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    expired_template = PortalTemplate(
        id=uuid.uuid4(),
        customer_id=expired_customer.id,
        location_id=expired_location.id,
        name="Expired Portal",
        method=METHOD_VOUCHER,
        is_default=True,
        theme={},
        fields=[],
        success_message=None,
        terms_url=None,
        meta={},
        is_active=True,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    expired_license = CustomerLicense(
        id=uuid.uuid4(),
        customer_id=expired_customer.id,
        active_guests_quota=10,
        max_sessions_per_day=20,
        session_minutes_default=60,
        expires_at=datetime(2026, 7, 10, tzinfo=timezone.utc),
        is_trial=True,
        is_radius_enterprise=False,
        is_active=True,
        plan="trial",
        meta={},
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    expired_batch = VoucherBatch(
        id=uuid.uuid4(),
        customer_id=expired_customer.id,
        location_id=expired_location.id,
        name="Expired Batch",
        prefix="TRIAL",
        count=2,
        duration_minutes=60,
        expires_at=datetime(2026, 7, 10, tzinfo=timezone.utc),
        created_by=uuid.uuid4(),
        is_active=True,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    expired_pending_voucher = Voucher(
        id=uuid.uuid4(),
        batch_id=expired_batch.id,
        code_hash="pending",
        code_prefix="TRIAL-",
        status=STATUS_PENDING,
        used_by_session_id=None,
        used_at=None,
        expires_at=expired_license.expires_at,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    expired_used_voucher = Voucher(
        id=uuid.uuid4(),
        batch_id=expired_batch.id,
        code_hash="used",
        code_prefix="TRIAL-",
        status=STATUS_USED,
        used_by_session_id=uuid.uuid4(),
        used_at=datetime(2026, 7, 9, tzinfo=timezone.utc),
        expires_at=expired_license.expires_at,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 9, tzinfo=timezone.utc),
    )
    active_inquiry = PublicInquiry(
        id=uuid.uuid4(),
        inquiry_type="trial",
        source_tab="partner",
        name="Active Trial",
        email="active@example.com",
        phone="+905551112233",
        company="Active Trial Co",
        role="client",
        message="Still active.",
        status="qualified",
        meta={
            "sandbox_provisioning": {
                "status": "provisioned",
                "provisioned_at": "2026-07-15T12:34:56+00:00",
                "tenant_id": str(uuid.uuid4()),
                "tenant_slug": "active-trial",
                "tenant_name": "Active Trial",
                "tenant_is_demo": True,
                "customer_id": str(uuid.uuid4()),
                "customer_name": "Active Trial Co",
                "location_id": str(uuid.uuid4()),
                "location_name": "Active Site",
                "device_id": str(uuid.uuid4()),
                "device_name": "Active Gateway",
                "portal_template_id": str(uuid.uuid4()),
                "portal_template_name": "Active Portal",
                "portal_method": METHOD_VOUCHER,
                "license_id": str(uuid.uuid4()),
                "license_plan": "trial",
                "license_is_trial": True,
                "license_expires_at": "2026-08-10T12:34:56+00:00",
                "voucher_batch_id": str(uuid.uuid4()),
                "voucher_prefix": "TRIAL",
                "voucher_code_prefix": "TRIAL-",
                "message": "Sandbox ortamı oluşturuldu.",
            }
        },
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )
    expired_inquiry = PublicInquiry(
        id=uuid.uuid4(),
        inquiry_type="trial",
        source_tab="partner",
        name="Expired Trial Lead",
        email="expired@example.com",
        phone="+905551112233",
        company="Expired Trial Co",
        role="client",
        message="Expired sandbox.",
        status="qualified",
        meta={
            "sandbox_provisioning": {
                "status": "provisioned",
                "provisioned_at": "2026-07-01T12:34:56+00:00",
                "tenant_id": str(expired_tenant.id),
                "tenant_slug": expired_tenant.slug,
                "tenant_name": expired_tenant.name,
                "tenant_is_demo": True,
                "customer_id": str(expired_customer.id),
                "customer_name": expired_customer.name,
                "location_id": str(expired_location.id),
                "location_name": expired_location.name,
                "device_id": str(expired_device.id),
                "device_name": expired_device.name,
                "portal_template_id": str(expired_template.id),
                "portal_template_name": expired_template.name,
                "portal_method": METHOD_VOUCHER,
                "license_id": str(expired_license.id),
                "license_plan": expired_license.plan,
                "license_is_trial": True,
                "license_expires_at": "2026-07-10T00:00:00+00:00",
                "voucher_batch_id": str(expired_batch.id),
                "voucher_prefix": expired_batch.prefix,
                "voucher_code_prefix": "TRIAL-",
                "message": "Sandbox ortamı oluşturuldu.",
            }
        },
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(side_effect=[
        _ScalarResult([expired_inquiry, active_inquiry]),
        _ScalarResult([expired_pending_voucher, expired_used_voucher]),
    ])
    lookup = {
        (Tenant, expired_tenant.id): expired_tenant,
        (Customer, expired_customer.id): expired_customer,
        (Location, expired_location.id): expired_location,
        (Device, expired_device.id): expired_device,
        (PortalTemplate, expired_template.id): expired_template,
        (CustomerLicense, expired_license.id): expired_license,
        (VoucherBatch, expired_batch.id): expired_batch,
    }

    async def _get(model, ident):
        return lookup.get((model, ident))

    db.get = mock.AsyncMock(side_effect=_get)
    db.add = mock.Mock()
    db.flush = mock.AsyncMock()
    db.commit = mock.AsyncMock()

    result = await service.cleanup_expired_trial_sandboxes(
        db,
        now=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    assert result == {"due": 2, "cleaned": 1, "skipped": 0}
    assert expired_inquiry.status == "archived"
    assert expired_inquiry.meta["sandbox_provisioning"]["status"] == "cleaned_up"
    assert expired_inquiry.meta["sandbox_provisioning"]["lifecycle_action"] == "cleaned_up"
    assert expired_inquiry.meta["sandbox_provisioning"]["cleanup_reason"] == "license_expired"
    assert expired_tenant.is_active is False
    assert expired_customer.is_active is False
    assert expired_location.is_active is False
    assert expired_device.is_active is False
    assert expired_device.status == "offline"
    assert expired_template.is_active is False
    assert expired_license.is_active is False
    assert expired_batch.is_active is False
    assert expired_pending_voucher.status == STATUS_EXPIRED
    assert expired_used_voucher.status == STATUS_USED
    assert active_inquiry.status == "qualified"
    assert active_inquiry.meta["sandbox_provisioning"]["status"] == "provisioned"
    assert db.commit.await_count == 1


@pytest.mark.asyncio
async def test_renew_trial_environment_reactivates_cleaned_up_sandbox():
    previous_license_expires_at = datetime(2026, 7, 10, tzinfo=timezone.utc)
    cleaned_at = "2026-07-15T08:00:00+00:00"
    tenant = Tenant(
        id=uuid.uuid4(),
        name="Renewed Trial",
        slug="renewed-trial",
        domain=None,
        is_root=False,
        is_demo=True,
        is_active=False,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    customer = Customer(
        id=uuid.uuid4(),
        tenant_id=tenant.id,
        partner_id=None,
        name="Renewed Trial Co",
        contact_name="Deniz",
        contact_email="deniz@example.com",
        contact_phone="+905551112233",
        is_active=False,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    location = Location(
        id=uuid.uuid4(),
        customer_id=customer.id,
        name="Renewed Site",
        address=None,
        city=None,
        default_ssid="renewed-guest",
        timezone="Europe/Istanbul",
        is_active=False,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    device = Device(
        id=uuid.uuid4(),
        location_id=location.id,
        name="Renewed Gateway",
        vendor="fortigate",
        model="trial-gateway",
        mgmt_ip=None,
        api_host=None,
        api_port=None,
        status="offline",
        meta={"sandbox": True},
        is_active=False,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    template = PortalTemplate(
        id=uuid.uuid4(),
        customer_id=customer.id,
        location_id=location.id,
        name="Renewed Portal",
        method=METHOD_VOUCHER,
        is_default=True,
        theme={},
        fields=[],
        success_message=None,
        terms_url=None,
        meta={},
        is_active=False,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    license_row = CustomerLicense(
        id=uuid.uuid4(),
        customer_id=customer.id,
        active_guests_quota=10,
        max_sessions_per_day=20,
        session_minutes_default=60,
        expires_at=previous_license_expires_at,
        is_trial=True,
        is_radius_enterprise=False,
        is_active=False,
        plan="trial",
        meta={},
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    old_batch = VoucherBatch(
        id=uuid.uuid4(),
        customer_id=customer.id,
        location_id=location.id,
        name="Renewed Batch",
        prefix="TRIAL",
        count=2,
        duration_minutes=90,
        expires_at=previous_license_expires_at,
        created_by=uuid.uuid4(),
        is_active=False,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    pending_voucher = Voucher(
        id=uuid.uuid4(),
        batch_id=old_batch.id,
        code_hash="pending",
        code_prefix="TRIAL-",
        status=STATUS_PENDING,
        used_by_session_id=None,
        used_at=None,
        expires_at=previous_license_expires_at,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )
    used_voucher = Voucher(
        id=uuid.uuid4(),
        batch_id=old_batch.id,
        code_hash="used",
        code_prefix="TRIAL-",
        status=STATUS_USED,
        used_by_session_id=uuid.uuid4(),
        used_at=datetime(2026, 7, 9, tzinfo=timezone.utc),
        expires_at=previous_license_expires_at,
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 9, tzinfo=timezone.utc),
    )
    inquiry = PublicInquiry(
        id=uuid.uuid4(),
        inquiry_type="trial",
        source_tab="partner",
        name="Renewed Trial Lead",
        email="renewed@example.com",
        phone="+905551112233",
        company="Renewed Trial Co",
        role="client",
        message="Sandbox cleanup sonrası yenileme.",
        status="archived",
        meta={
            "sandbox_provisioning": {
                "status": "cleaned_up",
                "lifecycle_action": "cleaned_up",
                "renewal_count": 0,
                "renewed_at": None,
                "previous_license_expires_at": previous_license_expires_at.isoformat(),
                "cleaned_at": cleaned_at,
                "cleanup_reason": "license_expired",
                "provisioned_at": "2026-07-01T12:34:56+00:00",
                "tenant_id": str(tenant.id),
                "tenant_slug": tenant.slug,
                "tenant_name": tenant.name,
                "tenant_is_demo": True,
                "customer_id": str(customer.id),
                "customer_name": customer.name,
                "location_id": str(location.id),
                "location_name": location.name,
                "device_id": str(device.id),
                "device_name": device.name,
                "portal_template_id": str(template.id),
                "portal_template_name": template.name,
                "portal_method": METHOD_VOUCHER,
                "license_id": str(license_row.id),
                "license_plan": license_row.plan,
                "license_is_trial": True,
                "license_expires_at": previous_license_expires_at.isoformat(),
                "voucher_batch_id": str(old_batch.id),
                "voucher_prefix": old_batch.prefix,
                "voucher_code_prefix": "TRIAL-",
                "message": "Sandbox ortamı oluşturuldu.",
            }
        },
        created_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 1, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(side_effect=lambda model, ident: {
        (PublicInquiry, inquiry.id): inquiry,
        (Tenant, tenant.id): tenant,
        (Customer, customer.id): customer,
        (Location, location.id): location,
        (Device, device.id): device,
        (PortalTemplate, template.id): template,
        (CustomerLicense, license_row.id): license_row,
        (VoucherBatch, old_batch.id): old_batch,
    }.get((model, ident)))
    db.execute = mock.AsyncMock(return_value=_ScalarResult([pending_voucher, used_voucher]))
    db.add = mock.Mock()
    db.add_all = mock.Mock()
    db.commit = mock.AsyncMock()

    result = await service.renew_trial_environment(db, inquiry.id, actor_id=uuid.uuid4())

    assert result.inquiry_id == inquiry.id
    assert result.lifecycle_action == "renewed"
    assert result.renewal_count == 1
    assert result.inquiry_status == "qualified"
    assert result.voucher_code is not None
    assert result.voucher_code.startswith("TRIAL-")
    assert result.previous_license_expires_at == previous_license_expires_at
    assert result.license_expires_at is not None
    assert result.license_expires_at >= previous_license_expires_at + timedelta(days=14)
    assert inquiry.status == "qualified"
    assert inquiry.meta["sandbox_provisioning"]["status"] == "provisioned"
    assert inquiry.meta["sandbox_provisioning"]["lifecycle_action"] == "renewed"
    assert inquiry.meta["sandbox_provisioning"]["renewal_count"] == 1
    assert inquiry.meta["sandbox_provisioning"]["previous_license_expires_at"] == previous_license_expires_at.isoformat()
    assert inquiry.meta["sandbox_provisioning"]["cleaned_at"] == cleaned_at
    assert tenant.is_active is True
    assert customer.is_active is True
    assert location.is_active is True
    assert device.is_active is True
    assert device.status == "unknown"
    assert template.is_active is True
    assert license_row.is_active is True
    assert license_row.expires_at == result.license_expires_at
    assert old_batch.is_active is False
    assert pending_voucher.status == STATUS_EXPIRED
    assert used_voucher.status == STATUS_USED
    created = db.add_all.call_args.args[0]
    assert any(isinstance(item, VoucherBatch) for item in created)
    assert any(isinstance(item, Voucher) for item in created)
    assert db.commit.await_count == 1
