"""Search export bundle tests."""
from __future__ import annotations

import io
import json
import zipfile
import uuid
from datetime import datetime, timezone

from app.modules.search.schemas import SearchHit, SearchQuery, SearchResult
from app.modules.search.service import build_firewall_logs_export_bundle


def test_build_firewall_logs_export_bundle_contains_manifest_and_csv():
    customer_id = uuid.uuid4()
    result = SearchResult(
        hits=[
            SearchHit(
                timestamp="2026-07-13T10:15:00+00:00",
                customer_id=str(customer_id),
                location_id="loc-1",
                device_id="dev-1",
                facility="local0",
                severity=4,
                hostname="fortigate-fw-1",
                source_ip="10.0.0.15",
                dest_ip="1.1.1.1",
                mac="AA:BB:CC:DD:EE:FF",
                username="demo.user",
                domain="corp.local",
                application="vpn",
                action="deny",
                message="VPN login failed",
                session_id="sess-123",
                source="clickhouse",
            )
        ],
        total=1,
        limit=5000,
        offset=0,
        source="mixed",
    )
    query = SearchQuery(
        customer_id=str(customer_id),
        q="failed",
        severity_min=4,
        severity_max=4,
        correlation_window_minutes=45,
        limit=5000,
        offset=0,
    )

    bundle, filename = build_firewall_logs_export_bundle(
        result,
        query,
        context={"vendor": "Fortinet", "severity": "warning"},
        generated_at=datetime(2026, 7, 13, 12, 30, tzinfo=timezone.utc),
    )

    assert filename == "firewall-logs-export-20260713-123000.zip"

    with zipfile.ZipFile(io.BytesIO(bundle), "r") as archive:
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
        csv_text = archive.read("results.csv").decode("utf-8-sig")
        readme = archive.read("README.txt").decode("utf-8")

    assert manifest["row_count"] == 1
    assert manifest["context"]["vendor"] == "Fortinet"
    assert manifest["correlation_rule"]["window_minutes"] == 45
    assert manifest["correlation_summary"]
    assert "VPN login failed" in csv_text
    assert "Rows exported: 1" in readme
    assert "Correlation window: 45 minutes" in readme
    assert "Correlation groups:" in readme
    assert "Firewall Logs Evidence Bundle" in readme
