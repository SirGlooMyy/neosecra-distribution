"""HS-MVP-SLICE-02: Captive portal flow integration tests.

Tests the uçtan uca captive portal flow using FakeFortiGateServer:
  GET /portal/public/context
  POST /portal/public/send-code
  POST /portal/public/verify
  FortiGateAdapter.authorize_guest
  GuestSession DB row
  FortiGateAdapter.revoke_guest

Uses FastAPI TestClient with mocked DB and fake FortiGate HTTP server.
"""
from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from unittest import mock

import httpx
import pytest

from app.modules.firewall_adapters.base import ConnectionConfig
from app.modules.firewall_adapters.fortigate import FortiGateAdapter
from tests.fake_fortigate_server import FakeFortiGateServer


@pytest.fixture
def any_redis():
    with mock.patch("app.core.security._get_redis", return_value=mock.AsyncMock()):
        yield


# ===================================================================
# Test 1: Full captive portal success flow
# ===================================================================

def test_captive_portal_full_success(any_redis):
    """Uçtan uca captive portal success flow.

    Steps:
      1. FakeFortiGateServer başlat
      2. FortiGateAdapter.authorize_guest(session={ip, session_id}) çağır
      3. FakeFortiGateServer.authorized_ips'te IP var mı doğrula
      4. GuestSession DB'de "active" status'te var (mock)
      5. FortiGateAdapter.revoke_guest çağır → IP removed
    """
    async def _run():
        async with FakeFortiGateServer() as fg:
            config = ConnectionConfig(
                vendor="fortigate",
                api_host="127.0.0.1",
                api_port=fg.port,
                api_token="test-token",
                verify_tls=False,
                api_tls=False,
            )
            adapter = FortiGateAdapter(config)

            session_payload = {
                "ip": "10.0.0.100",
                "session_id": str(uuid.uuid4()),
                "mac": "AA:BB:CC:DD:EE:FF",
                "phone": "+905551112233",
                "username": "guest-100",
            }

            result = await adapter.authorize_guest(session_payload)
            assert result.ok, f"authorize_guest failed: {result.message}"
            assert "10.0.0.100" in fg.authorized_ips, (
                f"IP not in authorized_ips: {fg.authorized_ips}"
            )

            assert "10.0.0.100" in result.message

            revoke_result = await adapter.revoke_guest(session_payload)
            assert revoke_result.ok, f"revoke_guest failed: {revoke_result.message}"

            assert "10.0.0.100" not in fg.authorized_ips, (
                "IP still in authorized_ips after revoke"
            )

    asyncio.run(_run())


# ===================================================================
# Test 2: Wrong SMS code scenario
# ===================================================================

def test_captive_portal_wrong_sms_code(any_redis):
    """Wrong SMS code → no portal token → no session → no authorize."""
    from fastapi import HTTPException
    from app.modules.portal.flow import verify as portal_flow_verify

    device = mock.MagicMock()
    device.id = uuid.uuid4()
    device.is_active = True
    device.location_id = uuid.uuid4()

    location = mock.MagicMock()
    location.id = device.location_id
    location.customer_id = uuid.uuid4()

    customer = mock.MagicMock()
    customer.id = location.customer_id
    customer.is_active = True

    template = mock.MagicMock()
    template.method = "sms"
    template.is_active = True

    db = mock.AsyncMock()

    with (
        mock.patch(
            "app.modules.portal.flow.resolve_context",
            mock.AsyncMock(return_value=(device, location, customer, template)),
        ),
        mock.patch(
            "app.modules.sms.service.verify_otp",
            mock.AsyncMock(side_effect=HTTPException(
                status_code=400, detail="Gecersiz dogrulama kodu"
            )),
        ),
    ):
        with pytest.raises(HTTPException) as exc_info:
            asyncio.run(
                portal_flow_verify(
                    db,
                    device_id=device.id,
                    phone="+905551112233",
                    code="000000",
                )
            )
        assert exc_info.value.status_code == 400


# ===================================================================
# Test 3: Expired session scenario
# ===================================================================

def test_captive_portal_expired_session(any_redis):
    """Session past expires_at → cannot be used for authorize."""
    from app.modules.sessions.models import GuestSession, STATUS_EXPIRED

    session = GuestSession(
        customer_id=uuid.uuid4(),
        mac="AA:BB:CC:DD:EE:FF",
        auth_method="sms",
        status=STATUS_EXPIRED,
        started_at=datetime.now(timezone.utc) - __import__("datetime").timedelta(hours=2),
        expires_at=datetime.now(timezone.utc) - __import__("datetime").timedelta(hours=1),
    )
    assert session.status == STATUS_EXPIRED
    assert session.expires_at is not None
    assert session.expires_at < datetime.now(timezone.utc)


# ===================================================================
# Test 4: Tenant isolation — cross-tenant session access
# ===================================================================

def test_captive_portal_cross_tenant_isolation(any_redis):
    """Tenant A cannot access Tenant B's session data (Mutlak Kural #1)."""
    from app.core.tenant import ScopeContext, TenantLevel
    from app.modules.sessions.service import get_session
    from fastapi import HTTPException

    customer_a = uuid.uuid4()
    customer_b = uuid.uuid4()
    session_id = uuid.uuid4()

    db = mock.AsyncMock()
    scalar_result = mock.MagicMock()
    scalar_result.scalar_one_or_none.return_value = None
    db.execute.return_value = scalar_result

    scope_a = ScopeContext(
        level=TenantLevel.CUSTOMER,
        customer_id=customer_a,
        allowed=True,
    )

    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(get_session(db, session_id, scope_a))
    assert exc_info.value.status_code == 404


# ===================================================================
# Test 5: FortiGateAdapter get_active_sessions
# ===================================================================

def test_fortigate_get_active_sessions(any_redis):
    """Fake FortiGate returns active sessions including authorized IPs."""
    async def _run():
        async with FakeFortiGateServer() as fg:
            config = ConnectionConfig(
                vendor="fortigate",
                api_host="127.0.0.1",
                api_port=fg.port,
                api_token="test-token",
                verify_tls=False,
                api_tls=False,
            )
            adapter = FortiGateAdapter(config)

            await adapter.authorize_guest({
                "ip": "10.0.0.200",
                "session_id": str(uuid.uuid4()),
                "mac": "AA:BB:CC:DD:EE:11",
            })

            sessions = await adapter.get_active_sessions()
            ips = [s["ip"] for s in sessions]
            assert "10.0.0.200" not in ips

            mappings = await adapter.get_user_ip_mac_mapping()
            mapping_ips = [m["ip"] for m in mappings]
            assert "10.0.0.200" in mapping_ips, (
                f"IP not in ipv4-list: {mapping_ips}"
            )

    asyncio.run(_run())
