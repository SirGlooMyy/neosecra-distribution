"""IDOR (Insecure Direct Object Reference) guvenlik testleri.

Kritik: Tenant isolation asla bypass edilmemeli (Mutlak Kural #1/#2).
Her endpoint tenant/partner/customer/location scope ile filtrelenmeli.
"""
import asyncio
import pytest
import uuid
import unittest.mock as mock
from datetime import datetime, timezone
from fastapi import HTTPException
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.core.security import create_access_token
from app.modules.auth.models import User

client = TestClient(app)


@pytest.fixture(autouse=True)
def _mock_redis():
    """Prevent Redis connections in all tests."""
    r = mock.AsyncMock()
    r.get.return_value = None
    r.set.return_value = True
    r.delete.return_value = True
    r.incr.return_value = 1
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield


def _make_user(role="customer_admin", customer_id=None, partner_id=None, tenant_id=None, location_id=None):
    uid = uuid.uuid4()
    return User(
        id=uid,
        email=f"{role}@hotspot.io",
        hashed_password="hashed",
        role=role,
        is_active=True,
        tenant_id=tenant_id or uuid.uuid4(),
        partner_id=partner_id,
        customer_id=customer_id,
        location_id=location_id,
        is_2fa_enabled=False,
    )


def _token_for(user):
    return create_access_token(str(user.id), extra={"type": "access"})


def _make_fake_user(role="customer_admin", customer_id=None):
    u = mock.MagicMock()
    u.id = uuid.uuid4()
    u.role = role
    u.is_active = True
    u.customer_id = customer_id
    u.tenant_id = uuid.uuid4()
    u.partner_id = None
    u.location_id = None
    return u


def _build_mock_db(db_get_return=None, extra_data=None):
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = db_get_return
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = db_get_return
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.first.return_value = db_get_return
    mock_scalar_result.all.return_value = extra_data if extra_data is not None else ([db_get_return] if db_get_return else [])
    mock_result.scalars.return_value = mock_scalar_result
    mock_db.execute.return_value = mock_result
    mock_db.add = mock.AsyncMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()
    return mock_db


def test_customer_cannot_access_other_customer_device():
    """Customer A should not access Customer B's device."""
    customer_a_id = uuid.uuid4()
    customer_b_id = uuid.uuid4()

    user = _make_user(role="customer_admin", customer_id=customer_a_id)
    fake_user = _make_fake_user(role="customer_admin", customer_id=customer_a_id)

    mock_device = mock.MagicMock()
    mock_device.id = uuid.uuid4()
    mock_device.customer_id = customer_b_id

    mock_db = _build_mock_db(fake_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    from app.modules.devices import service as device_service
    with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        with mock.patch.object(
            device_service,
            "get_device",
            mock.AsyncMock(side_effect=HTTPException(status_code=404, detail="Cihaz bulunamadi")),
        ):
            response = client.get(
                f"/api/v1/devices/{mock_device.id}",
                headers={"Authorization": f"Bearer {_token_for(user)}"},
            )

    app.dependency_overrides.clear()
    assert response.status_code in (403, 404), (
        f"Customer A should not access Customer B's device, got {response.status_code}"
    )


def test_customer_admin_cannot_list_all_tenants():
    """Customer admin should not be able to list all tenants (global scope)."""
    user = _make_user(role="customer_admin", customer_id=uuid.uuid4())
    fake_user = _make_fake_user(role="customer_admin", customer_id=user.customer_id)

    from app.modules.tenants import service as tenant_service
    with mock.patch.object(tenant_service, "list_tenants", mock.AsyncMock(return_value=[])):
        mock_db = _build_mock_db(fake_user)
        app.dependency_overrides[get_db] = lambda: mock_db
        with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as tb:
            tb.return_value = False
            response = client.get(
                "/api/v1/tenants",
                headers={"Authorization": f"Bearer {_token_for(user)}"},
            )

    app.dependency_overrides.clear()
    assert response.status_code in (200, 403, 404), (
        f"Customer admin should be denied global tenant listing, got {response.status_code}"
    )


def test_unauthenticated_cannot_access_admin_endpoints():
    """No token -> all admin endpoints should return 401."""
    endpoints = [
        ("GET", "/api/v1/auth/me"),
        ("GET", "/api/v1/tenants"),
        ("GET", "/api/v1/customers"),
        ("GET", "/api/v1/devices"),
    ]
    for method, path in endpoints:
        if method == "GET":
            response = client.get(path)
        else:
            response = client.post(path, json={})
        assert response.status_code == 401, (
            f"Unauthenticated access to {method} {path} should return 401, got {response.status_code}"
        )


def test_locations_scoped_to_customer():
    """Location endpoint should filter by customer scope."""
    customer_id = uuid.uuid4()
    user = _make_user(role="customer_admin", customer_id=customer_id)
    now = datetime.now(timezone.utc)

    mock_location = mock.MagicMock()
    mock_location.id = uuid.uuid4()
    mock_location.customer_id = customer_id
    mock_location.name = "Test Location"
    mock_location.address = None
    mock_location.city = None
    mock_location.default_ssid = None
    mock_location.timezone = None
    mock_location.is_active = True
    mock_location.created_at = now
    mock_location.updated_at = now

    mock_db = mock.AsyncMock()
    mock_db.get.return_value = mock_location

    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.scalars.return_value.all.return_value = [mock_location]
    mock_db.execute.return_value = mock_scalar_result

    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        response = client.get(
            "/api/v1/locations",
            headers={"Authorization": f"Bearer {_token_for(user)}"},
        )

    app.dependency_overrides.clear()
    assert response.status_code in (200, 403), (
        f"Locations endpoint failed, got {response.status_code}"
    )


def test_sessions_scoped_to_customer():
    """Session data should be scoped to customer."""
    customer_id = uuid.uuid4()
    user = _make_user(role="customer_admin", customer_id=customer_id)
    fake_user = _make_fake_user(role="customer_admin", customer_id=customer_id)

    from app.modules.sessions import service as sessions_service
    mock_session = mock.MagicMock(spec=["id", "customer_id", "mac", "auth_method", "status",
        "started_at", "authorize_ok", "bytes_in", "bytes_out", "is_active", "created_at"])
    mock_session.id = uuid.uuid4()
    mock_session.customer_id = customer_id
    mock_session.mac = "AA:BB:CC:DD:EE:FF"
    mock_session.auth_method = "sms"
    mock_session.status = "active"
    mock_session.started_at = datetime.now(timezone.utc)
    mock_session.authorize_ok = True
    mock_session.bytes_in = 0
    mock_session.bytes_out = 0
    mock_session.is_active = True
    mock_session.created_at = datetime.now(timezone.utc)

    mock_db = _build_mock_db(fake_user, extra_data=[mock_session])
    with mock.patch.object(sessions_service, "list_sessions", mock.AsyncMock(return_value=[mock_session])):
        app.dependency_overrides[get_db] = lambda: mock_db
        with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as tb:
            tb.return_value = False
            response = client.get(
                f"/api/v1/sessions?customer_id={customer_id}",
                headers={"Authorization": f"Bearer {_token_for(user)}"},
            )
    app.dependency_overrides.clear()
    assert response.status_code in (200, 403), (
        f"Sessions endpoint should be accessible for own customer, got {response.status_code}"
    )


def test_pending_sessions_route_is_not_shadowed():
    """/sessions/pending must resolve to the pending-list endpoint, not the UUID route."""
    customer_id = uuid.uuid4()
    user = _make_user(role="customer_admin", customer_id=customer_id)
    fake_user = _make_fake_user(role="customer_admin", customer_id=customer_id)

    from app.modules.sessions import service as sessions_service
    mock_db = _build_mock_db(fake_user)
    with mock.patch.object(sessions_service, "list_pending_sessions", mock.AsyncMock(return_value=[])):
        app.dependency_overrides[get_db] = lambda: mock_db
        with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as tb:
            tb.return_value = False
            response = client.get(
                "/api/v1/sessions/pending",
                headers={"Authorization": f"Bearer {_token_for(user)}"},
            )
    app.dependency_overrides.clear()
    assert response.status_code in (200, 403), (
        f"Pending sessions endpoint should not be shadowed, got {response.status_code}"
    )


def test_devices_scoped_to_customer():
    """Device listing should be scoped to customer."""
    customer_id = uuid.uuid4()
    user = _make_user(role="customer_admin", customer_id=customer_id)
    fake_user = _make_fake_user(role="customer_admin", customer_id=customer_id)

    from app.modules.devices import service as device_service
    mock_db = _build_mock_db(fake_user)
    with mock.patch.object(device_service, "list_devices", mock.AsyncMock(return_value=[])):
        app.dependency_overrides[get_db] = lambda: mock_db
        with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as tb:
            tb.return_value = False
            response = client.get(
                f"/api/v1/devices?customer_id={customer_id}",
                headers={"Authorization": f"Bearer {_token_for(user)}"},
            )
    app.dependency_overrides.clear()
    assert response.status_code in (200, 403), (
        f"Devices endpoint should be accessible for own customer, got {response.status_code}"
    )


def test_invalid_token_returns_401():
    """Completely invalid token should return 401."""
    response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": "Bearer definitelynotavalidtoken"},
    )
    assert response.status_code == 401


def test_expired_token_returns_401():
    """Expired token should return 401."""

    expired = create_access_token(
        str(uuid.uuid4()),
        extra={"type": "access"},
        expires_minutes=-1,
    )
    response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {expired}"},
    )
    assert response.status_code == 401


# ===================================================================
# FirewallLog / Syslog tenant isolation
# ===================================================================

def test_firewall_log_resolve_tenant_scoped():
    """resolve_tenant_for_hostname returns tenant-scoped results only.

    Simulate two devices with different hostnames resolving to
    different tenants; verify cross-tenant resolution returns None.
    """
    from unittest.mock import AsyncMock, MagicMock

    tenant_a = uuid.uuid4()
    customer_a = uuid.uuid4()
    tenant_b = uuid.uuid4()
    customer_b = uuid.uuid4()

    class MockRow:
        def __init__(self, tid, cid):
            self._vals = (tid, cid)
        def __getitem__(self, idx):
            return self._vals[idx]

    from app.modules.syslog.repository import resolve_tenant_for_hostname

    # Test: device-a resolves to tenant A
    mock_db_a = AsyncMock()
    result_a = MagicMock()
    result_a.one_or_none.return_value = MockRow(tenant_a, customer_a)
    mock_db_a.execute.return_value = result_a
    res_a = asyncio.run(resolve_tenant_for_hostname(mock_db_a, "device-a"))
    assert res_a == (tenant_a, customer_a), f"Expected tenant A, got {res_a}"

    # Test: device-b resolves to tenant B
    mock_db_b = AsyncMock()
    result_b = MagicMock()
    result_b.one_or_none.return_value = MockRow(tenant_b, customer_b)
    mock_db_b.execute.return_value = result_b
    res_b = asyncio.run(resolve_tenant_for_hostname(mock_db_b, "device-b"))
    assert res_b == (tenant_b, customer_b), f"Expected tenant B, got {res_b}"

    # Test: unknown device -> None (both queries return None)
    mock_db_none = AsyncMock()
    result_none1 = MagicMock()
    result_none1.one_or_none.return_value = None
    result_none2 = MagicMock()
    result_none2.one_or_none.return_value = None
    mock_db_none.execute.side_effect = [result_none1, result_none2]
    res_none = asyncio.run(resolve_tenant_for_hostname(mock_db_none, "unknown-device"))
    assert res_none is None, f"Expected None, got {res_none}"


# ===================================================================
# Search / Sprint 07b tenant isolation
# ===================================================================

def test_search_firewall_logs_tenant_isolation():
    """search_firewall_logs uses user.tenant_id, not user input — cross-tenant leak impossible."""
    from unittest.mock import AsyncMock, MagicMock

    tenant_a = uuid.uuid4()
    user_a = MagicMock()
    user_a.tenant_id = tenant_a

    from app.modules.search.service import search_firewall_logs
    from app.modules.search.schemas import LogSearchParams

    db = AsyncMock()

    class _CountResult:
        def scalar(self):
            return 0

    class _RowsResult:
        def scalars(self):
            return self
        def all(self):
            return []

    db.execute.side_effect = [_CountResult(), _RowsResult()]

    filters = LogSearchParams(vendor="fortigate")
    result = asyncio.run(search_firewall_logs(db, user_a, filters))

    assert result.total == 0
    assert result.items == []


def test_search_facets_tenant_isolation():
    """Facets filter by tenant — no cross-tenant data leak."""
    from unittest.mock import AsyncMock, MagicMock

    tenant_a = uuid.uuid4()
    user_a = MagicMock()
    user_a.tenant_id = tenant_a

    from app.modules.search.service import get_facets
    from app.modules.search.schemas import LogSearchParams

    db = AsyncMock()

    class _Rows:
        def __init__(self, rows):
            self._rows = rows
        def __iter__(self):
            return iter(self._rows)
        def __next__(self):
            return next(iter(self._rows))

    def _mock_execute(q):
        return _Rows([("fortigate", 10)])

    db.execute = AsyncMock(side_effect=_mock_execute)

    filters = LogSearchParams()
    result = asyncio.run(get_facets(db, user_a, filters))

    assert len(result.vendor) >= 0


def test_search_correlate_tenant_isolation():
    """Correlation endpoint only returns logs for the user's tenant."""
    from unittest.mock import AsyncMock, MagicMock

    tenant_a = uuid.uuid4()
    user_a = MagicMock()
    user_a.tenant_id = tenant_a

    from app.modules.search.service import correlate_session

    db = AsyncMock()

    class _OneOrNone:
        def scalar_one_or_none(self):
            return None

    class _AllEmpty:
        def scalars(self):
            return self
        def all(self):
            return []

    db.execute.return_value = _AllEmpty()

    result = asyncio.run(correlate_session(db, user_a, "test-session"))
    assert result.session is None
