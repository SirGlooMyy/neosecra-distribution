import pytest
import uuid
from unittest import mock
from app.modules.vouchers.service import redeem
from app.modules.vouchers.models import Voucher


@pytest.mark.asyncio
async def test_mock_voucher_redeem():
    mock_customer_id = uuid.uuid4()
    with mock.patch("app.modules.vouchers.service.redeem") as mock_redeem:
        mock_redeem.return_value = Voucher(
            id=uuid.uuid4(),
            batch_id=uuid.uuid4(),
            code_hash="mock_hash",
            status="used",
        )
        voucher = await mock_redeem(mock.AsyncMock(), code="DEMO2026", customer_id=mock_customer_id)
        assert voucher is not None
        assert voucher.status == "used"


@pytest.mark.asyncio
async def test_real_voucher_fallthrough():
    mock_customer_id = uuid.uuid4()
    with pytest.raises(Exception):
        await redeem(None, code="INVALID123", customer_id=mock_customer_id)
