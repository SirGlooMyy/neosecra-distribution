"""MFA (Multi-Factor Authentication) servis testleri."""
import pytest
import uuid
import unittest.mock as mock
from fastapi import HTTPException

from app.modules.mfa.service import (
    setup_totp,
    verify_totp,
    verify_backup_code,
    send_mfa_code,
    verify_mfa_code,
    get_mfa_status,
    _generate_code,
    _hash_code,
    _constant_time_eq,
    _backup_code,
)


def test_generate_code_length():
    code = _generate_code()
    assert len(code) == 6
    assert code.isdigit()


def test_generate_code_custom_length():
    code = _generate_code(length=8)
    assert len(code) == 8
    assert code.isdigit()


def test_constant_time_eq():
    assert _constant_time_eq("abc123", "abc123") is True
    assert _constant_time_eq("abc123", "xyz789") is False
    assert _constant_time_eq("", "") is True


def test_hash_code():
    h1 = _hash_code("test123")
    h2 = _hash_code("test123")
    assert h1 == h2
    assert isinstance(h1, str)
    assert len(h1) == 64


def test_backup_code_format():
    code = _backup_code()
    assert len(code) == 12
    assert all(c in "0123456789abcdef" for c in code)


@pytest.mark.asyncio
async def test_setup_totp_returns_secret(monkeypatch):
    """Setup should return secret, qr_uri and backup codes."""
    user_id = uuid.uuid4()

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = None
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)
    mock_db.flush = mock.AsyncMock()

    monkeypatch.setattr("app.modules.mfa.service.settings.DEMO_MODE", True)

    result = await setup_totp(mock_db, user_id, request=None)

    assert "secret" in result
    assert "qr_code_uri" in result
    assert "backup_codes" in result
    assert len(result["backup_codes"]) == 8


@pytest.mark.asyncio
async def test_setup_totp_without_pyotp_and_no_demo_fails_closed(monkeypatch):
    user_id = uuid.uuid4()
    monkeypatch.setattr("app.modules.mfa.service.settings.DEMO_MODE", False)
    monkeypatch.setattr("app.modules.mfa.service.HAS_PYOTP", False)

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = None
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    with pytest.raises(HTTPException) as exc:
        await setup_totp(mock_db, user_id, request=None)
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_setup_totp_twice_raises():
    """Second setup should raise 409."""
    user_id = uuid.uuid4()

    mock_existing = mock.AsyncMock()
    mock_existing.user_id = user_id
    mock_existing.mfa_type = "totp"
    mock_existing.is_active = True

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = mock_existing
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    with pytest.raises(HTTPException) as exc:
        await setup_totp(mock_db, user_id)
    assert exc.value.status_code == 409
    assert "zaten aktif" in exc.value.detail


@pytest.mark.asyncio
async def test_verify_totp_invalid():
    """Verify with no active TOTP should raise 400."""
    user_id = uuid.uuid4()

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = None
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    with pytest.raises(HTTPException) as exc:
        await verify_totp(mock_db, user_id, code="123456")
    assert exc.value.status_code == 400
    assert "aktif degil" in exc.value.detail


def test_backup_codes_generation():
    codes = [_backup_code() for _ in range(8)]
    assert len(codes) == 8
    assert len(set(codes)) == 8


@pytest.mark.asyncio
async def test_verify_backup_code_not_found():
    """Verify backup code with no token should raise 400."""
    user_id = uuid.uuid4()

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.first.return_value = None
    mock_scalar.scalars.return_value = mock_scalar_result
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    with pytest.raises(HTTPException) as exc:
        await verify_backup_code(mock_db, user_id, code="test123")
    assert exc.value.status_code == 400
    assert "Yedek kod" in exc.value.detail


@pytest.mark.asyncio
async def test_get_mfa_status_no_user():
    """Status should return defaults when no user/token found."""
    user_id = uuid.uuid4()

    mock_db = mock.AsyncMock()
    mock_db.get = mock.AsyncMock(return_value=None)
    mock_scalar = mock.MagicMock()
    mock_scalar.all.return_value = []
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    status = await get_mfa_status(mock_db, user_id)
    assert status["mfa_required"] is False
    assert status["methods"] == []
    assert status["active_tokens"] == []


@pytest.mark.asyncio
async def test_send_mfa_code_invalid_method():
    """Unsupported method should raise 400."""
    user_id = uuid.uuid4()
    mock_db = mock.AsyncMock()

    with pytest.raises(HTTPException) as exc:
        await send_mfa_code(mock_db, user_id, method="invalid")
    assert exc.value.status_code == 400
    assert "Desteklenmeyen" in exc.value.detail


@pytest.mark.asyncio
async def test_send_mfa_code_email_uses_real_delivery(monkeypatch):
    monkeypatch.setattr("app.modules.mfa.service.settings.DEMO_MODE", False)
    user_id = uuid.uuid4()
    customer_id = uuid.uuid4()
    mock_user = mock.MagicMock()
    mock_user.id = user_id
    mock_user.email = "user@example.com"
    mock_user.customer_id = customer_id

    mock_db = mock.AsyncMock()
    mock_db.get = mock.AsyncMock(return_value=mock_user)
    mock_db.add = mock.MagicMock()
    mock_db.flush = mock.AsyncMock()

    with mock.patch(
        "app.modules.system.email_service.send_email",
        new=mock.AsyncMock(return_value=True),
    ) as mock_send_email:
        token = await send_mfa_code(mock_db, user_id, method="email")

    assert token
    mock_send_email.assert_awaited_once()
    assert mock_send_email.await_args.kwargs["to"] == "user@example.com"


@pytest.mark.asyncio
async def test_send_mfa_code_sms_fails_closed_without_demo(monkeypatch):
    monkeypatch.setattr("app.modules.mfa.service.settings.DEMO_MODE", False)
    user_id = uuid.uuid4()

    mock_user = mock.MagicMock()
    mock_user.id = user_id
    mock_user.email = "user@example.com"
    mock_user.customer_id = uuid.uuid4()

    mock_db = mock.AsyncMock()
    mock_db.get = mock.AsyncMock(return_value=mock_user)
    mock_db.add = mock.MagicMock()
    mock_db.flush = mock.AsyncMock()

    with pytest.raises(HTTPException) as exc:
        await send_mfa_code(mock_db, user_id, method="sms")
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_verify_mfa_code_session_expired():
    """Expired session should raise 410."""
    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = None
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    with pytest.raises(HTTPException) as exc:
        await verify_mfa_code(mock_db, "invalid_session_token", "123456")
    assert exc.value.status_code == 410
    assert "gecersiz" in exc.value.detail
