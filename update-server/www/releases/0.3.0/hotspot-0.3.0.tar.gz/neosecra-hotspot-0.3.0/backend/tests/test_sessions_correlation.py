"""Session correlation timeline tests."""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest import mock
import uuid

import pytest
from fastapi import HTTPException

from app.modules.search.schemas import SearchCorrelationSummary, SearchHit, SearchResult
from app.modules.sessions.correlation import correlate


def test_correlate_builds_timeline_and_summary():
    db = mock.AsyncMock()
    session_id = uuid.uuid4()
    customer_id = uuid.uuid4()
    identity_id = uuid.uuid4()
    session = SimpleNamespace(
        id=session_id,
        customer_id=customer_id,
        location_id=None,
        device_id=uuid.uuid4(),
        identity_verification_id=identity_id,
        voucher_id=None,
        phone="+905551112233",
        mac="AA:BB:CC:DD:EE:FF",
        ip="10.0.0.5",
        nas_ip="10.0.0.1",
        auth_method="sms",
        status="active",
        started_at=datetime(2026, 7, 13, 10, 0, tzinfo=timezone.utc),
        expires_at=datetime(2026, 7, 13, 12, 0, tzinfo=timezone.utc),
        ended_at=None,
        authorize_ok=True,
        authorize_message="allowed 10.0.0.5",
        radius_session_id="rad-123",
        bytes_in=1024,
        bytes_out=2048,
        created_at=datetime(2026, 7, 13, 9, 59, tzinfo=timezone.utc),
    )
    identity = SimpleNamespace(
        id=identity_id,
        customer_id=customer_id,
        location_id=None,
        device_id=None,
        method="sms",
        phone_masked="+90555***33",
        verified=True,
        created_at=datetime(2026, 7, 13, 9, 55, tzinfo=timezone.utc),
        consumed_at=datetime(2026, 7, 13, 9, 56, tzinfo=timezone.utc),
        portal_token_expires_at=datetime(2026, 7, 13, 12, 30, tzinfo=timezone.utc),
    )
    db.get = mock.AsyncMock(side_effect=[session, identity])

    search_result = SearchResult(
        hits=[
            SearchHit(
                timestamp="2026-07-13T10:02:00+00:00",
                customer_id=str(customer_id),
                source_ip="10.0.0.5",
                username="+905551112233",
                message="Portal auth accepted",
                source="clickhouse",
            )
        ],
        total=7,
        limit=5000,
        offset=0,
        source="mixed",
        correlation_summary=[
            SearchCorrelationSummary(
                correlation_id="principal:customer:demo",
                correlation_type="principal",
                reason="username eşleşmesi (15 dakikalık pencere)",
                hit_count=7,
                first_timestamp="2026-07-13T10:00:00+00:00",
                last_timestamp="2026-07-13T10:08:00+00:00",
                sample_hostname="fortigate-fw-1",
                sample_source_ip="10.0.0.5",
                sample_session_id="sess-1",
            )
        ],
    )

    with mock.patch(
        "app.modules.sessions.correlation.search_service.search_syslog",
        new=mock.AsyncMock(return_value=search_result),
    ) as search_mock:
        result = asyncio.run(correlate(db, guest_session_id=session_id))

    assert result.guest_session_id == session_id
    assert result.complete is True
    assert result.sources_matched == {
        "portal": True,
        "identity": True,
        "radius": True,
        "syslog": True,
        "firewall_api": True,
    }
    assert result.missing_sources == []
    assert result.stitching_summary == "Portal oturumu, Kimlik doğrulama, RADIUS, Syslog, Firewall API tamamlandı."
    assert [item.source for item in result.evidence_timeline] == [
        "identity",
        "identity",
        "portal",
        "radius",
        "syslog",
        "firewall_api",
    ]
    assert result.evidence_timeline[0].label == "Kimlik doğrulama kaydı oluşturuldu"
    assert result.evidence_timeline[1].label == "Portal token tüketildi"
    assert "mac=AA:BB:CC:DD:EE:FF" in (result.evidence_timeline[2].details or "")
    assert "radius_session_id=rad-123" in (result.evidence_timeline[3].details or "")
    assert result.evidence_timeline[4].label == "Syslog kayitlari eslesti"
    assert result.evidence_timeline[4].matched is True
    assert result.evidence_timeline[5].label == "Firewall API cagrisi kaydedildi"
    assert result.evidence_timeline[5].matched is True
    assert "authorize_ok=true" in (result.evidence_timeline[5].details or "")
    assert "message=allowed 10.0.0.5" in (result.evidence_timeline[5].details or "")
    assert result.case_window_minutes == 15
    assert result.related_log_count == 7
    assert result.related_log_groups[0].hit_count == 7
    assert result.case_summary.startswith("+905551112233 için 15 dakikalık pencerede 7 firewall kaydı")
    assert result.investigation_filters["correlation_window_minutes"] == 15
    assert search_mock.await_count == 1


def test_correlate_returns_404_when_session_missing():
    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=None)

    with pytest.raises(HTTPException) as exc:
        asyncio.run(correlate(db, guest_session_id=uuid.uuid4()))

    assert exc.value.status_code == 404
