"""Extended meeting service tests — list, delete, edge cases."""
import uuid
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.meeting.models import MeetingCode
from app.modules.meeting import service as meeting_service


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


class TestListCodes:
    @pytest.mark.asyncio
    async def test_list_codes_empty(self):
        db = _mock_db()
        result = await meeting_service.list_codes(db, customer_id=uuid.uuid4())
        assert result == []

    @pytest.mark.asyncio
    async def test_list_codes_ordered_by_created_at(self):
        db = _mock_db()
        db.execute.return_value.scalars.return_value.all.return_value = []
        result = await meeting_service.list_codes(db, customer_id=uuid.uuid4())
        db.execute.assert_awaited_once()


class TestVerifyCodeEdgeCases:
    @pytest.mark.asyncio
    async def test_verify_code_inactive(self):
        db = _mock_db()
        mc = MeetingCode(
            id=uuid.uuid4(), customer_id=uuid.uuid4(), code="INACTIVE",
            is_active=False, expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            current_uses=0, max_uses=100,
        )
        db.execute.return_value.scalar_one_or_none = mock.MagicMock(return_value=mc)

        with pytest.raises(HTTPException) as exc:
            await meeting_service.verify_code(
                db, code="INACTIVE",
                customer_id=mc.customer_id,
                location_id=None,
            )
        assert exc.value.status_code == 400
        assert "aktif degil" in exc.value.detail

    @pytest.mark.asyncio
    async def test_verify_code_different_customer(self):
        db = _mock_db()
        mc = MeetingCode(
            id=uuid.uuid4(), customer_id=uuid.uuid4(), code="OTHER_CUST",
            is_active=True, expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            current_uses=0, max_uses=100,
        )
        db.execute.return_value.scalar_one_or_none = mock.MagicMock(return_value=mc)

        r = await meeting_service.verify_code(
            db, code="OTHER_CUST",
            customer_id=mc.customer_id,
            location_id=None,
        )
        assert r is not None  # matches customer

    @pytest.mark.asyncio
    async def test_verify_code_increments_uses(self):
        db = _mock_db()
        mc = MeetingCode(
            id=uuid.uuid4(), customer_id=uuid.uuid4(), code="INCREMENT",
            is_active=True,
            expires_at=datetime.now(timezone.utc) + timedelta(hours=1),
            current_uses=0, max_uses=100,
        )
        db.execute.return_value.scalar_one_or_none = mock.MagicMock(return_value=mc)

        result = await meeting_service.verify_code(
            db, code="INCREMENT",
            customer_id=mc.customer_id,
            location_id=None,
        )
        assert result.current_uses == 1


class TestGenerateCode:
    def test_generate_code_default_length(self):
        code = meeting_service.generate_code()
        assert len(code) == 8

    def test_generate_code_min_length(self):
        code = meeting_service.generate_code(length=4)
        assert len(code) == 4

    def test_generate_code_max_length(self):
        code = meeting_service.generate_code(length=32)
        assert len(code) == 32

    def test_generate_code_uniqueness(self):
        codes = {meeting_service.generate_code() for _ in range(1000)}
        assert len(codes) > 900

    def test_generate_code_alphanumeric_uppercase(self):
        code = meeting_service.generate_code()
        assert code.isalnum()
        assert code.isupper()
