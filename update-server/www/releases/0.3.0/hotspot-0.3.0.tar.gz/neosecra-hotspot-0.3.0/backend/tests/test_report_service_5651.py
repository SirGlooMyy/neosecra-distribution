"""report_service.py (5651) tests — HTML, CSV, evidence package."""
import hashlib
import io
import json
import uuid
import zipfile
from types import SimpleNamespace
from datetime import datetime, timezone
from unittest import mock

import pytest

from app.modules.logs_5651.models import GENESIS_HASH, ArchiveRecord
from app.modules.logs_5651.report_service import (
    _build_5651_html,
    _chain_status_html,
    generate_court_evidence_package,
    _signature_detail_rows,
    export_session_logs_csv,
)


def make_archive(chain_seq=1, signed=False):
    cid = uuid.uuid4()
    ps = datetime(2026, 6, 1, tzinfo=timezone.utc)
    pe = datetime(2026, 6, 2, tzinfo=timezone.utc)
    chash = hashlib.sha256(b"test").hexdigest()
    curr = hashlib.sha256(
        (GENESIS_HASH + chash + "2026-06-01T00:00:00+00:00/2026-06-02T00:00:00+00:00session_archive").encode()
    ).hexdigest()
    return ArchiveRecord(
        id=uuid.uuid4(),
        customer_id=cid,
        period_start=ps,
        period_end=pe,
        record_type="session_archive",
        chain_seq=chain_seq,
        item_count=10,
        content_hash=chash,
        content_ref=f"none:{chash}",
        content_size=100,
        prev_hash=GENESIS_HASH,
        curr_hash=curr,
        meta={},
        signature_value="sig123" if signed else None,
        signature_time=datetime.now(timezone.utc) if signed else None,
        certificate_serial="SN12345" if signed else None,
        sign_method="kamusm" if signed else None,
    )


def test_build_5651_html_contains_title():
    records = [make_archive(1)]
    html = _build_5651_html(
        customer_info={"name": "Test Musteri", "id": str(uuid.uuid4())},
        period={"start": datetime(2026, 6, 1, tzinfo=timezone.utc),
                "end": datetime(2026, 6, 2, tzinfo=timezone.utc)},
        records=records,
    )
    assert "5651 Sayili Kanun" in html
    assert "Test Musteri" in html
    assert "Arsiv Kayitlari ve Hash Zinciri" in html


def test_build_5651_html_shows_chain_seq():
    records = [make_archive(5)]
    html = _build_5651_html(
        customer_info={"name": "Test", "id": str(uuid.uuid4())},
        period={"start": datetime(2026, 6, 1, tzinfo=timezone.utc),
                "end": datetime(2026, 6, 2, tzinfo=timezone.utc)},
        records=records,
    )
    assert "5</td>" in html or "chain_seq" not in html


def test_build_5651_html_multiple_records():
    records = [make_archive(1), make_archive(2), make_archive(3)]
    html = _build_5651_html(
        customer_info={"name": "Test", "id": str(uuid.uuid4())},
        period={"start": datetime(2026, 6, 1, tzinfo=timezone.utc),
                "end": datetime(2026, 6, 2, tzinfo=timezone.utc)},
        records=records,
    )
    assert html.count("<tr>") >= 3


def test_build_5651_html_shows_total_items():
    records = [make_archive(1), make_archive(2)]
    html = _build_5651_html(
        customer_info={"name": "Test", "id": str(uuid.uuid4())},
        period={"start": datetime(2026, 6, 1, tzinfo=timezone.utc),
                "end": datetime(2026, 6, 2, tzinfo=timezone.utc)},
        records=records,
    )
    assert "20" in html  # 2 records x 10 items


def test_build_5651_html_signed_status():
    records = [make_archive(1, signed=True)]
    html = _build_5651_html(
        customer_info={"name": "Test", "id": str(uuid.uuid4())},
        period={"start": datetime(2026, 6, 1, tzinfo=timezone.utc),
                "end": datetime(2026, 6, 2, tzinfo=timezone.utc)},
        records=records,
    )
    assert "Imzali" in html


def test_build_5651_html_unsigned_status():
    records = [make_archive(1, signed=False)]
    html = _build_5651_html(
        customer_info={"name": "Test", "id": str(uuid.uuid4())},
        period={"start": datetime(2026, 6, 1, tzinfo=timezone.utc),
                "end": datetime(2026, 6, 2, tzinfo=timezone.utc)},
        records=records,
    )
    assert "Imzasiz" in html


def test_chain_status_html_empty():
    html = _chain_status_html([])
    assert "Zincir bos" in html


def test_chain_status_html_valid():
    records = [make_archive(1)]
    html = _chain_status_html(records)
    assert "✓" in html


def test_signature_detail_rows_no_signed():
    records = [make_archive(1, signed=False)]
    html = _signature_detail_rows(records)
    assert "dijital imza bulunmamaktadir" in html


def test_signature_detail_rows_with_signed():
    records = [make_archive(1, signed=True)]
    html = _signature_detail_rows(records)
    assert "Imzali Kayitlar" in html
    assert "SN12345" in html


def test_export_session_logs_csv_headers():
    result = export_session_logs_csv([], {"start": "2026-01-01", "end": "2026-01-02"})
    text = result.decode("utf-8-sig")
    assert "5651 Log Kaydi Export" in text
    assert "session_id" in text


def test_export_session_logs_csv_with_sessions():
    class MockSession:
        id = uuid.uuid4()
        customer_id = uuid.uuid4()
        location_id = uuid.uuid4()
        mac = "aa:bb:cc:dd:ee:ff"
        ip = "192.168.1.100"
        nas_ip = "10.0.0.1"
        ssid = "Guest"
        phone = "5551234567"
        auth_method = "sms"
        status = "active"
        started_at = datetime(2026, 6, 1, tzinfo=timezone.utc)
        ended_at = datetime(2026, 6, 1, 1, tzinfo=timezone.utc)
        expires_at = datetime(2026, 6, 1, 4, tzinfo=timezone.utc)

    result = export_session_logs_csv([MockSession()], {"start": "2026-06-01", "end": "2026-06-02"})
    text = result.decode("utf-8-sig")
    assert "aa:bb:cc:dd:ee:ff" in text
    assert "192.168.1.100" in text
    assert "sms" in text
    assert "active" in text


def test_export_session_logs_csv_utf8_bom():
    result = export_session_logs_csv([], {"start": "", "end": ""})
    assert result.startswith(b"\xef\xbb\xbf")


def test_export_session_logs_csv_empty_fields():
    class MockSession:
        id = uuid.uuid4()
        customer_id = uuid.uuid4()
        location_id = None
        mac = None
        ip = None
        nas_ip = None
        ssid = None
        phone = None
        auth_method = "sms"
        status = "pending"
        started_at = None
        ended_at = None
        expires_at = None

    result = export_session_logs_csv([MockSession()], {"start": "", "end": ""})
    text = result.decode("utf-8-sig")
    assert "sms" in text
    assert "pending" in text


@pytest.mark.asyncio
async def test_generate_court_evidence_package_includes_group_policy():
    session = SimpleNamespace(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        location_id=uuid.uuid4(),
        device_id=uuid.uuid4(),
        identity_verification_id=None,
        voucher_id=None,
        group_id=uuid.uuid4(),
        phone="5551234567",
        mac="AA:BB:CC:DD:EE:FF",
        ip="10.0.0.55",
        nas_ip="10.0.0.1",
        ssid="GuestWiFi",
        auth_method="sms",
        status="active",
        started_at=datetime(2026, 6, 1, 10, 0, tzinfo=timezone.utc),
        ended_at=None,
        expires_at=datetime(2026, 6, 1, 11, 0, tzinfo=timezone.utc),
        radius_session_id="rad-123",
        bytes_in=1024,
        bytes_out=2048,
        authorize_ok=True,
        authorize_message="allowed 10.0.0.55",
        meta={
            "group_policy": {
                "group_id": "group-1",
                "group_name": "Gold",
                "vlan_id": 77,
                "radius_avps": {
                    "Tunnel-Type": 13,
                    "Tunnel-Medium-Type": 6,
                    "Tunnel-Private-Group-ID": "77",
                },
            }
        },
    )

    mock_result = mock.MagicMock()
    mock_result.scalars.return_value.all.return_value = []

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=session)
    db.execute = mock.AsyncMock(return_value=mock_result)

    pkg = await generate_court_evidence_package(db, session.id, session.customer_id)

    with zipfile.ZipFile(io.BytesIO(pkg), "r") as zf:
        session_json = json.loads(zf.read("session.json").decode("utf-8"))
        manifest_json = json.loads(zf.read("evidence_manifest.json").decode("utf-8"))

    assert session_json["authorize_ok"] is True
    assert session_json["authorize_message"] == "allowed 10.0.0.55"
    assert session_json["group_policy"]["group_name"] == "Gold"
    assert session_json["group_policy"]["radius_avps"]["Tunnel-Private-Group-ID"] == "77"
    assert "session.json" in manifest_json["files"]
