"""Unit tests for firewall_logs search filter parameters."""

import uuid
from datetime import datetime, timezone
from unittest import mock

import pytest

from app.modules.search.schemas import LogSearchParams
from app.modules.search.service import search_firewall_logs
from app.modules.syslog.models import FirewallLog


@pytest.fixture
def user():
    u = mock.MagicMock()
    u.id = uuid.uuid4()
    u.tenant_id = uuid.uuid4()
    u.role = "customer_admin"
    u.is_active = True
    return u


def _mock_firewall_log(**overrides) -> mock.MagicMock:
    """Build a mock FirewallLog with defaults."""
    now = datetime.now(timezone.utc)
    vals = dict(
        id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        received_at=now,
        event_time=now,
        vendor="fortigate",
        log_type="traffic",
        log_subtype=None,
        severity="info",
        action="accept",
        src_ip="10.0.0.1",
        dst_ip="8.8.8.8",
        src_port=12345,
        dst_port=443,
        proto="TCP",
        service="HTTPS",
        user="testuser",
        policyid=1,
        duration=100,
        sentbyte=1000,
        rcvdbyte=2000,
        session_id="sess-001",
        raw_syslog="<14>1 2026-07-27T10:00:00Z hostname ...",
        parsed_fields={},
    )
    vals.update(overrides)
    row = mock.MagicMock(spec=FirewallLog)
    for k, v in vals.items():
        setattr(row, k, v)
    return row


class _ScalarResultMock:
    """Mock the result of db.execute(...).scalars().all() pattern."""

    def __init__(self, rows):
        self._rows = rows

    def scalars(self):
        return self

    def all(self):
        return self._rows

    def first(self):
        return self._rows[0] if self._rows else None


class _ScalarResultMockOne:
    def __init__(self, scalar):
        self._scalar = scalar

    def scalar(self):
        return self._scalar


@pytest.mark.asyncio
async def test_search_filter_vendor():
    """vendor filter narrows results."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()

    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(50),
        _ScalarResultMock([_mock_firewall_log(vendor="fortigate")]),
    ]

    filters = LogSearchParams(vendor="fortigate")
    res = await search_firewall_logs(db, user, filters)

    assert res.total == 50
    assert len(res.items) == 1
    assert res.items[0].vendor == "fortigate"
    assert res.took_ms >= 0


@pytest.mark.asyncio
async def test_search_filter_log_type():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(10),
        _ScalarResultMock([_mock_firewall_log(log_type="utm")]),
    ]

    filters = LogSearchParams(log_type="utm")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 10
    assert res.items[0].log_type == "utm"


@pytest.mark.asyncio
async def test_search_filter_severity():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(3),
        _ScalarResultMock([_mock_firewall_log(severity="critical")]),
    ]

    filters = LogSearchParams(severity="critical")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 3
    assert res.items[0].severity == "critical"


@pytest.mark.asyncio
async def test_search_filter_action():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(7),
        _ScalarResultMock([_mock_firewall_log(action="deny")]),
    ]

    filters = LogSearchParams(action="deny")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 7
    assert res.items[0].action == "deny"


@pytest.mark.asyncio
async def test_search_filter_src_ip_exact():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(1),
        _ScalarResultMock([_mock_firewall_log(src_ip="192.168.1.100")]),
    ]

    filters = LogSearchParams(src_ip="192.168.1.100")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 1
    assert res.items[0].src_ip == "192.168.1.100"


@pytest.mark.asyncio
async def test_search_filter_src_ip_prefix():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(5),
        _ScalarResultMock([_mock_firewall_log(src_ip="10.0.0.50")]),
    ]

    filters = LogSearchParams(src_ip="10.0.0.")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 5


@pytest.mark.asyncio
async def test_search_filter_dst_ip():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(2),
        _ScalarResultMock([_mock_firewall_log(dst_ip="1.1.1.1")]),
    ]

    filters = LogSearchParams(dst_ip="1.1.1.1")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 2


@pytest.mark.asyncio
async def test_search_filter_src_port():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(3),
        _ScalarResultMock([_mock_firewall_log(src_port=8080)]),
    ]

    filters = LogSearchParams(src_port=8080)
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 3
    assert res.items[0].src_port == 8080


@pytest.mark.asyncio
async def test_search_filter_dst_port():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(4),
        _ScalarResultMock([_mock_firewall_log(dst_port=443)]),
    ]

    filters = LogSearchParams(dst_port=443)
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 4


@pytest.mark.asyncio
async def test_search_filter_user_substring():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(6),
        _ScalarResultMock([_mock_firewall_log(user="john.doe@example.com")]),
    ]

    filters = LogSearchParams(user="john")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 6
    assert "john" in res.items[0].user


@pytest.mark.asyncio
async def test_search_filter_proto():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(8),
        _ScalarResultMock([_mock_firewall_log(proto="UDP")]),
    ]

    filters = LogSearchParams(proto="UDP")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 8
    assert res.items[0].proto == "UDP"


@pytest.mark.asyncio
async def test_search_filter_service():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(12),
        _ScalarResultMock([_mock_firewall_log(service="SSH")]),
    ]

    filters = LogSearchParams(service="SSH")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 12


@pytest.mark.asyncio
async def test_search_filter_policyid():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(2),
        _ScalarResultMock([_mock_firewall_log(policyid=10)]),
    ]

    filters = LogSearchParams(policyid=10)
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 2


@pytest.mark.asyncio
async def test_search_filter_time_window():
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(20),
        _ScalarResultMock([_mock_firewall_log()]),
    ]

    filters = LogSearchParams(time_window="24h")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 20


@pytest.mark.asyncio
async def test_search_filter_multi_value():
    """Comma-separated multi-value filters (severity)."""
    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarResultMockOne(15),
        _ScalarResultMock([
            _mock_firewall_log(severity="critical"),
            _mock_firewall_log(severity="high"),
        ]),
    ]

    filters = LogSearchParams(severity="critical,high")
    res = await search_firewall_logs(db, user, filters)
    assert res.total == 15
