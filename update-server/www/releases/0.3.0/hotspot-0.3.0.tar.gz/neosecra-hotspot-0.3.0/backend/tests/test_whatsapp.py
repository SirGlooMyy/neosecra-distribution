"""WhatsApp OTP servis testleri."""
import pytest
import uuid
import unittest.mock as mock
from datetime import datetime, timedelta, timezone
from fastapi import HTTPException

from app.modules.whatsapp.service import (
    send_whatsapp_code,
)
from app.modules.sms.service import normalize_tr_phone


@pytest.fixture(autouse=True)
def _mock_redis():
    """Prevent Redis connections in all tests."""
    r = mock.AsyncMock()
    r.get.return_value = None
    r.set.return_value = True
    r.delete.return_value = True
    r.incr.return_value = 1
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield


@pytest.mark.asyncio
async def test_normalize_phone_valid():
    normalized = normalize_tr_phone("05551234567")
    assert normalized == "+905551234567"

    normalized = normalize_tr_phone("5551234567")
    assert normalized == "+905551234567"

    normalized = normalize_tr_phone("+905551234567")
    assert normalized == "+905551234567"


@pytest.mark.asyncio
async def test_normalize_phone_invalid():
    with pytest.raises(HTTPException) as exc:
        normalize_tr_phone("123")
    assert exc.value.status_code == 400

    with pytest.raises(HTTPException):
        normalize_tr_phone("4440333")


@pytest.mark.asyncio
async def test_send_whatsapp_code_mock():
    """Mock delivery in dev mode – no token configured, falls through to mock."""
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = None
    mock_db.add = mock.MagicMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()

    from app.core.config import settings
    original_demo = settings.DEMO_MODE
    settings.DEMO_MODE = True

    try:
        result = await send_whatsapp_code(
            mock_db,
            phone="05551234567",
            customer_id=uuid.uuid4(),
            location_id=uuid.uuid4(),
        )
        assert result.state == "sent"
        assert result.ttl_seconds > 0
        assert result.attempts_left > 0
    finally:
        settings.DEMO_MODE = original_demo


@pytest.mark.asyncio
async def test_send_whatsapp_code_fails_closed_without_config():
    """WhatsApp config eksikken demo kapaliyken 503 donmeli."""
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = None
    mock_db.add = mock.MagicMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()

    from app.core.config import settings
    original_demo = settings.DEMO_MODE
    settings.DEMO_MODE = False

    try:
        with pytest.raises(HTTPException) as exc:
            await send_whatsapp_code(
                mock_db,
                phone="05551234567",
                customer_id=uuid.uuid4(),
                location_id=uuid.uuid4(),
            )
    finally:
        settings.DEMO_MODE = original_demo

    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_verify_whatsapp_code_valid():
    """Verify a code that was just sent (mocked DB returns an unexpired record)."""
    phone = "+905551234567"
    customer_id = uuid.uuid4()
    location_id = uuid.uuid4()
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=180)

    mock_wa = mock.AsyncMock()
    mock_wa.phone = phone
    mock_wa.customer_id = customer_id
    mock_wa.location_id = location_id
    mock_wa.code_hash = "fakesalt$" + "a" * 64
    mock_wa.expires_at = expires_at
    mock_wa.verified = False
    mock_wa.consumed_at = None
    mock_wa.attempts = 0
    mock_wa.max_attempts = 3

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = mock_wa
    mock_db.execute.return_value = mock_scalar
    mock_db.commit.return_value = None
    mock_db.refresh.return_value = None

    from app.modules.whatsapp.service import _hash_code, _verify_code

    code = "123456"
    stored = _hash_code(code)

    assert _verify_code(code, stored) is True
    assert _verify_code("wrong", stored) is False


@pytest.mark.asyncio
async def test_verify_whatsapp_code_invalid():
    """Verify that wrong code raises 400."""
    mock_wa = mock.AsyncMock()
    mock_wa.phone = "+905551234567"
    mock_wa.code_hash = "fakesalt$" + "b" * 64
    mock_wa.expires_at = datetime.now(timezone.utc) + timedelta(seconds=180)
    mock_wa.verified = False
    mock_wa.consumed_at = None
    mock_wa.attempts = 0
    mock_wa.max_attempts = 3

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = mock_wa
    mock_db.execute.return_value = mock_scalar
    mock_db.commit.return_value = None

    from app.modules.whatsapp.service import _hash_code, _verify_code

    stored = _hash_code("654321")
    assert _verify_code("wrong_code", stored) is False


def test_verify_code_expired_logic():
    """Test that _verify_code returns False for expired tokens structurally."""
    from app.modules.whatsapp.service import _hash_code, _verify_code

    code = "000000"
    stored = _hash_code(code)

    assert _verify_code(code, stored) is True
    assert _verify_code("", stored) is False
    assert _verify_code("000001", stored) is False
