"""Customer service tests — CRUD, scoped queries, partner link, edge cases."""
import uuid
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.customers.models import Customer
from app.modules.customers.schemas import CustomerCreate, CustomerUpdate
from app.modules.customers import service as customer_service
from app.modules.partners.models import Partner
from app.core.tenant import ScopeContext, TenantLevel


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


def _global_scope() -> ScopeContext:
    return ScopeContext(level=TenantLevel.GLOBAL)


class TestListCustomers:
    @pytest.mark.asyncio
    async def test_list_empty(self):
        db = _mock_db()
        result = await customer_service.list_customers(db, _global_scope())
        assert result == []

    @pytest.mark.asyncio
    async def test_list_scoped_to_partner(self):
        db = _mock_db()
        pid = uuid.uuid4()
        scope = ScopeContext(level=TenantLevel.PARTNER, partner_id=pid)
        result = await customer_service.list_customers(db, scope)
        assert result == []


class TestGetCustomer:
    @pytest.mark.asyncio
    async def test_get_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await customer_service.get_customer(db, uuid.uuid4(), _global_scope())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_get_forbidden_for_wrong_partner(self):
        db = _mock_db()
        cid = uuid.uuid4()
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        r.scalars.return_value.all.return_value = []
        db.execute.return_value = r
        wrong_scope = ScopeContext(level=TenantLevel.PARTNER, partner_id=uuid.uuid4())

        with pytest.raises(HTTPException) as exc:
            await customer_service.get_customer(db, cid, wrong_scope)
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_get_success_global(self):
        db = _mock_db()
        cid = uuid.uuid4()
        customer = Customer(id=cid, tenant_id=uuid.uuid4(), name="Acme Corp")
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = customer
        db.execute.return_value = r

        result = await customer_service.get_customer(db, cid, _global_scope())
        assert result.name == "Acme Corp"


class TestCreateCustomer:
    @pytest.mark.asyncio
    async def test_create_success_global(self):
        db = _mock_db()
        pid = uuid.uuid4()
        tid = uuid.uuid4()
        body = CustomerCreate(partner_id=pid, name="New Customer")
        partner = Partner(id=pid, tenant_id=tid, name="Test Partner")
        db.get.return_value = partner

        result = await customer_service.create_customer(db, body, _global_scope(), uuid.uuid4())
        assert result is not None
        assert db.add.called
        db.commit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_create_global_missing_partner_id(self):
        db = _mock_db()
        body = CustomerCreate(name="No Partner")
        with pytest.raises(HTTPException) as exc:
            await customer_service.create_customer(db, body, _global_scope(), uuid.uuid4())
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_create_global_partner_not_found(self):
        db = _mock_db()
        body = CustomerCreate(partner_id=uuid.uuid4(), name="No Partner")
        db.get.return_value = None
        with pytest.raises(HTTPException) as exc:
            await customer_service.create_customer(db, body, _global_scope(), uuid.uuid4())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_create_as_partner_success(self):
        db = _mock_db()
        pid = uuid.uuid4()
        tid = uuid.uuid4()
        body = CustomerCreate(name="Partner Cust")
        scope = ScopeContext(level=TenantLevel.PARTNER, partner_id=pid)
        partner = Partner(id=pid, tenant_id=tid, name="Partner")
        db.get.return_value = partner

        result = await customer_service.create_customer(db, body, scope, uuid.uuid4())
        assert result is not None

    @pytest.mark.asyncio
    async def test_create_denied_for_customer_scope(self):
        db = _mock_db()
        scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=uuid.uuid4())
        body = CustomerCreate(name="Cust Scope")
        with pytest.raises(HTTPException) as exc:
            await customer_service.create_customer(db, body, scope, uuid.uuid4())
        assert exc.value.status_code == 403


class TestUpdateCustomer:
    @pytest.mark.asyncio
    async def test_update_not_found(self):
        db = _mock_db()
        body = CustomerUpdate(name="Updated")
        with pytest.raises(HTTPException) as exc:
            await customer_service.update_customer(db, uuid.uuid4(), body, _global_scope(), uuid.uuid4())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_update_success(self):
        db = _mock_db()
        cid = uuid.uuid4()
        customer = Customer(id=cid, tenant_id=uuid.uuid4(), name="Old Name")
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = customer
        db.execute.return_value = r

        body = CustomerUpdate(name="New Name", contact_email="admin@acme.com")
        result = await customer_service.update_customer(db, cid, body, _global_scope(), uuid.uuid4())
        assert result.name == "New Name"
        db.commit.assert_awaited_once()


class TestDeactivateCustomer:
    @pytest.mark.asyncio
    async def test_deactivate_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await customer_service.deactivate_customer(db, uuid.uuid4(), _global_scope(), uuid.uuid4())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_deactivate_success(self):
        db = _mock_db()
        cid = uuid.uuid4()
        customer = Customer(id=cid, tenant_id=uuid.uuid4(), name="Active Cust", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = customer
        db.execute.return_value = r

        await customer_service.deactivate_customer(db, cid, _global_scope(), uuid.uuid4())
        assert customer.is_active is False
        db.commit.assert_awaited_once()
