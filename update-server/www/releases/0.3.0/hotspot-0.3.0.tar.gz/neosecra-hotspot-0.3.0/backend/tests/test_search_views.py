"""Search view service tests."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.search.models import SearchView
from app.modules.search.schemas import SearchViewCreate, SearchViewUpdate
from app.modules.search import service


class _ScalarResult:
    def __init__(self, rows):
        self._rows = rows

    def scalars(self):
        return self

    def all(self):
        return self._rows


def _make_view(**overrides) -> SearchView:
    defaults = dict(
        id=uuid.uuid4(),
        created_by_user_id=uuid.uuid4(),
        surface="firewall_logs",
        title="VPN Errors",
        description="warning filtreleri",
        filters={"vendor": "Fortinet", "severity": "warning"},
        is_shared=False,
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    defaults.update(overrides)
    return SearchView(**defaults)


@pytest.mark.asyncio
async def test_list_search_views_returns_shared_and_owned_rows():
    user_id = uuid.uuid4()
    owned = _make_view(created_by_user_id=user_id, title="My view")
    shared = _make_view(created_by_user_id=uuid.uuid4(), title="Shared view", is_shared=True)
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([owned, shared]))

    rows = await service.list_search_views(db, user_id=user_id, surface="firewall_logs")

    assert len(rows) == 2
    assert rows[0].title == "My view"
    assert rows[1].title == "Shared view"


@pytest.mark.asyncio
async def test_create_search_view_assigns_id_and_timestamps():
    user_id = uuid.uuid4()
    db = mock.AsyncMock()
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()

    body = SearchViewCreate(
        surface="firewall_logs",
        title="VPN Alerts",
        description="Saved warning filters",
        filters={"vendor": "Fortinet", "severity": "warning"},
        is_shared=True,
    )

    result = await service.create_search_view(db, body=body, user_id=user_id)

    assert result.title == "VPN Alerts"
    assert result.created_by_user_id == user_id
    assert result.is_shared is True
    assert result.created_at.tzinfo is not None
    assert db.add.called


@pytest.mark.asyncio
async def test_update_and_delete_search_view_require_ownership():
    owner_id = uuid.uuid4()
    other_id = uuid.uuid4()
    view = _make_view(created_by_user_id=owner_id)

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=view)
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    db.delete = mock.AsyncMock()

    updated = await service.update_search_view(
        db,
        view_id=view.id,
        body=SearchViewUpdate(title="Updated title", filters={"severity": "error"}),
        user_id=owner_id,
    )
    assert updated.title == "Updated title"
    assert updated.filters == {"severity": "error"}

    await service.delete_search_view(db, view_id=view.id, user_id=owner_id)
    assert db.delete.called

    with pytest.raises(HTTPException) as exc:
        await service.delete_search_view(db, view_id=view.id, user_id=other_id)
    assert exc.value.status_code == 403
