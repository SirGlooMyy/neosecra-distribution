from __future__ import annotations

from pathlib import Path
from unittest import mock
import uuid

import pytest

from app.modules.system import backup_service
from app.modules.workers import tasks


class _AsyncSessionContext:
    def __init__(self, db):
        self.db = db

    async def __aenter__(self):
        return self.db

    async def __aexit__(self, exc_type, exc, tb):
        return False


@pytest.mark.asyncio
async def test_start_config_backup_uses_config_worker():
    db = mock.AsyncMock()
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()

    with mock.patch("app.modules.workers.tasks.run_config_backup") as task_mock:
        result = await backup_service.start_config_backup(db, uuid.uuid4())

    job = db.add.call_args.args[0]
    assert job.type == backup_service.BT_CONFIG
    assert result["status"] == backup_service.BS_RUNNING
    task_mock.delay.assert_called_once_with(str(job.id))


@pytest.mark.asyncio
async def test_restore_from_backup_dispatches_restore_worker_for_db_backups():
    backup_id = uuid.uuid4()
    job = mock.MagicMock(id=backup_id, type=backup_service.BT_DB, file_ref="minio:backups/db/backup.dump")
    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=job)

    with mock.patch("app.modules.workers.tasks.run_restore_backup") as task_mock:
        result = await backup_service.restore_from_backup(db, backup_id)

    task_mock.delay.assert_called_once_with(str(backup_id))
    assert result["status"] == "restoring"


@pytest.mark.asyncio
async def test_restore_from_backup_rejects_config_backups():
    backup_id = uuid.uuid4()
    job = mock.MagicMock(id=backup_id, type=backup_service.BT_CONFIG, file_ref="minio:backups/config/backup.tar.gz")
    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=job)

    with pytest.raises(ValueError, match="geri yukleme"):
        await backup_service.restore_from_backup(db, backup_id)


def test_run_restore_backup_uses_primary_database_ref(tmp_path, monkeypatch):
    backup_id = uuid.uuid4()
    job = mock.MagicMock(
        id=backup_id,
        type=backup_service.BT_FULL,
        file_ref="minio:backups/db/backup.dump;minio:backups/config/backup.tar.gz",
    )
    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=job)
    ctx = _AsyncSessionContext(db)
    download_mock = mock.Mock()
    restore_mock = mock.Mock()

    monkeypatch.setattr(tasks.settings, "BACKUP_PATH", str(tmp_path), raising=False)

    with mock.patch("app.modules.workers.tasks.WorkerSession", return_value=ctx), \
        mock.patch("app.modules.system.backup_service._download_from_minio", new=download_mock), \
        mock.patch("app.modules.system.backup_service._run_pg_restore", new=restore_mock):
        result = tasks.run_restore_backup(str(backup_id))

    assert result["ok"] is True
    download_mock.assert_called_once()
    restore_mock.assert_called_once()
    assert download_mock.call_args.args[0] == "minio:backups/db/backup.dump"
    assert Path(download_mock.call_args.args[1]).parent == tmp_path
