"""Syslog router serialization tests."""
from __future__ import annotations

from datetime import datetime, timezone
import uuid

from app.modules.syslog.models import SyslogTrigger, TriggerEvent
from app.modules.syslog.router import _serialize_trigger, _serialize_trigger_event


def test_serialize_trigger_exposes_frontend_fields():
    trigger = SyslogTrigger(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        name="WAN down",
        description="Primary link failed",
        match_type="keyword",
        match_pattern="down",
        severity_threshold=None,
        channel="email",
        channel_config={"to": ["ops@example.com"]},
        cooldown_minutes=12,
        is_active=True,
        last_triggered_at=datetime(2026, 7, 13, 10, 0, tzinfo=timezone.utc),
    )

    payload = _serialize_trigger(trigger)

    assert payload["pattern"] == "down"
    assert payload["last_triggered"] == "2026-07-13T10:00:00+00:00"
    assert payload["cooldown_minutes"] == 12
    assert payload["channel_config"]["to"] == ["ops@example.com"]


def test_serialize_trigger_event_exposes_delivery_fields():
    event = TriggerEvent(
        id=uuid.uuid4(),
        trigger_id=uuid.uuid4(),
        syslog_record_id=uuid.uuid4(),
        matched_value="down",
        triggered_at=datetime(2026, 7, 13, 10, 1, tzinfo=timezone.utc),
        delivery_channel="email",
        delivery_status="sent",
        delivery_target="ops@example.com",
        delivery_detail="ok",
        delivered_at=datetime(2026, 7, 13, 10, 2, tzinfo=timezone.utc),
        acknowledged_at=datetime(2026, 7, 13, 10, 5, tzinfo=timezone.utc),
        acknowledged_by=uuid.uuid4(),
    )

    payload = _serialize_trigger_event(event, trigger_name="WAN down")

    assert payload["trigger_name"] == "WAN down"
    assert payload["timestamp"] == "2026-07-13T10:01:00+00:00"
    assert payload["delivery_channel"] == "email"
    assert payload["delivery_status"] == "sent"
    assert payload["delivery_target"] == "ops@example.com"
    assert payload["acknowledged"] is True
