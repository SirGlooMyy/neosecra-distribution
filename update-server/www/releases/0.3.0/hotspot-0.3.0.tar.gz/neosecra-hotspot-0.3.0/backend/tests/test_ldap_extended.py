"""Extended LDAP service tests — edge cases, parse helpers, auth logic."""
import pytest
from app.modules.ldap.service import (
    _parse_ldap_url,
    _get_attr,
)


class TestParseLdapUrl:
    def test_default_no_url(self):
        result = _parse_ldap_url(None)
        assert result["host"] == "localhost"
        assert result["port"] == 389

    def test_ldap_default_port(self):
        result = _parse_ldap_url("ldap://192.168.1.1")
        assert result["port"] == 389

    def test_ldaps_default_port(self):
        result = _parse_ldap_url("ldaps://dc.example.com")
        assert result["port"] == 636

    def test_custom_port(self):
        result = _parse_ldap_url("ldap://10.0.0.1:1389")
        assert result["port"] == 1389

    def test_ipv6_host(self):
        result = _parse_ldap_url("ldap://[::1]:389")
        assert result["host"] == "::1"
        assert result["port"] == 389


class TestGetAttr:
    def test_attr_exists(self):
        result = _get_attr({"cn": ["test_user"]}, "cn")
        assert result == "test_user"

    def test_attr_missing(self):
        result = _get_attr({"cn": ["test"]}, "mail")
        assert result is None

    def test_attr_empty_list(self):
        result = _get_attr({"cn": []}, "cn")
        assert result is None

    def test_attr_none(self):
        result = _get_attr({}, "anything")
        assert result is None


class TestAuthenticateEdgeCases:
    @pytest.mark.asyncio
    async def test_authenticate_empty_username_returns_none(self):
        from app.modules.ldap.service import LDAP_AVAILABLE, authenticate
        if LDAP_AVAILABLE:
            result = await authenticate(username="", password="pass")
        else:
            with pytest.raises(ImportError):
                await authenticate(username="", password="pass")
            return
        assert result is None

    @pytest.mark.asyncio
    async def test_authenticate_domain_backslash(self):
        from app.modules.ldap.service import LDAP_AVAILABLE, authenticate
        if not LDAP_AVAILABLE:
            pytest.skip("ldap3 not installed")
        result = await authenticate(username="DOMAIN\\user", password="pass")
        assert result is None  # will fail at LDAP connection level, not parsing

    @pytest.mark.asyncio
    async def test_authenticate_email_format(self):
        from app.modules.ldap.service import LDAP_AVAILABLE, authenticate
        if not LDAP_AVAILABLE:
            pytest.skip("ldap3 not installed")
        result = await authenticate(username="user@domain.com", password="pass")
        assert result is None


class TestSearchUserEdgeCases:
    @pytest.mark.asyncio
    async def test_search_user_empty_query(self):
        from app.modules.ldap.service import search_user
        result = await search_user(query="")
        assert result == []

    @pytest.mark.asyncio
    async def test_search_user_no_ldap(self):
        from app.modules.ldap.service import LDAP_AVAILABLE, search_user
        if not LDAP_AVAILABLE:
            with pytest.raises(ImportError):
                await search_user(query="test")
            return
        result = await search_user(query="nonexistent_user_xyz")
        assert result == []
