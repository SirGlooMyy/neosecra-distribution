"""Verify every OpenAPI path has tags + summary (min 10 chars)."""
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_openapi_json_returns_200():
    r = client.get("/openapi.json")
    assert r.status_code == 200


def test_openapi_json_is_valid():
    r = client.get("/openapi.json")
    spec = r.json()
    assert "paths" in spec
    assert len(spec["paths"]) > 0


def test_every_path_has_tags():
    r = client.get("/openapi.json")
    spec = r.json()
    untagged = []
    for path, methods in spec["paths"].items():
        for method, detail in methods.items():
            if "tags" not in detail or not detail["tags"]:
                untagged.append(f"{method.upper()} {path}")
    assert not untagged, f"Untagged endpoints: {untagged}"


def test_every_path_has_summary_min_10_chars():
    r = client.get("/openapi.json")
    spec = r.json()
    short = []
    for path, methods in spec["paths"].items():
        for method, detail in methods.items():
            summary = detail.get("summary", "")
            if len(summary) < 10:
                short.append(f"{method.upper()} {path}: '{summary}' ({len(summary)} chars)")
    assert not short, f"Endpoints with too-short summary (< 10 chars): {short}"


def test_tags_are_meaningful():
    r = client.get("/openapi.json")
    spec = r.json()
    valid_tags = {
        "auth", "tenants", "customers", "locations", "devices",
        "portal", "sessions", "vouchers", "radius", "syslog",
        "logs-5651", "licensing", "mfa", "syslog-triggers", "reports",
        "system", "user-groups", "ban", "traffic", "search",
        "auth-methods", "alarm", "public-content", "site-bridge",
        "archive", "pms", "captive-portal", "platform-licensing",
        "platform-upgrade",
    }
    bad = []
    for path, methods in spec["paths"].items():
        for method, detail in methods.items():
            for tag in detail.get("tags", []):
                if tag not in valid_tags:
                    bad.append(f"{method.upper()} {path}: tag '{tag}' not in known set")
    assert not bad, f"Unknown tags: {bad}"
