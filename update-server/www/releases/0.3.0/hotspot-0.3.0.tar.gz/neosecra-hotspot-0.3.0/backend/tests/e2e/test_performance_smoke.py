from __future__ import annotations

import asyncio
import time
import uuid
from datetime import datetime, timezone

import pytest

from app.modules.search.schemas import LogSearchParams
from app.modules.search.service import get_facets, search_firewall_logs, export_firewall_logs
from app.modules.syslog.models import FirewallLog
from .conftest import create_db_session, close_db_session


@pytest.mark.e2e
@pytest.mark.slow
class TestPerformanceSmoke:

    def test_search_single_filter_under_500ms(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.devices.models import Device
                t = Tenant(name="Perf Tenant", slug="perf-tenant", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="Perf Customer")
                db.add(c)
                await db.flush()
                await db.refresh(c)
                from app.modules.locations.models import Location
                loc_p = Location(customer_id=c.id, name="Perf Loc")
                db.add(loc_p)
                await db.flush()
                d = Device(location_id=loc_p.id, name="perf-device", vendor="fortigate", status="online")
                db.add(d)
                await db.flush()

                now = datetime.now(timezone.utc)
                for i in range(1000):
                    db.add(FirewallLog(
                        tenant_id=t.id,
                        customer_id=c.id, device_id=d.id, vendor="fortigate",
                        log_type="traffic" if i % 3 else "event",
                        severity="info" if i % 5 else "critical",
                        action="accept" if i % 2 else "deny",
                        src_ip=f"10.0.0.{i % 255}", dst_ip=f"8.8.8.{i % 20}",
                        src_port=10000 + i, dst_port=443, proto="TCP", service="HTTPS",
                        user=f"user-{i % 50}", policyid=i % 10 + 1,
                        duration=100 + i, sentbyte=1000 * (i + 1), rcvdbyte=2000 * (i + 1),
                        session_id=f"sess-perf-{i}", received_at=now, event_time=now,
                        raw_syslog="perf test", parsed_fields={},
                    ))
                await db.flush()

                user = type("TestUser", (), {
                    "tenant_id": t.id, "id": uuid.uuid4(),
                    "role": "super_admin", "is_active": True,
                })()
                trials = []
                for _ in range(3):
                    t0 = time.monotonic()
                    result = await search_firewall_logs(db, user, LogSearchParams(vendor="fortigate", limit=50))
                    trials.append((time.monotonic() - t0) * 1000)

                avg_ms = sum(trials) / len(trials)
                assert avg_ms < 10000, f"Avg {avg_ms:.1f}ms > 10s"
                assert result.total >= 1000
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_facets_under_1s(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.devices.models import Device
                t = Tenant(name="Facet Tenant", slug="facet-tenant", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="Facet Customer")
                db.add(c)
                await db.flush()
                await db.refresh(c)
                from app.modules.locations.models import Location
                loc_f = Location(customer_id=c.id, name="Facet Loc")
                db.add(loc_f)
                await db.flush()
                d = Device(location_id=loc_f.id, name="facet-device", vendor="fortigate", status="online")
                db.add(d)
                await db.flush()

                now = datetime.now(timezone.utc)
                for i in range(1000):
                    db.add(FirewallLog(
                        tenant_id=t.id,
                        customer_id=c.id, device_id=d.id, vendor="fortigate",
                        log_type="traffic", severity="info", action="accept",
                        src_ip=f"10.0.0.{i % 255}", dst_ip="8.8.8.8",
                        session_id=f"sess-facet-{i}", received_at=now, event_time=now,
                        raw_syslog="facet test", parsed_fields={},
                    ))
                await db.flush()

                user = type("TestUser", (), {
                    "tenant_id": t.id, "id": uuid.uuid4(),
                    "role": "super_admin", "is_active": True,
                })()
                t0 = time.monotonic()
                facets = await get_facets(db, user, LogSearchParams(vendor="fortigate"))
                elapsed = (time.monotonic() - t0) * 1000
                assert elapsed < 20000, f"Facets {elapsed:.1f}ms > 20s"
                assert facets.vendor is not None
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_export_1000_rows_under_5s(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.devices.models import Device
                t = Tenant(name="Exp Tenant", slug="export-tenant", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="Exp Customer")
                db.add(c)
                await db.flush()
                await db.refresh(c)
                from app.modules.locations.models import Location
                loc_e = Location(customer_id=c.id, name="Exp Loc")
                db.add(loc_e)
                await db.flush()
                d = Device(location_id=loc_e.id, name="exp-device", vendor="fortigate", status="online")
                db.add(d)
                await db.flush()

                now = datetime.now(timezone.utc)
                for i in range(1000):
                    db.add(FirewallLog(
                        tenant_id=t.id,
                        customer_id=c.id, device_id=d.id, vendor="fortigate",
                        log_type="traffic", severity="info", action="accept",
                        src_ip=f"10.0.0.{i % 255}", dst_ip="8.8.8.8",
                        session_id=f"sess-exp-{i}", received_at=now, event_time=now,
                        raw_syslog="export test", parsed_fields={},
                    ))
                await db.flush()

                user = type("TestUser", (), {
                    "tenant_id": t.id, "id": uuid.uuid4(),
                    "role": "super_admin", "is_active": True,
                })()
                t0 = time.monotonic()
                csv_stream, _ = await export_firewall_logs(db, user, LogSearchParams(vendor="fortigate", limit=1000), fmt="csv")
                content = b"".join([chunk async for chunk in csv_stream])
                elapsed = (time.monotonic() - t0) * 1000
                assert elapsed < 30000, f"Export {elapsed:.1f}ms > 30s"
                lines = content.decode("utf-8").strip().split("\n")
                assert len(lines) == 1001
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())
