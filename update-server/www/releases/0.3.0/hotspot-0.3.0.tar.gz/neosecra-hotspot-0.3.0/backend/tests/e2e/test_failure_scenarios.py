from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.firewall_adapters.base import ConnectionConfig
from app.modules.firewall_adapters.fortigate import FortiGateAdapter
from app.modules.portal.flow import verify as portal_verify
from app.modules.sessions.models import GuestSession, STATUS_EXPIRED
from app.modules.syslog.models import FirewallLog
from app.modules.search.schemas import LogSearchParams
from app.modules.search.service import search_firewall_logs
from tests.fake_fortigate_server import FakeFortiGateServer
from .conftest import create_db_session, close_db_session


@pytest.mark.e2e
class TestFailureScenarios:

    def test_wrong_sms_code_returns_401(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.locations.models import Location
                from app.modules.devices.models import Device
                from app.modules.portal.models import PortalTemplate, METHOD_SMS

                t = Tenant(name="Fail Tenant", slug="fail-tenant", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="Fail Customer")
                db.add(c)
                await db.flush()
                await db.refresh(c)
                loc_f = Location(customer_id=c.id, name="Fail Location")
                db.add(loc_f)
                await db.flush()
                d = Device(location_id=loc_f.id, name="fail-device", vendor="fortigate", status="online")
                db.add(d)
                tmpl = PortalTemplate(customer_id=c.id, location_id=loc_f.id, name="F", method=METHOD_SMS, is_default=True, theme={}, fields=[])
                db.add(tmpl)
                await db.flush()

                with mock.patch(
                    "app.modules.sms.service.verify_otp",
                    side_effect=HTTPException(status_code=400, detail="Gecersiz kod"),
                ):
                    with pytest.raises(HTTPException) as exc_info:
                        await portal_verify(db, device_id=d.id, phone="+905551112233", code="000000")
                    assert exc_info.value.status_code == 400
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_expired_session_cannot_authorize(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                t = Tenant(name="Exp Tenant", slug="exp-tenant", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="Exp Customer")
                db.add(c)
                await db.flush()

                now = datetime.now(timezone.utc)
                from datetime import timedelta
                expired = GuestSession(
                    customer_id=c.id, mac="AA:BB:CC:DD:EE:FF", ip="10.0.0.200",
                    auth_method="sms", status=STATUS_EXPIRED,
                    started_at=now - timedelta(hours=5),
                    expires_at=now - timedelta(hours=1),
                    ended_at=now - timedelta(hours=1),
                    terms_accepted=True, privacy_accepted=True,
                )
                db.add(expired)
                await db.flush()
                await db.refresh(expired)
                assert expired.status == STATUS_EXPIRED
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_syslog_listener_down_graceful_degradation(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.devices.models import Device
                t = Tenant(name="Grace Tenant", slug="grace-tenant", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="Grace Customer")
                db.add(c)
                await db.flush()
                await db.refresh(c)
                from app.modules.locations.models import Location
                loc_g = Location(customer_id=c.id, name="Grace Loc")
                db.add(loc_g)
                await db.flush()
                d = Device(location_id=loc_g.id, name="grace-device", vendor="fortigate", status="online")
                db.add(d)
                await db.flush()

                now = datetime.now(timezone.utc)
                db.add(FirewallLog(
                    tenant_id=t.id,
                    customer_id=c.id, device_id=d.id, vendor="fortigate",
                    log_type="traffic", severity="info", action="accept",
                    src_ip="10.0.0.99", dst_ip="8.8.8.8",
                    session_id="sess-graceful-1", received_at=now, event_time=now,
                    raw_syslog="graceful test", parsed_fields={},
                ))
                await db.flush()

                user = type("TestUser", (), {
                    "tenant_id": t.id, "id": uuid.uuid4(),
                    "role": "super_admin", "is_active": True,
                })()
                result = await search_firewall_logs(db, user, LogSearchParams(src_ip="10.0.0.99"))
                assert result.total >= 1
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_fortigate_adapter_connection_refused(self):
        async def _run():
            config = ConnectionConfig(
                vendor="fortigate", api_host="127.0.0.1", api_port=1,
                api_token="invalid", verify_tls=False, api_tls=False,
            )
            adapter = FortiGateAdapter(config)
            result = await adapter.test_connection()
            assert result.ok is False
        asyncio.run(_run())

    def test_fortigate_authorize_guest_401(self):
        async def _run():
            async with FakeFortiGateServer() as fg:
                fg.simulate_401 = True
                config = ConnectionConfig(
                    vendor="fortigate", api_host="127.0.0.1", api_port=fg.port,
                    api_token="bad-token", verify_tls=False, api_tls=False,
                )
                adapter = FortiGateAdapter(config)
                session = {"ip": "10.0.0.50", "mac": "AA:BB:CC:DD:EE:FF", "session_id": str(uuid.uuid4())}
                result = await adapter.authorize_guest(session)
                assert result.ok is False
        asyncio.run(_run())
