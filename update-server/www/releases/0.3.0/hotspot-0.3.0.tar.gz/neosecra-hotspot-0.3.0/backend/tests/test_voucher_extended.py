"""Extended voucher service tests — hash/gen helpers, redeem error paths."""
import uuid
from unittest import mock

import pytest
from fastapi import HTTPException


def _scope(customer_id=None):
    from app.core.tenant import ScopeContext, TenantLevel
    return ScopeContext(
        level=TenantLevel.CUSTOMER if customer_id else TenantLevel.GLOBAL,
        allowed=True,
        customer_id=customer_id,
    )


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    r.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


class TestHashAndGenCode:
    def test_hash_code(self):
        from app.modules.vouchers.service import _hash_code
        code = "TESTCODE123"
        h1 = _hash_code(code)
        h2 = _hash_code(code)
        assert h1 == h2
        assert isinstance(h1, str)
        assert h1 != code

    def test_gen_code_format(self):
        from app.modules.vouchers.service import _gen_code
        code = _gen_code(prefix="TEST")
        assert code.startswith("TEST")
        assert len(code) > 4

    def test_gen_code_length(self):
        from app.modules.vouchers.service import _gen_code
        code = _gen_code(prefix="X")
        assert len(code) >= 6


class TestRedeemErrors:
    @pytest.mark.asyncio
    async def test_redeem_not_found(self):
        from app.modules.vouchers.service import redeem
        db = _mock_db()
        with pytest.raises(Exception):
            await redeem(db, code="NONEXIST", customer_id=uuid.uuid4())

    @pytest.mark.asyncio
    async def test_redeem_empty_code_still_fails(self):
        from app.modules.vouchers.service import redeem
        db = _mock_db()
        with pytest.raises(Exception):
            await redeem(db, code="", customer_id=uuid.uuid4())


class TestVoucherBatch:
    @pytest.mark.asyncio
    async def test_get_batch_not_found_with_scope(self):
        from app.modules.vouchers.service import get_batch
        db = _mock_db()
        db.get.return_value = None
        with pytest.raises(HTTPException) as exc:
            await get_batch(db, uuid.uuid4(), scope=_scope(customer_id=uuid.uuid4()))
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_list_batches_returns_list(self):
        from app.modules.vouchers.service import list_batches
        db = _mock_db()
        result = await list_batches(db, scope=_scope())
        assert result == []
