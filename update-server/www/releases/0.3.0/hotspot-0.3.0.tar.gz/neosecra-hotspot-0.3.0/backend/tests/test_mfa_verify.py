"""MFA verification tests — helper functions, edge cases, error paths."""
import uuid
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.mfa.service import (
    _hash_code,
    _constant_time_eq,
    _generate_code,
    _backup_code,
)


def test_generate_code_default():
    code = _generate_code()
    assert len(code) == 6
    assert code.isdigit()


def test_generate_code_custom():
    code = _generate_code(length=10)
    assert len(code) == 10


def test_generate_code_randomness():
    codes = {_generate_code() for _ in range(100)}
    assert len(codes) > 90


def test_hash_code_consistency():
    h1 = _hash_code("test123")
    h2 = _hash_code("test123")
    assert h1 == h2


def test_hash_code_different():
    h1 = _hash_code("test123")
    h2 = _hash_code("test456")
    assert h1 != h2


def test_constant_time_eq_same():
    assert _constant_time_eq("abc", "abc") is True


def test_constant_time_eq_different():
    assert _constant_time_eq("abc", "xyz") is False


def test_constant_time_eq_empty():
    assert _constant_time_eq("", "") is True


def test_backup_code_format():
    code = _backup_code()
    assert len(code) == 12
    assert all(c in "0123456789abcdef" for c in code)


def test_backup_code_uniqueness():
    codes = {_backup_code() for _ in range(50)}
    assert len(codes) == 50


class TestMfaServiceIntegration:
    @pytest.mark.asyncio
    async def test_activate_totp_no_token(self):
        from app.modules.mfa.service import activate_totp
        db = mock.AsyncMock()
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        db.execute.return_value = r
        with pytest.raises(HTTPException) as exc:
            await activate_totp(db, uuid.uuid4(), code="123456")
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_get_mfa_status_no_user(self):
        from app.modules.mfa.service import get_mfa_status
        db = mock.AsyncMock()
        db.get = mock.AsyncMock(return_value=None)
        r = mock.MagicMock()
        r.all.return_value = []
        db.execute.return_value = r
        status = await get_mfa_status(db, uuid.uuid4())
        assert status["mfa_required"] is False
        assert status["methods"] == []

    @pytest.mark.asyncio
    async def test_verify_backup_code_missing(self):
        from app.modules.mfa.service import verify_backup_code
        db = mock.AsyncMock()
        r = mock.MagicMock()
        r.first.return_value = None
        r.scalars.return_value = r
        db.execute.return_value = r
        with pytest.raises(HTTPException) as exc:
            await verify_backup_code(db, uuid.uuid4(), code="test1234")
        assert exc.value.status_code == 400
