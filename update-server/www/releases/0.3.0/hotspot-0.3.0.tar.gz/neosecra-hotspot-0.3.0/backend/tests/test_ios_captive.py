"""Tests for Apple iOS/macOS captive portal detection endpoints."""
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


class TestHotspotDetect:
    def test_hotspot_detect_no_token_returns_redirect(self):
        r = client.get("/hotspot-detect.html", follow_redirects=False)
        assert r.status_code in (302, 307)
        assert "/portal/config" in r.headers.get("location", "")

    def test_hotspot_detect_with_token_returns_success(self):
        r = client.get(
            "/hotspot-detect.html",
            headers={"X-Portal-Token": "valid-token-123"},
        )
        assert r.status_code == 200
        assert "Success" in r.text


class TestGenerate204:
    def test_generate_204_no_token_returns_redirect(self):
        r = client.get("/generate_204", follow_redirects=False)
        assert r.status_code in (302, 307)
        assert "/portal/config" in r.headers.get("location", "")

    def test_generate_204_with_token_returns_204(self):
        r = client.get(
            "/generate_204",
            headers={"X-Portal-Token": "valid-token-123"},
        )
        assert r.status_code == 204


class TestNcsiTxt:
    def test_ncsi_txt_no_token_returns_redirect(self):
        r = client.get("/ncsi.txt", follow_redirects=False)
        assert r.status_code in (302, 307)
        assert "/portal/config" in r.headers.get("location", "")

    def test_ncsi_txt_with_token_returns_microsoft_ncsi(self):
        r = client.get(
            "/ncsi.txt",
            headers={"X-Portal-Token": "valid-token-123"},
        )
        assert r.status_code == 200
        assert "Microsoft NCSI" in r.text
