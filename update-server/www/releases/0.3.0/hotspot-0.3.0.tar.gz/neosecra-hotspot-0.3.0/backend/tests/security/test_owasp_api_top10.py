"""OWASP API Top 10 (2023) güvenlik testleri.

Kapsam:
  API1: BOLA/IDOR — cross-tenant resource access
  API2: Broken Auth — JWT forgery, weak signature, expired token
  API3: Excessive Data Exposure — secret fields in responses
  API4: Rate Limit — brute force login blocking
  API5: Broken Function Auth — RBAC matrix (5 roles)
  API6: Mass Assignment — role/tenant_id override via body
  API7: Security Misconfig — debug, CORS, security headers
  API8: Injection — SQL/NoSQL/command in filter params
  API9: Improper Assets — staging endpoints leaked
  API10: Insufficient Logging — failed auth audit trail
"""
import uuid
import unittest.mock as mock

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.core.security import create_access_token
from app.modules.auth.models import User

client = TestClient(app)


@pytest.fixture(autouse=True)
def _mock_redis():
    incr_store = {}

    async def incr_side_effect(key):
        incr_store[key] = incr_store.get(key, 0) + 1
        return incr_store[key]

    async def delete_side(key):
        incr_store.pop(key, None)
        return True

    async def get_side(key):
        return incr_store.get(key)

    r = mock.AsyncMock()
    r.get.side_effect = get_side
    r.set.return_value = True
    r.setex.side_effect = lambda k, t, v: True
    r.delete.side_effect = delete_side
    r.incr.side_effect = incr_side_effect
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield


def _make_user(role="customer_admin", customer_id=None, partner_id=None,
               tenant_id=None, location_id=None):
    uid = uuid.uuid4()
    return User(
        id=uid,
        email=f"{role}@hotspot.io",
        full_name=f"{role.title()} User",
        hashed_password="hashed",
        role=role,
        is_active=True,
        tenant_id=tenant_id or uuid.uuid4(),
        partner_id=partner_id,
        customer_id=customer_id,
        location_id=location_id,
        is_2fa_enabled=False,
    )


def _mock_user(**overrides):
    uid = overrides.pop("id", uuid.uuid4())
    return mock.MagicMock(
        id=uid,
        email=overrides.pop("email", "user@hotspot.io"),
        full_name=overrides.pop("full_name", "Test User"),
        hashed_password=overrides.pop("hashed_password", "hashed"),
        role=overrides.pop("role", "customer_admin"),
        is_active=overrides.pop("is_active", True),
        tenant_id=overrides.pop("tenant_id", uuid.uuid4()),
        customer_id=overrides.pop("customer_id", uuid.uuid4()),
        partner_id=overrides.pop("partner_id", None),
        location_id=overrides.pop("location_id", None),
        is_2fa_enabled=overrides.pop("is_2fa_enabled", False),
        **overrides,
    )


def _token_for(user):
    return create_access_token(str(user.id), extra={"type": "access"})


def _build_mock_db(user):
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = user
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = user
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.first.return_value = user
    mock_scalar_result.all.return_value = []
    mock_result.scalars.return_value = mock_scalar_result
    mock_db.execute.return_value = mock_result
    mock_db.add = mock.AsyncMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()
    return mock_db


# =====================================================================
# API1: BOLA/IDOR — cross-tenant resource access
# =====================================================================

ENDPOINTS_BY_SCOPE = [
    ("GET", "/api/v1/tenants"),
    ("GET", "/api/v1/customers"),
    ("GET", "/api/v1/locations"),
    ("GET", "/api/v1/devices"),
    ("GET", "/api/v1/sessions"),
    ("GET", "/api/v1/vouchers"),
    ("GET", "/api/v1/licenses"),
    ("GET", "/api/v1/user-groups"),
    ("GET", "/api/v1/logs-5651"),
]


@pytest.mark.parametrize("method,path", ENDPOINTS_BY_SCOPE)
def test_api1_cross_tenant_idor(method, path):
    """API1: User from tenant A must not access tenant B's resources."""
    tenant_a = uuid.uuid4()

    mock_user = _mock_user(role="customer_admin", customer_id=uuid.uuid4(), tenant_id=tenant_a)
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        user = _make_user(role="customer_admin", customer_id=uuid.uuid4(), tenant_id=tenant_a)
        response = client.get(
            f"{path}?customer_id={uuid.uuid4()}",
            headers={"Authorization": f"Bearer {_token_for(user)}"},
        )

    app.dependency_overrides.clear()
    assert response.status_code in (200, 403, 404), (
        f"API1 fail: {method} {path} cross-tenant returned {response.status_code}"
    )


# =====================================================================
# API2: Broken Authentication
# =====================================================================

def test_api2_jwt_alg_none():
    """API2: JWT with alg:none must be rejected."""
    import jwt as pyjwt
    token = pyjwt.encode(
        {"sub": str(uuid.uuid4()), "type": "access"},
        key="",
        algorithm="none",
    )
    response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 401, (
        f"alg:none token should be rejected, got {response.status_code}"
    )


def test_api2_jwt_hs256_weak_key():
    """API2: JWT signed with wrong/weak key must be rejected."""
    import jwt as pyjwt
    token = pyjwt.encode(
        {"sub": str(uuid.uuid4()), "type": "access"},
        key="weak",
        algorithm="HS256",
    )
    response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 401, (
        f"Wrong-key JWT should be rejected, got {response.status_code}"
    )


def test_api2_jwt_expired():
    """API2: Expired access token must be rejected."""
    token = create_access_token(str(uuid.uuid4()), extra={"type": "access"}, expires_minutes=-1)
    response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 401, (
        f"Expired token should return 401, got {response.status_code}"
    )


def test_api2_refresh_token_as_access():
    """API2: Refresh token used as access token must fail."""
    from app.core.security import create_refresh_token
    token = create_refresh_token(str(uuid.uuid4()))
    response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 401, (
        f"Refresh token as access should fail, got {response.status_code}"
    )


# =====================================================================
# API3: Excessive Data Exposure
# =====================================================================

SECRET_FIELD_PATTERNS = ["api_token", "password", "secret", "hashed_password",
                         "totp_secret", "token", "api_key"]


def test_api3_excessive_data_exposure():
    """API3: Sensitive fields must not appear in responses."""
    uid = uuid.uuid4()
    mock_user = _mock_user(role="super_admin", id=uid)
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    sample_endpoints = [
        ("GET", "/api/v1/auth/me"),
        ("GET", "/api/v1/customers"),
        ("GET", "/api/v1/devices"),
        ("GET", "/api/v1/sessions"),
        ("GET", "/api/v1/tenants"),
        ("GET", "/api/v1/locations"),
    ]

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        user = _make_user(role="super_admin")
        for method, path in sample_endpoints:
            response = client.get(
                path,
                headers={"Authorization": f"Bearer {_token_for(user)}"},
            )
            body = response.text.lower()
            for field in SECRET_FIELD_PATTERNS:
                assert field not in body, (
                    f"API3: Secret field '{field}' leaked in {method} {path}"
                )

    app.dependency_overrides.clear()


# =====================================================================
# API4: Rate Limiting
# =====================================================================

def test_api4_rate_limit_login_attempts():
    """API4: Brute force login attempts must be rate-limited."""
    from app.core.security import rate_limit_check
    from app.core.config import settings

    import asyncio
    key = f"test:login:{uuid.uuid4()}"
    blocked = False
    blocked_at = 0

    for i in range(10):
        is_blocked, attempts = asyncio.run(rate_limit_check(key))
        if is_blocked:
            blocked = True
            blocked_at = i + 1
            break

    assert blocked, (
        "API4: Rate limit should block after max_attempts"
    )
    assert blocked_at <= settings.LOGIN_MAX_ATTEMPTS + 1, (
        f"Blocked at {blocked_at} but max is {settings.LOGIN_MAX_ATTEMPTS}"
    )


# =====================================================================
# API5: Broken Function Level Authorization
# =====================================================================

RBAC_MATRIX = [
    ("super_admin", "device.write", True),
    ("super_admin", "system.write", True),
    ("partner_admin", "device.write", True),
    ("partner_admin", "system.write", True),
    ("customer_admin", "device.write", True),
    ("customer_admin", "system.write", False),
    ("customer_admin", "system.read", True),
    ("location_manager", "device.read", True),
    ("location_manager", "device.write", False),
    ("location_manager", "system.write", False),
    ("support", "session.read", True),
    ("support", "device.write", False),
    ("support", "system.write", False),
    ("support", "log.read", True),
]


@pytest.mark.parametrize("role,permission,expected", RBAC_MATRIX)
def test_api5_rbac_matrix(role, permission, expected):
    """API5: RBAC permission check for all 5 roles."""
    from app.core.rbac import has_permission

    result = has_permission(role, permission)
    assert result == expected, (
        f"API5: Role '{role}' permission '{permission}' "
        f"expected {expected}, got {result}"
    )


# =====================================================================
# API6: Mass Assignment
# =====================================================================

def test_api6_role_override_in_body():
    """API6: Attempt to escalate role via PATCH body must be rejected."""
    uid = uuid.uuid4()
    mock_user = _mock_user(role="customer_admin", tenant_id=uuid.uuid4(), id=uid)
    mock_user.role = "customer_admin"

    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        response = client.patch(
            "/api/v1/auth/me",
            json={"role": "super_admin"},
            headers={"Authorization": f"Bearer {_token_for(mock_user)}"},
        )

    app.dependency_overrides.clear()
    assert response.status_code in (200, 422, 403), (
        f"API6: Role escalation attempt returned {response.status_code}"
    )
    if response.status_code == 200:
        data = response.json()
        assert data.get("role") != "super_admin", (
            "API6: Role escalated to super_admin via mass assignment!"
        )


def test_api6_tenant_id_override():
    """API6: Attempt to change tenant_id via body must be rejected."""
    uid = uuid.uuid4()
    mock_user = _mock_user(role="customer_admin", id=uid)

    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    other_tenant = uuid.uuid4()
    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        response = client.patch(
            "/api/v1/auth/me",
            json={"tenant_id": str(other_tenant)},
            headers={"Authorization": f"Bearer {_token_for(mock_user)}"},
        )

    app.dependency_overrides.clear()
    assert response.status_code in (200, 422), (
        f"API6: tenant_id override attempt returned {response.status_code}"
    )


# =====================================================================
# API7: Security Misconfiguration
# =====================================================================

def test_api7_debug_mode():
    """API7: Debug mode must be False in production-like mode."""
    from app.core.config import settings
    if settings.ENVIRONMENT == "production":
        assert settings.DEBUG is False, (
            "API7: DEBUG is True in production!"
        )


def test_api7_cors_origins_no_wildcard():
    """API7: CORS origins must not use wildcard."""
    from app.core.config import settings
    origins = settings.cors_origins_list
    assert "*" not in origins, (
        "API7: CORS wildcard '*' is not allowed"
    )


# =====================================================================
# API8: Injection
# =====================================================================

INJECTION_PAYLOADS = [
    "' OR '1'='1",
    "'; DROP TABLE users; --",
    "1; SELECT * FROM users",
    "${7*7}",
    "{{7*7}}",
    "<script>alert(1)</script>",
    "'; exec xp_cmdshell('dir'); --",
]


@pytest.mark.parametrize("payload", INJECTION_PAYLOADS)
def test_api8_injection_filter_params(payload):
    """API8: Injection payloads in filter params must not crash/leak."""
    mock_user = _mock_user(role="customer_admin")
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    token = create_access_token(str(mock_user.id), extra={"type": "access"})

    for endpoint in ["/api/v1/devices", "/api/v1/sessions", "/api/v1/locations"]:
        with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                         new_callable=mock.AsyncMock) as tb:
            tb.return_value = False
            response = client.get(
                f"{endpoint}?name={payload}",
                headers={"Authorization": f"Bearer {token}"},
            )
        assert response.status_code not in (500,), (
            f"API8: Injection '{payload}' caused 500 on {endpoint}"
        )

    app.dependency_overrides.clear()


# =====================================================================
# API9: Improper Assets Management
# =====================================================================

STAGING_PATTERNS = [
    "/api/v1/health",
    "/api/v1/docs",
    "/api/v1/openapi.json",
    "/api/v1/redoc",
]


@pytest.mark.parametrize("path", STAGING_PATTERNS)
def test_api9_staging_endpoint_leak(path):
    """API9: Staging/internal endpoints must not leak sensitive info."""
    response = client.get(path)
    assert response.status_code in (200, 404, 403), (
        f"API9: {path} returned {response.status_code} (unexpected)"
    )
    body = response.text.lower() if response.text else ""
    sensitive = ["secret", "password", "api_key", "token", "private_key"]
    for s in sensitive:
        assert s not in body, (
            f"API9: Sensitive data leaked in {path}: '{s}' found"
        )


# =====================================================================
# API10: Insufficient Logging & Monitoring
# =====================================================================

def test_api10_failed_auth_event():
    """API10: Failed auth should return None (no user found)."""
    from app.modules.auth import service as auth_service

    from app.modules.auth.schemas import LoginRequest
    from fastapi import HTTPException

    mock_db = mock.AsyncMock()
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = None
    mock_db.execute.return_value = mock_result
    mock_db.get.return_value = None

    body = LoginRequest(email="nonexistent@test.com", password="wrong")

    import asyncio
    with mock.patch("app.modules.auth.service.verify_password", return_value=False):
        with mock.patch("app.modules.auth.service.rate_limit_check",
                         mock.AsyncMock(return_value=(False, 1))):
            with pytest.raises(HTTPException) as exc_info:
                asyncio.run(
                    auth_service.authenticate(mock_db, body)
                )
    assert exc_info.value.status_code == 401, (
        "API10: Bad credentials should raise 401"
    )


def test_api8_path_traversal_payloads():
    """API8: Path traversal payloads in search/filter params must fail safely."""
    mock_user = _mock_user(role="customer_admin")
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    token = create_access_token(str(mock_user.id), extra={"type": "access"})
    traversal_payloads = ["../../../../etc/passwd", "..\\..\\windows\\system32", "....//....//etc/passwd"]

    for payload in traversal_payloads:
        with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as tb:
            tb.return_value = False
            response = client.get(
                f"/api/v1/devices?name={payload}",
                headers={"Authorization": f"Bearer {token}"},
            )
        assert response.status_code != 500
        assert "root:" not in response.text.lower()

    app.dependency_overrides.clear()


def test_api2_token_replay_blacklisting():
    """API2: Blacklisted JWT tokens must be rejected on protected routes."""
    mock_user = _mock_user(role="customer_admin")
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    token = create_access_token(str(mock_user.id), extra={"type": "access"})

    with mock.patch("app.modules.auth.deps.is_token_blacklisted", new_callable=mock.AsyncMock) as tb:
        tb.return_value = True  # Simulating revoked / blacklisted token
        response = client.get(
            "/api/v1/devices",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 401
        assert "kimlik" in response.text.lower() or "token" in response.text.lower()

    app.dependency_overrides.clear()
