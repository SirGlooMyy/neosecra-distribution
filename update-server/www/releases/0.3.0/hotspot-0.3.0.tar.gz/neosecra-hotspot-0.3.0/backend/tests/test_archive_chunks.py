"""Archive chunk test — models, repository, service build/verify with local cert."""
import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.modules.archive.hash_chain import GENESIS_HASH
from app.modules.archive.models import (
    CHUNK_STATUS_FAILED,
    CHUNK_STATUS_PENDING,
    CHUNK_STATUS_SIGNED,
    CHUNK_STATUS_UPLOADED,
    CHUNK_STATUS_VERIFIED,
    ArchiveChunk,
)
from app.modules.archive.repository import (
    create_chunk,
    get_chunk,
    get_latest_chunk,
    list_chunks,
)
from app.modules.archive.schemas import BuildResult, ChunkOut, VerifyResult
from app.modules.archive.service import (
    _build_minio_key,
    _compute_content_hash,
    build_chunk_for_period,
    sign_chunk_with_local_cert,
    upload_to_minio_worm,
    verify_chunk_integrity,
)

TEST_CERT_PATH = os.path.join(
    os.path.dirname(__file__), "data", "test-cert.p12"
)
TEST_CERT_PASSWORD = "test123"


def _make_db_mock():
    db = AsyncMock()
    db.add = MagicMock()
    db.flush = AsyncMock()
    db.refresh = AsyncMock()
    db.get = AsyncMock(return_value=None)
    execute_res = MagicMock()
    execute_res.scalars.return_value.all.return_value = []
    execute_res.scalar_one_or_none.return_value = None
    db.execute = AsyncMock(return_value=execute_res)
    return db


def _make_chunk(customer_id=None, prev_hash=None):
    from app.modules.archive.hash_chain import compute_chain_hash

    cid = customer_id or uuid.uuid4()
    prev = prev_hash or GENESIS_HASH
    ps = datetime(2026, 7, 26, tzinfo=timezone.utc)
    pe = datetime(2026, 7, 27, tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    logs = [{"seq": 1, "type": "test", "logged_at": "2026-07-26T12:00:00"}]
    final_hash, intermediates = compute_chain_hash(logs, prev)
    chunk_data = {
        "logs": logs,
        "chain": {"prev_hash": prev, "curr_hash": final_hash, "intermediate_hashes": intermediates},
        "period": {"start": ps.isoformat(), "end": pe.isoformat()},
        "customer_id": str(cid),
        "generated_at": now.isoformat(),
    }
    chunk_json = json.dumps(chunk_data, sort_keys=True, ensure_ascii=False)
    content_hash_val = hashlib.sha256(chunk_json.encode()).hexdigest()
    return ArchiveChunk(
        id=uuid.uuid4(),
        customer_id=cid,
        period_start=ps,
        period_end=pe,
        log_count=1,
        content_hash=content_hash_val,
        curr_hash=final_hash,
        prev_hash=prev,
        intermediate_hashes=intermediates,
        status=CHUNK_STATUS_PENDING,
        content_size=len(chunk_json.encode()),
        meta={"_chunk_json": chunk_json},
        created_at=now,
    )


# ---- model tests ------------------------------------------------------------


def test_archive_chunk_create():
    chunk = _make_chunk()
    assert chunk.status == CHUNK_STATUS_PENDING
    assert len(chunk.content_hash) == 64
    assert chunk.prev_hash == GENESIS_HASH


def test_archive_chunk_statuses():
    for s in (CHUNK_STATUS_PENDING, CHUNK_STATUS_SIGNED, CHUNK_STATUS_UPLOADED, CHUNK_STATUS_VERIFIED, CHUNK_STATUS_FAILED):
        chunk = _make_chunk()
        chunk.status = s
        assert chunk.status == s


# ---- repository tests -------------------------------------------------------


@pytest.mark.asyncio
async def test_create_chunk():
    db = _make_db_mock()
    chunk = _make_chunk()
    result = await create_chunk(db, chunk)
    assert result is chunk
    db.add.assert_called_once_with(chunk)


@pytest.mark.asyncio
async def test_get_chunk_not_found():
    db = _make_db_mock()
    result = await get_chunk(db, uuid.uuid4())
    assert result is None


@pytest.mark.asyncio
async def test_list_chunks_empty():
    db = _make_db_mock()
    result = await list_chunks(db, uuid.uuid4())
    assert result == []


@pytest.mark.asyncio
async def test_get_latest_chunk_none():
    db = _make_db_mock()
    result = await get_latest_chunk(db, uuid.uuid4())
    assert result is None


# ---- build_minio_key --------------------------------------------------------


def test_build_minio_key():
    cid = uuid.uuid4()
    ps = datetime(2026, 7, 27, tzinfo=timezone.utc)
    chunk_id = uuid.uuid4()
    key = _build_minio_key(cid, ps, chunk_id)
    assert str(cid) in key
    assert "2026/07/27" in key
    assert str(chunk_id) in key
    assert key.endswith(".json")


# ---- compute_content_hash ---------------------------------------------------


def test_compute_content_hash():
    data = '{"test": "data"}'
    h = _compute_content_hash(data)
    assert len(h) == 64
    expected = hashlib.sha256(data.encode("utf-8")).hexdigest()
    assert h == expected


# ---- sign_chunk_with_local_cert (uses real test cert) -----------------------


@pytest.mark.asyncio
async def test_sign_chunk_with_local_cert():
    if not os.path.exists(TEST_CERT_PATH):
        pytest.skip("test-cert.p12 not found, skipping local cert test")

    db = _make_db_mock()
    chunk = _make_chunk()
    result = await sign_chunk_with_local_cert(
        db, chunk, TEST_CERT_PATH, TEST_CERT_PASSWORD
    )
    assert result.signature_value is not None
    assert result.signature_time is not None
    assert result.certificate_serial is not None
    assert result.sign_method == "localfile"
    assert result.status == CHUNK_STATUS_SIGNED


@pytest.mark.asyncio
async def test_sign_chunk_with_local_cert_empty_cert():
    db = _make_db_mock()
    chunk = _make_chunk()
    with pytest.raises(FileNotFoundError):
        await sign_chunk_with_local_cert(
            db, chunk, "/nonexistent/cert.p12", "pass"
        )


# ---- upload_to_minio_worm (local mode) --------------------------------------


@pytest.mark.asyncio
async def test_upload_to_minio_worm_local(monkeypatch):
    from app.core.config import settings

    monkeypatch.setattr(settings, "ARCHIVE_PROVIDER", "local")
    monkeypatch.setattr(settings, "ARCHIVE_LOCAL_DIR", "/tmp/_test_archives")

    chunk = _make_chunk()
    content = b'{"test": "data"}'
    result = await upload_to_minio_worm(chunk, content)
    assert result.startswith("local:")
    assert chunk.status == CHUNK_STATUS_UPLOADED
    os.remove(result[6:])


# ---- verify_chunk_integrity -------------------------------------------------


@pytest.mark.asyncio
async def test_verify_chunk_integrity_not_found():
    db = _make_db_mock()
    result = await verify_chunk_integrity(db, uuid.uuid4())
    assert result.ok is False
    assert "not found" in result.message.lower()


@pytest.mark.asyncio
async def test_verify_chunk_integrity_no_meta():
    db = _make_db_mock()

    async def _fake_get(db, cid):
        return ArchiveChunk(
            id=cid,
            customer_id=uuid.uuid4(),
            period_start=datetime.now(timezone.utc),
            period_end=datetime.now(timezone.utc),
            log_count=0,
            content_hash="a" * 64,
            curr_hash="b" * 64,
            prev_hash=GENESIS_HASH,
            intermediate_hashes=[],
            status=CHUNK_STATUS_PENDING,
            content_size=0,
            meta={},
        )

    originals = {}

    from app.modules.archive import repository as repo_mod

    orig_get = repo_mod.get_chunk
    repo_mod.get_chunk = _fake_get
    try:
        result = await verify_chunk_integrity(db, uuid.uuid4())
        assert result.ok is False
    finally:
        repo_mod.get_chunk = orig_get


@pytest.mark.asyncio
async def test_verify_chunk_integrity_valid():
    db = _make_db_mock()
    chunk = _make_chunk()

    async def _fake_get(db, cid):
        return chunk

    from app.modules.archive import service as svc_mod

    orig_get = svc_mod.get_chunk
    svc_mod.get_chunk = _fake_get
    try:
        result = await verify_chunk_integrity(db, chunk.id)
        assert result.ok is True
        assert result.chain_valid is True
    finally:
        svc_mod.get_chunk = orig_get


# ---- BuildResult / ChunkOut schemas -----------------------------------------


def test_build_result_schema():
    br = BuildResult(
        chunk_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        period_start=datetime.now(timezone.utc),
        period_end=datetime.now(timezone.utc),
        log_count=5,
        curr_hash="h" * 64,
        status=CHUNK_STATUS_PENDING,
    )
    assert br.log_count == 5


def test_chunk_out_from_attributes():
    chunk = _make_chunk()
    out = ChunkOut.model_validate(chunk)
    assert out.id == chunk.id
    assert out.content_hash == chunk.content_hash
    assert out.status == CHUNK_STATUS_PENDING


def test_verify_result_schema():
    vr = VerifyResult(
        chunk_id=uuid.uuid4(),
        ok=True,
        chain_valid=True,
        signature_valid=True,
        message="All good",
        verified_at=datetime.now(timezone.utc),
    )
    assert vr.ok is True
