from __future__ import annotations

import asyncio
from datetime import datetime, timezone

import pytest
from sqlalchemy import select

from app.modules.archive.models import ArchiveChunk, CHUNK_STATUS_PENDING
from app.modules.customers.models import Customer
from app.modules.devices.models import Device
from app.modules.locations.models import Location
from app.modules.sessions.models import GuestSession, STATUS_ACTIVE
from app.modules.tenants.models import Tenant
from app.modules.syslog.models import FirewallLog
from .conftest import create_db_session, close_db_session


@pytest.mark.e2e
class TestMultiTenantIsolation:

    def test_tenant_a_syslog_not_visible_to_tenant_b(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                t_a = Tenant(name="Tenant A", slug="ta-syslog", is_root=False)
                db.add(t_a)
                t_b = Tenant(name="Tenant B", slug="tb-syslog", is_root=False)
                db.add(t_b)
                await db.flush()

                c_a = Customer(tenant_id=t_a.id, name="Cust A")
                db.add(c_a)
                c_b = Customer(tenant_id=t_b.id, name="Cust B")
                db.add(c_b)
                await db.flush()

                l_a = Location(customer_id=c_a.id, name="Loc A")
                db.add(l_a)
                l_b = Location(customer_id=c_b.id, name="Loc B")
                db.add(l_b)
                await db.flush()

                d_a = Device(location_id=l_a.id, name="Dev A", vendor="fortigate", status="online")
                db.add(d_a)
                d_b = Device(location_id=l_b.id, name="Dev B", vendor="fortigate", status="online")
                db.add(d_b)
                await db.flush()

                now = datetime.now(timezone.utc)
                for i in range(5):
                    db.add(FirewallLog(
                        tenant_id=t_a.id,
                        customer_id=c_a.id, device_id=d_a.id, vendor="fortigate",
                        log_type="traffic", severity="info", action="accept",
                        src_ip=f"10.0.0.{i}", dst_ip="8.8.8.8",
                        session_id=f"sess-a-{i}", received_at=now, event_time=now,
                        raw_syslog="a log", parsed_fields={},
                    ))
                for i in range(3):
                    db.add(FirewallLog(
                        tenant_id=t_b.id,
                        customer_id=c_b.id, device_id=d_b.id, vendor="fortigate",
                        log_type="traffic", severity="info", action="accept",
                        src_ip=f"10.0.0.{i}", dst_ip="8.8.8.8",
                        session_id=f"sess-b-{i}", received_at=now, event_time=now,
                        raw_syslog="b log", parsed_fields={},
                    ))
                await db.flush()

                res_a = await db.execute(
                    select(FirewallLog).where(FirewallLog.customer_id == c_a.id)
                )
                assert len(list(res_a.scalars().all())) == 5

                res_b = await db.execute(
                    select(FirewallLog).where(FirewallLog.customer_id == c_b.id)
                )
                assert len(list(res_b.scalars().all())) == 3
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_tenant_a_session_not_visible_to_tenant_b(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                t_a = Tenant(name="Tenant A", slug="ta-sess", is_root=False)
                db.add(t_a)
                t_b = Tenant(name="Tenant B", slug="tb-sess", is_root=False)
                db.add(t_b)
                await db.flush()

                c_a = Customer(tenant_id=t_a.id, name="Cust A")
                db.add(c_a)
                c_b = Customer(tenant_id=t_b.id, name="Cust B")
                db.add(c_b)
                await db.flush()

                now = datetime.now(timezone.utc)
                for _ in range(2):
                    db.add(GuestSession(
                        customer_id=c_a.id, mac="AA:AA:AA:AA:AA:01", ip="10.0.0.1",
                        auth_method="sms", status=STATUS_ACTIVE, started_at=now,
                        terms_accepted=True, privacy_accepted=True,
                    ))
                    db.add(GuestSession(
                        customer_id=c_b.id, mac="BB:BB:BB:BB:BB:01", ip="10.0.0.2",
                        auth_method="sms", status=STATUS_ACTIVE, started_at=now,
                        terms_accepted=True, privacy_accepted=True,
                    ))
                await db.flush()

                res_a = await db.execute(
                    select(GuestSession).where(GuestSession.customer_id == c_a.id)
                )
                assert len(list(res_a.scalars().all())) == 2

                res_b = await db.execute(
                    select(GuestSession).where(GuestSession.customer_id == c_b.id)
                )
                assert len(list(res_b.scalars().all())) == 2
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_tenant_a_archive_not_visible_to_tenant_b(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                t_a = Tenant(name="Tenant A", slug="ta-arch", is_root=False)
                db.add(t_a)
                t_b = Tenant(name="Tenant B", slug="tb-arch", is_root=False)
                db.add(t_b)
                await db.flush()

                c_a = Customer(tenant_id=t_a.id, name="Cust A")
                db.add(c_a)
                c_b = Customer(tenant_id=t_b.id, name="Cust B")
                db.add(c_b)
                await db.flush()

                now = datetime.now(timezone.utc)
                from datetime import timedelta
                db.add(ArchiveChunk(
                    customer_id=c_a.id, period_start=now - timedelta(days=1),
                    period_end=now, log_count=10,
                    content_hash="a" * 64, curr_hash="b" * 64,
                    prev_hash="0" * 64, intermediate_hashes=[],
                    status=CHUNK_STATUS_PENDING, content_size=1000, meta={},
                ))
                db.add(ArchiveChunk(
                    customer_id=c_b.id, period_start=now - timedelta(days=1),
                    period_end=now, log_count=5,
                    content_hash="c" * 64, curr_hash="d" * 64,
                    prev_hash="0" * 64, intermediate_hashes=[],
                    status=CHUNK_STATUS_PENDING, content_size=500, meta={},
                ))
                await db.flush()

                from app.modules.archive.repository import list_chunks
                chunks_a = await list_chunks(db, c_a.id)
                assert len(chunks_a) == 1
                assert chunks_a[0].customer_id == c_a.id

                chunks_b = await list_chunks(db, c_b.id)
                assert len(chunks_b) == 1
                assert chunks_b[0].customer_id == c_b.id
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())
