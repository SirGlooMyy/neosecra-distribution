"""Alarm service tests — CRUD, stats, trend, edge cases."""
import uuid
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.alarm.models import AlarmEvent
from app.modules.alarm import service as alarm_service


def _row_class(**kwargs):
    row = mock.MagicMock()
    for k, v in kwargs.items():
        setattr(row, k, v)
    return row


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    r.all.return_value = []
    r.one.return_value = _row_class(total=0, critical=0, warning=0, info=0, acknowledged=0)
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


class TestCreateAlarm:
    @pytest.mark.asyncio
    async def test_create_alarm_success(self):
        db = _mock_db()
        cid = uuid.uuid4()
        result = await alarm_service.create_alarm(
            db,
            customer_id=cid,
            location_id=uuid.uuid4(),
            severity="critical",
            title="Test alarm",
            message="Test message",
            source="test",
            trigger_id=uuid.uuid4(),
        )
        assert result is not None
        db.add.assert_called_once()
        db.commit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_create_alarm_minimal(self):
        db = _mock_db()
        result = await alarm_service.create_alarm(
            db,
            customer_id=uuid.uuid4(),
            location_id=None,
            severity="info",
            title="Minimal",
        )
        assert result is not None

    @pytest.mark.asyncio
    async def test_create_alarm_flush_no_commit(self):
        db = _mock_db()
        await alarm_service.create_alarm(
            db,
            customer_id=uuid.uuid4(),
            location_id=None,
            severity="warning",
            title="No commit",
            commit=False,
        )
        db.flush.assert_awaited_once()
        db.commit.assert_not_awaited()


class TestListAlarms:
    @pytest.mark.asyncio
    async def test_list_alarms_default(self):
        db = _mock_db()
        result = await alarm_service.list_alarms(db)
        assert result == []

    @pytest.mark.asyncio
    async def test_list_alarms_with_filters(self):
        db = _mock_db()
        cid = uuid.uuid4()
        result = await alarm_service.list_alarms(
            db,
            customer_id=cid,
            severity="critical",
            limit=10,
            offset=5,
        )
        assert result == []


class TestAcknowledgeAlarm:
    @pytest.mark.asyncio
    async def test_acknowledge_not_found(self):
        db = _mock_db()
        db.get.return_value = None
        with pytest.raises(HTTPException) as exc:
            await alarm_service.acknowledge_alarm(db, uuid.uuid4(), uuid.uuid4())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_acknowledge_already_acknowledged(self):
        db = _mock_db()
        event = AlarmEvent(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            acknowledged=True, acknowledged_at=datetime.now(timezone.utc),
            severity="info", title="Done",
        )
        db.get.return_value = event
        with pytest.raises(HTTPException) as exc:
            await alarm_service.acknowledge_alarm(db, event.id, uuid.uuid4())
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_acknowledge_success(self):
        db = _mock_db()
        event = AlarmEvent(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            acknowledged=False, severity="critical", title="Fix me",
        )
        db.get.return_value = event
        result = await alarm_service.acknowledge_alarm(db, event.id, uuid.uuid4())
        assert result.acknowledged is True


class TestAlarmStats:
    @pytest.mark.asyncio
    async def test_get_alarm_stats_structure(self):
        db = _mock_db()
        stats = await alarm_service.get_alarm_stats(db)
        assert isinstance(stats, dict)
        assert "total_today" in stats
        assert "critical" in stats

    @pytest.mark.asyncio
    async def test_get_alarm_stats_with_customer(self):
        db = _mock_db()
        stats = await alarm_service.get_alarm_stats(db, customer_id=uuid.uuid4())
        assert "total_today" in stats


class TestAlarmTrend:
    @pytest.mark.asyncio
    async def test_get_alarm_trend_empty(self):
        db = _mock_db()
        trend = await alarm_service.get_alarm_trend(db)
        assert trend == []

    @pytest.mark.asyncio
    async def test_get_alarm_trend_custom_days(self):
        db = _mock_db()
        trend = await alarm_service.get_alarm_trend(db, days=30)
        assert trend == []


class TestAlarmRouterSerialize:
    def test_serialize_alarm_event_full(self):
        from app.modules.alarm.router import _serialize_alarm_event
        event = AlarmEvent(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            location_id=uuid.uuid4(), trigger_id=uuid.uuid4(),
            severity="critical", title="Port scan", message="Detected",
            source="test", acknowledged=True,
            acknowledged_at=datetime(2026, 7, 13, 10, 0, tzinfo=timezone.utc),
            acknowledged_by=uuid.uuid4(),
            event_time=datetime(2026, 7, 13, 9, 55, tzinfo=timezone.utc),
        )
        payload = _serialize_alarm_event(event, trigger_name="Trigger")
        assert payload["id"] == str(event.id)
        assert payload["trigger_name"] == "Trigger"
        assert payload["severity"] == "critical"

    def test_serialize_alarm_event_minimal(self):
        from app.modules.alarm.router import _serialize_alarm_event
        event = AlarmEvent(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            location_id=None, trigger_id=None,
            severity="info", title="Test", message=None,
            source=None, acknowledged=False,
            acknowledged_at=None, acknowledged_by=None,
            event_time=datetime(2026, 7, 27, tzinfo=timezone.utc),
        )
        payload = _serialize_alarm_event(event)
        assert payload["location_id"] is None
        assert payload["acknowledged_at"] is None
