"""Fake FortiGate HTTP server for integration testing.

Simulates the FortiOS REST API endpoints that the FortiGateAdapter talks to.
Designed to be used as an async context manager with pytest.

Usage::

    async with FakeFortiGateServer() as fg:
        config = ConnectionConfig(
            vendor="fortigate",
            api_host="127.0.0.1",
            api_port=fg.port,
            api_token="test-token",
        )
        adapter = FortiGateAdapter(config)
        result = await adapter.test_connection()
        assert result.ok
"""
from __future__ import annotations

import asyncio
import socket
from typing import Any

import uvicorn
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route


def _forti_envelope(
    results: list | dict | None = None,
) -> dict[str, Any]:
    """Wrap response data in standard FortiOS envelope."""
    return {
        "http_status": 200,
        "results": results if results is not None else [],
    }


def _forti_error(
    status: int = 400,
    message: str = "bad request",
) -> JSONResponse:
    return JSONResponse(
        {
            "http_status": status,
            "error": status,
            "errmessage": message,
        },
        status_code=status,
    )

class FakeFortiGateServer:
    """A lightweight simulated FortiOS REST API for integration tests.

    Attributes
    ----------
    authorized_ips : set[str]
        IPs that have been allowlisted via authorize_guest.
    address_map : dict[str, str]
        Maps address name -> IP for DELETE resolution.
    simulate_auth_failure : bool
        When True, ``authorize_guest`` returns an error.
    simulate_timeout : bool
        When True, requests hang until the caller's timeout.
    simulate_401 : bool
        When True, every request returns HTTP 401.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 0) -> None:
        self._host = host
        self._port = port if port else self._find_free_port()
        self._server: uvicorn.Server | None = None
        self._app = self._build_app()

        # Simulation controls
        self.authorized_ips: set[str] = set()
        self.address_map: dict[str, str] = {}
        self.simulate_auth_failure: bool = False
        self.simulate_timeout: bool = False
        self.simulate_401: bool = False

    # ------------------------------------------------------------------
    # lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the uvicorn server in the background."""
        config = uvicorn.Config(
            self._app,
            host=self._host,
            port=self._port,
            log_level="error",
            lifespan="off",
        )
        self._server = uvicorn.Server(config)
        self._server.force_exit = True  # allow fast shutdown
        # uvicorn.Server.serve is a synchronous loop -- run in a task
        self._task = asyncio.create_task(self._server.serve())
        # Wait until the server is actually listening
        for _ in range(50):
            await asyncio.sleep(0.02)
            if self._server.started:
                break

    async def stop(self) -> None:
        """Shut down the uvicorn server."""
        if self._server is not None:
            self._server.should_exit = True
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, RuntimeError):
                pass
            self._server = None

    async def __aenter__(self) -> "FakeFortiGateServer":
        await self.start()
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.stop()

    # ------------------------------------------------------------------
    # properties
    # ------------------------------------------------------------------

    @property
    def url(self) -> str:
        """Base URL of the fake server, e.g. ``http://127.0.0.1:43125``."""
        return f"http://{self._host}:{self._port}/api/v2"

    @property
    def port(self) -> int:
        """The actual TCP port the server is listening on."""
        return self._port if self._port else self._find_free_port()

    # ------------------------------------------------------------------
    # internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _find_free_port() -> int:
        """Bind to ephemeral port and release it immediately."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            return s.getsockname()[1]

    def _build_app(self) -> Starlette:
        routes = [
            Route("/api/v2/monitor/system/health", self._handle_health, methods=["GET"]),
            Route("/api/v2/monitor/system/status", self._handle_system_status, methods=["GET"]),
            Route("/api/v2/cmdb/system/interface", self._handle_interfaces, methods=["GET"]),
            Route("/api/v2/cmdb/user/group", self._handle_user_groups, methods=["GET"]),
            Route("/api/v2/monitor/user/fsso/list", self._handle_sessions, methods=["GET"]),
            Route("/api/v2/cmdb/firewall/address/{name}", self._handle_address_put, methods=["PUT"]),
            Route("/api/v2/cmdb/firewall/address/{name}", self._handle_address_delete, methods=["DELETE"]),
            Route("/api/v2/monitor/firewall/ipv4-list", self._handle_ipv4_list, methods=["GET"]),
        ]
        app = Starlette(routes=routes)
        return app

    async def _check_simulations(
        self, request: Request
    ) -> JSONResponse | None:
        """Return a 401 response if simulate_401 is on, or None to continue."""
        if self.simulate_401:
            return _forti_error(401, "API token is invalid")
        # Specific request header to trigger auth failure per-call
        if request.headers.get("X-Simulate-401"):
            return _forti_error(401, "simulated auth failure")
        return None

    # ------------------------------------------------------------------
    # route handlers
    # ------------------------------------------------------------------

    async def _handle_health(self, request: Request) -> JSONResponse:
        blocked = await self._check_simulations(request)
        if blocked is not None:
            return blocked
        if self.simulate_timeout:
            await asyncio.sleep(3600)
        return JSONResponse(
            _forti_envelope([{"name": "fortigate", "status": "ok"}])
        )

    async def _handle_system_status(self, request: Request) -> JSONResponse:
        blocked = await self._check_simulations(request)
        if blocked is not None:
            return blocked
        if self.simulate_timeout:
            await asyncio.sleep(3600)
        return JSONResponse(
            _forti_envelope([
                {
                    "hostname": "fake-fortigate",
                    "serial": "FGT-FAKE-1234",
                    "model": "FortiGate-100F",
                    "version": "v7.2.10",
                    "firmware_version": "v7.2.10",
                }
            ])
        )

    async def _handle_interfaces(self, request: Request) -> JSONResponse:
        blocked = await self._check_simulations(request)
        if blocked is not None:
            return blocked
        if self.simulate_timeout:
            await asyncio.sleep(3600)
        return JSONResponse(
            _forti_envelope([
                {
                    "name": "port1",
                    "type": "physical",
                    "ip": "192.168.1.1/24",
                    "vdom": "root",
                    "status": True,
                },
                {
                    "name": "port2",
                    "type": "physical",
                    "ip": "10.0.0.1/24",
                    "vdom": "root",
                    "status": True,
                },
                {
                    "name": "port3",
                    "type": "physical",
                    "ip": "0.0.0.0/0",
                    "vdom": "root",
                    "status": False,
                },
            ])
        )

    async def _handle_user_groups(self, request: Request) -> JSONResponse:
        blocked = await self._check_simulations(request)
        if blocked is not None:
            return blocked
        if self.simulate_timeout:
            await asyncio.sleep(3600)
        return JSONResponse(
            _forti_envelope([
                {
                    "name": "Guest-Group",
                    "member": [{"name": "guest-user"}],
                },
                {
                    "name": "Employees",
                    "member": [{"name": "alice"}, {"name": "bob"}],
                },
            ])
        )


    async def _handle_sessions(self, request: Request) -> JSONResponse:
        blocked = await self._check_simulations(request)
        if blocked is not None:
            return blocked
        if self.simulate_timeout:
            await asyncio.sleep(3600)
        return JSONResponse(
            _forti_envelope([
                {
                    "ip": "10.0.0.100",
                    "name": "guest-user-1",
                    "mac": "AA:BB:CC:11:22:33",
                    "groups": ["Guest-Group"],
                },
                {
                    "ip": "10.0.0.101",
                    "name": "guest-user-2",
                    "mac": "DD:EE:FF:44:55:66",
                    "groups": ["Guest-Group"],
                },
            ])
        )

    async def _handle_address_put(self, request: Request) -> JSONResponse:
        blocked = await self._check_simulations(request)
        if blocked is not None:
            return blocked
        if self.simulate_timeout:
            await asyncio.sleep(3600)
        if self.simulate_auth_failure:
            return _forti_error(403, "authorization failed")

        name = request.path_params.get("name", "unknown")
        body = await request.json()
        ip = (
            body.get("subnet", "").split()[0]
            if body.get("subnet")
            else None
        )
        if ip:
            self.authorized_ips.add(ip)
            self.address_map[name] = ip
        return JSONResponse(
            _forti_envelope([
                {
                    "name": name,
                    "type": body.get("type", "ipmask"),
                    "subnet": body.get("subnet"),
                    "comment": body.get("comment"),
                }
            ])
        )

    async def _handle_address_delete(self, request: Request) -> JSONResponse:
        blocked = await self._check_simulations(request)
        if blocked is not None:
            return blocked
        if self.simulate_timeout:
            await asyncio.sleep(3600)

        name = request.path_params.get("name", "unknown")
        if name in self.address_map:
            ip = self.address_map.pop(name)
            self.authorized_ips.discard(ip)
        return JSONResponse(
            _forti_envelope([
                {"name": name, "status": "deleted"}
            ])
        )

    async def _handle_ipv4_list(self, request: Request) -> JSONResponse:
        blocked = await self._check_simulations(request)
        if blocked is not None:
            return blocked
        if self.simulate_timeout:
            await asyncio.sleep(3600)
        # Build IP/MAC list from authorized_ips with sample data
        if self.authorized_ips:
            results = [
                {
                    "ip": ip,
                    "mac": "00:00:00:00:00:00",
                    "interface": "port2",
                }
                for ip in sorted(self.authorized_ips)
            ]
        else:
            results = [
                {
                    "ip": "10.0.0.100",
                    "mac": "AA:BB:CC:11:22:33",
                    "interface": "port2",
                },
                {
                    "ip": "10.0.0.101",
                    "mac": "DD:EE:FF:44:55:66",
                    "interface": "port2",
                },
            ]
        return JSONResponse(_forti_envelope(results))
