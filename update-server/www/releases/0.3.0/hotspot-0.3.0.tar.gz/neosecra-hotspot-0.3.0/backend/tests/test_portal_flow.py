import unittest.mock as mock
import uuid
from datetime import datetime, timezone
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app.core.config import settings
from app.api.v1.endpoints.portal import (
    SmsRequestIn,
    SmsVerifyIn,
    WhatsAppVerifyIn,
    get_portal_config,
    portal_sms_request,
    portal_sms_verify,
    portal_whatsapp_verify,
)
from app.modules.portal.flow import verify as portal_flow_verify
from app.modules.portal.models import METHOD_PMS
import app.modules.devices.router as devices_router


def _db_with_get(location):
    db = mock.MagicMock()

    async def _get(*args, **kwargs):
        return location

    db.get = _get
    return db


def _db_with_template(location, template, customer=None, tenant=None):
    db = mock.MagicMock()

    async def _get(model, obj_id):
        model_name = getattr(model, "__name__", "")
        if model_name == "Location":
            return location
        if model_name == "Customer":
            return customer
        if model_name == "Tenant":
            return tenant
        return None

    async def _execute(*args, **kwargs):
        mock_result = mock.MagicMock()
        mock_result.scalars.return_value.first.return_value = template
        return mock_result

    db.get = _get
    db.execute = _execute
    return db


@pytest.mark.asyncio
async def test_sms_request_success():
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()

    mock_db = _db_with_get(mock_location)

    async def fake_send_otp(*args, **kwargs):
        return {"state": "sent", "ttl_seconds": 180, "attempts_left": 3}

    with mock.patch("app.api.v1.endpoints.portal.send_otp", new=fake_send_otp):
        response = await portal_sms_request(
            SmsRequestIn(phone="05551234567", location_id=mock_location.id),
            mock_db,
        )

    assert response["status"] == "success"
    assert "SMS doğrulama kodu" in response["message"]


@pytest.mark.asyncio
async def test_firewall_test_connection_requires_permission():
    mock_db = mock.MagicMock()
    user = mock.MagicMock(role="viewer")

    with pytest.raises(HTTPException) as exc:
        await devices_router.test_connection(uuid.uuid4(), mock_db, user)

    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_portal_config_success():
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()
    mock_location.name = "Test Location"

    mock_customer = mock.MagicMock()
    mock_customer.id = mock_location.customer_id
    mock_customer.tenant_id = uuid.uuid4()

    mock_tenant = mock.MagicMock()
    mock_tenant.id = mock_customer.tenant_id
    mock_tenant.name = "Test Tenant"
    mock_tenant.is_demo = False

    mock_template = mock.MagicMock()
    mock_template.name = "Test Template"
    mock_template.method = "sms"
    mock_template.theme = {"primaryColor": "blue", "welcomeTitle": "Test Welcome"}
    mock_db = _db_with_template(mock_location, mock_template, mock_customer, mock_tenant)

    response = await get_portal_config(location_id=mock_location.id, db=mock_db)
    assert response.locationId == mock_location.id
    assert response.tenantName == "Test Tenant"
    assert response.logoText == "Test Template"
    assert response.primaryColor == "blue"
    assert response.welcomeTitle == "Test Welcome"
    assert response.isDemoMode is False


@pytest.mark.asyncio
async def test_portal_context_resolves_sms_template():
    """Portal config, SMS template ile dogru sekilde yapilandirilmalidir."""
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()
    mock_location.name = "Hotel Lobby"

    mock_customer = mock.MagicMock()
    mock_customer.id = mock_location.customer_id
    mock_customer.tenant_id = uuid.uuid4()

    mock_tenant = mock.MagicMock()
    mock_tenant.id = mock_customer.tenant_id
    mock_tenant.name = "Hotel Tenant"
    mock_tenant.is_demo = False

    mock_template = mock.MagicMock()
    mock_template.name = "SMS Template"
    mock_template.method = "sms"
    mock_template.theme = {
        "primaryColor": "indigo",
        "welcomeTitle": "Misafir Wi-Fi",
        "welcomeDescription": "SMS ile dogrulama yapin.",
        "termsText": "Kosullari kabul ediyorum.",
        "supportText": "Resepsiyona basvurun.",
    }

    mock_db = _db_with_template(mock_location, mock_template, mock_customer, mock_tenant)

    response = await get_portal_config(location_id=mock_location.id, db=mock_db)

    assert response.locationId == mock_location.id
    assert response.locationName == "Hotel Lobby"
    assert response.tenantName == "Hotel Tenant"
    assert response.logoText == "SMS Template"
    assert response.primaryColor == "indigo"
    assert response.welcomeTitle == "Misafir Wi-Fi"
    assert response.welcomeDescription == "SMS ile dogrulama yapin."
    assert response.termsText == "Kosullari kabul ediyorum."
    assert response.supportText == "Resepsiyona basvurun."
    assert "sms" in response.enabledMethods
    assert response.isDemoMode is False


@pytest.mark.asyncio
async def test_portal_config_marks_demo_tenant():
    """Demo tenant portal config icinde acik demo sinyali tasimali."""
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()
    mock_location.name = "Demo Lobby"

    mock_customer = mock.MagicMock()
    mock_customer.id = mock_location.customer_id
    mock_customer.tenant_id = uuid.uuid4()

    mock_tenant = mock.MagicMock()
    mock_tenant.id = mock_customer.tenant_id
    mock_tenant.name = "VDataLab Operator"
    mock_tenant.is_demo = True

    mock_template = mock.MagicMock()
    mock_template.name = "Demo Template"
    mock_template.method = "sms"
    mock_template.theme = {"primaryColor": "emerald"}

    mock_db = _db_with_template(mock_location, mock_template, mock_customer, mock_tenant)

    response = await get_portal_config(location_id=mock_location.id, db=mock_db)

    assert response.tenantName == "VDataLab Operator"
    assert response.isDemoMode is True
    assert response.demoFallbackReason == "Demo tenant aktif: VDataLab Operator"


@pytest.mark.asyncio
async def test_send_code_invalid_phone_format():
    """Gecersiz telefon formatinda 400 donmeli."""
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()

    mock_db = _db_with_get(mock_location)

    with pytest.raises(HTTPException) as exc:
        await portal_sms_request(
            SmsRequestIn(phone="123", location_id=mock_location.id),
            mock_db,
        )

    assert exc.value.status_code == 400


@pytest.mark.asyncio
async def test_verify_invalid_method_returns_400():
    """Bilinmeyen dogrulama metodunda 400 donmeli."""
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()
    mock_location.sms_template = None

    mock_db = _db_with_get(mock_location)

    with pytest.raises(HTTPException) as exc:
        await portal_sms_verify(
            SmsVerifyIn(
                phone="05551234567",
                code="000000",
                location_id=mock_location.id,
            ),
            mock_db,
        )

    assert exc.value.status_code in (400, 404, 422)


@pytest.mark.asyncio
async def test_sms_verify_development_bypass():
    """Explicit demo modunda 123456 kodu bypass calismali."""
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()
    mock_location.name = "Test"

    mock_db = mock.MagicMock()
    async def _get_location(*args, **kwargs):
        return mock_location

    mock_db.get = _get_location

    from app.core.config import settings
    original_demo = settings.DEMO_MODE
    settings.DEMO_MODE = True

    try:
        response = await portal_sms_verify(
            SmsVerifyIn(
                phone="05551234567",
                code="123456",
                location_id=mock_location.id,
            ),
            mock_db,
        )
        assert response["status"] == "success"
        assert "session_id" in response
    finally:
        settings.DEMO_MODE = original_demo


@pytest.mark.asyncio
async def test_sms_verify_demo_only_bypass(monkeypatch):
    """123456 kodu sadece explicit demo modunda bypass etmelidir."""
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()
    mock_location.name = "Test"
    mock_db = _db_with_get(mock_location)

    original_demo = settings.DEMO_MODE
    settings.DEMO_MODE = False

    fake_otp = SimpleNamespace(id=uuid.uuid4())
    fake_session = SimpleNamespace(id=uuid.uuid4(), portal_token="ptok")

    verify_otp_mock = mock.AsyncMock(return_value=fake_otp)
    issue_mock = mock.AsyncMock(return_value=fake_session)

    monkeypatch.setattr("app.api.v1.endpoints.portal.verify_otp", verify_otp_mock)
    monkeypatch.setattr("app.api.v1.endpoints.portal.identity_service.issue_for_sms", issue_mock)

    try:
        response = await portal_sms_verify(
            SmsVerifyIn(
                phone="05551234567",
                code="123456",
                location_id=mock_location.id,
            ),
            mock_db,
        )
    finally:
        settings.DEMO_MODE = original_demo

    assert response["status"] == "success"
    assert response["session_id"] == str(fake_session.id)
    assert response["portal_token"] == fake_session.portal_token
    assert verify_otp_mock.await_count == 1
    assert issue_mock.await_count == 1


@pytest.mark.asyncio
async def test_whatsapp_verify_demo_only_bypass(monkeypatch):
    """000000 kodu sadece explicit demo modunda bypass etmelidir."""
    mock_location = mock.MagicMock()
    mock_location.customer_id = uuid.uuid4()
    mock_location.id = uuid.uuid4()
    mock_location.name = "Test"
    mock_db = _db_with_get(mock_location)

    original_demo = settings.DEMO_MODE
    settings.DEMO_MODE = False

    fake_wa = SimpleNamespace(id=uuid.uuid4())
    fake_session = SimpleNamespace(id=uuid.uuid4(), portal_token="wtoken")

    verify_wa_mock = mock.AsyncMock(return_value=fake_wa)
    issue_mock = mock.AsyncMock(return_value=fake_session)

    monkeypatch.setattr("app.api.v1.endpoints.portal.whatsapp_service.verify_whatsapp_code", verify_wa_mock)
    monkeypatch.setattr("app.api.v1.endpoints.portal.identity_service.issue_for_whatsapp", issue_mock)

    try:
        response = await portal_whatsapp_verify(
            WhatsAppVerifyIn(
                phone="05551234567",
                code="000000",
                location_id=mock_location.id,
            ),
            mock_db,
        )
    finally:
        settings.DEMO_MODE = original_demo

    assert response["status"] == "success"
    assert response["session_id"] == str(fake_session.id)
    assert response["portal_token"] == fake_session.portal_token
    assert verify_wa_mock.await_count == 1
    assert issue_mock.await_count == 1


@pytest.mark.asyncio
async def test_portal_pms_requires_explicit_config(monkeypatch):
    device = SimpleNamespace(id=uuid.uuid4(), location_id=uuid.uuid4(), is_active=True)
    location = SimpleNamespace(id=device.location_id, customer_id=uuid.uuid4(), name="Test")
    customer = SimpleNamespace(id=location.customer_id, is_active=True)
    template = SimpleNamespace(method=METHOD_PMS, meta={}, is_active=True)
    db = mock.AsyncMock()
    fake_iv = SimpleNamespace(
        id=uuid.uuid4(),
        portal_token="tok-prod",
        portal_token_expires_at=datetime.now(timezone.utc),
        method=METHOD_PMS,
        phone=None,
        voucher_id=None,
    )

    monkeypatch.setattr(settings, "DEMO_MODE", False)

    with (
        mock.patch("app.modules.portal.flow.resolve_context", new=mock.AsyncMock(return_value=(device, location, customer, template))),
        mock.patch("app.modules.pms.service.verify_guest_stay", new=mock.AsyncMock()) as verify_mock,
        mock.patch("app.modules.portal.flow.identity_service.issue_for_pms", new=mock.AsyncMock(return_value=fake_iv)) as issue_mock,
    ):
        with pytest.raises(HTTPException) as exc:
            await portal_flow_verify(
                db,
                device_id=device.id,
                room_number="101",
                surname_or_birth="SMITH",
            )

    assert exc.value.status_code == 503
    assert verify_mock.await_count == 0
    assert issue_mock.await_count == 0


@pytest.mark.asyncio
async def test_portal_pms_uses_mock_only_in_demo_mode(monkeypatch):
    device = SimpleNamespace(id=uuid.uuid4(), location_id=uuid.uuid4(), is_active=True)
    location = SimpleNamespace(id=device.location_id, customer_id=uuid.uuid4(), name="Test")
    customer = SimpleNamespace(id=location.customer_id, is_active=True)
    template = SimpleNamespace(method=METHOD_PMS, meta={}, is_active=True)
    db = mock.AsyncMock()
    fake_iv = SimpleNamespace(
        id=uuid.uuid4(),
        portal_token="tok-demo",
        portal_token_expires_at=datetime.now(timezone.utc),
        method=METHOD_PMS,
        phone=None,
        voucher_id=None,
    )

    monkeypatch.setattr(settings, "DEMO_MODE", True)

    with (
        mock.patch("app.modules.portal.flow.resolve_context", new=mock.AsyncMock(return_value=(device, location, customer, template))),
        mock.patch("app.modules.pms.service.verify_guest_stay", new=mock.AsyncMock(return_value=SimpleNamespace(verified=True, vendor="mock"))) as verify_mock,
        mock.patch("app.modules.portal.flow.identity_service.issue_for_pms", new=mock.AsyncMock(return_value=fake_iv)) as issue_mock,
    ):
        response = await portal_flow_verify(
            db,
            device_id=device.id,
            room_number="101",
            surname_or_birth="SMITH",
        )

    assert response.portal_token == "tok-demo"
    assert verify_mock.await_count == 1
    assert verify_mock.await_args.args[2] == {"pms_type": "mock"}
    assert issue_mock.await_count == 1
