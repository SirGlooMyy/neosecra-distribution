"""Secret leak / information disclosure testleri."""
import uuid
import unittest.mock as mock
import re

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.core.security import create_access_token

client = TestClient(app)

SENSITIVE_PATTERNS = [
    r'(?i)(api[_-]?key|api[_-]?token)\s*[:=]\s*["\'][^"\']+["\']',
    r'(?i)(secret|secret_key|secret_token)\s*[:=]\s*["\'][^"\']+["\']',
    r'(?i)(password|passwd|hashed_password)\s*[:=]\s*["\'][^"\']+["\']',
    r'(?i)totp[_-]?secret',
    r'(?i)private[_-]?key',
    r'(?i)access[_-]?key[_-]?id',
    r'(?i)secret[_-]?access[_-]?key',
    r'(?i)x[_-]?api[_-]?key',
]


@pytest.fixture(autouse=True)
def _mock_redis():
    r = mock.AsyncMock()
    r.get.return_value = None
    r.set.return_value = True
    r.delete.return_value = True
    r.incr.return_value = 1
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield


def _mock_user(**overrides):
    uid = overrides.pop("id", uuid.uuid4())
    return mock.MagicMock(
        id=uid,
        email=overrides.pop("email", "user@hotspot.io"),
        full_name=overrides.pop("full_name", "Test User"),
        hashed_password=overrides.pop("hashed_password", "hashed"),
        role=overrides.pop("role", "customer_admin"),
        is_active=overrides.pop("is_active", True),
        tenant_id=overrides.pop("tenant_id", uuid.uuid4()),
        customer_id=overrides.pop("customer_id", uuid.uuid4()),
        partner_id=overrides.pop("partner_id", None),
        location_id=overrides.pop("location_id", None),
        **overrides,
    )


def _build_mock_db(user):
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = user
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = user
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.first.return_value = user
    mock_scalar_result.all.return_value = []
    mock_result.scalars.return_value = mock_scalar_result
    mock_db.execute.return_value = mock_result
    return mock_db


ENDPOINT_SAMPLE = [
    "/api/v1/auth/me",
    "/api/v1/auth/permissions",
    "/api/v1/tenants",
    "/api/v1/customers",
    "/api/v1/locations",
    "/api/v1/devices",
    "/api/v1/sessions",
    "/api/v1/sessions/online",
    "/api/v1/vouchers",
    "/api/v1/licenses",
    "/api/v1/user-groups",
    "/api/v1/logs-5651",
    "/api/v1/radius/events",
    "/api/v1/alarm",
    "/api/v1/public-content",
    "/api/v1/site-bridge",
    "/api/v1/reports",
    "/api/v1/system",
    "/api/v1/mfa/methods",
    "/api/v1/ban",
    "/api/v1/traffic",
    "/api/v1/archive",
]


def test_secret_leak_in_responses():
    """Verify 22 endpoints do not leak sensitive fields."""
    mock_user = _mock_user(role="super_admin")
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    token = create_access_token(str(mock_user.id), extra={"type": "access"})

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        for path in ENDPOINT_SAMPLE:
            response = client.get(
                path,
                headers={"Authorization": f"Bearer {token}"},
            )
            body = response.text if response.text else ""
            for pattern in SENSITIVE_PATTERNS:
                matches = re.findall(pattern, body)
                assert not matches, (
                    f"Sensitive leak in {path}: matched {pattern} -> {matches}"
                )

    app.dependency_overrides.clear()


def test_no_stack_trace_in_errors():
    """Error responses must not contain Python stack traces."""
    response = client.get("/api/v1/auth/me")
    body = response.text.lower() if response.text else ""

    trace_indicators = ["traceback", "file \"", "line ", "in <module>",
                        "exception", "error occurred", "internal server error"]
    for indicator in trace_indicators:
        if indicator in body:
            if response.status_code == 401:
                continue
            pytest.fail(
                f"Stack trace leak: '{indicator}' found in {response.status_code} response"
            )


def test_docs_no_secret_leak():
    """API documentation must not contain secrets or internal paths."""
    response = client.get("/api/v1/openapi.json")
    assert response.status_code in (200, 404), (
        f"openapi.json returned {response.status_code}"
    )
    if response.status_code == 200:
        body = response.text
        for pattern in SENSITIVE_PATTERNS:
            matches = re.findall(pattern, body)
            assert not matches, (
                f"Sensitive data leaked in openapi.json: {matches}"
            )


def test_docs_endpoint_accessible():
    """/docs endpoint availability check."""
    response = client.get("/api/v1/docs")
    assert response.status_code in (200, 404), (
        f"/docs returned {response.status_code}"
    )


def test_error_no_internal_paths():
    """Error messages should not expose internal file paths."""
    endpoints_with_bad_auth = [
        "/api/v1/auth/me",
        "/api/v1/devices",
        "/api/v1/sessions",
    ]
    for path in endpoints_with_bad_auth:
        response = client.get(path)
        if response.status_code == 401:
            body = response.text.lower()
            internal_paths = ["/app/", "\\app\\", "site-packages", "lib/python"]
            for ip in internal_paths:
                assert ip not in body, (
                    f"Internal path leaked in error for {path}: '{ip}'"
                )
