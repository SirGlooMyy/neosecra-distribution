"""SMS provider tests — vendor dispatch, config validation, mock delivery."""
import pytest
from fastapi import HTTPException


class TestSmsServiceCore:
    def test_normalize_tr_phone_valid(self):
        from app.modules.sms.service import normalize_tr_phone
        assert normalize_tr_phone("05551234567") == "+905551234567"
        assert normalize_tr_phone("5551234567") == "+905551234567"
        assert normalize_tr_phone("+905551234567") == "+905551234567"

    def test_normalize_tr_phone_invalid_raises(self):
        from app.modules.sms.service import normalize_tr_phone
        with pytest.raises(HTTPException) as exc:
            normalize_tr_phone("123")
        assert exc.value.status_code == 400

    def test_normalize_tr_phone_short_raises(self):
        from app.modules.sms.service import normalize_tr_phone
        with pytest.raises(HTTPException):
            normalize_tr_phone("4440333")

    def test_hash_code(self):
        from app.modules.sms.service import _hash_code
        h = _hash_code("123456")
        assert isinstance(h, str)
        assert "$" in h  # salt$digest format
        salt, digest = h.split("$")
        assert len(salt) == 16
        assert len(digest) == 64

    def test_gen_code(self):
        from app.modules.sms.service import _gen_code
        code = _gen_code()
        assert len(code) == 6
        assert code.isdigit()


class TestSmsProvidersBasic:
    @pytest.mark.asyncio
    async def test_netgsm_provider_send(self):
        from app.modules.sms.providers.netgsm import NetGSMProvider
        provider = NetGSMProvider()
        ok, msg = await provider.send(phone="+905551234567", message="Test")
        assert isinstance(ok, bool)
        assert isinstance(msg, (str, type(None)))

    @pytest.mark.asyncio
    async def test_twilio_provider_send(self):
        from app.modules.sms.providers.twilio import TwilioProvider
        provider = TwilioProvider()
        ok, msg = await provider.send(phone="+905551234567", message="Test")
        assert ok is False

    @pytest.mark.asyncio
    async def test_muttl_provider_send(self):
        from app.modules.sms.providers.muttl import MuttlProvider
        provider = MuttlProvider()
        ok, msg = await provider.send(phone="+905551234567", message="Test")
        assert ok is False

    @pytest.mark.asyncio
    async def test_relateddigital_provider_send(self):
        from app.modules.sms.providers.relateddigital import RelatedDigitalProvider
        provider = RelatedDigitalProvider()
        ok, msg = await provider.send(phone="+905551234567", message="Test")
        assert ok is False

    @pytest.mark.asyncio
    async def test_vatansms_provider_send(self):
        from app.modules.sms.providers.vatansms import VatanSMSProvider
        provider = VatanSMSProvider()
        ok, msg = await provider.send(phone="+905551234567", message="Test")
        assert ok is False

    @pytest.mark.asyncio
    async def test_custom_http_provider_send(self):
        from app.modules.sms.providers.custom_http import CustomHttpProvider
        provider = CustomHttpProvider()
        ok, msg = await provider.send(phone="+905551234567", message="Test")
        assert ok is False

    def test_sms_provider_base_is_abstract(self):
        from app.modules.sms.providers.base import SmsProvider
        assert hasattr(SmsProvider, "send")
        assert SmsProvider.send.__isabstractmethod__ is True
