"""PostgreSQL integration test. Requires a running PostgreSQL.

Usage:
    DATABASE_URL=postgresql+asyncpg://hotspot:hotspot@localhost:5432/hotspot_test \
    pytest tests/integration/test_db.py -x -v
"""
import os

import pytest

pytestmark = pytest.mark.skipif(
    not os.environ.get("DATABASE_URL"),
    reason="DATABASE_URL not set — integration test skipped",
)


@pytest.mark.asyncio
async def test_db_connection():
    from app.core.database import AsyncSessionLocal
    async with AsyncSessionLocal() as db:
        result = await db.execute(__import__("sqlalchemy").text("SELECT 1"))
        assert result.scalar() == 1
