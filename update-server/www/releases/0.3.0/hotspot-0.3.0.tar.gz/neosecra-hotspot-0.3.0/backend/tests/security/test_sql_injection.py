"""SQL Injection güvenlik testleri.

Tüm filter parametrelerinde (src_ip, dst_ip, user, q) SQL payload
gönderilerek injection zafiyeti taranır.

Ayrıca backend/app/ içinde raw SQL query pattern'leri grep ile
kontrol edilir (string concatenation ile SQL).
"""
import uuid
import unittest.mock as mock
import subprocess
import os

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.core.security import create_access_token

client = TestClient(app)


@pytest.fixture(autouse=True)
def _mock_redis():
    r = mock.AsyncMock()
    r.get.return_value = None
    r.set.return_value = True
    r.delete.return_value = True
    r.incr.return_value = 1
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield


SQL_PAYLOADS = [
    "' OR 1=1 --",
    "1' OR '1'='1",
    "1; DROP TABLE users--",
    "1' UNION SELECT * FROM users--",
    "1' AND 1=1--",
    "admin'--",
    "admin' #",
    "'; SELECT pg_sleep(5)--",
    "' OR '1'='1' --",
    "1' AND SLEEP(5) AND '1'='1",
    "1' OR '1'='1' ORDER BY 1--",
    "1' UNION SELECT null, null, null--",
    "1' HAVING 1=1--",
    # NoSQL injection variants
    '{"$gt": ""}',
    '{"$ne": ""}',
    'admin"||"1',
    "$where: '1==1'",
]

FILTER_PARAMS = [
    "src_ip",
    "dst_ip",
    "user",
]


def _mock_user(**overrides):
    uid = overrides.pop("id", uuid.uuid4())
    return mock.MagicMock(
        id=uid,
        email=overrides.pop("email", "user@hotspot.io"),
        full_name=overrides.pop("full_name", "Test User"),
        hashed_password=overrides.pop("hashed_password", "hashed"),
        role=overrides.pop("role", "customer_admin"),
        is_active=overrides.pop("is_active", True),
        tenant_id=overrides.pop("tenant_id", uuid.uuid4()),
        customer_id=overrides.pop("customer_id", uuid.uuid4()),
        partner_id=overrides.pop("partner_id", None),
        location_id=overrides.pop("location_id", None),
        **overrides,
    )


def _build_mock_db(user):
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = user
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = user
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.first.return_value = user
    mock_scalar_result.all.return_value = []
    mock_result.scalars.return_value = mock_scalar_result
    mock_db.execute.return_value = mock_result
    mock_db.add = mock.AsyncMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()
    return mock_db


@pytest.mark.parametrize("payload", SQL_PAYLOADS)
@pytest.mark.parametrize("param", FILTER_PARAMS)
def test_sql_injection_filter_params(payload, param):
    """SQL injection payload in filter params must not cause 500 or data leak."""
    mock_user = _mock_user()
    mock_db = _build_mock_db(mock_user)

    app.dependency_overrides[get_db] = lambda: mock_db

    token = create_access_token(str(mock_user.id), extra={"type": "access"})

    for endpoint in ["/api/v1/devices", "/api/v1/sessions", "/api/v1/locations"]:
        with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                         new_callable=mock.AsyncMock) as tb:
            tb.return_value = False
            response = client.get(
                f"{endpoint}?{param}={payload}",
                headers={"Authorization": f"Bearer {token}"},
            )
        assert response.status_code not in (500, 503), (
            f"SQLi payload '{payload}' in '{param}' on {endpoint} "
            f"caused {response.status_code}"
        )

    app.dependency_overrides.clear()


# =====================================================================
# Raw SQL query audit: grep for string concatenation / f-string in queries
# =====================================================================

RAW_SQL_PATTERNS = [
    (r'execute\(f["\']', "f-string in execute() — possible SQL injection"),
    (r'execute\(\s*["\'][^"\']*\+[^"\']*["\']\s*\)',
     "string concat in execute() — possible SQL injection"),
    (r'text\(f["\']', "f-string in text() — possible SQL injection"),
    (r'text\(\s*["\'][^"\']*\+[^"\']*["\']\s*\)',
     "string concat in text() — possible SQL injection"),
]


def test_raw_sql_audit():
    """Search backend/app/ for raw SQL string concatenation patterns."""
    app_dir = os.path.join(os.path.dirname(__file__), "..", "..", "app")
    app_dir = os.path.abspath(app_dir)

    findings = []
    for pattern, desc in RAW_SQL_PATTERNS:
        try:
            result = subprocess.run(
                ["rg", "-n", pattern, app_dir, "--include", "*.py"],
                capture_output=True, text=True, timeout=30,
            )
            if result.stdout.strip():
                findings.append(f"  [{desc}]\n{result.stdout}")
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    if findings:
        msg = "Raw SQL patterns detected (possible injection vectors):\n"
        msg += "\n".join(findings)
        pytest.skip(msg)
