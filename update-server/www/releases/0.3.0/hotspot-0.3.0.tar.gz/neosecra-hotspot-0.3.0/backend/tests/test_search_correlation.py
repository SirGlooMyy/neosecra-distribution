"""Search correlation tests."""
from __future__ import annotations

import uuid
from unittest import mock

import pytest

from app.modules.search.schemas import SearchHit, SearchQuery, SearchResult
from app.modules.search import service
from app.modules.search.router import firewall_logs
from app.modules.search.service import (
    build_firewall_logs_export_bundle,
    enrich_search_hits_with_correlations,
    hit_matches_vendor,
    infer_vendor_display_name,
    search_syslog,
    _row_to_hit,
)


def test_enrich_search_hits_with_correlations_groups_session_and_principal_hits():
    customer_id = str(uuid.uuid4())
    hits = [
        SearchHit(
            timestamp="2026-07-13T10:01:00+00:00",
            customer_id=customer_id,
            source_ip="10.0.0.5",
            username="demo.user",
            message="Auth failed",
            source="clickhouse",
        ),
        SearchHit(
            timestamp="2026-07-13T10:07:00+00:00",
            customer_id=customer_id,
            source_ip="10.0.0.5",
            username="demo.user",
            message="Auth retry",
            source="clickhouse",
        ),
        SearchHit(
            timestamp="2026-07-13T11:01:00+00:00",
            customer_id=customer_id,
            session_id="sess-1",
            source_ip="10.0.0.8",
            message="Session opened",
            source="archive",
        ),
        SearchHit(
            timestamp="2026-07-13T11:04:00+00:00",
            customer_id=customer_id,
            session_id="sess-1",
            source_ip="10.0.0.8",
            message="Session closed",
            source="archive",
        ),
    ]

    enriched, summary = enrich_search_hits_with_correlations(hits)

    assert len(enriched) == 4
    assert all(hit.correlation_id for hit in enriched)
    assert len(summary) == 2
    assert {item.hit_count for item in summary} == {2}
    assert any(item.correlation_type == "session" for item in summary)
    assert any(item.correlation_type == "principal" for item in summary)


def test_enrich_search_hits_with_correlations_honors_custom_window():
    customer_id = str(uuid.uuid4())
    hits = [
        SearchHit(
            timestamp="2026-07-13T10:01:00+00:00",
            customer_id=customer_id,
            source_ip="10.0.0.5",
            username="demo.user",
            message="Auth failed",
            source="clickhouse",
        ),
        SearchHit(
            timestamp="2026-07-13T10:18:00+00:00",
            customer_id=customer_id,
            source_ip="10.0.0.5",
            username="demo.user",
            message="Auth retry",
            source="clickhouse",
        ),
    ]

    _, default_summary = enrich_search_hits_with_correlations(hits)
    _, wide_summary = enrich_search_hits_with_correlations(hits, correlation_window_minutes=30)

    assert len(default_summary) == 2
    assert len(wide_summary) == 1
    assert wide_summary[0].hit_count == 2


def test_enrich_search_hits_with_correlations_tracks_sources():
    customer_id = str(uuid.uuid4())
    session_id = "sess-1"
    hits = [
        SearchHit(
            timestamp="2026-07-13T10:01:00+00:00",
            customer_id=customer_id,
            session_id=session_id,
            source_ip="10.0.0.5",
            username="demo.user",
            message="Auth failed",
            source="clickhouse",
        ),
        SearchHit(
            timestamp="2026-07-13T10:03:00+00:00",
            customer_id=customer_id,
            session_id=session_id,
            source_ip="10.0.0.5",
            username="demo.user",
            message="Auth retry",
            source="archive",
        ),
    ]

    _, summary = enrich_search_hits_with_correlations(hits)

    assert len(summary) == 1
    assert summary[0].hit_count == 2
    assert summary[0].source_count == 2
    assert summary[0].sources == ["archive", "clickhouse"]


def test_export_bundle_embeds_correlation_summary():
    customer_id = str(uuid.uuid4())
    hits = [
        SearchHit(
            timestamp="2026-07-13T10:01:00+00:00",
            customer_id=customer_id,
            source_ip="10.0.0.5",
            username="demo.user",
            message="Auth failed",
            source="clickhouse",
        ),
        SearchHit(
            timestamp="2026-07-13T10:07:00+00:00",
            customer_id=customer_id,
            source_ip="10.0.0.5",
            username="demo.user",
            message="Auth retry",
            source="clickhouse",
        ),
    ]
    enriched, _ = enrich_search_hits_with_correlations(hits)
    result = SearchResult(hits=enriched, total=2, limit=100, offset=0, source="mixed")
    query = SearchQuery(customer_id=customer_id, q="Auth", correlation_window_minutes=30, limit=100, offset=0)

    bundle, _ = build_firewall_logs_export_bundle(result, query)

    import io
    import json
    import zipfile

    with zipfile.ZipFile(io.BytesIO(bundle), "r") as archive:
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
        readme = archive.read("README.txt").decode("utf-8")

    assert manifest["correlation_summary"]
    assert manifest["correlation_summary"][0]["hit_count"] == 2
    assert manifest["correlation_summary"][0]["sources"] == ["clickhouse"]
    assert manifest["correlation_rule"]["window_minutes"] == 30
    assert "Correlation window: 30 minutes" in readme
    assert "clickhouse" in readme


def test_row_to_hit_uses_app_name_when_application_is_missing():
    customer_id = str(uuid.uuid4())
    row = {
        "timestamp": "2026-07-13T12:00:00+00:00",
        "customer_id": customer_id,
        "app_name": "fortigate",
        "message": "utm auth event",
    }

    hit = _row_to_hit(row, customer_id, "clickhouse")

    assert hit.application == "fortigate"
    assert infer_vendor_display_name(hit) == "Fortinet"
    assert hit_matches_vendor(hit, "Fortinet")
    assert not hit_matches_vendor(hit, "PaloAlto")

    tp_link_hit = SearchHit(
        timestamp="2026-07-13T12:01:00+00:00",
        customer_id=customer_id,
        application="TP-Link Omada",
        hostname="tp-link-controller",
        message="gateway auth event",
        source="archive",
    )

    assert infer_vendor_display_name(tp_link_hit) == "TP-Link"
    assert hit_matches_vendor(tp_link_hit, "TP-Link")


@pytest.mark.asyncio
async def test_search_syslog_filters_hits_by_vendor(monkeypatch):
    customer_id = str(uuid.uuid4())
    scope = mock.Mock(customer_id=uuid.UUID(customer_id))
    db = mock.AsyncMock()
    query = SearchQuery(customer_id=customer_id, vendor="Fortinet", limit=100, offset=0)

    hits = [
        SearchHit(
            timestamp="2026-07-13T10:01:00+00:00",
            customer_id=customer_id,
            application="fortigate",
            hostname="fortigate-fw-1",
            message="Auth failed",
            source="clickhouse",
        ),
        SearchHit(
            timestamp="2026-07-13T10:02:00+00:00",
            customer_id=customer_id,
            application="paloalto",
            hostname="pa-fw-1",
            message="Auth failed",
            source="clickhouse",
        ),
    ]

    monkeypatch.setattr(service.cache, "search_cache_key", mock.AsyncMock(return_value=None))
    monkeypatch.setattr(service.cache, "set_search_cache", mock.AsyncMock())
    monkeypatch.setattr(service, "_search_clickhouse", mock.AsyncMock(return_value=hits))
    monkeypatch.setattr(service, "_search_archive", mock.AsyncMock(return_value=[]))
    monkeypatch.setattr(service, "_search_postgres", mock.AsyncMock(return_value=[]))

    result = await search_syslog(db, scope, query)

    assert result.total == 1
    assert len(result.hits) == 1
    assert result.hits[0].application == "fortigate"


@pytest.mark.asyncio
async def test_firewall_logs_route_surfaces_source(monkeypatch):
    customer_id = uuid.uuid4()
    user = mock.MagicMock(role="customer_admin", customer_id=customer_id)
    db = mock.AsyncMock()
    result = SearchResult(
        hits=[
            SearchHit(
                timestamp="2026-07-13T10:01:00+00:00",
                customer_id=str(customer_id),
                source_ip="10.0.0.5",
                username="demo.user",
                message="Auth failed",
                source="archive",
            )
        ],
        total=1,
        limit=15,
        offset=0,
        source="archive",
        correlation_summary=[],
    )

    monkeypatch.setattr("app.modules.search.router.service.search_syslog", mock.AsyncMock(return_value=result))

    rows = await firewall_logs(
        vendor=None,
        severity=None,
        search="Auth",
        from_time=None,
        to_time=None,
        correlation_window_minutes=15,
        page=1,
        page_size=15,
        db=db,
        user=user,
    )

    assert rows[0]["source"] == "archive"
