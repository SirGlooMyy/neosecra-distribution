"""Licensing service tests — CRUD, quota, plan, edge cases."""
import uuid
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.licensing.models import CustomerLicense, UNLIMITED
from app.modules.licensing.schemas import LicenseUpsert, QuotaStatus
from app.modules.licensing import service as licensing_service
from app.core.tenant import ScopeContext, TenantLevel


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    r.scalars.return_value.first.return_value = None
    r.scalar_one.return_value = 0
    r.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


def _global_scope() -> ScopeContext:
    return ScopeContext(level=TenantLevel.GLOBAL)


class TestQuotaStatus:
    @pytest.mark.asyncio
    async def test_quota_no_license_returns_unlimited(self):
        db = _mock_db()
        cid = uuid.uuid4()
        qs = await licensing_service.quota_status(db, cid)
        assert qs.within_quota is True
        assert qs.active_guests_quota == UNLIMITED
        assert qs.active_remaining == UNLIMITED

    @pytest.mark.asyncio
    async def test_quota_with_license_active(self):
        db = _mock_db()
        cid = uuid.uuid4()
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            active_guests_quota=100, max_sessions_per_day=500,
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            is_active=True, plan="pro",
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalar_one.return_value = 3
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        qs = await licensing_service.quota_status(db, cid)
        assert qs.active_guests_quota == 100
        assert qs.active_count == 3
        assert qs.active_remaining == 97
        assert qs.within_quota is True
        assert qs.expired is False
        assert qs.active is True

    @pytest.mark.asyncio
    async def test_quota_expired_license(self):
        db = _mock_db()
        cid = uuid.uuid4()
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            active_guests_quota=50,
            expires_at=datetime.now(timezone.utc) - timedelta(days=1),
            is_active=True, plan="basic",
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalar_one.return_value = 0
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        qs = await licensing_service.quota_status(db, cid)
        assert qs.expired is True
        assert qs.active is False
        assert qs.within_quota is False

    @pytest.mark.asyncio
    async def test_quota_over_limit(self):
        db = _mock_db()
        cid = uuid.uuid4()
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            active_guests_quota=5,
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            is_active=True, plan="basic",
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalar_one.return_value = 10
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        qs = await licensing_service.quota_status(db, cid)
        assert qs.active_count == 10
        assert qs.active_remaining == 0
        assert qs.within_quota is False

    @pytest.mark.asyncio
    async def test_quota_inactive_license(self):
        db = _mock_db()
        cid = uuid.uuid4()
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            active_guests_quota=100,
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            is_active=False, plan="basic",
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalar_one.return_value = 0
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        qs = await licensing_service.quota_status(db, cid)
        assert qs.active is False
        assert qs.within_quota is False

    @pytest.mark.asyncio
    async def test_day_start_resets_quota(self):
        db = _mock_db()
        cid = uuid.uuid4()
        now = datetime(2026, 7, 27, 15, 30, 0, tzinfo=timezone.utc)
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            active_guests_quota=100, max_sessions_per_day=10,
            is_active=True, plan="basic",
            expires_at=now + timedelta(days=30),
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalar_one.return_value = 8
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        qs = await licensing_service.quota_status(db, cid, now=now)
        assert qs.daily_used == 8
        assert qs.daily_remaining == 2


class TestEnforceQuota:
    @pytest.mark.asyncio
    async def test_enforce_quota_passes(self):
        db = _mock_db()
        cid = uuid.uuid4()
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            active_guests_quota=100,
            expires_at=datetime.now(timezone.utc) + timedelta(days=30),
            is_active=True, plan="pro",
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalar_one.return_value = 3
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        qs = await licensing_service.enforce_quota(db, cid)
        assert qs.within_quota is True

    @pytest.mark.asyncio
    async def test_enforce_quota_raises_402_expired(self):
        db = _mock_db()
        cid = uuid.uuid4()
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            active_guests_quota=100,
            expires_at=datetime.now(timezone.utc) - timedelta(days=1),
            is_active=True,
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalar_one.return_value = 0
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        with pytest.raises(HTTPException) as exc:
            await licensing_service.enforce_quota(db, cid)
        assert exc.value.status_code == 402

    @pytest.mark.asyncio
    async def test_enforce_quota_no_license_passes(self):
        db = _mock_db()
        cid = uuid.uuid4()
        qs = await licensing_service.enforce_quota(db, cid)
        assert qs.within_quota is True


class TestSessionDuration:
    def test_license_override_wins(self):
        qs = QuotaStatus(
            customer_id=uuid.uuid4(),
            active_guests_quota=100, active_count=0, active_remaining=100,
            max_sessions_per_day=None, daily_used=0, daily_remaining=None,
            session_minutes_default=60,
            expired=False, active=True, within_quota=True,
        )
        result = licensing_service.session_duration_minutes(qs, default_minutes=30)
        assert result == 60

    def test_default_when_no_override(self):
        qs = QuotaStatus(
            customer_id=uuid.uuid4(),
            active_guests_quota=100, active_count=0, active_remaining=100,
            max_sessions_per_day=None, daily_used=0, daily_remaining=None,
            session_minutes_default=None,
            expired=False, active=True, within_quota=True,
        )
        result = licensing_service.session_duration_minutes(qs, default_minutes=30)
        assert result == 30


class TestUpsertLicense:
    @pytest.mark.asyncio
    async def test_create_license(self):
        db = _mock_db()
        cid = uuid.uuid4()
        cust = mock.MagicMock()
        cust.id = cid
        cust.partner_id = uuid.uuid4()
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = cust
        r.scalars.return_value.first.return_value = None
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r
        db.get.return_value = cust

        body = LicenseUpsert(active_guests_quota=200, plan="pro")
        result = await licensing_service.upsert_license(
            db, cid, body, _global_scope(), uuid.uuid4(),
        )
        assert result is not None
        assert db.add.called
        db.commit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_upsert_no_customer_raises(self):
        db = _mock_db()
        cid = uuid.uuid4()
        body = LicenseUpsert(active_guests_quota=100)

        with pytest.raises(HTTPException) as exc:
            await licensing_service.upsert_license(
                db, cid, body, _global_scope(), uuid.uuid4(),
            )
        assert exc.value.status_code == 404


class TestListAndGetLicense:
    @pytest.mark.asyncio
    async def test_list_licenses_empty(self):
        db = _mock_db()
        result = await licensing_service.list_licenses(db, _global_scope())
        assert result == []

    @pytest.mark.asyncio
    async def test_get_license_not_found(self):
        db = _mock_db()
        cid = uuid.uuid4()
        with pytest.raises(HTTPException) as exc:
            await licensing_service.get_license(db, cid, _global_scope())
        assert exc.value.status_code == 404


class TestCheckRadiusEnterprise:
    @pytest.mark.asyncio
    async def test_radius_enabled_when_settings_off(self):
        db = _mock_db()
        with mock.patch("app.core.config.settings") as s:
            s.RADIUS_ENTERPRISE_ENABLED = False
            result = await licensing_service.check_radius_enterprise_enabled(db, uuid.uuid4())
            assert result is False

    @pytest.mark.asyncio
    async def test_radius_enabled_no_license_falls_to_settings(self):
        db = _mock_db()
        with mock.patch("app.core.config.settings") as s:
            s.RADIUS_ENTERPRISE_ENABLED = True
            result = await licensing_service.check_radius_enterprise_enabled(db, uuid.uuid4())
            assert result is True

    @pytest.mark.asyncio
    async def test_radius_enabled_license_active(self):
        db = _mock_db()
        cid = uuid.uuid4()
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            is_active=True, is_radius_enterprise=True,
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        with mock.patch("app.core.config.settings") as s:
            s.RADIUS_ENTERPRISE_ENABLED = True
            result = await licensing_service.check_radius_enterprise_enabled(db, cid)
            assert result is True

    @pytest.mark.asyncio
    async def test_radius_enabled_license_inactive_despite_flag(self):
        db = _mock_db()
        cid = uuid.uuid4()
        lic = CustomerLicense(
            id=uuid.uuid4(), customer_id=cid,
            is_active=False, is_radius_enterprise=True,
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = lic
        r.scalars.return_value.first.return_value = lic
        r.scalars.return_value.all.return_value = []
        r.all.return_value = []
        db.execute.return_value = r

        with mock.patch("app.core.config.settings") as s:
            s.RADIUS_ENTERPRISE_ENABLED = True
            result = await licensing_service.check_radius_enterprise_enabled(db, cid)
            assert result is False
