"""Ban module service-layer tests — CRUD, check_banned/whitelisted."""
import uuid

import pytest
import unittest.mock as mock

from app.modules.ban.models import BanRule, WhitelistEntry


@pytest.fixture(autouse=True)
def _any_redis():
    with mock.patch("app.core.security._get_redis", return_value=mock.AsyncMock()):
        yield


def _scope(customer_id=None):
    from app.core.tenant import ScopeContext, TenantLevel
    return ScopeContext(
        level=TenantLevel.CUSTOMER if customer_id else TenantLevel.GLOBAL,
        allowed=True, customer_id=customer_id,
    )


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    return db


# ---- Ban CRUD Service Tests ----


class TestBanList:
    async def _call(self, db, scope):
        from app.modules.ban.service import list_bans
        return await list_bans(db, scope)

    def test_empty(self):
        import asyncio
        result = asyncio.run(self._call(_mock_db(), _scope(customer_id=uuid.uuid4())))
        assert result == []


class TestBanCreate:
    async def _call(self, db, scope, **kw):
        from app.modules.ban.service import create_ban
        from app.modules.ban.schemas import BanRuleCreate
        body = BanRuleCreate(
            customer_id=kw.get("customer_id", uuid.uuid4()),
            mac_address=kw.get("mac", "AA:BB:CC:DD:EE:FF"),
            reason=kw.get("reason", "spam"),
        )
        return await create_ban(db, body, scope, mock.MagicMock())

    def test_creates_ban(self):
        cid = uuid.uuid4()
        db = _mock_db()

        import asyncio
        result = asyncio.run(self._call(db, _scope(customer_id=cid), customer_id=cid))
        assert result is not None


class TestBanGet:
    async def _call(self, db, ban_id, scope):
        from app.modules.ban.service import get_ban
        return await get_ban(db, ban_id, scope)

    def test_found(self):
        cid = uuid.uuid4()
        bid = uuid.uuid4()
        db = _mock_db()
        b = BanRule(id=bid, customer_id=cid, mac_address="AA:BB:CC:DD:EE:FF", reason="spam", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = b
        db.execute.return_value = r

        import asyncio
        result = asyncio.run(self._call(db, bid, _scope(customer_id=cid)))
        assert result.id == bid

    def test_not_found(self):
        db = _mock_db()
        import asyncio
        with pytest.raises(Exception):
            asyncio.run(self._call(db, uuid.uuid4(), _scope(customer_id=uuid.uuid4())))


class TestBanDelete:
    async def _call(self, db, ban_id, scope):
        from app.modules.ban.service import delete_ban
        return await delete_ban(db, ban_id, scope)

    def test_soft_delete(self):
        cid = uuid.uuid4()
        bid = uuid.uuid4()
        db = _mock_db()
        b = BanRule(id=bid, customer_id=cid, mac_address="AA:BB:CC:DD:EE:FF", reason="spam", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = b
        db.execute.return_value = r

        import asyncio
        asyncio.run(self._call(db, bid, _scope(customer_id=cid)))
        assert b.is_active is False


# ---- Whitelist Service Tests ----


class TestWhitelist:
    async def _create(self, db, **kw):
        from app.modules.ban.service import create_whitelist_entry
        from app.modules.ban.schemas import WhitelistEntryCreate
        body = WhitelistEntryCreate(
            customer_id=kw.get("customer_id", uuid.uuid4()),
            mac_address=kw.get("mac", "AA:BB:CC:DD:EE:FF"),
        )
        return await create_whitelist_entry(db, body, _scope(customer_id=body.customer_id))

    def test_create_entry(self):
        db = _mock_db()
        import asyncio
        result = asyncio.run(self._create(db))
        assert result is not None

    async def _delete(self, db, entry_id, scope):
        from app.modules.ban.service import delete_whitelist_entry
        return await delete_whitelist_entry(db, entry_id, scope)

    def test_soft_delete(self):
        cid = uuid.uuid4()
        wid = uuid.uuid4()
        db = _mock_db()
        w = WhitelistEntry(id=wid, customer_id=cid, mac_address="AA:BB:CC:DD:EE:FF", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = w
        db.execute.return_value = r

        import asyncio
        asyncio.run(self._delete(db, wid, _scope(customer_id=cid)))
        assert w.is_active is False


# ---- Ban/Whitelist Check Service Tests ----


class TestCheckBan:
    async def _call(self, db, **kw):
        from app.modules.ban.service import check_banned
        return await check_banned(
            db,
            customer_id=kw.get("customer_id", uuid.uuid4()),
            mac=kw.get("mac"),
            location_id=kw.get("location_id"),
        )

    def test_found(self):
        cid = uuid.uuid4()
        lid = uuid.uuid4()
        db = _mock_db()
        b = BanRule(id=uuid.uuid4(), customer_id=cid, location_id=lid, mac_address="AA:BB:CC:DD:EE:FF", reason="spam", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = b
        db.execute.return_value = r

        import asyncio
        result = asyncio.run(self._call(db, customer_id=cid, mac="AA:BB:CC:DD:EE:FF", location_id=lid))
        assert result is not None

    def test_not_found(self):
        cid = uuid.uuid4()
        db = _mock_db()
        import asyncio
        result = asyncio.run(self._call(db, customer_id=cid, mac="11:22:33:44:55:66"))
        assert result is None


class TestCheckWhitelist:
    async def _call(self, db, **kw):
        from app.modules.ban.service import check_whitelisted
        return await check_whitelisted(
            db,
            customer_id=kw.get("customer_id", uuid.uuid4()),
            mac=kw.get("mac"),
            location_id=kw.get("location_id"),
        )

    def test_found(self):
        cid = uuid.uuid4()
        lid = uuid.uuid4()
        db = _mock_db()
        w = WhitelistEntry(id=uuid.uuid4(), customer_id=cid, location_id=lid, mac_address="AA:BB:CC:DD:EE:FF", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = w
        db.execute.return_value = r

        import asyncio
        result = asyncio.run(self._call(db, customer_id=cid, mac="AA:BB:CC:DD:EE:FF", location_id=lid))
        assert result is not None

    def test_not_found(self):
        cid = uuid.uuid4()
        db = _mock_db()
        import asyncio
        result = asyncio.run(self._call(db, customer_id=cid, mac="11:22:33:44:55:66"))
        assert result is None
