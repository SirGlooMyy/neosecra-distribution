"""Meeting/Toplanti kodu servis testleri."""
import pytest
import uuid
import unittest.mock as mock
from datetime import datetime, timedelta, timezone
from fastapi import HTTPException

from app.modules.meeting.service import generate_code, create_meeting_code, verify_code


def test_generate_code_format():
    """Generated code should be 8 chars alphanumeric uppercase."""
    code = generate_code()
    assert len(code) == 8
    assert code.isalnum()
    assert code.isupper()


def test_generate_code_variable_length():
    """Code length should match the parameter."""
    code = generate_code(length=12)
    assert len(code) == 12
    assert code.isalnum()
    assert code.isupper()


@pytest.mark.asyncio
async def test_create_and_verify_code():
    """Create a meeting code then verify it."""
    customer_id = uuid.uuid4()
    location_id = uuid.uuid4()
    created_by = uuid.uuid4()
    expires_at = datetime.now(timezone.utc) + timedelta(hours=2)

    mock_mc = mock.AsyncMock()
    mock_mc.code = "TESTCODE1"
    mock_mc.customer_id = customer_id
    mock_mc.location_id = location_id
    mock_mc.is_active = True
    mock_mc.expires_at = expires_at
    mock_mc.current_uses = 0
    mock_mc.max_uses = 100

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = None
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)
    mock_db.add = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()

    mc = await create_meeting_code(
        mock_db,
        customer_id=customer_id,
        location_id=location_id,
        event_name="Test Event",
        max_uses=100,
        duration_minutes=120,
        expires_at=expires_at,
        created_by=created_by,
    )
    assert mc is not None


@pytest.mark.asyncio
async def test_verify_expired_code():
    """Verifying an expired code should raise 400."""
    customer_id = uuid.uuid4()

    mock_mc = mock.AsyncMock()
    mock_mc.code = "EXPIRED01"
    mock_mc.customer_id = customer_id
    mock_mc.location_id = uuid.uuid4()
    mock_mc.is_active = True
    mock_mc.expires_at = datetime.now(timezone.utc) - timedelta(hours=1)
    mock_mc.current_uses = 0
    mock_mc.max_uses = 100

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = mock_mc
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    with pytest.raises(HTTPException) as exc:
        await verify_code(
            mock_db,
            code="EXPIRED01",
            customer_id=customer_id,
            location_id=mock_mc.location_id,
        )
    assert exc.value.status_code == 400
    assert "suresi doldu" in exc.value.detail


@pytest.mark.asyncio
async def test_verify_max_uses_exceeded():
    """Code used max times should raise 400."""
    customer_id = uuid.uuid4()

    mock_mc = mock.AsyncMock()
    mock_mc.code = "MAXED001"
    mock_mc.customer_id = customer_id
    mock_mc.location_id = uuid.uuid4()
    mock_mc.is_active = True
    mock_mc.expires_at = datetime.now(timezone.utc) + timedelta(hours=2)
    mock_mc.current_uses = 100
    mock_mc.max_uses = 100

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = mock_mc
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    with pytest.raises(HTTPException) as exc:
        await verify_code(
            mock_db,
            code="MAXED001",
            customer_id=customer_id,
            location_id=mock_mc.location_id,
        )
    assert exc.value.status_code == 400
    assert "maksimum kullanim" in exc.value.detail


@pytest.mark.asyncio
async def test_verify_not_found():
    """Non-existent code should raise 404."""
    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = None
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    with pytest.raises(HTTPException) as exc:
        await verify_code(
            mock_db,
            code="NONEXIST",
            customer_id=uuid.uuid4(),
            location_id=uuid.uuid4(),
        )
    assert exc.value.status_code == 404
    assert "bulunamadi" in exc.value.detail
