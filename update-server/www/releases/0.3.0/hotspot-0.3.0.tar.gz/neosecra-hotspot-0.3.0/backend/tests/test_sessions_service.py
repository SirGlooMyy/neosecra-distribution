"""Sessions service-layer tests — group_id popülasyonu, scope isolation."""
import uuid
from datetime import datetime, timezone

import pytest
import unittest.mock as mock

from app.modules.sessions.models import GuestSession, STATUS_ACTIVE


@pytest.fixture(autouse=True)
def _any_redis():
    with mock.patch("app.core.security._get_redis", return_value=mock.AsyncMock()):
        yield


class TestCreateSessionGroupId:
    async def _call(self, db, **kw):
        from app.modules.sessions.service import create_session
        return await create_session(
            db,
            customer_id=kw.get("customer_id", uuid.uuid4()),
            mac=kw.get("mac", "AA:BB:CC:DD:EE:FF"),
            auth_method=kw.get("auth_method", "sms"),
            group_id=kw.get("group_id"),
            phone=kw.get("phone"),
            ip=kw.get("ip"),
        )

    def test_stores_group_id(self):
        cid = uuid.uuid4()
        gid = uuid.uuid4()
        db = mock.AsyncMock()
        import asyncio
        sess = asyncio.run(self._call(db, customer_id=cid, group_id=gid))
        assert sess.group_id == gid

    def test_without_group_id_defaults_none(self):
        db = mock.AsyncMock()
        import asyncio
        sess = asyncio.run(self._call(db))
        assert sess.group_id is None

    def test_normalizes_mac_to_upper(self):
        db = mock.AsyncMock()
        import asyncio
        sess = asyncio.run(self._call(db, mac="aa:bb:cc:dd:ee:ff"))
        assert sess.mac == "AA:BB:CC:DD:EE:FF"


class TestListOnlineSessions:
    async def _call(self, db, scope):
        from app.modules.sessions.service import list_online_sessions
        return await list_online_sessions(db, scope)

    def test_returns_empty_when_no_active(self):
        from app.core.tenant import ScopeContext, TenantLevel
        scope = ScopeContext(level=TenantLevel.GLOBAL, allowed=True)
        db = mock.AsyncMock()
        r = mock.MagicMock()
        r.scalars.return_value.all.return_value = []
        db.execute.return_value = r

        import asyncio
        result = asyncio.run(self._call(db, scope))
        assert result == []

    def test_returns_only_active(self):
        from app.core.tenant import ScopeContext, TenantLevel
        scope = ScopeContext(level=TenantLevel.GLOBAL, allowed=True)
        db = mock.AsyncMock()
        active = GuestSession(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            mac="AA:BB:CC:DD:EE:FF", auth_method="sms",
            status=STATUS_ACTIVE, started_at=datetime.now(timezone.utc),
        )
        r = mock.MagicMock()
        r.scalars.return_value.all.return_value = [active]
        db.execute.return_value = r

        import asyncio
        result = asyncio.run(self._call(db, scope))
        assert len(result) == 1
        assert result[0].status == STATUS_ACTIVE


class TestCountActiveSessions:
    async def _call(self, db, **kw):
        from app.modules.sessions.service import count_active_sessions_for_identity
        return await count_active_sessions_for_identity(
            db,
            customer_id=kw.get("customer_id", uuid.uuid4()),
            phone=kw.get("phone"),
            mac=kw.get("mac"),
        )

    def test_counts_active_sessions_for_phone_or_mac(self):
        cid = uuid.uuid4()
        db = mock.AsyncMock()
        r = mock.MagicMock()
        r.scalar_one.return_value = 3
        db.execute.return_value = r

        import asyncio
        count = asyncio.run(self._call(db, customer_id=cid, phone="5551234567", mac="aa:bb:cc:dd:ee:ff"))
        assert count == 3

    def test_returns_zero_when_no_identity(self):
        db = mock.AsyncMock()

        import asyncio
        count = asyncio.run(self._call(db))
        assert count == 0
