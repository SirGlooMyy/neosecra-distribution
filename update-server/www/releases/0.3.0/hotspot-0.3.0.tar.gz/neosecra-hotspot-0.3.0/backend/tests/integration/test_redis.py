"""Redis integration test. Requires a running Redis.

Usage:
    REDIS_URL=redis://localhost:6379/0 \
    pytest tests/integration/test_redis.py -x -v
"""
import os

import pytest

pytestmark = pytest.mark.skipif(
    not os.environ.get("REDIS_URL"),
    reason="REDIS_URL not set — integration test skipped",
)


@pytest.mark.asyncio
async def test_redis_ping():
    import redis.asyncio as redis
    r = redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
    try:
        pong = await r.ping()
        assert pong is True
    finally:
        await r.aclose()


@pytest.mark.asyncio
async def test_redis_set_get():
    import redis.asyncio as redis
    r = redis.from_url(os.environ["REDIS_URL"], decode_responses=True)
    try:
        await r.set("test_key", "test_value", ex=10)
        val = await r.get("test_key")
        assert val == "test_value"
    finally:
        await r.aclose()
