"""Unit tests for Phase 1 & Phase 3 implementations:
1. Phase 1: unified_search, scope_for(user), ClickHouse q free-text, rich facets (histogram + top-N)
2. Phase 3: raw traffic/syslog/radius 5651 archiving into hash chain & searchable_fields indexing
"""
import uuid
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest

from app.core.tenant import ScopeContext, TenantLevel, scope_for
from app.modules.logs_5651 import archive_service, service as logs_5651_service
from app.modules.logs_5651.models import (
    GENESIS_HASH,
    RECORD_RAW_RADIUS,
    RECORD_RAW_SYSLOG,
    RECORD_RAW_TRAFFIC,
    RECORD_SESSION_ARCHIVE,
)
from app.modules.search import service as search_service
from app.modules.search.schemas import (
    FacetResult,
    LogSearchParams,
    SearchQuery,
)


@pytest.fixture
def test_customer_id():
    return uuid.uuid4()


@pytest.fixture
def customer_scope(test_customer_id):
    return ScopeContext(
        level=TenantLevel.CUSTOMER,
        customer_id=test_customer_id,
        allowed=True,
    )


@pytest.fixture
def mock_user(test_customer_id):
    u = mock.MagicMock()
    u.id = uuid.uuid4()
    u.role = "customer_admin"
    u.tenant_id = test_customer_id
    u.customer_id = test_customer_id
    u.partner_id = None
    u.location_id = None
    return u


# ──────────────────────────────────────────────
# Phase 1 Tests: Unified Search & Scoping
# ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_unified_search_allowed_scope(customer_scope, test_customer_id):
    """unified_search calls search_syslog and enforces ScopeContext."""
    db = mock.AsyncMock()
    query = SearchQuery(customer_id=str(test_customer_id), q="test-query")

    with mock.patch("app.modules.search.service._search_clickhouse", return_value=[]), \
         mock.patch("app.modules.search.service._search_archive", return_value=[]), \
         mock.patch("app.modules.search.service._search_postgres", return_value=[]):
        res = await search_service.unified_search(db, customer_scope, query)
        assert res.total == 0
        assert res.source == "clickhouse"


@pytest.mark.asyncio
async def test_unified_search_disallowed_scope():
    """Disallowed scope fails closed."""
    disallowed_scope = ScopeContext(level=TenantLevel.CUSTOMER, allowed=False)
    db = mock.AsyncMock()
    query = SearchQuery(customer_id=str(uuid.uuid4()))

    res = await search_service.unified_search(db, disallowed_scope, query)
    assert res.total == 0
    assert res.source == "none"


@pytest.mark.asyncio
async def test_scope_for_user_integration(mock_user):
    """scope_for(user) correctly extracts customer_id."""
    scope = scope_for(mock_user)
    assert scope.allowed is True
    assert scope.customer_id == mock_user.customer_id
    assert scope.level == TenantLevel.CUSTOMER


@pytest.mark.asyncio
async def test_get_facets_histogram_and_top_n(mock_user):
    """get_facets returns top-N fields and date histogram."""
    db = mock.AsyncMock()
    db.execute.return_value.all.return_value = []
    db.execute.return_value.__iter__.return_value = []

    filters = LogSearchParams()
    facets: FacetResult = await search_service.get_facets(db, mock_user, filters)

    assert isinstance(facets, FacetResult)
    assert hasattr(facets, "vendor")
    assert hasattr(facets, "src_ip")
    assert hasattr(facets, "dst_ip")
    assert hasattr(facets, "user")
    assert hasattr(facets, "histogram")


# ──────────────────────────────────────────────
# Phase 3 Tests: Raw Log Archiving & Hash Chain
# ──────────────────────────────────────────────


def test_serialize_raw_logs_and_extract_searchable_fields():
    """Raw logs serialization is deterministic zstd and extract_searchable_fields collects unique IPs/users/MACs."""
    records = [
        {
            "id": "1",
            "event_time": "2026-08-20T10:00:00Z",
            "src_ip": "10.0.0.1",
            "dst_ip": "1.1.1.1",
            "mac": "aa:bb:cc:dd:ee:ff",
            "user": "alice",
            "domain": "example.com",
        },
        {
            "id": "2",
            "event_time": "2026-08-20T10:05:00Z",
            "src_ip": "10.0.0.2",
            "dst_ip": "8.8.8.8",
            "mac": "11:22:33:44:55:66",
            "username": "bob",
        },
    ]

    compressed = archive_service.serialize_raw_logs(records)
    assert len(compressed) > 0

    decompressed = archive_service.decompress(compressed)
    assert b"alice" in decompressed
    assert b"10.0.0.1" in decompressed

    searchable = archive_service.extract_searchable_fields(records)
    assert "10.0.0.1" in searchable["ips"]
    assert "1.1.1.1" in searchable["ips"]
    assert "AA:BB:CC:DD:EE:FF" in searchable["macs"]
    assert "alice" in searchable["users"]
    assert "example.com" in searchable["domains"]


@pytest.mark.asyncio
async def test_build_raw_log_archive_hash_chain(test_customer_id):
    """build_raw_log_archive seals raw_traffic records into per-(customer, record_type) hash chain."""
    db = mock.AsyncMock()
    exec_res = mock.MagicMock()
    exec_res.scalar_one_or_none.return_value = None
    db.execute.return_value = exec_res

    now = datetime.now(timezone.utc)
    pstart = now - timedelta(hours=1)
    pend = now

    raw_records = [
        {"id": "sys-1", "event_time": pstart.isoformat(), "src_ip": "192.168.1.10", "user": "user1"}
    ]

    record = await logs_5651_service.build_raw_log_archive(
        db,
        customer_id=test_customer_id,
        record_type=RECORD_RAW_TRAFFIC,
        period_start=pstart,
        period_end=pend,
        records=raw_records,
    )

    assert record.customer_id == test_customer_id
    assert record.record_type == RECORD_RAW_TRAFFIC
    assert record.chain_seq == 1
    assert record.prev_hash == GENESIS_HASH
    assert len(record.curr_hash) == 64
    assert db.add.call_count >= 2
