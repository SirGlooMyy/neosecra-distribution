"""Hash chain implementation tests — sequential chain, append-only proof, immutability, genesis."""
import copy

from app.modules.archive.hash_chain import (
    GENESIS_HASH,
    compute_chain_hash,
    verify_chain,
)


def _make_log(seq: int, data: str = "test") -> dict:
    return {"seq": seq, "data": data, "type": "firewall_log"}


def test_compute_chain_empty():
    final_hash, intermediates = compute_chain_hash([])
    assert final_hash == GENESIS_HASH
    assert intermediates == []


def test_compute_chain_single():
    logs = [_make_log(1)]
    final_hash, intermediates = compute_chain_hash(logs)
    assert len(final_hash) == 64
    assert len(intermediates) == 1
    assert intermediates[0] == final_hash


def test_compute_chain_three_logs():
    logs = [_make_log(1), _make_log(2, "data2"), _make_log(3, "data3")]
    final_hash, intermediates = compute_chain_hash(logs)
    assert len(final_hash) == 64
    assert len(intermediates) == 3
    assert intermediates[-1] == final_hash
    assert all(h != GENESIS_HASH for h in intermediates)
    assert all(len(h) == 64 for h in intermediates)


def test_chain_deterministic():
    logs = [_make_log(1), _make_log(2)]
    h1, _ = compute_chain_hash(logs)
    h2, _ = compute_chain_hash(logs)
    assert h1 == h2


def test_chain_different_inputs_different_hashes():
    logs1 = [_make_log(1, "A"), _make_log(2, "B")]
    logs2 = [_make_log(1, "X"), _make_log(2, "Y")]
    h1, _ = compute_chain_hash(logs1)
    h2, _ = compute_chain_hash(logs2)
    assert h1 != h2


def test_chain_order_matters():
    logs_a = [_make_log(1, "x"), _make_log(2, "y")]
    logs_b = [_make_log(2, "y"), _make_log(1, "x")]
    h_a, _ = compute_chain_hash(logs_a)
    h_b, _ = compute_chain_hash(logs_b)
    assert h_a != h_b


def test_chain_append_only_proof():
    logs = [_make_log(1), _make_log(2)]
    final_hash, intermediates = compute_chain_hash(logs)

    assert verify_chain(logs, intermediates, final_hash)

    tampered_logs = logs + [_make_log(3)]
    assert not verify_chain(
        tampered_logs, intermediates, final_hash
    ), "Adding a log should invalidate chain"


def test_chain_immutability():
    logs = [_make_log(1), _make_log(2), _make_log(3)]
    final_hash, intermediates = compute_chain_hash(logs)

    assert verify_chain(logs, intermediates, final_hash)

    tampered = copy.deepcopy(logs)
    tampered[1]["data"] = "tampered"
    assert not verify_chain(
        tampered, intermediates, final_hash
    ), "Modifying a log should break the chain"


def test_genesis_hash_value():
    assert GENESIS_HASH == "0" * 64
    assert len(GENESIS_HASH) == 64


def test_chain_with_genesis():
    logs = [_make_log(1)]
    final_with_genesis, _ = compute_chain_hash(logs, GENESIS_HASH)
    final_with_none, _ = compute_chain_hash(logs, None)
    assert final_with_genesis == final_with_none


def test_chain_with_custom_prev_hash():
    prev = "a" * 64
    logs = [_make_log(1)]
    final1, _ = compute_chain_hash(logs, GENESIS_HASH)
    final2, _ = compute_chain_hash(logs, prev)
    assert final1 != final2


def test_verify_chain_valid():
    logs = [_make_log(i, f"data{i}") for i in range(1, 6)]
    final_hash, intermediates = compute_chain_hash(logs)
    assert verify_chain(logs, intermediates, final_hash)


def test_verify_chain_wrong_final():
    logs = [_make_log(1)]
    _, intermediates = compute_chain_hash(logs)
    assert not verify_chain(logs, intermediates, "x" * 64)


def test_verify_chain_wrong_intermediate():
    logs = [_make_log(1), _make_log(2)]
    final_hash, _ = compute_chain_hash(logs)
    bad_intermediates = ["x" * 64, "y" * 64]
    assert not verify_chain(logs, bad_intermediates, final_hash)


def test_verify_chain_wrong_length():
    logs = [_make_log(1), _make_log(2)]
    final_hash, _ = compute_chain_hash(logs)
    assert not verify_chain(logs, [], final_hash)
    assert not verify_chain(
        logs, ["a" * 64, "b" * 64, "c" * 64], final_hash
    )


def test_verify_chain_empty_logs():
    assert verify_chain([], [], GENESIS_HASH)


def test_canonical_form_deterministic():
    log1 = {"b": 2, "a": 1}
    log2 = {"a": 1, "b": 2}
    logs1 = [log1]
    logs2 = [log2]
    h1, _ = compute_chain_hash(logs1)
    h2, _ = compute_chain_hash(logs2)
    assert h1 == h2


def test_chain_three_logs_append_detection():
    base = [_make_log(1), _make_log(2)]
    final, inter = compute_chain_hash(base)

    extended = base + [_make_log(3)]
    assert not verify_chain(extended, inter, final, GENESIS_HASH)
