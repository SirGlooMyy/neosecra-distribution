from __future__ import annotations

import asyncio
import io
import json
import os
from datetime import datetime, timezone
from unittest import mock
import uuid
import zipfile

from fastapi.testclient import TestClient

from app.core.database import get_db
from app.modules.auth.deps import get_current_user
from app.modules.auth.models import User
from app.main import app
from app.modules.public_content.models import PublicAsset
from app.modules.system.schemas import SystemUpdateUpsertIn
from app.modules.system import update_service


class _ScalarResult:
    def __init__(self, rows):
        self._rows = rows

    def scalars(self):
        return self

    def all(self):
        return self._rows

    def scalar_one_or_none(self):
        return self._rows[0] if self._rows else None


def _read_local_json(ref: str) -> dict:
    assert ref.startswith("local:")
    with open(ref[6:], "r", encoding="utf-8") as fh:
        return json.load(fh)


client = TestClient(app)


def _user(role: str = "super_admin") -> User:
    return User(
        id=uuid.uuid4(),
        email="admin@test.io",
        hashed_password="x",
        role=role,
        tenant_id=None,
        partner_id=None,
        customer_id=None,
        location_id=None,
        is_2fa_enabled=False,
        mfa_required=False,
        mfa_methods=[],
    )


def test_update_snapshot_separates_latest_draft_from_latest_published():
    draft = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-3-0",
        version="0.3.0",
        title="Hotspot Platform 0.3.0",
        category="Feature",
        summary="Taslak sürüm",
        body="Taslak",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={"status": "draft", "release_type": "feature", "channel": "stable"},
        created_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
    )
    archived = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-1-5",
        version="0.1.5",
        title="Hotspot Platform 0.1.5",
        category="Fix",
        summary="Arşivlenmiş sürüm",
        body="Arşiv",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={
            "status": "archived",
            "release_type": "fix",
            "channel": "stable",
            "published_at": "2026-07-13T12:00:00+00:00",
            "archived_at": "2026-07-13T18:00:00+00:00",
            "archived_by": "user-999",
        },
        created_at=datetime(2026, 7, 13, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, 18, tzinfo=timezone.utc),
    )
    published = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-2-0",
        version="0.2.0",
        title="Hotspot Platform 0.2.0",
        category="Feature",
        summary="Canlı sürüm",
        body="Yayınlandı",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=100,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "stable",
            "published_at": "2026-07-13T00:00:00+00:00",
        },
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([draft, archived, published]))

    snapshot = asyncio.run(update_service.get_update_snapshot(db))

    assert snapshot.current_version == "0.1.0"
    assert snapshot.latest_release_version == "0.3.0"
    assert snapshot.latest_published_version == "0.2.0"
    assert snapshot.upgrade_available is True
    assert snapshot.release_count == 3
    assert snapshot.draft_count == 1
    assert snapshot.archived_count == 1
    assert snapshot.featured_release is not None
    assert snapshot.featured_release.version == "0.3.0"


def test_update_snapshot_includes_stored_artifact_inventory():
    draft = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-4-2",
        version="0.4.2",
        title="Hotspot Platform 0.4.2",
        category="Feature",
        summary="Taslak sürüm",
        body="Taslak",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={"status": "draft", "release_type": "feature", "channel": "stable"},
        created_at=datetime(2026, 7, 16, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 16, tzinfo=timezone.utc),
    )
    archived = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-2-5",
        version="0.2.5",
        title="Hotspot Platform 0.2.5",
        category="Fix",
        summary="Arşivlenmiş paket",
        body="Arşiv",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={
            "status": "archived",
            "release_type": "fix",
            "channel": "stable",
            "artifact_name": "hotspot-update-0.2.5.zip",
            "artifact_ref": "local:/artifacts/hotspot-update-0.2.5.zip",
            "artifact_generated_at": "2026-07-15T10:00:00+00:00",
        },
        created_at=datetime(2026, 7, 15, 10, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, 10, tzinfo=timezone.utc),
    )
    published = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-4-2",
        version="0.4.2",
        title="Hotspot Platform 0.4.2",
        category="Feature",
        summary="Yayınlı paket",
        body="Yayın",
        asset_url="/api/v1/public-content/releases/release-0-4-2/download?version=0.4.2",
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=100,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "stable",
            "artifact_name": "hotspot-update-0.4.2.zip",
            "artifact_ref": "local:/artifacts/hotspot-update-0.4.2.zip",
            "artifact_generated_at": "2026-07-16T10:00:00+00:00",
        },
        created_at=datetime(2026, 7, 16, 10, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 16, 10, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([draft, archived, published]))

    snapshot = asyncio.run(update_service.get_update_snapshot(db))

    assert [item.version for item in snapshot.stored_artifacts] == ["0.4.2", "0.2.5"]
    assert snapshot.stored_artifacts[0].artifact_ref == "local:/artifacts/hotspot-update-0.4.2.zip"
    assert snapshot.stored_artifacts[1].artifact_ref == "local:/artifacts/hotspot-update-0.2.5.zip"


def test_update_snapshot_includes_distribution_telemetry_summary():
    latest_activated = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-5-1",
        version="0.5.1",
        title="Hotspot Platform 0.5.1",
        category="Feature",
        summary="Aktif sürüm",
        body="Aktif",
        asset_url="/api/v1/public-content/releases/release-0-5-1/download?version=0.5.1",
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=100,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "stable",
            "distribution_status": "activated",
            "distribution_manifest_generated_at": "2026-07-16T08:00:00+00:00",
            "distribution_activation_ref": "local:/artifacts/release-0.5.1/activation.json",
            "distribution_activated_at": "2026-07-16T09:00:00+00:00",
            "distribution_activated_by": "user-1",
        },
        created_at=datetime(2026, 7, 16, 9, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 16, 9, tzinfo=timezone.utc),
    )
    latest_ready = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-5-0",
        version="0.5.0",
        title="Hotspot Platform 0.5.0",
        category="Feature",
        summary="Hazır sürüm",
        body="Hazır",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "beta",
            "distribution_status": "ready",
            "distribution_manifest_generated_at": "2026-07-15T08:00:00+00:00",
        },
        created_at=datetime(2026, 7, 15, 8, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, 8, tzinfo=timezone.utc),
    )
    archived = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-4-9",
        version="0.4.9",
        title="Hotspot Platform 0.4.9",
        category="Fix",
        summary="Arşiv",
        body="Arşiv",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={
            "status": "archived",
            "release_type": "fix",
            "channel": "stable",
            "distribution_status": "superseded",
        },
        created_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
    )
    draft = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-5-2",
        version="0.5.2",
        title="Hotspot Platform 0.5.2",
        category="Feature",
        summary="Taslak",
        body="Taslak",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={
            "status": "draft",
            "release_type": "feature",
            "channel": "hotfix",
        },
        created_at=datetime(2026, 7, 16, 10, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 16, 10, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([draft, latest_activated, latest_ready, archived]))

    snapshot = asyncio.run(update_service.get_update_snapshot(db))

    assert snapshot.distribution_status_counts == {
        "activated": 1,
        "draft": 1,
        "ready": 1,
        "superseded": 1,
    }
    assert snapshot.channel_counts == {
        "beta": 1,
        "hotfix": 1,
        "stable": 2,
    }
    assert snapshot.latest_distribution_manifest_at == datetime(2026, 7, 16, 8, tzinfo=timezone.utc)
    assert snapshot.latest_distribution_activation_at == datetime(2026, 7, 16, 9, tzinfo=timezone.utc)


def test_create_update_release_marks_draft_or_published_metadata(temp_archive_dir):
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([]))
    db.add = mock.MagicMock()
    db.flush = mock.AsyncMock()
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    request = mock.MagicMock()
    request.client.host = "127.0.0.1"
    request.headers = {"user-agent": "pytest"}

    body = SystemUpdateUpsertIn(
        version="0.2.0",
        title="Hotspot Platform 0.2.0",
        summary="Yeni sürüm",
        body="Release notu",
        release_type="security",
        channel="stable",
        minimum_version="0.1.0",
        is_mandatory=True,
        upgrade_steps=["Servisi yeniden başlatın", "Public release notes'u doğrulayın"],
        artifact_name="hotspot-platform-0.2.0.zip",
        artifact_url="/api/v1/system/updates/0.2.0/bundle",
        checksum="abc123",
        file_size_kb=5120,
    )

    with mock.patch("app.modules.system.update_service.log_audit", new=mock.AsyncMock()) as audit_mock:
        result = asyncio.run(
            update_service.create_update_release(
                db,
                body,
                publish=True,
                published_by="user-123",
                request=request,
            )
        )

    asset = db.add.call_args.args[0]
    assert asset.section == "release_notes"
    assert asset.version == "0.2.0"
    assert asset.is_current is True
    assert asset.meta["status"] == "published"
    assert asset.meta["is_mandatory"] is True
    assert asset.meta["published_by"] == "user-123"
    assert result.status == "published"
    assert result.published_at is not None
    assert result.published_by == "user-123"
    assert result.asset_url == "/api/v1/system/updates/0.2.0/bundle"
    assert result.artifact_ref and result.artifact_ref.startswith("local:")
    assert result.artifact_generated_at is not None
    assert result.artifact_size_bytes and result.artifact_size_bytes > 0
    assert result.distribution_status == "ready"
    assert result.distribution_manifest_ref and result.distribution_manifest_ref.startswith("local:")
    assert result.distribution_manifest_generated_at is not None
    assert result.meta["artifact_ref"].startswith("local:")
    assert os.path.exists(result.meta["artifact_ref"][6:])
    assert result.meta["distribution_manifest_ref"].startswith("local:")
    assert os.path.exists(result.meta["distribution_manifest_ref"][6:])
    assert result.artifact_name == "hotspot-platform-0.2.0.zip"
    assert result.upgrade_steps == ["Servisi yeniden başlatın", "Public release notes'u doğrulayın"]
    manifest = _read_local_json(result.meta["distribution_manifest_ref"])
    assert manifest["distribution_status"] == "ready"
    assert manifest["download_url"] == "/api/v1/system/updates/0.2.0/bundle"
    assert "public-download" in manifest["distribution_targets"]
    assert manifest["artifact_ref"].startswith("local:")
    assert audit_mock.await_count == 1
    assert audit_mock.await_args.args[1] == "system.update_release.created"


def test_publish_update_release_sets_visibility_and_timestamp(temp_archive_dir):
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-4-0",
        version="0.4.0",
        title="Hotspot Platform 0.4.0",
        category="Feature",
        summary="Taslak",
        body="Taslak içerik",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={"status": "draft", "release_type": "feature", "channel": "beta"},
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    request = mock.MagicMock()
    request.client.host = "127.0.0.1"
    request.headers = {"user-agent": "pytest"}

    with mock.patch("app.modules.system.update_service.log_audit", new=mock.AsyncMock()) as audit_mock:
        result = asyncio.run(
            update_service.publish_update_release(
                db,
                asset.id,
                published_by="user-456",
                request=request,
            )
        )

    assert asset.is_current is True
    assert asset.meta["status"] == "published"
    assert asset.meta["published_by"] == "user-456"
    assert asset.meta["published_at"]
    assert result.is_current is True
    assert result.status == "published"
    assert result.published_by == "user-456"
    assert result.asset_url == "/api/v1/public-content/releases/release-0-4-0/download?version=0.4.0"
    assert result.artifact_ref and result.artifact_ref.startswith("local:")
    assert result.artifact_generated_at is not None
    assert result.artifact_size_bytes and result.artifact_size_bytes > 0
    assert result.distribution_status == "ready"
    assert result.distribution_manifest_ref and result.distribution_manifest_ref.startswith("local:")
    assert result.distribution_manifest_generated_at is not None
    assert result.meta["artifact_ref"].startswith("local:")
    assert os.path.exists(result.meta["artifact_ref"][6:])
    assert result.meta["distribution_manifest_ref"].startswith("local:")
    assert os.path.exists(result.meta["distribution_manifest_ref"][6:])
    assert result.artifact_name.startswith("hotspot-update-0.4.0-")
    assert audit_mock.await_count == 1
    assert audit_mock.await_args.args[1] == "system.update_release.published"


def test_archive_update_release_sets_status_and_audit(temp_archive_dir):
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-4-0",
        version="0.4.0",
        title="Hotspot Platform 0.4.0",
        category="Feature",
        summary="Yayınlı",
        body="Yayınlı içerik",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=100,
        meta={"status": "published", "release_type": "feature", "channel": "stable", "published_by": "user-123"},
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    request = mock.MagicMock()
    request.client.host = "127.0.0.1"
    request.headers = {"user-agent": "pytest"}

    with mock.patch("app.modules.system.update_service.log_audit", new=mock.AsyncMock()) as audit_mock:
        result = asyncio.run(
            update_service.archive_update_release(
                db,
                asset.id,
                archived_by="user-456",
                request=request,
            )
        )

    assert asset.is_current is False
    assert asset.meta["status"] == "archived"
    assert asset.meta["archived_by"] == "user-456"
    assert asset.meta["archived_at"]
    assert result.status == "archived"
    assert result.archived_by == "user-456"
    assert result.archived_at is not None
    assert result.artifact_ref and result.artifact_ref.startswith("local:")
    assert result.artifact_generated_at is not None
    assert result.artifact_size_bytes and result.artifact_size_bytes > 0
    assert result.meta["artifact_ref"].startswith("local:")
    assert os.path.exists(result.meta["artifact_ref"][6:])
    assert audit_mock.await_count == 1
    assert audit_mock.await_args.args[1] == "system.update_release.archived"


def test_update_update_release_keeps_archived_status_until_republished(temp_archive_dir):
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-4-1",
        version="0.4.1",
        title="Hotspot Platform 0.4.1",
        category="Feature",
        summary="Arşiv",
        body="Arşiv içerik",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={
            "status": "archived",
            "release_type": "feature",
            "channel": "stable",
            "published_at": "2026-07-15T00:00:00+00:00",
            "archived_at": "2026-07-15T12:00:00+00:00",
            "archived_by": "user-456",
            "published_by": "user-123",
        },
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(side_effect=[_ScalarResult([asset]), _ScalarResult([])])
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    request = mock.MagicMock()
    request.client.host = "127.0.0.1"
    request.headers = {"user-agent": "pytest"}

    body = SystemUpdateUpsertIn(
        version="0.4.1",
        title="Hotspot Platform 0.4.1",
        summary="Güncellenmiş arşiv",
        body="Yeni içerik",
        release_type="feature",
        channel="stable",
    )

    with mock.patch("app.modules.system.update_service.log_audit", new=mock.AsyncMock()) as audit_mock:
        result = asyncio.run(
            update_service.update_update_release(
                db,
                asset.id,
                body,
                publish=False,
                published_by="user-789",
                request=request,
            )
        )

    assert asset.is_current is False
    assert asset.meta["status"] == "archived"
    assert asset.meta["archived_at"] == "2026-07-15T12:00:00+00:00"
    assert asset.meta["archived_by"] == "user-456"
    assert result.status == "archived"
    assert result.archived_by == "user-456"
    assert result.published_by == "user-123"
    assert result.artifact_ref and result.artifact_ref.startswith("local:")
    assert result.artifact_generated_at is not None
    assert result.artifact_size_bytes and result.artifact_size_bytes > 0
    assert result.meta["artifact_ref"].startswith("local:")
    assert os.path.exists(result.meta["artifact_ref"][6:])
    assert audit_mock.await_count == 1
    assert audit_mock.await_args.args[1] == "system.update_release.updated"


def test_build_update_release_bundle_contains_manifest_and_guide():
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-0-5-0",
        version="0.5.0",
        title="Hotspot Platform 0.5.0",
        category="Feature",
        summary="Bundle test",
        body="Release body",
        asset_url="/api/v1/system/updates/0.5.0/bundle",
        checksum="abc123",
        file_size_kb=4096,
        is_current=True,
        sort_order=10,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "stable",
            "published_at": "2026-07-15T00:00:00+00:00",
            "published_by": "user-789",
            "upgrade_steps": ["Step 1", "Step 2"],
            "is_mandatory": True,
        },
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    bundle, filename = update_service.build_update_release_bundle(asset)

    assert filename.startswith("hotspot-update-0.5.0-")

    with zipfile.ZipFile(io.BytesIO(bundle), "r") as archive:
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
        readme = archive.read("README.txt").decode("utf-8")
        guide = archive.read("UPGRADE_GUIDE.txt").decode("utf-8")
        release_notes = archive.read("RELEASE_NOTES.txt").decode("utf-8")

    assert manifest["version"] == "0.5.0"
    assert manifest["artifact_url"] == "/api/v1/system/updates/0.5.0/bundle"
    assert manifest["published_by"] == "user-789"
    assert "Step 1" in guide
    assert "Published by: user-789" in guide
    assert "Release body" in release_notes
    assert "Hotspot Update Bundle" in readme


def test_download_update_bundle_endpoint_uses_stored_artifact(temp_archive_dir):
    artifact_dir = os.path.join(temp_archive_dir, "manual")
    os.makedirs(artifact_dir, exist_ok=True)
    stored_path = os.path.join(artifact_dir, "stored-update.zip")
    with zipfile.ZipFile(stored_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(
            "manifest.json",
            json.dumps(
                {
                    "title": "Stored release",
                    "version": "9.9.9",
                    "artifact_name": "stored-update.zip",
                    "generated_at": "2026-07-15T00:00:00+00:00",
                },
                ensure_ascii=False,
                indent=2,
            ).encode("utf-8"),
        )
        archive.writestr("README.txt", b"Stored artifact")

    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="stored-release",
        version="9.9.9",
        title="Stored release",
        category="Feature",
        summary="Stored artifact test",
        body="Stored body",
        asset_url=None,
        checksum="abc123",
        file_size_kb=0,
        is_current=True,
        sort_order=100,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "stable",
            "artifact_name": "stored-update.zip",
            "artifact_ref": f"local:{stored_path}",
            "artifact_generated_at": "2026-07-15T00:00:00+00:00",
        },
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))
    db.add = mock.MagicMock()

    app.dependency_overrides[get_db] = lambda: db
    app.dependency_overrides[get_current_user] = lambda: _user()
    try:
        response = client.get(f"/api/v1/system/updates/{asset.id}/bundle")
    finally:
        app.dependency_overrides.clear()

    assert response.status_code == 200
    assert response.headers["content-disposition"] == 'attachment; filename="stored-update.zip"'
    with zipfile.ZipFile(io.BytesIO(response.content), "r") as archive:
        manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
        readme = archive.read("README.txt").decode("utf-8")

    assert manifest["artifact_name"] == "stored-update.zip"
    assert "Stored artifact" in readme


def test_download_update_manifest_endpoint_uses_generated_manifest(temp_archive_dir):
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-9-9-9",
        version="9.9.9",
        title="Manifest release",
        category="Feature",
        summary="Manifest test",
        body="Manifest body",
        asset_url="/api/v1/public-content/releases/release-9-9-9/download?version=9.9.9",
        checksum="abc123",
        file_size_kb=0,
        is_current=True,
        sort_order=100,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "stable",
            "artifact_name": "stored-update.zip",
            "artifact_ref": "local:/artifacts/stored-update.zip",
            "artifact_generated_at": "2026-07-15T00:00:00+00:00",
            "distribution_status": "ready",
            "distribution_manifest_ref": "local:/artifacts/release-9-9-9/distribution-manifest.json",
            "distribution_manifest_generated_at": "2026-07-15T00:00:00+00:00",
            "distribution_targets": ["public-download", "client-auto-update", "channel:stable"],
        },
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([asset]))
    db.add = mock.MagicMock()

    app.dependency_overrides[get_db] = lambda: db
    app.dependency_overrides[get_current_user] = lambda: _user()
    try:
        response = client.get(f"/api/v1/system/updates/{asset.id}/manifest")
    finally:
        app.dependency_overrides.clear()

    assert response.status_code == 200
    assert response.headers["content-disposition"].endswith('filename="hotspot-update-9.9.9-20260715-000000-distribution.json"')
    manifest = json.loads(response.content.decode("utf-8"))
    assert manifest["distribution_status"] == "ready"
    assert manifest["download_url"] == "/api/v1/public-content/releases/release-9-9-9/download?version=9.9.9"
    assert manifest["artifact_ref"] == "local:/artifacts/stored-update.zip"
    assert "client-auto-update" in manifest["distribution_targets"]


def test_activate_update_release_endpoint_sets_distribution_activated(temp_archive_dir):
    old_asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-9-9-8",
        version="9.9.8",
        title="Older stable release",
        category="Feature",
        summary="Older release",
        body="Older body",
        asset_url="/api/v1/public-content/releases/release-9-9-8/download?version=9.9.8",
        checksum="old123",
        file_size_kb=0,
        is_current=True,
        sort_order=100,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "stable",
            "artifact_name": "older-update.zip",
            "artifact_ref": "local:/artifacts/older-update.zip",
            "artifact_generated_at": "2026-07-14T00:00:00+00:00",
            "distribution_status": "activated",
        },
        created_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
    )
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="release_notes",
        slug="release-9-9-9",
        version="9.9.9",
        title="Activation release",
        category="Feature",
        summary="Activation test",
        body="Activation body",
        asset_url="/api/v1/public-content/releases/release-9-9-9/download?version=9.9.9",
        checksum="abc123",
        file_size_kb=0,
        is_current=True,
        sort_order=100,
        meta={
            "status": "published",
            "release_type": "feature",
            "channel": "stable",
            "artifact_name": "stored-update.zip",
            "artifact_ref": "local:/artifacts/stored-update.zip",
            "artifact_generated_at": "2026-07-15T00:00:00+00:00",
        },
        created_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 15, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(side_effect=[
        _ScalarResult([asset]),
        _ScalarResult([old_asset, asset]),
    ])
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    db.add = mock.MagicMock()

    user = _user()
    app.dependency_overrides[get_db] = lambda: db
    app.dependency_overrides[get_current_user] = lambda: user
    try:
        response = client.post(f"/api/v1/system/updates/{asset.id}/activate")
    finally:
        app.dependency_overrides.clear()

    assert response.status_code == 200
    payload = response.json()
    assert payload["distribution_status"] == "activated"
    assert payload["distribution_activation_ref"].startswith("local:")
    assert payload["distribution_activated_at"] is not None
    assert payload["distribution_activated_by"] == str(user.id)
    assert payload["distribution_manifest_ref"].startswith("local:")
    assert os.path.exists(payload["distribution_manifest_ref"][6:])
    assert os.path.exists(payload["distribution_activation_ref"][6:])
    assert old_asset.is_current is False
    assert old_asset.meta["distribution_status"] == "superseded"
    assert old_asset.meta["distribution_superseded_by"] == str(user.id)
    assert old_asset.meta["distribution_superseded_by_release_id"] == str(asset.id)
    assert old_asset.meta["distribution_superseded_at"] is not None

    manifest = _read_local_json(payload["distribution_manifest_ref"])
    activation = _read_local_json(payload["distribution_activation_ref"])

    assert manifest["distribution_status"] == "activated"
    assert activation["distribution_status"] == "activated"
    assert activation["activated_by"] == str(user.id)
    assert activation["distribution_manifest_ref"] == payload["distribution_manifest_ref"]
    assert activation["download_url"] == "/api/v1/public-content/releases/release-9-9-9/download?version=9.9.9"
