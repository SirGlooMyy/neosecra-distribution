"""Platform license tests — envelope verify, product enforcement, module map,
trial fallback, and revocation.

Mirrors the PISH reference test suite adapted for Hotspot.
"""
import base64
import json
import time
from datetime import datetime, timezone, timedelta
from uuid import uuid4

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519
from sqlalchemy import select

from app.shared.licensing.license_service import (
    EXPECTED_PRODUCT,
    expand_licensed_modules,
    get_platform_license,
    verify_ed25519_envelope,
)
from app.modules.system.models import PlatformSetting


# ── helpers ──────────────────────────────────────────────────────

def _make_keypair():
    private_key = ed25519.Ed25519PrivateKey.generate()
    pub_bytes = private_key.public_key().public_bytes_raw()
    pub_b64 = base64.urlsafe_b64encode(pub_bytes).decode()
    return private_key, pub_b64


def _patch_keyring(monkeypatch, pub_b64):
    monkeypatch.setattr(
        "app.shared.licensing.license_service.TRUSTED_KEYRING",
        {
            "vdata-license-prod-2026-01": {
                "public_key_b64": pub_b64,
                "valid_from": "2026-01-01T00:00:00Z",
                "valid_until": "2036-12-31T23:59:59Z",
                "status": "active",
            },
        },
    )


def _build_envelope(private_key, payload: dict) -> str:
    payload_str = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode()
    signature = private_key.sign(payload_str.encode("utf-8"))
    sig_b64 = base64.urlsafe_b64encode(signature).decode()
    return json.dumps({
        "schema_version": 1,
        "key_id": "vdata-license-prod-2026-01",
        "algorithm": "Ed25519",
        "payload": payload_str,
        "signature": sig_b64,
    })


VALID_PAYLOAD = {
    "license_id": "test-license-001",
    "issuer": "VData",
    "valid_from": "2026-01-01T00:00:00Z",
    "expires_at": "2036-12-31T23:59:59Z",
    "limits": {"max_customers": 100, "max_assets": 1000, "max_users": 50},
    "modules": ["hotspot_core", "vouchers"],
    "edition": "Enterprise",
    "product_code": "HOTSPOT-ENT",
    "customer_name": "Test Corp",
}

EXPIRED_PAYLOAD = {
    "license_id": "test-expired-001",
    "issuer": "VData",
    "valid_from": "2024-01-01T00:00:00Z",
    "expires_at": "2024-06-01T00:00:00Z",
    "limits": {},
    "modules": ["hotspot_core"],
    "edition": "Enterprise",
}

PRODUCT_VALID_PAYLOAD = {
    "license_id": "test-product-hotspot",
    "issuer": "VData",
    "valid_from": "2026-01-01T00:00:00Z",
    "expires_at": "2036-12-31T23:59:59Z",
    "limits": {"max_customers": 100, "max_assets": 1000, "max_users": 50},
    "modules": ["hotspot_core"],
    "edition": "Enterprise",
    "product": "hotspot",
}

PRODUCT_MISMATCH_PAYLOAD = {
    "license_id": "test-product-assessment",
    "issuer": "VData",
    "valid_from": "2026-01-01T00:00:00Z",
    "expires_at": "2036-12-31T23:59:59Z",
    "limits": {"max_customers": 100, "max_assets": 1000, "max_users": 50},
    "modules": ["hotspot_core"],
    "edition": "Enterprise",
    "product": "assessment",
}

PRODUCT_LEGACY_PAYLOAD = {
    "license_id": "test-product-legacy",
    "issuer": "VData",
    "valid_from": "2026-01-01T00:00:00Z",
    "expires_at": "2036-12-31T23:59:59Z",
    "limits": {"max_customers": 100, "max_assets": 1000, "max_users": 50},
    "modules": ["hotspot_core"],
    "edition": "Enterprise",
}

# ── 1. Envelope Verification ─────────────────────────────────────

@pytest.mark.asyncio
async def test_verify_valid_envelope(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    envelope = _build_envelope(priv, VALID_PAYLOAD)
    result = verify_ed25519_envelope(envelope)
    assert result["license_id"] == VALID_PAYLOAD["license_id"]
    assert result["issuer"] == "VData"
    assert "hotspot_core" in result["modules"]


@pytest.mark.asyncio
async def test_verify_tampered_signature(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    envelope = json.loads(_build_envelope(priv, VALID_PAYLOAD))
    envelope["signature"] = base64.urlsafe_b64encode(b"x" * 64).decode()
    with pytest.raises(ValueError, match="LICENSE_SIGNATURE_INVALID"):
        verify_ed25519_envelope(json.dumps(envelope))


@pytest.mark.asyncio
async def test_verify_tampered_payload(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    envelope = json.loads(_build_envelope(priv, VALID_PAYLOAD))
    tampered_payload = dict(VALID_PAYLOAD)
    tampered_payload["expires_at"] = "2099-01-01T00:00:00Z"
    tampered_b64 = base64.urlsafe_b64encode(json.dumps(tampered_payload).encode()).decode()
    envelope["payload"] = tampered_b64
    with pytest.raises(ValueError, match="LICENSE_SIGNATURE_INVALID"):
        verify_ed25519_envelope(json.dumps(envelope))


@pytest.mark.asyncio
async def test_verify_unknown_key_id(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    envelope = json.loads(_build_envelope(priv, VALID_PAYLOAD))
    envelope["key_id"] = "unknown-key-id"
    with pytest.raises(ValueError, match="LICENSE_KEY_ID_UNKNOWN"):
        verify_ed25519_envelope(json.dumps(envelope))


@pytest.mark.asyncio
async def test_verify_missing_required_field(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    incomplete = dict(VALID_PAYLOAD)
    del incomplete["modules"]
    envelope = _build_envelope(priv, incomplete)
    with pytest.raises(ValueError, match="LICENSE_FORMAT_INVALID"):
        verify_ed25519_envelope(envelope)


# ── 2. Expired / Grace Period ────────────────────────────────────

async def _seed_license(db, envelope_str):
    existing = await db.execute(
        select(PlatformSetting).where(PlatformSetting.key == "platform_license")
    )
    setting = existing.scalar_one_or_none()
    if setting:
        setting.value = json.dumps({"envelope_string": envelope_str})
    else:
        db.add(PlatformSetting(
            key="platform_license",
            value=json.dumps({"envelope_string": envelope_str}),
            category="system",
            is_secret=True,
        ))
    await db.commit()


@pytest.mark.asyncio
async def test_expired_license(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    envelope = _build_envelope(priv, EXPIRED_PAYLOAD)

    from unittest import mock
    db = mock.AsyncMock()
    setting = PlatformSetting(
        key="platform_license",
        value=json.dumps({"envelope_string": envelope}),
        category="system",
        is_secret=True,
    )
    side_effects = [None, None]

    async def mock_execute(q):
        if side_effects[0] is None:
            side_effects[0] = True
            r = mock.MagicMock()
            r.scalar_one_or_none.return_value = setting
            return r
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        return r

    db.execute = mock_execute
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()

    result = await get_platform_license(db)
    assert result is not None
    assert result["status"] in ("EXPIRED", "GRACE_PERIOD")

# ── 3. Revocation / CRL ─────────────────────────────────────────

@pytest.mark.asyncio
async def test_revoked_license(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    import tempfile
    import os
    from app.shared.licensing import license_service as svc

    old_path = svc.CRL_CACHE_PATH
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump({"revoked_licenses": {"test-license-001": True}, "cached_at": datetime.now(timezone.utc).isoformat()}, f)
        crl_path = f.name

    monkeypatch.setattr(svc, "CRL_CACHE_PATH", crl_path)
    monkeypatch.setattr(svc, "crl_cache_path", lambda: crl_path)

    from unittest import mock
    db = mock.AsyncMock()
    setting = PlatformSetting(
        key="platform_license",
        value=json.dumps({"envelope_string": _build_envelope(priv, VALID_PAYLOAD)}),
        category="system",
        is_secret=True,
    )
    side_effects = [None, None]

    async def mock_execute(q):
        if side_effects[0] is None:
            side_effects[0] = True
            r = mock.MagicMock()
            r.scalar_one_or_none.return_value = setting
            return r
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        return r

    db.execute = mock_execute
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()

    result = await get_platform_license(db)
    assert result is not None
    assert result["status"] == "REVOKED"
    assert result.get("revoked") is True
    assert result.get("enabled_modules") == []

    os.unlink(crl_path)


# ── 4. Trial Mode Fallback ───────────────────────────────────────

@pytest.mark.asyncio
async def test_trial_active_when_no_license(monkeypatch):
    from app.shared.licensing.license_service import get_trial_status
    from unittest import mock

    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    db.execute.return_value = r
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()

    result = await get_trial_status(db)
    assert result["trial_active"] is True
    assert result["days_used"] == 0
    assert result["days_remaining"] == 30
    assert result["total_days"] == 30


# ── 5. Module Name Expansion ────────────────────────────────────

def test_expand_known_modules():
    result = expand_licensed_modules(["hotspot_core"])
    assert "portal" in result
    assert "sessions" in result
    assert "devices" in result
    assert "locations" in result


def test_expand_multiple_codes():
    result = expand_licensed_modules(["hotspot_core", "vouchers"])
    assert "portal" in result
    assert "vouchers" in result
    assert "radius" not in result


def test_expand_all_codes():
    result = expand_licensed_modules([
        "hotspot_core", "radius", "vouchers", "sms_ott",
        "logs_5651", "reporting",
    ])
    expected = {
        "portal", "sessions", "devices", "locations",
        "radius",
        "vouchers",
        "sms", "whatsapp",
        "logs_5651", "archive", "syslog",
        "reports",
    }
    for m in expected:
        assert m in result
    assert result == sorted(result)


def test_expand_unknown_passes_through():
    result = expand_licensed_modules(["hotspot_core", "custom_module"])
    assert "portal" in result
    assert "custom_module" in result


# ── 6. Product Enforcement ──────────────────────────────────

@pytest.mark.asyncio
async def test_product_match(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    envelope = _build_envelope(priv, PRODUCT_VALID_PAYLOAD)

    from unittest import mock
    db = mock.AsyncMock()
    setting = PlatformSetting(
        key="platform_license",
        value=json.dumps({"envelope_string": envelope}),
        category="system",
        is_secret=True,
    )
    side_effects = [None, None]

    async def mock_execute(q):
        if side_effects[0] is None:
            side_effects[0] = True
            r = mock.MagicMock()
            r.scalar_one_or_none.return_value = setting
            return r
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        return r

    db.execute = mock_execute
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()

    result = await get_platform_license(db)
    assert result is not None
    assert result["status"] not in ("INVALID_PRODUCT", "INVALID")
    assert result["status"] in ("ACTIVE", "EXPIRING_SOON")
    assert "portal" in result.get("enabled_modules", [])


@pytest.mark.asyncio
async def test_product_mismatch(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    envelope = _build_envelope(priv, PRODUCT_MISMATCH_PAYLOAD)

    from unittest import mock
    db = mock.AsyncMock()
    setting = PlatformSetting(
        key="platform_license",
        value=json.dumps({"envelope_string": envelope}),
        category="system",
        is_secret=True,
    )
    side_effects = [None, None]

    async def mock_execute(q):
        if side_effects[0] is None:
            side_effects[0] = True
            r = mock.MagicMock()
            r.scalar_one_or_none.return_value = setting
            return r
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        return r

    db.execute = mock_execute
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()

    result = await get_platform_license(db)
    assert result is not None
    assert result["status"] == "INVALID_PRODUCT"
    assert result.get("enabled_modules") == []
    assert "product" in result.get("detail", "")


@pytest.mark.asyncio
async def test_product_legacy(monkeypatch):
    priv, pub_b64 = _make_keypair()
    _patch_keyring(monkeypatch, pub_b64)
    envelope = _build_envelope(priv, PRODUCT_LEGACY_PAYLOAD)

    from unittest import mock
    db = mock.AsyncMock()
    setting = PlatformSetting(
        key="platform_license",
        value=json.dumps({"envelope_string": envelope}),
        category="system",
        is_secret=True,
    )
    side_effects = [None, None]

    async def mock_execute(q):
        if side_effects[0] is None:
            side_effects[0] = True
            r = mock.MagicMock()
            r.scalar_one_or_none.return_value = setting
            return r
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        return r

    db.execute = mock_execute
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()

    result = await get_platform_license(db)
    assert result is not None
    assert result["status"] in ("ACTIVE", "EXPIRING_SOON")
    assert result.get("legacy_warning") is True
    assert "portal" in result.get("enabled_modules", [])
