"""Device endpoint tests."""
from __future__ import annotations

from types import SimpleNamespace
from unittest import mock

import pytest

from app.api.v1.endpoints.devices import list_devices


@pytest.mark.asyncio
async def test_list_devices_uses_scoped_device_service():
    db = mock.AsyncMock()
    user = SimpleNamespace(
        role="customer_admin",
        customer_id="cust-123",
        partner_id=None,
        tenant_id="tenant-1",
        location_id=None,
    )
    devices = [SimpleNamespace(id="dev-1", name="AP-01")]

    device_service_mock = mock.AsyncMock(return_value=devices)

    with mock.patch("app.api.v1.endpoints.devices.device_service.list_devices", device_service_mock):
        result = await list_devices(db=db, user=user)

    assert result == devices
    assert device_service_mock.await_count == 1
    call_args = device_service_mock.await_args
    assert call_args.args[0] is db
    assert call_args.args[1].customer_id == "cust-123"
    assert call_args.args[1].level.value == "customer"
