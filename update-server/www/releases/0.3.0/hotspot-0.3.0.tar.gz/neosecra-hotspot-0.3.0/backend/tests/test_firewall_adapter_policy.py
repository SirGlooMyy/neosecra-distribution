"""Firewall adapter policy propagation tests."""
from __future__ import annotations

import xml.etree.ElementTree as ET

import pytest

from app.modules.firewall_adapters.aruba import ArubaAdapter
from app.modules.firewall_adapters.base import ConnectionConfig, FirewallAdapter
from app.modules.firewall_adapters.draytek import DrayTekAdapter
from app.modules.firewall_adapters.fortigate import FortiGateAdapter
from app.modules.firewall_adapters.mikrotik import MikroTikAdapter
from app.modules.firewall_adapters.pfsense import PfSenseAdapter
from app.modules.firewall_adapters.paloalto import PaloAltoAdapter
from app.modules.firewall_adapters.ruijie import RuijieAdapter
from app.modules.firewall_adapters.sonicwall import SonicWallAdapter
from app.modules.firewall_adapters.sophos import SophosAdapter
from app.modules.firewall_adapters.tplink import TplinkOmadaAdapter
from app.modules.firewall_adapters.watchguard import WatchGuardAdapter
from app.modules.firewall_adapters.zyxel import ZyxelAdapter


def _policy_session() -> dict[str, object]:
    return {
        "session_id": "sess-123",
        "ip": "10.0.0.55",
        "mac": "AA:BB:CC:DD:EE:FF",
        "policy": {
            "group_id": "group-1",
            "group_name": "Gold",
            "vlan_id": 77,
            "bandwidth_up": 2000,
            "bandwidth_down": 5000,
            "session_timeout": 30,
            "idle_timeout": 10,
        },
    }


def _extract_path(data: dict, path: tuple[str, ...]) -> object:
    value: object = data
    for key in path:
        assert isinstance(value, dict)
        value = value[key]
    return value


class _DummyAdapter(FirewallAdapter):
    vendor = "dummy"

    async def test_connection(self):  # pragma: no cover - helper only
        raise NotImplementedError

    async def get_device_info(self):  # pragma: no cover - helper only
        raise NotImplementedError

    async def get_interfaces(self):  # pragma: no cover - helper only
        raise NotImplementedError

    async def get_captive_portal_config(self):  # pragma: no cover - helper only
        raise NotImplementedError

    async def get_active_sessions(self):  # pragma: no cover - helper only
        raise NotImplementedError

    async def get_user_ip_mac_mapping(self):  # pragma: no cover - helper only
        raise NotImplementedError

    async def authorize_guest(self, session):  # pragma: no cover - helper only
        raise NotImplementedError

    async def revoke_guest(self, session):  # pragma: no cover - helper only
        raise NotImplementedError

    async def parse_syslog_event(self, raw_event):  # pragma: no cover - helper only
        raise NotImplementedError


def test_guest_policy_note_compacts_vlan_and_shaping():
    adapter = _DummyAdapter(ConnectionConfig(vendor="dummy", api_host="10.0.0.1"))
    note = adapter._guest_policy_note(_policy_session())
    assert "policy vlan=77" in note
    assert "bw=2000:5000" in note
    assert "session_timeout=30" in note
    assert "idle_timeout=10" in note
    assert "group=Gold" in note


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "adapter_cls, transport_attr, transport_key, payload_path, call_index",
    [
        (FortiGateAdapter, "_request", "json", ("comment",), 0),
        (MikroTikAdapter, "_request", "json", ("comment",), 0),
        (ArubaAdapter, "_request", "json", ("comment",), 0),
        (PfSenseAdapter, "_request", "json", ("alias", "detail"), 0),
        (DrayTekAdapter, "_request", "data", ("comment",), 0),
        (RuijieAdapter, "_request", "json", ("description",), 0),
        (TplinkOmadaAdapter, "_request", "json", ("comment",), 0),
        (WatchGuardAdapter, "_request", "json", ("comment",), 0),
        (ZyxelAdapter, "_request", "json", ("description",), 0),
        (SophosAdapter, "_xg_request", "json", ("Comment",), 0),
        (SonicWallAdapter, "_request", "json", ("access_rule", "comment"), 1),
    ],
)
async def test_authorize_guest_propagates_policy_note(
    adapter_cls,
    transport_attr: str,
    transport_key: str,
    payload_path: tuple[str, ...],
    call_index: int,
):
    adapter = adapter_cls(ConnectionConfig(vendor=adapter_cls.vendor, api_host="10.0.0.1", api_token="token"))
    calls: list[tuple[tuple, dict]] = []

    async def capture(*args, **kwargs):
        calls.append((args, kwargs))
        return {}

    setattr(adapter, transport_attr, capture)

    result = await adapter.authorize_guest(_policy_session())

    assert result.ok is True
    assert result.data["policy"]["vlan_id"] == 77
    payload = calls[call_index][1][transport_key]
    note = "policy vlan=77"
    assert note in str(_extract_path(payload, payload_path))


@pytest.mark.asyncio
async def test_paloalto_authorize_guest_propagates_policy_note():
    adapter = PaloAltoAdapter(ConnectionConfig(vendor="paloalto", api_host="10.0.0.1", api_token="token"))
    calls: list[dict[str, object]] = []
    root = ET.fromstring("<response status='success'><result/></response>")

    async def capture(**kwargs):
        calls.append(kwargs)
        return root

    adapter._xml_request = capture  # type: ignore[method-assign]

    result = await adapter.authorize_guest(_policy_session())

    assert result.ok is True
    assert result.data["policy"]["group_name"] == "Gold"
    assert len(calls) == 2
    assert "policy vlan=77" in str(calls[1]["params"]["element"])
