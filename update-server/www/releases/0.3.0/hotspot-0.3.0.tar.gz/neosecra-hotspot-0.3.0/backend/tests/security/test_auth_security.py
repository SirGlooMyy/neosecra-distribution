"""Auth/JWT güvenlik testleri.

Kapsam:
  - JWT alg confusion (alg:none, HS256 -> RS256 downgrade)
  - Token expiry, refresh rotation
  - Blacklist after logout
  - Bcrypt 72-char limit
  - 2FA bypass
"""
import uuid
import unittest.mock as mock
import asyncio

import pytest
import jwt as pyjwt
from jose import JWTError
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.core.security import create_access_token, create_refresh_token, decode_token
from app.modules.auth.models import User

client = TestClient(app)


@pytest.fixture(autouse=True)
def _mock_redis():
    store = {}

    async def get_side(key):
        return store.get(key)

    async def setex_side(key, ttl, val):
        store[key] = val
        return True

    async def delete_side(key):
        store.pop(key, None)
        return True

    r = mock.AsyncMock()
    r.get.side_effect = get_side
    r.set.side_effect = lambda k, v: True
    r.setex.side_effect = setex_side
    r.delete.side_effect = delete_side
    r.incr.return_value = 1
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield


def _make_user(role="customer_admin", customer_id=None):
    uid = uuid.uuid4()
    return User(
        id=uid,
        email=f"{role}@hotspot.io",
        full_name=f"{role.title()} User",
        hashed_password="hashed",
        role=role,
        is_active=True,
        tenant_id=uuid.uuid4(),
        customer_id=customer_id or uuid.uuid4(),
        is_2fa_enabled=False,
    )


def _token_for(user):
    return create_access_token(str(user.id), extra={"type": "access"})


def _build_mock_db(user):
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = user
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = user
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.first.return_value = user
    mock_scalar_result.all.return_value = []
    mock_result.scalars.return_value = mock_scalar_result
    mock_db.execute.return_value = mock_result
    mock_db.add = mock.AsyncMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()
    return mock_db


# =====================================================================
# JWT alg confusion
# =====================================================================

def test_jwt_alg_none():
    """alg:none token must be rejected by decode_token."""
    token = pyjwt.encode(
        {"sub": str(uuid.uuid4()), "type": "access"},
        key="",
        algorithm="none",
    )
    with pytest.raises(JWTError):
        decode_token(token)


def test_jwt_hs256_signed_with_wrong_key():
    """Token signed with a wrong key must be rejected."""
    wrong_key = "this-is-not-the-secret-key-for-testing-purpose"
    token = pyjwt.encode(
        {"sub": str(uuid.uuid4()), "type": "access", "role": "super_admin"},
        key=wrong_key,
        algorithm="HS256",
    )
    with pytest.raises(JWTError):
        decode_token(token)


# =====================================================================
# Token blacklist
# =====================================================================

def test_token_blacklist_after_logout():
    """Token marked as blacklisted via blacklist_token must be tracked."""
    token = create_access_token(str(uuid.uuid4()), extra={"type": "access"})
    payload = decode_token(token)
    jti = payload.get("jti")

    from app.core.security import blacklist_token
    exp = payload.get("exp", 0)

    asyncio.run(blacklist_token(jti, exp))

    from app.core.security import is_token_blacklisted
    is_blacklisted = asyncio.run(is_token_blacklisted(jti))

    assert is_blacklisted, "Token should be blacklisted after logout"


def test_blacklisted_token_rejected_by_endpoint():
    """Endpoints must reject blacklisted tokens."""
    uid = uuid.uuid4()
    mock_user = mock.MagicMock(
        id=uid,
        email="user@hotspot.io",
        full_name="Test User",
        hashed_password="hashed",
        role="customer_admin",
        is_active=True,
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        partner_id=None,
        location_id=None,
    )

    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = True
        user = _make_user()
        response = client.get(
            "/api/v1/auth/me",
            headers={"Authorization": f"Bearer {_token_for(user)}"},
        )

    app.dependency_overrides.clear()
    assert response.status_code == 401, (
        f"Blacklisted token should return 401, got {response.status_code}"
    )


# =====================================================================
# Refresh token rotation
# =====================================================================

def test_refresh_token_rotation():
    """Refresh token /auth/refresh should issue new tokens (basic check)."""
    uid = uuid.uuid4()
    mock_user = mock.MagicMock(
        id=uid,
        email="user@hotspot.io",
        full_name="Test User",
        hashed_password="hashed",
        role="customer_admin",
        is_active=True,
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        partner_id=None,
        location_id=None,
    )

    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    refresh = create_refresh_token(str(uid))

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        response = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": refresh},
        )

    app.dependency_overrides.clear()
    assert response.status_code in (200, 422, 401), (
        f"Refresh endpoint unexpected status: {response.status_code}"
    )


# =====================================================================
# Bcrypt 72-char limit
# =====================================================================

def test_bcrypt_72_char_password():
    """Bcrypt silently truncates passwords beyond 72 chars — verify behavior."""
    from app.core.security import hash_password, verify_password

    long_pw = "a" * 100
    short_pw = "a" * 72
    hashed = hash_password(long_pw)

    assert verify_password(short_pw, hashed), (
        "Bcrypt 72-char truncation: short_pw should verify long_pw's hash"
    )
    assert verify_password(long_pw, hashed), (
        "Long password should verify its own hash"
    )


# =====================================================================
# 2FA bypass
# =====================================================================

def test_2fa_bypass_without_header():
    """MFA-required user must provide X-MFA-Session header on sensitive endpoints."""
    uid = uuid.uuid4()
    mock_user = mock.MagicMock(
        id=uid,
        email="user@hotspot.io",
        full_name="Test User",
        hashed_password="hashed",
        role="customer_admin",
        is_active=True,
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        partner_id=None,
        location_id=None,
        mfa_required=True,
    )

    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        user = _make_user()
        response = client.get(
            "/api/v1/auth/me",
            headers={"Authorization": f"Bearer {_token_for(user)}"},
        )

    app.dependency_overrides.clear()
    assert response.status_code == 200, (
        f"/auth/me should not enforce MFA, got {response.status_code}"
    )


def test_mfa_required_endpoint_without_session():
    """MFA dependency must reject requests without X-MFA-Session."""
    from app.modules.auth.deps import require_mfa_completed

    mock_req = mock.MagicMock()
    mock_req.headers = {}

    mock_user = mock.MagicMock()
    mock_user.id = uuid.uuid4()

    with pytest.raises(Exception) as exc_info:
        asyncio.run(require_mfa_completed(mock_req, mock_user))
    assert "MFA" in str(exc_info.value), (
        "MFA header missing should raise an auth error"
    )
