"""Tenant isolation fuzz testleri.

5 farklı tenant oluşturulur, her tenant'ın kullanıcısı diğer tenant'ların
tüm endpoint'lerine erişmeye çalışır.

Beklenen: 403/404/empty response
Critical: 200 (veri sızıntısı)
"""
import uuid
import unittest.mock as mock

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.core.database import get_db
from app.core.security import create_access_token
from app.modules.auth.models import User

client = TestClient(app)


@pytest.fixture(autouse=True)
def _mock_redis():
    r = mock.AsyncMock()
    r.get.return_value = None
    r.set.return_value = True
    r.delete.return_value = True
    r.incr.return_value = 1
    r.expire.return_value = True
    r.exists.return_value = 0
    with mock.patch("app.core.security._get_redis", return_value=r):
        yield


TENANT_COUNT = 5
TENANT_IDS = [uuid.uuid4() for _ in range(TENANT_COUNT)]


def _make_tenant_user(index, role="customer_admin"):
    uid = uuid.uuid4()
    tid = TENANT_IDS[index]
    cid = uuid.uuid4()
    return User(
        id=uid,
        email=f"tenant{index}@hotspot.io",
        full_name=f"Tenant {index} User",
        hashed_password="hashed",
        role=role,
        is_active=True,
        tenant_id=tid,
        customer_id=cid,
    )


def _mock_tenant_user(role="customer_admin", tenant_id=None, customer_id=None):
    return mock.MagicMock(
        id=uuid.uuid4(),
        email=f"{role}@hotspot.io",
        full_name=f"{role.title()} User",
        hashed_password="hashed",
        role=role,
        is_active=True,
        tenant_id=tenant_id or uuid.uuid4(),
        customer_id=customer_id or uuid.uuid4(),
        partner_id=None,
        location_id=None,
        is_2fa_enabled=False,
    )


def _token_for(user):
    return create_access_token(str(user.id), extra={"type": "access"})


def _build_mock_db(user):
    mock_db = mock.AsyncMock()
    mock_db.get.return_value = user
    mock_result = mock.MagicMock()
    mock_result.scalar_one_or_none.return_value = user
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.first.return_value = user
    mock_scalar_result.all.return_value = []
    mock_result.scalars.return_value = mock_scalar_result
    mock_db.execute.return_value = mock_result
    mock_db.add = mock.AsyncMock()
    mock_db.flush = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()
    return mock_db


CROSS_TENANT_ENDPOINTS = [
    "/api/v1/devices",
    "/api/v1/sessions",
    "/api/v1/locations",
    "/api/v1/vouchers",
    "/api/v1/licenses",
    "/api/v1/logs-5651",
    "/api/v1/user-groups",
    "/api/v1/ban",
    "/api/v1/reports",
    "/api/v1/radius/events",
    "/api/v1/alarm",
]


@pytest.mark.parametrize("victim_idx", range(TENANT_COUNT))
@pytest.mark.parametrize("attacker_idx", range(TENANT_COUNT))
@pytest.mark.parametrize("path", CROSS_TENANT_ENDPOINTS[:3])
def test_cross_tenant_isolation(victim_idx, attacker_idx, path):
    """Tenant isolation: attacker must not access victim's data."""
    if victim_idx == attacker_idx:
        pytest.skip("Same-tenant access is expected")

    attacker_tid = TENANT_IDS[attacker_idx]
    attacker_cid = uuid.uuid4()

    mock_user = _mock_tenant_user(
        role="customer_admin",
        tenant_id=attacker_tid,
        customer_id=attacker_cid,
    )
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    user = _make_tenant_user(attacker_idx)
    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        response = client.get(
            path,
            headers={"Authorization": f"Bearer {_token_for(user)}"},
        )

    app.dependency_overrides.clear()

    if response.status_code == 200:
        data = response.json()
        if isinstance(data, list) and len(data) > 0:
            pytest.fail(
                f"CRITICAL: Tenant {attacker_idx} accessed tenant {victim_idx}"
                f" data on {path} — cross-tenant data leak! "
                f"Response: {str(data)[:200]}"
            )

    assert response.status_code not in (500,), (
        f"Cross-tenant fuzz caused 500 on {path} "
        f"(attacker={attacker_idx}, victim={victim_idx})"
    )


ROLES = ["super_admin", "partner_admin", "customer_admin", "location_manager", "support"]


@pytest.mark.parametrize("role", ROLES)
@pytest.mark.parametrize("path", CROSS_TENANT_ENDPOINTS[:3])
def test_role_cross_tenant_access(role, path):
    """Each role accessing cross-tenant endpoints."""
    tid = uuid.uuid4()
    cid = uuid.uuid4() if role != "super_admin" else None

    mock_user = _mock_tenant_user(role=role, tenant_id=tid, customer_id=cid)
    mock_db = _build_mock_db(mock_user)
    app.dependency_overrides[get_db] = lambda: mock_db

    user = User(
        id=uuid.uuid4(),
        email=f"{role}@hotspot.io",
        full_name=f"{role.title()} User",
        hashed_password="hashed",
        role=role,
        is_active=True,
        tenant_id=tid,
        customer_id=cid,
    )

    with mock.patch("app.modules.auth.deps.is_token_blacklisted",
                     new_callable=mock.AsyncMock) as tb:
        tb.return_value = False
        response = client.get(
            path,
            headers={"Authorization": f"Bearer {_token_for(user)}"},
        )

    app.dependency_overrides.clear()

    if role == "super_admin" and response.status_code == 200:
        return

    assert response.status_code not in (500,), (
        f"Role {role} caused 500 on {path}"
    )
