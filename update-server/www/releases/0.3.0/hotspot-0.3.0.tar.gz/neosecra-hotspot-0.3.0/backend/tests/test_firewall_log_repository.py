"""Unit tests for FirewallLog repository functions."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.modules.syslog.models import FirewallLog
from app.modules.syslog.repository import (
    insert_firewall_log,
    insert_firewall_log_batch,
    resolve_tenant_for_hostname,
)


@pytest.mark.asyncio
async def test_insert_firewall_log():
    db = AsyncMock()
    log_entry = FirewallLog(
        tenant_id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        log_type="traffic",
        severity="info",
        raw_syslog="test",
        parsed_fields={},
    )
    result = await insert_firewall_log(db, log_entry)
    db.add.assert_called_once_with(log_entry)
    db.flush.assert_awaited_once()
    assert result is log_entry


@pytest.mark.asyncio
async def test_insert_firewall_log_batch():
    db = AsyncMock()
    logs = [
        FirewallLog(tenant_id=uuid.uuid4(), customer_id=uuid.uuid4(), log_type="traffic", severity="info", raw_syslog="a", parsed_fields={}),
        FirewallLog(tenant_id=uuid.uuid4(), customer_id=uuid.uuid4(), log_type="event", severity="low", raw_syslog="b", parsed_fields={}),
    ]
    count = await insert_firewall_log_batch(db, logs)
    assert count == 2
    assert db.add.call_count == 2
    db.flush.assert_awaited_once()


@pytest.mark.asyncio
async def test_insert_firewall_log_batch_empty():
    db = AsyncMock()
    count = await insert_firewall_log_batch(db, [])
    assert count == 0
    db.add.assert_not_called()


@pytest.mark.asyncio
async def test_resolve_tenant_for_hostname_found():
    """When a device with matching hostname exists, return (tenant_id, customer_id)."""
    db = AsyncMock()
    tenant_id = uuid.uuid4()
    customer_id = uuid.uuid4()

    class MockRow:
        def __getitem__(self, idx):
            return (tenant_id, customer_id)[idx]

    mock_result = MagicMock()
    mock_result.one_or_none.return_value = MockRow()
    db.execute.return_value = mock_result

    result = await resolve_tenant_for_hostname(db, "FG-100F")
    assert result == (tenant_id, customer_id)


@pytest.mark.asyncio
async def test_resolve_tenant_for_hostname_not_found():
    """When no device matches, return None."""
    db = AsyncMock()
    mock_result1 = MagicMock()
    mock_result1.one_or_none.return_value = None
    mock_result2 = MagicMock()
    mock_result2.one_or_none.return_value = None
    db.execute.side_effect = [mock_result1, mock_result2]

    result = await resolve_tenant_for_hostname(db, "nonexistent-host")
    assert result is None


@pytest.mark.asyncio
async def test_resolve_tenant_fallback_to_syslog_source():
    """Fallback to SyslogSource identifier lookup."""
    db = AsyncMock()
    tenant_id = uuid.uuid4()
    customer_id = uuid.uuid4()

    class MockRow:
        def __getitem__(self, idx):
            return (tenant_id, customer_id)[idx]

    mock_result1 = MagicMock()
    mock_result1.one_or_none.return_value = None
    mock_result2 = MagicMock()
    mock_result2.one_or_none.return_value = MockRow()
    db.execute.side_effect = [mock_result1, mock_result2]

    result = await resolve_tenant_for_hostname(db, "syslog-host")
    assert result == (tenant_id, customer_id)
