import os
import pytest
from app.core.database import Base
from app.modules.tenants.models import Tenant
from app.modules.partners.models import Partner
from app.modules.customers.models import Customer
from app.modules.auth.models import User


def test_migrations_exist():
    """Verify that Alembic migrations exist in the versions directory."""
    versions_dir = os.path.join(os.path.dirname(__file__), "..", "alembic", "versions")
    assert os.path.exists(versions_dir), "Alembic versions directory does not exist"
    
    files = [f for f in os.listdir(versions_dir) if f.endswith(".py") and not f.startswith("__")]
    assert len(files) > 0, "No migration files found in alembic/versions"


def test_seed_demo_importable():
    """Verify that the seed demo module is importable."""
    try:
        from app.seeds.seed_demo import run_seed
        assert run_seed is not None
    except ImportError as e:
        pytest.fail(f"Could not import run_seed from app.seeds.seed_demo: {e}")


def test_metadata_contains_tables():
    """Verify all critical enterprise-ready tables exist in SQL Alchemy metadata."""
    expected_tables = {
        "tenants",
        "partners",
        "customers",
        "locations",
        "users",
        "devices",
        "device_credentials",
        "syslog_sources",
        "radius_clients",
        "portal_templates",
        "sms_otps",
        "voucher_batches",
        "vouchers",
        "identity_verifications",
        "guest_sessions",
        "radius_events",
        "syslog_records",
        "archive_records_5651",
        "customer_licenses",
        "audit_logs",
    }
    metadata_tables = set(Base.metadata.tables.keys())
    missing = expected_tables - metadata_tables
    assert not missing, f"Missing tables in model metadata: {missing}"


def test_tenant_isolation_attributes():
    """Verify that models requiring tenant scoping/isolation have the tenant_id field."""
    # Tenant can be explicitly labeled as demo/sandbox.
    assert hasattr(Tenant, "is_demo"), "Tenant model is missing is_demo column"
    # Partner is scoped to tenant
    assert hasattr(Partner, "tenant_id"), "Partner model is missing tenant_id column"
    # Customer is scoped to tenant
    assert hasattr(Customer, "tenant_id"), "Customer model is missing tenant_id column"
    # User is scoped to tenant (nullable for super_admin)
    assert hasattr(User, "tenant_id"), "User model is missing tenant_id column"
