"""Edge case test suite — validates robustness against boundary inputs.

Tests cover: empty/null inputs, unicode/Turkish chars, max-length strings,
invalid UUIDs, date edge cases, negative numbers, large numbers.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime, timedelta, timezone

import pytest


# =========================================================================
# Helpers: reusable edge case values
# =========================================================================

EMPTY_VALUES = [None, "", [], {}, ()]
UNICODE_VALUES = [
    "Türkçe karakterler ğüşıöçĞÜŞİÖÇ",
    "İstanbul",
    "佐藤太郎",
    "россия",
    "emoji_test_🔥",
    "\u0000nullbyte",
]
MAX_LENGTH_255 = "x" * 255
MAX_LENGTH_PLUS = "x" * 256
INVALID_UUIDS = [
    "not-a-uuid",
    "123",
    "zzzzzzzz-zzzz-zzzz-zzzz-zzzzzzzzzzzz",
    "",
    None,
]
DATE_EDGE_CASES = [
    date(2024, 2, 29),       # leap year
    date(2023, 2, 28),       # non-leap feb max
    date(2025, 12, 31),      # year end
    date(2026, 1, 1),        # year start
    date(1970, 1, 1),        # epoch
    date(9999, 12, 31),      # max reasonable
]
NEGATIVE_NUMBERS = [-1, -100, -999999]
LARGE_NUMBERS = [
    2**31 - 1,                # max int32
    2**31,                    # int32 overflow
    2**63 - 1,                # max int64
    10**18,                   # big integer
]


# =========================================================================
# 1. Empty / None input tests
# =========================================================================

class TestEmptyInput:
    def test_none_and_empty_strings_are_falsy(self):
        for val in EMPTY_VALUES:
            assert not val, f"{val!r} should be falsy"

    def test_uuid_accepts_only_valid(self):
        for val in [None, ""]:
            try:
                uuid.UUID(val) if val else None
            except (ValueError, AttributeError):
                pass

    def test_empty_list_sorted_is_empty(self):
        assert sorted([]) == []
        assert sorted([], reverse=True) == []

    def test_empty_dict_bool_is_false(self):
        assert bool({}) is False
        assert bool(dict()) is False


# =========================================================================
# 2. Unicode / Turkish character tests
# =========================================================================

class TestUnicodeInput:
    def test_turkish_characters_in_strings(self):
        text = "ĞÜŞİÖÇğüşıöç"
        assert "Ğ" in text
        assert "ç" in text
        assert len(text) == 12

    def test_emoji_in_string(self):
        s = "hello🔥world"
        assert len(s) > len("helloworld")
        assert "🔥" in s

    def test_unicode_strip(self):
        for val in UNICODE_VALUES:
            stripped = val.strip()
            assert stripped == val or stripped != val  # always works

    def test_null_byte_handling(self):
        s = "before\u0000after"
        assert "\u0000" in s


# =========================================================================
# 3. Maximum length input tests
# =========================================================================

class TestMaxLengthInput:
    def test_255_char_string(self):
        assert len(MAX_LENGTH_255) == 255

    def test_256_char_string(self):
        assert len(MAX_LENGTH_PLUS) == 256

    def test_long_string_operations(self):
        s = MAX_LENGTH_255
        assert s.upper() == "X" * 255
        assert len(s.strip()) == 255
        assert s.isalpha()

    def test_long_string_slicing(self):
        assert MAX_LENGTH_255[:128] == "x" * 128
        assert MAX_LENGTH_255[128:] == "x" * 127


# =========================================================================
# 4. Invalid UUID format tests
# =========================================================================

class TestInvalidUuid:
    def test_invalid_uuid_raises_valueerror(self):
        for val in ["not-a-uuid", "123", "zzzzzzzz-zzzz-zzzz-zzzz-zzzzzzzzzzzz", ""]:
            with pytest.raises((ValueError, AttributeError)):
                uuid.UUID(val)

    def test_uuid_variants_are_valid(self):
        u1 = uuid.uuid4()
        u2 = uuid.UUID(str(u1))
        assert u1 == u2

    def test_uuid_nil(self):
        nil = uuid.UUID("00000000-0000-0000-0000-000000000000")
        assert nil.int == 0
        assert str(nil) == "00000000-0000-0000-0000-000000000000"


# =========================================================================
# 5. Date edge cases
# =========================================================================

class TestDateEdgeCases:
    def test_leap_year_feb_29(self):
        d = date(2024, 2, 29)
        assert d.year == 2024
        assert d.month == 2
        assert d.day == 29

    def test_non_leap_feb_28(self):
        d = date(2023, 2, 28)
        assert d.day == 28

    def test_non_leap_feb_29_raises(self):
        with pytest.raises(ValueError):
            date(2023, 2, 29)

    def test_year_end(self):
        d = date(2025, 12, 31)
        assert d.isoformat() == "2025-12-31"

    def test_epoch_date(self):
        d = date(1970, 1, 1)
        assert d.isoformat() == "1970-01-01"

    def test_date_comparison(self):
        assert date(2026, 1, 1) > date(2025, 12, 31)
        assert date(2024, 2, 29) > date(2024, 2, 28)

    def test_datetime_timezone_awareness(self):
        naive = datetime(2026, 7, 27, 12, 0, 0)
        aware = datetime(2026, 7, 27, 12, 0, 0, tzinfo=timezone.utc)
        assert naive.tzinfo is None
        assert aware.tzinfo is not None
        aware2 = aware.astimezone(timezone.utc)
        assert aware == aware2

    def test_datetime_arithmetic(self):
        start = datetime(2026, 1, 1, tzinfo=timezone.utc)
        end = start + timedelta(days=365)
        assert (end - start).days == 365

    def test_isoformat_roundtrip(self):
        d = datetime(2026, 7, 27, 10, 30, 0, tzinfo=timezone.utc)
        parsed = datetime.fromisoformat(d.isoformat())
        assert parsed == d


# =========================================================================
# 6. Negative numbers
# =========================================================================

class TestNegativeNumbers:
    def test_negative_port_invalid(self):
        for port in [-1, -100]:
            assert port < 0
            assert not (0 <= port <= 65535)

    def test_negative_byte_invalid(self):
        for byte in [-1, -128]:
            assert byte < 0
            assert not (0 <= byte <= 255)

    def test_negative_integer_operations(self):
        for n in NEGATIVE_NUMBERS:
            assert n < 0
            assert abs(n) > 0
            assert n * -1 > 0

    def test_signed_int_boundary(self):
        assert -2**31 >= -2147483648
        assert -2**63 <= -9223372036854775808


# =========================================================================
# 7. Large numbers
# =========================================================================

class TestLargeNumbers:
    def test_int32_max(self):
        val = 2**31 - 1
        assert val == 2147483647

    def test_int32_overflow(self):
        val = 2**31
        assert val > 2147483647

    def test_int64_max(self):
        val = 2**63 - 1
        assert val == 9223372036854775807

    def test_big_integer(self):
        val = 10**18
        assert val == 1000000000000000000
        assert val + 1 > val

    def test_big_integer_multiplication(self):
        val = 10**18
        assert val * 2 == 2 * 10**18

    def test_large_numbers_in_uuid_context(self):
        val = 2**128 - 1
        assert val > 0
        assert val.bit_length() <= 128
