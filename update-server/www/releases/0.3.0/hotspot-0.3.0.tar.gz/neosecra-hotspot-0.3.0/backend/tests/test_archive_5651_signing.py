"""5651 log imzalama ve hash zinciri testleri."""
import uuid
from datetime import datetime, timezone

from app.modules.logs_5651.models import (
    GENESIS_HASH,
    ArchiveRecord,
    RECORD_SESSION_ARCHIVE,
)
from app.modules.logs_5651.service import _chain_hash, _period_key
from app.modules.logs_5651.archive_service import content_hash


def test_chain_hash_consistency():
    """Hash chain integrity: same inputs produce same curr_hash."""
    prev_hash = GENESIS_HASH
    content = b'{"test": "data"}'
    chash = content_hash(content)
    pkey = _period_key(
        datetime(2026, 1, 1, tzinfo=timezone.utc),
        datetime(2026, 1, 1, 1, tzinfo=timezone.utc),
    )
    record_type = RECORD_SESSION_ARCHIVE

    hash1 = _chain_hash(prev_hash, chash, pkey, record_type)
    hash2 = _chain_hash(prev_hash, chash, pkey, record_type)

    assert hash1 == hash2
    assert len(hash1) == 64
    assert hash1 != GENESIS_HASH


def test_chain_hash_different_content():
    """Different content should produce different curr_hash."""
    chash1 = content_hash(b'{"data": "A"}')
    chash2 = content_hash(b'{"data": "B"}')
    pkey = _period_key(
        datetime(2026, 1, 1, tzinfo=timezone.utc),
        datetime(2026, 1, 2, tzinfo=timezone.utc),
    )

    h1 = _chain_hash(GENESIS_HASH, chash1, pkey, RECORD_SESSION_ARCHIVE)
    h2 = _chain_hash(GENESIS_HASH, chash2, pkey, RECORD_SESSION_ARCHIVE)
    assert h1 != h2


def test_chain_hash_different_prev():
    """Different prev_hash should produce different curr_hash."""
    chash = content_hash(b'test content')
    pkey = "2026-01-01/2026-01-02"

    h1 = _chain_hash(GENESIS_HASH, chash, pkey, RECORD_SESSION_ARCHIVE)
    h2 = _chain_hash("a" * 64, chash, pkey, RECORD_SESSION_ARCHIVE)
    assert h1 != h2


def test_content_hash_deterministic():
    """Same content always produces the same hash."""
    data = b'{"sessions": []}'
    assert content_hash(data) == content_hash(data)


def test_content_hash_different():
    """Different content produces different hash."""
    assert content_hash(b"data1") != content_hash(b"data2")


def test_genesis_hash_format():
    """GENESIS_HASH must be 64 zeroes."""
    assert len(GENESIS_HASH) == 64
    assert GENESIS_HASH == "0" * 64


def generate_archive_record(chain_seq=1, prev_hash=None, content=b'test'):
    """Helper to create a mock archive record for testing."""
    prev = prev_hash or GENESIS_HASH
    chash = content_hash(content)
    ps = datetime(2026, 6, 1, tzinfo=timezone.utc)
    pe = datetime(2026, 6, 2, tzinfo=timezone.utc)
    pkey = _period_key(ps, pe)
    curr = _chain_hash(prev, chash, pkey, RECORD_SESSION_ARCHIVE)
    return ArchiveRecord(
        id=uuid.uuid4(),
        customer_id=uuid.uuid4(),
        period_start=ps,
        period_end=pe,
        record_type=RECORD_SESSION_ARCHIVE,
        chain_seq=chain_seq,
        item_count=1,
        content_hash=chash,
        content_ref=f"none:{chash}",
        content_size=len(content),
        prev_hash=prev,
        curr_hash=curr,
        meta={},
    )


def test_verify_chain_valid():
    """Simulate a valid 3-record chain and verify hash linkage."""
    content1 = b'session data 1'
    content2 = b'session data 2'
    content3 = b'session data 3'

    r1 = generate_archive_record(chain_seq=1, prev_hash=GENESIS_HASH, content=content1)
    r2 = generate_archive_record(chain_seq=2, prev_hash=r1.curr_hash, content=content2)
    r3 = generate_archive_record(chain_seq=3, prev_hash=r2.curr_hash, content=content3)

    # Verify linkage: r2.prev_hash == r1.curr_hash
    assert r2.prev_hash == r1.curr_hash
    assert r3.prev_hash == r2.curr_hash
    assert r1.prev_hash == GENESIS_HASH


def test_verify_chain_tampered():
    """Simulate tampering: changing a prev_hash should break the chain."""
    content1 = b'session data 1'
    content2 = b'session data 2'

    r1 = generate_archive_record(chain_seq=1, prev_hash=GENESIS_HASH, content=content1)
    r2 = generate_archive_record(chain_seq=2, prev_hash=r1.curr_hash, content=content2)

    # Tamper: change r2's prev_hash
    r2.prev_hash = "x" * 64
    assert r2.prev_hash != r1.curr_hash


def test_period_key_format():
    """Period key should be ISO format separated by slash."""
    ps = datetime(2026, 6, 15, 10, 30, tzinfo=timezone.utc)
    pe = datetime(2026, 6, 15, 11, 30, tzinfo=timezone.utc)
    key = _period_key(ps, pe)
    assert "/" in key
    assert "2026" in key
