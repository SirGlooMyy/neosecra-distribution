"""Extended edge case tests — domain-specific boundary inputs for all 5 modules.
Validates that service-layer functions handle empty/unicode/max-length/invalid
UUID/negative/date edge cases gracefully.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime, timedelta, timezone
from unittest import mock

import pytest
from fastapi import HTTPException
from pydantic import ValidationError

from app.modules.licensing.schemas import LicenseUpsert
from app.modules.partners.schemas import PartnerCreate, PartnerUpdate
from app.modules.customers.schemas import CustomerCreate, CustomerUpdate
from app.modules.locations.schemas import LocationCreate, LocationUpdate
from app.modules.identity.tc_validation import is_valid_turkish_identity_number


# =========================================================================
# 1. Licensing schema edge cases
# =========================================================================
class TestLicenseUpsertEdgeCases:
    def test_negative_quota_rejected(self):
        with pytest.raises(ValidationError):
            LicenseUpsert(active_guests_quota=-2)

    def test_unlimited_quota_allowed(self):
        s = LicenseUpsert(active_guests_quota=-1)
        assert s.active_guests_quota == -1

    def test_zero_sessions_per_day(self):
        s = LicenseUpsert(max_sessions_per_day=0)
        assert s.max_sessions_per_day == 0

    def test_plan_max_length(self):
        s = LicenseUpsert(plan="p" * 40)
        assert len(s.plan) == 40

    def test_plan_too_long(self):
        with pytest.raises(ValidationError):
            LicenseUpsert(plan="p" * 41)

    def test_session_minutes_ge_1(self):
        with pytest.raises(ValidationError):
            LicenseUpsert(session_minutes_default=0)

    def test_all_fields_empty(self):
        s = LicenseUpsert()
        assert s.model_dump(exclude_unset=True) == {}


# =========================================================================
# 2. Partner schema edge cases
# =========================================================================
class TestPartnerSchemaEdgeCases:
    def test_partner_create_empty_name(self):
        with pytest.raises(ValidationError):
            PartnerCreate(tenant_id=uuid.uuid4(), name="")

    def test_partner_create_name_too_long(self):
        with pytest.raises(ValidationError):
            PartnerCreate(tenant_id=uuid.uuid4(), name="x" * 256)

    def test_partner_update_empty_all(self):
        s = PartnerUpdate()
        assert s.model_dump(exclude_unset=True) == {}

    def test_partner_update_unicode(self):
        s = PartnerUpdate(name="İş Ortağı Şirket")
        assert s.name == "İş Ortağı Şirket"


# =========================================================================
# 3. Customer schema edge cases
# =========================================================================
class TestCustomerSchemaEdgeCases:
    def test_customer_create_empty_name(self):
        with pytest.raises(ValidationError):
            CustomerCreate(name="")

    def test_customer_create_partner_none(self):
        s = CustomerCreate(name="Valid Name")
        assert s.partner_id is None

    def test_customer_update_all_fields(self):
        s = CustomerUpdate(
            name="Updated",
            contact_name="Ali",
            contact_email="ali@test.com",
            contact_phone="+905551234567",
            is_active=False,
        )
        assert s.name == "Updated"
        assert s.is_active is False

    def test_customer_update_invalid_email(self):
        with pytest.raises(ValidationError):
            CustomerUpdate(contact_email="not-an-email")


# =========================================================================
# 4. Location schema edge cases
# =========================================================================
class TestLocationSchemaEdgeCases:
    def test_location_create_empty_name(self):
        with pytest.raises(ValidationError):
            LocationCreate(customer_id=uuid.uuid4(), name="")

    def test_location_create_unicode(self):
        s = LocationCreate(
            customer_id=uuid.uuid4(),
            name="Şube-Ğüşıöç",
            city="İstanbul",
            address="Cadde No:5",
        )
        assert "Şube" in s.name

    def test_location_update_empty(self):
        s = LocationUpdate()
        assert s.model_dump(exclude_unset=True) == {}

    def test_location_update_long_name(self):
        with pytest.raises(ValidationError):
            LocationUpdate(name="x" * 256)


# =========================================================================
# 5. TC validation edge cases
# =========================================================================
class TestTcValidationEdgeCases:
    def test_tc_null_byte(self):
        assert is_valid_turkish_identity_number("10000000146\u0000") is False

    def test_tc_with_spaces(self):
        assert is_valid_turkish_identity_number(" 10000000146 ") is False

    def test_tc_unicode_digits(self):
        assert is_valid_turkish_identity_number("\u2460000000146") is False

    def test_tc_all_zeros(self):
        assert is_valid_turkish_identity_number("00000000000") is False


# =========================================================================
# 6. UUID edge cases
# =========================================================================
class TestUuidEdgeCases:
    def test_nil_uuid_str(self):
        u = uuid.UUID("00000000-0000-0000-0000-000000000000")
        assert u.int == 0

    def test_max_uuid_str(self):
        u = uuid.UUID("ffffffff-ffff-ffff-ffff-ffffffffffff")
        assert u.int == 2**128 - 1

    def test_uuid_roundtrip(self):
        u = uuid.uuid4()
        assert uuid.UUID(str(u)) == u

    def test_invalid_uuid_raises(self):
        with pytest.raises(ValueError):
            uuid.UUID("not-a-valid-uuid-at-all")


# =========================================================================
# 7. Date and time edge cases
# =========================================================================
class TestDateEdgeCases:
    def test_leap_year(self):
        d = date(2024, 2, 29)
        assert d.day == 29

    def test_non_leap_raises(self):
        with pytest.raises(ValueError):
            date(2023, 2, 29)

    def test_year_2038_problem(self):
        d = datetime(2038, 1, 19, 3, 14, 7, tzinfo=timezone.utc)
        assert d.timestamp() > 0

    def test_post_2038(self):
        d = datetime(2040, 1, 1, tzinfo=timezone.utc)
        assert d.year == 2040

    def test_datetime_min_max_comparison(self):
        d1 = datetime.min.replace(tzinfo=timezone.utc)
        d2 = datetime.max.replace(tzinfo=timezone.utc)
        assert d2 > d1


# =========================================================================
# 8. Number edge cases
# =========================================================================
class TestNumberEdgeCases:
    def test_negative_quota_sentinel(self):
        assert -1 < 0

    def test_zero_active_count(self):
        assert max(0, 0) == 0

    def test_large_session_minutes(self):
        val = 1000000
        assert val > 0
        assert isinstance(val, int)

    def test_negative_phone(self):
        assert not isinstance(-1, str)


# =========================================================================
# 9. Schema default/null edge cases
# =========================================================================
class TestSchemaDefaults:
    def test_license_upsert_none_coerced(self):
        s = LicenseUpsert()
        assert s.model_dump(exclude_none=True) == {}

    def test_partner_contact_phone_optional(self):
        s = PartnerCreate(tenant_id=uuid.uuid4(), name="Test")
        assert s.contact_phone is None

    def test_location_timezone_optional(self):
        s = LocationCreate(customer_id=uuid.uuid4(), name="Test")
        assert s.timezone is None


# =========================================================================
# 10. SQL injection / special chars
# =========================================================================
class TestSpecialChars:
    def test_sql_injection_like_in_name(self):
        s = PartnerUpdate(name="' OR 1=1; --")
        assert s.name == "' OR 1=1; --"

    def test_html_in_name(self):
        s = LocationUpdate(name="<script>alert(1)</script>")
        assert s.name == "<script>alert(1)</script>"

    def test_newline_in_address(self):
        s = LocationUpdate(address="Line1\nLine2\nLine3")
        assert "\n" in s.address
