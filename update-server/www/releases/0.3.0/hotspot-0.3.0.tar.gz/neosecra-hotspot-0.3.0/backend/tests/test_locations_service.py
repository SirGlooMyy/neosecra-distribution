"""Location service tests — CRUD, scoped queries, edge cases."""
import uuid
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.locations.models import Location
from app.modules.locations.schemas import LocationCreate, LocationUpdate
from app.modules.locations import service as location_service
from app.core.tenant import ScopeContext, TenantLevel


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


def _global_scope() -> ScopeContext:
    return ScopeContext(level=TenantLevel.GLOBAL)


class TestListLocations:
    @pytest.mark.asyncio
    async def test_list_empty(self):
        db = _mock_db()
        result = await location_service.list_locations(db, _global_scope())
        assert result == []

    @pytest.mark.asyncio
    async def test_list_scoped_to_customer(self):
        db = _mock_db()
        cid = uuid.uuid4()
        scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=cid)
        result = await location_service.list_locations(db, scope)
        assert result == []


class TestGetLocation:
    @pytest.mark.asyncio
    async def test_get_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await location_service.get_location(db, uuid.uuid4(), _global_scope())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_get_forbidden_for_wrong_customer(self):
        db = _mock_db()
        loc_id = uuid.uuid4()
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        r.scalars.return_value.all.return_value = []
        db.execute.return_value = r
        wrong_scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=uuid.uuid4())

        with pytest.raises(HTTPException) as exc:
            await location_service.get_location(db, loc_id, wrong_scope)
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_get_success_global(self):
        db = _mock_db()
        loc_id = uuid.uuid4()
        location = Location(id=loc_id, customer_id=uuid.uuid4(), name="HQ")
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = location
        db.execute.return_value = r

        result = await location_service.get_location(db, loc_id, _global_scope())
        assert result.name == "HQ"


class TestCreateLocation:
    @pytest.mark.asyncio
    async def test_create_success(self):
        db = _mock_db()
        cid = uuid.uuid4()
        body = LocationCreate(
            customer_id=cid,
            name="New Location",
            city="Istanbul",
            timezone="Europe/Istanbul",
        )
        customer = mock.MagicMock()
        customer.id = cid
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = customer
        db.execute.return_value = r

        result = await location_service.create_location(db, body, _global_scope(), uuid.uuid4())
        assert result is not None
        assert db.add.called
        db.commit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_create_forbidden_for_wrong_scope(self):
        db = _mock_db()
        cid = uuid.uuid4()
        body = LocationCreate(customer_id=cid, name="No Access")
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = None
        db.execute.return_value = r
        scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=uuid.uuid4())  # different customer

        with pytest.raises(HTTPException) as exc:
            await location_service.create_location(db, body, scope, uuid.uuid4())
        assert exc.value.status_code == 403


class TestUpdateLocation:
    @pytest.mark.asyncio
    async def test_update_not_found(self):
        db = _mock_db()
        body = LocationUpdate(name="Updated")
        with pytest.raises(HTTPException) as exc:
            await location_service.update_location(db, uuid.uuid4(), body, _global_scope(), uuid.uuid4())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_update_success(self):
        db = _mock_db()
        loc_id = uuid.uuid4()
        location = Location(id=loc_id, customer_id=uuid.uuid4(), name="Old Name")
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = location
        db.execute.return_value = r

        body = LocationUpdate(name="New Name", city="Ankara")
        result = await location_service.update_location(db, loc_id, body, _global_scope(), uuid.uuid4())
        assert result.name == "New Name"
        assert location.name == "New Name"
        db.commit.assert_awaited_once()


class TestDeactivateLocation:
    @pytest.mark.asyncio
    async def test_deactivate_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await location_service.deactivate_location(db, uuid.uuid4(), _global_scope(), uuid.uuid4())
        assert exc.value.status_code == 404

    @pytest.mark.asyncio
    async def test_deactivate_success(self):
        db = _mock_db()
        loc_id = uuid.uuid4()
        location = Location(id=loc_id, customer_id=uuid.uuid4(), name="Active Loc", is_active=True)
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = location
        db.execute.return_value = r

        await location_service.deactivate_location(db, loc_id, _global_scope(), uuid.uuid4())
        assert location.is_active is False
        db.commit.assert_awaited_once()


class TestCreateLocationEdgeCases:
    @pytest.mark.asyncio
    async def test_create_with_unicode(self):
        db = _mock_db()
        cid = uuid.uuid4()
        body = LocationCreate(
            customer_id=cid,
            name="Şube İstanbul",
            city="İstanbul",
            address="İstiklal Caddesi No:123",
        )
        customer = mock.MagicMock()
        customer.id = cid
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = customer
        db.execute.return_value = r

        result = await location_service.create_location(db, body, _global_scope(), uuid.uuid4())
        assert result is not None
        assert "İstanbul" in result.name or result is not None
