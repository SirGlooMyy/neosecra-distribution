"""Extended identity service tests — SMS OTP, TC validation, voucher, token exchange."""
import uuid
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest
from fastapi import HTTPException

from app.modules.identity.models import IdentityVerification, METHOD_SMS, METHOD_TC, METHOD_VOUCHER, METHOD_FREE, METHOD_PMS, METHOD_LDAP, METHOD_LOCAL, METHOD_FOREIGNER, METHOD_MEETING, METHOD_WHATSAPP
from app.modules.identity import service as identity_service
from app.modules.identity.tc_validation import is_valid_turkish_identity_number, verify_with_nvi_fallback
from app.modules.sms.models import SmsOtp
from app.modules.vouchers.models import Voucher
from app.core.tenant import ScopeContext, TenantLevel


def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.flush = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


def _req():
    req = mock.MagicMock()
    req.client.host = "192.168.1.1"
    return req


# ----------------------------------------------------------------
# TC Validation (algorithmic)
# ----------------------------------------------------------------
class TestTcValidation:
    def test_valid_tc_numbers(self):
        assert is_valid_turkish_identity_number("10000000146") is True
        assert is_valid_turkish_identity_number("90141675250") is True

    def test_invalid_short(self):
        assert is_valid_turkish_identity_number("123") is False

    def test_invalid_long(self):
        assert is_valid_turkish_identity_number("123456789012") is False

    def test_invalid_letter(self):
        assert is_valid_turkish_identity_number("1000000014a") is False

    def test_invalid_starts_with_zero(self):
        assert is_valid_turkish_identity_number("00000000146") is False

    def test_invalid_checksum(self):
        assert is_valid_turkish_identity_number("12345678901") is False

    def test_empty_none(self):
        assert is_valid_turkish_identity_number("") is False
        assert is_valid_turkish_identity_number(None) is False

    def test_nvi_fallback_no_names(self):
        result = is_valid_turkish_identity_number("10000000146")
        assert result is True

    @pytest.mark.asyncio
    async def test_verify_with_nvi_fallback_algorithmic(self):
        result = await verify_with_nvi_fallback("10000000146")
        assert result is True

    @pytest.mark.asyncio
    async def test_verify_with_nvi_fallback_invalid(self):
        result = await verify_with_nvi_fallback("10000000147")
        assert result is False


# ----------------------------------------------------------------
# IdentityService :: _issue (private helper)
# ----------------------------------------------------------------
class TestIssue:
    @pytest.mark.asyncio
    async def test_issue_for_sms_success(self):
        db = _mock_db()
        otp = SmsOtp(
            id=uuid.uuid4(), phone="+905551234567",
            verified=True,
        )
        iv = await identity_service.issue_for_sms(
            db, otp=otp,
            customer_id=uuid.uuid4(),
            location_id=uuid.uuid4(),
            request=_req(),
        )
        assert iv is not None
        assert iv.method == METHOD_SMS
        assert iv.verified is True
        db.commit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_issue_for_sms_unverified_raises(self):
        db = _mock_db()
        otp = SmsOtp(id=uuid.uuid4(), phone="+905551234567", verified=False)
        with pytest.raises(HTTPException) as exc:
            await identity_service.issue_for_sms(
                db, otp=otp,
                customer_id=uuid.uuid4(),
            )
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_issue_for_tc_success(self):
        db = _mock_db()
        iv = await identity_service.issue_for_tc(
            db, tc_number="10000000146",
            customer_id=uuid.uuid4(),
            request=_req(),
        )
        assert iv.method == METHOD_TC
        assert iv.verified is True

    @pytest.mark.asyncio
    async def test_issue_for_tc_invalid_raises(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await identity_service.issue_for_tc(
                db, tc_number="123",
                customer_id=uuid.uuid4(),
            )
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_issue_for_voucher_success(self):
        db = _mock_db()
        voucher = Voucher(id=uuid.uuid4(), code_hash="abc")
        iv = await identity_service.issue_for_voucher(
            db, voucher=voucher,
            customer_id=uuid.uuid4(),
            request=_req(),
        )
        assert iv.method == METHOD_VOUCHER
        assert iv.verified is True

    @pytest.mark.asyncio
    async def test_issue_free(self):
        db = _mock_db()
        iv = await identity_service.issue_free(
            db, customer_id=uuid.uuid4(),
            request=_req(),
        )
        assert iv.method == METHOD_FREE
        assert iv.verified is True

    @pytest.mark.asyncio
    async def test_issue_for_pms(self):
        db = _mock_db()
        iv = await identity_service.issue_for_pms(
            db, room_number="101",
            customer_id=uuid.uuid4(),
        )
        assert iv.method == METHOD_PMS
        assert "Oda 101" in iv.phone

    @pytest.mark.asyncio
    async def test_issue_for_ldap(self):
        db = _mock_db()
        iv = await identity_service.issue_for_ldap(
            db, username="ali", display_name="Ali Yilmaz",
            customer_id=uuid.uuid4(),
        )
        assert iv.method == METHOD_LDAP
        assert "LDAP: ali (Ali Yilmaz)" in iv.phone

    @pytest.mark.asyncio
    async def test_issue_for_local(self):
        db = _mock_db()
        iv = await identity_service.issue_for_local(
            db, username="guest", display_name="Guest User",
            customer_id=uuid.uuid4(),
        )
        assert iv.method == METHOD_LOCAL
        assert iv.phone == "guest"

    @pytest.mark.asyncio
    async def test_issue_for_meeting(self):
        db = _mock_db()
        iv = await identity_service.issue_for_meeting(
            db, meeting_code="ABC123",
            customer_id=uuid.uuid4(),
        )
        assert iv.method == METHOD_MEETING
        assert "ABC123" in iv.phone

    @pytest.mark.asyncio
    async def test_issue_for_foreigner(self):
        db = _mock_db()
        iv = await identity_service.issue_for_foreigner(
            db, passport_number="AB123456",
            full_name="John Doe",
            country="US",
            customer_id=uuid.uuid4(),
        )
        assert iv.method == METHOD_FOREIGNER
        assert iv.phone == "AB123456"

    @pytest.mark.asyncio
    async def test_issue_for_whatsapp_success(self):
        db = _mock_db()
        wa = mock.MagicMock()
        wa.verified = True
        wa.phone = "+905551234567"
        wa.id = uuid.uuid4()
        iv = await identity_service.issue_for_whatsapp(
            db, wa=wa,
            customer_id=uuid.uuid4(),
            request=_req(),
        )
        assert iv.method == METHOD_WHATSAPP

    @pytest.mark.asyncio
    async def test_issue_for_whatsapp_unverified_raises(self):
        db = _mock_db()
        wa = mock.MagicMock()
        wa.verified = False
        with pytest.raises(HTTPException) as exc:
            await identity_service.issue_for_whatsapp(
                db, wa=wa,
                customer_id=uuid.uuid4(),
            )
        assert exc.value.status_code == 400


# ----------------------------------------------------------------
# Token exchange
# ----------------------------------------------------------------
class TestValidatePortalToken:
    @pytest.mark.asyncio
    async def test_token_valid(self):
        db = _mock_db()
        cid = uuid.uuid4()
        iv = IdentityVerification(
            id=uuid.uuid4(), customer_id=cid,
            portal_token="valid_token",
            portal_token_expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
            verified=True,
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = iv
        db.execute.return_value = r

        result = await identity_service.validate_portal_token(db, token="valid_token", customer_id=cid)
        assert result is not None
        assert result.id == iv.id

    @pytest.mark.asyncio
    async def test_token_not_found(self):
        db = _mock_db()
        with pytest.raises(HTTPException) as exc:
            await identity_service.validate_portal_token(db, token="nonexistent", customer_id=uuid.uuid4())
        assert exc.value.status_code == 401

    @pytest.mark.asyncio
    async def test_token_expired(self):
        db = _mock_db()
        cid = uuid.uuid4()
        iv = IdentityVerification(
            id=uuid.uuid4(), customer_id=cid,
            portal_token="expired_token",
            portal_token_expires_at=datetime.now(timezone.utc) - timedelta(minutes=5),
            verified=True,
        )
        r = mock.MagicMock()
        r.scalar_one_or_none.return_value = iv
        db.execute.return_value = r

        with pytest.raises(HTTPException) as exc:
            await identity_service.validate_portal_token(db, token="expired_token", customer_id=cid)
        assert exc.value.status_code == 410


class TestConsume:
    @pytest.mark.asyncio
    async def test_consume_success(self):
        db = _mock_db()
        iv = IdentityVerification(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            consumed_at=None,
        )
        db.get.return_value = iv

        await identity_service.consume(db, iv_id=iv.id)
        assert iv.consumed_at is not None
        db.commit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_consume_idempotent(self):
        db = _mock_db()
        iv = IdentityVerification(
            id=uuid.uuid4(), customer_id=uuid.uuid4(),
            consumed_at=datetime.now(timezone.utc),
        )
        db.get.return_value = iv

        await identity_service.consume(db, iv_id=iv.id)
        db.commit.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_consume_not_found(self):
        db = _mock_db()
        db.get.return_value = None
        await identity_service.consume(db, iv_id=uuid.uuid4())
        db.commit.assert_not_awaited()


# ----------------------------------------------------------------
# Admin scope queries
# ----------------------------------------------------------------
class TestListForAdmin:
    @pytest.mark.asyncio
    async def test_global_scope_returns_all(self):
        db = _mock_db()
        scope = ScopeContext(level=TenantLevel.GLOBAL)
        result = await identity_service.list_for_admin(db, scope)
        assert result == []

    @pytest.mark.asyncio
    async def test_customer_scope(self):
        db = _mock_db()
        cid = uuid.uuid4()
        scope = ScopeContext(level=TenantLevel.CUSTOMER, customer_id=cid)
        result = await identity_service.list_for_admin(db, scope)
        assert result == []

    @pytest.mark.asyncio
    async def test_support_scope_denied(self):
        db = _mock_db()
        scope = ScopeContext(level=TenantLevel.LOCATION, location_id=uuid.uuid4(), allowed=False)
        loc = mock.MagicMock()
        loc.customer_id = uuid.uuid4()
        db.execute.return_value.scalar_one_or_none.return_value = loc
        result = await identity_service.list_for_admin(db, scope)
        assert result == []


class TestMaskPhone:
    def test_mask_phone_standard(self):
        result = identity_service._mask_phone("+905551234567")
        assert result == "+90555***67"

    def test_mask_phone_short(self):
        result = identity_service._mask_phone("123")
        assert result == "***"

    def test_mask_phone_none(self):
        result = identity_service._mask_phone(None)
        assert result is None


class TestHashPhone:
    def test_hash_phone_deterministic(self):
        h1 = identity_service._hash_phone("+905551234567")
        h2 = identity_service._hash_phone("+905551234567")
        assert h1 == h2
        assert len(h1) == 64  # sha256 hex

    def test_hash_phone_different_inputs(self):
        h1 = identity_service._hash_phone("+905551234567")
        h2 = identity_service._hash_phone("+905551234568")
        assert h1 != h2
