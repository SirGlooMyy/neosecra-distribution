"""Portal flow policy enforcement tests."""
from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest import mock
import uuid

import pytest
from fastapi import HTTPException

from app.modules.user_groups.models import UserGroup
from app.modules.portal import flow as portal_flow
from app.modules.portal.flow import start_session


def _fake_context():
    device = mock.MagicMock(id=uuid.uuid4(), mgmt_ip="10.0.0.1")
    location = mock.MagicMock(id=uuid.uuid4())
    customer = mock.MagicMock(id=uuid.uuid4())
    template = mock.MagicMock()
    template.method = "sms"
    return device, location, customer, template


def _fake_identity(method: str = "sms", phone: str = "5551234567"):
    return SimpleNamespace(
        id=uuid.uuid4(),
        phone=phone,
        method=method,
        voucher_id=None,
        portal_token_expires_at=datetime(2026, 7, 13, 12, 30, tzinfo=timezone.utc),
    )


def _fake_group(customer_id: uuid.UUID, location_id: uuid.UUID):
    return UserGroup(
        id=uuid.uuid4(),
        customer_id=customer_id,
        location_id=location_id,
        name="Gold",
        is_active=True,
        is_default=True,
        priority=10,
        bandwidth_up=2000,
        bandwidth_down=5000,
        session_timeout=30,
        idle_timeout=10,
        daily_quota=1024,
        hourly_quota=128,
        max_sessions=2,
        vlan_id=77,
    )


@pytest.mark.asyncio
async def test_start_session_applies_group_policy_and_meta():
    db = mock.AsyncMock()
    device, location, customer, template = _fake_context()
    identity = _fake_identity()
    group = _fake_group(customer.id, location.id)
    group.access_start = datetime(2026, 7, 13, 11, 0, tzinfo=timezone.utc)
    group.access_end = datetime(2026, 7, 13, 23, 0, tzinfo=timezone.utc)
    session = SimpleNamespace(
        id=uuid.uuid4(),
        status="active",
        started_at=datetime(2026, 7, 13, 12, 0, tzinfo=timezone.utc),
        expires_at=datetime(2026, 7, 13, 12, 30, tzinfo=timezone.utc),
        terms_accepted=True,
        privacy_accepted=True,
        terms_version="v1",
        privacy_version="v1",
    )

    with (
        mock.patch("app.modules.portal.flow.resolve_context", new=mock.AsyncMock(return_value=(device, location, customer, template))),
        mock.patch("app.modules.portal.flow.identity_service.validate_portal_token", new=mock.AsyncMock(return_value=identity)),
        mock.patch("app.modules.portal.flow.ban_service.check_whitelisted", new=mock.AsyncMock(return_value=None)),
        mock.patch("app.modules.portal.flow.ban_service.check_banned", new=mock.AsyncMock(return_value=None)),
        mock.patch("app.modules.portal.flow.licensing_service.enforce_quota", new=mock.AsyncMock(return_value=mock.MagicMock())),
        mock.patch("app.modules.portal.flow.licensing_service.session_duration_minutes", return_value=45),
        mock.patch("app.modules.portal.flow.user_groups_service.list_session_groups", new=mock.AsyncMock(return_value=[group])),
        mock.patch("app.modules.portal.flow.user_groups_service.pick_session_group", return_value=group),
        mock.patch("app.modules.portal.flow.sessions_service.count_active_sessions_for_identity", new=mock.AsyncMock(return_value=1)),
        mock.patch("app.modules.portal.flow.authorize_guest_service", new=mock.AsyncMock(return_value=mock.MagicMock(ok=True, message="allowed"))) as authorize_mock,
        mock.patch("app.modules.portal.flow.sessions_service.create_session", new=mock.AsyncMock(return_value=session)) as create_session_mock,
        mock.patch("app.modules.portal.flow.identity_service.consume", new=mock.AsyncMock()),
    ):
        result = await start_session(
            db,
            device_id=device.id,
            portal_token="portal-token",
            mac="aa:bb:cc:dd:ee:ff",
            ip="10.0.0.55",
            ssid="GuestWiFi",
            terms_accepted=True,
            privacy_accepted=True,
        )

    assert result.session_id == session.id
    assert result.expires_at == session.expires_at
    assert create_session_mock.await_count == 1
    assert authorize_mock.await_count == 1
    authorize_payload = authorize_mock.await_args.args[3]
    assert authorize_payload["radius_avps"]["Tunnel-Type"] == 13
    assert authorize_payload["radius_avps"]["Tunnel-Private-Group-ID"] == "77"
    kwargs = create_session_mock.call_args.kwargs
    # Firewall and persisted session must share the same identity so the
    # close-session revoke derives the exact address name created at auth.
    assert kwargs["session_id"] == uuid.UUID(authorize_payload["session_id"])
    assert kwargs["group_id"] == group.id
    policy = kwargs["meta"]["group_policy"]
    assert policy["vlan_id"] == 77
    assert policy["radius_avps"]["Tunnel-Medium-Type"] == 6
    assert policy["bandwidth_up"] == 2000
    assert policy["location_id"] == str(location.id)
    assert policy["scope"] == "location"
    assert policy["access_start"] == group.access_start.isoformat()
    assert policy["access_window"]["end"] == group.access_end.isoformat()


@pytest.mark.asyncio
async def test_start_session_blocks_banned_guest_before_quota():
    db = mock.AsyncMock()
    device, location, customer, template = _fake_context()
    identity = _fake_identity()
    banned = object()

    with (
        mock.patch("app.modules.portal.flow.resolve_context", new=mock.AsyncMock(return_value=(device, location, customer, template))),
        mock.patch("app.modules.portal.flow.identity_service.validate_portal_token", new=mock.AsyncMock(return_value=identity)),
        mock.patch("app.modules.portal.flow.ban_service.check_whitelisted", new=mock.AsyncMock(return_value=None)),
        mock.patch("app.modules.portal.flow.ban_service.check_banned", new=mock.AsyncMock(return_value=banned)),
        mock.patch("app.modules.portal.flow.licensing_service.enforce_quota", new=mock.AsyncMock()) as quota_mock,
        mock.patch("app.modules.portal.flow.sessions_service.create_session", new=mock.AsyncMock()),
    ):
        with pytest.raises(HTTPException) as exc:
            await start_session(
                db,
                device_id=device.id,
                portal_token="portal-token",
                mac="aa:bb:cc:dd:ee:ff",
                ip="10.0.0.55",
                ssid="GuestWiFi",
                terms_accepted=True,
                privacy_accepted=True,
            )

    assert exc.value.status_code == 403
    assert quota_mock.await_count == 0


@pytest.mark.asyncio
async def test_start_session_blocks_over_limit_group():
    db = mock.AsyncMock()
    device, location, customer, template = _fake_context()
    identity = _fake_identity()
    group = _fake_group(customer.id, location.id)
    group.max_sessions = 1

    with (
        mock.patch("app.modules.portal.flow.resolve_context", new=mock.AsyncMock(return_value=(device, location, customer, template))),
        mock.patch("app.modules.portal.flow.identity_service.validate_portal_token", new=mock.AsyncMock(return_value=identity)),
        mock.patch("app.modules.portal.flow.ban_service.check_whitelisted", new=mock.AsyncMock(return_value=None)),
        mock.patch("app.modules.portal.flow.ban_service.check_banned", new=mock.AsyncMock(return_value=None)),
        mock.patch("app.modules.portal.flow.licensing_service.enforce_quota", new=mock.AsyncMock(return_value=mock.MagicMock())),
        mock.patch("app.modules.portal.flow.licensing_service.session_duration_minutes", return_value=45),
        mock.patch("app.modules.portal.flow.user_groups_service.list_session_groups", new=mock.AsyncMock(return_value=[group])),
        mock.patch("app.modules.portal.flow.sessions_service.count_active_sessions_for_identity", new=mock.AsyncMock(return_value=1)),
        mock.patch("app.modules.portal.flow.authorize_guest_service", new=mock.AsyncMock()),
        mock.patch("app.modules.portal.flow.sessions_service.create_session", new=mock.AsyncMock()),
    ):
        with pytest.raises(HTTPException) as exc:
            await start_session(
                db,
                device_id=device.id,
                portal_token="portal-token",
                mac="aa:bb:cc:dd:ee:ff",
                ip="10.0.0.55",
                ssid="GuestWiFi",
                terms_accepted=True,
                privacy_accepted=True,
            )

    assert exc.value.status_code == 409


@pytest.mark.asyncio
async def test_tc_sms_verify_uses_device_bound_identity():
    """Canonical TC+SMS verification must stay bound to the device site."""
    device, location, customer, template = _fake_context()
    template.method = "tc"
    otp = SimpleNamespace(verified=True)
    identity = SimpleNamespace(
        portal_token="portal-token",
        portal_token_expires_at=datetime.now(timezone.utc),
    )

    with (
        mock.patch.object(
            portal_flow,
            "resolve_context",
            new=mock.AsyncMock(return_value=(device, location, customer, template)),
        ),
        mock.patch.object(portal_flow, "_ensure_guest_not_banned", new=mock.AsyncMock()),
        mock.patch.object(portal_flow.sms_service, "verify_otp", new=mock.AsyncMock(return_value=otp)) as verify_otp,
        mock.patch.object(portal_flow.identity_service, "issue_for_tc", new=mock.AsyncMock(return_value=identity)) as issue_tc,
    ):
        result = await portal_flow.verify(
            mock.AsyncMock(),
            device_id=device.id,
            phone="+905551112233",
            code="123456",
            tc_number="10000000146",
        )

    assert result.portal_token == "portal-token"
    verify_otp.assert_awaited_once()
    issue_tc.assert_awaited_once_with(
        mock.ANY,
        tc_number="10000000146",
        customer_id=customer.id,
        location_id=location.id,
        device_id=device.id,
        request=None,
    )
