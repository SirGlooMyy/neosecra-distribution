from __future__ import annotations

import asyncio
import csv
import hashlib
import io
import json
import uuid
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest

from app.modules.archive.hash_chain import GENESIS_HASH, compute_chain_hash, verify_chain
from app.modules.archive.models import (
    CHUNK_STATUS_PENDING,
    CHUNK_STATUS_SIGNED,
    CHUNK_STATUS_UPLOADED,
    ArchiveChunk,
)
from app.modules.archive.repository import create_chunk, get_latest_chunk
from app.modules.archive.service import (
    sign_chunk_with_local_cert,
    upload_to_minio_worm,
    verify_chunk_integrity,
)
from app.modules.portal.flow import resolve_context, send_code, start_session, verify as portal_verify
from app.modules.sessions.correlation import correlate_session_with_firewall_logs
from app.modules.search.schemas import LogSearchParams
from app.modules.search.service import _CSV_BTK_COLUMNS, export_firewall_logs
from app.modules.sessions.models import GuestSession, STATUS_ACTIVE
from app.modules.syslog.models import FirewallLog
from tests.fake_fortigate_server import FakeFortiGateServer
from .conftest import create_db_session, close_db_session


@pytest.mark.e2e
class TestMVPFullFlow:

    def test_captive_portal_to_signed_archive(self, minio_client, test_cert):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.locations.models import Location
                from app.modules.devices.models import Device
                from app.modules.devices.models import DeviceCredential
                from app.modules.portal.models import PortalTemplate, METHOD_SMS
                from app.core.crypto import encrypt as fernet_encrypt

                tenant = Tenant(name="E2E", slug="e2e-main", is_root=True)
                db.add(tenant)
                await db.flush()
                await db.refresh(tenant)

                customer = Customer(tenant_id=tenant.id, name="E2E Customer")
                db.add(customer)
                await db.flush()
                await db.refresh(customer)

                location = Location(customer_id=customer.id, name="E2E Location")
                db.add(location)
                await db.flush()
                await db.refresh(location)

                async with FakeFortiGateServer() as fg:
                    device = Device(
                        location_id=location.id,
                        name="e2e-fortigate-test",
                        vendor="fortigate",
                        model="FortiGate-100F",
                        serial_number="E2E-FGT-0001",
                        status="online",
                        api_host="127.0.0.1",
                        api_port=fg.port,
                        meta={"api_tls": False},
                    )
                    db.add(device)
                    await db.flush()
                    await db.refresh(device)

                    cred = DeviceCredential(
                        device_id=device.id,
                        api_token_encrypted=fernet_encrypt("test-token"),
                        verify_tls=False,
                    )
                    db.add(cred)
                    await db.flush()

                    template = PortalTemplate(
                        customer_id=customer.id,
                        location_id=location.id,
                        name="E2E SMS Template",
                        method=METHOD_SMS,
                        is_default=True,
                        theme={"primary_color": "#4F46E5"},
                        fields=[{"key": "phone", "type": "tel", "label": "Phone"}],
                    )
                    db.add(template)
                    await db.flush()

                    device_id = device.id
                    customer_id = customer.id
                    session_id = str(uuid.uuid4())
                    guest_ip = "10.0.0.100"
                    guest_mac = "AA:BB:CC:DD:EE:FF"

                    fw_logs = []
                    for i in range(10):
                        et = datetime.now(timezone.utc) - timedelta(minutes=10 - i)
                        log_entry = FirewallLog(
                            tenant_id=tenant.id,
                            customer_id=customer_id,
                            device_id=device_id,
                            vendor="fortigate",
                            log_type="traffic" if i < 8 else "event",
                            severity="info",
                            action="accept",
                            src_ip=guest_ip,
                            dst_ip=f"8.8.8.{i}",
                            src_port=10000 + i,
                            dst_port=443,
                            proto="TCP",
                            service="HTTPS",
                            user="guest-user",
                            policyid=1,
                            duration=100 + i,
                            sentbyte=1000 * (i + 1),
                            rcvdbyte=2000 * (i + 1),
                            session_id=session_id,
                            received_at=et,
                            event_time=et,
                            raw_syslog="<14>1 test ...",
                            parsed_fields={},
                        )
                        db.add(log_entry)
                        fw_logs.append(log_entry)
                    await db.flush()
                    assert len(fw_logs) == 10

                    resolved = await resolve_context(db, device_id=device_id)
                    dev, loc, cust, tmpl = resolved
                    assert dev.id == device_id
                    assert cust.id == customer_id

                    fake_req = mock.MagicMock()
                    fake_req.client.host = "127.0.0.1"
                    fake_req.headers = {"user-agent": "pytest-e2e"}

                    with (
                        mock.patch("app.modules.sms.service._gen_code", return_value="123456"),
                        mock.patch("app.modules.sms.service.rate_limit", return_value=(False, 0)),
                    ):
                        sms_result = await send_code(
                            db, device_id=device_id, phone="+905551112233", request=fake_req
                        )
                        assert sms_result.state == "sent"

                        verify_result = await portal_verify(
                            db, device_id=device_id, phone="+905551112233",
                            code="123456", request=fake_req,
                        )
                        assert verify_result.portal_token is not None

                    session_out = await start_session(
                        db, device_id=device_id,
                        portal_token=verify_result.portal_token,
                        mac=guest_mac, ip=guest_ip, ssid="E2E-Guest",
                        request=fake_req,
                        terms_accepted=True, privacy_accepted=True,
                    )
                    assert session_out.status == "active"
                    assert session_out.authorize_ok is True
                    assert guest_ip in fg.authorized_ips

                    gs = await db.get(GuestSession, session_out.session_id)
                    assert gs is not None
                    assert gs.status == STATUS_ACTIVE

                    correlation = await correlate_session_with_firewall_logs(db, gs.id)
                    assert correlation["session"]["id"] == str(gs.id)
                    assert correlation["log_count"] >= 8

                    archive_logs = []
                    for fl in fw_logs:
                        archive_logs.append({
                            "type": "firewall_log",
                            "id": str(fl.id),
                            "logged_at": fl.event_time.isoformat() if fl.event_time else None,
                            "src_ip": fl.src_ip, "dst_ip": fl.dst_ip,
                            "action": fl.action, "proto": fl.proto,
                            "src_port": fl.src_port, "dst_port": fl.dst_port,
                            "policy_id": fl.policyid,
                        })
                    archive_logs.append({
                        "type": "guest_session",
                        "id": str(gs.id), "mac": gs.mac, "ip": gs.ip,
                        "phone": gs.phone, "status": gs.status,
                        "started_at": gs.started_at.isoformat() if gs.started_at else None,
                    })
                    archive_logs.sort(key=lambda x: (x.get("logged_at") or "", x.get("id") or ""))

                    period_start = datetime.now(timezone.utc) - timedelta(days=1)
                    period_end = datetime.now(timezone.utc)

                    latest = await get_latest_chunk(db, customer_id)
                    prev_hash = latest.curr_hash if latest else GENESIS_HASH
                    final_hash, intermediate_hashes = compute_chain_hash(archive_logs, prev_hash)

                    chunk_data = {
                        "logs": archive_logs,
                        "chain": {
                            "prev_hash": prev_hash, "curr_hash": final_hash,
                            "intermediate_hashes": intermediate_hashes,
                        },
                        "period": {"start": period_start.isoformat(), "end": period_end.isoformat()},
                        "customer_id": str(customer_id),
                        "generated_at": datetime.now(timezone.utc).isoformat(),
                    }
                    chunk_json = json.dumps(chunk_data, sort_keys=True, ensure_ascii=False)
                    content_hash_val = hashlib.sha256(chunk_json.encode("utf-8")).hexdigest()

                    chunk = ArchiveChunk(
                        customer_id=customer_id,
                        period_start=period_start, period_end=period_end,
                        log_count=len(archive_logs),
                        content_hash=content_hash_val,
                        curr_hash=final_hash, prev_hash=prev_hash,
                        intermediate_hashes=intermediate_hashes,
                        status=CHUNK_STATUS_PENDING,
                        content_size=len(chunk_json.encode("utf-8")),
                        meta={"_chunk_json": chunk_json},
                    )
                    await create_chunk(db, chunk)

                    signed = await sign_chunk_with_local_cert(db, chunk, test_cert, "test123")
                    assert signed.status == CHUNK_STATUS_SIGNED
                    assert signed.signature_value is not None

                    chunk_payload = chunk_json.encode("utf-8")
                    minio_key = await upload_to_minio_worm(signed, chunk_payload)
                    assert minio_key is not None
                    assert signed.status == CHUNK_STATUS_UPLOADED

                    if hasattr(minio_client, "get_object") and not isinstance(minio_client.get_object, mock.MagicMock):
                        obj = minio_client.get_object("hotspot-5651-test", signed.minio_object_key)
                        obj_data = obj.read()
                        obj.close()
                        obj.release_conn()
                        assert obj_data == chunk_payload

                    verify_result = await verify_chunk_integrity(db, signed.id)
                    assert verify_result.chain_valid is True
                    assert "Content hash valid" in verify_result.message

                    chain_ok = verify_chain(
                        logs=archive_logs, intermediate_hashes=intermediate_hashes,
                        final_hash=final_hash, prev_hash=prev_hash,
                    )
                    assert chain_ok

                    import base64
                    from cryptography.hazmat.primitives import hashes, serialization
                    from cryptography.hazmat.primitives.asymmetric import padding, rsa
                    from cryptography.hazmat.primitives.serialization import pkcs12

                    with open(test_cert, "rb") as fh:
                        p12_data = fh.read()
                    _, cert, _ = pkcs12.load_key_and_certificates(p12_data, b"test123")
                    if cert:
                        sig_bytes = base64.b64decode(signed.signature_value)
                        public_key = cert.public_key()
                        if isinstance(public_key, rsa.RSAPublicKey):
                            content_to_sign = f"{signed.curr_hash}:{signed.content_hash}:{signed.period_start.isoformat()}:{signed.period_end.isoformat()}"
                            content_hash_for_sig = hashlib.sha256(content_to_sign.encode()).hexdigest()
                            public_key.verify(
                                sig_bytes,
                                content_hash_for_sig.encode("utf-8"),
                                padding.PKCS1v15(),
                                hashes.SHA256(),
                            )

                    user = type("TestUser", (), {
                        "tenant_id": tenant.id, "id": uuid.uuid4(),
                        "role": "super_admin", "is_active": True,
                    })()

                    csv_filters = LogSearchParams(src_ip=guest_ip, limit=100)
                    csv_stream, _ = await export_firewall_logs(db, user, csv_filters, fmt="csv")
                    csv_content = b"".join([chunk async for chunk in csv_stream]).decode("utf-8")

                    reader = csv.DictReader(io.StringIO(csv_content))
                    assert reader.fieldnames == _CSV_BTK_COLUMNS
                    rows = list(reader)
                    assert len(rows) >= 10
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())
