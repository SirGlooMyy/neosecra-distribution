"""Shared test fixtures for the Hotspot backend test suite."""
from __future__ import annotations

import asyncio
import inspect
import tempfile

import pytest


def pytest_configure(config):
    """Register local markers and keep async tests self-contained."""
    config.addinivalue_line("markers", "asyncio: run the test in an event loop")


def pytest_pyfunc_call(pyfuncitem):
    """Run coroutine test functions without requiring pytest-asyncio."""
    if inspect.iscoroutinefunction(pyfuncitem.obj):
        testargs = {
            name: pyfuncitem.funcargs[name]
            for name in pyfuncitem._fixtureinfo.argnames
        }
        asyncio.run(pyfuncitem.obj(**testargs))
        return True
    return None


@pytest.fixture
def temp_archive_dir():
    """Create a temporary directory for archive upload tests."""
    from app.core.config import settings

    old_val = settings.ARCHIVE_LOCAL_DIR
    with tempfile.TemporaryDirectory() as tmpdir:
        settings.ARCHIVE_LOCAL_DIR = tmpdir
        yield tmpdir
    settings.ARCHIVE_LOCAL_DIR = old_val
