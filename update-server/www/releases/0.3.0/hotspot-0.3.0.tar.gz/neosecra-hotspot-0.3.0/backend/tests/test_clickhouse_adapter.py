"""Unit tests for ClickHouse adapter client and queries."""
import pytest
from datetime import datetime, timezone
import uuid
from unittest.mock import MagicMock, patch

from app.adapters import clickhouse as ch


@pytest.fixture
def mock_ch_client():
    with patch("app.adapters.clickhouse.clickhouse_connect.get_client") as mock_get:
        mock_client = MagicMock()
        mock_get.return_value = mock_client
        # Reset global client
        ch._client = None
        yield mock_client
        ch._client = None


def test_ensure_schema(mock_ch_client):
    import asyncio
    asyncio.run(ch.ensure_schema())
    assert mock_ch_client.command.call_count == 2


def test_insert_syslog_batch(mock_ch_client):
    import asyncio
    cid = uuid.uuid4()
    lid = uuid.uuid4()
    did = uuid.uuid4()
    sid = uuid.uuid4()
    records = [
        {
            "timestamp": datetime(2026, 7, 12, 12, 0, 0, tzinfo=timezone.utc),
            "customer_id": cid,
            "location_id": lid,
            "device_id": did,
            "facility": "auth",
            "severity": 6,
            "hostname": "fw-1",
            "app_name": "sshd",
            "source_ip": "192.168.1.5",
            "dest_ip": "8.8.8.8",
            "mac": "00:11:22:33:44:55",
            "username": "user1",
            "domain": "test.com",
            "application": "SSH",
            "action": "allow",
            "message": "connection accepted",
            "raw": "raw syslog msg",
            "session_id": sid,
        }
    ]
    inserted = asyncio.run(ch.insert_syslog_batch(records))
    assert inserted == 1
    mock_ch_client.insert.assert_called_once()
    args, kwargs = mock_ch_client.insert.call_args
    assert kwargs["table"] == "syslog_logs"
    assert kwargs["column_names"][0] == "timestamp"
    assert kwargs["data"][0][1] == cid


def test_query_syslog(mock_ch_client):
    import asyncio
    mock_result = MagicMock()
    mock_result.column_names = ["timestamp", "message", "username"]
    mock_result.result_rows = [(datetime.now(), "hello", "user1")]
    mock_ch_client.query.return_value = mock_result

    cid = str(uuid.uuid4())
    rows = asyncio.run(ch.query_syslog(
        customer_id=cid,
        from_time=datetime(2026, 7, 1, 0, 0, 0),
        username="user1",
        limit=10,
    ))

    assert len(rows) == 1
    assert rows[0]["username"] == "user1"
    assert rows[0]["message"] == "hello"
    mock_ch_client.query.assert_called_once()
    query_str = mock_ch_client.query.call_args[0][0]
    assert "syslog_logs" in query_str
    assert "customer_id = {cid:String}" in query_str
    assert "username = {uname:String}" in query_str


def test_count_syslog(mock_ch_client):
    import asyncio
    mock_result = MagicMock()
    mock_result.first_row = (42,)
    mock_ch_client.query.return_value = mock_result

    cid = str(uuid.uuid4())
    count = asyncio.run(ch.count_syslog(
        customer_id=cid,
        from_time=datetime(2026, 7, 1, 0, 0, 0),
        to_time=datetime(2026, 7, 12, 0, 0, 0),
    ))

    assert count == 42
    mock_ch_client.query.assert_called_once()


def test_get_traffic_aggregation(mock_ch_client):
    import asyncio
    mock_hourly = MagicMock()
    mock_hourly.result_rows = [(datetime.now(), 500, 1000, 5, 2)]
    mock_summary = MagicMock()
    mock_summary.first_row = (5000, 10000, 50, 10)
    mock_ch_client.query.side_effect = [mock_hourly, mock_summary]

    cid = str(uuid.uuid4())
    data = asyncio.run(ch.get_traffic_aggregation(customer_id=cid, days=30))

    assert "hourly" in data
    assert "summary" in data
    assert data["summary"]["total_bytes_in"] == 5000
    assert data["summary"]["peak_active"] == 10
    assert mock_ch_client.query.call_count == 2
