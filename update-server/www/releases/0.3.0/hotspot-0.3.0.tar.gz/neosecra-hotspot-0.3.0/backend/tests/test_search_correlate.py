"""Session correlation tests — GuestSession + FirewallLog traffic + FirewallLog auth."""

import uuid
from datetime import datetime, timezone
from unittest import mock

import pytest

from app.modules.search.schemas import LogSearchParams
from app.modules.search.service import correlate_session, search_firewall_logs
from app.modules.sessions.models import GuestSession
from app.modules.syslog.models import FirewallLog


@pytest.mark.asyncio
async def test_correlate_session_returns_all_sections():
    """Correlation returns session info, traffic_logs, auth_logs, and timeline."""
    session_id = str(uuid.uuid4())
    tenant_id = uuid.uuid4()
    now = datetime.now(timezone.utc)

    mock_session = mock.MagicMock(spec=GuestSession)
    mock_session.id = uuid.UUID(session_id)
    mock_session.mac = "AA:BB:CC:DD:EE:FF"
    mock_session.ip = "10.0.0.50"
    mock_session.auth_method = "sms"
    mock_session.status = "active"
    mock_session.started_at = now
    mock_session.ended_at = None
    mock_session.bytes_in = 5000
    mock_session.bytes_out = 10000

    def _mock_log(**kw):
        r = mock.MagicMock(spec=FirewallLog)
        for k, v in kw.items():
            setattr(r, k, v)
        return r

    traffic = _mock_log(
        id=uuid.uuid4(), tenant_id=tenant_id, vendor="fortigate",
        log_type="traffic", severity="info", action="accept",
        src_ip="10.0.0.50", dst_ip="8.8.8.8", event_time=now,
        session_id=session_id, raw_syslog="traffic log",
        received_at=now, log_subtype=None, src_port=443, dst_port=443,
        proto="TCP", service="HTTPS", user="test", policyid=1,
        duration=100, sentbyte=1000, rcvdbyte=2000,
        parsed_fields={},
    )
    auth_log = _mock_log(
        id=uuid.uuid4(), tenant_id=tenant_id, vendor="fortigate",
        log_type="event", severity="info", action="auth",
        src_ip="10.0.0.50", dst_ip=None, event_time=now,
        session_id=session_id, raw_syslog="auth event",
        received_at=now, log_subtype="auth", src_port=None, dst_port=None,
        proto=None, service=None, user="test", policyid=None,
        duration=None, sentbyte=None, rcvdbyte=None,
        parsed_fields={},
    )

    class _ScalarOne:
        def __init__(self, val):
            self._val = val
        def scalar_one_or_none(self):
            return self._val

    class _ScalarAll:
        def __init__(self, rows):
            self._rows = rows
        def scalars(self):
            return self
        def all(self):
            return self._rows

    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarOne(mock_session),
        _ScalarAll([traffic]),
        _ScalarAll([auth_log]),
    ]

    user = mock.MagicMock()
    user.tenant_id = tenant_id
    user.role = "customer_admin"

    res = await correlate_session(db, user, session_id)

    assert res.session is not None
    assert res.session.mac == "AA:BB:CC:DD:EE:FF"
    assert len(res.traffic_logs) == 1
    assert res.traffic_logs[0].log_type == "traffic"
    assert len(res.auth_logs) == 1
    assert res.auth_logs[0].log_type == "event"
    assert len(res.timeline) >= 1
    assert res.timeline[0].source in ("traffic", "auth", "session")


@pytest.mark.asyncio
async def test_correlate_session_with_unknown_session_id():
    """Unknown session_id returns empty sections but no error."""
    db = mock.AsyncMock()

    class _ScalarAll:
        def __init__(self, rows):
            self._rows = rows
        def scalars(self):
            return self
        def all(self):
            return self._rows

    db.execute.side_effect = [
        _ScalarAll([]),
        _ScalarAll([]),
    ]

    user = mock.MagicMock()
    user.tenant_id = uuid.uuid4()

    res = await correlate_session(db, user, "unknown-session-id")

    assert res.session is None
    assert len(res.traffic_logs) == 0
    assert len(res.auth_logs) == 0
    assert len(res.timeline) == 0


@pytest.mark.asyncio
async def test_correlate_timeline_ordered_by_event_time():
    """Timeline items are sorted chronologically."""
    session_id = str(uuid.uuid4())
    tenant_id = uuid.uuid4()

    t1 = datetime(2026, 7, 27, 10, 0, 0, tzinfo=timezone.utc)
    t2 = datetime(2026, 7, 27, 10, 5, 0, tzinfo=timezone.utc)
    t3 = datetime(2026, 7, 27, 10, 10, 0, tzinfo=timezone.utc)

    mock_session = mock.MagicMock(spec=GuestSession)
    mock_session.id = uuid.uuid4()
    mock_session.mac = "AA:BB:CC:DD:EE:FF"
    mock_session.ip = "10.0.0.50"
    mock_session.auth_method = "sms"
    mock_session.status = "active"
    mock_session.started_at = t2
    mock_session.ended_at = None
    mock_session.bytes_in = 0
    mock_session.bytes_out = 0

    def _mock_log(**kw):
        r = mock.MagicMock(spec=FirewallLog)
        for k, v in kw.items():
            setattr(r, k, v)
        return r

    traffic = _mock_log(
        id=uuid.uuid4(), tenant_id=tenant_id, vendor="fortigate",
        log_type="traffic", severity="info", action="accept",
        event_time=t3, session_id=session_id, raw_syslog="traffic",
        received_at=t3, log_subtype=None, src_ip="10.0.0.1",
        dst_ip="8.8.8.8", src_port=80, dst_port=80, proto="TCP",
        service="HTTP", user=None, policyid=None, duration=None,
        sentbyte=None, rcvdbyte=None, parsed_fields={},
    )
    auth = _mock_log(
        id=uuid.uuid4(), tenant_id=tenant_id, vendor="fortigate",
        log_type="event", severity="info", action="auth",
        event_time=t1, session_id=session_id, raw_syslog="auth",
        received_at=t1, log_subtype="auth", src_ip="10.0.0.1",
        dst_ip=None, src_port=None, dst_port=None, proto=None,
        service=None, user=None, policyid=None, duration=None,
        sentbyte=None, rcvdbyte=None, parsed_fields={},
    )

    class _ScalarOne:
        def __init__(self, val):
            self._val = val
        def scalar_one_or_none(self):
            return self._val

    class _ScalarAll:
        def __init__(self, rows):
            self._rows = rows
        def scalars(self):
            return self
        def all(self):
            return self._rows

    db = mock.AsyncMock()
    db.execute.side_effect = [
        _ScalarOne(mock_session),
        _ScalarAll([traffic]),
        _ScalarAll([auth]),
    ]

    user = mock.MagicMock()
    user.tenant_id = tenant_id

    res = await correlate_session(db, user, session_id)

    times = [item.event_time for item in res.timeline]
    assert times == sorted(times)
