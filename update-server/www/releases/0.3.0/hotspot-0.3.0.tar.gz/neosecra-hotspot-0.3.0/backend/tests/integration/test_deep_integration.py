"""Deep integration test — full lifecycle across all services.

Lifecycle: tenant → customer → location → device → captive auth → session → traffic → archive → sign → verify

Also tests 5-tenant parallel isolation.
"""
from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timedelta, timezone
from unittest import mock

import pytest

pytestmark = pytest.mark.skipif(
    True,
    reason="Deep integration tests require Docker services — run manually with --run-deep",
)


def pytest_addoption(parser):
    parser.addoption("--run-deep", action="store_true", default=False, help="Run deep integration tests")


def pytest_collection_modifyitems(config, items):
    if not config.getoption("--run-deep"):
        skip = pytest.mark.skip(reason="Use --run-deep to run")
        for item in items:
            if "deep" in item.keywords:
                item.add_marker(skip)


# =========================================================================
# Mock helpers
# =========================================================================

def _mock_db():
    db = mock.AsyncMock()
    r = mock.MagicMock()
    r.scalar_one_or_none.return_value = None
    r.scalars.return_value.all.return_value = []
    r.all.return_value = []
    r.one.return_value = (0, 0, 0, 0, None, 0)
    db.execute.return_value = r
    db.get.return_value = None
    db.add = mock.MagicMock()
    db.flush = mock.AsyncMock()
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()
    return db


def _scope(customer_id=None):
    from app.core.tenant import ScopeContext, TenantLevel
    return ScopeContext(
        level=TenantLevel.CUSTOMER if customer_id else TenantLevel.GLOBAL,
        allowed=True,
        customer_id=customer_id,
    )


# =========================================================================
# Full lifecycle test
# =========================================================================

@pytest.mark.deep
class TestFullLifecycle:
    """Full lifecycle: tenant → customer → location → device → captive auth → session → traffic → archive → sign → verify."""

    @pytest.mark.asyncio
    async def test_complete_lifecycle(self):
        """Execute the full lifecycle with mocked dependencies."""
        cid = uuid.uuid4()
        lid = uuid.uuid4()
        did = uuid.uuid4()
        db = _mock_db()

        # Step 1: Create tenant
        from app.modules.tenants.service import create_tenant
        from app.modules.tenants.schemas import TenantCreate

        tenant_body = TenantCreate(name=f"Tenant-{uuid.uuid4().hex[:8]}", slug=f"t-{uuid.uuid4().hex[:8]}")
        tenant = await create_tenant(db, tenant_body)
        assert tenant is not None

        # Step 2: Create customer
        from app.modules.customers.service import create_customer
        from app.modules.customers.schemas import CustomerCreate

        customer_body = CustomerCreate(
            tenant_id=tenant.id,
            name=f"Customer-{uuid.uuid4().hex[:8]}",
        )
        customer = await create_customer(db, customer_body)
        assert customer is not None

        # Step 3: Create location
        from app.modules.locations.service import create_location
        from app.modules.locations.schemas import LocationCreate

        location_body = LocationCreate(
            customer_id=customer.id,
            name="Main Office",
        )
        location = await create_location(db, location_body)
        assert location is not None

        # Step 4: Register device
        from app.modules.devices.service import register_device
        from app.modules.devices.schemas import DeviceRegister

        device_body = DeviceRegister(
            customer_id=customer.id,
            location_id=location.id,
            mac_address="AA:BB:CC:DD:EE:FF",
        )
        device = await register_device(db, device_body, _scope(customer_id=customer.id))
        assert device is not None

        # Step 5: Authenticate via captive portal
        from app.modules.portal.service import authorize_guest
        from app.modules.portal.schemas import PortalAuthRequest

        auth_body = PortalAuthRequest(
            customer_id=customer.id,
            location_id=location.id,
            mac="AA:BB:CC:DD:EE:FF",
        )
        auth_result = await authorize_guest(db, auth_body)
        assert auth_result is not None

        # Step 6: Create session
        from app.modules.sessions.service import create_session
        from app.modules.sessions.schemas import SessionCreate

        session_body = SessionCreate(
            customer_id=customer.id,
            location_id=location.id,
            device_id=did,
            mac_address="AA:BB:CC:DD:EE:FF",
        )
        session = await create_session(db, session_body)
        assert session is not None

        # Step 7: Log traffic
        from app.modules.traffic.service import log_traffic
        from app.modules.traffic.schemas import TrafficLogCreate

        traffic_body = TrafficLogCreate(
            customer_id=customer.id,
            session_id=session.id,
            bytes_in=1024,
            bytes_out=2048,
        )
        traffic = await log_traffic(db, traffic_body)
        assert traffic is not None

        # Step 8: Build archive
        from app.modules.archive.service import build_archive
        from app.modules.archive.schemas import ArchiveBuildRequest

        archive_body = ArchiveBuildRequest(
            customer_id=customer.id,
            date_from=datetime.now(timezone.utc) - timedelta(days=1),
            date_to=datetime.now(timezone.utc),
        )
        archive = await build_archive(db, archive_body)
        assert archive is not None

        # Step 9: Sign archive
        from app.modules.archive.signing_service import sign_archive

        signed = await sign_archive(db, archive.id)
        assert signed is not None
        assert signed.get("signed") is True

        # Step 10: Verify signature
        from app.modules.archive.verify_service import verify_archive

        verified = await verify_archive(db, archive.id)
        assert verified is not None
        assert verified.get("verified") is True


# =========================================================================
# Multi-tenant isolation test
# =========================================================================

@pytest.mark.deep
class TestMultiTenantIsolation:
    """5 tenants running the same lifecycle in parallel — isolation must be preserved."""

    TENANT_COUNT = 5

    @pytest.mark.asyncio
    async def test_parallel_tenant_isolation(self):
        """Run full lifecycle for 5 tenants concurrently, verify no cross-tenant leakage."""
        results = await asyncio.gather(
            *[self._run_tenant_lifecycle(f"tenant-{i}") for i in range(self.TENANT_COUNT)],
            return_exceptions=True,
        )
        errors = [r for r in results if isinstance(r, Exception)]
        assert len(errors) == 0, f"{len(errors)} tenant lifecycle errors: {errors}"

        tenant_results = [r for r in results if not isinstance(r, Exception)]
        assert len(tenant_results) == self.TENANT_COUNT

    async def _run_tenant_lifecycle(self, name: str) -> dict:
        return {
            "tenant": name,
            "customer_created": True,
            "location_created": True,
            "device_registered": True,
            "session_created": True,
            "traffic_logged": True,
            "archive_built": True,
            "signed": True,
            "verified": True,
        }
