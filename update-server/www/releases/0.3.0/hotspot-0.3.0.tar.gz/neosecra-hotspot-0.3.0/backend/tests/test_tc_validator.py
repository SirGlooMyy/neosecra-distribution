"""TC Kimlik No ve NVI dogrulama testleri."""
from app.modules.identity.tc_validation import is_valid_turkish_identity_number


def test_tc_validator_valid():
    """Gecerli TC numaralari algoritma kontrolunden gecmeli."""
    assert is_valid_turkish_identity_number("10000000146") is True
    assert is_valid_turkish_identity_number("90141675250") is True


def test_tc_validator_invalid():
    """Gecersiz TC numaralari reddedilmeli."""
    # 11 haneden kisa
    assert is_valid_turkish_identity_number("123") is False
    # 11 haneden uzun
    assert is_valid_turkish_identity_number("123456789012") is False
    # Harf iceriyor
    assert is_valid_turkish_identity_number("1000000014a") is False
    # Ilk hane 0 olamaz
    assert is_valid_turkish_identity_number("00000000146") is False
    # Algoritma kontrolu basarisiz
    assert is_valid_turkish_identity_number("12345678901") is False


def test_tc_validator_empty():
    """Bos deger False donmeli."""
    assert is_valid_turkish_identity_number("") is False
    assert is_valid_turkish_identity_number(None) is False


def test_nvi_fallback_algorithmic():
    """NVI (Merkezi Nufus Idaresi) kullanilamadiginda algoritmik kontrol calismali.

    Bu test, NVI servisinin ulasilamaz oldugu senaryoda
    algoritmik dogrulamanin hala dogru calistigini kontrol eder.
    TC dogrulama su an icin sadece algoritmiktir (NVI entegrasyonu ileride
    eklenecek). Algoritmik kontrol dogru calismalidir.
    """
    # Gecerli TC
    assert is_valid_turkish_identity_number("10000000146") is True

    # Gecersiz TC (10. hane yanlis)
    assert is_valid_turkish_identity_number("10000000147") is False

    # Gecersiz uzunluk
    assert is_valid_turkish_identity_number("1234567890") is False


def test_tc_validator_edge_cases():
    """Sinir deger testleri."""
    # En kucuk gecerli TC baslangici (1 ile baslamali)
    assert is_valid_turkish_identity_number("10000000000") is False  # algoritma dogrulamaz

    # 0 ile baslayamaz
    assert is_valid_turkish_identity_number("01234567890") is False
    assert is_valid_turkish_identity_number("01234567891") is False

    # Alfanumerik
    assert is_valid_turkish_identity_number("AAAAAAAAAAA") is False
