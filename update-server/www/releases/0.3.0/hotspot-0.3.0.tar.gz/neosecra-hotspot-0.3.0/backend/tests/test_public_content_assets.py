from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest import mock
import uuid

import pytest
from fastapi.testclient import TestClient

from app.core.database import get_db
from app.main import app
from app.modules.auth.deps import get_current_user
from app.modules.public_content.models import PublicAsset
from app.modules.public_content.schemas import PublicAssetUpsert
from app.modules.public_content import service


class _ScalarResult:
    def __init__(self, rows):
        self._rows = rows

    def scalars(self):
        return self

    def all(self):
        return self._rows

    def scalar_one_or_none(self):
        return self._rows[0] if self._rows else None


client = TestClient(app)


@pytest.mark.asyncio
async def test_list_public_assets_admin_serializes_rows():
    first = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-a",
        version="1.0.0",
        title="Ilk Makale",
        category="Destek",
        summary="Ozet",
        body="Icerik",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=100,
        meta={"kb_type": "faq", "workflow_status": "review"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    second = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-b",
        version="1.0.0",
        title="Ikinci Makale",
        category="Kurulum",
        summary="Ozet",
        body="Icerik",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=False,
        sort_order=90,
        meta={"kb_type": "troubleshooting", "workflow_status": "archived"},
        created_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 14, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([first, second]))

    result = await service.list_public_assets_admin(db, section="kb", include_inactive=True)

    assert [item.slug for item in result] == ["faq-a", "faq-b"]
    assert result[0].section == "kb"
    assert result[1].is_current is False
    assert result[0].workflow_status == "review"
    assert result[1].workflow_status == "archived"


@pytest.mark.asyncio
async def test_upsert_public_asset_updates_existing_row_and_deactivates_peers():
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-portal",
        version="1.0.0",
        title="Eski Baslik",
        category="Destek",
        summary="Eski ozet",
        body="Eski icerik",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=100,
        meta={"kb_type": "faq", "workflow_status": "draft"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=asset)
    db.execute = mock.AsyncMock(side_effect=[_ScalarResult([]), _ScalarResult([])])
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()

    body = PublicAssetUpsert(
        section="kb",
        slug="faq-portal",
        version="1.0.0",
        title="Yeni Baslik",
        category="Destek",
        summary="Yeni ozet",
        body="Guncel icerik",
        asset_url="/kb/faq-portal",
        checksum="abc123",
        file_size_kb=12,
        is_current=True,
        sort_order=50,
        workflow_status="review",
        meta={"kb_type": "faq", "audience": "all"},
    )

    result = await service.upsert_public_asset(db, body, asset_id=asset.id)

    assert asset.title == "Yeni Baslik"
    assert asset.summary == "Yeni ozet"
    assert asset.body == "Guncel icerik"
    assert asset.asset_url == "/kb/faq-portal"
    assert asset.checksum == "abc123"
    assert asset.file_size_kb == 12
    assert asset.sort_order == 50
    assert asset.meta["audience"] == "all"
    assert asset.meta["workflow_status"] == "review"
    assert result.title == "Yeni Baslik"
    assert result.workflow_status == "review"
    assert db.execute.await_count == 2
    assert db.commit.await_count == 1
    assert db.refresh.await_count == 1


@pytest.mark.asyncio
async def test_upsert_public_asset_creates_new_row_when_missing():
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(side_effect=[_ScalarResult([]), _ScalarResult([])])
    db.add = mock.MagicMock()
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()

    body = PublicAssetUpsert(
        section="kb",
        slug="faq-login",
        version="1.0.0",
        title="Giris Sorunu",
        category="Kurulum",
        summary="Ozet",
        body="Yeni icerik",
        is_current=True,
        sort_order=10,
        workflow_status="published",
        meta={"kb_type": "troubleshooting"},
    )

    result = await service.upsert_public_asset(db, body)

    assert result.slug == "faq-login"
    assert result.workflow_status == "published"
    assert db.add.call_count == 1
    assert db.execute.await_count == 2
    created = db.add.call_args.args[0]
    assert created.slug == "faq-login"
    assert created.is_current is True


@pytest.mark.asyncio
async def test_archive_public_asset_marks_row_inactive():
    asset = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-archived",
        version="1.0.0",
        title="Arsivlenecek",
        category="Destek",
        summary="Ozet",
        body="Icerik",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=10,
        meta={"workflow_status": "published"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=asset)
    db.commit = mock.AsyncMock()
    db.refresh = mock.AsyncMock()

    result = await service.archive_public_asset(db, asset.id)

    assert asset.is_current is False
    assert result.is_current is False
    assert result.workflow_status == "archived"
    assert result.updated_at >= asset.created_at
    assert db.commit.await_count == 1
    assert db.refresh.await_count == 1


@pytest.mark.asyncio
async def test_search_public_assets_ranks_exact_match_first():
    exact = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-portal-login",
        version="1.0.0",
        title="Portal Login Sorunu",
        category="Destek",
        summary="Portal açılmıyor",
        body="Portal login troubleshooting",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=100,
        meta={"kb_type": "troubleshooting", "tags": ["portal", "login"], "workflow_status": "published"},
        created_at=datetime(2026, 7, 13, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, 12, tzinfo=timezone.utc),
    )
    fuzzy = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-portal-setup",
        version="1.0.0",
        title="Portal Kurulumu",
        category="Kurulum",
        summary="Portal ayarları",
        body="Genel portal kurulum rehberi",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=90,
        meta={"kb_type": "guide", "tags": ["portal"], "workflow_status": "published"},
        created_at=datetime(2026, 7, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 12, tzinfo=timezone.utc),
    )
    unrelated = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-support-contact",
        version="1.0.0",
        title="Destek İletişimi",
        category="Destek",
        summary="İletişim kanalları",
        body="Support contact info",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=80,
        meta={"kb_type": "contact", "workflow_status": "published"},
        created_at=datetime(2026, 7, 11, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 11, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([fuzzy, exact, unrelated]))

    result = await service.search_public_assets(db, query="faq-portal-login", section="kb", include_inactive=True, limit=10)

    assert [item.slug for item in result][:2] == ["faq-portal-login", "faq-portal-setup"]


@pytest.mark.asyncio
async def test_suggest_public_kb_assets_prioritizes_related_slug_and_shared_tags():
    selected = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-portal-base",
        version="1.0.0",
        title="Portal Temelleri",
        category="Kurulum",
        summary="Portal başlangıç",
        body="Portal basics",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=100,
        meta={"kb_type": "guide", "tags": ["portal", "wifi"], "related_slugs": ["faq-landing"], "workflow_status": "published"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    related = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-landing",
        version="1.0.0",
        title="Landing Page",
        category="Kurulum",
        summary="Açılış sayfası",
        body="Landing guidance",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=90,
        meta={"kb_type": "guide", "tags": ["welcome"], "workflow_status": "published"},
        created_at=datetime(2026, 7, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 12, tzinfo=timezone.utc),
    )
    shared_tags = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-portal-wifi",
        version="1.0.0",
        title="Portal Wi-Fi",
        category="Kurulum",
        summary="Portal ve Wi-Fi",
        body="Wi-Fi portal guidance",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=80,
        meta={"kb_type": "guide", "tags": ["portal", "wifi"], "workflow_status": "published"},
        created_at=datetime(2026, 7, 11, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 11, tzinfo=timezone.utc),
    )

    db = mock.AsyncMock()
    db.get = mock.AsyncMock(return_value=selected)
    db.execute = mock.AsyncMock(return_value=_ScalarResult([shared_tags, related]))

    result = await service.suggest_public_kb_assets(db, asset_id=selected.id, include_inactive=True, limit=5)

    assert [item.slug for item in result][:2] == ["faq-landing", "faq-portal-wifi"]


def test_search_public_assets_endpoint_returns_ranked_results():
    exact = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-portal-login",
        version="1.0.0",
        title="Portal Login Sorunu",
        category="Destek",
        summary="Portal açılmıyor",
        body="Portal login troubleshooting",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=100,
        meta={"kb_type": "troubleshooting", "tags": ["portal", "login"], "workflow_status": "published"},
        created_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 13, tzinfo=timezone.utc),
    )
    fuzzy = PublicAsset(
        id=uuid.uuid4(),
        section="kb",
        slug="faq-portal-setup",
        version="1.0.0",
        title="Portal Kurulumu",
        category="Kurulum",
        summary="Portal ayarları",
        body="Genel portal kurulum rehberi",
        asset_url=None,
        checksum=None,
        file_size_kb=None,
        is_current=True,
        sort_order=90,
        meta={"kb_type": "guide", "tags": ["portal"], "workflow_status": "published"},
        created_at=datetime(2026, 7, 12, tzinfo=timezone.utc),
        updated_at=datetime(2026, 7, 12, tzinfo=timezone.utc),
    )
    db = mock.AsyncMock()
    db.execute = mock.AsyncMock(return_value=_ScalarResult([fuzzy, exact]))

    app.dependency_overrides[get_db] = lambda: db
    app.dependency_overrides[get_current_user] = lambda: SimpleNamespace(id=uuid.uuid4(), role="super_admin")
    try:
        response = client.get("/api/v1/public-content/assets/search?q=faq-portal-login&section=kb")
    finally:
        app.dependency_overrides.clear()

    assert response.status_code == 200
    payload = response.json()
    assert [item["slug"] for item in payload] == ["faq-portal-login", "faq-portal-setup"]
