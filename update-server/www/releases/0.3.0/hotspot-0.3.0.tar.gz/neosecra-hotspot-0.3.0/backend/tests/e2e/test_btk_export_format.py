from __future__ import annotations

import asyncio
import csv
import io
import uuid
from datetime import datetime, timezone

import pytest

from app.modules.search.schemas import LogSearchParams
from app.modules.search.service import _CSV_BTK_COLUMNS, export_firewall_logs
from app.modules.syslog.models import FirewallLog
from .conftest import create_db_session, close_db_session


@pytest.mark.e2e
class TestBtkExportFormat:

    def test_btk_column_order(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.devices.models import Device
                t = Tenant(name="BTK Tenant", slug="btk-tenant", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="BTK Customer")
                db.add(c)
                await db.flush()
                await db.refresh(c)
                from app.modules.locations.models import Location
                loc_btk = Location(customer_id=c.id, name="BTK Loc")
                db.add(loc_btk)
                await db.flush()
                d = Device(location_id=loc_btk.id, name="btk-device", vendor="fortigate", status="online")
                db.add(d)
                await db.flush()

                now = datetime.now(timezone.utc)
                for i in range(100):
                    db.add(FirewallLog(
                        tenant_id=t.id,
                        customer_id=c.id, device_id=d.id, vendor="fortigate",
                        log_type="traffic", severity="info", action="accept",
                        src_ip=f"10.0.0.{i % 255}", dst_ip="8.8.8.8",
                        src_port=10000 + i, dst_port=443, proto="TCP",
                        service="HTTPS", user=f"user-{i}", policyid=i % 10 + 1,
                        duration=100 + i, sentbyte=1000 * (i + 1), rcvdbyte=2000 * (i + 1),
                        session_id=f"sess-btk-{i}", received_at=now, event_time=now,
                        raw_syslog="btk test", parsed_fields={},
                    ))
                await db.flush()

                user = type("TestUser", (), {
                    "tenant_id": t.id, "id": uuid.uuid4(),
                    "role": "super_admin", "is_active": True,
                })()
                csv_stream, _ = await export_firewall_logs(db, user, LogSearchParams(limit=100), fmt="csv")
                csv_content = b"".join([chunk async for chunk in csv_stream]).decode("utf-8")

                reader = csv.DictReader(io.StringIO(csv_content))
                assert reader.fieldnames == _CSV_BTK_COLUMNS
                rows = list(reader)
                assert len(rows) == 100
                for row in rows:
                    assert row["vendor"] == "fortigate"
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_btk_date_format(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.devices.models import Device
                t = Tenant(name="BTK D Tenant", slug="btk-date", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="BTK D Cust")
                db.add(c)
                await db.flush()
                await db.refresh(c)
                from app.modules.locations.models import Location
                loc_dt = Location(customer_id=c.id, name="BTK Date Loc")
                db.add(loc_dt)
                await db.flush()
                d = Device(location_id=loc_dt.id, name="btk-date-dev", vendor="fortigate", status="online")
                db.add(d)
                await db.flush()

                now = datetime.now(timezone.utc)
                for i in range(5):
                    db.add(FirewallLog(
                        tenant_id=t.id,
                        customer_id=c.id, device_id=d.id, vendor="fortigate",
                        log_type="traffic", severity="info", action="accept",
                        src_ip="10.0.0.1", dst_ip="8.8.8.8",
                        session_id=f"sess-dt-{i}", received_at=now, event_time=now,
                        raw_syslog="date test", parsed_fields={},
                    ))
                await db.flush()

                user = type("TestUser", (), {
                    "tenant_id": t.id, "id": uuid.uuid4(),
                    "role": "super_admin", "is_active": True,
                })()
                csv_stream, _ = await export_firewall_logs(db, user, LogSearchParams(limit=5), fmt="csv")
                csv_content = b"".join([chunk async for chunk in csv_stream]).decode("utf-8")

                reader = csv.DictReader(io.StringIO(csv_content))
                for row in reader:
                    if row.get("event_time"):
                        datetime.fromisoformat(row["event_time"])
                    if row.get("received_at"):
                        datetime.fromisoformat(row["received_at"])
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())

    def test_btk_export_content_format(self):
        async def _run():
            engine, db, conn, tx = await create_db_session()
            try:
                from app.modules.tenants.models import Tenant
                from app.modules.customers.models import Customer
                from app.modules.devices.models import Device
                t = Tenant(name="BTK C Tenant", slug="btk-content", is_root=True)
                db.add(t)
                await db.flush()
                await db.refresh(t)
                c = Customer(tenant_id=t.id, name="BTK C Cust")
                db.add(c)
                await db.flush()
                await db.refresh(c)
                from app.modules.locations.models import Location
                loc_ct = Location(customer_id=c.id, name="BTK Content Loc")
                db.add(loc_ct)
                await db.flush()
                d = Device(location_id=loc_ct.id, name="btk-content-dev", vendor="fortigate", status="online")
                db.add(d)
                await db.flush()

                now = datetime.now(timezone.utc)
                for i in range(10):
                    db.add(FirewallLog(
                        tenant_id=t.id,
                        customer_id=c.id, device_id=d.id, vendor="fortigate",
                        log_type="traffic", severity="info", action="accept",
                        src_ip="10.0.0.1", dst_ip="8.8.8.8",
                        session_id=f"sess-ct-{i}", received_at=now, event_time=now,
                        raw_syslog="content test", parsed_fields={},
                    ))
                await db.flush()

                user = type("TestUser", (), {
                    "tenant_id": t.id, "id": uuid.uuid4(),
                    "role": "super_admin", "is_active": True,
                })()
                csv_stream, filename = await export_firewall_logs(db, user, LogSearchParams(limit=10), fmt="csv")
                assert filename.endswith(".csv")

                csv_content = b"".join([chunk async for chunk in csv_stream]).decode("utf-8")
                lines = csv_content.strip().split("\n")
                assert len(lines) == 11
                assert lines[0].startswith("event_time")
            finally:
                await close_db_session(engine, db, conn, tx)

        asyncio.run(_run())
