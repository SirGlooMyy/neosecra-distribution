"""CORS (Cross-Origin Resource Sharing) güvenlik testleri.

Kapsam:
  - Origin: evil.com -> reject
  - Credentials: true -> ACLO sınırı
  - Preflight OPTIONS doğrulama
  - Allow-Origin reflection yok
  - Vary: Origin header kontrolü
"""
import pytest
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


# =====================================================================
# CORS — evil origin rejection
# =====================================================================

MALICIOUS_ORIGINS = [
    "https://evil.com",
    "https://malicious.site",
    "http://attacker.io",
    "https://evilsite.com.evilsite.com",
    "http://localhost:9999",
]


@pytest.mark.parametrize("origin", MALICIOUS_ORIGINS)
def test_cors_reject_malicious_origin(origin):
    """CORS: Malicious origins must not be allowed."""
    response = client.options(
        "/api/v1/auth/me",
        headers={
            "Origin": origin,
            "Access-Control-Request-Method": "GET",
        },
    )
    allow_origin = response.headers.get("access-control-allow-origin", "")
    assert origin not in allow_origin, (
        f"CORS: Malicious origin '{origin}' was allowed!"
    )


# =====================================================================
# CORS — allowed origins verification
# =====================================================================

def test_cors_allowed_origins():
    """CORS: Only configured origins should be allowed."""
    from app.core.config import settings

    allowed = settings.cors_origins_list
    assert len(allowed) > 0, "CORS origins list should not be empty"

    # Verify localhost origins are allowed (dev mode)
    for origin in allowed:
        response = client.options(
            "/api/v1/auth/login",
            headers={
                "Origin": origin,
                "Access-Control-Request-Method": "POST",
            },
        )
        assert response.status_code in (200, 204), (
            f"CORS preflight for allowed origin '{origin}' "
            f"returned {response.status_code}"
        )


# =====================================================================
# CORS — no wildcard in production
# =====================================================================

def test_cors_no_wildcard():
    """CORS: Wildcard '*' must not be used in allowed origins."""
    from app.core.config import settings
    origins = settings.cors_origins_list
    assert "*" not in origins, (
        "CORS wildcard '*' detected — security risk"
    )


# =====================================================================
# CORS — Vary header
# =====================================================================

def test_cors_vary_header():
    """CORS responses should include Vary: Origin header."""
    response = client.get(
        "/api/v1/health",
        headers={"Origin": "http://localhost:5173"},
    )
    vary = response.headers.get("vary", "")
    assert "origin" in vary.lower(), (
        f"CORS: Vary header missing 'Origin', got '{vary}'"
    )


# =====================================================================
# CORS — credentials with wildcard
# =====================================================================

def test_cors_credentials_conflict():
    """If Access-Control-Allow-Credentials: true, origin must not be '*'."""
    response = client.options(
        "/api/v1/auth/login",
        headers={
            "Origin": "http://localhost:5173",
            "Access-Control-Request-Method": "POST",
        },
    )
    aco = response.headers.get("access-control-allow-origin", "")
    credentials = response.headers.get("access-control-allow-credentials", "")

    if credentials.lower() == "true":
        assert aco != "*", (
            "CORS: credentials=true with wildcard origin is insecure"
        )


# =====================================================================
# CORS — reflect-origin protection
# =====================================================================

def test_cors_no_reflect_origin():
    """CORS must not reflect any arbitrary origin back."""
    test_origins = [
        "https://evil.com",
        "https://attacker.org",
        "http://phishing-site.com",
    ]
    for origin in test_origins:
        response = client.get(
            "/api/v1/health",
            headers={"Origin": origin},
        )
        reflected = response.headers.get("access-control-allow-origin", "")
        if reflected:
            assert reflected != origin, (
                f"CORS: Origin reflection detected — '{origin}' reflected back"
            )


# =====================================================================
# CORS — preflight max-age
# =====================================================================

def test_cors_preflight_max_age():
    """Preflight response should include Access-Control-Max-Age."""
    response = client.options(
        "/api/v1/auth/login",
        headers={
            "Origin": "http://localhost:5173",
            "Access-Control-Request-Method": "POST",
        },
    )
    max_age = response.headers.get("access-control-max-age")
    # Max-age is optional but should be reasonable if present
    if max_age is not None:
        assert int(max_age) <= 86400, (
            f"CORS max-age too large: {max_age}s (max recommended: 86400)"
        )
