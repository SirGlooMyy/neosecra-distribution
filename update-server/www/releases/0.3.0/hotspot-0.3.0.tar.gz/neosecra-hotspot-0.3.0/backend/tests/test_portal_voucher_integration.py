import shutil
import subprocess
import uuid

import httpx
import pytest

BASE = "http://localhost:58001"
DEVICE_ID = "be25c340-59f8-42b8-bbcf-27af315ef4cc"

# Check if Docker compose stack `hotspot-run-20260727-001-postgres-1` is actually running AND backend API responds on BASE
def _is_docker_env_up():
    try:
        r = httpx.get(f"{BASE}/portal/public/context?device_id={DEVICE_ID}", timeout=1.5)
        return r.status_code == 200
    except Exception:
        return False

pytestmark = pytest.mark.skipif(
    not _is_docker_env_up(),
    reason="Requires active Hotspot server on port 58001 with pre-populated demo database"
)


def _reset():
    subprocess.run(["docker", "exec", "hotspot-run-20260727-001-postgres-1", "psql", "-U", "hotspot", "-d", "hotspot",
         "-c", "UPDATE vouchers SET status = 'pending', used_at = NULL, used_by_session_id = NULL"])
    # Reset Redis rate-limit keys so tests don't get 429 from accumulated counters
    subprocess.run(["docker", "exec", "hotspot-run-20260727-001-redis-1", "redis-cli", "KEYS", "rl:portal:*"],
                   capture_output=True)
    result = subprocess.run(["docker", "exec", "hotspot-run-20260727-001-redis-1", "redis-cli", "KEYS", "rl:portal:*"],
                            capture_output=True, text=True)
    keys = result.stdout.strip().split("\n")
    for key in keys:
        if key.strip():
            subprocess.run(["docker", "exec", "hotspot-run-20260727-001-redis-1", "redis-cli", "DEL", key.strip()],
                           capture_output=True)

def _post(path, json): return httpx.post(f"{BASE}{path}", json=json, timeout=10)
def _get(path): return httpx.get(f"{BASE}{path}", timeout=10)
def _admin_token():
    r = _post("/api/v1/auth/login", {"email": "admin@hotspot.com", "password": "Admin123!"})
    return r.json()["access_token"]


def test_portal_context_returns_voucher():
    r = _get(f"/portal/public/context?device_id={DEVICE_ID}")
    assert r.status_code == 200 and r.json()["method"] == "voucher"

def test_voucher_full_flow_with_consent():
    _reset()
    # Clean old sessions
    subprocess.run(["docker", "exec", "hotspot-run-20260727-001-postgres-1", "psql", "-U", "hotspot", "-d", "hotspot",
        "-c", "DELETE FROM guest_sessions WHERE auth_method='voucher'"])
    _reset()
    r = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "DEMO2026"})
    assert r.status_code == 200
    token = r.json()["portal_token"]
    r = _post("/portal/public/start-session", {
        "device_id": DEVICE_ID, "portal_token": token,
        "mac": "AA:BB:CC:DD:EE:11", "ip": "10.0.0.42", "ssid": "Test-SSID",
        "terms_accepted": True, "privacy_accepted": True,
        "terms_version": "v1", "privacy_version": "v1",
    })
    assert r.status_code == 200
    sess = r.json()
    assert sess["status"] == "active"
    assert sess["terms_accepted"] is True
    assert sess["terms_version"] == "v1"
    
    # Verify via admin API
    at = _admin_token()
    r = httpx.get(f"{BASE}/api/v1/sessions/{sess['session_id']}",
                  headers={"Authorization": f"Bearer {at}"}, timeout=10)
    assert r.status_code == 200
    assert r.json()["terms_accepted"] is True
    
    # Verification via direct DB: consent fields must be stored
    sid = sess["session_id"]
    result = subprocess.run(["docker", "exec", "hotspot-run-20260727-001-postgres-1", "psql", "-U", "hotspot", "-d", "hotspot",
        "-t", "-c", f"SELECT terms_accepted, terms_version FROM guest_sessions WHERE id = '{sid}'"],
        capture_output=True, text=True)
    assert "t" in result.stdout, f"DB terms not stored: {result.stdout}"
    assert "v1" in result.stdout, f"DB terms_version not stored: {result.stdout}"
    # Voucher must be used
    result = subprocess.run(["docker", "exec", "hotspot-run-20260727-001-postgres-1", "psql", "-U", "hotspot", "-d", "hotspot",
        "-t", "-c", f"SELECT v.status FROM vouchers v JOIN guest_sessions gs ON gs.voucher_id = v.id WHERE gs.id = '{sid}'"],
        capture_output=True, text=True)
    assert "used" in result.stdout, f"Voucher not marked used: {result.stdout}"

def test_terms_not_accepted_rejects():
    _reset()
    r = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "DEMO2026"})
    assert r.status_code == 200
    r = _post("/portal/public/start-session", {
        "device_id": DEVICE_ID, "portal_token": r.json()["portal_token"],
        "mac": "AA:BB:CC:DD:EE:22", "ip": "10.0.0.99", "ssid": "Test"})
    assert r.status_code == 400 and "Kullanim kosullari" in r.json()["detail"]

def test_privacy_not_accepted_rejects():
    _reset()
    r = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "DEMO2026"})
    assert r.status_code == 200
    r = _post("/portal/public/start-session", {
        "device_id": DEVICE_ID, "portal_token": r.json()["portal_token"],
        "mac": "AA:BB:CC:DD:EE:33", "ip": "10.0.0.100", "ssid": "Test",
        "terms_accepted": True, "privacy_accepted": False})
    assert r.status_code == 400 and "KVKK" in r.json()["detail"]

def test_invalid_voucher_returns_404():
    r = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "INVALID123"})
    assert r.status_code == 404

def test_wrong_device_returns_404():
    r = _post("/portal/public/verify", {"device_id": str(uuid.uuid4()), "voucher_code": "DEMO2026"})
    assert r.status_code == 404

def test_already_used_voucher_returns_409():
    _reset()
    r1 = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "DEMO2026"})
    assert r1.status_code == 200
    r2 = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "DEMO2026"})
    assert r2.status_code == 409

def test_double_session_token_rejected():
    _reset()
    r = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "DEMO2026"})
    assert r.status_code == 200
    token = r.json()["portal_token"]
    r1 = _post("/portal/public/start-session", {
        "device_id": DEVICE_ID, "portal_token": token,
        "mac": "AA:BB:CC:DD:EE:44", "ip": "10.0.0.200", "ssid": "Test",
        "terms_accepted": True, "privacy_accepted": True})
    assert r1.status_code == 200
    r2 = _post("/portal/public/start-session", {
        "device_id": DEVICE_ID, "portal_token": token,
        "mac": "AA:BB:CC:DD:EE:55", "ip": "10.0.0.201", "ssid": "Test",
        "terms_accepted": True, "privacy_accepted": True})
    assert r2.status_code in (400, 401, 409)

def test_cross_device_isolation():
    """Different device in same location can't use same voucher."""
    _reset()
    subprocess.run(["docker", "exec", "hotspot-run-20260727-001-postgres-1", "psql", "-U", "hotspot", "-d", "hotspot",
        "-c", "DELETE FROM guest_sessions WHERE auth_method='voucher'"])
    _reset()
    # First device: verify + start-session
    r = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "DEMO2026"})
    assert r.status_code == 200
    token = r.json()["portal_token"]
    r = _post("/portal/public/start-session", {
        "device_id": DEVICE_ID, "portal_token": token,
        "mac": "AA:BB:CC:DD:EE:77", "ip": "10.0.0.77", "ssid": "Test",
        "terms_accepted": True, "privacy_accepted": True})
    assert r.status_code == 200
    session_id = r.json()["session_id"]
    
    # Second device tries same voucher - must fail
    r = _post("/portal/public/verify", {"device_id": DEVICE_ID, "voucher_code": "DEMO2026"})
    assert r.status_code == 409
    assert "kullanildi" in r.json()["detail"]
    
    # Verify exactly ONE session for this voucher
    result = subprocess.run(["docker", "exec", "hotspot-run-20260727-001-postgres-1", "psql", "-U", "hotspot", "-d", "hotspot",
        "-t", "-c", f"SELECT COUNT(*) FROM guest_sessions WHERE id = '{session_id}' AND status='active' AND auth_method='voucher'"],
        capture_output=True, text=True)
    count = int(result.stdout.strip())
    assert count == 1, f"Expected 1 session, got {count}: {result.stdout}"
