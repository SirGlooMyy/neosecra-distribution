"""PMS (Property Management System) servis testleri."""
import pytest
from app.core.config import settings
from app.modules.pms.service import verify_guest_stay


@pytest.mark.asyncio
async def test_mock_pms_valid(monkeypatch):
    """Room 101 + surname DEMO should verify successfully."""
    monkeypatch.setattr(settings, "DEMO_MODE", True)
    result = await verify_guest_stay(
        room_number="101",
        surname_or_birth="DEMO",
        pms_config={"pms_type": "mock"},
    )
    assert result.verified is True
    assert result.vendor == "mock"
    assert "GUEST/DEMO" in (result.guest_name or "")


@pytest.mark.asyncio
async def test_mock_pms_invalid_room(monkeypatch):
    """Non-numeric room number should fail."""
    monkeypatch.setattr(settings, "DEMO_MODE", True)
    result = await verify_guest_stay(
        room_number="ABC",
        surname_or_birth="DEMO",
        pms_config={"pms_type": "mock"},
    )
    assert result.verified is False
    assert "sayisal" in (result.message or "").lower()


@pytest.mark.asyncio
async def test_mock_pms_invalid_surname(monkeypatch):
    """Short surname (less than 3 chars) should fail."""
    monkeypatch.setattr(settings, "DEMO_MODE", True)
    result = await verify_guest_stay(
        room_number="101",
        surname_or_birth="AB",
        pms_config={"pms_type": "mock"},
    )
    assert result.verified is False
    assert "3 harf" in (result.message or "")


@pytest.mark.asyncio
async def test_mock_pms_birth_year(monkeypatch):
    """4-digit birth year should also be accepted as surname."""
    monkeypatch.setattr(settings, "DEMO_MODE", True)
    result = await verify_guest_stay(
        room_number="101",
        surname_or_birth="1990",
        pms_config={"pms_type": "mock"},
    )
    assert result.verified is True


@pytest.mark.asyncio
async def test_opera_pms_fallback(monkeypatch):
    """Opera vendor with no SOAP URL configured falls back to mock only in demo mode."""
    monkeypatch.setattr(settings, "DEMO_MODE", True)
    result = await verify_guest_stay(
        room_number="202",
        surname_or_birth="GUEST",
        pms_config={
            "pms_type": "opera",
            "host": "",
        },
    )
    assert result.vendor == "opera"
    assert result.verified is True


@pytest.mark.asyncio
async def test_opera_pms_missing_config_fails_closed(monkeypatch):
    """Opera vendor without config must fail closed when demo mode is off."""
    monkeypatch.setattr(settings, "DEMO_MODE", False)
    result = await verify_guest_stay(
        room_number="202",
        surname_or_birth="GUEST",
        pms_config={
            "pms_type": "opera",
            "host": "",
        },
    )
    assert result.vendor == "opera"
    assert result.verified is False
    assert "yapilandirilmamis" in (result.message or "").lower()


@pytest.mark.asyncio
async def test_pms_empty_params(monkeypatch):
    """Empty room and surname should fail."""
    monkeypatch.setattr(settings, "DEMO_MODE", True)
    result = await verify_guest_stay(
        room_number="",
        surname_or_birth="",
        pms_config={"pms_type": "mock"},
    )
    assert result.verified is False


@pytest.mark.asyncio
async def test_pms_unknown_vendor_fails_closed(monkeypatch):
    """Unknown vendor name should fail closed instead of silently mocking."""
    monkeypatch.setattr(settings, "DEMO_MODE", True)
    result = await verify_guest_stay(
        room_number="101",
        surname_or_birth="DEMO",
        pms_config={"pms_type": "nonexistent"},
    )
    assert result.verified is False
    assert result.vendor == "nonexistent"


@pytest.mark.asyncio
async def test_pms_missing_config_fails_closed(monkeypatch):
    """Missing PMS config should not silently fall back to mock."""
    monkeypatch.setattr(settings, "DEMO_MODE", False)
    result = await verify_guest_stay(
        room_number="101",
        surname_or_birth="DEMO",
        pms_config=None,
    )
    assert result.verified is False
    assert result.vendor == "unknown"
    assert "bulunamad" in (result.message or "").lower()
