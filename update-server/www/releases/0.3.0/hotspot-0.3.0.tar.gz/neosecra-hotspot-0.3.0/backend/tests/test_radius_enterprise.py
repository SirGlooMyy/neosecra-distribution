"""RADIUS Enterprise / 802.1X servis testleri (MAB, VLAN, FreeRADIUS config)."""
import pytest
import uuid
import unittest.mock as mock

from app.modules.radius.mab_service import add_mac, remove_mac, list_macs
from app.modules.radius.vlan_service import (
    assign_vlan,
    build_user_group_key,
    build_vlan_avps,
    create_profile,
    sync_profile_for_group,
)
from app.modules.radius.enterprise_service import (
    generate_freeradius_config,
    enable_dynamic_vlan,
    configure_mac_bypass,
    generate_radius_client_config,
)


@pytest.mark.asyncio
async def test_mab_whitelist_crud():
    """MAB whitelist ekleme, listeleme ve silme."""
    customer_id = uuid.uuid4()

    mock_entry = mock.AsyncMock()
    mock_entry.id = uuid.uuid4()
    mock_entry.mac_address = "AA:BB:CC:DD:EE:FF"
    mock_entry.customer_id = customer_id
    mock_entry.is_active = True
    mock_entry.description = "Test device"

    mock_db = mock.AsyncMock()
    mock_db.add = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()
    mock_db.get = mock.AsyncMock(return_value=mock_entry)

    entry = await add_mac(mock_db, "AA:BB:CC:DD:EE:FF", "Test device", customer_id)
    assert entry.mac_address == "AA:BB:CC:DD:EE:FF"

    mock_scalar = mock.MagicMock()
    mock_scalar_result = mock.MagicMock()
    mock_scalar_result.all.return_value = [mock_entry]
    mock_scalar.scalars.return_value = mock_scalar_result
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    entries = await list_macs(mock_db, customer_id)
    assert len(entries) == 1

    deleted = await remove_mac(mock_db, mock_entry.id)
    assert deleted is True


@pytest.mark.asyncio
async def test_vlan_profile_crud():
    """VLAN profili CRUD islemleri."""
    customer_id = uuid.uuid4()

    mock_vlan = mock.AsyncMock()
    mock_vlan.id = uuid.uuid4()
    mock_vlan.name = "Employees"
    mock_vlan.vlan_id = 100
    mock_vlan.user_group = "employee"
    mock_vlan.customer_id = customer_id

    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = None
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)
    mock_db.add = mock.AsyncMock()
    mock_db.commit = mock.AsyncMock()
    mock_db.refresh = mock.AsyncMock()

    profile = await create_profile(
        mock_db,
        customer_id=customer_id,
        name="Employees",
        vlan_id=100,
        user_group="employee",
    )
    assert profile is not None


@pytest.mark.asyncio
async def test_vlan_profile_duplicate():
    """Duplicate user_group should raise 409."""
    customer_id = uuid.uuid4()

    mock_existing = mock.AsyncMock()
    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = mock_existing
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc:
        await create_profile(
            mock_db,
            customer_id=customer_id,
            name="Employees",
            vlan_id=100,
            user_group="employee",
        )
    assert exc.value.status_code == 409


@pytest.mark.asyncio
async def test_sync_profile_for_group_uses_stable_key_and_replaces_old_profile():
    customer_id = uuid.uuid4()
    group_id = uuid.uuid4()
    previous_name = "Old Group"
    current_name = "New Group"

    current_result = mock.MagicMock()
    current_result.scalar_one_or_none.return_value = None
    previous_profile = mock.MagicMock()
    previous_profile.user_group = build_user_group_key(previous_name, group_id)
    previous_result = mock.MagicMock()
    previous_result.scalar_one_or_none.return_value = previous_profile

    mock_db = mock.AsyncMock()
    mock_db.execute = mock.AsyncMock(side_effect=[current_result, previous_result])
    mock_db.add = mock.MagicMock()
    mock_db.delete = mock.AsyncMock()
    mock_db.flush = mock.AsyncMock()

    profile = await sync_profile_for_group(
        mock_db,
        customer_id=customer_id,
        group_id=group_id,
        group_name=current_name,
        vlan_id=123,
        previous_group_name=previous_name,
        description="Gold tier",
    )

    assert profile is not None
    assert profile.user_group == build_user_group_key(current_name, group_id)
    assert profile.vlan_id == 123
    assert profile.description == "Gold tier"
    mock_db.add.assert_called_once()
    mock_db.delete.assert_awaited_once_with(previous_profile)
    mock_db.flush.assert_awaited()


@pytest.mark.asyncio
async def test_assign_vlan_default():
    """Unknown user_group should return VLAN 1."""
    mock_db = mock.AsyncMock()
    mock_scalar = mock.MagicMock()
    mock_scalar.scalar_one_or_none.return_value = None
    mock_db.execute = mock.AsyncMock(return_value=mock_scalar)

    vlan_id = await assign_vlan(mock_db, "unknown_group")
    assert vlan_id == 1


def test_build_vlan_avps():
    avps = build_vlan_avps(100)
    assert avps["Tunnel-Type"] == 13
    assert avps["Tunnel-Medium-Type"] == 6
    assert avps["Tunnel-Private-Group-ID"] == "100"


def test_build_user_group_key_is_stable_and_bounded():
    group_id = uuid.uuid4()
    key = build_user_group_key("Very Long Group Name With Special / Characters !!!", group_id)
    assert key.endswith(group_id.hex[:8])
    assert len(key) <= 100
    assert key.startswith("very-long-group-name-with-special-characters")


def test_generate_freeradius_config():
    """FreeRADIUS config should contain the location name and NAS identifier."""
    mock_client = mock.MagicMock()
    mock_client.nas_identifier = "nas-01"
    mock_client.nas_ip = "192.168.1.1"
    mock_client.shared_secret_encrypted = None

    config = generate_freeradius_config(
        location_id=str(uuid.uuid4()),
        radius_client=mock_client,
        location_name="Test Office",
    )
    assert "Test Office" in config
    assert "nas-01" in config
    assert "CHANGE_ME" in config


def test_enable_dynamic_vlan():
    mock_client = mock.MagicMock()
    mock_client.nas_identifier = "nas-01"

    result = enable_dynamic_vlan(mock_client, vlan_id=200, user_group="iot")
    assert result["Tunnel-Type"] == 13
    assert result["Tunnel-Private-Group-ID"] == "200"
    assert result["_meta"]["nas_identifier"] == "nas-01"


def test_configure_mac_bypass():
    macs = ["AA:BB:CC:DD:EE:01", "AA:BB:CC:DD:EE:02"]
    result = configure_mac_bypass("10.0.0.1", "secret123", macs)
    assert result["mac_count"] == 2
    assert result["nas_ip"] == "10.0.0.1"
    assert "AA:BB:CC:DD:EE:01" in result["config"]


def test_generate_radius_client_config():
    config = generate_radius_client_config("10.0.0.1", "shared_secret", "cisco")
    assert "10.0.0.1" in config
    assert "shared_secret" in config
    assert "cisco" in config
