"""LDAP authentication servis testleri."""
import pytest
from app.modules.ldap.service import authenticate, search_user, _parse_ldap_url


@pytest.mark.asyncio
async def test_authenticate_mock(monkeypatch):
    """LDAP without ldap3 installed should raise ImportError gracefully."""
    monkeypatch.setattr("app.modules.ldap.service.LDAP_AVAILABLE", False)
    with pytest.raises(ImportError) as exc:
        await authenticate(username="testuser", password="testpass")
    assert "ldap3" in str(exc.value)


@pytest.mark.asyncio
async def test_search_user_mock(monkeypatch):
    """LDAP search without ldap3 installed should raise ImportError."""
    monkeypatch.setattr("app.modules.ldap.service.LDAP_AVAILABLE", False)
    with pytest.raises(ImportError) as exc:
        await search_user(query="testuser")
    assert "ldap3" in str(exc.value)


def test_parse_ldap_url_default():
    """Default LDAP URL parsing."""
    result = _parse_ldap_url(None)
    assert result["host"] == "localhost"
    assert result["port"] == 389
    assert result["use_ssl"] is False


def test_parse_ldap_url_ldaps():
    """LDAPS URL parsing."""
    result = _parse_ldap_url("ldaps://dc01.example.com:636")
    assert result["host"] == "dc01.example.com"
    assert result["port"] == 636
    assert result["use_ssl"] is True


def test_parse_ldap_url_custom():
    """Custom LDAP URL parsing."""
    result = _parse_ldap_url("ldap://192.168.1.100:1389")
    assert result["host"] == "192.168.1.100"
    assert result["port"] == 1389
    assert result["use_ssl"] is False


@pytest.mark.asyncio
async def test_authenticate_empty_username():
    """Empty username should return None (before ldap3 check)."""
    from app.modules.ldap.service import LDAP_AVAILABLE

    if not LDAP_AVAILABLE:
        with pytest.raises(ImportError):
            await authenticate(username="", password="pass")
    else:
        result = await authenticate(username="", password="pass")
        assert result is None


@pytest.mark.asyncio
async def test_authenticate_empty_password():
    """Empty password should return None (before ldap3 check)."""
    from app.modules.ldap.service import LDAP_AVAILABLE

    if not LDAP_AVAILABLE:
        with pytest.raises(ImportError):
            await authenticate(username="user", password="")
    else:
        result = await authenticate(username="user", password="")
        assert result is None
