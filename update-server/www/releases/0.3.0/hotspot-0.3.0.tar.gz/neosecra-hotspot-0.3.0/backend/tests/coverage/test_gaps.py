"""Coverage gap analysis — identifies modules below 70% threshold with missing lines."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
sys.path.insert(0, str(REPO_ROOT / "backend"))

ALL_MODULES = [
    "alarm", "archive", "audit", "auth", "ban", "customers", "devices",
    "firewall_adapters", "foreigner", "identity", "ldap", "licensing",
    "local_auth", "locations", "logs_5651", "meeting", "mfa", "partners",
    "pms", "portal", "public_content", "radius", "reports", "search",
    "sessions", "site_bridge", "sms", "syslog", "system", "tenants",
    "traffic", "user_groups", "vouchers", "whatsapp", "workers",
]

COVERAGE_THRESHOLD = 70.0


def test_all_modules_listed():
    """Verify all 35 expected backend modules exist."""
    module_dir = REPO_ROOT / "backend" / "app" / "modules"
    present = sorted(d.name for d in module_dir.iterdir() if d.is_dir() and not d.name.startswith("_"))
    assert len(present) >= 33, f"Expected at least 33 modules, found {len(present)}"
    for m in ALL_MODULES:
        assert m in present, f"Module {m} not found on disk"


@pytest.mark.skipif(
    not (REPO_ROOT / "backend" / "coverage.json").exists(),
    reason="coverage.json not found — run scripts/coverage-backend.sh first",
)
def test_coverage_json_exists_and_readable():
    import json
    with open(REPO_ROOT / "backend" / "coverage.json") as f:
        data = json.load(f)
    assert "meta" in data
    assert "totals" in data
    assert "files" in data
    total = data["totals"]["percent_covered"]
    print(f"\nTotal coverage: {total:.1f}%")


@pytest.mark.skipif(
    not (REPO_ROOT / "backend" / "coverage.json").exists(),
    reason="coverage.json not found",
)
def test_identify_low_coverage_modules():
    import json
    with open(REPO_ROOT / "backend" / "coverage.json") as f:
        data = json.load(f)

    low_coverage = []
    for filepath, file_data in data["files"].items():
        if "app/modules/" not in filepath:
            continue
        pct = file_data["summary"]["percent_covered"]
        if pct < COVERAGE_THRESHOLD:
            low_coverage.append((filepath, pct))

    low_coverage.sort(key=lambda x: x[1])
    print(f"\n=== Modules below {COVERAGE_THRESHOLD}% coverage ({len(low_coverage)} found) ===")
    for path, pct in low_coverage:
        print(f"  {pct:5.1f}%  {path}")

    for path, pct in low_coverage[:10]:
        file_data = data["files"][path]
        missing = file_data.get("missing_lines", []) or file_data["summary"].get("missing_lines", [])
        if missing:
            print(f"\nMissing lines in {path}:")
            for line in missing[:20]:
                print(f"  - Line {line}")


@pytest.mark.skipif(
    not (REPO_ROOT / "backend" / "coverage.json").exists(),
    reason="coverage.json not found",
)
def test_module_coverage_summary():
    import json
    with open(REPO_ROOT / "backend" / "coverage.json") as f:
        data = json.load(f)

    module_coverage: dict[str, list] = {}
    for filepath, file_data in data["files"].items():
        if "app/modules/" not in filepath:
            continue
        parts = filepath.replace("app/modules/", "").split("/")
        module = parts[0]
        pct = file_data["summary"]["percent_covered"]
        module_coverage.setdefault(module, []).append(pct)

    print(f"\n=== Module coverage summary ({len(module_coverage)} modules) ===")
    below_threshold = []
    for mod, pcts in sorted(module_coverage.items()):
        avg = sum(pcts) / len(pcts)
        status = "PASS" if avg >= COVERAGE_THRESHOLD else "FAIL"
        if avg < COVERAGE_THRESHOLD:
            below_threshold.append((mod, avg))
        print(f"  [{status}] {mod:25s} {avg:5.1f}% (across {len(pcts)} files)")

    assert len(below_threshold) == 0, (
        f"{len(below_threshold)} modules below {COVERAGE_THRESHOLD}%: "
        + ", ".join(f"{m}({a:.1f}%)" for m, a in below_threshold)
    )


def test_direct_test_files_exist_for_core_modules():
    module_test_map = {
        "alarm": "test_alarm_router.py",
        "ban": "test_ban_api.py",
        "ldap": "test_ldap_service.py",
        "meeting": "test_meeting_service.py",
        "mfa": "test_mfa_service.py",
        "pms": "test_pms_service.py",
        "public_content": "test_public_content.py",
        "radius": "test_radius_challenge.py",
        "sms": "test_sms_negative.py",
        "system": "test_system_backup.py",
        "traffic": "test_traffic_api.py",
        "user_groups": "test_user_groups_api.py",
        "vouchers": "test_voucher_service.py",
        "whatsapp": "test_whatsapp.py",
    }

    missing = []
    for module, test_file in module_test_map.items():
        if not (REPO_ROOT / "backend" / "tests" / test_file).exists():
            missing.append(test_file)

    if missing:
        pytest.fail(f"Missing direct test files: {missing}")
