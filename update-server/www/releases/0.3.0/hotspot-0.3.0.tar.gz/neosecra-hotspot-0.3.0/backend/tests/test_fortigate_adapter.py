"""Comprehensive tests for the FortiGate adapter using a fake FortiOS REST API server.

Spins up a lightweight Starlette/Uvicorn server that mimics the FortiOS
API endpoints, so all tests run without a real device.
"""
from __future__ import annotations

from typing import Any

import httpx
import pytest

from app.modules.firewall_adapters.base import ConnectionConfig
from app.modules.firewall_adapters.fortigate import FortiGateAdapter, parse_syslog_event
from tests.fake_fortigate_server import FakeFortiGateServer


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

@pytest.fixture
def session_data() -> dict[str, Any]:
    """Minimal guest session dict used across authorize/revoke tests."""
    return {
        "session_id": "sess-42",
        "ip": "10.0.0.55",
        "mac": "AA:BB:CC:DD:EE:FF",
    }


@pytest.fixture
def session_with_policy() -> dict[str, Any]:
    """Guest session carrying a group policy (vlan + bandwidth shaping)."""
    return {
        "session_id": "sess-99",
        "ip": "10.0.0.77",
        "mac": "11:22:33:44:55:66",
        "policy": {
            "group_id": "premium-gold",
            "group_name": "Premium Gold",
            "vlan_id": 100,
            "bandwidth_up": 5000,
            "bandwidth_down": 10000,
            "session_timeout": 60,
            "idle_timeout": 15,
        },
    }


async def _build_adapter(
    fg: FakeFortiGateServer,
    **overrides: Any,
) -> FortiGateAdapter:
    """Build a FortiGateAdapter pointed at the fake server.

    The real adapter forces HTTPS; the fake server is plain HTTP, so we
    patch ``_base_url`` after construction.
    """
    config = ConnectionConfig(
        vendor="fortigate",
        api_host="127.0.0.1",
        api_port=fg.port,
        api_token="test-token",
        **overrides,
    )
    adapter = FortiGateAdapter(config)
    # Override HTTPS → HTTP for the fake server
    adapter._base_url = f"http://{config.api_host}:{config.api_port}/api/v2"
    return adapter


# ===================================================================
# test_connection
# ===================================================================

@pytest.mark.asyncio
async def test_connection_success() -> None:
    """test_connection returns ok=True with hostname and version in message."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        result = await adapter.test_connection()

    assert result.ok is True
    assert "fake-fortigate" in result.message
    assert "v7.2.10" in result.message
    assert isinstance(result.data, dict)
    assert result.data.get("hostname") == "fake-fortigate"


@pytest.mark.asyncio
async def test_connection_failure_when_server_down() -> None:
    """test_connection returns ok=False when the device is unreachable."""
    adapter = FortiGateAdapter(
        ConnectionConfig(
            vendor="fortigate",
            api_host="127.0.0.1",
            api_port=9,  # nothing listening here
            api_token="test-token",
        )
    )
    result = await adapter.test_connection()

    assert result.ok is False
    assert result.message  # non-empty error message


# ===================================================================
# get_device_info
# ===================================================================

@pytest.mark.asyncio
async def test_get_device_info_parses_response() -> None:
    """get_device_info returns a dict with expected keys."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        info = await adapter.get_device_info()

    assert info["hostname"] == "fake-fortigate"
    assert info["model"] == "FortiGate-100F"
    assert info["serial_number"] == "FGT-FAKE-1234"
    assert info["firmware_version"] == "v7.2.10"
    # bios_version is not in fake-server response -> None
    assert info.get("bios_version") is None


# ===================================================================
# get_interfaces
# ===================================================================

@pytest.mark.asyncio
async def test_get_interfaces_parses_response() -> None:
    """get_interfaces returns a list of dicts with normalized fields."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        interfaces = await adapter.get_interfaces()

    assert isinstance(interfaces, list)
    assert len(interfaces) == 3

    names = [iface["name"] for iface in interfaces]
    assert "port1" in names
    assert "port2" in names
    assert "port3" in names

    # port1 and port2 are up; port3 is down
    port1 = next(i for i in interfaces if i["name"] == "port1")
    assert port1["type"] == "physical"
    assert port1["ip"] == "192.168.1.1/24"
    assert port1["vdom"] == "root"
    assert port1["status"] == "up"

    port3 = next(i for i in interfaces if i["name"] == "port3")
    assert port3["status"] == "down"


# ===================================================================
# get_captive_portal_config
# ===================================================================

@pytest.mark.asyncio
async def test_get_captive_portal_config_returns_user_groups() -> None:
    """get_captive_portal_config returns dict with user_groups list."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        config = await adapter.get_captive_portal_config()

    assert isinstance(config, dict)
    assert "user_groups" in config
    groups = config["user_groups"]
    assert isinstance(groups, list)
    assert len(groups) == 2

    guest_group = next(g for g in groups if g["name"] == "Guest-Group")
    assert guest_group["members"] == 1  # one member

    employees = next(g for g in groups if g["name"] == "Employees")
    assert employees["members"] == 2  # alice + bob


# ===================================================================
# get_active_sessions
# ===================================================================

@pytest.mark.asyncio
async def test_get_active_sessions_parses_response() -> None:
    """get_active_sessions returns a list of session dicts."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        sessions = await adapter.get_active_sessions()

    assert isinstance(sessions, list)
    assert len(sessions) == 2

    # Check first session
    s1 = sessions[0]
    assert s1["ip"] == "10.0.0.100"
    assert s1["user"] == "guest-user-1"
    assert s1["mac"] == "AA:BB:CC:11:22:33"
    assert s1["group"] == ["Guest-Group"]

    s2 = sessions[1]
    assert s2["ip"] == "10.0.0.101"
    assert s2["user"] == "guest-user-2"


# ===================================================================
# get_user_ip_mac_mapping
# ===================================================================

@pytest.mark.asyncio
async def test_get_user_ip_mac_mapping_parses_response() -> None:
    """get_user_ip_mac_mapping returns list of ip/mac/interface dicts."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        mappings = await adapter.get_user_ip_mac_mapping()

    assert isinstance(mappings, list)
    # Default response has two entries
    assert len(mappings) == 2

    m0 = mappings[0]
    assert m0["ip"] == "10.0.0.100"
    assert m0["mac"] == "AA:BB:CC:11:22:33"
    assert m0["interface"] == "port2"


# ===================================================================
# authorize_guest
# ===================================================================

@pytest.mark.asyncio
async def test_authorize_guest_creates_address_and_returns_success(
    session_data: dict[str, Any],
) -> None:
    """authorize_guest creates a firewall address and returns ok=True."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        result = await adapter.authorize_guest(session_data)

    assert result.ok is True
    assert "10.0.0.55" in result.message
    assert result.data["address"] == "hsess-42"
    assert "10.0.0.55" in fg.authorized_ips


@pytest.mark.asyncio
async def test_authorize_guest_with_group_policy(
    session_with_policy: dict[str, Any],
) -> None:
    """authorize_guest includes policy details (vlan, bandwidth) in returned data."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        result = await adapter.authorize_guest(session_with_policy)

    assert result.ok is True
    assert result.data["address"] == "hsess-99"
    assert "10.0.0.77" in fg.authorized_ips

    policy = result.data.get("policy", {})
    assert policy.get("vlan_id") == 100
    assert policy.get("bandwidth_up") == 5000
    assert policy.get("bandwidth_down") == 10000
    assert policy.get("group_name") == "Premium Gold"


@pytest.mark.asyncio
async def test_authorize_guest_missing_ip_returns_error() -> None:
    """authorize_guest returns ok=False when session has no ip."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        result = await adapter.authorize_guest({"session_id": "sess-3"})

    assert result.ok is False
    assert "ip required" in result.message


@pytest.mark.asyncio
async def test_authorize_guest_handles_401() -> None:
    """authorize_guest returns ok=False when the device returns 401."""
    async with FakeFortiGateServer() as fg:
        fg.simulate_401 = True
        adapter = await _build_adapter(fg)
        session = {"session_id": "sess-42", "ip": "10.0.0.55"}
        result = await adapter.authorize_guest(session)

    assert result.ok is False
    assert "401" in result.message


@pytest.mark.asyncio
async def test_authorize_guest_handles_timeout() -> None:
    """authorize_guest returns ok=False when the device times out."""
    async with FakeFortiGateServer() as fg:
        fg.simulate_timeout = True
        adapter = await _build_adapter(fg)
        session = {"session_id": "sess-42", "ip": "10.0.0.55"}
        result = await adapter.authorize_guest(session)

    assert result.ok is False


@pytest.mark.asyncio
async def test_authorize_guest_with_vdom(session_data: dict[str, Any]) -> None:
    """authorize_guest works when a VDOM is configured on the connection."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg, api_vdom="root")
        result = await adapter.authorize_guest(session_data)

    assert result.ok is True
    assert result.data["address"] == "hsess-42"
    assert "10.0.0.55" in fg.authorized_ips


@pytest.mark.asyncio
async def test_authorize_guest_handles_auth_failure() -> None:
    """authorize_guest returns ok=False when simulate_auth_failure is on (403)."""
    async with FakeFortiGateServer() as fg:
        fg.simulate_auth_failure = True
        adapter = await _build_adapter(fg)
        session = {"session_id": "sess-42", "ip": "10.0.0.55"}
        result = await adapter.authorize_guest(session)

    assert result.ok is False
    assert "403" in result.message or "authorization failed" in result.message


# ===================================================================
# revoke_guest
# ===================================================================

@pytest.mark.asyncio
async def test_revoke_guest_deletes_address_and_returns_success(
    session_data: dict[str, Any],
) -> None:
    """revoke_guest deletes the firewall address and returns ok=True."""
    async with FakeFortiGateServer() as fg:
        # First authorize so the address exists
        adapter = await _build_adapter(fg)
        await adapter.authorize_guest(session_data)
        assert "10.0.0.55" in fg.authorized_ips

        # Now revoke
        result = await adapter.revoke_guest(session_data)

    assert result.ok is True
    assert "10.0.0.55" in result.message


@pytest.mark.asyncio
async def test_revoke_guest_handles_404_gracefully() -> None:
    """revoke_guest returns ok=False when the device returns an error (401 sim)."""
    async with FakeFortiGateServer() as fg:
        fg.simulate_401 = True
        adapter = await _build_adapter(fg)
        session = {"session_id": "sess-nonexistent", "ip": "10.0.0.200"}
        result = await adapter.revoke_guest(session)

    assert result.ok is False
    assert result.message  # non-empty error


@pytest.mark.asyncio
async def test_revoke_guest_handles_device_error() -> None:
    """revoke_guest returns ok=False when the device returns an error."""
    async with FakeFortiGateServer() as fg:
        fg.simulate_401 = True
        adapter = await _build_adapter(fg)
        session = {"session_id": "sess-1", "ip": "10.0.0.1"}
        result = await adapter.revoke_guest(session)

    assert result.ok is False
    assert "401" in result.message


# ===================================================================
# get_capabilities
# ===================================================================

@pytest.mark.asyncio
async def test_get_capabilities_returns_expected_flags() -> None:
    """get_capabilities returns a FirewallCapabilities with expected values."""
    adapter = FortiGateAdapter(
        ConnectionConfig(vendor="fortigate", api_host="10.0.0.1", api_token="t")
    )
    caps = adapter.get_capabilities()

    assert caps.external_captive_portal is True
    assert caps.radius_authentication is True
    assert caps.radius_accounting is True
    assert caps.radius_coa is True
    assert caps.disconnect_message is True
    assert caps.mac_auth_bypass is True
    assert caps.local_guest_users is True
    assert caps.active_session_query is True
    assert caps.authorize_guest_api is True
    assert caps.revoke_guest_api is True
    assert caps.syslog is True
    assert caps.api_health is True

    # These should remain False for FortiGate
    assert caps.config_backup is False
    assert caps.vpn_radius_mfa is False


# ===================================================================
# Additional edge-case / error-path tests
# ===================================================================

@pytest.mark.asyncio
async def test_get_device_info_handles_401() -> None:
    """get_device_info raises AdapterError when device returns 401."""
    async with FakeFortiGateServer() as fg:
        fg.simulate_401 = True
        adapter = await _build_adapter(fg)
        with pytest.raises(Exception):
            await adapter.get_device_info()


@pytest.mark.asyncio
async def test_get_interfaces_handles_timeout() -> None:
    """get_interfaces raises an error when the device times out."""
    async with FakeFortiGateServer() as fg:
        fg.simulate_timeout = True
        adapter = await _build_adapter(fg)
        with pytest.raises(Exception):
            await adapter.get_interfaces()


@pytest.mark.asyncio
async def test_get_active_sessions_handles_401() -> None:
    """get_active_sessions raises AdapterError when device returns 401."""
    async with FakeFortiGateServer() as fg:
        fg.simulate_401 = True
        adapter = await _build_adapter(fg)
        with pytest.raises(Exception):
            await adapter.get_active_sessions()


@pytest.mark.asyncio
async def test_get_user_ip_mac_mapping_reflects_authorized_ips() -> None:
    """After authorize_guest, the IP/MAC mapping includes the authorized IP."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        # Authorize a new guest
        await adapter.authorize_guest({"session_id": "sess-100", "ip": "10.0.0.200"})
        mappings = await adapter.get_user_ip_mac_mapping()

    ips = [m["ip"] for m in mappings]
    assert "10.0.0.200" in ips
    # When authorized_ips is non-empty, the fake server only returns
    # entries from that set, so the default 10.0.0.100 is not included.
    assert len(ips) == 1


@pytest.mark.asyncio
async def test_adapter_works_without_api_token() -> None:
    """Adapter can be created without an API token."""
    async with FakeFortiGateServer() as fg:
        config = ConnectionConfig(
            vendor="fortigate",
            api_host="127.0.0.1",
            api_port=fg.port,
            api_token=None,
        )
        adapter = FortiGateAdapter(config)
        # Override HTTPS → HTTP for the fake server
        adapter._base_url = f"http://{config.api_host}:{config.api_port}/api/v2"
        result = await adapter.test_connection()

    assert result.ok is True


@pytest.mark.asyncio
async def test_revoke_guest_without_prior_authorize() -> None:
    """revoke_guest on a non-existent address still returns success
    because the fake server always returns HTTP 200 for DELETE.
    This exercises the adapter's behaviour where the device
    responds OK even when there's nothing to delete."""
    async with FakeFortiGateServer() as fg:
        adapter = await _build_adapter(fg)
        session = {"session_id": "sess-unknown", "ip": "10.0.0.250"}
        result = await adapter.revoke_guest(session)

    assert result.ok is True
    assert "10.0.0.250" in result.message


# ===================================================================
# parse_syslog_event (module-level function)
# ===================================================================

class TestParseSyslogEvent:
    """Tests for the standalone parse_syslog_event function."""

    def test_traffic_log(self):
        raw = (
            'date=2026-07-27 time=12:30:00 devname="FG-100F" devid="FGT-FAKE-1234" '
            'logid="0000000013" type="traffic" subtype="forward" level="notice" '
            'srcip=10.0.0.1 srcport=54321 srcintf="port1" '
            'dstip=8.8.8.8 dstport=53 dstintf="port2" '
            'policyid=1 sessionid=100001 proto=17 action="accept" '
            'duration=120 sentbyte=4096 rcvdbyte=8192 '
            'user="test@example.com" service="dns"'
        )
        result = parse_syslog_event(raw)
        assert result["vendor"] == "fortigate"
        assert result["log_type"] == "traffic"
        assert result["log_subtype"] == "forward"
        assert result["severity"] == "low"  # notice → low
        assert result["src_ip"] == "10.0.0.1"
        assert result["dst_ip"] == "8.8.8.8"
        assert result["src_port"] == 54321
        assert result["dst_port"] == 53
        assert result["action"] == "accept"
        assert result["policyid"] == 1
        assert result["duration"] == 120
        assert result["sentbyte"] == 4096
        assert result["rcvdbyte"] == 8192
        assert result["session_id"] == "100001"
        assert result["user"] == "test@example.com"
        assert result["service"] == "dns"
        assert result["proto"] == "17"
        assert result["device_name"] == "FG-100F"

    def test_event_log(self):
        raw = (
            'date=2026-07-27 time=14:00:00 devname="FG-100F" type="event" '
            'subtype="system" level="information" logid="0100038201" '
            'user="admin" message="Configuration change"'
        )
        result = parse_syslog_event(raw)
        assert result["log_type"] == "event"
        assert result["log_subtype"] == "system"
        assert result["severity"] == "info"
        assert result["user"] == "admin"

    def test_utm_log(self):
        raw = (
            'date=2026-07-27 time=15:30:00 devname="FG-100F" type="utm" '
            'subtype="virus" level="warning" srcip=10.0.0.2 dstip=10.0.0.3 '
            'action="blocked"'
        )
        result = parse_syslog_event(raw)
        assert result["log_type"] == "utm"
        assert result["log_subtype"] == "virus"
        assert result["severity"] == "medium"  # warning → medium

    def test_severity_mapping_all_levels(self):
        cases = [
            ("emergency", "critical"), ("alert", "critical"), ("critical", "critical"),
            ("error", "high"), ("warning", "medium"), ("notice", "low"),
            ("information", "info"), ("info", "info"), ("debug", "info"),
        ]
        for raw_level, expected in cases:
            raw = f'date=2026-07-27 time=00:00:00 type="traffic" level="{raw_level}"'
            result = parse_syslog_event(raw)
            assert result["severity"] == expected, f"level={raw_level} -> {expected}"

    def test_anomaly_log_type(self):
        raw = (
            'date=2026-07-27 time=16:00:00 type="anomaly" subtype="syn_flood" '
            'level="critical" action="detected"'
        )
        result = parse_syslog_event(raw)
        assert result["log_type"] == "anomaly"
        assert result["severity"] == "critical"

    def test_iap_log_type(self):
        raw = (
            'date=2026-07-27 time=17:00:00 type="iap" subtype="station" '
            'level="information" action="associate"'
        )
        result = parse_syslog_event(raw)
        assert result["log_type"] == "iap"

    def test_session_id_from_logid(self):
        raw = (
            'date=2026-07-27 time=18:00:00 type="event" '
            'logid="0100038201" action="login"'
        )
        result = parse_syslog_event(raw)
        assert result["session_id"] == "0100038201"

    def test_no_pri_line(self):
        """Line without PRI."""
        raw = 'date=2026-07-27 time=00:00:00 type="traffic" action="deny"'
        result = parse_syslog_event(raw)
        assert result is not None
        assert result["action"] == "deny"

    def test_pri_stripped(self):
        """Line with leading <PRI> should be stripped."""
        raw = '<14>date=2026-07-27 time=00:00:00 type="traffic" action="accept"'
        result = parse_syslog_event(raw)
        assert result["action"] == "accept"

    def test_int_conversion_handles_missing(self):
        """Missing numeric fields default to None."""
        raw = 'date=2026-07-27 time=00:00:00 type="traffic"'
        result = parse_syslog_event(raw)
        assert result["duration"] is None
        assert result["sentbyte"] is None
        assert result["rcvdbyte"] is None
        assert result["policyid"] is None

    def test_malformed_quotes_fallback(self):
        """Malformed quoting falls back to simple split."""
        raw = 'date=2026-07-27 time=00:00:00 type="traffic action="deny"'
        result = parse_syslog_event(raw)
        # The adapter should still parse something useful
        assert result["vendor"] == "fortigate"
