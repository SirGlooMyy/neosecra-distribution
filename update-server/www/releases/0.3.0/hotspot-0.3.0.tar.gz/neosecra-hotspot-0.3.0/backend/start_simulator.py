"""Quick simulator starter script."""
import asyncio
import sys
sys.path.insert(0, ".")
from tests.fake_fortigate_server import FakeFortiGateServer

async def main():
    server = FakeFortiGateServer("0.0.0.0", 40000)
    await server.start()
    print("SIMULATOR_READY", flush=True)
    while True:
        await asyncio.sleep(3600)

asyncio.run(main())
