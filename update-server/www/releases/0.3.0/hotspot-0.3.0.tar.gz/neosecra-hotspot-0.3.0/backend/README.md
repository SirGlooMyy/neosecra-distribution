# Backend Skeleton

FastAPI + SQLAlchemy 2.x + Alembic tabanlı modüler backend iskeleti.

## Modüller
- auth
- tenants
- partners
- customers
- locations
- devices
- firewall_adapters
- portal
- radius
- syslog
- sessions
- identity
- vouchers
- sms
- logs_5651
- archive
- reports
- licensing
- audit
- workers
- site_bridge
